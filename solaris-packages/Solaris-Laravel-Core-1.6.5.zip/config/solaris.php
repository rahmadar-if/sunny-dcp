<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Application
    |--------------------------------------------------------------------------
    |
    | Branding, meta tags, and static asset paths used across the UI.
    |
    */
    'application' => [
        'title' => env('APP_NAME', 'Solaris'),

        'meta' => [
            'author'      => 'Solaris',
            'description' => 'The future of customer relationships rises. Simple, straightforward, CRM is easy as 1-2-3',
            'keywords'    => 'admin dashboard, template admin, admin template, dashboard',
            'viewport'    => 'width=device-width, initial-scale=1.0',
        ],

        'assets' => [
            'icon' => 'vendor/solaris/solaris-laravel-core/resources/assets/images/favicon.ico',
            'logo' => [
                'auth' => [
                    'white' => 'vendor/solaris/solaris-laravel-core/resources/assets/images/logo/sunny_logo_black_no_bg.png',
                    'dark'  => 'vendor/solaris/solaris-laravel-core/resources/assets/images/logo/sunny_logo_white_no_bg.png',
                ],
                'header' => [
                    'white' => 'vendor/solaris/solaris-laravel-core/resources/assets/images/logo/sunny_logo_black_no_bg.png',
                    'dark'  => 'vendor/solaris/solaris-laravel-core/resources/assets/images/logo/sunny_logo_white_no_bg.png',
                    'icon'  => 'vendor/solaris/solaris-laravel-core/resources/assets/images/logo/sunny_logo_only_no_bg.png',
                ],
                'sidebar' => [
                    'white' => 'vendor/solaris/solaris-laravel-core/resources/assets/images/logo/sunny_logo_black_no_bg.png',
                    'dark'  => 'vendor/solaris/solaris-laravel-core/resources/assets/images/logo/sunny_logo_white_no_bg.png',
                    'icon'  => 'vendor/solaris/solaris-laravel-core/resources/assets/images/logo/sunny_logo_only_no_bg.png',
                ],
            ],
            'error_background'   => 'vendor/solaris/solaris-laravel-core/resources/assets/images/sunny_login_bg.jpg',
            'profile_background' => 'vendor/solaris/solaris-laravel-core/resources/assets/images/media/media-3.jpg',
            'favicon'             => 'vendor/solaris/solaris-laravel-core/resources/assets/images/favicon.ico',
            'profile_picture'     => 'vendor/solaris/solaris-laravel-core/resources/assets/images/user-dummy-img.jpg',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Interface
    |--------------------------------------------------------------------------
    |
    | Feature toggles and defaults for the admin UI shell.
    |
    */
    'interface' => [
        'menu_access' => false,
        'license'     => false,
        'languange'   => true,
        'dark_mode'   => true,
        'approval'    => true,
        'fullscreen'  => true,
        'switcher'    => true,
        'home_route'  => 'core.profile',

        'notification' => [
            'enabled'             => true,
            'read_retention_days' => 30, // null = keep forever
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Scheduler
    |--------------------------------------------------------------------------
    */
    'scheduler_timezone' => 'UTC',

    /*
    |--------------------------------------------------------------------------
    | Search
    |--------------------------------------------------------------------------
    |
    | Full-text and similarity matching used by scopeFilter's Similar operator.
    |
    */
    'search' => [
        // Postgres to_tsvector language; ignored on MySQL/MariaDB.
        'fulltext_language' => env('DB_FULLTEXT_LANGUAGE', 'simple'),

        // Trigram match threshold (0-1), Postgres pg_trgm only.
        'similarity_threshold' => env('DB_SIMILARITY_THRESHOLD', 0.35),
    ],

    /*
    |--------------------------------------------------------------------------
    | Authentication
    |--------------------------------------------------------------------------
    */
    'auth' => [
        'default' => 'default', // default | v1 | v2
        'presets' => [
            'default' => [
                'background_image' => 'vendor/solaris/solaris-laravel-core/resources/assets/images/sunny_login_bg.jpg',
            ],
            'v1' => [
                'background_image' => null,
                'background_color' => null,
            ],
            'v2' => [
                'background_image'  => null,
                'background_color'  => null,
                'tagline'           => 'The future of customer relationships',
                'tagline_highlight' => 'rises.',
                'subtitle'          => 'Simple, straightforward — CRM is easy as 1-2-3',
            ],
        ],
        'rate_limit' => [
            'max_attempts'  => 5,
            'decay_seconds' => 60,
        ],
        'single_login' => [
            'enabled'   => true,
            'behaviour' => 1, // 1 = kick existing session, 2 = reject new login
        ],
        'mobile' => [
            'access_token_ttl'  => 3600,    // 1 hour
            'refresh_token_ttl' => 2592000, // 30 days
        ],
        'api' => [
            // api_keys.rate_limit stores the tier name; the real numbers live here
            'rate_limit' => [
                'default' => 'standard',
                'tiers'   => [
                    'low'      => 30,  // requests per minute
                    'standard' => 60,
                    'high'     => 300,
                ],
            ],
            'last_used_throttle' => 300, // seconds between last_used_at writes

            'idempotency_retention_hours' => 24,

            // Kept separate from http_log on purpose: that one governs what Solaris sends out,
            // this governs what Solaris receives. Sharing the lists would let a change to one
            // silently expose credentials in the other.
            'log' => [
                'retention_days'         => 90,
                'body_retention_days'    => null,  // null = bodies live as long as the row
                'request_body_max_size'  => 65536, // 64KB
                'response_body_max_size' => 16384, // 16KB
                'file_retention_days'    => 30,    // failed-auth file log, rotated daily
                'sensitive_headers'      => ['authorization', 'x-api-key', 'x-secret', 'x-token'],
                'sensitive_fields'       => ['password', 'token', 'secret', 'api_key', 'access_token', 'client_secret'],
            ],
        ],
        'session_history' => [
            'retention_days' => 90, // null = keep forever
        ],
        'sso' => [
            'login'    => true,
            'register' => true,
        ],
        'register' => true,
    ],

    /*
    |--------------------------------------------------------------------------
    | Attachments
    |--------------------------------------------------------------------------
    */
    'attachment' => [
        'max_size'        => 5 * 1024 * 1024 * 1024, // 5 GB total quota per user
        'max_upload_file' => 10, // 10 MB per-file limit (Dropzone)
    ],

    /*
    |--------------------------------------------------------------------------
    | Excel Import/Export
    |--------------------------------------------------------------------------
    */
    'excel' => [
        'export_file_retention_days'  => 7,
        'export_log_retention_days'   => 30,
        'import_error_retention_days' => 7,
        'import_log_retention_days'   => 90,
    ],

    /*
    |--------------------------------------------------------------------------
    | HTTP Logging
    |--------------------------------------------------------------------------
    |
    | Logs outgoing Http:: traffic to storage/logs/{channel}/, separate from laravel.log.
    |
    */
    'http_log' => [
        'enabled'                => false,
        'log_response_body'      => false,
        'request_body_max_size'  => 16384,
        'response_body_max_size' => 16384,
        'sensitive_headers'      => ['authorization', 'x-api-key', 'x-secret', 'x-token'],
        'sensitive_fields'       => ['password', 'token', 'secret', 'api_key', 'access_token', 'client_secret'],
        'retention_days'         => 30,

        // Host => channel map for clients that can't set X-Solaris-Log-Channel themselves.
        'channel_routes' => [],
    ],

    /*
    |--------------------------------------------------------------------------
    | WhatsApp
    |--------------------------------------------------------------------------
    |
    | WhatsApp Business API device registry. Unrelated to the AI feature below.
    |
    */
    'whatsapp' => [
        'base_url' => env('WHATSAPP_BASE_URL'),
        'devices'  => [
            'sunny' => [
                'handler'        => \Solaris\Core\Http\Controllers\WhatsApp\WhatsAppCoreController::class,
                'device_id'      => env('WHATSAPP_SUNNY_DEVICE_ID'),
                'api_key'        => env('WHATSAPP_SUNNY_DEVICE_API_KEY'),
                'webhook_type'   => env('WHATSAPP_SUNNY_WEBHOOK_TYPE', 'url'), // url | redis
                'webhook_secret' => env('WHATSAPP_SUNNY_WEBHOOK_SECRET'),      // only for type=url
                'redis' => [
                    'host'     => env('WHATSAPP_SUNNY_REDIS_HOST', '127.0.0.1'),
                    'port'     => (int) env('WHATSAPP_SUNNY_REDIS_PORT', 6379),
                    'username' => env('WHATSAPP_SUNNY_REDIS_USERNAME'),
                    'password' => env('WHATSAPP_SUNNY_REDIS_PASSWORD'),
                    'channel'  => env('WHATSAPP_SUNNY_REDIS_CHANNEL'),
                ],
            ],
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Artificial Intelligence
    |--------------------------------------------------------------------------
    |
    | Assistant identity, tool registry, per-agent behavior, and cost tracking.
    | Provider/model/API key setup lives in config/ai.php (laravel/ai), not here.
    |
    */
    'ai' => [
        'assistant_name' => env('AI_ASSISTANT_NAME', 'Sunny AI'),

        // Namespace => path, same shape as 'model.namespaces' below. AiRegistryService::sync() scans
        // these (plus the project's own App\Ai\Agents/App\Ai\Tools) to discover any agent/tool NOT
        // already declared in 'agents'/'tools' below — a config entry always takes priority over
        // whatever discovery finds for the same slug. Each package contributes its own entry here.
        'agent_namespaces' => [
            'Solaris\\Core\\Ai\\Agents' => base_path('vendor/solaris/solaris-laravel-core/src/Ai/Agents'),
        ],

        'tool_namespaces' => [
            'Solaris\\Core\\Ai\\Tools' => base_path('vendor/solaris/solaris-laravel-core/src/Ai/Tools'),
        ],

        // Slug => FQCN, same shape/resolution as 'tools' below. Each package that ships its own Agent
        // (ProfileAgent here; MasterDataAgent/SalesAgent/... in their own packages) contributes its own
        // entry in ITS OWN config/solaris.php.
        'agents' => [
            'whatsapp' => 'Solaris\\Core\\Ai\\Agents\\WhatsAppAgent',
            'profile'  => 'Solaris\\Core\\Ai\\Agents\\ProfileAgent',
            'image_extraction' => 'Solaris\\Core\\Ai\\Agents\\ImageExtractionAgent',
            'audio_extraction' => 'Solaris\\Core\\Ai\\Agents\\AudioExtractionAgent',
        ],

        // Slug => FQCN. Accepts a short name resolved via tool_namespaces too.
        'tools' => [
            'get_profile'             => 'Solaris\\Core\\Ai\\Tools\\Profile\\GetProfileTool',
            'update_profile'          => 'Solaris\\Core\\Ai\\Tools\\Profile\\UpdateProfileTool',
            'lookup_region'           => 'Solaris\\Core\\Ai\\Tools\\Lookup\\LookupRegionTool',
            'lookup_options'          => 'Solaris\\Core\\Ai\\Tools\\Lookup\\LookupOptionsTool',
            'send_password_reset'     => 'Solaris\\Core\\Ai\\Tools\\Profile\\ForgotPasswordTool',
            'set_avatar'              => 'Solaris\\Core\\Ai\\Tools\\Profile\\SetAvatarTool',
            'reset_conversation'      => 'Solaris\\Core\\Ai\\Tools\\Conversation\\ResetWaConversationTool',
            'batch_mode'              => 'Solaris\\Core\\Ai\\Tools\\Conversation\\WaBatchModeTool',
            'quick_reply'             => 'Solaris\\Core\\Ai\\Tools\\Conversation\\QuickReplyWaTool',
            'wa_media_tool'           => 'Solaris\\Core\\Ai\\Tools\\Attachment\\WaMediaTool',
            'upload_attachment'       => 'Solaris\\Core\\Ai\\Tools\\Attachment\\UploadAttachmentTool',
            'list_attachment_targets' => 'Solaris\\Core\\Ai\\Tools\\Attachment\\ListAttachmentTargetsTool',
            'extract_images'          => 'Solaris\\Core\\Ai\\Tools\\Attachment\\ExtractImagesTool',
            'get_current_datetime'    => 'Solaris\\Core\\Ai\\Tools\\Conversation\\GetCurrentDateTimeTool',
        ],

        // Per-tool settings, keyed by slug (matches 'tools' above).
        'tool_settings' => [
            // Shared by every tool using the HasConfirmation trait, not tied to one slug.
            'confirmation' => [
                // How long a pending confirmation may wait for the user's approval.
                'ttl_minutes'    => (int) env('AI_CONFIRMATION_TTL_MINUTES', 30),
                // How long resolved confirmation rows are kept before cleanConfirmations() prunes them.
                'retention_days' => (int) env('AI_CONFIRMATION_RETENTION_DAYS', 30),
            ],
            // Confirmed upload/avatar actions whose file was still downloading when the user approved.
            'confirmed_media' => [
                // How long a note may wait for its files before it is closed and reported as failed.
                'wait_minutes'  => (int) env('AI_CONFIRMED_MEDIA_WAIT_MINUTES', 30),
                // A claim older than this belongs to a process that died mid-copy, never to work still running.
                'stuck_minutes' => (int) env('AI_CONFIRMED_MEDIA_STUCK_MINUTES', 5),
            ],
            'quick_reply' => [
                // Fallback text sent by DelegateTool when the model skips the interim ack it was told to
                // send. The model's own ack follows the user's language; this one cannot, so keep it short
                // and neutral. Empty string disables the fallback and leaves the ack entirely to the model.
                'default_message' => env('AI_QUICK_REPLY_DEFAULT_MESSAGE', 'Sebentar ya, sedang saya cek.'),
            ],
            'batch_mode' => [
                'ttl_minutes' => (int) env('AI_BATCH_MODE_TTL_MINUTES', 5), // hold ceiling, minutes
                'keywords' => [
                    'stop' => [
                        'id' => env('AI_BATCH_MODE_STOP_ID', 'selesai'),
                        'en' => env('AI_BATCH_MODE_STOP_EN', 'done'),
                    ],
                    'cancel' => [
                        'id' => env('AI_BATCH_MODE_CANCEL_ID', 'batal'),
                        'en' => env('AI_BATCH_MODE_CANCEL_EN', 'cancel'),
                    ],
                ],
            ],
        ],

        // Per-agent runtime settings, keyed by slug. Kept out of 'agents' above for the same reason
        // 'agent_providers' is: that key maps slug=>FQCN, so nesting anything under it silently reads null.
        'agent_settings' => [
            'whatsapp' => [
                // How long a media file that is still downloading stays claimable by a confirmed action.
                'pending_media_ttl_minutes' => (int) env('AI_WHATSAPP_PENDING_MEDIA_TTL_MINUTES', 15),
            ],
        ],

        // Per-agent provider/model failover chain (see Ai\Concerns\HasProviderFailover). Separate key from
        // 'agents' above — that one is the slug=>FQCN registry map read by AiRegistryService/Helper::aiAgent(),
        // this one is per-agent runtime settings; sharing one key silently drops whichever definition loses.
        'agent_providers' => [
            'whatsapp' => [
                'providers' => [
                    'openrouter' => env('WHATSAPP_AGENT_OPENROUTER_MODEL') ?: 'deepseek/deepseek-v4-pro',
                    'gemini'     => env('WHATSAPP_AGENT_GEMINI_MODEL') ?: 'gemini-3.5-flash-lite',
                    'anthropic'  => env('WHATSAPP_AGENT_ANTHROPIC_MODEL') ?: 'claude-haiku-4-5-20251001',
                    'openai'     => env('WHATSAPP_AGENT_OPENAI_MODEL') ?: 'gpt-5.4-nano',
                ],
            ],
            // Vision-only sub-agent (ExtractImagesTool). Its own chain rather than whatsapp's: the two have
            // conflicting modality needs, and sharing meant every image read paid the orchestrator's model
            // price and lost its failover the moment whatsapp was pinned to one provider.
            'image_extraction' => [
                'providers' => [
                    'openrouter' => env('IMAGE_EXTRACTION_AGENT_OPENROUTER_MODEL') ?: 'qwen/qwen3-vl-32b-instruct',
                    'gemini'     => env('IMAGE_EXTRACTION_AGENT_GEMINI_MODEL') ?: 'gemini-3.5-flash-lite',
                    'anthropic'  => env('IMAGE_EXTRACTION_AGENT_ANTHROPIC_MODEL') ?: 'claude-haiku-4-5-20251001',
                    'openai'     => env('IMAGE_EXTRACTION_AGENT_OPENAI_MODEL') ?: 'gpt-5.4-nano',
                ],
            ],
            // Audio-only sub-agent, reads WhatsApp voice messages before WhatsAppAgent's turn. MUST resolve to
            // a Gemini-driver provider: Gateway\Gemini is the only one that maps audio attachments at all, and
            // the others throw InvalidArgumentException — not a FailoverableException, so no failover saves it.
            // Extra entries here are the place to pool additional Gemini API keys (same driver, own key): a
            // quota 429 is failoverable, so the chain rolls to the next key on its own.
            'audio_extraction' => [
                'providers' => [
                    'gemini' => env('AUDIO_EXTRACTION_AGENT_GEMINI_MODEL') ?: 'gemini-3.5-flash-lite',
                ],
            ],
            // search_* tools attach to whichever domain agent the DB grants them to (e.g. CustomerAgent)
            // instead of a dedicated search specialist — no separate search agent provider chain exists.
            // ProfileAgent stays in Core too (owns the user's own account: biodata, password, avatar) —
            // same failover shape, own env overrides.
            'profile' => [
                'providers' => [
                    'openrouter' => env('PROFILE_AGENT_OPENROUTER_MODEL') ?: 'qwen/qwen3.7-flash',
                    'gemini'     => env('PROFILE_AGENT_GEMINI_MODEL') ?: 'gemini-3.5-flash-lite',
                    'anthropic'  => env('PROFILE_AGENT_ANTHROPIC_MODEL') ?: 'claude-haiku-4-5-20251001',
                    'openai'     => env('PROFILE_AGENT_OPENAI_MODEL') ?: 'gpt-5.4-nano',
                ],
            ],
        ],

        // USD per 1,000,000 tokens. Verified against provider list pricing on 2026-08-04.
        //
        // Keys must match the model string EXACTLY as sent to the provider — AdminDashboard::tokenPrice()
        // looks up "ai.pricing.{provider}.{model}" with no normalisation, so a near-miss key (e.g.
        // 'claude-haiku-4-5' for a request that sent 'claude-haiku-4-5-20251001') silently falls through
        // to 'default' and reports a fabricated cost. Every default in agent_providers above is covered
        // here verbatim; add a row whenever an env override points at a model not listed.
        //
        // List price only — introductory, batch, cached and flex rates are deliberately NOT used, so the
        // dashboard reports an upper bound that never silently expires. Notably Claude Sonnet 5 carries a
        // $2/$10 introductory rate through 2026-08-31; the $3/$15 standard rate is what sits below.
        'pricing' => [
            'anthropic' => [
                'claude-haiku-4-5-20251001' => ['input' => 1.0, 'output' => 5.0],
                'claude-haiku-4-5'          => ['input' => 1.0, 'output' => 5.0],
                'claude-sonnet-5'           => ['input' => 3.0, 'output' => 15.0],
                'claude-opus-5'             => ['input' => 5.0, 'output' => 25.0],
                'claude-opus-4-8'           => ['input' => 5.0, 'output' => 25.0],
            ],
            'openai' => [
                'gpt-5.4-nano' => ['input' => 0.2, 'output' => 1.25],
                'gpt-5.4-mini' => ['input' => 0.75, 'output' => 4.5],
                'gpt-5.4'      => ['input' => 2.5, 'output' => 15.0],
                'gpt-5'        => ['input' => 1.25, 'output' => 10.0],
            ],
            // Gemini charges audio input higher than text/image/video (e.g. 2.5-flash: $0.30 text vs $1.00
            // audio). The rates below are the text/image/video ones — audio-heavy usage under-reports.
            'gemini' => [
                'gemini-3.5-flash-lite' => ['input' => 0.3, 'output' => 2.5],
                'gemini-3.5-flash'      => ['input' => 1.5, 'output' => 9.0],
                'gemini-2.5-flash'      => ['input' => 0.3, 'output' => 2.5],
                'gemini-2.5-flash-lite' => ['input' => 0.1, 'output' => 0.4],
            ],
            // OpenRouter list price per model page. What is actually billed can run well below this when
            // prompt caching hits — an upper bound by design, same rule as above.
            'openrouter' => [
                'deepseek/deepseek-v4-pro'     => ['input' => 0.435, 'output' => 0.87],
                'qwen/qwen3-vl-32b-instruct'   => ['input' => 0.104, 'output' => 0.416],
                'qwen/qwen3.7-flash'           => ['input' => 0.03, 'output' => 0.13],
            ],
            'default' => ['input' => 1.0, 'output' => 3.0],
        ],

        'exchange_rate' => [
            'source'   => env('AI_EXCHANGE_RATE_URL', 'https://open.er-api.com/v6/latest/USD'),
            'fallback' => 16000,
        ],

        // Per-request agent log, separate from laravel.log. full = with prompt/response text
        // (local/development), essential = metadata only (production).
        'logging' => [
            'enabled'        => env('AI_LOGGING_ENABLED', true),
            'verbosity'      => env('AI_LOGGING_VERBOSITY', env('APP_ENV') === 'production' ? 'essential' : 'full'),
            'retention_days' => (int) env('AI_LOG_RETENTION_DAYS', env('APP_ENV') === 'production' ? 7 : 14),
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | WhatsApp AI
    |--------------------------------------------------------------------------
    |
    | The WhatsApp AI feature itself — on/off, Bouncer, reply pacing.
    | Not agent behavior (ai.agent_providers.whatsapp) and not the device registry (whatsapp above).
    |
    | Solaris-WhatsAppBouncer is a required dependency: every inbound message is announced to it,
    | and it decides when a turn runs. app_id below must be set.
    |
    */
    'whatsapp_ai' => [
        'device'  => env('WHATSAPP_AI_DEVICE', 'sunny'),
        'enabled' => env('WHATSAPP_AI_ENABLED', false),

        'session_idle_minutes' => (int) env('WHATSAPP_AGENT_SESSION_IDLE_MINUTES', 240),

        'bouncer' => [
            'secret'        => env('WHATSAPP_AI_BOUNCER_SECRET'),
            'app_id'        => env('WHATSAPP_AI_BOUNCER_APP_ID'),
            'stream'        => env('WHATSAPP_AI_BOUNCER_STREAM', 'wa-ai-bouncer-events'),
            'stream_maxlen' => (int) env('WHATSAPP_AI_BOUNCER_STREAM_MAXLEN', 100000),
            'redis' => [
                'host'     => env('WHATSAPP_AI_BOUNCER_REDIS_HOST', env('REDIS_HOST', '127.0.0.1')),
                'port'     => env('WHATSAPP_AI_BOUNCER_REDIS_PORT', env('REDIS_PORT', 6379)),
                'password' => env('WHATSAPP_AI_BOUNCER_REDIS_PASSWORD', env('REDIS_PASSWORD')),
                'db'       => env('WHATSAPP_AI_BOUNCER_REDIS_DB', 0),
            ],
        ],

        'typing_speed' => env('WHATSAPP_AI_TYPING_SPEED', 'default'), // slow | default | fast
    ],

    /*
    |--------------------------------------------------------------------------
    | Access Control
    |--------------------------------------------------------------------------
    |
    | Internal. Models excluded from the object-permission and lookup-management
    | systems — extend when adding new models to your own app.
    |
    */
    'object_permissions' => [
        'model_exceptions' => [
            'App\\Models\\User',
            'Solaris\\Core\\Models\\CodeGenerator',
            'Solaris\\Core\\Models\\CodeGeneratorDetail',
            'Solaris\\Core\\Models\\CodeGeneratorOwner',
            'Solaris\\Core\\Models\\ObjectPermission',
            'Solaris\\Core\\Models\\ObjectRule',
            'Solaris\\Core\\Models\\ObjectRuleDetail',
            'Solaris\\Core\\Models\\RecordRule',
            'Solaris\\Core\\Models\\RecordRuleDetail',
            'Solaris\\Core\\Models\\Attachment',
            'Solaris\\Core\\Models\\Menu',
            'Solaris\\Core\\Models\\ExportLog',
            'Solaris\\Core\\Models\\ImportLog',
            'Solaris\\Core\\Models\\Notification',
            'Solaris\\Core\\Models\\Profile',
            'Solaris\\Core\\Models\\UserSSO',
            'Solaris\\Core\\Models\\Role',
            'Solaris\\Core\\Models\\Permission',
            'Solaris\\Core\\Models\\ApprovalRequest',
            'Solaris\\Core\\Models\\ApprovalLevel',
            'Solaris\\Core\\Models\\ApprovalAssignment',
            'Solaris\\Core\\Models\\AuthSession',
            'Solaris\\Core\\Models\\ApiKey',
            'Solaris\\Core\\Models\\ApiRequestLog',
            'Solaris\\Core\\Models\\Folder',
            'Solaris\\Core\\Models\\MobileToken',
            'Solaris\\Core\\Models\\WaConversation',
            'Solaris\\Core\\Models\\WaMessage',
            'Solaris\\Core\\Models\\WaAiConfirmation',
        ],
    ],

    'lookup_management' => [
        'model_exceptions' => [
            'Solaris\\Core\\Models\\RightLevel',
            'Solaris\\Core\\Models\\RightOperation',
        ],
        'mobile_exceptions' => [
            'Solaris\\Core\\Models\\ApprovalAssignmentStatus',
            'Solaris\\Core\\Models\\ApprovalLevelStatus',
            'Solaris\\Core\\Models\\ApprovalRequestStatus',
            'Solaris\\Core\\Models\\City',
            'Solaris\\Core\\Models\\Country',
            'Solaris\\Core\\Models\\District',
            'Solaris\\Core\\Models\\PermissionType',
            'Solaris\\Core\\Models\\Province',
            'Solaris\\Core\\Models\\SubDistrict',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Resources
    |--------------------------------------------------------------------------
    |
    | Internal. Per-package asset path resolution and view-name registry.
    |
    */
    'resource' => [
        'path' => [
            'core' => 'vendor/solaris/solaris-laravel-core/resources',
        ],
        'views' => [
            'admin_dashboard' => 'core::pages.admin-dashboard.page',
            'login'           => 'core::pages.auth.login',
            '2fa'             => 'core::pages.auth.two-factor',
            'register'        => 'core::pages.auth.register',
            'password' => [
                'forgot-password' => 'core::pages.auth.forgot_password',
                'reset-password'  => 'core::pages.auth.reset_password',
            ],
            'profile' => 'core::pages.profile.page',
            'home' => [
                'page'      => 'core::pages.auth.profile',
                'thank-you' => 'core::pages.auth.thank-you',
            ],
            'user' => [
                'list' => 'core::pages.user.list',
                'page' => 'core::pages.user.page',
                'integration-page' => 'core::pages.user.integration-page',
            ],
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Models
    |--------------------------------------------------------------------------
    |
    | Internal. Resolvable namespaces and short-name => FQCN lookups (Helper::model()).
    |
    */
    'model' => [
        'namespaces' => [
            'Solaris\\Core\\Models' => base_path('vendor/solaris/solaris-laravel-core/src/Models'),
        ],
        'models' => [
            'user'               => 'App\\Models\\User',
            'chat_style'         => 'Solaris\\Core\\Models\\ChatStyle',
            'city'               => 'Solaris\\Core\\Models\\City',
            'country'            => 'Solaris\\Core\\Models\\Country',
            'currency'           => 'Solaris\\Core\\Models\\Currency',
            'district'           => 'Solaris\\Core\\Models\\District',
            'gender'             => 'Solaris\\Core\\Models\\Gender',
            'province'           => 'Solaris\\Core\\Models\\Province',
            'religion'           => 'Solaris\\Core\\Models\\Religion',
            'salutation'         => 'Solaris\\Core\\Models\\Salutation',
            'sub_district'       => 'Solaris\\Core\\Models\\SubDistrict',
            'profile'            => 'Solaris\\Core\\Models\\Profile',
            'wa_message_status'  => 'Solaris\\Core\\Models\\WaMessageStatus',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | 3rd Party API
    |--------------------------------------------------------------------------
    |
    | Internal. Short-name => FQCN for the /api/v1 layer. Downstream packages override an
    | entry to extend it; the route block resolves through here, so nothing else changes.
    |
    */
    'api' => [
        'controllers' => [],
        'resources'   => [],

        'docs' => [
            'enabled'     => true,
            'route'       => 'docs/api',
            // Follows the application name so the docs of each installation identify themselves.
            'title'       => env('APP_NAME', 'Solaris') . ' API',
            'description' => 'Third-party integration API.',

            // Empty follows whichever host is being browsed, so no production URL is baked in
            // and accidentally becomes the target of "Try it out".
            'servers'    => [],
            'swagger_ui' => 'https://cdn.jsdelivr.net/npm/swagger-ui-dist@5',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Repositories
    |--------------------------------------------------------------------------
    |
    | Internal. Short-name => FQCN lookups (Helper::repository()).
    |
    */
    'repositories' => [
        'user'    => 'Solaris\\Core\\Repositories\\UserRepository',
        'profile' => 'Solaris\\Core\\Repositories\\ProfileRepository',
    ],

    /*
    |--------------------------------------------------------------------------
    | HTTP Layer
    |--------------------------------------------------------------------------
    |
    | Internal. Controller/request bindings resolved by the gateway pattern.
    |
    */
    'controller' => [
        'namespaces' => [
            'Solaris\\Core\\Http\\Controllers',
            'Solaris\\Core\\Http\\Controllers\\Auth',
        ],
        'controllers' => [
            'admin_dashboard' => 'Solaris\\Core\\Http\\Controllers\\AdminDashboardController',
            'login'           => 'Solaris\\Core\\Http\\Controllers\\Auth\\AuthController',
            'register'        => 'Solaris\\Core\\Http\\Controllers\\Auth\\RegisterController',
            'verify_email'    => 'Solaris\\Core\\Http\\Controllers\\Auth\\VerifyEmailController',
            'resend_email'    => 'Solaris\\Core\\Http\\Controllers\\Auth\\ResendVerifyEmailController',
            'password'        => 'Solaris\\Core\\Http\\Controllers\\Auth\\PasswordController',
            'sso'             => 'Solaris\\Core\\Http\\Controllers\\Auth\\SSOController',
            'profile'         => 'Solaris\\Core\\Http\\Controllers\\Auth\\ProfileController',
            'home'            => 'Solaris\\Core\\Http\\Controllers\\HomeController',
            'user'            => 'Solaris\\Core\\Http\\Controllers\\UserController',
        ],
    ],

    'form_requests' => [
        'user' => 'Solaris\\Core\\Http\\Requests\\UserRequest',
    ],

    /*
    |--------------------------------------------------------------------------
    | Code Generator
    |--------------------------------------------------------------------------
    |
    | Internal. Models excluded from the code generator tool.
    |
    */
    'code_generator' => [
        'model_exceptions' => [
            'App\\Models\\User',
            'Solaris\\Core\\Models\\CodeGenerator',
            'Solaris\\Core\\Models\\CodeGeneratorDetail',
            'Solaris\\Core\\Models\\CodeGeneratorOwner',
            'Solaris\\Core\\Models\\Folder',
            'Solaris\\Core\\Models\\ObjectPermission',
            'Solaris\\Core\\Models\\ObjectRule',
            'Solaris\\Core\\Models\\ObjectRuleDetail',
            'Solaris\\Core\\Models\\RecordRule',
            'Solaris\\Core\\Models\\RecordRuleDetail',
            'Solaris\\Core\\Models\\Attachment',
            'Solaris\\Core\\Models\\Menu',
            'Solaris\\Core\\Models\\ExportLog',
            'Solaris\\Core\\Models\\ImportLog',
            'Solaris\\Core\\Models\\Notification',
            'Solaris\\Core\\Models\\Profile',
            'Solaris\\Core\\Models\\UserSSO',
            'Solaris\\Core\\Models\\Role',
            'Solaris\\Core\\Models\\Permission',
            'Solaris\\Core\\Models\\RightLevel',
            'Solaris\\Core\\Models\\RightOperation',
            'Solaris\\Core\\Models\\ApprovalRequest',
            'Solaris\\Core\\Models\\ApprovalLevel',
            'Solaris\\Core\\Models\\ApprovalAssignment',
            'Solaris\\Core\\Models\\AuthSession',
            'Solaris\\Core\\Models\\ApiKey',
            'Solaris\\Core\\Models\\ApiRequestLog',
            'Solaris\\Core\\Models\\Folder',
            'Solaris\\Core\\Models\\MobileToken',
            'Solaris\\Core\\Models\\WaConversation',
            'Solaris\\Core\\Models\\WaMessage',
            'Solaris\\Core\\Models\\WaAiConfirmation',
        ],
    ],
];
