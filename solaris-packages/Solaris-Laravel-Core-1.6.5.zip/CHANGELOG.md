# Changelog

All notable changes to `Solaris-Laravel` will be documented in this file.

---

## [v1.6.5] - 21 Aug 2026

Patch release — `Helper::config()` resolution rewritten for predictable scalar precedence and array merging.

- **Scalar precedence** — scalars from all providers (`sunny`, `solaris`) are collected first, then returned in provider order, so `sunny` always wins over `solaris`. Previously the first non-null scalar hit returned immediately from inside the scan loop.
- **Associative merge order flipped** — associative arrays are now merged over `array_reverse($configs)`, so the earlier provider (`sunny`) overrides the later one (`solaris`) — matching the scalar rule. Before, `solaris` overwrote `sunny`.
- **List detection fixed** — list-vs-associative is decided once from the first provider that supplies a value, instead of being latched inside the merge loop; list arrays are still concatenated and deduplicated via `array_unique` + `array_values`.
- **Default return** — an early return of `$default` when no provider supplies the key, replacing the fall-through at the end of the method. Scalar, list and associative paths are now three flat branches instead of one nested block.

---

## [v1.6.4] - 21 Aug 2026

Patch release — HTTP log hardening: body size caps, channel-name sanitizing, and logging that can no longer break the request it observes.

- **Body size caps** — `http_log.request_body_max_size` added and `response_body_max_size` raised from 2048 to 16384; request bodies were previously unbounded except for an ad-hoc 1000-char cut on xml/plain text. Structured bodies are masked *first*, then bounded, so a truncated preview can never carry a raw sensitive value.
- **Shared truncation** — `boundBodyValue()` moved into `MasksSensitiveData`; `ApiRequestLogService::boundBody()` now delegates to it instead of carrying its own copy. Size is measured on the encoded form and the truncated result stays a valid array, so a json column never receives half a JSON document.
- **Request/response parsing merged** — `HttpLogService` request and response paths share one `parseTextBody()` (plus `boundText()` for unstructured payloads); multipart request bodies are bounded too.
- **Channel-name sanitizing** — a channel arrives from the `X-Solaris-Log-Channel` header and ends up as both a path segment and a config key. `sanitizeChannel()` restricts it to `[a-z0-9_-]` and falls back to `http-outgoing`, closing a path-traversal vector on the log file location.
- **Logging never crashes the caller** — `HttpLogMiddleware` wraps `writeLog()` in try/catch + `report()`, and drops `defer()` so the write happens inline.
- **Logger reuse** — the channel is registered once under `logging.channels.http_log_{channel}` and resolved via `Log::channel()`, letting `LogManager` cache the logger and hold the file handle open; `Log::build()` rebuilt both on every record.

---

## [v1.6.3] - 19 Aug 2026

Patch release — access-right rule listing/editing fixed independent of enforcement flags, plus UI label corrections.

- **Access control — rule listing/management fix**
  - `ObjectRuleService`/`RecordRuleService` gain `listing()`, a management-path query that resolves by object-permission id (or code) and is never gated by the parent `object_permission`/`record_permission` flag — rules stay visible and editable in the UI even while enforcement is disabled. `rules()` (the enforcement path, cached) is unchanged and still requires the flag.
  - `ObjectRuleController::list()`/`RecordRuleController::list()` call `listing()` directly with the route id instead of resolving `code` first; `ObjectPermissionCommand` follows suit, and `getAvailablePermission()` no longer filters by rule type.
- **UI — access-right list/detail fixes**
  - `list.js` record-rule badge read "object rules" instead of "record rules"; both badges now always render instead of being hidden behind the (removed) enforcement-flag check.
  - `base-rule.js`'s fetch guards against a non-array payload, returning `[]` instead of passing through whatever the response shape was.

---

## [v1.6.2] - 18 Aug 2026

Minor release — 3rd-party API foundation with generated OpenAPI docs, integration user/API key auth, a role/permission security fix, and AI agent hardening against fabricated field values and repeat-failure thrashing.

- **API — 3rd-party foundation (new)**
  - `BaseApiController` gives every entity index, search, show, store, update, replace and destroy through one response envelope and one stable error code; model, repository, form request and resource all resolve through config, so a downstream package extends an entity without touching the controller layer. PATCH accepts a relaxed rule set where absent is not null; PUT demands the required fields and blanks what is omitted.
  - Lookups accept id or name; a name matching more than one record is rejected with the candidates instead of guessed.
  - OpenAPI spec generated from those declarations (`OpenApiGenerator`), not hand-written — it follows whichever packages are actually installed. Served at `/docs/api`, public, write verbs disabled in Swagger UI on production.
  - `ApiIdempotency` middleware + `api_idempotency_keys` table, pruned by `CleanApiIdempotencyKeysJob`.
- **API — integration auth & audit (new)**
  - An API key is a password, not an identity: `users.is_integration` marks accounts that cannot sign in to web or mobile (guarded in `webLogin`, `mobileLogin`, `completeWebLogin`), permissions stay on the user like any other account.
  - `ApiKeyService` issues at most two active keys per user, returns the plaintext once, revokes by stamping `revoked_at`. `solaris:api-key list|create|revoke` for operators. `IntegrationSeeder` adds the Integration role and a starter user.
  - Every 3rd-party request is logged: a resolved key writes to `api_request_logs` (visible in the UI), an unresolved one writes to `storage/logs/api-auth`, a rejected key is never written down — only an 8-character fingerprint. `MasksSensitiveData` extracted from `HttpLogService` so inbound/outbound logging no longer share one field-mask config.
- **Access control — scoped roles/permissions & integration management UI (new)**
  - Roles and permissions gain a `group_name` (`user` / `ai` / `integration`); assignment modals, seeders and the role list filter by scope so AI and integration grants no longer mix into the general user picker.
  - New Integration page per user: access badges, API key issuance/revocation, and an audit-log viewer with a JSON payload inspector (`json-viewer.js`).
  - `assign-modal.js` split into a generic `ListModal` (load/guard/render lifecycle) plus a shared `BaseAssign` and thin per-type wrappers (`UserAssign`, `RoleAssign`, `PermissionAssign`, `MenuAssign`, `AiAssign`, `IntegrationAssign`). Selections commit on debounced change against the server diff instead of the full set. Server-side, `AssignmentRegistry` declares all owner-target pairs with their own search columns, replacing `HasUserAssignment`'s hardcoded email/username columns (permissions have neither); sixteen routes collapse into one.
- **Security fix — inactive role/permission checks**
  - `RoleController`, `PermissionController` and `MenuController` declared `middleware()` without implementing `HasMiddleware`, so Laravel never read it — combined with `menu.access` defaulting to `false`, their endpoints were reachable by any authenticated user.
  - `HasRolesAndPermissions` read `UserCache::permissions` instead of `allPermissions`, hiding permissions granted through a role. `PermissionMiddleware` called `hasRole()` instead of `hasPermission()` (copy-paste from `RoleMiddleware`).
  - `ParseExpression::parseRole()` renamed to `parseExpression()`.
- **AI — per-turn tool-failure guard & delegate hardening**
  - `ToolTurnState` (injected into every `BaseAiTool`) counts failures per `slug|error_code`; after two identical failures the tool stops calling `execute()` and returns a `BusinessRule` error telling the model to report instead of retry. Batch tools' per-item errors (e.g. `lookup_options` results) are now unpacked into the same counter, not just root-level ones.
  - `DelegateTurnState` now also records each specialist's successful answer; the next specialist's task is prefixed with a `FINDINGS FROM OTHER SPECIALISTS THIS TURN` block so a value one already retrieved isn't re-fetched or lost.
  - Delegate targets are forced to reply in English, compactly, data-only (`BaseAiAgent::delegateOutputInstructions()`); `AudioExtractionAgent` and `ImageExtractionAgent` opt out since their output is user-facing content.
  - Interim ack hardened: `DelegateTool::ensureAcknowledged()` sends a configured fallback (`ai.tool_settings.quick_reply.default_message`) if the model skips its own `quick_reply` call; `QuickReplyWaTool::claimAck()` locks so only one ack goes out.
- **AI — stop fabricating field values, cap search browse fallback**
  - `BaseCreateAiTool`/`BaseUpdateAiTool` instructions now explicitly forbid writing a plausible sentence for a free-text field (notes, needs, description) or deriving a value from another field — both are fabrication stored as if the user said it.
  - `BaseSearchTool`'s no-match browse fallback now caps at 25 records and returns identifying fields only (previously up to 30 full records); above the cap it reports the count instead of a misleadingly partial list, and returned fields are trimmed to just what's searchable plus `name`.
  - `LookupOptionsTool` resolves lookup types unregistered in `model.models` by scanning `App\Models` and configured namespaces for `SolarisLookup` implementations, matching how `LookupManagementController` already discovers project-defined lookups elsewhere; unknown types now list the valid ones instead of failing silently.

---

## [v1.6.1] - 12 Aug 2026

Patch release — metric numeral/tooltip support, Kanban board-summary + lifecycle events, and hardened extend/make commands.

- **UI — metric numeral & tooltip (new)**
  - `numeral` prop on `x-core::metric` (and its `compact`/`detail`/`simple`/`simple-icon`/`summary` variants) renders click-to-expand abbreviated values (e.g. `1.2K` ↔ `1,200`) via `x-core::numeral`; `tooltip` prop adds a hover info icon next to the title.
  - `MetricDashboard` refactored to emit raw values for numeral formatting; `Numeral::render()` (new static) builds the same markup as the Blade component for runtime-rendered elements, bindable afterwards via `new Numeral(element)`.
  - Fix: `MetricDashboard` now binds `Numeral` to the inner `[solar-ui="numeral"]` element instead of the wrapper, so decimals/separator attributes are honoured.
  - `Table` number/currency formatting switched to the shared `Helper.readableNumber()`, removing the duplicate `Table._applyNumberFormat()`.
- **UI — Kanban board-summary & events (new)**
  - New `.board-summary` container (color-aware borders) with header reordered so the new-action button stays right-aligned.
  - New lifecycle events: `fetching`, board created, board updated; `deleted` now includes `boardId`.
  - New helper APIs `getParamData()`, `getBoardElement()`, `getBoardColumn()` so consumers can build identical fetch payloads and read board state; `_fetchData` uses `getParamData()` and emits `fetching`; `SolarUI` uses `getBoardColumn()` instead of reaching into internal properties.
  - `Table` gains matching `getParamData()` for consistent search/filter-state access.
- **CLI — extend/make command robustness**
  - Stricter option validation, safer handling of existing files, support for skipping module migrations, and config-aware naming for view/repository generation.
  - Module generation summaries now surface both successful and failed steps; fixed controller/model repository binding using correct class names.
  - View extension hardened across package-based layouts; safer directory creation and JS generation checks.
- **Docs** — component `.docs.json` files moved under `resources/views/components/docs/`.

---

## [v1.6.0] - 11 Aug 2026

Minor release — WhatsApp voice message transcription, deferred media confirmation, richer search-tool provenance, and OpenRouter as a first-class provider.

- **AI — audio extraction agent (new)**
  - New `AudioExtractionAgent` reads WhatsApp voice messages via Gemini, transcribing content plus tone/clarity/emphasis before `WhatsAppAgent`'s turn; runs on its own `ai.agent_providers.audio_extraction` chain, which **must** resolve to a Gemini-driven provider — `Gateway\Gemini` is the only driver that maps audio attachments, others throw a non-failoverable `InvalidArgumentException`.
  - `image_extraction` likewise gets its own dedicated provider chain (was implicitly sharing `whatsapp`'s), so a vision read no longer pays the orchestrator's model price or loses failover.
- **AI — deferred media & confirmed actions (new)**
  - New `ConfirmedMediaService` (replaces `PendingMediaActionService`) — lets users confirm an upload/avatar change before the file finishes downloading; applies the action automatically, transaction-safe across the multi-phase confirm→download→apply flow, once the media is ready.
  - New `HasDeferredMedia` trait unifies pending-file handling across `UploadAttachmentTool` and `BaseSetAvatarTool`.
  - New `ProcessMediaSignalJob` + `WaMessageMediaFailed` event resolve/report media asynchronously; new `PublishMediaFailedToBouncer` listener signals download failure to the Bouncer.
  - `WaMediaTool` refactored from ordinal references to message-id suffixes for clearer "Media N" targeting.
- **AI — search tool provenance & filtering**
  - `BaseSearchTool` gains audit-field support, base filters, aggregation with direction/limit, and criteria reporting so tool responses can trace back what was actually queried.
  - New `WaPromptBuilder` centralizes WhatsApp message formatting — proper media-state indicators and inlined voice transcripts, replacing ad-hoc formatting in `WhatsAppAiService`.
  - `BaseAiAgent` gains recovery-mode support and instruction merging with search-tool filters.
- **AI — OpenRouter provider & pricing**
  - `openrouter` added as a provider across `whatsapp`, `image_extraction`, and `profile` agent chains, alongside verified default models for gemini/anthropic/openai (previously `null`, forcing an env override).
  - `ai.pricing` — added `openrouter` price table plus missing anthropic/openai/gemini model entries; keys documented as must match the wire model string exactly, since a near-miss silently falls through to `default` and fabricates a cost in `AdminDashboard`.
- **Config** — `whatsapp_ai.mode` removed (bouncer mode is now the only mode; `Solaris-WhatsAppBouncer` is a required dependency, `app_id` must be set).

---

## [v1.5.2] - 30 Jul 2026

Patch release — `ImageExtractionAgent` registered as a proper AI agent.

- **AI — `ImageExtractionAgent` registration & conversation persistence**
  - Registered in `ai.agents` config (was previously only instantiated directly by `ExtractImagesTool`).
  - New `read()` binds the run to the acting user so Laravel AI's `RememberConversation` middleware activates and persists the prompt/response — without a participant the middleware is never added to the pipeline; each call still starts a fresh conversation, since image groups are read in isolation with no thread to continue.
  - New `decode()` strips markdown code fences vision models keep wrapping around the JSON payload despite the JSON-only instruction, then parses it — returns `null` on unusable output instead of trusting the raw response.
  - `ExtractImagesTool` updated to use `agent->read()`/`agent->decode()` and report a `SystemError` on a null decode.

---

## [v1.5.1] - 30 Jul 2026

Patch release — AI delegation framework with typed error codes, conversation thread recovery, transaction-optional repositories, and a condensed roles UI.

- **AI — typed error codes & delegate framework (new)**
  - New `AiErrorCode` enum (`UserError`, `NotFound`, `BusinessRule`, `Inconclusive`, `SystemError`) — `AiResponse::error()` now takes a typed code plus an optional `$debug` payload (log-only, never relayed to the user or model); tools across the package migrated from ad-hoc string codes to categorized `AiErrorCode` cases.
  - New channel-agnostic delegation framework — `DelegateTool`/`DelegateTurnState`/`DelegateThreadResolver` (+ `WaDelegateThreadResolver`) let an agent hand a turn off to a sub-agent, persisting the sub-agent's thread and tracking a per-turn circuit breaker; delegate failures logged via `AiLogService`.
  - New `AiIgnore` attribute — marks internal/decorator tool classes (e.g. `BatchModeGuard`) so they're excluded from `ai_tools` registry discovery; `AiRegistryService` discovery now skips classes marked with it.
  - `BaseCreateAiTool`/`BaseUpdateAiTool`/`BaseDeleteAiTool` — lock target ids into the confirmation payload and strengthen confirmation text; `QuickReplyWaTool` gains a storm guard (cache-based).
- **AI — WhatsAppAgent delegation & instructions**
  - `WhatsAppAgent` wraps sub-`Agent` tools with `DelegateTool` and other tools with `BatchModeGuard`; `WaBatchModeTool` now filtered out outside bouncer mode; in-agent instructions strengthened (ALWAYS REPLY, reporting/delegation rules).
  - `ProfileAgent` — runtime tool list removed in favor of a static `essentialToolClasses()` so `AiRegistryService` can lock/grant its ACLs directly; tools still served from DB.
- **AI — conversation thread recovery & bouncer unlock**
  - New `ai_agent_threads` JSON column on `wa_conversations` (+ model cast) — tracks per-conversation sub-agent delegate threads; cleared on idle/reset.
  - `WhatsAppAiService` — recovers empty agent responses with a recovery-nudge retry, falls back to a generic Indonesian message if still empty.
  - New `BouncerEventPublisher::publishUnlock()` — signals conversation unlocks to the Bouncer.
  - `ProcessAiChatResponse` — increased tries, adjusted backoff, `WithoutOverlapping` middleware, failure notices, and bouncer lock release on terminal outcomes.
  - `AiRegistrySeeder` now runs `solaris:ai-sync` before its wiring/permission steps; registered in `DatabaseSeeder`'s seeder list.
- **Repositories — optional transactions**
  - `AttachmentRepository`/`ObjectRuleRepository`/`ProfileRepository`/`RecordRuleRepository`/`UserRepository` gain an optional `$transaction` constructor param (default `true`), forwarded to `BaseRepository`, letting callers disable automatic transactions without touching the base class.
- **UI — condensed role display (new)**
  - Profile and User pages now show only the first two role badges plus a "…" more badge; new `#roles-modal` lists the full role set. `initRoles()`/`_renderRoles()` added to `profile/page.js`/`user/page.js`, replacing inline rendering in `onRefreshed`.
- **Fixes**
  - `HasRolesAndPermissions::getPermissionsByArgs()` — the `when()` guard checked `$permission` (undefined) instead of `$permissions`, so the permission filter silently never applied; fixed.

---

## [v1.5.0] - 28 Jul 2026

Minor release — database-backed AI Agent/Tool registry with role/permission ACL, AI tool architecture moved to trait-based composition, generalized media handling, and menu/folder/mask-input fixes.

- **AI — database-backed registry & access control (new)**
  - New `AiAgent`/`AiTool` models + `0002_01_01_000031_core_create_ai_registry_table` migration — agents and tools are now DB records instead of pure config, with user/role/permission grant tables for fine-grained ACL.
  - New `AiRegistryService::sync()` — syncs agents/tools from `config('ai.agents'/'ai.tools')` plus convention-based discovery (`ai.agent_namespaces`/`ai.tool_namespaces`, project's own `App\Ai\Agents`/`App\Ai\Tools`) into the database; config entries always take priority over discovery for the same slug. New `solaris:ai-sync` console command runs it.
  - New `AiEssential` attribute — flags an agent/tool as a locked default, auto-granted to the base user role and exempt from ACL removal.
  - `AiAccessService` rewritten to read ACL purely from the database (was config-derived) with two-gate enforcement — a tool call is only permitted if both the tool and the owning agent are granted to the user.
  - New `AiAgentController`/`AiToolController` — admin endpoints for managing agent/tool grants.
  - New `UserCache` AI cache methods (`aiAgents`, `aiTools`, `forgetByRoles`/`forgetByPermissions`/`forgetByUsers`, `forgetAiForUser`/`forgetAiForRoles`, `flushAi`) — `Role`/`Permission`/`HasRolesAndPermissions` now invalidate a user's AI cache on any role/permission change (previously only the plain permission cache was cleared); `AiRegistryService::sync()` triggers a full `flushAi()`.
- **AI — tool/agent architecture: composition over inheritance** ⚠️ Breaking
  - New `BaseAiAgent` — `WhatsAppAgent`/`ImageExtractionAgent` now extend it instead of implementing an interface directly; new `ProfileAgent` (specialist for the user's own account: biodata, password, avatar) added alongside it.
  - Tools moved off constructor dependency injection onto trait-based property injection — new `NeedsUser`/`NeedsWaConversation`/`NeedsAgent` interfaces + `HasUser`/`HasWaConversation`/`HasAgent` traits declare what a tool needs instead of a base-class constructor providing it; `HasConfirmation` absorbed the confirmation protocol previously spread across `BaseAiTool` subclasses.
  - Renamed for consistency: `name()` → `slug()`, `columns()` → `fields()`, `modelDescription()` → `resourceLabel()`, `newModelInstance()` → `model()`, `resolveContext()`/`validateForConfirmation()` → `handle()`/`validateConfirmation()`; `make()` static factories removed.
  - WhatsApp-specific tools renamed with a `Wa` prefix and moved onto the new pattern: `QuickReplyTool` → `QuickReplyWaTool`, `ResetConversationTool` → `ResetWaConversationTool`, `BatchModeTool` → `WaBatchModeTool`.
- **AI — batch/delegate infrastructure removed** ⚠️ Breaking
  - `BatchExecuteTool`, `SearchDelegateTool`, `SearchAliasTool`, `SearchAgent`, `BatchableAiTool`, `HasConfirmationBatch`, `HasDirectBatch` all removed — delegated search (v1.4.0) is superseded by attaching `search_*` tools directly to the domain agent the DB grants them to, instead of routing through a dedicated search specialist.
  - `config('ai.tools')` — `batch_execute`/`delegate_search` entries removed; `config('ai.delegates')` section removed entirely (was only used to build `WhatsAppAgent`'s routing blurb for delegate tools).
- **AI — media handling generalized**
  - `AvatarService` replaced by `PendingMediaActionService` — tracks pending actions for any media type across turns, not just images.
  - New `WaMediaTool` — resolves WhatsApp media references ("Media N" tags, replies) to `attachment_id`s; new `ExtractImagesTool` — structured data extraction from images.
  - `UploadAttachmentTool` reworked to take pre-resolved `attachment_id`s instead of WhatsApp-specific pending-media lookups, making it channel-agnostic.
- **AI — CRUD tools: nested detail validation (new)**
  - `BaseCreateAiTool::validateDetailList()` — validates an array of detail/line items against given rules, returning validated items plus indexed errors.
  - `BaseUpdateAiTool::resolveDetailOperations()` — classifies detail items into creates/updates/deletes, checks ownership by parent key/id, merges existing records for update validation.
  - `BaseCreateAiTool`/`BaseUpdateAiTool` gain `afterValidation()` hooks for cross-field validation; `BaseUpdateAiTool` gains `excludedChangeKeys()`.
- **AI — search tool: sort support** — `BaseSearchTool` extended with sort functionality; `AiSearchColumn`/`AiSearchable` adjusted accordingly.
- **AI — config restructure** ⚠️ Breaking
  - `ai.agents` split in two — it's now the slug→FQCN agent registry map (matching `ai.tools`' shape), while runtime provider/model failover settings moved to the new `ai.agent_providers` key (was `ai.agents.*.providers`).
  - New `ai.agent_namespaces` (agent discovery, mirrors `ai.tool_namespaces`); `ai.tool_namespaces`/`ai.agent_namespaces` are now `Namespace => path` maps instead of a bare namespace list.
  - `whatsapp_ai.session_idle_minutes` moved out of `ai.agent_providers.whatsapp` (was `ai.agents.whatsapp.session_idle_minutes`).
- **Helper — explicit registry-first class resolution**
  - `Helper::resolveControllerClass()`/`resolveModelClass()` now check `config('controller.controllers')`/`config('model.models')` (explicit FQCN list) before falling back to the project's `App\Http\Controllers`/`App\Models` namespace, instead of scanning a namespace list with `class_exists()`; new `Helper::resolveAiAgentClass()`/`Helper::aiAgent()` mirror the existing tool-resolution helpers for agents.
- **Fixes**
  - Menu Management — assign-user search box searched hardcoded `name`/`description` columns regardless of caller; `MenuController::getDataTableResponse()` now accepts a `$searchColumns` param, user assignment now searches `name`/`email`.
  - Folder — folder state now included in table cache; audit fields (created/updated at/by) were missing from the column filter list.
  - Folder — canceling a folder item while the table cache was active left stale state (`folders.js`).
  - Input mask — decimal value bug in the mask-input component (`mask-input.js`, `input.blade.php`).

---

## [v1.4.0] - 21 Jul 2026

Minor release — AI batch/multi-message mode, agent provider failover with delegated search, database-backed confirmation system, Filter DSL parser, WhatsApp reply feature, chat style preference, config restructure.

- **AI — batch mode & multi-message (new)**
  - `BatchModeService` — hold-and-merge multiple inbound WA messages into one agent turn instead of replying per message; `BatchModeTool`/`BatchModeGuard` let a tool enter/guard batch state; `BouncerEventPublisher` gains `hold_start`/`hold_end` events for the Bouncer to coordinate around.
  - `BatchExecuteTool` + `BatchableAiTool` interface — run multiple independent tool calls in one round-trip instead of one call per turn.
  - Replaces the old `NO_REPLY_SENTINEL` multi-message hack (added in v1.3.4) — sentinel/ignore-reply logic removed from `AiService`/`WhatsAppAgent` now that batch mode owns this.
  - `AiToolRegistry` — tools now register into named groups (`core`, `utility`); `SolarisServiceProvider::registerAiTools()` rewritten around `core` (router-only, WhatsApp-account tools) vs `utility` (cross-agent: lookup, batch, current time — merged into every agent including specialists).
- **AI — agents: provider failover & search delegation**
  - New `HasProviderFailover` concern — centralizes provider-chain resolution; agents now configured with provider *arrays* instead of a single provider/model string, so a failed provider falls through to the next.
  - New `SearchAgent` — specialist agent for delegated search (filtering, batch search), reached via new `SearchDelegateTool`/`SearchAliasTool` (`delegate_search`).
  - `WhatsAppAgent` — reworked prompt structure, chat-style detection (see Profile section below), and delegation to specialist agents; `ImageExtractionAgent` updated for the new provider-array config shape.
- **AI — tool infrastructure rework**
  - Confirmation flow moved off in-memory cache onto a DB-backed `wa_ai_confirmations` table (`WaAiConfirmation` model + migration) with a scheduled daily cleanup of expired rows (`routes/console.php`); protocol consolidated into `HasConfirmation` (validate → issue token → execute) replacing the ad-hoc logic previously spread across `BaseAiTool`/`BaseCreateAiTool`/`BaseUpdateAiTool`/`BaseDeleteAiTool`.
  - New `AiColumn`/`AiColumnType` — type-safe column/field builders replacing raw array schema definitions across CRUD tools; new `AiResponse` — standardized success/error tool response shape, adopted by all tools.
  - New `AiSearchable` interface + `AiSearchColumn` — `BaseSearchTool` overhauled with relation validation, aggregate queries (count/sum/avg/min/max), Filter DSL support (see below), and clearer error messages; `LookupRegionTool`/`LookupOptionsTool` implement `AiSearchable` so they can serve as delegation targets.
  - New attachment tools — `UploadAttachmentTool`, `ListAttachmentTargetsTool`, `AttachmentTargetRegistry` (reflection-based discovery of models exposing `fileAttachments()`); `AttachmentRepository::copyToRecord()` extracted for reuse (was duplicated in `AvatarService`).
  - `ResetConversationTool`/`ForgotPasswordTool` migrated onto the confirmation protocol (`BaseConfirmAiTool`); `HelpTool` removed in favor of direct tool delegation.
  - New `src/Ai/README.md` — developer guide for building AI tools/agents against this infrastructure.
- **AI — logging (new)**
  - `AiLogService` + `LogAiPrompt`/`LogAiResponse` listeners — records AI prompt/response pairs.
  - `SolarisServiceProvider::registerAiHttpLogChannel()` — routes `laravel/ai` provider SDK HTTP calls (which can't be tagged with the log-channel header directly) to the `ai` HTTP log channel by `host:port`.
- **AI — WhatsApp Bouncer**
  - `AiService` renamed to `WhatsAppAiService` throughout; `BouncerEventPublisher::publish()` now takes explicit `app_id`/`device_key`; `AiBouncerController` reads the request payload directly instead of a DB lookup.
  - Video and document media types now supported end-to-end (was audio/image only); `WhatsAppAiService` tracks pending media across turns, media messages tagged with ordinals so tools can reference "the 2nd image" etc.
- **Filter — DSL parser (new)**
  - New `Solaris\Core\Services\FilterDsl\{Lexer,Parser,Token,TokenType,DslException}` — parses a filter *string* into the same structure `scopeFilter` already consumes, for building filters from external/LLM-generated input without hand-assembling the `Filter` class.
  - `Filter::OperatorType` array replaced with individual class constants; new `Filter::operator()` helper resolves an operator name dynamically. `HasFilterModel`/`HasSearchModel` — improved validation and error messages for malformed filters.
- **WhatsApp — reply feature & message status**
  - Chat UI/service now support replying to a specific message (`chat.js`, `_chat.scss`, `chat.blade.php`/`message.blade.php`); new `WebhookReplyToData`, `WebhookMessageData::$replyTo` populated from incoming webhook data when present.
  - New `core.whatsapp.messages.delete` / `core.whatsapp.conversations.delete` routes on `WhatsAppController`/`WhatsAppHandler`.
  - `wa_messages.status` migrated from a string enum to a `wa_message_statuses` lookup table (UUID-keyed); new `failure_reason` column, `WaMessageFailed` event + webhook handler, `WaMessage::isFailed()`, frontend failure tooltip listener.
- **Config — restructure** ⚠️ Breaking
  - `config/solaris.php` reorganized into logical sections (`application`, `interface`, `scheduler`, `search`, `auth`, `attachment`, `excel`, `http_log`, `whatsapp`, `ai`, `whatsapp_ai`, …); WhatsApp AI config moved `ai.whatsapp.*` → `whatsapp_ai.*` and agent provider config to `ai.agents.whatsapp.*` — any project overriding these keys directly must update to the new paths.
- **Profile — chat style preference**
  - Users can now pick a chat style (Casual / Friendly / Professional) — new `chat_styles` lookup table, `ChatStyle` model, `ChatStyleConst`, `Profile` relation, `ProfileRequest` validation; `WhatsAppAgent` reads it for tone detection. Profile page gains an AI section showing usage stats; `AdminDashboard::userAgentAi()`/`userTotalTokenAi()`/`userTotalRequestAi()` add per-user AI token/request metrics.
- **Repository — transaction control & lifecycle hooks**
  - `BaseRepository::create()`/`update()`/`delete()` gain optional `$before`/`$after` closures and a `$transaction` flag so a repository can join a caller's existing transaction instead of always wrapping its own (prevents nested-transaction issues when one repo's hooks call another); `SolarisRepository` interface updated to match.
- **Fixes / minor**
  - `fileAttachments()` moved from `HasSolarisUser` to `HasBaseModel` so any model can expose it, not just users.
  - `laravel/ai`'s automatic conversation-title generation (`RememberConversation::generateTitle()`) now defaults off — was firing a hidden extra LLM call on every new WhatsApp session; only applied when the host app hasn't set `ai.conversations.generate_title` itself.
  - Folder filter conditions — relabeled several operators for clarity (`IsNull`/`IsNotNull` → "Has No Value"/"Has Value", etc.), reordered aggregate vs. relation conditions, added `In`/`NotIn`/`FullText`/`Similar` labels.
  - New Filter Similar-operator (v1.3.4) column labels wired into the folder UI.

---

## [v1.3.4] - 10 Jul 2026

Patch release — AI confirmation batching & safety rules, reference-field validation with lifecycle hooks, fuzzy-match Similar filter operator.

- **AI Tools — confirmation batching & prompt safety rules**
  - `AiService::NO_REPLY_SENTINEL` — replies containing it are trimmed/ignored, enabling a multi-message mode where the agent waits for a completion token (superseded by proper batch mode in v1.4.0).
  - `BaseAiTool` — per-request confirmation batch (id + `resetConfirmationBatch()`, reset before each agent call); `issueConfirmation()` now records `user_id` and returns `other_pending_actions` so the model can present all pending confirmations together instead of one at a time; `consumeConfirmation()` validates `user_id` before consuming.
  - `WhatsAppAgent` prompt — injects timezone-aware current date/time (from user profile or app timezone); stricter rules force a tool call for user/account data instead of assuming, and require explicit confirmation before create/update/delete.
- **AI Tools — reference fields & lifecycle hooks**
  - New `reference` field type — validates a value against real model records (for large/searchable models like accounts, contacts, products) instead of a static option list.
  - `BaseAiTool` subclasses gain `creating()`, `updating()`, `guardDelete()` hooks for custom data processing and business-rule validation.
  - `lookupOptions()`/`buildLookupHints()` extracted into reusable methods, removing duplication across create/update/lookup tools.
- **Filter — new Similar operator (fuzzy match)**
  - `Filter::OperatorType['Similar']` + `andSimilar()`/`orSimilar()`; `Helper::similaritySql()` builds a Postgres trigram (`pg_trgm`) similarity condition, degrading to a LIKE-contains match on other drivers.
  - New `search.similarity_threshold` config (env `DB_SIMILARITY_THRESHOLD`, default `0.35`); `HasFilterModel`/`HasSearchModel` wired for the `SIMILAR` operator — `scopeSearch`'s column-operator map now clamps to a safe subset (`Equal`/`Contains`/`StartWith`/`EndWith`/`FullText`/`Similar`), falling back to `Contains` for anything else instead of erroring.
- Version bump to 1.3.4.

---

## [v1.3.3] - 09 Jul 2026

Patch release — chunked WA media upload for large files, AI tool eager-confirmation flow, image-extraction agent, WhatsApp Bouncer dedicated Redis connection.

- **WhatsApp — chunked media upload**
  - `WhatsAppClient::uploadChunked()` (init/chunk/complete, 2MB chunks) — new path for files over WaService's 2MB direct-upload ceiling; `uploadDirect()`/`uploadChunked()` now both take an explicit `filename` instead of deriving it from the local path.
  - `WhatsAppService::sendMedia()` — new required `filename` param, auto-picks `uploadChunked()` vs `uploadDirect()` by file size (`DIRECT_UPLOAD_LIMIT` = 2MB).
- **AI Tools — eager-confirmation flow**
  - `BaseCreateAiTool`/`BaseUpdateAiTool`/`BaseDeleteAiTool` descriptions rewritten — model must call the tool immediately to get a server-issued `confirmation_token` and present its summary, instead of composing its own confirmation message first; never fabricate a token.
  - `BaseSearchTool` — new `search_synonyms` schema param, OR-combined with `search` in one query instead of the agent retrying keyword-by-keyword; multi-result listings now trim long field values to 200 chars (`trimForListing()`); no-match fallback listing also trimmed and points the agent to re-query by `id` for full detail.
- **AI — image extraction agent (new)**
  - `ImageExtractionAgent` — JSON-only image data-extraction agent, config-driven provider/model/timeout (`ai.whatsapp.*`).
  - `WhatsAppAgent` — media-intent instructions reworked to use prior conversation context (including the agent's own replies) instead of re-asking what an image is for when intent was already established.
- **WhatsApp Bouncer — dedicated Redis connection**
  - `BouncerEventPublisher` now publishes via a dedicated `bouncer` Redis connection instead of the app's default connection, so every app sharing one Bouncer instance lands events in the same Redis db; new `ai.whatsapp.bouncer.redis.*` config + `SolarisServiceProvider::registerBouncerRedisConnection()`.
- **Fixes**
  - `ProfileRepository::updated()` — `getPrevious()['phone_number']` now defaults to `''` instead of erroring when the previous value is unset.

---

## [v1.3.2] - 08 Jul 2026

Patch release — per-column full-text search override, document editor/notes PDF export rework, attachment upload by model name, kanban selector fix.

- **Search — per-column full-text override**
  - `<x-table-column searchable="FullText">` (or any `Filter::OperatorType` key) now overrides the model's default `$searchColumns` mode for that column, instead of only being settable model-wide.
  - `DataTable` — `extendSearch` now accepts `"column:Mode"` entries (comma-separated) alongside bare column names; new `Filter::OperatorType`-aware merge of column-level, extendSearch-level, and model-level search modes.
  - `Helper::toTsQueryOr()` — builds an OR-joined raw `tsquery` (`"login log in"` → `login | log | in`) so a keyword guess matches on ANY word instead of Postgres's default AND-every-word; used by both `HasSearchModel::scopeSearch()` and the new `HasFilterModel::applyFullTextCondition()` (FULLTEXT filter operator, pgsql-only — other drivers degrade to LIKE).
- **Document editor / Notes — PDF export rework**
  - `HtmlToPdfController`/`HtmlToPdfRequest` — export now always resolves HTML from `model` + `column` + `id` (all required, plus `type: document-editor|notes`); raw-`html`/arbitrary-`view` export removed.
  - `HtmlToPdfService::documentEditor()` / `::notes()` replace the single `export()` method — document-editor export additionally strips OLE objects, CSS variables, and non-PDF-renderable media embeds (CKEditor video/media blocks); notes export strips `<video>` tags. New `HtmlToPdfService::view()` for rendering an arbitrary Blade view to PDF without the model/column lookup.
  - `document-editor.js`/`notes.js` — dropped `table-name`/`setTableName()` in favor of `model`; PDF export now requires the field to be bound to a saved record (`model`+`column`+`id`) and shows an error alert otherwise; download now goes through `FileHelper.downloadFile()` instead of `Helper.downloadFile()`.
- **Attachment upload — support `model` in place of `table_name`**
  - `DropzoneUpload` — new `model` option/attribute/`setModel()` alongside `table-name`; `AttachmentRequest` accepts `model` (nullable).
  - `AttachmentRepository::chunkUpload()` — resolves the destination table from `model` via `Helper::resolveModelClass()` when `table_name` isn't given directly.
- **Fixes**
  - `solar-ui.js` — Kanban registration selector narrowed to `div[solar-ui="kanban"] div.TASK-kanban-board` (was matching the outer wrapper, not the board itself).

---

## [v1.3.1] - 07 Jul 2026

Patch release — WhatsApp AI human-mode sending, Bouncer integration wired end-to-end, AI tool confirmation gate, full-text search support.

- **WhatsApp AI — human-mode sending**
  - Integrated `Solaris-WhatsAppService`'s `mode: 'human'` (server-side typing indicator + delay + per-device FIFO queue) into the send flow — `WhatsAppClient`/`WhatsAppService` now pass `mode`/`typing_speed` through to the gateway.
  - `SendAiReplyJob` removed — AI replies are sent directly from `ProcessAiChatResponse` (one fewer queue hop); anti-ban pacing is now entirely WhatsAppService's responsibility, not Laravel's.
  - New `wa_messages.status` value `queued` (migration `0002_01_01_000027_core_add_queued_status_to_wa_messages`) — human-mode sends start as `queued` until the existing `message.status` webhook confirms actual delivery.
  - Config: `ai.whatsapp.typing_speed` now passed straight through to WhatsAppService; removed the unused local `typing_presets` (cps/max) formula.
- **WhatsApp AI Bouncer — integration wired end-to-end**
  - `BouncerEventPublisher` (Laravel → Redis Stream `wa-ai-bouncer-events`) + `AiBouncerController` (`POST /webhooks/whatsapp-ai-bouncer`, Bouncer → Laravel process-batch callback, HMAC-verified) — both gated by `ai.whatsapp.mode = bouncer`.
  - `DispatchAiResponse` / `DispatchAiOnMediaReady` updated to publish to the Bouncer instead of dispatching AI processing directly when in `bouncer` mode.
- **AI Tools — code-level confirmation gate**
  - `BaseAiTool::issueConfirmation()` / `findConfirmation()` — one-time-token confirmation for mutating tools, enforced server-side rather than relying on the LLM choosing to ask first.
  - `BaseCreateAiTool`, `BaseUpdateAiTool`, `BaseDeleteAiTool` updated to require a `confirmation_token` before actually mutating data.
  - `BaseSearchTool` — searchable columns can now opt into full-text search via `'searchable' => 'FullText'`.
- **Search — full-text search support**
  - `HasSearchModel::scopeSearch()` — column definitions given as `'column' => 'OperatorKey'` (e.g. `FullText`) now opt out of the default LIKE tokenizer and use the named `Filter::OperatorType` operator instead.
  - New `Filter::OperatorType['FullText']`; `Helper::fullTextLanguage()` + new `search.fulltext_language` config (Postgres `to_tsvector`/`plainto_tsquery` language, ignored on MySQL/MariaDB).
- **Fixes**
  - JS circular-dependency dead zone — further fix in `solar-factory.js`/`solar-ui.js` (follow-up to v1.3.0's split).

---

## [v1.3.0] - 03 Jul 2026

Minor release — Admin Dashboard, WhatsApp AI Agent overhaul, JS module dead-zone fix, smoke test suite.

- **Admin Dashboard (new)**
  - New `AdminDashboardController` + `AdminDashboard` service — 5 tabs: Users & Sessions, Storage, WhatsApp, Approval, Agent AI.
  - New JS modules per tab (`users-sessions.js`, `storage.js`, `whatsapp.js`, `approval.js`, `agent-ai.js`) + `page.blade.php` and section partials.
  - `AdminDashboardMenuSeeder` registered in `DatabaseSeeder`; new config keys in `config/solaris.php`.
- **WhatsApp AI Agent — overhaul + ban mitigation**
  - `WhatsAppAgent` enhanced; new `HelpTool`, `ResetConversationTool` update; `ForgotPasswordTool`, `GetProfileTool`, `SetAvatarTool`, `UpdateProfileTool` reworked.
  - New `SendAiReplyJob` — delayed send message to reduce WA ban risk; `ProcessAiChatResponse` updated to dispatch via delayed job.
  - `AiService`, `WhatsAppClient`, `WhatsAppService` extended to support delayed/queued replies.
  - New `nickname` field on profiles (migration `2026_01_01_000026_core_add_nickname_to_profiles`) — used by AI agent; `ProfileRequest` and `about.blade.php` updated.
  - Clear-cache-on-update wired for WA AI agent user data (`UserController`, `ProfileRepository`, `UserRepository`).
- **JS — module alias + circular dependency fix**
  - JS import alias updated across `app.js`, page modules, and Solaris JS (drop `jsconfig.json` legacy alias entries).
  - Fixed circular dependency dead-zone in Solaris JS core: `solar-ui.js` split — new `solar-factory.js` extracted; `filter.js` split — new `filter-constants.js` extracted; `attachment.js`, `chat-setup.js`, `form.js`, `lookup-input.js`, `folders.js`, `solar-singleton.js` updated accordingly.
  - New `chat/setup-modal.blade.php`; `attachment.blade.php`, `chat.blade.php`, `dropzone.blade.php`, `lookup.blade.php` updated to match.
  - `button.js` — fixed load/unload state handling.
- **Smoke tests (new)** — `tests/Smoke/AdminRoutesTest.php`, `AuthRoutesTest.php`, `GuestRoutesTest.php`; `TestCase.php` reworked to support smoke suite.
- **Fixes / minor**
  - `FolderAccess` attribute — can now exclude relation.
  - `HasFolderModel`, `AuthSession` — minor fixes.
  - `PermissionController`, `ExcelController` — minor cleanup.
  - `thank-you.blade.php` — minor update.

---

## [v1.2.6] - 30 Jun 2026

Patch release — WhatsApp controller refactor, device setup UI, and thank-you countdown resend.

- **WhatsApp — controller split**
  - `WhatsAppCoreController` stripped; logic extracted into new `WhatsAppHandler` — handles conversations, messages, send, markAsRead, downloadMedia, checkMediaStatus, and device setup (device-info, connect, logout, QR stream).
  - New `WhatsAppController` — thin gateway controller that delegates to `WhatsAppHandler`.
  - Routes reorganized under `/whatsapp/` prefix group with dedicated named routes (`core.whatsapp.*`).
  - WA events (`WaMessageReceived`, `WaMessageMediaReady`, `WaMessageStatusUpdated`, `WaProfilePictureUpdated`) updated to match new handler structure.
- **WhatsApp — device setup UI**
  - New `chat-setup.js` — JS module for WhatsApp device setup flow (QR scan, connect, logout).
  - New `setup-modal.blade.php` — modal UI for device setup.
  - `chat.blade.php` and `whatsapp-core/page.blade.php` updated to integrate setup modal.
- **Thank-you page** — countdown resend notification logic rewritten; `page.js` now properly tracks countdown state and handles resend trigger.
- **Minor fixes** — `UserRepository` and user `list.blade.php` minor updates.

---

## [v1.2.5] - 26 Jun 2026

Patch release — WA AI UI, lookup fixes, calendar race condition, MakeCommand enhancements, and import signature update.

- **WhatsApp AI UI** — user list table now shows `WhatsApp AI` column (allowed/denied badge); user and profile pages display WA AI status in profile section.
- **Lookup input** — fixed disabled state not applied when `disabled` attribute is present at initialization; general updates.
- **`calendar.js`** — fixed race condition.
- **`MakeCommand` enhancements**
  - New options: `--model` (repository model binding), `--parent`, `--parent-column`, `--stage-model`, `--stage-column` for non-interactive scaffolding.
  - `approve` case indentation fix.
- **`importRules()` signature change** — removed `$row` parameter from `SolarisImportable` interface and `HasImportModel` trait. ⚠️ Breaking: update all implementations.
- **AI stubs** — new `stubs/ai/` directory: `AGENTS.md`, `CLAUDE.md`, `cursor-rules`, copilot instructions, and Solaris skill guides for AI coding assistants.
- **`PublishCommand`** — new command added.
- **`BaseRepository`** — removed unused Symfony Clock import.
- **Removed** — `whatsapp-preview` Blade component (unused); `SOLARIS_MAKE_GUIDE.md` and `Solaris Command Doc.md` (replaced by AI stubs).

---

## [v1.2.4] - 24 Jun 2026

Patch release — access right UI redesign, AI error handling, config simplification, and bug fixes.

- **Access Right module** — UI/UX overhaul for rule list and modals; fixed drag-and-drop priority calculation on first/last item.
- **AI — specific error messages in `ProcessAiChatResponse`**
  - `resolveErrorMessage()` and `errorMessages()` added — returns a user-facing Indonesian message matched to the exception type.
  - Handled types: `RateLimitedException`, `ProviderOverloadedException`, `InsufficientCreditsException`, and `RequestException` (HTTP 400, 401, 403, 413, 500, 502, 503, 504, 529).
- **AI — WhatsApp config simplification**
  - New `device` key added to `ai.whatsapp` config — replaces the per-device override comment block.
  - `DispatchAiResponse` listener simplified: checks `ai.whatsapp.device` directly instead of resolving a per-device config map.
- **WhatsApp seeders**
  - New `WhatsAppMenuSeeder` — seeds a WhatsApp menu item under the Admin category with role assignment.
  - `WhatsAppMenuSeeder` registered in `DatabaseSeeder`.
- **`MetricDashboard` fix** — when `readable = false`, value now formatted via `number_format()` instead of a raw cast, respecting `decimal`, `decimalSeparator`, and `thousandSeparator` settings.
- **`HasPreparedModel` fix** — `array_filter` in `HasOne`/`HasMany` lookup now uses `ARRAY_FILTER_USE_BOTH` to correctly preserve array keys when filtering out the foreign key from the nested structure.
- **`table-column` component** — removed unused `width` prop.

---

## [v1.2.3] - 23 Jun 2026

Patch release — AI CRUD base tools, config-driven tool registry, and lookup enhancements.

- **AI CRUD base tools**
  - New `BaseCreateAiTool` — abstract base for AI tools that create records; auto-generates `description()` from column definitions, handles validation via `rules()`, and delegates to `create()`.
  - New `BaseUpdateAiTool` — same pattern for update operations; auto-generates `description()` and delegates to `update()`.
  - New `BaseDeleteAiTool` — abstract base for AI tools that delete records.
- **AI tool registry refactor**
  - `SolarisServiceProvider` no longer hard-registers tool classes; uses new `registerAiTools()` which resolves tools via `Helper::aiTool()`.
  - New `tool_namespaces` and `tools` keys in `[ai]` config — maps slug → FQCN. Project `App\Ai\Tools` namespace has highest priority, enabling per-project tool overrides.
  - `Helper::aiTool(string $slug)` — resolves a tool class from config slug, checking `tool_namespaces` in reverse priority order.
  - `Helper::resolveAiToolClass(string $toolClass)` — resolves short class name against registered namespaces with FQCN fallback.
- **New `QuickReplyTool`** — sends an immediate acknowledgment message to the user before slow or multi-step operations; registered as `quick_reply`.
- **`BaseAiTool` enhancements**
  - `cleanData(Request $request, array $columns)` — extracts, trims, and resolves lookup fields from a request in one pass; returns `[$data, $errors]`.
  - `filled(Request $request, string $key)` — checks whether a request key is present and non-empty.
- **`LookupRegionTool` enhancements**
  - Ambiguity detection: when multiple regions share the same name, returns `ambiguous: true` with parent-context options and instructs the AI to ask the user to clarify before retrying with `parent_id`.
  - `PARENT_RELATION` map added for parent-context enrichment in ambiguous results.
- **`LookupOptionsTool`** — updated and enhanced.
- **`UpdateProfileTool`** — major refactor; now uses `cleanData()` for field extraction and lookup resolution.
- **`BaseSearchTool`** — fixed and refactored for cleaner column/folder/lookup handling.
- **`AiService`** — enhanced user cache keyed by phone number for faster AI context lookups.
- **`Helper::stripHtml()`** — new utility: converts HTML to plain text, preserving block-level newlines and stripping tags/entities.
- **`UserRequest`** — username validation now enforces `min:5` and rejects email-format values.

---

## [v1.2.2] - 22 Jun 2026

Patch release — AI tool architecture refactor with shared base classes.

- **AI Tool refactor**
  - Replaced `AiTool` interface with abstract `BaseAiTool` class — all tools now extend it instead of implementing the interface.
  - `resolveLookup()` extracted from `UpdateProfileTool` into `BaseAiTool` for reuse across tools (fuzzy name-to-ID matching with exact, partial, and Levenshtein scoring).
  - `waToHtml()` added to `BaseAiTool` — converts WhatsApp-style text (lists, blockquotes, bold, italic, strikethrough, code) to HTML.
  - New `BaseSearchTool` extending `BaseAiTool` — provides search/filter/folder capabilities for search-oriented AI tools with column schema, folder awareness, and lookup resolution.
  - `AiToolRegistry` updated to reference `BaseAiTool` instead of removed `AiTool` interface.
  - `BaseSetAvatarTool` refactored: constructor accepts `WaConversation` via parent; `SetAvatarTool` updated accordingly.
  - `UpdateProfileTool` cleaned up: uses `Helper::model()` instead of deprecated `Helper::config()`, typed `Profile` parameter, removed duplicated `resolveLookup()`.
- **Internal** — removed `src/Ai/Contracts/AiTool.php` interface file.

---

## [v1.2.1] - 19 Jun 2026

Patch release — filter enhancements, WA AI fixes, and migration update.

- **Filter enhancements**
  - New filter column support.
  - New date filter with timezone support.
  - Added `doesntHave`, `isEmpty`, and `isNotEmpty` filter types.
  - Extended filter support in folder component.
  - Fixed number field issue when input value is `0`.
- **WhatsApp AI fixes**
  - Fixed auth user bug in `WhatsAppAgent`.
  - Fixed and fine-tuned `UpdateProfileTool`.
- **Migration** — updated `wa_conversations` table migration.

---

## [v1.2.0] - 19 Jun 2026

Major release — WhatsApp AI integration and module enhancements.

- **WhatsApp AI** — AI-powered assistant embedded in WhatsApp conversations.
  - `AiService` and `WhatsAppAgent` — agent orchestration with tool-calling support.
  - `AiToolRegistry` — registry for custom AI tools.
  - Built-in tools: `GetProfileTool`, `UpdateProfileTool`, `SetAvatarTool`, `ForgotPasswordTool`, `ResetConversationTool`, `LookupOptionsTool`, `LookupRegionTool`.
  - `AiProfileData` — structured data class for passing user profile context to AI.
  - `AvatarService` — fetch and set avatar from a URL.
  - Listeners: `DispatchAiResponse`, `DispatchAiOnMediaReady`.
  - Events: `WaMessageMediaReady`, `WaMessageProcessing`, `WaMessageSending`, `WaProfilePictureUpdated`.
  - Job: `ProcessAiChatResponse` for async AI response generation.
  - Migration: AI opt-in columns on users and conversations tables.
  - New `[ai]` config section in `solaris.php`.
- **WhatsApp module improvements**
  - `DownloadWaMediaJob` — async media download on message receive.
  - `FetchWaProfilePictureJob` — async contact profile picture fetch.
  - Renamed `ProcessWhatsAppWebhookJob` → `WhatsAppWebhookJob`.
  - New webhook data types: `WebhookMediaReadyData`, `WaContactInfo`.
  - Refactored `WhatsAppService`, `WhatsAppClient`, `WhatsAppCoreController`, `WhatsAppWebhookController`.
  - Added `WHATSAPP_BASE_URL` env key.
  - Enhanced Chat UI — audio message support via `audio-chat.js`.
  - Major `chat.js` refactor with audio recording and playback.
- **Bug fixes & improvements**
  - Fixed `HasOne` relation issue in `HasPreparedModel` trait.
  - `AttachmentRepository` — thumbnail logic extracted to dedicated method.
  - Fixed thumbnail attachment bug in WA message receive.
  - `attachment.js` internal refactor.
  - `ProfileRequest` validation enhancements.

---

## [v1.1.0] - 11 Jun 2026

Major release — WhatsApp integration and component improvements.

- **WhatsApp Service** — full WhatsApp link-device integration via Solaris WA Service: send/receive messages, media, webhooks.
  - `WhatsAppService` and `WhatsAppClient` for API communication.
  - `WaConversation` and `WaMessage` models with migration.
  - Webhook handling via `WhatsAppWebhookController` and `ProcessWhatsAppWebhookJob`.
  - Events: `WaMessageReceived`, `WaMessageStatusUpdated`.
  - `DownloadWaThumbnailJob` for async media thumbnail download.
  - `WhatsAppCommand` for CLI management.
- **Chat UI component** — new `<x-core::chat>` Blade component with full conversation UI, message bubbles, and media support.
- **Enhanced button load/unload** — improved load/unload lifecycle in button component.
- **New `Helper::esc()` JS method** — HTML-safe escaping for attribute and text content insertion.
- Updated code generator — exception check before file creation.
- Minor dashboard styles fix.

---

## [v1.0.6] - 5 Jun 2026

- Updated folder component — refactored JS logic and added boolean support via switch checkbox.
- Updated funnel chart — added hover and click events, integrated `on`/`off`/`trigger` from Solar component system.

---

## [v1.0.5] - 4 Jun 2026

- Fixed bug in dropdown stage component.

---

## [v1.0.4] - 3 Jun 2026

- Fixed stage button next/prev mode behavior.
- Updated LookupResource to support dot notation.
- Added view, reset, and trigger actions to code generator.
- Added public API to table component.
- Updated table-lookup component.

---

## [v1.0.3] - 26 May 2026

- Fixed 2FA flow in AuthService.
- Auth session now shown in user command (`showList`, `showInfo`).
- Removed deprecated `last_login`, `ip_address`, `user_agent` columns from users table.

---

## [v1.0.2] - 26 May 2026

- Updated email logo asset.

---

## [v1.0.1] - 26 May 2026

- Enhanced lookup seeder.

---

## [v1.0.0] - 25 May 2026

Major release — milestone version with significant new features across the entire package.

- **2FA (Two-Factor Authentication)** — full 2FA support in login, profile enable/disable/change method.
- **New email template system** — structured, reusable email templates.
- **Mobile & API support** — new routes and controllers for mobile clients; lookup, attachment, and profile APIs.
- **Table Lookup component** — new component integrating table selection within a lookup input.
- **New UI components** — OTP input, numeral display, fieldset, radio/checkbox card style.
- **Lock auth feature** — session lock screen support.
- **Attachment API** — serve and manage attachments via API.
- **Profile picture via Dropzone** — profile photo upload refactored using the Dropzone component.
- **Filter class refactor** — new `Filter` class for generating structured array filters.
- **Notification mobile support** — in-app and mobile push notification enhancements.
- **Session management** — session detail view, mobile device session tracking.
- **Kanban improvements** — exclude new board, board exception for drag & drop.
- **Comprehensive type hints** — return types added across models, repositories, controllers.
- Various bug fixes: folder column relations, assign modal counter, DataTable controller, Google SSO profile.

---

## [v0.9.0] - 24 Apr 2026

- Introduced **SolarResponse** — standardized response macro for all controllers (`response()` macro deprecated).
- **Notes component** now supports media uploads.
- Added PDF export for Notes using `dompdf`.
- `UploadFile` replaces deprecated `UploadAvatar`.
- Return type hints added across base repository and controllers.
- Enhanced import process, attachment URL handling, and axios interceptor.
- Toast notification position updated to bottom.

---

## [v0.8.12] - 21 Apr 2026

- Fixed Excel import failure issue.
- Fixed datepicker callback bug.

---

## [v0.8.11] - 20 Apr 2026

- Fixed bug in lookup input multiple selection inside forms.

---

## [v0.8.10] - 19 Apr 2026

- **New Lookup component** — replaces the old select-based lookup; breaking change.
- DataTable scope sort now supports relation `ORDER BY`.
- Introduced standard interfaces for Solaris Model.
- Added Blade component docs for Solar UI VS Code extension.
- Enhanced extend search in DataTable and Lookup.

---

## [v0.8.9] - 17 Apr 2026

- DataTable now supports pre-orders (default sort order before user interaction).
- Enhanced lookup input behavior.
- `BaseModel::scopeSort` supports custom parameters.
- Added `extend_search` to table.
- Edit page: new `mainCard` and `save` props.

---

## [v0.8.8] - 16 Apr 2026

- New **HTTP log service** for logging outbound HTTP requests.
- Lookup input now supports `displayValue` for setting initial display text.

---

## [v0.8.7] - 14 Apr 2026

- New **Dropzone component** for file uploads.
- Attachment component refactored to use Dropzone.
- Support for Vite asset resolution in local projects.
- Config-based auth login page customization.
- Fixed dark mode / custom theme glitch on hard reload.
- Fixed tab nav hidden class bug and edit page success event bug.

---

## [v0.8.6] - 6 Apr 2026

- Fixed permission assign user bug.
- New **phone preview component**.
- Fixed camera icon in dark mode.

---

## [v0.8.5] - 1 Apr 2026

- Added remove action in Solar List Page.
- New string helpers: `toTitleCase`, `toHeadline`.
- Left action slot position change in table.
- Updated `on`/`off` methods in Solar component class.
- Fixed view generator path for JS prop.

---

## [v0.8.4] - 1 Apr 2026

- Fixed Excel import bug.
- Export/import log page now uses `base.page` component.
- Fixed folder lookup field with condition.
- Fixed lookup input value retrieval.
- Added import access to default model stub.

---

## [v0.8.3] - 31 Mar 2026

- Fixed PHP deprecated warning in batch delete.
- Added scheduler to auto-clean export/import logs.
- Enhanced import process.
- DataTable service supports column exception via attribute.

---

## [v0.8.2] - 30 Mar 2026

- Updated Excel service (export/import improvements).
- Enhanced `downloadFiles` helper with new options param.
- Updated attribute support for extended params.

---

## [v0.8.1] - 27 Mar 2026

- Added `name` key parameter to Solar component events.
- Fixed profile picture issue.
- Updated folder access.
- Changed color palette.

---

## [v0.8.0] - 26 Mar 2026

Major update with significant UI and feature additions.

- **Export/Download table** — table data can now be exported.
- **Drag-and-drop helper** — reusable helper integrated into tree and menu-tree.
- **Folder enhancements** — improved folder component and access management.
- **Multi-select in lookup** — lookup input supports selecting multiple values.
- **Attachment viewer** — supports viewing PDF and text files inline.
- **Filter refactor** — relation filter and aggregate filter support.
- **Lookup input refactor** — link mode, JS doc improvements.
- **DataTable relation sort** — sort by related model columns.
- **Mobile UI fixes** — responsive improvements for small screens.
- **In-app notification update** — improved UI and behavior.
- **Primary color changed** from yellow to orange.
- Kanban updates, upload avatar via chunk upload.

---

## [v0.7.7] - 12 Mar 2026

- Fixed stage dropdown menu bug.
- Added `slug` string helper.
- Updated repository stub.

---

## [v0.7.6] - 11 Mar 2026

- Input components (checkbox, radio, option group) now support `disabled` prop.
- User list updates.

---

## [v0.7.5] - 9 Mar 2026

- New **approval feature** (initial implementation).
- Replaced custom toast with Bootstrap native toast.
- Fixed radio/option group bugs.
- Added `carbon()->localized()` macro.

---

## [v0.7.4] - 27 Feb 2026

- Fixed bug in access right object/record rule evaluation.

---

## [v0.7.3] - 27 Feb 2026

- Access right updates and fixes.
- Improved database migration helpers.

---

## [v0.7.2] - 26 Feb 2026

- **Access Rights feature** — object/record-level access control.
- New **Tab component** in Solar UI.
- Checkbox component improvements.
- Lookup input: new JS docs, enhanced options.
- Table and form component enhancements.

---

## [v0.7.1] - 23 Feb 2026

- **Menu Access feature** — control which users/roles can access menu items.
- **Code Generator UI** — visual interface for the code generator.
- New **tag input** component.
- Mask format component update.

---

## [v0.7.0] - 16 Feb 2026

- **Extend Module** feature — modules can now extend other modules.
- View alias changed: `x-solar` → `x-core`, `@solar` → `@core`.
- Auth page updates.

---

## [v0.6.5] - 13 Feb 2026

- **Module Generator** — new `solaris:make module` command to scaffold modules.
- New slot in list page component.
- Lookup management fixes.

---

## [v0.6.4] - 12 Feb 2026

- Fixed bug in assigning user to role or permission.

---

## [v0.6.3] - 11 Feb 2026

- Fixed menu migration bug.

---

## [v0.6.2] - 11 Feb 2026

- DataTable, config, and model parsing updates.

---

## [v0.6.1] - 10 Feb 2026

- Completed user, role, and permission admin feature.

---

## [v0.6.0] - 10 Feb 2026

Major admin UI update with new management pages.

- **Menu Management** — create and manage menus from the admin panel.
- **Role & Permission Management** — full CRUD for roles and permissions.
- **Lookup Management** — manage lookup data from the UI; supports update.
- **Assign Modal component** — UI for assigning users to roles/permissions.
- **Tree component** — new hierarchical display component.
- Refactored Lookup, DataTable, FormController, and FolderController.
- Default role seeder added.

---

## [v0.5.4] - 4 Feb 2026

- **Namespace refactor** — full standardization of Solaris namespaces.
- `SolarConfig` renamed to `SolarHelper`; `Helper::config()` is now the standard.
- New email verification middleware (`EnsureUserIsVerified`).
- New `visibleColumn` method in list page.
- Radio/checkbox/group input bug fixes.
- Moved Solaris command to Solaris DevKit package.

---

## [v0.5.3] - 29 Jan 2026

- Updated datepicker and stage button components.
- Metric component improvements.
- Fixed duplicate event trigger bug.
- Batch delete process improvements.

---

## [v0.5.3.1] - 30 Jan 2026

- Version bump only.

---

## [v0.5.2] - 12 Jan 2026

- Fixed migration issue on fresh install.

---

## [v0.5.1] - 8 Jan 2026

- Updated repository create/update logic to align with new hook events.

---

## [v0.5.0] - 8 Jan 2026

Major repository and table update.

- **Repository lifecycle hooks** — `creating`, `created`, `updating`, `updated`, `deleting`, `deleted` events in `BaseRepository`.
- **Table card mode** — table can display data as cards.
- **Select all** — select all rows across pages in table.
- **Batch delete in attachment** — select and delete multiple attachments.
- **StageHistoryModel & HasStageHistory trait** — track stage change history.
- Renamed all index naming to follow standard convention.

---

## [v0.4.5] - 29 Dec 2025

- **Batch delete** feature in table — select multiple rows and delete at once.
- In-app notifications now processed via queue.
- Modal form can rename or hide save/cancel buttons.
- Table supports auto-increment column and select-all toggle.

---

## [v0.4.4] - 19 Dec 2025

- Refactored metric dashboard.
- New `getInitialName` helper (generates initials from a name).
- Updated funnel chart and metric chart components.

---

## [v0.4.4.1] - 22 Dec 2025

- Fixed metric chart variant rendering.

---

## [v0.4.3] - 15 Dec 2025

- Extend module support.
- Axios error 500 handling.
- Detail module improvements.

---

## [v0.4.3.1] - 16 Dec 2025

- Hotfix: profile form access bug.

---

## [v0.4.2] - 15 Dec 2025

- **Module service** — create and manage detail modules.
- Attachment: dynamic max file size.
- Code generator bug fixes.

---

## [v0.4.1] - 12 Dec 2025

- Code generator fixes and enhancements.
- **Funnel chart** component added.
- Fixed metric dashboard.
- Default rate limiting for datatable, kanban, form, and lookup.
- Object permission seeder improvements.

---

## [v0.4.0] - 8 Dec 2025

- **ModelBinding** — replaces deprecated `parseShorthandModel`.
- **Security attribute** for `rawModel` functions.
- New validation attribute.
- Metric variant separated into distinct types.
- Page component restructured.
- Repository delete hooks: `deleting` & `deleted`.

---

## [v0.3.10] - 3 Dec 2025

- Fixed `initDiscard` bug in edit page.
- Fixed stage component click trigger.
- New `createActionButton` helper method.
- Response macros updated.
- Fixed SSO registration bug.

---

## [v0.3.9] - 28 Nov 2025

- **Kanban card editing** — cards are now editable directly on the board.
- Fixed null timezone handling in `AsDateTimeTimezone` cast.
- Renamed `card moving` event to `card moved`.
- Folder component bug fixes.

---

## [v0.3.8] - 27 Nov 2025

- Refactored folder UI into a reusable component.
- Refactored dropdown event handling in table.

---

## [v0.3.7] - 26 Nov 2025

- Improved search input UX — input no longer clears during table refresh.
- Helper and SolarConfig now prioritize default namespaces.

---

## [v0.3.6] - 24 Nov 2025

- Improved search logic in `HasSearchModel` trait.
- Fixed Kanban column render and columns prop bug.

---

## [v0.3.5] - 24 Nov 2025

- Major Solaris command update and config restructure.
- Stubs moved out of resources into dedicated folder.
- New migrations, new config values.
- Fixed like operator, assign menu role bug.

---

## [v0.3.4] - 20 Nov 2025

- Kanban updates.
- Updated modal form and new Solar Modal Page.
- New `isEmpty` method in filter.
- Fixed `resolveControllerClass` helper bug.
- Fixed menu service `isActive` bug.

---

## [v0.3.3] - 17 Nov 2025

- **New SolarComponent system** — major refactor of JS component base class.
- Old `solar-component` replaced with `solar-ui`, new `SolarComponent` base class.
- Fixed table list layout and attachment upload bug.
- Fixed number column type detection in PostgreSQL.

---

## [v0.3.2] - 14 Nov 2025

- **Folders feature** — group and segment data with folder-based filtering.
- **Advanced custom filter** — build complex filter conditions from the UI.
- New **Offcanvas component**.
- Lookup input can now populate client-side options.
- Modal form supports `afterLoad` callback.
- Pagination style changed to compact mode.

---

## [v0.3.1] - 12 Nov 2025

- Enhanced menu access middleware.
- Support assigning permissions from a role.
- Fixed cache clearing in menu service.
- Added username validation in profile.

---

## [v0.3.0] - 11 Nov 2025

- **Menu Access Control** — menus can be restricted by user, role, or permission.
- New `EnsureMenuAccess` middleware.
- Moved upload avatar logic to `UploadAvatar` trait.
- Moved attachment logic from Model to Repository.

---

## [v0.2.5] - 7 Nov 2025

- Updated stage buttons.
- Attachment service updates.
- New `backupTable` method in helper.

---

## [v0.2.4] - 2 Nov 2025

- Datagrid enhancements.
- Solar List Page improvements.
- Fixed lookup cache.
- Fixed table wrapper and added fixed column support.

---

## [v0.2.3] - 31 Oct 2025

- Composer and command updates.

---

## [v0.2.2] - 31 Oct 2025

- Default `rowDoubleClick` in Solar List Detail.
- In-app notification improvements.
- Fixed form submit on Enter key.
- Added buttons slot in modal form.
- Fixed SSO sign-up bug.
- Fixed lookup input bug.

---

## [v0.2.1] - 29 Oct 2025

- Stage and form improvements.
- Fixed list page component.
- Updated `AttachmentRepository`.

---

## [v0.2.0] - 27 Oct 2025

- **Solar Page component** — new base page component.
- Attachment component improvements.
- Simplified modal form.
- Fixed datatable and form bugs.

---

## [v0.1.5] - 26 Oct 2025

- Fixed change password bug.
- Various core bug fixes.

---

## [v0.1.4] - 23 Oct 2025

- Fixed `npm run dev` bug.
- Install command fix.

---

## [v0.1.3] - 22 Oct 2025

- Updated app.js and app.css publish command.
- Fixed seeder bug.

---

## [v0.1.2] - 22 Oct 2025

- **SolarConfig system** — centralized config helper.
- Major Solaris install command overhaul.
- Migration helper improvements.
- Form and table JS improvements.

---

## [v0.1.1] - 14 Oct 2025

- Menu creator updates.
- Helper improvements.
- Fixed ambiguous column bug.

---

## [v0.1.0] - 10 Oct 2025

- **Metric dashboard** — new dashboard with metric widgets.
- Enhanced search trait — supports multiple default search columns.
- New config options for user registration and SSO.
- Shorthand modal parsing.

---

## [v0.0.5] - 15 Sep 2025

- **Object Permission system** — permission at the object level, select mode.
- User cache for permissions.
- Custom casts.
- Code generator and model updates.

---

## [v0.0.4] - 9 Sep 2025

- Fixed profile and SSO user bug.

---

## [v0.0.3] - 9 Sep 2025

- Enhanced code generator command.
- UI fixes — logout button, input component types.

---

## [v0.0.2] - 8 Sep 2025

- Bug fixes: code generator, BaseModel sort, route integration, auth controller.
- Helper improvements.

---

## [v0.0.1] - 5 Sep 2025

- Initial release.
- Basic framework: auth, config, helper, layout templates, code generator, BaseModel.
