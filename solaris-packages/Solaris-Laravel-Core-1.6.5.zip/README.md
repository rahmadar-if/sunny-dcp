# 🚀 Solaris Core

A Laravel-based starter kit designed for building real-world enterprise and SaaS applications fast.

It’s basically Laravel — but on steroids. We've wired in all the essentials you usually spend days setting up, from granular access rights to dynamic UI components. You just focus on shipping features instead of writing boilerplate.

---

## 🛠 Features Breakdown

We packed this starter kit with features that devs actually need to build solid apps:

### 🎨 UI & Frontend Engine
- **Starter Kit Admin**: A fully ready-to-use layout template powered by **Bootstrap 5 (Latest)**. 
- **Solar UI Components**: All resource views are built using our custom `Solar UI` Blade components (located in `resources/views/components`).
- **Zero-Setup JS Integration**: Most Blade components are already wired up with JS and will run out-of-the-box without needing manual initialization. Need to tweak them? No problem—they're fully customizable.

### 🔐 Auth & Access Control
- **Auth Ready**: Login, register, and forgot password flows are done. You get **3 preset layouts** to choose from: Default, v1, and v2. Plus, built-in **SSO support with Google & Entra ID**.
- **Admin Management**: Full CRUD for Users, Roles, and Permissions. Assign roles, manage permissions, resend verifications, or reset passwords right from the dashboard.
- **Granular Access Rights**: Control access on two levels: 
  - **Object Permission**: Table-level access control.
  - **Record Permission**: Row-level access control.
  - Create rules based on user, role, or permission, and easily adjust execution priority via **drag & drop**.

### 🏗️ Data & Content Management
- **Dynamic Lookups Management**: Just make a model extend `LookupModel` and boom—it auto-registers and a CRUD UI is dynamically generated for users to manage the lookup data. 
- **Drag & Drop Menu Management**: Set up your sidebar dynamically. Reorder items, change parents, or categorize everything with a simple drag & drop. Includes robust menu-access controls to hide items based on user, role, or permission.
- **Smart DataTables**: Complex, dynamic filters (folders) are naturally integrated into every table view. You can define when and where to use them, giving users crazy powerful filtering capabilities.

### ⚡ Developer Experience (DX) & Tooling
- **CLI Boilerplate Generators**: Spin up your project files blazing fast using console commands (`MakeCommand` & `ExtendCommand`).
- **Code Generator Tool**: Stop worrying about generating complex invoice or transaction numbers. Define your format and let this tool handle code numbering automatically on data creation—supporting masks, multi-column value pulling, and nested relations!

### 🌟 Plus Some Next-Level Extras
We didn't stop there. Here's what else you get out of the box:
- **Kanban Boards**: Integrated Kanban features with drag-and-drop sort and move actions.
- **Excel Export/Import**: Advanced export features (custom columns, pagination scoping, previews) and template-driven imports (supporting both code and display-name columns).
- **Metric Dashboards**: Quick-to-setup analytic and metric boards.
- **Robust Attachments**: Built-in support for chunked file uploads and generic attachment management.
- **Notifications**: Out-of-the-box In-App, Web Push, and Email notifications.
- **User Profiles**: Let users manage their bios, notification preferences, and linked sign-on accounts.
- **WhatsApp Integration**: Full WhatsApp link-device support — send/receive messages and media, webhook handling, and real-time conversation UI with audio message support.
- **WhatsApp AI Assistant**: AI-powered assistant embedded in WhatsApp chats. Responds to messages, handles profile updates, lookups, and avatar changes via conversational AI with extensible tool support (`AiToolRegistry`).

---

## 📚 Documentation

The official documentation is **currently in development**. 
Once finished, there will be a separate website and dedicated documentation files detailing customization guides, component usage, and advanced setups.
