<x-core::page.auth 
    title="Two-Factor Authentication" 
    package="core" 
    path="login/two-factor-index">

    <x-core::form 
        id="login-2fa" 
        :action="route('login.2fa.store')" 
        method="POST">

        <div class="text-center mb-4">
            @if ($method === 'email')
                <div class="mb-3">
                    <i class="bi bi-envelope-check fs-1 text-primary"></i>
                </div>
                <h5 class="fw-semibold">Check your email</h5>
                <p class="text-muted fs-13">We sent a 6-digit code to your email address. Enter the code below to continue.</p>
            @else
                <div class="mb-3">
                    <i class="bi bi-shield-lock fs-1 text-primary"></i>
                </div>
                <h5 class="fw-semibold">Authenticator app</h5>
                <p class="text-muted fs-13">Open your authenticator app and enter the 6-digit code for your account.</p>
            @endif
        </div>

        <x-core::otp-input
            id="login-otp"
            :resend-url="$showResend ? route('login.2fa.resend') : null"
        />

        <x-core::button id="2fa-submit" type="submit" class="w-100 mt-4">Verify</x-core::button>

        <div class="mt-3 text-center">
            <a href="{{ route('login') }}" class="fs-13 text-muted">Back to login</a>
        </div>

    </x-core::form>

    @push('pre-scripts')
    <script>
        const TWO_FACTOR_METHOD = {{ Js::from($method) }}
        const LOGIN_ROUTE = {{ Js::from(route('login')) }}
    </script>
    @endpush
</x-core::page.auth>
