<x-core::page.auth 
    title="Register"
    package="core"
    path="register/page">

    <x-core::form 
        id="register" 
        :action="route('register.store')" 
        method="POST">
        
        <x-core::field id="name" label="Name" required>
            <x-core::input  
                placeholder="Your full name, please 😊"/>
        </x-core::field>
        
        <x-core::field id="email" label="Email" required>
            <x-core::input 
                placeholder="We'll need your best email 📧"/>
        </x-core::field>
        
        <x-core::field id="password" label="Password" required>
            <x-core::password />
        </x-core::field>

        <x-core::field id="password_confirmation" label="Confirm Password" required>
            <x-core::password />
        </x-core::field>

        <x-core::button id="register-submit" type="submit" class="w-100 mt-3">Sign Up</x-core::button>

        <div class="mt-4 text-center">
            <p>Already have an account <a href="{{ route('login') }}" class="fw-semibold"> Sign In </a> </p>
        </div>

        @if (SolarHelper::config("auth.sso.register"))

            <div class="divider my-4">
                <div class="divider-text">or continue with</div>
            </div>

            <div class="d-flex justify-content-center gap-2">
                <x-core::button 
                    id="google" 
                    variant="outline" 
                    color="danger" 
                    data-url="{{ route('sso.redirect', ['provider' => \Solaris\Core\Const\SSOProviderConst::Google, 'mode' => 'register']) }}">
                    <i class="ri-google-line me-1"></i>Google
                </x-core::button>

                {{-- <x-core::button 
                    id="google" 
                    variant="outline" 
                    color="danger" 
                    data-url="{{ route('sso.redirect', ['provider' => \Solaris\Core\Const\SSOProviderConst::Google, 'mode' => 'register']) }}">
                    <i class="ri-google-line me-1"></i>Google
                </x-core::button> --}}

                {{-- <x-core::button 
                    id="google" 
                    variant="outline" 
                    color="danger" 
                    data-url="{{ route('sso.redirect', ['provider' => \Solaris\Core\Const\SSOProviderConst::Google, 'mode' => 'register']) }}">
                    <i class="ri-google-line me-1"></i>Google
                </x-core::button> --}}
            </div>

        @endif

    </x-core::form>

    @push('pre-scripts')
        <script>
            const SSO_REGISTER = {{ Js::from(SolarHelper::config("sso.register", false)) }}
        </script>
    @endpush
</x-core::page.auth>