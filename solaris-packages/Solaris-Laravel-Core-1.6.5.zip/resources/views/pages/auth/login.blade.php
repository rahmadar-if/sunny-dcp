<x-core::page.auth 
    title="Login"
    package="core"
    path="login/index">

    <div id="lockout-notice" class="alert alert-danger text-center d-none mb-3" role="alert">
        <i class="ri-lock-line me-1"></i>
        Too many failed attempts. Try again in <strong id="lockout-countdown"></strong>.
    </div>

    <x-core::form
        id="login"
        :action="route('login.store')"
        method="POST">

        <x-core::field id="username" label="Username/email" required>
            <x-core::input  
                placeholder="Enter your username/email"/>
        </x-core::field>
        
        <x-core::field id="password" label="Password" required>
            <x-core::password />
        </x-core::field>
        
        <div class="d-flex justify-content-between">
            <x-core::checkbox id="remember" label="Remember me"/>
            <a href="{{ route('forgot-password') }}" class="fw-semibold">Forgot password?</a>
        </div>

        <x-core::button id="login-submit" type="submit" class="w-100 mt-3">Sign In</x-core::button>

        @if (SolarHelper::config("auth.register"))

            <div class="mt-4 text-center">
                <p>New on our platform? <a href="{{ route('register') }}" class="fw-semibold"> Create an account </a> </p>
            </div>
            
        @endif

        @if (SolarHelper::config("auth.sso.login"))
        
            <div class="divider my-4">
                <p class="divider-text">or login using</p>
            </div>

            <div class="d-flex justify-content-center gap-2">
                <x-core::button 
                    id="google" 
                    variant="outline" 
                    color="danger" 
                    data-url="{{ route('sso.redirect', ['provider' => \Solaris\Core\Const\SSOProviderConst::Google, 'mode' => 'login']) }}">
                    <i class="ri-google-line me-1"></i>Google
                </x-core::button>

                {{-- <x-core::button 
                    id="google" 
                    variant="outline" 
                    color="danger" 
                    data-url="{{ route('sso.redirect', ['provider' => \Solaris\Core\Const\SSOProviderConst::Google, 'mode' => 'register']) }}">
                    <i class="ri-google-line me-1"></i>Google
                </x-core::button> --}}

                {{-- <x-core::button 
                    id="google" 
                    variant="outline" 
                    color="danger" 
                    data-url="{{ route('sso.redirect', ['provider' => \Solaris\Core\Const\SSOProviderConst::Google, 'mode' => 'register']) }}">
                    <i class="ri-google-line me-1"></i>Google
                </x-core::button> --}}
            </div>

        @endif

    </x-core::form>

    @push('pre-scripts')
        <script>
            const SSO_LOGIN = {{ Js::from(SolarHelper::config("sso.login", false)) }}
            const AUTH_LOCKED_UNTIL = {{ Js::from(session('auth_locked_until')) }}
        </script>
    @endpush
</x-core::page.auth>