<x-core::page.auth 
    title="Forgot password"
    package="core"
    path="forgot-password/index">

    <x-core::form 
        id="forgot-password" 
        :action="route('forgot-password.request')" 
        method="POST">

        <x-core::field id="email" label="Email" required>
            <x-core::input 
                id="email" 
                placeholder="Enter your email"/>
        </x-core::field>

        <x-core::button id="forgot-password-submit" type="submit" class="w-100 mt-3">Reset password</x-core::button>

        <div class="mt-4 text-center">
            <p><a href="{{ route('login') }}" class="fw-semibold"><i class="ri-arrow-left-line me-1"></i> Back to login </a> </p>
        </div>

    </x-core::form>

</x-core::page.auth>