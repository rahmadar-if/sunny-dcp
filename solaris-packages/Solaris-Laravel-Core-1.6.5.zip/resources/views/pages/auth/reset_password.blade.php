<x-core::page.auth 
    title="Reset password"
    package="core"
    path="reset-password/index">

    <x-core::form 
        id="reset-password" 
        :action="route('password.update')" 
        method="POST">

        <input type="hidden" id="token" value="{{ $token }}">
        <input type="hidden" id="email" value="{{ $email }}">

        <x-core::field id="password" label="Password" required>
            <x-core::password />
        </x-core::field>

        <x-core::field id="password_confirmation" label="Confirm Password" required>
            <x-core::password />
        </x-core::field>

        <x-core::button id="reset-password-submit" type="submit" class="w-100 mt-3">Reset password</x-core::button>

        <div class="mt-4 text-center">
            <p><a href="{{ route('login') }}" class="fw-semibold"><i class="ri-arrow-left-line me-1"></i> Back to login </a> </p>
        </div>

    </x-core::form>

</x-core::page.auth>