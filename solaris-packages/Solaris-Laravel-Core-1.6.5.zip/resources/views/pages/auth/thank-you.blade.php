<x-core::page.blank 
    title="Thanks for signing up"
    package="core" 
    path="thank-you/index">

    @push('styles')
        @vite([SolarAsset::css('pages/auth.scss', 'core')])
    @endpush

    <div class="coming-soon-main row authentication coming-soon justify-content-center g-0 my-auto" style="--login-bg: url('{{ Vite::asset(SolarHelper::config('auth.presets.default.background_image')) }}')">
        <div class="col-xxl-5 col-xl-5 col-lg-5 col-md-6 col-sm-7 col-11 my-auto">
            <div class="authentication-cover rounded-3 overflow-hidden card custom-card my-3">
                <div class="aunthentication-cover-content text-center">
                    <div class="row justify-content-center align-items-center mx-0 g-0">
                        <div class="col-xxl-11 col-xl-10 col-lg-10 col-md-12 col-sm-12 col-12">
                            <div>
                                <div class="mb-4"> 
                                    <a href="{{ route('home') }}"><img src="{{ Vite::asset(SolarHelper::config('application.assets.logo.auth.dark')) }}" alt="logo" width="256" height="68" style="height: 100%"></a> 
                                </div>
                                <h4 class="mb-2 text-fixed-white fs-2">Thanks for signing up</h4>
                                <p class="mb-0 text-fixed-white fs-16">We're excited to have you on board!</p>
                                <p class="mb-4 text-fixed-white fs-16">We've sent a confirmation email your way, just click the link inside to verify your account</p>
                                
                                <input type="hidden" id="email" value="{{ $email }}">
                                <div class="d-flex justify-content-center">
                                    <x-core::button id="resend_confirmation" color="secondary" disabled>Resend confirmation</x-core::button>
                                </div>
                                <small id="resend-countdown" class="text-fixed-white opacity-75 d-block text-center mt-2"></small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

</x-core::page.blank>