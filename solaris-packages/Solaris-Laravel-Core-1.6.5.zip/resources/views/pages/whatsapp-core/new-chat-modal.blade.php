<x-core::modal-box
    id="new-chat-modal"
    title="New Chat"
    size="md">

    <x-core::field id="new-chat-modal_contact_name" label="Name">
        <x-core::input
            placeholder="Contact name" />
    </x-core::field>

    <x-core::field id="new-chat-modal_phone_number" label="Phone Number" required>
        <x-core::input
            phone
            placeholder="628123456789" />
    </x-core::field>

    <x-slot:buttons>
        <x-core::button id="new-chat-modal_save">Start Chat</x-core::button>
    </x-slot>

</x-core::modal-box>