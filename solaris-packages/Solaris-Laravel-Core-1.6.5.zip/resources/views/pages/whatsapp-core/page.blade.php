@php
	$hasMore = $conversations->hasMorePages();
@endphp

<x-core::page.base
	title="WhatsApp"
	:breadcrumbs="$breadcrumbs"
	package="core"
	path="whatsapp-core/index">

	<x-slot:buttons>
		<x-core::button id="new-chat-btn">
			<i class="ri-add-line me-1"></i>New Chat
		</x-core::button>
		<x-core::button
			id="setup-btn"
			color="light"
			icon>
			<i class="ri-settings-3-line"></i>
		</x-core::button>
	</x-slot>

	<x-core::chat
		id="wa-chat"
		device="sunny"
		:conversations="$conversations->getCollection()"
		:chat-active="$chatActive ?? null"
		:data-has-more-conv="$hasMore ? 'true' : 'false'"
	/>

	@push('modal-content')
		@include("core::pages.whatsapp-core.new-chat-modal")
	@endpush

</x-core::page.base>
