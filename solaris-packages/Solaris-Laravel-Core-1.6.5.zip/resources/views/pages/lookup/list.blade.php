<x-core::page.list
    id="lookup"
    title="Lookup"
    class="table-hover"
    :breadcrumbs="$breadcrumbs"
    model="!LookupManagement@datatable"
    package="core"
    path="lookup/list-index"
    :new="false"
    :pagination="false" 
    :select_all="false"
    :refresh="false"
    lazy>

    <x-slot:table-left-action>
        <x-core::button id="lookup_refresh" size="sm" disabled>
            <span class="ri-refresh-line me-1"></span>Refresh
        </x-core::button>
    </x-slot:table-left-action>

    <x-slot:table-column>
        <x-core::table-action-column :edit="false" :delete="false"/>

        <x-core::table-column  
            data="name">
            Name
        </x-core::table-column>

        <x-core::table-column  
            data="table">
            Table
        </x-core::table-column>
    </x-slot>

</x-core::page.list>