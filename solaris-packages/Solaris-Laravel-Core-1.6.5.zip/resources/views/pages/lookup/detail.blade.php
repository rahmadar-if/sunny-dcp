<x-core::page.list
    id="lookup"
    title="{{$name}}"
    class="table-hover"
    :breadcrumbs="$breadcrumbs"
    model="!LookupManagement@datatableDetail({{$name}})"
    mode="grid"
    save_all
    discard_all
    package="core"
    path="lookup/detail-index" lazy>

    <x-slot:table-pre-left-action>
        <x-core::cancel-button size="sm" />
    </x-slot>

    <x-slot:table-column>
        <x-core::table-action-column discard :view="false"/>
        
        @foreach ($columns as $column)
            @if ($column["type"] == "lookup")
                <x-core::table-column 
                    :data="$column['name']" 
                    lookup 
                    searchable
                    orderable 
                    width="15rem"
                    :editable="[
                        'editor'       => 'lookup', 
                        'placeholder'  => 'Choose '.$column['displayName'], 
                        'source'       => $column['lookup'],
                        'isPagination' => true
                    ]">
                    {{ $column["displayName"] }}
                </x-core::table-column>
            @elseif($column["type"] == 'number')
                <x-core::table-column 
                    :data="$column['name']" 
                    orderable
                    width="15rem"
                    :editable="[
                        'editor'  => 'number', 
                        'decimal' => 2
                    ]">
                    {{ $column["displayName"] }}
                </x-core::table-column>
            @else
                <x-core::table-column 
                    :data="$column['name']"  
                    searchable 
                    orderable
                    width="15rem"
                    :editable="['editor' => $column['type'] ]">
                    {{ $column["displayName"] }}
                </x-core::table-column>
            @endif

        @endforeach

    </x-slot>

    @push('scripts')
        <script>
            const DATAGRID_COLUMNS = {{ Js::from($datagrid_columns) }}
        </script>
    @endpush

</x-core::page.list>