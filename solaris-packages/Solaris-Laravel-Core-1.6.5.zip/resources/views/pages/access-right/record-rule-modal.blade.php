<x-core::modal-form
	id="record-rule-modal"
	model="RecordRule"
	title="Record Rule"
    size="lg">

	<p class="fs-14 fw-medium">Records owned by:</p>

	<div class="row">
		<div class="col-lg-4">
			<x-core::field
				id="record-rule-modal_owner_type_id:owner_type_id"
				label="Type">
				<x-core::lookup
					placeholder="Choose owner type"
					:options="Solaris\Core\Models\PermissionType::toSelect()" />
			</x-core::field>
		</div>
		<div class="col-lg-8">
			<x-core::field
				id="record-rule-modal_owner_id:owner_id"
				label="Name"
				disabled>
				<x-core::lookup
					placeholder="Choose owner" />
			</x-core::field>
		</div>
	</div>

	<p class="fs-14 fw-medium mt-3">Can be accessed by:</p>

	<div class="row">
		<div class="col-lg-4">
			<x-core::field
				id="record-rule-modal_grantee_type_id:grantee_type_id"
				label="Type">
				<x-core::lookup
					placeholder="Choose type"
					:options="Solaris\Core\Models\PermissionType::toSelect()" />
			</x-core::field>
		</div>
		<div class="col-lg-8">
			<x-core::field
				id="record-rule-modal_grantee_id:grantee_id"
				label="Name"
				disabled>
				<x-core::lookup
					placeholder="Choose grantee" />
			</x-core::field>
		</div>
	</div>

	<p class="fs-14 fw-medium mt-3">With permission to:</p>

	<x-core::checkbox-group
		name="record-rule-modal_operation:operations"
		wrap:class="mb-3"
		switch inline
		:options="\Solaris\Core\Models\RightOperation::toRadio()->whereIn('id', [
            \Solaris\Core\Const\RightOperationConst::Read,
            \Solaris\Core\Const\RightOperationConst::Update,
            \Solaris\Core\Const\RightOperationConst::Delete
        ])" />

	<p class="fs-14 fw-medium">Rule Preview</p>
	<p class="rule-preview"></p>

</x-core::modal-form>
