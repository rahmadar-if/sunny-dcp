<x-core::page.list
    id="access-right"
    title="Access Right"
    class="table-hover"
    :breadcrumbs="$breadcrumbs"
    model="ObjectPermission@datatable"
    package="core"
    path="access-right/list-index"
    :select_all="false"
    new="@access-right-modal" lazy>

    <x-slot:table-column>
        <x-core::table-action-column />

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="code"
            searchable 
            orderable>
            Table
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap" 
            data="object_permission"
            orderable
            width="5%">
            Object permission
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap" 
            data="record_permission"
            orderable
            width="5%">
            Record permission
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap" 
            name="rules">
            Rules
        </x-core::table-column>
    </x-slot>

    @push('modal-content')
        @include("core::pages.access-right.modal")
    @endpush

</x-core::page.list>