<x-core::modal-form 
	id="access-right-modal" 
	model="ObjectPermission" 
	title="Access Right"
    size="md">

    <x-core::field 
        id="access-right-modal-code:code"
        label="Table"
        required>
        <x-core::lookup source="!ObjectPermission@getTables" />
    </x-core::field>

    <x-core::checkbox 
        id="access-right-modal-object_permission:object_permission"
        label="Object permission"
        wrap:class="mb-3"
        switch />

    <x-core::checkbox 
        id="access-right-modal-record_permission:record_permission"
        label="Record permission"
        switch />

</x-core::modal-form>