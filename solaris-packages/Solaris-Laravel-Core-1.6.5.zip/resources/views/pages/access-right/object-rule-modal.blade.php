<x-core::modal-form 
	id="object-rule-modal" 
	model="ObjectRule" 
	title="Object Rule">

	<p class="fs-14 fw-medium">Apply this rule to:</p>

	<div class="row">
		<div class="col-lg-4">
			<x-core::field 
				id="object-rule-modal_grantee_type_id:grantee_type_id"
				label="Type">
				<x-core::lookup
					placeholder="Choose type"
					:options="Solaris\Core\Models\PermissionType::toSelect()" />
			</x-core::field>
		</div>
		<div class="col-lg-8">
			<x-core::field 
				id="object-rule-modal_grantee_id:grantee_id"
				label="Name" 
				disabled>
				<x-core::lookup
					placeholder="Choose grantee" />
			</x-core::field>
		</div>
	</div>

	<p class="fs-14 fw-medium">Set permissions:</p>

	<x-core::checkbox-group 
		name="object-rule-modal_operation:operations"
		wrap:class="mb-3"
		switch inline
		:options="Solaris\Core\Models\RightOperation::toRadio()" />

	<p class="fs-14 fw-medium">Rule Preview</p>
	<p class="rule-preview"></p>

</x-core::modal-form>