<x-core::page.edit
    :id="$data->id"
    title="Access Right"
    :breadcrumbs="$breadcrumbs"
    model="ObjectPermission"
    package="core"
    path="access-right/page-index"
    profile-position="left"
    :main-card="false">

    @php
        $tabId = "access-right-page-tabs";
    @endphp

    @push('styles')
        <style>
            .rule-list {
                border: 1px solid var(--bs-border-color);
                border-radius: var(--bs-card-border-radius, 0.375rem);
            }

            .rule-list > .rule-card {
                border: none !important;
                border-bottom: 1px solid var(--bs-border-color) !important;
                border-radius: 0 !important;
                margin: 0 !important;
                box-shadow: none !important;
            }

            .rule-list > .rule-card:first-child {
                border-top-left-radius: var(--bs-card-border-radius, 0.375rem) !important;
                border-top-right-radius: var(--bs-card-border-radius, 0.375rem) !important;
            }

            .rule-list > .rule-card:has(+ .rule-drop-placeholder) {
                border-bottom-left-radius: var(--bs-card-border-radius, 0.375rem) !important;
                border-bottom-right-radius: var(--bs-card-border-radius, 0.375rem) !important;
                border-bottom: none !important;
            }

            .rule-card.drop-target {
                border-color: var(--primary-color) !important;
                box-shadow: 0 0 0 2px rgba(var(--primary-rgb), 0.2);
                transition: border-color 0.15s ease, box-shadow 0.15s ease;
            }

            .rule-drop-placeholder {
                transition: background-color 0.15s ease, color 0.15s ease;
                cursor: default;
                user-select: none;
            }
        </style>
    @endpush

    <x-slot:profile>
        <x-core::card>
            <x-core::field id="access-right-page-code:code" label="Table" disabled>
                <x-core::input :value="$data->code" />
            </x-core::field>

            <x-core::checkbox
                id="access-right-page-object_permission:object_permission"
                label="Object permission"
                wrap:class="mb-3"
                switch
                :checked="$data->object_permission" />

            <x-core::checkbox
                id="access-right-page-record_permission:record_permission"
                label="Record permission"
                switch
                :checked="$data->record_permission" />
        </x-core::card>
    </x-slot>

    <x-slot:footer>
        <x-core::tab id="{{ $tabId }}" class="p-0 mb-4" style="background-color: transparent !important;">
            <x-slot:nav>
                <x-core::tab-nav id="{{ $tabId }}_object_rules" active>Object Rules</x-core::tab-nav>
                <x-core::tab-nav id="{{ $tabId }}_record_rules">Record Rules</x-core::tab-nav>
            </x-slot>

            <x-slot:content>
                <x-core::tab-content id="{{ $tabId }}_object_rules" active class="p-0 border-0">
                    <div class="alert svg-primary alert-primary alert-dismissible fade show custom-alert-icon shadow-sm" role="alert">
                        <svg xmlns="http://www.w3.org/2000/svg" height="1.5rem" viewBox="0 0 24 24" width="1.5rem" fill="#000000"><path d="M0 0h24v24H0z" fill="none"></path><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"></path></svg>
                        These rules control who can perform CRUD operations on this table. Rules with a lower priority number take precedence. Drag to reorder.
                    </div>

                    <div class="d-flex align-items-center justify-content-between mb-3">
                        <x-core::button id="object-rule-new" size="sm">Add rules</x-core::button>
                        <x-core::refresh-button id="object-rule-refresh" size="sm" />
                    </div>

                    <div id="object-rule-list"></div>

                    <div id="object-rule-empty-state" class="d-flex flex-column align-items-center py-5 text-muted gap-2">
                        <i class="ti ti-shield-off fs-1 opacity-50"></i>
                        <span class="fs-6">No rules yet — click <strong>Add rules</strong> to get started.</span>
                    </div>
                </x-core::tab-content>

                <x-core::tab-content id="{{ $tabId }}_record_rules" class="p-0 border-0">
                    <div class="alert svg-primary alert-primary alert-dismissible fade show custom-alert-icon shadow-sm" role="alert">
                        <svg xmlns="http://www.w3.org/2000/svg" height="1.5rem" viewBox="0 0 24 24" width="1.5rem" fill="#000000"><path d="M0 0h24v24H0z" fill="none"></path><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"></path></svg>
                        These rules control access at the record level. Define who owns the data and who else can access each record. Drag to reorder.
                    </div>

                    <div class="d-flex align-items-center justify-content-between mb-3">
                        <x-core::button id="record-rule-new" size="sm">Add rules</x-core::button>
                        <x-core::refresh-button id="record-rule-refresh" size="sm" />
                    </div>

                    <div id="record-rule-list"></div>

                    <div id="record-rule-empty-state" class="d-flex flex-column align-items-center py-5 text-muted gap-2">
                        <i class="ti ti-shield-off fs-1 opacity-50"></i>
                        <span class="fs-6">No rules yet — click <strong>Add rules</strong> to get started.</span>
                    </div>
                </x-core::tab-content>
            </x-slot>
        </x-core::tab>
    </x-slot>

    @push('modal-content')
        @include("core::pages.access-right.object-rule-modal")
        @include("core::pages.access-right.record-rule-modal")
    @endpush

</x-core::page.edit>
