<x-core::page.list
    id="code-generator"
    title="Code Generator"
    class="table-hover"
    :breadcrumbs="$breadcrumbs"
    model="CodeGenerator"
    package="core"
    path="code-generator/list-index"
    :select_all="false"
    new="@code-generator-modal" lazy>

    <x-slot:table-column>
        <x-core::table-action-column :view="true"/>

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="code"
            searchable 
            orderable>
            Table
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap" 
            data="column"
            searchable
            orderable>
            Column
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap" 
            data="mask"
            searchable
            orderable>
            Mask
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap" 
            data="active"
            orderable>
            Active
        </x-core::table-column>
    </x-slot>

    <x-core::table-lookup
        id="code-generator-view-lookup"
        model="CodeGeneratorDetail"
        title="Mask Format"
        choose="Reset">
        <x-slot:column>
            <x-core::table-column data="mask_format" searchable orderable>Mask Format</x-core::table-column>
            <x-core::table-column data="last_number" orderable>Last Number</x-core::table-column>
        </x-slot>
    </x-core::table-lookup>

    <x-core::table-lookup
        id="code-generator-trigger-lookup"
        model="CodeGenerator"
        title="Select Record"
        choose="Trigger">
        <x-slot:column>
            <x-core::table-column name="name" searchable>Record</x-core::table-column>
        </x-slot>
    </x-core::table-lookup>

    @push('modal-content')
        @include("core::pages.code-generator.modal")
        @include("core::pages.code-generator.reset-modal")
    @endpush

    @push('scripts')
        <script>
            const MASK_FORMAT_PLACEHOLDER = {{ Js::from($placeholders) }}
            const MASK_FORMAT_TRANSFORMS = {{ Js::from($transforms) }}
        </script>
    @endpush

</x-core::page.list>