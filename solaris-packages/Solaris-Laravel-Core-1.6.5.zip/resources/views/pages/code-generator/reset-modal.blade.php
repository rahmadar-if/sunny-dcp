<x-core::modal-form
    id="code-generator-reset-form"
    model="CodeGeneratorDetail"
    title="Reset Last Number"
    size="sm">

    <x-core::field
        id="code-generator-reset-form-last_number:last_number"
        label="Last Number"
        required>
        <x-core::input number />
    </x-core::field>

</x-core::modal-form>
