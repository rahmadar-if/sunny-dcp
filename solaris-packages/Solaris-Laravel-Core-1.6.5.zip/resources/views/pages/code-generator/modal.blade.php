<x-core::modal-form 
	id="code-generator-modal" 
	model="CodeGenerator" 
	title="Code Generator"
    size="lg">

	@push('styles')
		@vite([SolarAsset::css('pages/code-generator.scss', 'core')])
	@endpush

    <x-core::field 
        id="code-generator-modal-code:code"
        label="Table"
        required>
        <x-core::lookup
            source="!CodeGenerator@getTables" />
    </x-core::field>

    <x-core::field 
        id="code-generator-modal-column:column" 
        label="Column"
        disabled required lazy>
        <x-core::lookup
            source="!CodeGenerator@getColumns" />
    </x-core::field>

	<div id="code-generator-modal-mask" class="mask-format-wrap">
        <x-core::label required>Mask Format</x-core::label>
		<div class="mask-format-editor border rounded-3 p-3" contenteditable="true" spellcheck="false" data-placeholder="Type @ for functions, # for columns..."></div>
	</div>

    <x-core::checkbox 
        id="code-generator-modal-active:active"
        wrap:class="mt-3"
        label="Active"
        switch />

</x-core::modal-form>