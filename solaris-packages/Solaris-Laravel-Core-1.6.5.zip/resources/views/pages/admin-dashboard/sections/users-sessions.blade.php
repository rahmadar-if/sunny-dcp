<div class="row mt-3">
    <div class="col-lg-3 col-md-6">
        <x-core::metric
            id="total-user"
            variant="compact"
            title="Total User"
            :value="$data['total_user']->value"
            icon="ri-user-line"
            color="primary"
            lazy />
    </div>

    <div class="col-lg-3 col-md-6">
        <x-core::metric
            id="active-user"
            variant="compact"
            title="Active User"
            :value="$data['active_user']->value"
            icon="ri-user-follow-line"
            color="success"
            lazy />
    </div>

    <div class="col-lg-3 col-md-6">
        <x-core::metric
            id="unverified-user"
            variant="compact"
            title="Unverified User"
            :value="$data['unverified_user']->value"
            icon="ri-mail-unread-line"
            color="warning"
            lazy />
    </div>

    <div class="col-lg-3 col-md-6">
        <x-core::metric
            id="non-active-user"
            variant="compact"
            title="Non-active User"
            :value="$data['non_active_user']->value"
            icon="ri-user-unfollow-line"
            color="danger"
            lazy />
    </div>
</div>

<div class="row">
    <div class="col-xxl-4 col-lg-5">
        <x-core::card>
            <x-slot:header class="d-flex justify-content-between">
                <div class="fs-14 fw-medium">User Distribution</div>
                <x-core::refresh-button id="user-distribution-refresh" size="sm" color="light" />
            </x-slot:header>

            <div id="user-distribution-chart"></div>

            <ul class="list-group list-group-flush" id="user-distribution-detail">
                @foreach ($data['user_distribution']['detail'] as $category)
                <li class="list-group-item d-flex align-items-center gap-2">
                    <span class="avatar avatar-sm bg-{{ $category['color'] }}-transparent">
                        <i class="{{ $category['icon'] }} text-{{ $category['color'] }}"></i>
                    </span>
                    <span class="flex-fill">{{ $category['name'] }}</span>
                    <span class="fw-medium">{{ $category['total'] }}</span>
                    <span class="fs-12 text-muted text-end" style="min-width: 3rem">{{ $category['percent'] }}%</span>
                </li>
                @endforeach
            </ul>
        </x-core::card>
    </div>

    <div class="col-xxl-8 col-lg-7">
        <x-core::table
            id="admin-active-sessions_list"
            class="table-hover"
            model="AuthSession@activeWithLastActive"
            lazy
            :new="false"
            :select_all="false"
            order_by="last_active_at:desc"
            extend_columns="user.email,device_name"
            length="10">

            <x-slot:preLeftAction>
                <span class="fs-14 fw-medium">Active Sessions</span>
            </x-slot:preLeftAction>

            <x-slot:column>
                <x-core::table-column
                    cell_class="text-nowrap"
                    name="user_name"
                    data="user.name"
                    searchable
                    orderable>
                    User
                </x-core::table-column>

                <x-core::table-column
                    cell_class="text-nowrap"
                    data="channel"
                    searchable
                    orderable>
                    Channel
                </x-core::table-column>

                <x-core::table-column
                    cell_class="text-nowrap"
                    data="user_agent"
                    searchable
                    orderable>
                    Device / Browser
                </x-core::table-column>

                <x-core::table-column
                    cell_class="text-nowrap"
                    data="last_active_at"
                    orderable>
                    Last Active
                </x-core::table-column>
            </x-slot:column>

        </x-core::table>
    </div>
</div>

@push('scripts')
    <script>
        const USER_DISTRIBUTION = {{ Js::from($data['user_distribution']['chart']) }}
    </script>
@endpush
