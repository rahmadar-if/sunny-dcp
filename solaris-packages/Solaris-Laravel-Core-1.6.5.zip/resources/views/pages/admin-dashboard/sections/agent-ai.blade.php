<div class="row mt-3">
    <div class="col-lg-4 col-md-6">
        <x-core::metric
            id="total-token-ai"
            variant="compact"
            title="Total Token (This Month)"
            :value="$data['total_token']->value"
            icon="ri-cpu-line"
            color="primary"
            lazy />
    </div>

    <div class="col-lg-4 col-md-6">
        <x-core::metric
            id="total-request-ai"
            variant="compact"
            title="Total Request (This Month)"
            :value="$data['total_request']->value"
            icon="ri-send-plane-line"
            color="info"
            lazy />
    </div>

    <div class="col-lg-4 col-md-6">
        <x-core::metric
            id="est-cost-ai"
            variant="compact"
            title="Est. Cost (This Month)"
            :value="$data['est_cost']->value"
            icon="ri-money-dollar-circle-line"
            color="success"
            lazy />
    </div>
</div>

<div class="row">
    <div class="col-xl-6">
        <x-core::card class="overflow-hidden" body:class="p-0">
            <x-slot:header class="d-flex justify-content-between">
                <div class="fs-14 fw-medium">Top Agent by Cost</div>
                <x-core::refresh-button id="top-agent-by-cost-refresh" size="sm" color="light" />
            </x-slot:header>

            <ul class="list-group list-group-flush" id="top-agent-by-cost">
                @forelse ($data['top_agent_by_cost'] as $item)
                <li class="list-group-item d-flex align-items-center justify-content-between gap-2">
                    <span class="fw-medium">{{ $item['name'] }}</span>
                    <div class="text-end">
                        <div class="fs-12 fw-medium">{{ $item['cost_human'] }}</div>
                        <div class="fs-11 text-muted">{{ number_format($item['total_token']) }} tokens &middot; {{ $item['total_request'] }} req</div>
                    </div>
                </li>
                @empty
                <li class="list-group-item text-center text-muted py-4">
                    No agent usage this month.
                </li>
                @endforelse
            </ul>
        </x-core::card>
    </div>

    <div class="col-xl-6">
        <x-core::card class="overflow-hidden" body:class="p-0">
            <x-slot:header class="d-flex justify-content-between">
                <div class="fs-14 fw-medium">Top User by Cost</div>
                <x-core::refresh-button id="top-user-by-cost-refresh" size="sm" color="light" />
            </x-slot:header>

            <ul class="list-group list-group-flush" id="top-user-by-cost">
                @forelse ($data['top_user_by_cost'] as $item)
                <li class="list-group-item d-flex align-items-center justify-content-between gap-2">
                    <span class="fw-medium">{{ $item['name'] }}</span>
                    <div class="text-end">
                        <div class="fs-12 fw-medium">{{ $item['cost_human'] }}</div>
                        <div class="fs-11 text-muted">{{ number_format($item['total_token']) }} tokens &middot; {{ $item['total_request'] }} req</div>
                    </div>
                </li>
                @empty
                <li class="list-group-item text-center text-muted py-4">
                    No user usage this month.
                </li>
                @endforelse
            </ul>
        </x-core::card>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <p class="fs-12 text-muted mb-0">
            Exchange rate: 1 USD = {{ $data['exchange_rate']['rate_human'] }}
            (updated {{ $data['exchange_rate']['fetched_at'] }}, source: {{ $data['exchange_rate']['source'] }})
        </p>
    </div>
</div>
