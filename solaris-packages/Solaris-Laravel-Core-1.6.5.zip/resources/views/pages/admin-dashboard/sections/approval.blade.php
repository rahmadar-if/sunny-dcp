<div class="row mt-3">
    <div class="col-xl col-lg-4 col-md-6">
        <x-core::metric
            id="total-pending-approval"
            variant="compact"
            title="Total Pending"
            :value="$data['total_pending']->value"
            icon="ri-time-line"
            color="warning"
            lazy />
    </div>

    <div class="col-xl col-lg-4 col-md-6">
        <x-core::metric
            id="total-in-progress-approval"
            variant="compact"
            title="In Progress"
            :value="$data['total_in_progress']->value"
            icon="ri-loader-3-line"
            color="info"
            lazy />
    </div>

    <div class="col-xl col-lg-4 col-md-6">
        <x-core::metric
            id="expiring-soon-approval"
            variant="compact"
            title="Expiring ≤ 3 Days"
            :value="$data['expiring_soon']->value"
            icon="ri-alarm-warning-line"
            color="danger"
            lazy />
    </div>

    <div class="col-xl col-lg-4 col-md-6">
        <x-core::metric
            id="expired-unresolved-approval"
            variant="compact"
            title="Expired Unresolved"
            :value="$data['expired_unresolved']->value"
            icon="ri-error-warning-line"
            color="dark"
            lazy />
    </div>

    <div class="col-xl col-lg-4 col-md-6">
        <x-core::metric
            id="avg-resolve-time-approval"
            variant="compact"
            title="Avg Resolve Time"
            :value="$data['avg_resolve_time']->value"
            icon="ri-timer-line"
            color="primary"
            lazy />
    </div>
</div>

<div class="row">
    <div class="col-xl-4">
        <x-core::card>
            <x-slot:header>
                <div class="fs-14 fw-medium">Request per Status</div>
            </x-slot:header>

            <div id="request-by-status-chart"></div>

            <ul class="list-group list-group-flush" id="request-by-status-detail">
                @foreach ($data['request_by_status']['detail'] as $item)
                <li class="list-group-item d-flex align-items-center gap-2">
                    <span class="avatar avatar-sm bg-{{ $item['color'] }}-transparent">
                        <i class="ri-circle-fill fs-10 text-{{ $item['color'] }}"></i>
                    </span>
                    <span class="flex-fill">{{ $item['name'] }}</span>
                    <span class="fw-medium">{{ $item['total'] }}</span>
                    <span class="fs-12 text-muted text-end" style="min-width: 3rem">{{ $item['percent'] }}%</span>
                </li>
                @endforeach
            </ul>
        </x-core::card>
    </div>

    <div class="col-xl-8">
        <x-core::card class="overflow-hidden" body:class="p-0">
            <x-slot:header class="d-flex justify-content-between">
                <div class="fs-14 fw-medium">Needs Action</div>
                <x-core::refresh-button id="needs-action-refresh" size="sm" color="light" />
            </x-slot:header>

            <ul class="list-group list-group-flush" id="needs-action">
                @forelse ($data['needs_action'] as $item)
                <li class="list-group-item">
                    <div class="d-flex align-items-center justify-content-between gap-2">
                        <div>
                            <span class="d-block fw-medium">{{ $item->name ?? '-' }}</span>
                            <span class="fs-12 text-muted">Requested by {{ $item->requester_name ?? '-' }}</span>
                        </div>
                        <div class="text-end">
                            <span class="badge bg-secondary-transparent text-secondary">Level {{ $item->level_label }}</span>
                            <div class="fs-11 text-muted mt-1">{{ $item->expires_human ?? 'No expiry' }}</div>
                        </div>
                    </div>
                </li>
                @empty
                <li class="list-group-item text-center text-muted py-4">
                    No approval needs action right now.
                </li>
                @endforelse
            </ul>
        </x-core::card>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <x-core::card class="overflow-hidden" body:class="p-0">
            <x-slot:header class="d-flex justify-content-between">
                <div class="fs-14 fw-medium">Resolved History</div>
                <x-core::refresh-button id="resolved-history-refresh" size="sm" color="light" />
            </x-slot:header>

            <ul class="list-group list-group-flush" id="resolved-history">
                @forelse ($data['resolved_history'] as $item)
                <li class="list-group-item">
                    <div class="d-flex align-items-center justify-content-between gap-2">
                        <div>
                            <span class="d-block fw-medium">{{ $item->name ?? '-' }}</span>
                            <span class="fs-12 text-muted">Requested by {{ $item->requester_name ?? '-' }}</span>
                        </div>
                        <div class="text-end">
                            <span class="badge bg-{{ $item->status_color }}-transparent text-{{ $item->status_color }}">{{ $item->status_name }}</span>
                            <div class="fs-11 text-muted mt-1">{{ $item->resolved_at_human }} &middot; {{ $item->duration_human }}</div>
                        </div>
                    </div>
                </li>
                @empty
                <li class="list-group-item text-center text-muted py-4">
                    No resolved approval yet.
                </li>
                @endforelse
            </ul>
        </x-core::card>
    </div>
</div>

@push('scripts')
    <script>
        const REQUEST_BY_STATUS = {{ Js::from($data['request_by_status']['chart']) }}
    </script>
@endpush
