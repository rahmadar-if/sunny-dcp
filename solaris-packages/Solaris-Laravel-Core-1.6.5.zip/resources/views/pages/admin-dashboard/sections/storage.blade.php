<div class="row mt-3">
    <div class="col-lg-3 col-md-6">
        <x-core::metric
            id="total-file"
            variant="compact"
            title="Total File"
            :value="$data['total_file']->value"
            icon="ri-file-line"
            color="primary"
            lazy />
    </div>

    <div class="col-lg-3 col-md-6">
        <x-core::metric
            id="total-size"
            variant="compact"
            title="Total Size"
            :value="$data['total_size']->value"
            icon="ri-hard-drive-2-line"
            color="info"
            lazy />
    </div>

    <div class="col-lg-3 col-md-6">
        <x-core::metric
            id="wa-file"
            variant="compact"
            title="WhatsApp File"
            :value="$data['wa_file']->value"
            icon="ri-whatsapp-line"
            color="success"
            lazy />
    </div>

    <div class="col-lg-3 col-md-6">
        <x-core::metric
            id="wa-storage"
            variant="compact"
            title="WhatsApp Storage"
            :value="$data['wa_storage']->value"
            icon="ri-whatsapp-line"
            color="success"
            lazy />
    </div>
</div>

<div class="row">
    <div class="col-xl-4 col-md-6">
        <x-core::card class="overflow-hidden" body:class="p-0">
            <x-slot:header class="d-flex justify-content-between">
                <div class="fs-14 fw-medium">Storage per Module</div>
                <x-core::refresh-button id="storage-per-module-refresh" size="sm" color="light" />
            </x-slot:header>

            <ul class="list-group list-group-flush" id="storage-per-module">
                @forelse ($data['storage_per_module'] as $item)
                <li class="list-group-item d-flex align-items-center justify-content-between">
                    <span class="fw-medium">{{ $item['name'] }}</span>
                    <span class="fs-12 text-muted">{{ $item['total_file'] }} files &middot; {{ $item['size_human'] }} &middot; {{ $item['percent'] }}%</span>
                </li>
                @empty
                <li class="list-group-item text-center text-muted py-4">
                    No storage usage recorded yet.
                </li>
                @endforelse
            </ul>
        </x-core::card>
    </div>

    <div class="col-xl-4 col-md-6">
        <x-core::card class="overflow-hidden" body:class="p-0">
            <x-slot:header class="d-flex justify-content-between">
                <div class="fs-14 fw-medium">Top Storage by User</div>
                <x-core::refresh-button id="top-storage-by-user-refresh" size="sm" color="light" />
            </x-slot:header>

            <ul class="list-group list-group-flush" id="top-storage-by-user">
                @forelse ($data['top_storage_by_user'] as $item)
                <li class="list-group-item">
                    <div class="d-flex align-items-center justify-content-between gap-2">
                        <div class="d-flex align-items-center gap-2">
                            <span class="avatar avatar-sm avatar-rounded bg-secondary">
                                {{ SolarHelper::getInitialName($item->user_name) }}
                            </span>
                            <div>
                                <span class="d-block fw-medium">{{ $item->user_name ?? '-' }}</span>
                                <span class="fs-12 text-muted">{{ $item->user_email ?? '-' }}</span>
                            </div>
                        </div>
                        <div class="text-end">
                            <div class="fs-12 fw-medium">{{ $item->total_size_human }} / {{ $item->limit_human }}</div>
                            <div class="fs-11 text-muted">{{ $item->total_file }} files &middot; {{ $item->percent }}%</div>
                        </div>
                    </div>
                    <div class="progress mt-2" style="height: 4px;">
                        <div class="progress-bar bg-{{ $item->percent >= 90 ? 'danger' : ($item->percent >= 70 ? 'warning' : 'success') }}"
                             role="progressbar"
                             style="width: {{ min(100, $item->percent) }}%"></div>
                    </div>
                </li>
                @empty
                <li class="list-group-item text-center text-muted py-4">
                    No storage usage recorded yet.
                </li>
                @endforelse
            </ul>
        </x-core::card>
    </div>

    <div class="col-xl-4 col-md-6">
        <x-core::card class="overflow-hidden" body:class="p-0">
            <x-slot:header class="d-flex justify-content-between">
                <div class="fs-14 fw-medium">Near Storage Limit</div>
                <x-core::refresh-button id="near-limit-users-refresh" size="sm" color="light" />
            </x-slot:header>

            <ul class="list-group list-group-flush" id="near-limit-users">
                @forelse ($data['near_limit_users'] as $item)
                <li class="list-group-item">
                    <div class="d-flex align-items-center justify-content-between gap-2">
                        <div class="d-flex align-items-center gap-2">
                            <span class="avatar avatar-sm avatar-rounded bg-danger-transparent">
                                {{ SolarHelper::getInitialName($item->user_name) }}
                            </span>
                            <div>
                                <span class="d-block fw-medium">{{ $item->user_name ?? '-' }}</span>
                                <span class="fs-12 text-muted">{{ $item->user_email ?? '-' }}</span>
                            </div>
                        </div>
                        <div class="text-end">
                            <div class="fs-12 fw-medium">{{ $item->total_size_human }} / {{ $item->limit_human }}</div>
                            <div class="fs-11 text-muted">{{ $item->total_file }} files &middot; {{ $item->percent }}%</div>
                        </div>
                    </div>
                    <div class="progress mt-2" style="height: 4px;">
                        <div class="progress-bar bg-danger" role="progressbar" style="width: {{ min(100, $item->percent) }}%"></div>
                    </div>
                </li>
                @empty
                <li class="list-group-item text-center text-muted py-4" id="near-limit-users-empty">
                    No user near the storage limit.
                </li>
                @endforelse
            </ul>
        </x-core::card>
    </div>
</div>
