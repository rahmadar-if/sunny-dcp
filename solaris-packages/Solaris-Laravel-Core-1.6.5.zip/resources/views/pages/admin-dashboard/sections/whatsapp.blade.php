<div class="row mt-3">
    <div class="col-lg-4 col-md-6">
        <x-core::metric
            id="total-device"
            variant="compact"
            title="Total Device"
            :value="$data['total_device']->value"
            icon="ri-smartphone-line"
            color="primary"
            lazy />
    </div>

    <div class="col-lg-4 col-md-6">
        <x-core::metric
            id="total-messages-in"
            variant="compact"
            title="Messages In"
            :value="$data['total_messages_in']->value"
            icon="ri-arrow-down-circle-line"
            color="success"
            lazy />
    </div>

    <div class="col-lg-4 col-md-6">
        <x-core::metric
            id="total-messages-out"
            variant="compact"
            title="Messages Out"
            :value="$data['total_messages_out']->value"
            icon="ri-arrow-up-circle-line"
            color="info"
            lazy />
    </div>
</div>

<div class="row">
    <div class="col-lg-4 col-md-6">
        <x-core::metric
            id="media-messages"
            variant="compact"
            title="Media Messages"
            :value="$data['media_messages']->value"
            icon="ri-image-line"
            color="warning"
            lazy />
    </div>

    <div class="col-lg-4 col-md-6">
        <x-core::metric
            id="whatsapp-wa-file"
            variant="compact"
            title="WhatsApp File"
            :value="$data['wa_file']->value"
            icon="ri-file-line"
            color="secondary"
            lazy />
    </div>

    <div class="col-lg-4 col-md-6">
        <x-core::metric
            id="whatsapp-wa-storage"
            variant="compact"
            title="WhatsApp Storage"
            :value="$data['wa_storage']->value"
            icon="ri-hard-drive-2-line"
            color="success"
            lazy />
    </div>
</div>

<div class="row">
    <div class="col-lg-4">
        <div class="d-flex flex-column gap-3" id="whatsapp-devices">
            @forelse ($data['devices'] as $device)
            <div class="whatsapp-device-item">
                @include('core::pages.admin-dashboard.sections.partials.whatsapp-device', ['device' => $device])
            </div>
            @empty
            <div class="text-center text-muted py-4">
                No WhatsApp device configured.
            </div>
            @endforelse
        </div>
    </div>

    <div class="col-lg-8">
        <x-core::card>
            <x-slot:header class="d-flex justify-content-between">
                <div class="fs-14 fw-medium">Message Volume (14 Days)</div>
                <x-core::refresh-button id="message-volume-refresh" size="sm" color="light" />
            </x-slot:header>

            <div id="message-volume-chart"></div>
        </x-core::card>
    </div>
</div>

@push('scripts')
    <script>
        const MESSAGE_VOLUME = {{ Js::from($data['message_volume']) }}
    </script>
@endpush
