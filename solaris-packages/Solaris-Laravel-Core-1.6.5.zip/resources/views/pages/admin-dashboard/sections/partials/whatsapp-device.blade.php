@php
    $quota = $device['quota'] ?? null;
    $packagePercent = $quota && ($quota['total'] ?? 0) > 0
        ? min(100, round(($quota['used'] / $quota['total']) * 100))
        : 0;
    $dailyPercent = $quota && ($quota['daily_limit'] ?? 0) > 0
        ? min(100, round(($device['daily_used'] / $quota['daily_limit']) * 100))
        : 0;
@endphp

<x-core::card class="mb-0">
    <div class="d-flex align-items-center justify-content-between mb-2">
        <div>
            <div class="fw-medium">{{ $device['name'] }}</div>
            <div class="fs-12 text-muted">{{ $device['phone_number'] ?? 'No active number' }}</div>
        </div>

        @if ($device['error'])
            <span class="badge bg-danger">Error</span>
        @elseif ($device['is_connected'])
            <span class="badge bg-success">Connected</span>
        @else
            <span class="badge bg-secondary">Disconnected</span>
        @endif
    </div>

    <div class="fs-12 text-muted mb-3">
        <i class="ri-chat-3-line me-1"></i>{{ $device['total_conversation'] }} conversations
    </div>

    @if ($quota)
        <div class="mb-2">
            <div class="d-flex justify-content-between fs-12 text-muted mb-1">
                <span>
                    <span class="badge bg-light text-dark border me-1">{{ $quota['package'] ?? '-' }}</span>
                    @if (!empty($quota['expires_at']))
                        until {{ \Illuminate\Support\Carbon::parse($quota['expires_at'])->format('d M Y') }}
                    @endif
                </span>
                <span>{{ number_format($quota['used'] ?? 0) }} / {{ number_format($quota['total'] ?? 0) }}</span>
            </div>
            <div class="progress" style="height: 6px;">
                <div class="progress-bar bg-{{ $packagePercent >= 90 ? 'danger' : ($packagePercent >= 70 ? 'warning' : 'primary') }}"
                     role="progressbar"
                     style="width: {{ $packagePercent }}%"></div>
            </div>
        </div>

        <div>
            <div class="d-flex justify-content-between fs-12 text-muted mb-1">
                <span>Daily Limit</span>
                <span>{{ number_format($device['daily_used'] ?? 0) }} / {{ number_format($quota['daily_limit'] ?? 0) }}</span>
            </div>
            <div class="progress" style="height: 6px;">
                <div class="progress-bar bg-warning" role="progressbar" style="width: {{ $dailyPercent }}%"></div>
            </div>
        </div>
    @endif
</x-core::card>
