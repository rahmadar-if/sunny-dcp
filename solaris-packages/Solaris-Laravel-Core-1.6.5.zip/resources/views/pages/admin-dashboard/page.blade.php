<x-core::page.base
    title="Admin Dashboard"
    :breadcrumbs="$breadcrumbs"
    package="core"
    path="admin-dashboard/index">

    <x-slot:buttons>
        <x-core::refresh-button id="refresh" />
    </x-slot:buttons>

    <x-core::tab id="dashboard-tab" style="background-color: transparent;">
        <x-slot:nav>
            <x-core::tab-nav id="dashboard-tab-users-sessions" active>Users & Sessions</x-core::tab-nav>
            <x-core::tab-nav id="dashboard-tab-storage">Storage</x-core::tab-nav>
            <x-core::tab-nav id="dashboard-tab-whatsapp">WhatsApp</x-core::tab-nav>
            <x-core::tab-nav id="dashboard-tab-approval">Approval</x-core::tab-nav>
            <x-core::tab-nav id="dashboard-tab-agent-ai">AI Agent Usage</x-core::tab-nav>
        </x-slot:nav>

        <x-slot:content>
            <x-core::tab-content id="dashboard-tab-users-sessions" active class="p-0 border-0">
                @include('core::pages.admin-dashboard.sections.users-sessions', ['data' => $data['users_sessions']])
            </x-core::tab-content>

            <x-core::tab-content id="dashboard-tab-storage" class="p-0 border-0">
                @include('core::pages.admin-dashboard.sections.storage', ['data' => $data['storage']])
            </x-core::tab-content>

            <x-core::tab-content id="dashboard-tab-whatsapp" class="p-0 border-0">
                @include('core::pages.admin-dashboard.sections.whatsapp', ['data' => $data['whatsapp']])
            </x-core::tab-content>

            <x-core::tab-content id="dashboard-tab-approval" class="p-0 border-0">
                @include('core::pages.admin-dashboard.sections.approval', ['data' => $data['approval']])
            </x-core::tab-content>

            <x-core::tab-content id="dashboard-tab-agent-ai" class="p-0 border-0">
                @include('core::pages.admin-dashboard.sections.agent-ai', ['data' => $data['agent_ai']])
            </x-core::tab-content>
        </x-slot:content>
    </x-core::tab>

</x-core::page.base>
