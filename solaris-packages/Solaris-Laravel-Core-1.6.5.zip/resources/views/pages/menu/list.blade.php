<x-core::page.base
    title="Menu Management"
    :breadcrumbs="$breadcrumbs"
    package="core"
    path="menu/list-index">

    @php
        $id = "menu-tree";
    @endphp

    <x-core::card>
        <div class="d-flex align-items-center justify-content-between mb-3">
            <div class="d-flex gap-2">
                <x-core::button id="{{ $id }}_add-menu" size="sm" disabled>
                    <span class="ri-add-fill me-1"></span>Add Menu
                </x-core::button>

                <x-core::button id="{{ $id }}_add-category" size="sm" color="secondary" disabled>
                    <span class="ri-add-fill me-1"></span>Add Category
                </x-core::button>

                <x-core::button id="{{ $id }}_expand-all" size="sm" color="info" disabled>
                    <span class="ri-arrow-down-double-line me-1"></span>Expand All
                </x-core::button>

                <x-core::button id="{{ $id }}_collapse-all" size="sm" color="info" disabled>
                    <span class="ri-arrow-up-double-fill me-1"></span>Collapse All
                </x-core::button>
            </div>

            <x-core::refresh-button id="{{ $id }}_refresh" disabled size="sm" color="light" />
        </div>

        <x-core::tree id="menu-tree" lazy />
    </x-core::card>

    @push("modal-content")
        @include("core::pages.menu.modal", ["id" => $id])
        <x-core::menu-assign-modal />
    @endpush

    @push('scripts')
        <script>
            const MENUS = {{ Js::from($menus) }};
        </script>
    @endpush

</x-core::page.base>