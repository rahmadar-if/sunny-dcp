<x-core::modal-form 
    id="{{ $id }}_modal" 
    title="Edit Menu" 
    size="md"
    model="Menu">
    
    <x-core::field id="{{ $id }}_modal_name:name" label="Name" required>
        <x-core::input placeholder="Menu name" />
    </x-core::field>
    
    <x-core::field id="{{ $id }}_modal_url:url" label="URL">
        <x-core::input placeholder="/path/to/page" />
    </x-core::field>
    
    <x-core::field id="{{ $id }}_modal_route:route_name" label="Route Name">
        <x-core::input placeholder="route.name" />
    </x-core::field>
    
    <x-core::field id="{{ $id }}_modal_icon:icon" label="Icon">
        <div class="input-group">
            <span class="input-group-text" id="{{ $id }}_modal_icon_preview">
                <i class="ri-menu-line"></i>
            </span>
            <x-core::input placeholder="ri-home-line" />
        </div>
    </x-core::field>

    <x-core::checkbox 
        id="{{ $id }}_modal_hide:is_hide" 
        label="Hidden from sidebar" 
    />
</x-core::modal-form>