<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ $title }}</title>
    @if ($favicon)
        <link rel="icon" href="{{ $favicon }}" type="image/x-icon">
    @endif
    <link rel="stylesheet" href="{{ $swaggerUi }}/swagger-ui.css">
    <style>
        body { margin: 0; background: #fafafa; }
        .swagger-ui .topbar { display: none; }
    </style>
</head>
<body>
    <div id="swagger-ui"></div>

    <script src="{{ $swaggerUi }}/swagger-ui-bundle.js"></script>
    <script>
        window.onload = () => {
            SwaggerUIBundle({
                url: @json($specUrl),
                dom_id: '#swagger-ui',
                deepLinking: true,
                persistAuthorization: true,
                docExpansion: 'list',
                defaultModelsExpandDepth: 0,
                // Empty for a method means no "Try it out" button on it.
                supportedSubmitMethods: @json($submitMethods),
            })
        }
    </script>
</body>
</html>
