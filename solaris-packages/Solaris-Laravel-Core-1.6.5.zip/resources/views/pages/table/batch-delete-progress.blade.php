<x-core::modal :id="$id" :close="false" size="md" static center ignore>
    <div class="d-flex gap-3 mb-4">
        <div class="flex-shrink-0">
            <div class="loading-icon bg-primary bg-opacity-10 rounded-circle d-flex align-items-center justify-content-center" style="width: 48px; height: 48px;">
                <div class="spinner-border text-primary spinner-border-sm" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
            </div>

            <div class="success-icon bg-success bg-opacity-10 rounded-circle d-flex align-items-center justify-content-center d-none" style="width: 48px; height: 48px;">
                <i class="bi bi-check-circle text-success fs-4"></i>
            </div>
        </div>
        <div class="flex-grow-1">
            <h5 class="modal-title mb-2">Deleting Records...</h5>
            <p class="modal-subtitle text-muted mb-0">Please wait while we process your request</p>
        </div>
    </div>

    <div class="mb-4">
        <div class="d-flex justify-content-between text-muted small mb-2">
            <span>Progress</span>
            <span class="batch-delete-percent">0%</span>
        </div>
        <div class="progress" style="height: 8px;">
            <div class="progress-bar bg-primary batch-delete-progress" role="progressbar" style="width: 0%"></div>
        </div>
    </div>

    <div class="row g-2 mb-3">
        <div class="col-4">
            <div class="bg-light rounded p-3 text-center">
                <div class="text-muted small mb-1">Estimated</div>
                <div class="fs-4 fw-semibold batch-delete-estimated">0</div>
            </div>
        </div>
        <div class="col-4">
            <div class="bg-success bg-opacity-10 rounded p-3 text-center">
                <div class="text-success small mb-1">Deleted</div>
                <div class="fs-4 fw-semibold text-success batch-delete-deleted">0</div>
            </div>
        </div>
        <div class="col-4">
            <div class="bg-danger bg-opacity-10 rounded p-3 text-center">
                <div class="text-danger small mb-1">Failed</div>
                <div class="fs-4 fw-semibold text-danger batch-delete-failed">0</div>
            </div>
        </div>
    </div>

    <div class="modal-message text-center text-muted small">
        <span>Do not close this window</span>
        <x-core::button data-bs-dismiss="modal" color="light" aria-label="Close" hidden>Close</x-core::button>
    </div>
</x-core::modal>