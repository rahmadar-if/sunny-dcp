<x-core::page.base title="Export log">
	<x-slot:buttons>
		@if (empty($data->error_message))
		<a href="{{ route('core.excel.export.download', ['id' => $data->id]) }}" class="btn btn-success btn-wave">Download File</a>
		@endif
		<x-core::cancel-button />
	</x-slot:buttons>

	<div class="card custom-card">
		<div class="card-body">

			<div class="row">
				<div class="col-md-6">
					<x-core::field label="Filename" id="filename" disabled>
						<x-core::input
							:value="$data->file_name"/>
					</x-core::field>

					<x-core::field label="Request at" id="request_at" disabled>
						<x-core::input
							:value="$data->created_at->format('d M Y H:i:s')"/>
					</x-core::field>

					<x-core::field label="Finished at" id="finished_at" disabled>
						<x-core::input
							:value="$data->finished_at->format('d M Y H:i:s')"/>
					</x-core::field>

					<x-core::field label="Export from" id="export_from" disabled>
						<x-core::input
							:value="str_replace('App\Models\\', '', $data->model)" />
					</x-core::field>

					<x-core::checkbox
						id="success"
						wrap:class="mb-3"
						label="Success"
						disabled
						:checked="empty($data->error_message)" />

					<x-core::checkbox
						id="error"
						label="Error"
						disabled
						:checked="!empty($data->error_message)" />
				</div>

				<div class="col-md-6">
					<x-core::field label="Total rows" id="total_rows" disabled>
						<x-core::input
							number
							:value="$data->total_rows"/>
					</x-core::field>

					@if (!empty($data->error_message))
					<x-core::field label="Error message" id="error_message" disabled>
						<x-core::textarea
							:value="$data->error_message" />
					</x-core::field>
					@endif
				</div>
			</div>

		</div>
	</div>
</x-core::page.base>
