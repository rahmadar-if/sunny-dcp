<x-core::modal :id="$id" body:class="p-3 p-lg-4" static center size="lg" ignore>
    <x-slot:header class="border-0">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </x-slot>

    <div class="text-center">
        <h5 class="mb-2">Download data file</h5>
    </div>

    <div class="p-lg-4 p-2">
        <div class="row">
            <div class="col-md-4">
                <x-core::field id="{{ $id }}_export_type" label="Export type" required ignore>
                    <x-core::radio-group 
                        name="type" 
                        :options="[
                            ['label' => 'Current table view', 'id' => $id.'_export_type_current', 'value' => 'current_view'],
                            ['label' => 'Custom columns', 'id' => $id.'_export_type_custom', 'value' => 'custom']
                        ]"
                    />
                </x-core::field>

                <x-core::field id="{{ $id }}_export_scope" label="Export scope" required ignore>
                    <x-core::radio-group 
                        name="scope" 
                        :options="[
                            ['label' => 'Current page only', 'id' => $id.'_export_scope_current_page', 'value' => 'current_page'],
                            ['label' => 'All matching rows', 'id' => $id.'_export_scope_all', 'value' => 'all']
                        ]"
                    />
                </x-core::field>

                <p id="{{ $id }}_total_rows"></p>
            </div>

            <div class="col-md-8 custom-columns d-none">
                <x-core::tab id="{{ $id }}_tabs" class="p-0 mb-4">
                    <x-slot:nav>
                        <x-core::tab-nav id="{{ $id }}_tabs_columns" active>Columns</x-core::tab-nav>
                        <x-core::tab-nav id="{{ $id }}_tabs_details">Details</x-core::tab-nav>
                    </x-slot>

                    <x-slot:content>
                        <x-core::tab-content id="{{ $id }}_tabs_columns" active class="p-0 border-0" style="max-height: 28rem; overflow-y: auto !important">
                        </x-core::tab-content>

                        <x-core::tab-content id="{{ $id }}_tabs_details" class="p-0 border-0" style="max-height: 28rem; overflow-y: auto !important">
                        </x-core::tab-content>
                    </x-slot:content>
                </x-core::tab>
            </div>
        </div>

        <div class="hstack gap-2 justify-content-center mt-4">
            <x-core::button id="{{ $id }}_export" ignore>Download</x-core::button>
            <x-core::button data-bs-dismiss="modal" color="light" aria-label="Close" ignore>Cancel</x-core::button>
        </div>
    </div>
</x-core::modal>