<x-core::page.base title="Import log">
	<x-slot:buttons>
		@if (!empty($data->error_file_path))
		<a href="{{ route('core.excel.import.log-download', ['id' => $data->id]) }}" class="btn btn-danger btn-wave">Download error logs</a>
		@endif
		<x-core::cancel-button />
	</x-slot:buttons>

	<div class="card custom-card">
		<div class="card-body">

			<div class="row">
				<div class="col-md-6">
					<x-core::field label="Filename" id="filename" disabled>
						<x-core::input
							:value="$data->file_name"/>
					</x-core::field>

					<x-core::field label="Upload at" id="upload_at" disabled>
						<x-core::input
							:value="$data->created_at->timezone(Auth::user()->profile->timezone ?? 'UTC')->format('d M Y H:i:s')"/>
					</x-core::field>

					<x-core::field label="Finished at" id="finished_at" disabled>
						<x-core::input
							:value="$data->finished_at"/>
					</x-core::field>

					<x-core::field label="Import to" id="import_to" disabled>
						<x-core::input
							:value="str_replace('App\Models\\', '', $data->model)" />
					</x-core::field>

					<x-core::checkbox
						id="success"
						wrap:class="mb-3"
						label="Success"
						disabled
						:checked="$data->success_count == $data->total_rows && empty($data->error_message)" />

					<x-core::checkbox
						id="error"
						label="Error"
						disabled
						:checked="$data->success_count != $data->total_rows || !empty($data->error_message)" />
				</div>

				<div class="col-md-6">
					<x-core::field label="Total rows" id="total_rows" disabled>
						<x-core::input
							id="total_rows"
							number
							:value="$data->total_rows"/>
					</x-core::field>

					<x-core::field label="Total success rows" id="success_count" disabled>
						<x-core::input
							number
							:value="$data->success_count"/>
					</x-core::field>

					<x-core::field label="Total error rows" id="error_count" disabled>
						<x-core::input
							number
							:value="$data->error_count"/>
					</x-core::field>

					<x-core::field label="Error message" id="error_message" disabled>
						<x-core::textarea
							:value="$data->error_message" />
					</x-core::field>
				</div>
			</div>

		</div>
	</div>
</x-core::page.base>
