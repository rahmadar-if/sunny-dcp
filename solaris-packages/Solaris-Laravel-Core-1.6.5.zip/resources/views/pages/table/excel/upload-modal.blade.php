<x-core::modal :id="$id" body:class="p-3 p-lg-4" static center size="xl" ignore>
    <x-slot:header class="border-0">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </x-slot>

    {{-- Step 1: Upload --}}
    <div class="import-step-1">
        <div class="p-lg-4 p-2">
            <div class="text-center">
                <h5 class="mb-4">Upload Data File</h5>
            </div>

            <p class="mb-2">Please upload a file using the provided template. Only .xlsx formats are supported. Make sure all required fields are filled in correctly.</p>

            <div id="{{ $id }}_upload" class="dropzone mb-3">
                <div class="fallback">
                    <input name="file" type="file" multiple="multiple">
                </div>
                <div class="dz-message needsclick">
                    <h6>Drop files here or click to upload.</h6>
                </div>
            </div>

            <div class="d-flex justify-content-between mt-3">
                <x-core::button id="{{ $id }}_template" color="secondary" ignore>
                    <i class="ri-download-line me-1"></i>Download Template
                </x-core::button>
                <div class="d-flex gap-2">
                    <x-core::button id="{{ $id }}_next" color="primary" class="d-none" ignore>
                        Map Columns<i class="ri-arrow-right-line ms-1"></i>
                    </x-core::button>
                    <x-core::button class="close-button" data-bs-dismiss="modal" color="light" aria-label="Close" ignore>Cancel</x-core::button>
                </div>
            </div>
        </div>
    </div>

    {{-- Step 2: Column Mapping --}}
    <div class="import-step-2 d-none">
        <div class="p-lg-4 p-2">
            <div class="text-center">
                <h5 class="mb-2">Map Your Columns</h5>
                <p id="{{ $id }}_mapping_info" class="text-muted mb-3"></p>
            </div>

            <div style="max-height: 22rem; overflow-y: auto;">
                <div id="{{ $id }}_mapping_list"></div>
            </div>

            <div class="d-flex justify-content-between mt-4">
                <x-core::button id="{{ $id }}_back" color="secondary" ignore>
                    <i class="ri-arrow-left-line me-1"></i>Back
                </x-core::button>
                <x-core::button id="{{ $id }}_proceed" color="primary" ignore>
                    Proceed to Import<i class="ri-arrow-right-line ms-1"></i>
                </x-core::button>
            </div>
        </div>
    </div>
</x-core::modal>
