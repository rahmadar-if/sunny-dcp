<x-core::modal-form 
    id="user-modal" 
    model="User" 
    title="User"
    size="md">
    
    <div class="row mb-4">
        <div class="d-flex justify-content-center">
            <x-core::profile-picture id="user-modal-profile_picture"/>
        </div>
    </div>

    <x-core::field id="user-modal-name:name" label="Name" required>
        <x-core::input 
            placeholder="Enter full name"/>
    </x-core::field>

    <x-core::field id="user-modal-email:email" label="Email" required>
        <x-core::input
            type="email" 
            placeholder="Enter email address"/>
    </x-core::field>

    <x-core::field id="user-modal-username:username" label="Username">
        <x-core::input 
            placeholder="Choose a username"/>
    </x-core::field>

    @php
        $passwordModes = [
            ["id" => "auto", "value" => "auto", "label" => "Generate password automatically", "checked" => true],
            ["id" => "manual", "value" => "manual", "label" => "Set password manually"]
        ];
    @endphp
    <x-core::radio-group 
        name="password_mode" 
        :options="$passwordModes"
        wrap:class="mb-3"/>

    <x-core::field id="password" label="Password" hidden>
        <x-core::password />
    </x-core::field>

    <x-core::field id="password_confirmation" label="Confirm Password" hidden>
        <x-core::password />
    </x-core::field>

    <x-core::checkbox id="skip_email_verification" label="Skip email verification"/>

</x-core::modal-form>