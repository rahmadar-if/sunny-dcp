<x-core::table
    id="user-sessions_list"
    class="table-hover"
    model="AuthSession@withMobileLastActive"
    export lazy
    :new="false"
    :select_all="false"
    filter="user_id = {{ $id }}"
    extend_columns="device_id,device_name,logged_out_at,terminated_at,last_active_at">

    <x-slot:column>
        <x-core::table-action-column :view="false" :edit="false" :delete="false" />

        <x-core::table-column
            cell_class="text-nowrap"
            data="channel"
            searchable
            orderable>
            Channel
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="user_agent"
            searchable
            orderable>
            Device / Browser
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="ip_address"
            searchable
            orderable>
            IP Address
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="logged_in_at"
            searchable
            orderable>
            Login At
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="last_active_at"
            searchable
            orderable>
            Last Active
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            name="status">
            Status
        </x-core::table-column>
    </x-slot>

</x-core::table>
