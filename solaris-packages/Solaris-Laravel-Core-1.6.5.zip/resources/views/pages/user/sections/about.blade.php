{{-- Personal --}}
<x-core::fieldset label="Personal" />

<div class="row mb-3">
    <div class="col-md-6">
        <x-core::field label="Name" id="name" disabled>
            <x-core::input :value="$data->name" />
        </x-core::field>

        <x-core::field label="Salutation" id="salutation_id" disabled>
            <x-core::lookup
                placeholder="Choose a proper salutation"
                :value="json_encode($data->salutation)"/>
        </x-core::field>

        <x-core::field label="Gender" id="gender_id" disabled>
            <x-core::radio-group
                name="gender_id"
                inline />
        </x-core::field>

        <div class="row">
            <div class="col-lg-6">
                <x-core::field label="Birthdate" id="birthdate" disabled>
                    <x-core::date-picker
                        placeholder="Pick birth date"
                        :value="$data->birthdate"/>
                </x-core::field>
            </div>

            <div class="col-lg-6">
                <x-core::field id="birthplace" label="Birthplace" disabled>
                    <x-core::input
                        placeholder="Where were you born?"
                        :value="$data->birthplace"/>
                </x-core::field>
            </div>
        </div>

        <x-core::field label="Religion" id="religion_id" disabled>
            <x-core::lookup
                placeholder="Choose religion or belief"
                :value="json_encode($data->religion)"/>
        </x-core::field>
    </div>

    {{-- Account & Contact --}}
    <div class="col-md-6">
        <x-core::field id="username" label="Username" disabled>
            <x-core::input :value="$data->user->username"/>
        </x-core::field>

        <x-core::field id="email" label="Email" disabled>
            <x-core::input :value="$data->email"/>
        </x-core::field>

        <x-core::field id="phone_number" label="Phone number" disabled>
            <x-core::input
                phone="ID"
                placeholder="Enter phone number"
                :value="$data->phone_number"/>
        </x-core::field>
    </div>
</div>

{{-- Address --}}
<x-core::fieldset label="Address" />

<x-core::field id="address" label="Address" disabled>
    <x-core::textarea placeholder="Enter detailed address" :value="$data->address" rows="3"/>
</x-core::field>

<div class="row">
    <div class="col-md-6">
        <x-core::field label="Country" id="country_id" disabled>
            <x-core::lookup
                placeholder="Choose country"
                :value="json_encode($data->country)"/>
        </x-core::field>

        <x-core::field label="Province" id="province_id" disabled>
            <x-core::lookup
                placeholder="Choose province"
                :value="json_encode($data->province)"/>
        </x-core::field>

        <x-core::field label="City" id="city_id" disabled>
            <x-core::lookup
                placeholder="Choose city"
                :value="json_encode($data->city)"/>
        </x-core::field>
    </div>

    <div class="col-md-6">
        <x-core::field label="District" id="district_id" disabled>
            <x-core::lookup
                placeholder="Choose district"
                :value="json_encode($data->district)"/>
        </x-core::field>

        <x-core::field label="Sub district" id="sub_district_id" disabled>
            <x-core::lookup
                placeholder="Choose sub district"
                :value="json_encode($data->sub_district)"/>
        </x-core::field>

        <x-core::field id="postcode" label="Postcode" disabled>
            <x-core::input numeric blocks="10" placeholder="Enter postcode" :value="$data->postcode"/>
        </x-core::field>
    </div>
</div>
