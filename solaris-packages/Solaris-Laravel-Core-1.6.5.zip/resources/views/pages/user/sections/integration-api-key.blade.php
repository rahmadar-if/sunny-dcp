<div class="mb-2">
    <p class="fs-13 fw-semibold mb-1">API Keys</p>
    <p class="fs-11 text-muted mb-0">Max 2 active — rotate before revoking the last one</p>
</div>

<x-core::table
    id="api-key_list"
    class="table-hover"
    model="ApiKey"
    :card_wrapper="false"
    new="Generate Key@generate-key-modal"
    :search="false"
    :select_all="false"
    order_by="created_at:desc"
    filter="user_id = {{ $id }}" lazy>

    <x-slot:column>
        <x-core::table-action-column :view="false" :edit="false" :delete="false" />

        <x-core::table-column
            cell_class="text-nowrap"
            data="name">
            Name
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="rate_limit">
            Tier
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="last_used_at"
            type="datetime">
            Last used
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="created_at"
            type="datetime"
            orderable>
            Created
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="revoked_at"
            type="datetime"
            orderable>
            Revoked at
        </x-core::table-column>
    </x-slot:column>

</x-core::table>

@push('modal-content')
    <x-core::modal-form
        id="generate-key-modal"
        title="Generate API Key"
        size="md"
        method="POST"
        :action="route('admin.user.api-key.store', ['id' => $id])"
        save="Generate">

        <x-core::field id="name" label="Key name" required>
            <x-core::input placeholder="e.g. CRM Sync — primary" />
        </x-core::field>

    </x-core::modal-form>
@endpush
