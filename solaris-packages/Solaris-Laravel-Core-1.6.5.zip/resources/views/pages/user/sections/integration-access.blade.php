@php
    $accessRoles = $data->roles->where('group_name', 'integration');
    $accessPermissions = $data->getPermissions()->where('group_name', 'integration');
@endphp

<div class="d-flex align-items-start justify-content-between gap-3 mb-4" id="integration-access">
    <div>
        <p class="fs-13 fw-semibold mb-1">Access</p>
        <p class="fs-11 text-muted mb-2">Role &amp; permission, scoped to Integration only</p>

        <div class="d-flex flex-wrap gap-1" id="integration-access-badges">
            @forelse ($accessRoles as $role)
                <span class="badge bg-primary">{{ $role->name }}</span>
            @empty
            @endforelse

            @forelse ($accessPermissions as $permission)
                <span class="badge bg-light text-muted border">{{ $permission->name }}</span>
            @empty
            @endforelse

            @if ($accessRoles->isEmpty() && $accessPermissions->isEmpty())
                <span class="badge bg-danger">None</span>
            @endif
        </div>
    </div>

    <button type="button" class="btn btn-outline-primary btn-sm text-nowrap" id="btn-assign-access">
        <i class="ri-user-settings-line me-1"></i>Assign Access
    </button>
</div>

<hr class="my-4">
