<x-core::table
    id="audit-log_list"
    class="table-hover"
    model="ApiRequestLog@withApiKey"
    :new="false"
    :select_all="false"
    :search="true"
    :card_wrapper="false"
    order_by="created_at:desc"
    filter="user_id = {{ $id }}" lazy>

    <x-slot:column>
        <x-core::table-action-column :view="true" :edit="false" :delete="false" />

        <x-core::table-column
            cell_class="text-nowrap"
            data="created_at"
            type="datetime"
            format="dd MMM yyyy hh:mm:ss A"
            orderable>
            Time
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="method">
            Method
        </x-core::table-column>

        <x-core::table-column
            data="path"
            searchable>
            Endpoint
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="status">
            Status
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            name="api_key">
            Key
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="ip_address">
            IP
        </x-core::table-column>
    </x-slot>

</x-core::table>

@push('modal-content')
    <x-core::modal
        id="audit-log-detail-modal"
        title="Request Detail"
        size="lg"
        dialog:class="modal-dialog-scrollable"
        center>
        <div id="audit-log-detail-body"></div>
    </x-core::modal>
@endpush
