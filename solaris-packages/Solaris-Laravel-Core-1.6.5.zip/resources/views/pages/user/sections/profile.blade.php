<div class="card custom-card overflow-hidden border">

    {{-- Avatar + name --}}
    <div class="card-body border-bottom border-block-end-dashed">
        <div class="text-center">
            <x-core::profile-picture
                id="profile-picture"
                class="mb-3"
                :source="$data->user->profile_picture_id"
                :preview_width="$data->user->profile_picture?->image_width"
                :preview_height="$data->user->profile_picture?->image_height"
                :view_only="true" />

            <h5 class="fw-medium mb-1" id="name-display">{{ $data->name }}</h5>
            <span class="d-block fw-medium text-muted mb-2">{{ $data->email }}</span>
        </div>
    </div>

    {{-- Roles + verified at + mobile access --}}
    <div class="card-body border-bottom border-block-end-dashed p-0">
        <ul class="list-group list-group-flush">

            @php
                // Identity roles mirror the user list's Role column: the row's own kind only.
                // Null group_name (pre-migration role, not yet tagged) falls back to "user".
                $identityRoles = $data->user->is_integration
                    ? $data->roles->where('group_name', 'integration')
                    : $data->roles->whereIn('group_name', ['user', null]);
                $aiRoles = $data->roles->where('group_name', 'ai');
            @endphp

            <li class="list-group-item pt-2 border-0">
                <div class="d-flex align-items-center gap-2">
                    <i class="ri-organization-chart fs-22" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Role"></i>
                    <div class="d-flex align-items-center gap-1" id="roles-display">
                        @forelse ($identityRoles->take(2) as $role)
                            <span class="badge bg-{{ $role->name == 'Admin' ? 'success' : 'info'}}">{{ $role->name }}</span>
                        @empty
                            <span class="badge bg-danger">None</span>
                        @endforelse
                        @if ($identityRoles->count() > 2)
                            <span class="badge bg-secondary" role="button" id="roles-more-badge">{{ $identityRoles->count() - 2 }}+</span>
                        @endif
                    </div>
                </div>
            </li>

            <li class="list-group-item pt-2 border-0">
                <div class="d-flex align-items-center gap-2">
                    <i class="ri-robot-line fs-22" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="AI Access"></i>
                    <div class="d-flex align-items-center gap-1" id="ai-roles-display">
                        @forelse ($aiRoles->take(2) as $role)
                            <span class="badge bg-info">{{ $role->name }}</span>
                        @empty
                            <span class="badge bg-danger">None</span>
                        @endforelse
                        @if ($aiRoles->count() > 2)
                            <span class="badge bg-secondary" role="button" id="ai-roles-more-badge">{{ $aiRoles->count() - 2 }}+</span>
                        @endif
                    </div>
                </div>
            </li>

            <li class="list-group-item pt-2 border-0">
                <div class="d-flex align-items-center gap-2">
                    <i class="ri-verified-badge-line fs-22" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Verified at"></i>
                    <div class="d-flex flex-column gap-1">
                        <span class="fw-medium text-muted">{{ $data->user->email_verified_at?->localized() ?? "-" }}</span>
                    </div>
                </div>
            </li>

            <li class="list-group-item pt-2 border-0">
                <div class="d-flex align-items-center gap-2">
                    <i class="ri-smartphone-line fs-22" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Mobile Access"></i>
                    <span id="mobile-access-badge" class="badge {{ $data->user->is_mobile_access ? 'bg-success' : 'bg-danger' }}">
                        {{ $data->user->is_mobile_access ? 'Allowed' : 'Denied' }}
                    </span>
                </div>
            </li>

            <li class="list-group-item pt-2 border-0">
                <div class="d-flex align-items-center gap-2">
                    <i class="ri-whatsapp-line fs-22" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="WhatsApp AI"></i>
                    <span class="badge {{ $data->user->whatsapp_enabled ? 'bg-success' : 'bg-danger' }}">
                        {{ $data->user->whatsapp_enabled ? 'Allowed' : 'Denied' }}
                    </span>
                </div>
            </li>

        </ul>
    </div>

    {{-- Storage usage --}}
    @php
        $maxSize      = SolarHelper::config('attachment.max_size', 5 * 1024 * 1024 * 1024);
        $usedBytes    = $data->total_uploaded_size_raw;
        $percentage   = $maxSize > 0 ? min(100, round(($usedBytes / $maxSize) * 100, 2)) : 0;
        $barColor     = $percentage >= 90 ? 'danger' : ($percentage >= 70 ? 'warning' : 'success');
        $maxFormatted = \Solaris\Core\Helpers\Number::getHumanReadableSize($maxSize);
    @endphp

    <div class="card-body"
            id="storage-info"
            data-max-size="{{ $maxSize }}"
            data-max-formatted="{{ $maxFormatted }}">
        <div class="d-flex align-items-center justify-content-between mb-2">
            <div class="d-flex align-items-center gap-2">
                <i class="ri-hard-drive-2-line fs-16 text-muted"></i>
                <span class="fs-13 fw-medium">Storage</span>
            </div>
            <span class="fs-12 text-muted" id="file-size-display">{{ $data->total_uploaded_size }} / {{ $maxFormatted }}</span>
        </div>
        <div class="progress mb-2" style="height: 5px;">
            <div class="progress-bar bg-{{ $barColor }}"
                    id="storage-progress-bar"
                    role="progressbar"
                    style="width: {{ $percentage }}%"
                    aria-valuenow="{{ $percentage }}"
                    aria-valuemin="0"
                    aria-valuemax="100"></div>
        </div>
        <div class="d-flex justify-content-between">
            <span class="fs-12 text-muted" id="file-count-display">{{ $data->total_file }} files</span>
            <span class="fs-12 text-muted" id="storage-percentage">{{ $percentage }}% used</span>
        </div>
    </div>

</div>

@php
    $googleEmail = $data->sso['google'] ?? null;
    $is2fa       = !is_null($data->user->two_factor_confirmed_at);
    $method2fa   = $data->user->two_factor_method;
    $since2fa    = $data->user->two_factor_confirmed_at?->format('d M Y');
@endphp

<div class="card custom-card overflow-hidden border mt-3">
    <div class="card-body p-0">

        {{-- Notifications --}}
        <div class="p-3 border-bottom border-block-end-dashed">
            <p class="fs-11 fw-semibold text-muted text-uppercase mb-2">Notifications</p>
            <div class="d-flex flex-column gap-2">

                <div class="d-flex justify-content-between align-items-center">
                    <span class="fs-13 fw-medium">In-App</span>
                    <span id="notif-badge-app" class="badge {{ $data->user->is_app_notification ? 'bg-success' : 'bg-danger' }}">
                        {{ $data->user->is_app_notification ? 'On' : 'Off' }}
                    </span>
                </div>

                <div class="d-flex justify-content-between align-items-center">
                    <span class="fs-13 fw-medium">Push</span>
                    <span id="notif-badge-push" class="badge {{ $data->user->is_push_notification ? 'bg-success' : 'bg-danger' }}">
                        {{ $data->user->is_push_notification ? 'On' : 'Off' }}
                    </span>
                </div>

                <div class="d-flex justify-content-between align-items-center">
                    <span class="fs-13 fw-medium">Mobile</span>
                    <span id="notif-badge-mobile" class="badge {{ $data->user->is_mobile_notification ? 'bg-success' : 'bg-danger' }}">
                        {{ $data->user->is_mobile_notification ? 'On' : 'Off' }}
                    </span>
                </div>

                <div class="d-flex justify-content-between align-items-center">
                    <span class="fs-13 fw-medium">Email</span>
                    <span id="notif-badge-email" class="badge {{ $data->user->is_email_notification ? 'bg-success' : 'bg-danger' }}">
                        {{ $data->user->is_email_notification ? 'On' : 'Off' }}
                    </span>
                </div>

            </div>
        </div>

        {{-- Two-Factor Authentication --}}
        <div class="p-3 border-bottom border-block-end-dashed">
            <p class="fs-11 fw-semibold text-muted text-uppercase mb-2">Two-Factor Auth</p>
            <div class="d-flex flex-wrap gap-1 mb-1">
                <span id="2fa-badge-active" class="badge bg-success {{ !$is2fa ? 'd-none' : '' }}">Active</span>
                <span id="2fa-badge-method" class="badge bg-info {{ !$is2fa ? 'd-none' : '' }}">
                    {{ $method2fa === 'totp' ? 'Authenticator App' : 'Email OTP' }}
                </span>
                <span id="2fa-badge-inactive" class="badge bg-danger {{ $is2fa ? 'd-none' : '' }}">Inactive</span>
            </div>
            <p id="2fa-since" class="fs-11 text-muted mb-0 {{ (!$is2fa || !$since2fa) ? 'd-none' : '' }}">Since {{ $since2fa }}</p>
        </div>

        {{-- Single Sign On --}}
        <div class="p-3">
            <p class="fs-11 fw-semibold text-muted text-uppercase mb-2">Single Sign On</p>
            <div class="d-flex flex-column gap-3">

                {{-- Google --}}
                <div class="d-flex align-items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" class="flex-shrink-0">
                        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/>
                        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                    </svg>
                    <div class="flex-grow-1 overflow-hidden">
                        <p class="fs-13 fw-medium mb-0">Google</p>
                        <p id="sso-google-email" class="fs-11 text-muted mb-0 text-truncate">{{ $googleEmail ?? 'Not connected' }}</p>
                    </div>
                    <span id="sso-google-badge" class="badge bg-success flex-shrink-0 {{ !$googleEmail ? 'd-none' : '' }}">On</span>
                </div>

                {{-- LinkedIn --}}
                <div class="d-flex align-items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" fill="#0A66C2" class="flex-shrink-0">
                        <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                    </svg>
                    <div class="flex-grow-1">
                        <p class="fs-13 fw-medium mb-0">LinkedIn</p>
                        <p class="fs-11 text-muted mb-0">Coming soon</p>
                    </div>
                </div>

                {{-- Microsoft --}}
                <div class="d-flex align-items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 23 23" width="16" height="16" class="flex-shrink-0">
                        <path fill="#f35325" d="M1 1h10v10H1z"/>
                        <path fill="#81bc06" d="M12 1h10v10H12z"/>
                        <path fill="#05a6f0" d="M1 12h10v10H1z"/>
                        <path fill="#ffba08" d="M12 12h10v10H12z"/>
                    </svg>
                    <div class="flex-grow-1">
                        <p class="fs-13 fw-medium mb-0">Microsoft</p>
                        <p class="fs-11 text-muted mb-0">Coming soon</p>
                    </div>
                </div>

            </div>
        </div>

    </div>
</div>

@push('modal-content')
    <x-core::modal id="roles-modal" title="Role" size="sm" center>
        <div class="table-responsive">
            <table class="table table-sm mb-0">
                <thead>
                    <tr><th>Role</th></tr>
                </thead>
                <tbody id="roles-modal-body">
                    @foreach ($identityRoles as $role)
                        <tr>
                            <td><span class="badge bg-{{ $role->name == 'Admin' ? 'success' : 'info' }}">{{ $role->name }}</span></td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </x-core::modal>

    <x-core::modal id="ai-roles-modal" title="AI Access" size="sm" center>
        <div class="table-responsive">
            <table class="table table-sm mb-0">
                <thead>
                    <tr><th>Role</th></tr>
                </thead>
                <tbody id="ai-roles-modal-body">
                    @foreach ($aiRoles as $role)
                        <tr>
                            <td><span class="badge bg-info">{{ $role->name }}</span></td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </x-core::modal>
@endpush
