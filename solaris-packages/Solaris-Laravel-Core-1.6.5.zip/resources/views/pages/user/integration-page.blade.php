<x-core::page.edit
    :id="$data->id"
    title="Integration Account"
    :breadcrumbs="$breadcrumbs"
    model="User"
    :save="false"
    profile-position="left"
    package="core"
    path="user/integration-page-index">

    <x-slot:profile>
        <div class="card custom-card overflow-hidden border" id="integration-identity" data-user-id="{{ $data->id }}">
            <div class="card-body border-bottom border-block-end-dashed">
                <div class="text-center">
                    <span class="avatar avatar-xl avatar-rounded bg-primary-transparent mb-3 mx-auto">
                        <i class="ri-plug-line fs-24"></i>
                    </span>

                    <h5 class="fw-medium mb-1" id="name-display">{{ $data->name }}</h5>
                    <span class="d-block fw-medium text-muted mb-2">{{ $data->email }}</span>
                    <span class="badge bg-primary-transparent">Integration Account</span>
                </div>
            </div>

            <ul class="list-group list-group-flush border-bottom border-block-end-dashed">
                <li class="list-group-item pt-2 border-0">
                    <div class="d-flex align-items-center gap-2">
                        <i class="ri-verified-badge-line fs-22" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Verified at"></i>
                        <span class="fw-medium text-muted">{{ $data->email_verified_at?->localized() ?? "-" }}</span>
                    </div>
                </li>
            </ul>

            @php
                $maxSize      = SolarHelper::config('attachment.max_size', 5 * 1024 * 1024 * 1024);
                $usedBytes    = $data->total_uploaded_size_raw;
                $percentage   = $maxSize > 0 ? min(100, round(($usedBytes / $maxSize) * 100, 2)) : 0;
                $barColor     = $percentage >= 90 ? 'danger' : ($percentage >= 70 ? 'warning' : 'success');
                $maxFormatted = \Solaris\Core\Helpers\Number::getHumanReadableSize($maxSize);
            @endphp

            <div class="card-body"
                    id="storage-info"
                    data-max-size="{{ $maxSize }}"
                    data-max-formatted="{{ $maxFormatted }}">
                <div class="d-flex align-items-center justify-content-between mb-2">
                    <div class="d-flex align-items-center gap-2">
                        <i class="ri-hard-drive-2-line fs-16 text-muted"></i>
                        <span class="fs-13 fw-medium">Storage</span>
                    </div>
                    <span class="fs-12 text-muted" id="file-size-display">{{ $data->total_uploaded_size }} / {{ $maxFormatted }}</span>
                </div>
                <div class="progress mb-2" style="height: 5px;">
                    <div class="progress-bar bg-{{ $barColor }}"
                            id="storage-progress-bar"
                            role="progressbar"
                            style="width: {{ $percentage }}%"
                            aria-valuenow="{{ $percentage }}"
                            aria-valuemin="0"
                            aria-valuemax="100"></div>
                </div>
                <div class="d-flex justify-content-between">
                    <span class="fs-12 text-muted" id="file-count-display">{{ $data->total_file }} files</span>
                    <span class="fs-12 text-muted" id="storage-percentage">{{ $percentage }}% used</span>
                </div>
            </div>
        </div>
    </x-slot:profile>

    <x-core::tab id="tabs" class="p-0 mb-4" variant="tab-style-7">
        <x-slot:nav>
            <x-core::tab-nav id="tabs_api_key" active>API Key</x-core::tab-nav>
            <x-core::tab-nav id="tabs_audit_log">Audit Log</x-core::tab-nav>
        </x-slot>

        <x-slot:content>
            <x-core::tab-content id="tabs_api_key" active class="p-0 border-0">
                @include('core::pages.user.sections.integration-access', ['data' => $data])
                @include('core::pages.user.sections.integration-api-key', ['id' => $data->id])
            </x-core::tab-content>

            <x-core::tab-content id="tabs_audit_log" class="p-0 border-0">
                @include('core::pages.user.sections.integration-audit-log', ['id' => $data->id])
            </x-core::tab-content>
        </x-slot>
    </x-core::tab>

    @push('modal-content')
        <x-core::integration-assign-modal />
    @endpush

</x-core::page.edit>
