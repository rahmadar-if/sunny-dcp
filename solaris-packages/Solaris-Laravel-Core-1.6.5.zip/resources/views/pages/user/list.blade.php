<x-core::page.list
    id="user"
    title="User"
    class="table-hover"
    :breadcrumbs="$breadcrumbs"
    model="User@datatable"
    package="core"
    path="user/list-index"
    new="@user-modal"
    extend_columns="is_integration,profile_picture"
    export lazy>

    <x-slot:table-column>
        <x-core::table-action-column :edit="false"/>

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="name" 
            searchable 
            orderable>
            Name
        </x-core::table-column>

        <x-core::table-column
            width="20%"
            data="email" 
            searchable>
            Email / Username
        </x-core::table-column>
        
        <x-core::table-column class="d-none"
            data="username" 
            searchable>
        </x-core::table-column>
        
        <x-core::table-column
            width="15%" 
            name="role">
            Role
        </x-core::table-column>

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="email_verified_at" 
            searchable 
            orderable>
            Verified
        </x-core::table-column>

        <x-core::table-column 
            data="is_active" 
            width="5%" 
            orderable
            type="bool"
            format="badge:success|danger@Active|Nonactive">
            Status
        </x-core::table-column>

        <x-core::table-column 
            data="is_mobile_access"  
            width="5%"
            orderable
            type="bool"
            format="badge:success|danger@Allowed|Denied">
            Mobile Access
        </x-core::table-column>

        <x-core::table-column
            data="whatsapp_enabled"
            width="5%"
            orderable
            type="bool"
            format="badge:success|danger@Allowed|Denied">
            WhatsApp AI
        </x-core::table-column>

        <x-core::table-column
            width="15%"
            name="ai_access">
            AI Access
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"   
            name="total_attachment">
            Uploaded file
        </x-core::table-column>
    </x-slot>

    @push('modal-content')
        @include("core::pages.user.modal")
        <x-core::user-assign-modal />
        <x-core::ai-assign-modal />
        <x-core::integration-assign-modal />

        <x-core::modal
            id="user-role-modal"
            title="Role"
            dialog:class="modal-dialog-scrollable"
            size="sm"
            center>
            <div class="table-responsive">
                <table class="table table-sm mb-0">
                    <tbody id="user-role-modal-body"></tbody>
                </table>
            </div>
        </x-core::modal>

        <x-core::modal
            id="user-ai-role-modal"
            title="AI Access"
            dialog:class="modal-dialog-scrollable"
            size="sm"
            center>
            <div class="table-responsive">
                <table class="table table-sm mb-0">
                    <tbody id="user-ai-role-modal-body"></tbody>
                </table>
            </div>
        </x-core::modal>
    @endpush

</x-core::page.list>