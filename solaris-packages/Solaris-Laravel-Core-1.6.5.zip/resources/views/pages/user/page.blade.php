<x-core::page.edit
    :id="$data->user_id"
    title="Profile"
    :breadcrumbs="$breadcrumbs"
    model="Profile:User"
    :save="false"
    package="core"
    path="user/page-index">

    <div class="row">

        <div class="col">
            <div class="card custom-card profile-card">
                <x-core::profile-banner
                    id="profile-banner"
                    :source="$data->banner_id"
                    :preview_width="$data->banner?->image_width"
                    :preview_height="$data->banner?->image_height"
                    :view_only="true" />
                <div class="card-body pb-0 position-relative">
                    <div class="row profile-content">

                        {{-- Left sidebar --}}
                        <div class="col-xxl-3 col-xl-4">
                            @include('core::pages.user.sections.profile', ['data' => $data])
                        </div>

                        {{-- Right content --}}
                        <div class="col-xxl-9 col-xl-8">
                            <div class="card custom-card overflow-hidden border">
                                <div class="card-body">
                                    <x-core::tab id="tabs" class="p-0 mb-4" variant="tab-style-7">
                                        <x-slot:nav>
                                            <x-core::tab-nav id="tabs_about" active>About</x-core::tab-nav>
                                            <x-core::tab-nav id="tabs_session">Session</x-core::tab-nav>
                                        </x-slot>

                                        <x-slot:content>
                                            <x-core::tab-content id="tabs_about" active class="p-0 border-0">
                                                @include('core::pages.user.sections.about', ['data' => $data])
                                            </x-core::tab-content>

                                            <x-core::tab-content id="tabs_session" class="p-0 border-0">
                                                @include('core::pages.user.sections.session', ["id" => $data->user->id])
                                            </x-core::tab-content>
                                        </x-slot>
                                    </x-core::tab>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div>


</x-core::page.edit>
