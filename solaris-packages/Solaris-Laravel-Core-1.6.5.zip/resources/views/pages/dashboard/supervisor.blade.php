@extends('core::layouts.main')

@section('title', 'Dashboard')
@section('page-title', 'Hey, Supervisor👋')
@section('page-subtitle', 'Manage users, setups, and configs with real-time insights.')
@section('top-buttons')
    <x-core::period-filter id="period-filter" />
    <x-core::refresh-button id="dashboard-refresh" />
@endsection
@section('content')

@endsection

@push('scripts')
@endpush