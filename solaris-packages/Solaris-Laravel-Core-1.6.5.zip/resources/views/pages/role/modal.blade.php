<x-core::modal-form 
    id="role-modal" 
    model="Role" 
    title="Role"
    size="md">

    <x-core::field id="role-modal-name:name" label="Name" required>
        <x-core::input
            placeholder="Enter role name"/>
    </x-core::field>

    {{-- Indicator only. The submitted value comes from the active group filter, injected in list.js --}}
    <x-core::field id="role-modal-group_name:group_name" label="Group">
        <x-core::input readonly />
    </x-core::field>

    <x-core::field id="role-modal-description:description" label="Description">
        <x-core::textarea  
            placeholder="Enter role description"/>
    </x-core::field>

</x-core::modal-form>