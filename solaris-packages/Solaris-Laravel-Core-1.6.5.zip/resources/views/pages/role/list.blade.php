<x-core::page.list
    id="role"
    title="Role"
    class="table-hover"
    :breadcrumbs="$breadcrumbs"
    model="Role@datatable"
    package="core"
    path="role/list-index"
    new="@role-modal" lazy>

    <x-slot:table-pre-right-action>
        <div class="btn-group btn-group-sm" role="group">
            <input type="radio" class="btn-check" name="filter-group" id="filter-group-user" value="user">
            <label class="btn btn-outline-primary" for="filter-group-user">User</label>

            <input type="radio" class="btn-check" name="filter-group" id="filter-group-ai" value="ai">
            <label class="btn btn-outline-primary" for="filter-group-ai">AI</label>

            <input type="radio" class="btn-check" name="filter-group" id="filter-group-integration" value="integration">
            <label class="btn btn-outline-primary" for="filter-group-integration">Integration</label>
        </div>
    </x-slot>

    <x-slot:table-column>
        <x-core::table-action-column :view="false"/>

        <x-core::table-column
            cell_class="text-nowrap"
            data="name"
            width="25%"
            searchable
            orderable>
            Name
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="group_name"
            width="15%"
            orderable>
            Group
        </x-core::table-column>

        <x-core::table-column
            width="25%"
            name="permission">
            Permission
        </x-core::table-column>

        <x-core::table-column  
            data="description" 
            searchable 
            orderable>
            Description
        </x-core::table-column>
    </x-slot>

    @push('modal-content')
        @include("core::pages.role.modal")

        <x-core::role-assign-modal />

        <x-core::modal
            id="role-permission-modal"
            title="Permission"
            dialog:class="modal-dialog-scrollable"
            size="sm"
            center>
            <div class="table-responsive">
                <table class="table table-sm mb-0">
                    <tbody id="role-permission-modal-body"></tbody>
                </table>
            </div>
        </x-core::modal>
    @endpush

</x-core::page.list>