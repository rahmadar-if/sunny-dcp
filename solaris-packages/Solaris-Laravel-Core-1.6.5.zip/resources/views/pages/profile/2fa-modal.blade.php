<x-core::modal-form
    id="two-factor-setup-modal"
    size="lg"
    :save="false"
    :cancel="false">

    <x-slot:header class="border-0">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </x-slot>

    <div class="text-center mb-3">
        <h4 class="mb-1" id="twofa-modal-title">Enable Two-Factor Authentication</h4>
    </div>

    <div class="p-lg-4 p-2">

        {{-- Section 1: Stage Indicator --}}
        <x-core::stage-buttons id="twofa-steps" :stages="[
            ['id' => 'confirm', 'name' => 'Confirm', 'color' => 'primary', 'disabled' => true],
            ['id' => 'method',  'name' => 'Method',  'color' => 'primary', 'disabled' => true],
            ['id' => 'verify',  'name' => 'Verify',  'color' => 'primary', 'disabled' => true],
            ['id' => 'backup',  'name' => 'Backup',  'color' => 'success', 'disabled' => true],
        ]" class="mb-4" />

        {{-- Section 2: Dynamic Form Content --}}

        {{-- Step 1: Confirm Password --}}
        <x-core::field id="twofa-password" label="Current password" hidden required>
            <x-core::password />
        </x-core::field>

        {{-- Step 2: Choose Method --}}
        <x-core::field id="twofa-method" hidden>
            <x-core::radio-card-group name="twofa-method" :options="[
                ['value' => 'totp',  'icon' => 'ri-smartphone-line', 'label' => 'Authenticator App', 'description' => 'Use Google Authenticator, Authy, or any TOTP-compatible app. Works offline and is the most secure option.'],
                ['value' => 'email', 'icon' => 'ri-mail-line',       'label' => 'Email OTP',          'description' => 'Receive a one-time code to your registered email address each time you log in.', 'color' => 'info'],
            ]" />
        </x-core::field>

        {{-- Step 3a: TOTP Setup --}}
        <div id="twofa-step-totp" class="d-none">

            <p class="fs-13 text-muted mb-3">Scan this QR code with your authenticator app, then enter the 6-digit code to confirm.</p>

            <div class="d-flex justify-content-center mb-3">
                <div id="twofa-totp-qr" class="border rounded-3 p-2 bg-white d-inline-flex" style="line-height: 0;"></div>
            </div>

            <div class="text-center mb-4">
                <p class="fs-12 text-muted mb-1">Can't scan? Enter this key manually:</p>
                <code id="twofa-totp-manual-key" class="fs-13 text-primary fw-semibold letter-spacing-1"></code>
            </div>

            <x-core::otp-input id="twofa-totp-otp-input" />

        </div>

        {{-- Step 3b: Email OTP --}}
        <div id="twofa-step-email" class="d-none">

            <div class="text-center mb-4">
                <div class="avatar avatar-xl bg-info-transparent rounded-circle d-inline-flex align-items-center justify-content-center mb-3">
                    <i class="ri-mail-send-line fs-24 text-info"></i>
                </div>
                <p class="fs-14 mb-1 text-muted">We sent a code to</p>
                <p class="fs-15 fw-semibold mb-0" id="twofa-email-masked"></p>
            </div>

            <x-core::otp-input id="twofa-email-otp-input" resend-url="{{ route('core.two-factor.setup.email') }}" class="mb-3" />

        </div>

        {{-- Step 4: Backup Codes --}}
        <div id="twofa-step-backup" class="d-none">

            <div class="alert alert-solid-warning d-flex align-items-center gap-2 mb-4">
                <i class="ri-error-warning-line fs-16 flex-shrink-0"></i>
                <span class="fs-13">Save these codes now. They cannot be shown again. Each code can only be used once.</span>
            </div>

            <div class="row g-2 mb-4" id="twofa-backup-codes-grid"></div>

            <div class="d-flex gap-2 mb-4">
                <x-core::button id="twofa-download-codes" variant="outline" size="sm" color="secondary" class="flex-grow-1">
                    <i class="ri-download-line me-1"></i>Download .txt
                </x-core::button>
                <x-core::button id="twofa-copy-codes" variant="outline" size="sm" color="secondary" class="flex-grow-1">
                    <i class="ri-file-copy-line me-1"></i>Copy All
                </x-core::button>
            </div>

        </div>

        {{-- Section 3: Action Buttons --}}
        <div class="d-flex align-items-center mt-4">
            <x-core::button id="twofa-btn-prev" size="sm" variant="outline" color="secondary" hidden>
                <i class="ri-arrow-left-line me-1"></i>Back
            </x-core::button>
            <div class="ms-auto d-flex gap-2">
                <x-core::button size="sm" color="light" data-bs-dismiss="modal">Cancel</x-core::button>
                <x-core::button id="twofa-btn-next" size="sm">Continue</x-core::button>
            </div>
        </div>

    </div>

</x-core::modal>
