<x-core::modal-form
    id="disable-two-factor-modal"
    size="lg"
    :save="false"
    :cancel="false">

    <x-slot:header class="border-0">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </x-slot>

    <div class="text-center mb-3">
        <h4 class="mb-1">Disable Two-Factor Authentication</h4>
    </div>

    <div class="p-lg-4 p-2">

        {{-- Stage Indicator --}}
        <x-core::stage-buttons id="disable2fa-steps" :stages="[
            ['id' => 'confirm', 'name' => 'Confirm', 'color' => 'primary', 'disabled' => true],
            ['id' => 'verify',  'name' => 'Verify',  'color' => 'danger',  'disabled' => true],
        ]" class="mb-4" />

        {{-- Warning --}}
        <div class="alert alert-solid-danger d-flex align-items-center gap-2 mb-4">
            <i class="ri-error-warning-line fs-16 flex-shrink-0"></i>
            <span class="fs-13">Disabling two-factor authentication will remove an extra layer of security from your account.</span>
        </div>

        {{-- Step 1: Confirm Password --}}
        <x-core::field id="disable2fa-password" label="Current password" hidden required>
            <x-core::password />
        </x-core::field>

        {{-- Step 2a: TOTP Verify --}}
        <div id="disable2fa-step-totp" class="d-none">
            <p class="fs-13 text-muted mb-3">Enter the 6-digit code from your authenticator app to confirm.</p>
            <x-core::otp-input id="disable2fa-totp-otp-input" />
        </div>

        {{-- Step 2b: Email Verify --}}
        <div id="disable2fa-step-email" class="d-none">

            <div class="text-center mb-4">
                <div class="avatar avatar-xl bg-info-transparent rounded-circle d-inline-flex align-items-center justify-content-center mb-3">
                    <i class="ri-mail-send-line fs-24 text-info"></i>
                </div>
                <p class="fs-14 mb-1 text-muted">We sent a code to</p>
                <p class="fs-15 fw-semibold mb-0" id="disable2fa-email-masked"></p>
            </div>

            <x-core::otp-input id="disable2fa-email-otp-input" resend-url="{{ route('core.two-factor.disable.send-otp') }}" class="mb-3" />

        </div>

        {{-- Action Buttons --}}
        <div class="d-flex align-items-center mt-4">
            <x-core::button id="disable2fa-btn-prev" size="sm" variant="outline" color="secondary" hidden>
                <i class="ri-arrow-left-line me-1"></i>Back
            </x-core::button>
            <div class="ms-auto d-flex gap-2">
                <x-core::button size="sm" color="light" data-bs-dismiss="modal">Cancel</x-core::button>
                <x-core::button id="disable2fa-btn-next" size="sm">Continue</x-core::button>
            </div>
        </div>

    </div>

</x-core::modal>
