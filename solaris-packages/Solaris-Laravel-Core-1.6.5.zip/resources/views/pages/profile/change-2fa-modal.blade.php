<x-core::modal-form
    id="change-two-factor-modal"
    size="lg"
    :save="false"
    :cancel="false">

    <x-slot:header class="border-0">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </x-slot>

    <div class="text-center mb-3">
        <h4 class="mb-1" id="change2fa-modal-title">Change Two-Factor Method</h4>
    </div>

    <div class="p-lg-4 p-2">

        {{-- Stage Indicator --}}
        <x-core::stage-buttons id="change2fa-steps" :stages="[
            ['id' => 'confirm',        'name' => 'Confirm', 'color' => 'primary', 'disabled' => true],
            ['id' => 'verify-current', 'name' => 'Verify',  'color' => 'primary', 'disabled' => true],
            ['id' => 'method',         'name' => 'Method',  'color' => 'primary', 'disabled' => true],
            ['id' => 'verify-new',     'name' => 'Set Up',  'color' => 'primary', 'disabled' => true],
            ['id' => 'backup',         'name' => 'Backup',  'color' => 'success', 'disabled' => true],
        ]" class="mb-4" />

        {{-- Step 1: Confirm Password --}}
        <x-core::field id="change2fa-password" label="Current password" hidden required>
            <x-core::password />
        </x-core::field>

        {{-- Step 2a: Verify Current — TOTP --}}
        <div id="change2fa-verify-current-totp" class="d-none">
            <p class="fs-13 text-muted mb-3">Enter the 6-digit code from your current authenticator app to confirm.</p>
            <x-core::otp-input id="change2fa-current-totp-otp-input" />
        </div>

        {{-- Step 2b: Verify Current — Email OTP --}}
        <div id="change2fa-verify-current-email" class="d-none">

            <div class="text-center mb-4">
                <div class="avatar avatar-xl bg-info-transparent rounded-circle d-inline-flex align-items-center justify-content-center mb-3">
                    <i class="ri-mail-send-line fs-24 text-info"></i>
                </div>
                <p class="fs-14 mb-1 text-muted">We sent a verification code to</p>
                <p class="fs-15 fw-semibold mb-0" id="change2fa-current-email-masked"></p>
            </div>

            <x-core::otp-input id="change2fa-current-email-otp-input" resend-url="{{ route('core.two-factor.disable.send-otp') }}" class="mb-3" />

        </div>

        {{-- Step 3: Choose New Method --}}
        <x-core::field id="change2fa-method" hidden>
            <x-core::radio-card-group name="change2fa-method" :options="[
                ['value' => 'totp',  'icon' => 'ri-smartphone-line', 'label' => 'Authenticator App', 'description' => 'Use Google Authenticator, Authy, or any TOTP-compatible app. Works offline and is the most secure option.'],
                ['value' => 'email', 'icon' => 'ri-mail-line',       'label' => 'Email OTP',          'description' => 'Receive a one-time code to your registered email address each time you log in.', 'color' => 'info'],
            ]" />
        </x-core::field>

        {{-- Step 4a: Verify New — TOTP Setup --}}
        <div id="change2fa-step-totp" class="d-none">

            <p class="fs-13 text-muted mb-3">Scan this QR code with your new authenticator app, then enter the 6-digit code to confirm.</p>

            <div class="d-flex justify-content-center mb-3">
                <div id="change2fa-new-totp-qr" class="border rounded-3 p-2 bg-white d-inline-flex" style="line-height: 0;"></div>
            </div>

            <div class="text-center mb-4">
                <p class="fs-12 text-muted mb-1">Can't scan? Enter this key manually:</p>
                <code id="change2fa-new-totp-manual-key" class="fs-13 text-primary fw-semibold letter-spacing-1"></code>
            </div>

            <x-core::otp-input id="change2fa-new-totp-otp-input" />

        </div>

        {{-- Step 4b: Verify New — Email OTP --}}
        <div id="change2fa-step-email" class="d-none">

            <div class="text-center mb-4">
                <div class="avatar avatar-xl bg-info-transparent rounded-circle d-inline-flex align-items-center justify-content-center mb-3">
                    <i class="ri-mail-send-line fs-24 text-info"></i>
                </div>
                <p class="fs-14 mb-1 text-muted">We sent a code to</p>
                <p class="fs-15 fw-semibold mb-0" id="change2fa-new-email-masked"></p>
            </div>

            <x-core::otp-input id="change2fa-new-email-otp-input" resend-url="{{ route('core.two-factor.setup.email') }}" class="mb-3" />

        </div>

        {{-- Step 5: Backup Codes --}}
        <div id="change2fa-step-backup" class="d-none">

            <div class="alert alert-solid-warning d-flex align-items-center gap-2 mb-4">
                <i class="ri-error-warning-line fs-16 flex-shrink-0"></i>
                <span class="fs-13">Save these codes now. They cannot be shown again. Each code can only be used once.</span>
            </div>

            <div class="row g-2 mb-4" id="change2fa-backup-codes-grid"></div>

            <div class="d-flex gap-2 mb-4">
                <x-core::button id="change2fa-download-codes" variant="outline" size="sm" color="secondary" class="flex-grow-1">
                    <i class="ri-download-line me-1"></i>Download .txt
                </x-core::button>
                <x-core::button id="change2fa-copy-codes" variant="outline" size="sm" color="secondary" class="flex-grow-1">
                    <i class="ri-file-copy-line me-1"></i>Copy All
                </x-core::button>
            </div>

        </div>

        {{-- Action Buttons --}}
        <div class="d-flex align-items-center mt-4">
            <x-core::button id="change2fa-btn-prev" size="sm" variant="outline" color="secondary" hidden>
                <i class="ri-arrow-left-line me-1"></i>Back
            </x-core::button>
            <div class="ms-auto d-flex gap-2">
                <x-core::button size="sm" color="light" data-bs-dismiss="modal">Cancel</x-core::button>
                <x-core::button id="change2fa-btn-next" size="sm">Continue</x-core::button>
            </div>
        </div>

    </div>

</x-core::modal-form>
