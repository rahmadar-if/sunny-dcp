@php
    $googleEmail = $data->sso['google'] ?? null;
    $is2fa       = !is_null($data->user->two_factor_confirmed_at);
    $method2fa   = $data->user->two_factor_method;
    $since2fa    = $data->user->two_factor_confirmed_at?->format('d M Y');
@endphp

<ul class="list-group list-group-flush list-unstyled rounded">

    {{-- Change password --}}
    <li class="list-group-item">
        <div class="d-flex justify-content-between gap-2">
            <div class="d-flex flex-column gap-1">
                <p class="fs-16 mb-1 fw-medium">Change password</p>
                <p class="fs-12 mb-0 text-muted">Update your account password to keep your account secure and prevent unauthorized access.</p>
            </div>
            <div class="d-flex flex-column gap-2">
                <x-core::button id="forgot-password" color="danger" size="sm" disabled>Forgot password</x-core::button>
                <x-core::button id="change-password" variant="outline" size="sm"><i class="ri-lock-password-line me-1"></i>Change Password</x-core::button>
            </div>
        </div>
    </li>

    {{-- Two-step verification --}}
    <li class="list-group-item">
        <div id="2fa-status-section"
             data-enabled="{{ $is2fa ? 'true' : 'false' }}"
             data-method="{{ $method2fa ?? '' }}"
             data-since="{{ $since2fa ?? '' }}">

            <div class="d-flex justify-content-between gap-2">
                <div class="d-flex flex-column gap-1">
                    <div class="d-flex align-items-center gap-2 flex-wrap">
                        <p class="fs-16 mb-0 fw-medium">Two-Factor Authentication</p>
                        <span id="2fa-badge-active" class="badge bg-success-transparent {{ !$is2fa ? 'd-none' : '' }}">Active</span>
                        <span id="2fa-badge-method" class="badge bg-info-transparent {{ !$is2fa ? 'd-none' : '' }}">
                            {{ $method2fa === 'totp' ? 'Authenticator App' : 'Email OTP' }}
                        </span>
                        <span id="2fa-badge-inactive" class="badge bg-danger-transparent {{ $is2fa ? 'd-none' : '' }}">Inactive</span>
                    </div>
                    <p class="fs-12 mb-0 text-muted">Add an extra layer of security to your account by requiring a verification code in addition to your password.</p>
                    <p id="2fa-since" class="fs-11 mb-0 text-muted {{ (!$is2fa || !$since2fa) ? 'd-none' : '' }}">Active since {{ $since2fa }}</p>
                </div>
                <div class="d-flex align-items-start gap-2 flex-shrink-0">
                    <div id="2fa-actions-inactive" class="{{ $is2fa ? 'd-none' : '' }}">
                        <x-core::button id="btn-enable-2fa" size="sm">
                            <i class="ri-shield-check-line me-1"></i>Enable 2FA
                        </x-core::button>
                    </div>
                    <div id="2fa-actions-active" class="d-flex gap-2 {{ !$is2fa ? 'd-none' : '' }}">
                        <x-core::button id="btn-change-2fa-method" variant="outline" size="sm">Change Method</x-core::button>
                        <x-core::button id="btn-disable-2fa" color="danger" variant="outline" size="sm">Disable</x-core::button>
                    </div>
                </div>
            </div>

        </div>
    </li>

    {{-- Single Sign On --}}
    <li class="list-group-item">
        <div class="row gx-5 gy-3">
            <div class="col-xxl-4">
                <p class="fs-16 mb-1 fw-medium">Single Sign On</p>
                <p class="fs-12 mb-0 text-muted">Link your third-party accounts for quick, passwordless sign-in — no need to remember another password.</p>
            </div>
            <div class="col-xxl-8">
                <div class="d-flex flex-column gap-3">

                    {{-- Google --}}
                    <div id="google-sso-container"
                         data-email="{{ $googleEmail ?? '' }}"
                         data-connect-url="{{ (SolarHelper::config('auth.sso.login') || SolarHelper::config('auth.sso.register')) ? route('sso.redirect', ['google', 'connect']) : '' }}">
                        @if ($googleEmail)
                            <div class="d-flex align-items-center gap-3">
                                <div class="d-flex align-items-center gap-2 flex-grow-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24">
                                        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                                        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                                        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/>
                                        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                                    </svg>
                                    <div class="d-flex flex-column">
                                        <span class="fs-11 text-muted">Connected as</span>
                                        <span class="fs-13 fw-medium">{{ $googleEmail }}</span>
                                    </div>
                                </div>
                                <span class="badge bg-success-transparent">Connected</span>
                                <button type="button" class="btn btn-sm btn-outline-danger" id="sso-google-disconnect">Disconnect</button>
                            </div>
                        @else
                            <button type="button" class="btn btn-outline-secondary d-flex align-items-center gap-2" id="sso-google-connect">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24">
                                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/>
                                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                                </svg>
                                Connect with Google
                            </button>
                        @endif

                        @session('message')
                            <div class="alert alert-solid-danger alert-dismissible fade show w-100 mt-3">
                                {{ session('message') }}
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"><i class="bi bi-x"></i></button>
                            </div>
                        @endsession
                    </div>

                    {{-- LinkedIn --}}
                    <div>
                        <button type="button" class="btn btn-outline-secondary d-flex align-items-center gap-2" disabled>
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18" fill="#0A66C2">
                                <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                            </svg>
                            Connect with LinkedIn
                            <span class="fs-11 text-muted">(Coming soon)</span>
                        </button>
                    </div>

                    {{-- Microsoft Entra ID --}}
                    <div>
                        <button type="button" class="btn btn-outline-secondary d-flex align-items-center gap-2" disabled>
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 23 23" width="18" height="18">
                                <path fill="#f35325" d="M1 1h10v10H1z"/>
                                <path fill="#81bc06" d="M12 1h10v10H12z"/>
                                <path fill="#05a6f0" d="M1 12h10v10H1z"/>
                                <path fill="#ffba08" d="M12 12h10v10H12z"/>
                            </svg>
                            Connect with Microsoft
                            <span class="fs-11 text-muted">(Coming soon)</span>
                        </button>
                    </div>

                </div>
            </div>
        </div>
    </li>

</ul>

@push('modal-content')
    @include('core::pages.profile.change-password-modal')
    @include('core::pages.profile.2fa-modal')
    @include('core::pages.profile.disable-2fa-modal')
    @include('core::pages.profile.change-2fa-modal')
@endpush
