{{-- AI Persona --}}
<x-core::fieldset label="AI Persona" />

<div class="row mb-3">
    <div class="col-md-6">
        <x-core::field id="nickname" label="Nickname">
            <x-core::input
                placeholder="What should the AI call you?"
                :value="$data->nickname"/>
        </x-core::field>

        <x-core::field id="chat_style_id" label="Chat Style">
            <x-core::lookup
                placeholder="Choose a conversation style"
                :options="SolarHelper::model('chat_style')::toSelect()"
                :value="json_encode($data->chat_style)"/>
        </x-core::field>
    </div>
</div>

{{-- Usage --}}
<x-core::fieldset label="AI Usage This Month" />

<div class="row">
    <div class="col-lg-6 col-md-6">
        <x-core::metric
            id="profile-total-token-ai"
            variant="compact"
            title="Total Token (This Month)"
            :value="$aiStats['total_token']->value"
            icon="ri-cpu-line"
            color="primary" />
    </div>

    <div class="col-lg-6 col-md-6">
        <x-core::metric
            id="profile-total-request-ai"
            variant="compact"
            title="Total Request (This Month)"
            :value="$aiStats['total_request']->value"
            icon="ri-send-plane-line"
            color="info" />
    </div>
</div>
