<div class="card custom-card overflow-hidden border">

    {{-- Avatar + name --}}
    <div class="card-body border-bottom border-block-end-dashed">
        <div class="text-center">
            <x-core::profile-picture
                id="profile-picture"
                class="mb-3"
                :source="$data->user->profile_picture_id"
                :upload_to="route('core.profile.update.avatar', ['id' => $data->id])"
                :preview_width="$data->user->profile_picture?->image_width"
                :preview_height="$data->user->profile_picture?->image_height" />

            <h5 class="fw-medium mb-1" id="name-display">{{ $data->name }}</h5>
            <span class="d-block fw-medium text-muted mb-2">{{ $data->email }}</span>
        </div>
    </div>

    {{-- Roles + verified at --}}
    <div class="card-body border-bottom border-block-end-dashed p-0">
        <ul class="list-group list-group-flush">

            @php
                // Self-service profile — only regular users ever reach this page (integration
                // accounts can't log in), so identity roles are always group_name=user. Null
                // falls back to "user" too (pre-migration role, not yet tagged).
                $identityRoles = $data->roles->whereIn('group_name', ['user', null]);
                $aiRoles = $data->roles->where('group_name', 'ai');
            @endphp

            <li class="list-group-item pt-2 border-0">
                <div class="d-flex align-items-center gap-2">
                    <i class="ri-organization-chart fs-22" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Role"></i>
                    <div class="d-flex align-items-center gap-1" id="roles-display">
                        @forelse ($identityRoles->take(2) as $role)
                            <span class="badge bg-{{ $role->name == 'Admin' ? 'success' : 'info'}}">{{ $role->name }}</span>
                        @empty
                            <span class="badge bg-danger">None</span>
                        @endforelse
                        @if ($identityRoles->count() > 2)
                            <span class="badge bg-secondary" role="button" id="roles-more-badge">{{ $identityRoles->count() - 2 }}+</span>
                        @endif
                    </div>
                </div>
            </li>

            <li class="list-group-item pt-2 border-0">
                <div class="d-flex align-items-center gap-2">
                    <i class="ri-robot-line fs-22" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="AI Access"></i>
                    <div class="d-flex align-items-center gap-1" id="ai-roles-display">
                        @forelse ($aiRoles->take(2) as $role)
                            <span class="badge bg-info">{{ $role->name }}</span>
                        @empty
                            <span class="badge bg-danger">None</span>
                        @endforelse
                        @if ($aiRoles->count() > 2)
                            <span class="badge bg-secondary" role="button" id="ai-roles-more-badge">{{ $aiRoles->count() - 2 }}+</span>
                        @endif
                    </div>
                </div>
            </li>

            <li class="list-group-item pt-2 border-0">
                <div class="d-flex align-items-center gap-2">
                    <i class="ri-verified-badge-line fs-22" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Verified at"></i>
                    <div class="d-flex flex-column gap-1">
                        <span class="fw-medium text-muted">{{ $data->user->email_verified_at?->localized() ?? "-" }}</span>
                    </div>
                </div>
            </li>

            <li class="list-group-item pt-2 border-0">
                <div class="d-flex align-items-center gap-2">
                    <i class="ri-smartphone-line fs-22" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Mobile Access"></i>
                    <span class="badge {{ $data->user->is_mobile_access ? 'bg-success' : 'bg-danger' }}">
                        {{ $data->user->is_mobile_access ? 'Allowed' : 'Denied' }}
                    </span>
                </div>
            </li>

            <li class="list-group-item pt-2 border-0">
                <div class="d-flex align-items-center gap-2">
                    <i class="ri-whatsapp-line fs-22" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="WhatsApp AI"></i>
                    <span class="badge {{ $data->user->whatsapp_enabled ? 'bg-success' : 'bg-danger' }}">
                        {{ $data->user->whatsapp_enabled ? 'Allowed' : 'Denied' }}
                    </span>
                </div>
            </li>

        </ul>
    </div>

    {{-- Storage usage --}}
    @php
        $maxSize      = SolarHelper::config('attachment.max_size', 5 * 1024 * 1024 * 1024);
        $usedBytes    = $data->total_uploaded_size_raw;
        $percentage   = $maxSize > 0 ? min(100, round(($usedBytes / $maxSize) * 100, 2)) : 0;
        $barColor     = $percentage >= 90 ? 'danger' : ($percentage >= 70 ? 'warning' : 'success');
        $maxFormatted = \Solaris\Core\Helpers\Number::getHumanReadableSize($maxSize);
    @endphp

    <div class="card-body"
            id="storage-info"
            data-max-size="{{ $maxSize }}"
            data-max-formatted="{{ $maxFormatted }}">
        <div class="d-flex align-items-center justify-content-between mb-2">
            <div class="d-flex align-items-center gap-2">
                <i class="ri-hard-drive-2-line fs-16 text-muted"></i>
                <span class="fs-13 fw-medium">Storage</span>
            </div>
            <span class="fs-12 text-muted" id="file-size-display">{{ $data->total_uploaded_size }} / {{ $maxFormatted }}</span>
        </div>
        <div class="progress mb-2" style="height: 5px;">
            <div class="progress-bar bg-{{ $barColor }}"
                    id="storage-progress-bar"
                    role="progressbar"
                    style="width: {{ $percentage }}%"
                    aria-valuenow="{{ $percentage }}"
                    aria-valuemin="0"
                    aria-valuemax="100"></div>
        </div>
        <div class="d-flex justify-content-between">
            <span class="fs-12 text-muted" id="file-count-display">{{ $data->total_file }} files</span>
            <span class="fs-12 text-muted" id="storage-percentage">{{ $percentage }}% used</span>
        </div>
    </div>

</div>

@push('modal-content')
    <x-core::modal id="roles-modal" title="Role" size="sm" center>
        <div class="table-responsive">
            <table class="table table-sm mb-0">
                <thead>
                    <tr><th>Role</th></tr>
                </thead>
                <tbody id="roles-modal-body">
                    @foreach ($identityRoles as $role)
                        <tr>
                            <td><span class="badge bg-{{ $role->name == 'Admin' ? 'success' : 'info' }}">{{ $role->name }}</span></td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </x-core::modal>

    <x-core::modal id="ai-roles-modal" title="AI Access" size="sm" center>
        <div class="table-responsive">
            <table class="table table-sm mb-0">
                <thead>
                    <tr><th>Role</th></tr>
                </thead>
                <tbody id="ai-roles-modal-body">
                    @foreach ($aiRoles as $role)
                        <tr>
                            <td><span class="badge bg-info">{{ $role->name }}</span></td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </x-core::modal>
@endpush