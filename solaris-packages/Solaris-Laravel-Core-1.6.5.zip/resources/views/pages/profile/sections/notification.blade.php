<ul class="list-group list-group-flush list-unstyled rounded">
    <li class="list-group-item">
        <div class="d-flex justify-content-between gap-2">
            <div class="d-flex flex-column gap-1">
                <p class="fs-16 mb-1 fw-medium">In-App notification</p>
                <p class="fs-12 mb-0 text-muted">View alerts and updates directly within the app to stay on top of important actions and security events.</p>
            </div>
            <div class="d-flex align-items-start justify-content-end">
                <x-core::checkbox id="is_app_notification" size="lg" switch :checked="$data->user->is_app_notification" />
            </div>
        </div>
    </li>

    <li class="list-group-item">
        <div class="d-flex justify-content-between gap-2">
            <div class="d-flex flex-column gap-1">
                <p class="fs-16 mb-1 fw-medium">Push notification</p>
                <p class="fs-12 mb-0 text-muted">Receive browser and desktop alerts, like YouTube notifications, even when you're not actively using the app.</p>
            </div>
            <div class="d-flex align-items-start justify-content-end">
                <x-core::checkbox id="is_push_notification" size="lg" switch :checked="$data->user->is_push_notification" />
            </div>
        </div>
    </li>

    <li class="list-group-item">
        <div class="d-flex justify-content-between gap-2">
            <div class="d-flex flex-column gap-1">
                <p class="fs-16 mb-1 fw-medium">Mobile notification</p>
                <p class="fs-12 mb-0 text-muted">Receive push notifications directly on your mobile device via the app, even when running in the background.</p>
            </div>
            <div class="d-flex align-items-start justify-content-end">
                <x-core::checkbox id="is_mobile_notification" size="lg" switch :checked="$data->user->is_mobile_notification" />
            </div>
        </div>
    </li>

    <li class="list-group-item">
        <div class="d-flex justify-content-between gap-2">
            <div class="d-flex flex-column gap-1">
                <p class="fs-16 mb-1 fw-medium">Email notification</p>
                <p class="fs-12 mb-0 text-muted">Get important updates and alerts delivered to your email to stay informed about your account activity.</p>
            </div>
            <div class="d-flex align-items-start justify-content-end">
                <x-core::checkbox id="is_email_notification" size="lg" switch :checked="$data->user->is_email_notification" />
            </div>
        </div>
    </li>
</ul>
