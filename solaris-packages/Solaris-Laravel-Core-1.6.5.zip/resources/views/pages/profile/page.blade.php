<x-core::page.edit
    :id="$data->id"
    title="Profile"
    :breadcrumbs="$breadcrumbs"
    model="Profile"
    package="core"
    path="profile/index">

    <div class="row">

        <div class="col">
            <div class="card custom-card profile-card">
                <x-core::profile-banner
                    id="profile-banner"
                    :source="$data->banner_id"
                    :upload_to="route('core.profile.update.banner')"
                    :max="SolarHelper::config('attachment.max_upload_file', 5)"
                    :preview_width="$data->banner?->image_width"
                    :preview_height="$data->banner?->image_height" />
                <div class="card-body pb-0 position-relative">
                    <div class="row profile-content">

                        {{-- Left sidebar --}}
                        <div class="col-xxl-3 col-xl-4">
                            @include('core::pages.profile.sections.profile', ['data' => $data])
                        </div>

                        {{-- Right content --}}
                        <div class="col-xxl-9 col-xl-8">
                            <div class="card custom-card overflow-hidden border">
                                <div class="card-body">
                                    <x-core::tab id="tabs" class="p-0 mb-4" variant="tab-style-7">
                                        <x-slot:nav>
                                            <x-core::tab-nav id="tabs_about" active>About</x-core::tab-nav>
                                            <x-core::tab-nav id="tabs_ai">AI</x-core::tab-nav>
                                            <x-core::tab-nav id="tabs_notification">Notification</x-core::tab-nav>
                                            <x-core::tab-nav id="tabs_security">Security</x-core::tab-nav>
                                            <x-core::tab-nav id="tabs_session">Session</x-core::tab-nav>
                                        </x-slot>

                                        <x-slot:content>
                                            <x-core::tab-content id="tabs_about" active class="p-0 border-0">
                                                @include('core::pages.profile.sections.about', ['data' => $data])
                                            </x-core::tab-content>

                                            <x-core::tab-content id="tabs_ai" class="p-0 border-0">
                                                @include('core::pages.profile.sections.ai', ['data' => $data, 'aiStats' => $aiStats])
                                            </x-core::tab-content>

                                            <x-core::tab-content id="tabs_notification" class="p-0 border-0">
                                                @include('core::pages.profile.sections.notification', ['data' => $data])
                                            </x-core::tab-content>

                                            <x-core::tab-content id="tabs_security" class="p-0 border-0">
                                                @include('core::pages.profile.sections.security', ['data' => $data])
                                            </x-core::tab-content>

                                            <x-core::tab-content id="tabs_session" class="p-0 border-0">
                                                @include('core::pages.profile.sections.session', ["id" => $data->user->id])
                                            </x-core::tab-content>
                                        </x-slot>
                                    </x-tab>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div>

</x-core::page.edit>
