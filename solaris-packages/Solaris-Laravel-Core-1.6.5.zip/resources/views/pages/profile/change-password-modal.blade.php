<x-core::modal-form
    id="change-password-modal"
    title="Change Password"
    size="md"
    method="PUT"
    :action="route('core.profile.change-password')"
    save="Change Password">

    <x-core::field id="current_password" label="Current password" required>
        <x-core::password />
    </x-core::field>

    <x-core::field id="password" label="New password" required>
        <x-core::password />
    </x-core::field>

    <x-core::field id="password_confirmation" label="Confirm password" required>
        <x-core::password />
    </x-core::field>

</x-core::modal-form>
