<x-core::modal-form 
    id="permission-modal" 
    model="Permission" 
    title="Permission"
    size="md">

    <x-core::field id="permission-modal-name:name" label="Name" required>
        <x-core::input 
            placeholder="Enter permission name"/>
    </x-core::field>

    {{-- Indicator only. The submitted value comes from the active group filter, injected in list.js --}}
    <x-core::field id="permission-modal-group_name:group_name" label="Group">
        <x-core::input readonly />
    </x-core::field>

    <x-core::field id="permission-modal-description:description" label="Description">
        <x-core::textarea  
            placeholder="Enter permission description"/>
    </x-core::field>

</x-core::modal-form>