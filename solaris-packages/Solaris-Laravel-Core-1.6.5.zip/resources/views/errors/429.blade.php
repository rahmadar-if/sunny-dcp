@extends('core::errors.layout')

@section('title', 'Too Many Requests')
@section('code', '429')
@section('code_message', 'Too Many Requests')
@section('message', 'You have made too many requests. Please wait a moment and try again.')
