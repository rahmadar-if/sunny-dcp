@extends('core::layouts.blank')
@section('content')

@php
    $back = $back ?? true;
    $logout = $logout ?? false;
@endphp

<div class="page error-bg" style="--error-bg: url('{{ Vite::asset(SolarHelper::config('application.assets.error_background')) }}')">
    <div class="error-page">
        <div class="container">
            <div class="my-auto">
                <div class="row align-items-center justify-content-center h-100 text-center">
                    <div class="col-xl-7 col-lg-5 col-md-6 col-12">
                        <p class="error-text mb-4 text-fixed-white">@yield('code')</p>
                        <p class="fs-4 fw-normal mb-2 text-fixed-white">@yield('code_message')</p>
                        <p class="fs-15 mb-5 text-fixed-white">@yield('message')</p>

                        <div class="d-flex justify-content-center gap-2">
                            @if(isset($back) && $back === true)
                            <a href="{{ route('home') }}" class="btn btn-outline-primary"><i class="ri-arrow-left-line align-middle me-1 d-inline-block"></i> BACK TO HOME PAGE</a>
                            @endif

                            @if(isset($logout) && $logout === true)
                            <a href="{{ route('logout') }}" class="btn btn-outline-secondary"><i class="ri-arrow-left-line align-middle d-inline-block"></i> LOGOUT</a>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection