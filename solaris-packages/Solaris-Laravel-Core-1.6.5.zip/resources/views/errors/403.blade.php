@extends('core::errors.layout')

@section('title', 'Forbidden')
@section('code', '403')
@section('code_message', 'Forbidden')
@section('message', 'You do not have permission to access this page.')
