@extends('core::errors.layout')

@section('title', 'Unauthorized')
@section('code', '401')
@section('code_message', 'Unauthorized')
@section('message', 'You are not authorized to access this resource. Please log in and try again.')
