@extends('core::errors.layout')

@section('title', 'Internal Server Error')
@section('code', '500')
@section('code_message', 'Internal Server Error')
@section('message', 'Something went wrong on our end. Please try again later or contact support if the problem persists.')
