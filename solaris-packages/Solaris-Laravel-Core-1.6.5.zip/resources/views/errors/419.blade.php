@extends('core::errors.layout')

@section('title', 'Page Expired')
@section('code', '419')
@section('code_message', 'Page Expired')
@section('message', 'Your session has expired. Please refresh the page and try again.')
