@extends('core::errors.layout')

@section('title', 'Page Not Found')
@section('code', '404')
@section('code_message', 'Oops! Page Not Found')
@section('message', 'The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.')
