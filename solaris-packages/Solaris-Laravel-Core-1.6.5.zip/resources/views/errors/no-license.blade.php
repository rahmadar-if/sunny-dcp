@extends('core::errors.layout')

@php
    $logout = true;
@endphp

@section('title', "No License")
@section('code', '403')
@section('code_message', 'No License')
@section('message', "Your account has been verified, but you do not have an active license assigne")
