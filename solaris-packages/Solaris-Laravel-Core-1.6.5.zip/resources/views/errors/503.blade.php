@extends('core::errors.layout')

@php
	$back = false;
@endphp

@section('title', 'Service Unavailable')
@section('code', '503')
@section('code_message', 'Service Unavailable')
@section('message', 'We are currently performing maintenance. Please check back soon.')
