@extends('core::errors.layout')

@section('title', "Needs Integration")
@section('code_message', 'Needs Integration')
@section('message', "This feature needs integration")
