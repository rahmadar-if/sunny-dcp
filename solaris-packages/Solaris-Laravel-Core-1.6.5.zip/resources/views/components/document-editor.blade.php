@props([
    "id",
    "bind"         => null,
    "lazy"         => false,
    "ignore"       => false,
    "record_id"    => null,
    "model"        => null,
    "column"       => null,
    "pdf_filename" => null,
])

@php
    if(!empty($id) && empty($bind) && str_contains($id, ":")) {
        $splitId = explode(":", $id);
        $id      = $splitId[0];
        $bind    = $splitId[1];
    }
@endphp

<div {{ 
    $attributes->merge([
        "id"         => $id,
        "solar-ui"     => "document-editor",
        "solar-bind"   => !empty($bind) ? $bind : $id,
        "lazy"         => $lazy === true,
        "ignore"       => $ignore === true,
        "record-id"    => $record_id,
        "model"        => $model,
        "column"       => $column,
        "pdf-filename" => $pdf_filename,
    ]) 
}} class="editor-container editor-container_document-editor editor-container_include-style editor-container_include-word-count editor-container_include-fullscreen">
    <div id="{{ $id }}_editor-menu-bar" class="editor-container__menu-bar"></div>
    <div id="{{ $id }}_editor-toolbar" class="editor-container__toolbar"></div>
    <div class="editor-container__editor-wrapper">
        <div class="editor-container__editor">
            <div id="{{ $id }}_editor">
                @if (!$slot->isEmpty()) {{ $slot }} @endif
            </div>
        </div>
    </div>
    <div id="{{ $id }}_editor-word-count" class="editor_container__word-count"></div>
</div>