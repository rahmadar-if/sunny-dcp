@props([
    "name"          => null,
    "data"          => null,
    "searchable"    => false, // true, false, or a Filter::OperatorType key (e.g. "FullText", "Contains") to override the model's $searchColumns default for this column
    "orderable"     => false,
    "editable"      => [],
    "width"         => null,
    "default_order" => null, // asc, desc
    "lookup"        => false, // can string, define extend column
    "cell_class"    => null, // default class for td in this column
    "type"          => null, // datetime, ...
    "format"        => null, // format string (e.g. yyyy-MM-dd HH:mm)
    "expand"             => false, // false | true (default 15rem) | CSS width string
    "decimal_separator"  => null,
    "thousand_separator" => null,
    "prefix"             => null,
])

@php
    $isLookup       = $lookup === true || (!empty($lookup) && is_string($lookup)) || (!empty($data) && str_contains($data, "."));
    $isLookupString = $isLookup && (!empty($lookup) && is_string($lookup));
    $isLookupDot    = $isLookup && (!empty($data) && str_contains($data, "."));

    $expandWidth    = $expand === true ? "15rem" : ($expand !== false ? $expand : null);

    if(empty($name) && !empty($data)) {
        if(!$isLookup) {
            $name = $data;
        } else if($isLookup && $isLookupDot) {
            $name = explode(".", $data)[0]."_id";
        } else if($isLookup && !str_ends_with($data, "_id")) {
            $name = $data."_id";
        } else if($isLookup && empty($name)) {
            $name = $data;
        }
    }
@endphp

<th {{ 
    $attributes->merge([
        "field-name"    => $name,
        "field-data"    => isset($data) && !empty($data) ? $data : null,
        "order"         => $orderable === true,
        "default-order" => $orderable === true ? (is_string($default_order) && !empty($default_order) ? $default_order : null) : null,
        "searchable"    => is_string($searchable) && $searchable !== '' ? $searchable : ($searchable === true),
        "editable"      => is_array($editable) && !empty($editable) ? json_encode($editable) : null,
        "width"         => $width,
        "lookup"        => $isLookupString ? $lookup : $isLookup,
        "cell-class"    => !empty($cell_class) ? $cell_class : null,
        "field-type"    => $type,
        "field-format"  => $format,
        "field-expand"              => $expandWidth,
        "field-decimal-separator"   => $decimal_separator,
        "field-thousand-separator"  => $thousand_separator,
        "field-prefix"              => $prefix,
    ])
    ->class([
        "orderable" => $orderable === true,
    ])
}}>
    {{ $slot }}

    @if ($orderable === true)
        <span class="sort-icon">
            <i class="ri-arrow-up-down-line sort-icon-hover"></i>
            <i class="ri-arrow-down-line sort-icon-desc"></i>
            <i class="ri-arrow-up-line sort-icon-asc"></i>
        </span>
    @endif
</th>