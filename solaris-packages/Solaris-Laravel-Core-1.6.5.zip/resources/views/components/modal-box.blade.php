@props([
    "id",
    "title"      => null,
    "size"       => "lg",
    "fullscreen" => false,
    "ignore"     => false,
    "center"     => true,
    "cancel"     => true,
])

<x-core::modal
    :id="$id"
    body:class="p-3 p-lg-4"
    animation="scale"
    static
    :center="$center"
    :size="$size"
    :fullscreen="$fullscreen"
    :ignore="$ignore">

    <x-slot:header class="border-0">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </x-slot>

    <div class="text-center mb-3">
        <h4 class="mb-2">{{ $title }}</h4>
    </div>

    <div class="p-lg-4 p-2">

        {{ $slot }}

        @if (isset($buttons) || $cancel)
        <div class="hstack gap-2 justify-content-center mt-4">
            @if (isset($buttons))
                {{ $buttons }}
            @endif

            @if ($cancel)
            <x-core::button data-bs-dismiss="modal" color="light" aria-label="Close">Cancel</x-core::button>
            @endif
        </div>
        @endif

    </div>
</x-core::modal>
