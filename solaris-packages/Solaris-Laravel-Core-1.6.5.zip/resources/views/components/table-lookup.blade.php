@props([
    'id',
    'model'          => null,
    'title'          => 'Choose',
    'size'           => 'xl',
    'vertical'       => 400,
    'filter'         => null,
    'order_by'       => null,
    'extend_columns' => null,
    'extend_search'  => null,
    'folder'         => false,
    'search'         => true,
    'refresh'        => true,
    'choose'         => 'Choose',
    'ignore'         => false
])

@php
    $isFullscreen = $size === 'fullscreen';
    $modalSize    = $isFullscreen ? null : (in_array($size, ['sm', 'lg', 'xl']) ? $size : null);
@endphp

@push('modal-content')

<div {{ 
    $attributes->merge([
        "id" => $id."_wrapper",
        "solar-id" => $id,
        "solar-ui" => "table-lookup",
        "ignore" => $ignore
    ]) 
}}>

    <x-core::modal
        :id="$id . '_modal'"
        :title="$title"
        :size="$modalSize"
        :fullscreen="$isFullscreen"
        center
        static
        ignore>

        <x-slot:footer class="border-top-0">
            @if(isset($footer))
                {{ $footer }}
            @endif
            <x-core::button size="sm" color="light" data-bs-dismiss="modal" ignore>Cancel</x-core::button>
            <x-core::button id="{{ $id }}_choose" size="sm" ignore>{{ $choose }}</x-core::button>
        </x-slot>

        @if(isset($body))
            {{ $body }}
        @endif

        <x-core::table
            :id="$id . '_table'"
            :model="$model"
            :card_wrapper="false"
            :new="false"
            :select_all="false"
            :delete_all="false"
            :import="false"
            :export="false"
            :vertical="$vertical"
            :filter="$filter"
            :order_by="$order_by"
            :extend_columns="$extend_columns"
            :extend_search="$extend_search"
            :folder="$folder"
            :search="$search"
            :refresh="$refresh"
            ignore
            lazy>

            <x-slot:column>
                {{ $column }}
            </x-slot>

        </x-core::table>

    </x-core::modal>

</div>
    
@endpush
