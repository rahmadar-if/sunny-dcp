@props([
    'id',
    'title',
    'description'       => null,
    'subtitle'          => null,
    'tooltip'           => null,
    'icon'              => 'ri-bar-chart-fill',
    'color'             => 'primary',
    'value'             => null,
    'changeTitle'       => null,
    'changeValue'       => null,
    'changeType'        => null,
    'variant'           => 'simple',
    'period'            => [],
    'date_column'       => 'created_at',
    'date_format'       => 'Y-m-d',
    'prefix'            => null,
    'decimal'           => 2,
    'decimalSeparator'  => ',',
    'thousandSeparator' => '.',
    'numberFormat'      => true,
    'model'             => null,
    'filter'            => null,
    'readable'          => true,
    'withPeriod'        => true,
    'withChange'        => false,
    'withChart'         => false,
    'lazy'              => false,
    'ignore'            => false,
    'numeral'           => false,
])

<div {{ $attributes->merge([
    'id'                 => $id,
    'solar-ui'           => 'metric',
    'variant'            => $variant,
    'color'              => $color,
    'model'              => $model ?: null,
    'date-column'        => $date_column,
    'date-format'        => $date_format,
    'decimal'            => $decimal,
    'decimal-separator'  => $decimalSeparator,
    'thousand-separator' => $thousandSeparator,
    'number-format'      => $numberFormat ? true : null,
    'readable'           => $readable ? true : null,
    'with-period'        => $withPeriod ? true : null,
    'with-change'        => $withChange ? true : null,
    'with-chart'         => $withChart ? true : null,
    'period'             => !empty($period) ? json_encode($period) : null,
    'prefix'             => $prefix ?: null,
    'filter'             => $filter ? (is_string($filter) ? $filter : json_encode($filter)) : null,
    'lazy'               => $lazy ? true : null,
    'ignore'             => $ignore ? true : null,
    'numeral'            => $numeral ? true : null,
]) }}>
    @if($slot->isEmpty())
        @switch($variant)
            @case('summary')
                <x-core::metric.summary
                    :title="$title" :tooltip="$tooltip" :icon="$icon" :color="$color" :value="$value"
                    :changeTitle="$changeTitle" :changeValue="$changeValue" :changeType="$changeType"
                    :numeral="$numeral" :prefix="$prefix" :decimal="$decimal" :decimalSeparator="$decimalSeparator" :thousandSeparator="$thousandSeparator" :id="$id"
                />
                @break

            @case('compact')
                <x-core::metric.compact
                    :title="$title" :tooltip="$tooltip" :icon="$icon" :color="$color" :value="$value"
                    :changeTitle="$changeTitle" :changeValue="$changeValue" :changeType="$changeType"
                    :numeral="$numeral" :prefix="$prefix" :decimal="$decimal" :decimalSeparator="$decimalSeparator" :thousandSeparator="$thousandSeparator" :id="$id"
                />
                @break

            @case('detail')
                <x-core::metric.detail
                    :title="$title" :description="$description" :subtitle="$subtitle" :tooltip="$tooltip"
                    :icon="$icon" :color="$color" :value="$value"
                    :changeTitle="$changeTitle" :changeValue="$changeValue" :changeType="$changeType"
                    :numeral="$numeral" :prefix="$prefix" :decimal="$decimal" :decimalSeparator="$decimalSeparator" :thousandSeparator="$thousandSeparator" :id="$id"
                />
                @break

            @case('simple-icon')
                <x-core::metric.simple-icon
                    :title="$title" :tooltip="$tooltip" :icon="$icon" :color="$color" :value="$value"
                    :changeTitle="$changeTitle" :changeValue="$changeValue" :changeType="$changeType"
                    :numeral="$numeral" :prefix="$prefix" :decimal="$decimal" :decimalSeparator="$decimalSeparator" :thousandSeparator="$thousandSeparator" :id="$id"
                />
                @break

            @default
                <x-core::metric.simple
                    :title="$title" :tooltip="$tooltip" :value="$value"
                    :changeTitle="$changeTitle" :changeValue="$changeValue" :changeType="$changeType"
                    :numeral="$numeral" :prefix="$prefix" :decimal="$decimal" :decimalSeparator="$decimalSeparator" :thousandSeparator="$thousandSeparator" :id="$id"
                />
        @endswitch
    @else
        {{ $slot }}
    @endif
</div>
