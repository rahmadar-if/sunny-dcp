@props([
	"id",
	"chunk_size"     => 2000000,
	"upload_message" => "Drop files here or click to upload.",
	"relation"       => null,
	"table_name"     => null,
	"record_id"      => null,
])

@php
	// @deprecated: prop "relation" digantikan oleh table_name + record_id
	$resolvedTableName = $table_name;
	$resolvedRecordId  = $record_id;

	if (empty($resolvedTableName) && !empty($relation) && str_contains($relation, ":")) {
		[$resolvedTableName, $resolvedRecordId] = explode(":", $relation, 2);
	}

	$filter = [];
	if (!empty($resolvedTableName) && !empty($resolvedRecordId)) {
		$filter = [
			"table_name = {$resolvedTableName}",
			"record_id = {$resolvedRecordId}"
		];
	}
@endphp

<div id="{{ $id }}" solar-ui="attachment" chunk-size="{{ $chunk_size }}"
	@if($resolvedTableName) table-name="{{ $resolvedTableName }}" @endif
	@if($resolvedRecordId)  record-id="{{ $resolvedRecordId }}"   @endif
>
	<x-core::dropzone
		id="{{ $id }}_upload"
		:chunk_size="$chunk_size"
		:upload_message="$upload_message"
		:table_name="$resolvedTableName"
		:record_id="$resolvedRecordId"
		ignore lazy />

	<x-core::table
		id="{{ $id }}_table"
		class="table-hover"
		model="Attachment:@datatable"
		:new="false"
		:card_wrapper="false"
		:filter="$filter"
		delete_all ignore lazy>
		<x-slot:column>
			<x-core::table-action-column :view="false" :edit="false" delete />
			<x-core::table-column width="50%" data="file_name" searchable orderable>Name</x-core::table-column>
			<x-core::table-column data="created_at" orderable type="datetime">Upload at</x-core::table-column>
		</x-slot>
	</x-core::table>
</div>

<x-core::modal
	id="{{ $id }}_preview"
	size="xl"
	:static="true"
	title="Preview"
	body:style="height:80vh;padding:0;overflow:hidden"
	ignore>
	<div id="{{ $id }}_preview_content" class="w-100 h-100"></div>
</x-core::modal>
