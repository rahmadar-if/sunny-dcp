@props([
    "id",
    "active"   => false,
    "disabled" => false
])

<li {{ $attributes->class(["nav-item"]) }} role="presentation">
    <button 
        id="{{ $id }}_button"
        class="nav-link {{ $active ? 'active' : '' }}" 
        data-bs-toggle="tab" 
        data-bs-target="#{{ $id }}" 
        type="button" 
        role="tab" 
        {{ $disabled === true ? 'disabled' : '' }}
        aria-controls="{{ $id }}" 
        aria-selected="true">
        {{ $slot }}
    </button>
</li>