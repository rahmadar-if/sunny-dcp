@props([
	"value"      => null,
	"whitelist"  => [],
	"maxTags"    => null,
	"mode"       => null, // mix
	"pattern"    => null, // for mixed mode, e.g. @|#
	"duplicates" => false,
	"placeholder" => "Type and press enter",
	"size"       => null, // sm, lg
	"lazy"       => false,
	"ignore"     => false,
	"attribute"  => []
])

@php
	$encodedWhitelist = !empty($whitelist) ? rawurlencode(json_encode($whitelist)) : null;
	$isMixed = $mode === 'mix';
@endphp

@if($isMixed)
	<textarea {{
		$attributes->merge([
			"solar-ui"  => "input:tag",
			"mode"      => $mode,
			"pattern"   => $pattern,
			"whitelist" => $encodedWhitelist,
			"max-tags"  => $maxTags,
			"lazy"      => $lazy === true,
			"ignore"    => $ignore === true,
			"placeholder" => $placeholder
		])
		->merge($duplicates ? ["duplicates" => true] : [])
		->merge($attribute)
		->class([
			"form-control",
			"form-control-{$size}" => !is_null($size) && in_array($size, ["sm", "lg"]),
		])
	}}>{{ is_array($value) ? json_encode($value) : $value }}</textarea>
@else
	<input {{
		$attributes->merge([
			"solar-ui"  => "input:tag",
			"whitelist" => $encodedWhitelist,
			"max-tags"  => $maxTags,
			"lazy"      => $lazy === true,
			"ignore"    => $ignore === true,
			"placeholder" => $placeholder,
			"value"     => is_array($value) ? json_encode($value) : $value
		])
		->merge($duplicates ? ["duplicates" => true] : [])
		->merge($attribute)
		->class([
			"form-control",
			"form-control-{$size}" => !is_null($size) && in_array($size, ["sm", "lg"]),
		])
	}}>
@endif

