@props([
    "menus" => [] // ["id", "name", "url", "icon", "route_name", "sub_menu", "category"]
])
@aware(['__level'])
@php
    $__level = isset($__level) ? $__level + 1 : 1;
    $currentRouteName = Route::currentRouteName();
@endphp

@foreach ($menus as $menu)
    @php
        if($menu instanceof \Illuminate\Support\Collection || $menu instanceof \Solaris\Core\Models\Menu) {
            $menu = $menu->toArray();
        } else if(is_object($menu)) {
            $menu = (array)$menu;
        }

        $hasSubmenu    = !empty($menu['sub_menu']);
        $active        = \Solaris\Core\Services\MenuService::isActive($menu, $currentRouteName);
        $submenuActive = false;
        if($hasSubmenu) {
            $submenuActive = \Solaris\Core\Services\MenuService::subMenuIsActive($menu['sub_menu'], $currentRouteName);
        }

        $url = empty($menu['url']) ? null : url($menu['url']);
    @endphp

    @if ($menu["is_category"] ?? false)
        <li class="slide__category"><span class="category-name">{{ $menu["name"] }}</span></li>
    @else
        @if (!$hasSubmenu)
            <x-core::sidebar-menu-item :url="$url" :name="$menu['name']" :icon="$menu['icon']" :active="$active" :root="empty($menu['parent_id'])" />
        @else
            <x-core::sidebar-menu-item :url="$url" :name="$menu['name']" :icon="$menu['icon']" submenu :active="$submenuActive" :root="empty($menu['parent_id'])">
                <ul class="slide-menu child{{ $__level }}">
                    <x-core::sidebar-menu :menus="$menu['sub_menu']" :__level="$__level" />
                </ul>
            </x-core::sidebar-menu-item>
        @endif
    @endif
@endforeach