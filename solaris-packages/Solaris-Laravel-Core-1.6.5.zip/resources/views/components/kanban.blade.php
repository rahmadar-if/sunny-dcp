@props([
    "id",
    "model",
    "columns"      => [],
    "length"       => 10,
    "lazy"         => false,
    "ignore"       => false,
    "new"          => true,
    "newIcon"      => "ri-add-line",
    "newExcept"    => [],
    "noDragBoards" => [],
    "noDropBoards" => [],
    "view"         => true,
    "edit"         => true,
    "delete"       => true,
    "folder"       => false,
    "search"       => true,
    "refresh"      => true
])

@php
    
    $isNew     = $new === true || !empty($new) ? true : false;
    $newLabel  = "New";
    $newAction = "";
    if($isNew && is_string($new)) {
        [$label, $newAction] = explode('@', $new . '@');
        $newLabel = empty($label) ? $newLabel : $label;
    }

    $wrapperAttrs = new \Illuminate\View\ComponentAttributeBag(
        collect($attributes->whereStartsWith('wrapper:')->all())
            ->mapWithKeys(fn($value, $key) => [Str::after($key, 'wrapper:') => $value])
            ->all()
    );
    $wrapperAttrs = $wrapperAttrs->merge([
        "id"         => $id."_wrapper",
        "solar-id"   => $id,
        "solar-ui"   => "kanban",
        "model"      => $model,
        "columns"    => is_string($columns) ? $columns : (is_array($columns) && !empty($columns) ? json_encode($columns) : null),
        "length"     => is_numeric($length) ? $length : 10,
        "lazy"       => $lazy,
        "ignore"     => $ignore,
        "new"        => $isNew ? $newLabel : false,
        "new-action" => $newAction,
        "new-icon"   => $newIcon,
        "new-except"      => !empty($newExcept) ? json_encode($newExcept) : null,
        "no-drag-boards"  => !empty($noDragBoards) ? json_encode($noDragBoards) : null,
        "no-drop-boards"  => !empty($noDropBoards) ? json_encode($noDropBoards) : null,
        "view"       => $view,
        "edit"       => $edit,
        "delete"     => $delete
    ]);

@endphp

<div {{ $wrapperAttrs }}>

    @if (isset($header))
        {{ $header }}
    @endif

    <div class="d-flex justify-content-between align-items-center mb-3">
        <div class="d-flex align-items-center gap-2">
            @if (isset($preLeftAction))
                {{ $preLeftAction }}
            @endif

            @if ($folder === true)
                <x-core::folder id="{{ $id }}_kanban_folder" :model="$model" ignore/>
            @endif
            
            @if (isset($leftAction))
                {{ $leftAction }}
            @endif
        </div>

        <div class="d-flex align-items-center gap-2">
            @if (isset($preRightAction))
                {{ $preRightAction }}
            @endif

            @if ($search === true)
                <x-core::search-input id="{{ $id }}_kanban_search" disabled size="sm" placeholder="Search" ignore />
            @endif

            @if ($refresh === true)
                <x-core::refresh-button id="{{ $id }}_kanban_refresh" disabled size="sm" color="light" ignore />
            @endif

            @if (isset($rightAction))
                {{ $rightAction }}
            @endif
        </div>
    </div>

    <div {{ 
        $attributes->merge([
            "id" => $id,
        ])
        ->class(["TASK-kanban-board"])
    }}>
    </div>

    @if (isset($footer))
        {{ $footer }}
    @endif

</div>