@props([
    "label" => "#"
])

<x-core::table-column name="_autoincrement" :attributes="$attributes">
    {{ $label }}
</x-core::table-column>