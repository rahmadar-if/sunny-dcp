@props([
	"id",
	"chunk_size"      => 2000000,
	"max_file_size"   => null,
	"upload_message"  => "Drop files here or click to upload.",
	"multiple"        => true,
	"auto"            => true,
	"url"             => null,
	"param_name"	  => "file",
	"table_name"      => null,
	"record_id"       => null,
	"accept"          => null,
	"ignore"          => false,
	"lazy"            => false,
	"size"            => "md"
])

<div {{
	$attributes->merge([
		"id"            => $id,
		"solar-ui"      => "dropzone",
		"chunk-size"    => $chunk_size,
		"multiple"      => $multiple,
		"auto"          => $auto,
        "max-file-size" => $max_file_size,
        "upload-url"    => $url,
		"param-name" 	=> $param_name,
        "table-name"    => $table_name,
        "record-id"     => $record_id,
        "accept-files"  => $accept,
        "ignore"        => $ignore,
        "lazy"          => $lazy
	])
	->class([
		"dropzone mb-3",
		"dropzone-sm" => $size === "sm"
	])
}}>
	<div class="fallback">
		<input name="file" type="file" {{ $multiple ? 'multiple="multiple"' : '' }}>
	</div>
	<div class="dz-message needsclick">
		<h6>{{ $upload_message }}</h6>
	</div>
</div>
