@props([
	"id",
	"variant" => "tab-style-6",
])

<div id="{{ $id }}" solar-ui="tab">
	<ul {{ 
		$attributes->class([
			"nav nav-tabs",
			$variant => !empty($variant)
		]) 
	}} id="{{ $id }}_nav" role="tablist">
		@if (isset($nav))
			{{ $nav }}
		@endif
	</ul>
	<div class="tab-content" id="{{ $id }}_content">
		@if (isset($content))
			{{ $content }}
		@endif
	</div>
</div>