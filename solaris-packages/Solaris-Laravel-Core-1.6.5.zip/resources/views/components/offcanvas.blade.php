@props([
    'id',
    'title'          => null,
    'staticBackdrop' => true,
    'bodyScroll'     => false,
    'position'       => 'left', // left, right, top, bottom
    'close'          => true
])

@php
    
    $headerAttrs = new \Illuminate\View\ComponentAttributeBag(
        collect($attributes->whereStartsWith('header:')->all())
            ->mapWithKeys(fn($value, $key) => [Str::after($key, 'header:') => $value])
            ->all()
    );
    $headerAttrs = $headerAttrs->class([
        "offcanvas-header border-bottom border-block-end-dashed"
    ]);

    $bodyAttrs = new \Illuminate\View\ComponentAttributeBag(
        collect($attributes->whereStartsWith('body:')->all())
            ->mapWithKeys(fn($value, $key) => [Str::after($key, 'body:') => $value])
            ->all()
    );
    $bodyAttrs = $bodyAttrs->class([
        "offcanvas-body"
    ]);

    $placement = match ($position) {
        'left'   => 'start',
        'right'  => 'end',
        'top'    => 'top',
        'bottom' => 'bottom'
    };

@endphp

<div {{ 
    $attributes->merge([
        'id'                => $id,
        'data-bs-backdrop'  => $staticBackdrop === true ? 'static' : null,
        'data-bs-scroll'    => $bodyScroll === true ? 'true' : null,
        'tabindex'          => '-1',
        'aria-labelledby'   => $id.'Label'
    ])
    ->class([
        "offcanvas offcanvas-".$placement
    ])
}}>
    <div {{ $headerAttrs }}>
        @if (!empty($title))
        <h5 class="offcanvas-title" id="{{ $id }}Label">{{ $title }}</h5>
        @endif

        @if($close)
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        @endif
        
        @if(isset($header))
            {{ $header }}
        @endif
    </div>

    <div {{ $bodyAttrs }}>
        {{ $slot }}
    </div>
</div>