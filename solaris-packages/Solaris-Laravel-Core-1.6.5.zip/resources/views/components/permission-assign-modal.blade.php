@props([
    "id" => "permission-assign-modal",
])

{{-- Single type, so no radio group — BaseAssign skips them too --}}
<x-core::list-modal :id="$id" title="Assign User" empty_text="No users found" />
