@props([
    "id" => "ai-assign-modal",
])

<x-core::list-modal :id="$id" title="Assign AI Access" empty_text="No data found">
    <x-slot:header>
        <div class="btn-group btn-group-sm w-100" role="group">
            <input type="radio" class="btn-check" name="{{ $id }}_type" id="{{ $id }}-type-role" value="role" checked>
            <label class="btn btn-outline-primary" for="{{ $id }}-type-role">Role</label>

            <input type="radio" class="btn-check" name="{{ $id }}_type" id="{{ $id }}-type-permission" value="permission">
            <label class="btn btn-outline-primary" for="{{ $id }}-type-permission">Permission</label>
        </div>
    </x-slot>
</x-core::list-modal>
