@props([
    'id'           => null,
    'length'       => 6,
    'mode'         => 'numeric', // numeric, alphanumeric
    'hidden'       => false,
    'resendUrl'    => null,
    'resendMethod' => 'POST',
])

<div
    id="{{ $id }}"
    solar-ui="input:otp"
    data-length="{{ $length }}"
    data-mode="{{ $mode }}"
    @if ($resendUrl)
        data-resend-url="{{ $resendUrl }}"
        data-resend-method="{{ $resendMethod }}"
    @endif
    {{ $attributes->class([
        'd-flex gap-2 justify-content-center',
        'd-none' => $hidden,
    ]) }}
>
    @for ($i = 0; $i < $length; $i++)
    <input
        type="text"
        maxlength="1"
        inputmode="{{ $mode === 'numeric' ? 'numeric' : 'text' }}"
        autocomplete="one-time-code"
        class="form-control text-center fw-bold fs-18 p-0"
        style="width: 44px; height: 50px; border-radius: 10px;"
    >
    @endfor

    @if ($resendUrl)
    <div class="w-100 text-center mt-3">
        <span class="fs-12 text-muted">Didn't receive it? </span>
        <x-core::button data-otp-resend variant="link" size="sm" class="p-0 fs-12" disabled>
            Resend code
        </x-core::button>
    </div>
    @endif
</div>
