@props([
    "id",
    "source"         => null,
    "upload_to"      => null,
    "param_name"     => "banner",
    "max"            => 5,
    "preview_width"  => null,
    "preview_height" => null,
    "view_only"      => false
])

@php
    $imgSrc = Vite::asset(SolarHelper::config('application.assets.profile_background'));
    $isImgAttachment = false;
    if (!empty($source) && \Illuminate\Support\Str::isUuid($source)) {
        $imgSrc = route('core.images', ['id' => $source]);
        $isImgAttachment = true;
    } else if (!empty($source)) {
        $imgSrc = $source;
    }

    $isPreview = $isImgAttachment && !is_null($preview_width) && !is_null($preview_height);
@endphp

<div id="{{ $id }}" {{ $attributes->class(["profile-banner-img"]) }} solar-ui="profile-banner">

    @if ($isPreview)
        <a href="{{ route('core.images', ['id' => $source]) }}" data-pswp-width="{{ $preview_width }}" data-pswp-height="{{ $preview_height }}" target="_blank">
    @endif

    <img src="{{ $imgSrc }}" class="card-img-top" alt="profile-banner">

    @if ($isPreview)
        </a>
    @endif
    
    @if (!$view_only)
    <div class="profile-banner-upload">
        <input id="{{ $id }}_input"
               type="file"
               accept="image/png, image/jpeg"
               upload-to="{{ $upload_to }}"
               max="{{ $max }}"
               param-name="{{ $param_name }}">
        <label for="{{ $id }}_input">
            <span>
                <i class="ri-image-edit-line"></i>
                Change Banner
            </span>
        </label>
    </div>
    @endif
</div>
