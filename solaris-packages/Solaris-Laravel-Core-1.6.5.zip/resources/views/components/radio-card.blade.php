@props([
    'id',
    'name'        => null,
    'bind'        => null,
    'value'       => null,
    'label'       => null,
    'description' => null,
    'icon'        => null,
    'color'       => 'primary',
    'checked'     => false,
    'hidden'      => false,
    'lazy'        => false,
    'ignore'      => false,
    'disabled'    => false,
])

@php
    if (!empty($id) && empty($bind) && str_contains($id, ':')) {
        $splitId = explode(':', $id);
        $id      = $splitId[0];
        $bind    = $splitId[1];
    }

    $colors     = ['primary', 'secondary', 'success', 'danger', 'info', 'warning', 'light', 'dark'];
    $validColor = in_array($color, $colors);

    $inputAttr = $attributes
        ->class(['flex-shrink-0 mt-1'])
        ->merge([
            'solar-ui'   => 'input:radio-card',
            'solar-bind' => !empty($bind) ? $bind : $id,
            'lazy'       => $lazy === true,
            'ignore'     => $ignore === true,
            'checked'    => $checked === true,
            'disabled'   => $disabled === true,
            'name'       => $name,
            'value'      => $value,
        ])
        ->except(['id', 'type']);

    $wrapAttr = new \Illuminate\View\ComponentAttributeBag(
        collect($attributes->whereStartsWith('wrap:')->all())
            ->mapWithKeys(fn($v, $k) => [\Illuminate\Support\Str::after($k, 'wrap:') => $v])
            ->all()
    );
    $wrapAttr = $wrapAttr
        ->merge(['data-card-color' => $color])
        ->class([
            'card-option-check card-option-label d-flex align-items-start gap-3 p-3 border rounded-3 cursor-pointer',
            "border-{$color} bg-{$color}-subtle" => $checked && $validColor,
            'd-none' => $hidden === true,
        ]);

    $titleClass = 'fw-semibold fs-14 card-option-title ' . (is_null($description) ? 'mb-0' : 'mb-1');
    $iconColor  = $validColor ? "text-{$color}" : '';
@endphp

<label {{ $wrapAttr }}>
    <input {{ $inputAttr }} type="radio" id="{{ $id }}">
    <div>
        @if (!is_null($label))
        <p class="{{ $titleClass }}">
            @if (!is_null($icon))<i class="{{ $icon }} me-1 {{ $iconColor }}"></i>@endif{{ $label }}
        </p>
        @endif
        @if (!is_null($description))
        <p class="mb-0 fs-12 text-muted">{{ $description }}</p>
        @endif
        {{ $slot }}
    </div>
</label>
