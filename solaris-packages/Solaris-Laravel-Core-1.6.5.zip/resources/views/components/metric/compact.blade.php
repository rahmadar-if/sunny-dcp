@props([
    'id'               => null,
    'title',
    'tooltip'          => null,
    'icon'             => 'ri-bar-chart-fill',
    'color'            => 'primary',
    'value'            => null,
    'changeTitle'      => null,
    'changeValue'      => null,
    'changeType'       => null,
    'numeral'          => false,
    'prefix'           => null,
    'decimal'          => 2,
    'decimalSeparator' => ',',
    'thousandSeparator' => '.',
])

@php
    $changeUpIcon   = 'ri-arrow-left-up-line';
    $changeDownIcon = 'ri-arrow-left-down-line';
    $changeIcon     = $changeType == 'up' ? $changeUpIcon : ($changeType == 'down' ? $changeDownIcon : null);
    $changeColor    = $changeType == 'up' ? 'success' : ($changeType == 'down' ? 'danger' : 'primary');
@endphp

<x-core::card :color="$color" class="overflow-hidden" {{ $attributes }}>
    <div solar-metric="content">
        <div class="d-flex justify-content-between">
            <div>
                <div class="flex-fill fs-14 text-muted">
                    {{ $title }}
                    @if ($tooltip)
                    <i class="ri-question-line fs-11 text-muted cursor-pointer" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="{{ $tooltip }}"></i>
                    @endif
                </div>
                <div solar-metric="value" class="fs-22 fw-medium mb-2">
                    @if ($numeral)
                    <x-core::numeral id="{{ $id }}-value" ignore size-class="" :value="$value" :prefix="$prefix" :decimals="$decimal" :decimal-separator="$decimalSeparator" :thousand-separator="$thousandSeparator" />
                    @else
                    {{ $value }}
                    @endif
                </div>
            </div>
            <div class="avatar avatar-md bg-{{ $color }}-transparent">
                <i class="{{ $icon }} fs-20"></i>
            </div>
        </div>
        <div class="d-flex align-items-end justify-content-between">
            @if (!is_null($changeValue))
            <div class="d-flex flex-column gap-1 align-items-center">
                <span
                    solar-metric="change-badge"
                    class="badge bg-{{ $changeColor }}-transparent text-{{ $changeColor }} rounded-pill d-flex align-items-center fs-11"
                    data-up="text-success bg-success-transparent"
                    data-down="text-danger bg-danger-transparent"
                >
                    @if ($changeIcon)
                    <i solar-metric="change-icon" class="{{ $changeIcon }} fs-11" data-up="{{ $changeUpIcon }}" data-down="{{ $changeDownIcon }}"></i>
                    @endif
                    <span solar-metric="change-value">{{ $changeValue }}</span>
                </span>
                <p solar-metric="change-title" class="fs-11 text-muted mb-0">{{ $changeTitle }}</p>
            </div>
            @endif
            <div solar-metric="chart"></div>
        </div>
    </div>
</x-core::card>
