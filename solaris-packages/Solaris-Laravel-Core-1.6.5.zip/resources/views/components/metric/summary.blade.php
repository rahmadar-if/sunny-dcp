@props([
    'id'               => null,
    'title',
    'tooltip'          => null,
    'icon'             => 'ri-bar-chart-fill',
    'color'            => 'primary',
    'value'            => null,
    'changeTitle'      => null,
    'changeValue'      => null,
    'changeType'       => null,
    'numeral'          => false,
    'prefix'           => null,
    'decimal'          => 2,
    'decimalSeparator' => ',',
    'thousandSeparator' => '.',
])

@php
    $changeUpIcon   = 'ti ti-trending-up';
    $changeDownIcon = 'ti ti-trending-down';
    $changeIcon     = $changeType == 'up' ? $changeUpIcon : ($changeType == 'down' ? $changeDownIcon : null);
    $changeColor    = $changeType == 'up' ? 'success' : ($changeType == 'down' ? 'danger' : 'primary');
@endphp

<x-core::card :color="$color" class="crm-card" {{ $attributes }}>
    <div solar-metric="content">
        <div class="d-flex justify-content-between align-items-start mb-2 gap-2">
            <div class="p-2 border border-{{ $color }} border-opacity-10 bg-{{ $color }}-transparent rounded">
                <span class="avatar avatar-md bg-{{ $color }} svg-white">
                    <i class="{{ $icon }} fs-16"></i>
                </span>
            </div>
            <div solar-metric="chart"></div>
        </div>
        <p class="flex-fill text-muted fs-14 mb-0">
            {{ $title }}
            @if ($tooltip)
            <i class="ri-question-line fs-11 text-muted cursor-pointer" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="{{ $tooltip }}"></i>
            @endif
        </p>
        <div class="d-flex align-items-center justify-content-between mt-1">
            <h4 solar-metric="value" class="mb-0">
                @if ($numeral)
                <x-core::numeral id="{{ $id }}-value" ignore size-class="" :value="$value" :prefix="$prefix" :decimals="$decimal" :decimal-separator="$decimalSeparator" :thousand-separator="$thousandSeparator" />
                @else
                {{ $value }}
                @endif
            </h4>

            @if (!is_null($changeValue))
            <div class="d-flex flex-column align-items-center gap-1">
                <span
                    solar-metric="change-badge"
                    class="badge bg-{{ $changeColor }}-transparent text-{{ $changeColor }} rounded-pill d-flex align-items-center fs-11"
                    data-up="text-success bg-success-transparent"
                    data-down="text-danger bg-danger-transparent"
                >
                    @if ($changeIcon)
                    <i solar-metric="change-icon" class="{{ $changeIcon }} fs-11" data-up="{{ $changeUpIcon }}" data-down="{{ $changeDownIcon }}"></i>
                    @endif
                    <span solar-metric="change-value">{{ $changeValue }}</span>
                </span>
                <p solar-metric="change-title" class="fs-11 text-muted mb-0">{{ $changeTitle }}</p>
            </div>
            @endif
        </div>
    </div>
</x-core::card>
