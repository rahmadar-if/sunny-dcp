@props([
    'id'               => null,
    'title',
    'description'      => null,
    'subtitle'         => null,
    'tooltip'          => null,
    'icon'             => 'ri-bar-chart-fill',
    'color'            => 'primary',
    'value'            => null,
    'changeTitle'      => null,
    'changeValue'      => null,
    'changeType'       => null,
    'numeral'          => false,
    'prefix'           => null,
    'decimal'          => 2,
    'decimalSeparator' => ',',
    'thousandSeparator' => '.',
])

@php
    $changeUpIcon   = 'ri-arrow-left-up-line';
    $changeDownIcon = 'ri-arrow-left-down-line';
    $changeIcon     = $changeType == 'up' ? $changeUpIcon : ($changeType == 'down' ? $changeDownIcon : null);
    $changeColor    = $changeType == 'up' ? 'success' : ($changeType == 'down' ? 'danger' : 'primary');
@endphp

<x-core::card :color="$color" class="overflow-hidden" {{ $attributes }}>
    <div class="d-flex align-items-center gap-3 mb-2 flex-wrap">
        <div class="lh-1">
            <div class="avatar avatar-md bg-{{ $color }}-transparent avatar-rounded">
                <div class="avatar avatar-sm avatar-rounded bg-{{ $color }} svg-white">
                    <i class="{{ $icon }} fs-18"></i>
                </div>
            </div>
        </div>
        <div class="flex-fill">
            <span class="d-block fw-medium fs-14">
                {{ $title }}
                @if ($tooltip)
                <i class="ri-question-line fs-11 text-muted cursor-pointer" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="{{ $tooltip }}"></i>
                @endif
            </span>
            @if ($description)
            <span class="d-block text-muted fs-12">{{ $description }}</span>
            @endif
        </div>

        @if (!is_null($changeValue))
        <div class="text-end">
            <span solar-metric="change-title" class="fs-12 text-muted d-block">{{ $changeTitle }}</span>
            <span
                solar-metric="change-badge"
                class="badge bg-{{ $changeColor }}-transparent text-{{ $changeColor }} rounded-pill d-flex align-items-center fs-11"
                data-up="text-success bg-success-transparent"
                data-down="text-danger bg-danger-transparent"
            >
                @if ($changeIcon)
                <i solar-metric="change-icon" class="{{ $changeIcon }} fs-11" data-up="{{ $changeUpIcon }}" data-down="{{ $changeDownIcon }}"></i>
                @endif
                <span solar-metric="change-value">{{ $changeValue }}</span>
            </span>
        </div>
        @endif
    </div>
    <div class="d-flex align-items-end justify-content-between gap-1">
        <div>
            @if ($subtitle)
            <span class="fs-11 text-muted">{{ $subtitle }}</span>
            @endif
            <span solar-metric="value" class="fs-20 fw-semibold d-block">
                @if ($numeral)
                <x-core::numeral id="{{ $id }}-value" ignore size-class="" :value="$value" :prefix="$prefix" :decimals="$decimal" :decimal-separator="$decimalSeparator" :thousand-separator="$thousandSeparator" />
                @else
                {{ $value }}
                @endif
            </span>
        </div>
        <div solar-metric="chart"></div>
    </div>
</x-core::card>
