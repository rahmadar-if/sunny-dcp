@props([
    'id'               => null,
    'title',
    'tooltip'          => null,
    'value'            => null,
    'changeTitle'      => null,
    'changeValue'      => null,
    'changeType'       => null,
    'numeral'          => false,
    'prefix'           => null,
    'decimal'          => 2,
    'decimalSeparator' => ',',
    'thousandSeparator' => '.',
])

@php
    $changeUpIcon   = 'ri-arrow-up-s-fill';
    $changeDownIcon = 'ri-arrow-down-s-fill';
    $changeIcon     = $changeType == 'up' ? $changeUpIcon : ($changeType == 'down' ? $changeDownIcon : null);
    $changeColor    = $changeType == 'up' ? 'success' : ($changeType == 'down' ? 'danger' : 'primary');
@endphp

<x-core::card {{ $attributes }}>
    <p solar-metric="title" class="flex-fill text-muted fs-14 mb-0">
        {{ $title }}
        @if ($tooltip)
        <i class="ri-question-line fs-11 text-muted cursor-pointer" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="{{ $tooltip }}"></i>
        @endif
    </p>
    <div class="d-flex align-items-center justify-content-between">
        <div solar-metric="value" class="fs-22 fw-medium mb-0 d-flex align-items-center">
            @if ($numeral)
            <x-core::numeral id="{{ $id }}-value" ignore size-class="" :value="$value" :prefix="$prefix" :decimals="$decimal" :decimal-separator="$decimalSeparator" :thousand-separator="$thousandSeparator" />
            @else
            {{ $value }}
            @endif
        </div>

        @if (!is_null($changeValue))
        <div class="d-flex align-items-center flex-column">
            <span
                solar-metric="change-badge"
                class="badge bg-{{ $changeColor }}-transparent text-{{ $changeColor }} rounded-pill d-flex align-items-center fs-11 me-0 mb-1"
                data-up="text-success bg-success-transparent"
                data-down="text-danger bg-danger-transparent"
            >
                @if ($changeIcon)
                <i solar-metric="change-icon" class="{{ $changeIcon }} fs-11" data-up="{{ $changeUpIcon }}" data-down="{{ $changeDownIcon }}"></i>
                @endif
                <span solar-metric="change-value">{{ $changeValue }}</span>
            </span>
            <p solar-metric="change-title" class="fs-11 text-muted mb-0">{{ $changeTitle }}</p>
        </div>
        @endif
    </div>
</x-core::card>
