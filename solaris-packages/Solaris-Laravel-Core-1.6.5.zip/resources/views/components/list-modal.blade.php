@props([
    "id",
    "title"      => null,
    "empty_text" => "No data found",
])

@push('styles')
    <style>
        #{{$id}} .list-container {
            max-height: 50vh;
            overflow-y: auto;
        }

        /* The theme hides scrollbar thumbs until hover; this list needs its own visible one
           so there is a grabbable indicator that more items exist below. */
        #{{$id}} .list-container::-webkit-scrollbar {
            width: 0.5rem !important;
        }

        #{{$id}} .list-container::-webkit-scrollbar-track {
            background: var(--default-background);
            border-radius: 0.25rem;
        }

        #{{$id}} .list-container::-webkit-scrollbar-thumb {
            background: var(--default-border);
            border-radius: 0.25rem;
        }

        #{{$id}} .list-container::-webkit-scrollbar-thumb:hover {
            background: var(--text-muted);
        }

        #{{$id}} .list-container {
            scrollbar-width: thin;
        }
    </style>
@endpush

{{-- No modal-dialog-scrollable: the list keeps the only scroll area, otherwise the body
     scrolls too and neither container owns the position. --}}
<x-core::modal
    id="{{ $id }}"
    body:class="p-3 p-lg-4"
    animation="scale"
    static center>

    {{-- No data-bs-dismiss: closing is routed through JS so the caller can hold it back --}}
    <x-slot:header class="border-0">
        <button type="button" class="btn-close" id="{{ $id }}_close" aria-label="Close"></button>
    </x-slot>

    @if (!empty($title))
        <div class="text-center mb-3">
            <h4 class="mb-2">{{ $title }}</h4>
        </div>
    @endif

    <div class="p-lg-2">
        <div class="d-flex align-items-center gap-2 p-2">
            <x-core::search-input id="{{ $id }}_search" wrap:class="w-100" disabled placeholder="Search" />
            <x-core::refresh-button id="{{ $id }}_refresh" disabled color="light" />
        </div>

        @isset($header)
            <div class="px-2 pt-2">
                {{ $header }}
            </div>
        @endisset

        <div class="mt-3 vstack gap-3 list-container p-2"></div>
    </div>

    <div class="text-center py-5 d-none empty-state">
        <i class="bi bi-search text-muted" style="font-size: 3rem;"></i>
        <p class="text-muted mt-2 mb-0">{{ $empty_text }}</p>
    </div>

    <x-slot:footer>
        {{ $footer ?? '' }}
    </x-slot>

</x-core::modal>
