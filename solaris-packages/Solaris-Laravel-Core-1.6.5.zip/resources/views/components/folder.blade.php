@props([
    "id",
    "model",
    "lazy"   => false,
    "ignore" => false
])

<div {{ 
    $attributes
        ->merge([
            "solar-id" => $id,
            "solar-ui" => "folder",
            "lazy"     => $lazy,
            "ignore"   => $ignore
        ])
        ->class(["d-flex gap-1 align-items-center"])
}}>
    <x-core::button 
        id="{{ $id }}" 
        size="sm" 
        variant="outline" 
        color="light"
        disabled 
        ignore>
        <span class="ri-folders-line me-1"></span>Folders
    </x-core::button>
    
    <span id="{{ $id }}_selected" class="badge bg-outline-primary d-none"></span>
</div>

@php
    use Solaris\Core\Services\ModelBinding\ModelBinding;
    $modelBinding = new ModelBinding(
        $model, 
        fn($model, $scope) => true, 
        fn($controller, $method) => true
    );
    $model = $modelBinding->getModelString();
@endphp

@push('offcanvas-content')
    <x-core::offcanvas title="Folders" id="{{ $id }}_offcanvas">
        <x-core::table 
            id="{{ $id }}_offcanvas_list" 
            model="Folder@list({{ $model }})"
            :card_wrapper="false"
            :folder="false"
            :select_all="false"
            ignore lazy
            extend_columns="created_by.name">
            <x-slot:column class="d-none">
                <x-core::table-column data="name" searchable>Name</x-core::table-column>
                <x-core::table-column cell_class="d-none" data="description" searchable>Description</x-core::table-column>
            </x-slot>
        </x-core::table>
    </x-core::offcanvas>
@endpush

@push('modal-content')
    <style>
    .filter-item.merge-target {
        background-color: rgba(var(--primary-rgb), 0.1);
        outline: 2px dashed var(--primary);
        outline-offset: 2px;
        border-radius: 0.375rem;
    }
    </style>

    <x-core::modal-form 
        id="{{ $id }}_modal" 
        title="Define your folder" 
        model="Folder"
        ignore 
        size="xl"
        :center="false">
        
        <div class="row">
            <div class="col-6">
                <x-core::field id="{{ $id }}_modal_name:name" label="Name" required>
                    <x-core::input placeholder="Give your folder a name" />
                </x-core::field>
            </div>

            <div class="col-6">
                <x-core::field id="{{ $id }}_modal_description:description" label="Description">
                    <x-core::input placeholder="Add description to make it clearer"/>
                </x-core::field>
            </div>
        </div>

        <div class="filter-container"></div>

        <div class="d-flex gap-2 mt-2">
            <x-core::button id="{{ $id }}_modal_add_filter" color="secondary" size="sm">
                <i class="ri-add-line me-1"></i>Add filter
            </x-core::button>
            <x-core::button id="{{ $id }}_modal_add_group" color="secondary" size="sm">
                <i class="ri-stack-line me-1"></i>Add group
            </x-core::button>
        </div>

    </x-core::modal-form>
@endpush