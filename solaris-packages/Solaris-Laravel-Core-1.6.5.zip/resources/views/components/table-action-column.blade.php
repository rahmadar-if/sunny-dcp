@props([
    "view"    => true,
    "edit"    => true,
    "delete"  => true,
    "discard" => false,
    "group"   => true,
    "label"   => ""
])

@php
    $customAttrs = [];
    if ($view) $customAttrs['action-view'] = true;
    if ($edit) $customAttrs['action-edit'] = true;
    if ($delete) $customAttrs['action-delete'] = true;
    if ($discard) $customAttrs['action-discard'] = true;
    if ($group) $customAttrs['action-group'] = true;
@endphp

<x-core::table-column name="_action" {{ $attributes->merge($customAttrs) }}>
    {{ $label }}
</x-core::table-column>