@props([
    "mode"   => "date", // date, datetime, time
    "range"  => false,
    "lazy"   => false,
    "ignore" => false,
    "inline" => false,
])

<x-core::input {{ $attributes }} solar-ui="input:{{ $mode }}" :lazy="$lazy" :ignore="$ignore" :range="$range" :inline="$inline" />