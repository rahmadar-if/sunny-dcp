@props([
    "id"                 => null,
    "type"               => "text",
    "size"               => null, // sm, lg
    "rounded"            => false,
    "square"             => false,
    "hidden"             => false,
    "attribute"          => [],
    "lazy"               => false,
    "ignore"             => false,
    "number"             => false,
    "numeric"            => false,
    "thousand_separator" => ".",
    "decimal_separator"  => ",",
    "decimal"            => 0,
    "uppercase"          => false,
    "lowercase"          => false,
    "prefix"             => null,
    "credit_card"        => null,
    "phone"              => null,
    "blocks"             => null,
    "delimiters"         => null
])

@php
    if(!empty($id) && empty($bind) && str_contains($id, ":")) {
        $splitId = explode(":", $id);
        $id      = $splitId[0];
        $bind    = $splitId[1];
    }

    $isNumber      = $number === true;
    $isPhoneNumber = isset($phone) && !empty($phone) ? true : false;
    $isCreditCard  = $credit_card === true;
    $isNumeric     = $numeric === true;
    
    $decimalScale     = is_numeric($decimal) ? (int) $decimal : 2;

    $isCanNumber      = $isNumber && !$isPhoneNumber && !$isCreditCard && !$isNumeric;
    $isCanPhoneNumber = $isPhoneNumber && !$isNumber && !$isCreditCard && !$isNumeric;
    $isCanCreditCard  = $isCreditCard && !$isNumber && !$isPhoneNumber && !$isNumeric;
    $isCanNumeric     = $isNumeric && !$isCreditCard && !$isNumber && !$isPhoneNumber;
    $isCanPrefix      = !$isPhoneNumber && !$isCreditCard && !empty($prefix);
    $isCanUpper       = $uppercase === true && $lowercase === false;
    $isCanLower       = $lowercase === true && $uppercase === false;
    $isCanBlocks      = !$isNumber && !$isPhoneNumber && !$isCreditCard && !empty($blocks);
    $isCanDelimiters  = !$isNumber && !$isPhoneNumber && !empty($delimiters);
@endphp

<input {{
    $attributes->merge([
        "id"          => $id,
        "type"        => $type,
        "solar-ui"    => "input",
        "solar-bind"  => !empty($bind) ? $bind : $id,
        "lazy"        => $lazy === true,
        "ignore"      => $ignore === true,
        "mask"        => $isCanNumber || $isCanUpper || $isCanLower || $isCanPhoneNumber || $isCanCreditCard || $isCanPrefix || $isCanBlocks || $isCanDelimiters || $isCanNumeric,
        "number"      => $isCanNumber,
        "decimal"     => $isCanNumber ? $decimalScale : null,
        "uppercase"   => $isCanUpper,
        "lowercase"   => $isCanLower,
        "prefix"      => $isCanPrefix ? $prefix : null,
        "credit-card" => $isCanCreditCard,
        "phone"       => $isCanPhoneNumber ? (is_string($phone) ? $phone : (is_bool($phone) ? "ID" : null)) : null,
        "blocks"      => $isCanBlocks ? $blocks : null,
        "delimiters"  => $isCanDelimiters ? $delimiters : null,
        "numeric"     => $isCanNumeric,
        "thousand-separator" => $isCanNumber && !empty($thousand_separator) ? $thousand_separator : null,
        "decimal-separator"  => $isCanNumber && !empty($decimal_separator) ? $decimal_separator : null,
    ])
    ->merge($attribute)
    ->class([
        "form-control",
        "form-control-{$size}" => !is_null($size) && in_array($size, ["sm", "lg"]),
        "rounded-pill"         => $rounded === true && $square === false,
        "rounded-0"            => $rounded === false && $square === true,
        "d-none"               => $hidden === true
    ])
}}>