@props([
    "id",
    "color"          => "primary",
    "variant"        => "outline",
    "size"           => "md",
    "ignore"         => false,
    "disabled"       => false,
    "default_active" => "current-year", // current-year, previous-year, current-week, last-week, current-month, previous-month, last-3-months, last-6-months
])

@php
    $isActive = function($class) use($default_active) {
        return $class == $default_active ? "active" : "";
    };
    $text = match ($default_active) {
        "previous-year"  => "01 Jan " . date('Y', strtotime('-1 year')) . " - 31 Dec " . date('Y', strtotime('-1 year')),
        "current-month"  => date('01 M Y') . " - " . date('t M Y'),
        "previous-month" => date('01 M Y', strtotime('first day of previous month')) . " - " . date('t M Y', strtotime('last day of previous month')),
        "last-3-months"  => date('01 M Y', strtotime('first day of -2 months')) . " - " . date('t M Y'),
        "last-6-months"  => date('01 M Y', strtotime('first day of -5 months')) . " - " . date('t M Y'),
        "current-week"   => date('d M Y', strtotime('monday this week')) . " - " . date('d M Y', strtotime('sunday this week')),
        "last-week"      => date('d M Y', strtotime('monday last week')) . " - " . date('d M Y', strtotime('sunday last week')),
        default          => "01 Jan ".date('y'). " - 31 Dec " .date('y')
    };
@endphp

<div {{ 
    $attributes->merge([
        "id"       => $id,
        "solar-ui" => "period-filter",
        "ignore"   => $ignore === true
    ])->class([
        "dropdown"
    ])
}}>
    <x-core::button id="{{ $id }}_button" :variant="$variant" :color="$color" :size="$size" data-bs-toggle="dropdown" aria-expanded="false" ignore :disabled="$disabled">
        <i class="bx bx-calendar me-1"></i> <span id="{{ $id }}_text">{{ $text }}</span>
    </x-core::button>
    <div class="dropdown-menu">
        <a class="dropdown-item current-year {{ $isActive('current-year') }}" href="#">Current year</a>
        <a class="dropdown-item previous-year {{ $isActive('previous-year') }}" href="#">Previous year</a>

        <div class="dropdown-divider"></div>

        <a class="dropdown-item current-month {{ $isActive('current-month') }}" href="#">Current month</a>
        <a class="dropdown-item previous-month {{ $isActive('previous-month') }}" href="#">Previous month</a>
        <a class="dropdown-item last-3-months {{ $isActive('last-3-months') }}" href="#">Last 3 months</a>
        <a class="dropdown-item last-6-months {{ $isActive('last-6-months') }}" href="#">Last 6 months</a>

        <div class="dropdown-divider"></div>

        <a class="dropdown-item current-week {{ $isActive('current-week') }}" href="#">Current week</a>
        <a class="dropdown-item last-week {{ $isActive('last-week') }}" href="#">Last week</a>

        <div class="dropdown-divider"></div>
        
        <a class="dropdown-item custom-range" href="#">Custom range</a>
    </div>
</div>

@push('modal-content')
<x-core::modal id="{{ $id }}_modal" dialog:class="modal-dialog-right" static size="md" ignore>
    <x-slot:header class="border-0">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </x-slot>

    <div class="d-flex justify-content-center mb-3">
        <x-core::date-picker id="{{ $id }}_datepicker" class="d-none" range inline ignore />
    </div>
    <div class="input-group">
        <x-core::input id="{{ $id }}_start" readonly ignore />
        <x-core::input id="{{ $id }}_end" readonly ignore />
    </div>

    <div class="hstack gap-2 justify-content-center mt-4">
        <x-core::button id="{{ $id }}_apply" ignore>Apply</x-core::button>
        <x-core::button data-bs-dismiss="modal" color="light" aria-label="Close" ignore>Cancel</x-core::button>
    </div>
</x-core::modal>
@endpush