@props([
    "title"   => "Cancel",
    "color"   => "secondary",
    "variant" => "outline",
    "size"    => null
])

<x-core::button 
    :color="$color" 
    :variant="$variant"
    :size="$size"
    onclick="location.href='{{ url()->previous() }}'">
    {{ $title }}
</x-core::button>