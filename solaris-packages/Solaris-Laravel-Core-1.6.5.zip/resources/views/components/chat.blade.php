@props([
	'conversations'      => null,
	'chatActive'         => null,
	'device'             => 'sunny',
	'showReply'          => true,
	'searchPlaceholder'  => 'Search Chat',
	'inputPlaceholder'   => 'Type a message...',
	'emptyMessage'       => 'Select a conversation to start chatting',
])

@php
	use Illuminate\Support\Collection;

	$allConversations    = $conversations instanceof Collection ? $conversations : collect();
	$unreadConversations = $allConversations->where('unread_count', '>', 0)->values();
	$noActive            = $chatActive === null;

	$getPreview = function ($conv) {
		$msg = $conv->latest_message;
		if (!$msg) return '';

		$label = fn(?string $text, string $fallback) => '<i class="%s me-1"></i>' . e($text ?? $fallback);

		return match($msg->type) {
			'image'    => sprintf($label($msg->caption ?? $msg->body, 'Photo'),    'ri-image-line'),
			'video'    => sprintf($label($msg->caption ?? $msg->body, 'Video'),    'ri-video-line'),
			'audio'    => '<i class="ri-mic-line me-1"></i>Audio',
			'document' => sprintf($label($msg->caption ?? $msg->body ?? $msg->media_filename, 'Document'), 'ri-file-line'),
			default    => e($msg->body ?? ''),
		};
	};
@endphp

<div {{ $attributes->merge(['class' => 'main-chart-wrapper gap-lg-2 gap-0 d-lg-flex' . ($noActive ? ' chat-no-active' : '')]) }}
	 data-device="{{ $device }}"
	 solar-ui="chat">

	{{ $before ?? '' }}

	{{-- Sidebar --}}
	<div class="chat-info border">

		{{ $sidebarBefore ?? '' }}

		<div class="chat-search p-3 border-bottom">
			<div class="input-group">
				<input type="text"
					class="form-control"
					placeholder="{{ $searchPlaceholder }}"
					data-chat-search>
				<button class="btn btn-primary" type="button" aria-label="Search">
					<i class="ri-search-line"></i>
				</button>
			</div>
		</div>

		<ul class="nav nav-tabs tab-style-6 nav-justified mb-0 border-bottom d-flex gap-1 gap-sm-2 flex-wrap"
			role="tablist">
			<li class="nav-item me-0" role="presentation">
				<button class="nav-link active" data-bs-toggle="tab"
					data-bs-target="#chat-tab-all" type="button" role="tab"
					aria-controls="chat-tab-all" aria-selected="true">
					All
				</button>
			</li>
			<li class="nav-item me-0" role="presentation">
				<button class="nav-link" data-bs-toggle="tab"
						data-bs-target="#chat-tab-unread" type="button" role="tab"
						aria-controls="chat-tab-unread" aria-selected="false">
					Unread
				</button>
			</li>
			{{ $sidebarTabs ?? '' }}
		</ul>

		<div class="tab-content">
			<div class="tab-pane show active border-0 chat-users-tab" id="chat-tab-all"
				 role="tabpanel" tabindex="0">
				<ul class="list-unstyled mb-0 mt-2" data-chat-list>
					@if($allConversations->isEmpty())
						<li class="px-3 py-5 text-center">
							<div class="d-flex flex-column align-items-center gap-3">
								<i class="ri-chat-smile-3-line fs-48 text-primary opacity-25"></i>
								<div>
									<p class="fw-semibold fs-14 mb-1">No conversations yet</p>
									<p class="text-muted fs-12 mb-0">Your conversations will appear here</p>
								</div>
							</div>
						</li>
					@else
						@foreach($allConversations as $conv)
							<x-core::chat.conversation-item
								:conversationId="$conv->id"
								:name="$conv->contact_name ?? $conv->phone_number"
								:phone="$conv->phone_number"
								:preview="$getPreview($conv)"
								:time="$conv->last_message_at?->diffForHumans(['short' => true]) ?? ''"
								:unreadCount="$conv->unread_count ?? 0"
								:active="(string) $chatActive === (string) $conv->id"
								:profilePictureUrl="$conv->profile_picture_id ? route('core.images', ['id' => $conv->profile_picture_id]) : null"
								:previewWidth="$conv->profile_picture?->image_width"
								:previewHeight="$conv->profile_picture?->image_height"
							/>
						@endforeach
					@endif
				</ul>
			</div>

			<div class="tab-pane border-0 chat-users-tab" id="chat-tab-unread"
				 role="tabpanel" tabindex="0">
				<ul class="list-unstyled mb-0 mt-2" data-chat-list>
					@if($unreadConversations->isEmpty())
						<li class="px-3 py-5 text-center">
							<div class="d-flex flex-column align-items-center gap-3">
								<i class="ri-checkbox-circle-line fs-48 text-success opacity-25"></i>
								<div>
									<p class="fw-semibold fs-14 mb-1">All caught up!</p>
									<p class="text-muted fs-12 mb-0">No unread messages</p>
								</div>
							</div>
						</li>
					@else
						@foreach($unreadConversations as $conv)
							<x-core::chat.conversation-item
								:conversationId="$conv->id"
								:name="$conv->contact_name ?? $conv->phone_number"
								:phone="$conv->phone_number"
								:preview="$getPreview($conv)"
								:time="$conv->last_message_at?->diffForHumans(['short' => true]) ?? ''"
								:unreadCount="$conv->unread_count ?? 0"
								:active="(string) $chatActive === (string) $conv->id"
								:profilePictureUrl="$conv->profile_picture_id ? route('core.images', ['id' => $conv->profile_picture_id]) : null"
							/>
						@endforeach
					@endif
				</ul>
			</div>

			{{ $sidebarTabPanes ?? '' }}
		</div>

		{{ $sidebarAfter ?? '' }}
	</div>

	{{-- Chat Area --}}
	<div class="main-chat-area border" data-chat-area>

		{{-- Placeholder — always in DOM, shown via CSS when chat-no-active --}}
		<div data-chat-placeholder>
			<div class="text-center p-5">
				<i class="ri-wechat-2-line fs-64 text-primary opacity-25 d-block mb-3"></i>
				<h6 class="fw-semibold mb-1">{{ $emptyMessage }}</h6>
				<p class="text-muted fs-13 mb-0">Choose a conversation from the left to start chatting</p>
			</div>
		</div>

		{{-- Header --}}
		<div class="d-flex align-items-center border-bottom main-chat-head flex-wrap gap-2"
			 data-chat-header>
			<span class="avatar avatar-md avatar-rounded lh-1 fw-semibold flex-shrink-0"
				  data-header-avatar></span>
			<div class="flex-fill min-w-0">
				<p class="mb-0 fw-semibold fs-14 lh-1 text-truncate" data-header-name>—</p>
				<p class="text-muted mb-0 fs-12 mt-1" data-header-status>—</p>
				{{ $headerMeta ?? '' }}
			</div>
			<div class="d-flex flex-wrap rightIcons gap-2 flex-shrink-0">
				{{ $headerActions ?? '' }}
				<div class="dropdown">
					<button class="btn btn-icon btn-secondary-light btn-wave btn-sm"
							type="button" data-bs-toggle="dropdown" aria-expanded="false"
							aria-label="Options">
						<i class="ti ti-dots-vertical"></i>
					</button>
					<ul class="dropdown-menu">
						@isset($headerMenuItems)
							{{ $headerMenuItems }}
						@else
							<li>
								<a class="dropdown-item" href="javascript:void(0);">
									<i class="ri-user-3-line me-1"></i>Profile
								</a>
							</li>
						@endisset
					</ul>
				</div>
				<button type="button"
					class="btn btn-icon btn-primary-light my-0 responsive-chat-close btn-sm"
					aria-label="Close">
					<i class="ri-close-line"></i>
				</button>
			</div>
		</div>

		{{ $messageBanner ?? '' }}

		{{-- Messages --}}
		<div class="chat-content" data-chat-content>
			<ul class="list-unstyled mb-0" data-messages-list>
				@isset($messages)
					{{ $messages }}
				@endisset
			</ul>
		</div>

		{{-- Footer --}}
		@if($showReply)
			@isset($footerToolbar)
				<div class="chat-footer-toolbar" data-chat-toolbar>
					{{ $footerToolbar }}
				</div>
			@endisset
			<div class="chat-reply-bar d-none" data-chat-reply-bar>
				<div class="chat-reply-bar-content">
					<span class="chat-reply-bar-sender" data-reply-sender></span>
					<span class="chat-reply-bar-snippet" data-reply-snippet></span>
				</div>
				<button type="button" class="btn btn-icon btn-sm chat-reply-bar-cancel" data-chat-reply-cancel aria-label="Cancel reply">
					<i class="ri-close-line"></i>
				</button>
			</div>
			<div class="chat-footer" data-chat-footer>
				{{ $footerLeft ?? '' }}
				<a class="btn btn-success-light btn-icon btn-sm"
				   	href="javascript:void(0)" data-chat-attach aria-label="Attach file">
					<i class="ri-attachment-2"></i>
				</a>
				<x-core::textarea
					class="chat-message-input"
					placeholder="{{ $inputPlaceholder }}"
					rows="1" 
					data-chat-input
					ignore />
				<x-core::button icon size="sm" class="btn-send" ignore data-chat-send>
					<i class="ri-send-plane-2-line"></i>
				</x-core::button>
				{{ $footerRight ?? '' }}
			</div>
		@endif
	</div>

	<div class="dropdown-menu chat-context-menu" data-chat-context-menu>
		<a class="dropdown-item" href="javascript:void(0)" data-action="reply" data-scope="message">
			<i class="ri-reply-line me-1"></i>Reply
		</a>
		<a class="dropdown-item text-danger" href="javascript:void(0)" data-action="delete-message" data-scope="message">
			<i class="ri-delete-bin-line me-1"></i>Delete Message
		</a>
		<a class="dropdown-item text-danger" href="javascript:void(0)" data-action="delete-conversation" data-scope="conversation">
			<i class="ri-delete-bin-line me-1"></i>Delete Conversation
		</a>
	</div>

	{{ $after ?? '' }}
</div>

@push('modal-content')
	@include("core::components.chat.setup-modal")
@endpush
