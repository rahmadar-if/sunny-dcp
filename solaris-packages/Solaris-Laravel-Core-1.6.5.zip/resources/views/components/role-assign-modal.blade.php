@props([
    "id" => "role-assign-modal",
])

<x-core::list-modal :id="$id" title="Assign Access" empty_text="No data found">
    <x-slot:header>
        <div class="btn-group btn-group-sm w-100" role="group">
            <input type="radio" class="btn-check" name="{{ $id }}_type" id="{{ $id }}-type-user" value="user" checked>
            <label class="btn btn-outline-primary" for="{{ $id }}-type-user">User</label>

            <input type="radio" class="btn-check" name="{{ $id }}_type" id="{{ $id }}-type-permission" value="permission">
            <label class="btn btn-outline-primary" for="{{ $id }}-type-permission">Permission</label>
        </div>
    </x-slot>
</x-core::list-modal>
