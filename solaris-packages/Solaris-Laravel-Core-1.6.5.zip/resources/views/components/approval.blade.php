@props(['id'])

@php
	use Solaris\Core\Const\ApprovalRequestStatusConst;
	use Solaris\Core\Const\ApprovalLevelStatusConst;
	use Solaris\Core\Const\ApprovalAssignmentStatusConst;
	use Solaris\Core\Services\Approval\ApprovalService;
	use Solaris\Core\Services\Approval\ApprovalModeConst;

	$pendingResult   = ApprovalService::pendingForMe(Auth::id());
	$requestsResult  = ApprovalService::myRequests(Auth::id());
	$pendingData     = $pendingResult['data'];
	$requestsData    = $requestsResult['data'];
	$totalPending    = $pendingResult['recordsTotal'];
	$totalInProgress = $requestsResult['totalInProgress'];
	$totalRequests   = $requestsResult['recordsTotal'];

	$statusColors = [
		ApprovalRequestStatusConst::Pending    => 'secondary',
		ApprovalRequestStatusConst::InProgress => 'warning',
		ApprovalRequestStatusConst::Approved   => 'success',
		ApprovalRequestStatusConst::Rejected   => 'danger',
		ApprovalRequestStatusConst::Cancelled  => 'secondary',
		ApprovalRequestStatusConst::Expired    => 'secondary',
	];
	$lvIconMap = [
		ApprovalLevelStatusConst::Approved   => ['icon' => 'ri-checkbox-circle-fill', 'cls' => 'text-success', 'title' => 'Approved'],
		ApprovalLevelStatusConst::InProgress => ['icon' => 'ri-loader-3-line', 'cls' => 'text-warning', 'title' => 'In Progress'],
		ApprovalLevelStatusConst::Rejected   => ['icon' => 'ri-close-circle-fill', 'cls' => 'text-danger', 'title' => 'Rejected'],
		ApprovalLevelStatusConst::Skipped    => ['icon' => 'ri-indeterminate-circle-line', 'cls' => 'text-muted', 'title' => 'Skipped'],
	];
	$lvConnectorMap = [
		ApprovalLevelStatusConst::Approved   => 'border-success',
		ApprovalLevelStatusConst::InProgress => 'border-warning',
		ApprovalLevelStatusConst::Rejected   => 'border-danger',
	];
	$assignIconMap = [
		ApprovalAssignmentStatusConst::Approved  => ['icon' => 'ri-checkbox-circle-fill', 'cls' => 'text-success', 'title' => 'Approved'],
		ApprovalAssignmentStatusConst::Rejected  => ['icon' => 'ri-close-circle-fill', 'cls' => 'text-danger', 'title' => 'Rejected'],
		ApprovalAssignmentStatusConst::Dismissed => ['icon' => 'ri-indeterminate-circle-line', 'cls' => 'text-muted', 'title' => 'Dismissed'],
		ApprovalAssignmentStatusConst::Pending   => ['icon' => 'ri-circle-line', 'cls' => 'text-muted', 'title' => 'Pending'],
	];
@endphp

<div id="{{ $id }}" solar-ui="approval" solar-id="{{ $id }}" total="{{ $totalPending }}" total-requests="{{ $totalRequests }}">
	<a id="{{ $id }}_icon" href="javascript:void(0);"
		class="header-link dropdown-toggle"
		data-bs-toggle="offcanvas"
		data-bs-target="#{{ $id }}_offcanvas"
		aria-controls="{{ $id }}_offcanvas">
		<svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6 header-link-icon" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
			<path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12c0 1.268-.63 2.39-1.593 3.068a3.745 3.745 0 0 1-1.043 3.296 3.745 3.745 0 0 1-3.296 1.043A3.745 3.745 0 0 1 12 21c-1.268 0-2.39-.63-3.068-1.593a3.746 3.746 0 0 1-3.296-1.043 3.745 3.745 0 0 1-1.043-3.296A3.745 3.745 0 0 1 3 12c0-1.268.63-2.39 1.593-3.068a3.745 3.745 0 0 1 1.043-3.296 3.746 3.746 0 0 1 3.296-1.043A3.746 3.746 0 0 1 12 3c1.268 0 2.39.63 3.068 1.593a3.746 3.746 0 0 1 3.296 1.043 3.746 3.746 0 0 1 1.043 3.296A3.745 3.745 0 0 1 21 12Z" />
		</svg>
		<span id="{{ $id }}_pulse" class="{{ $totalPending > 0 ? 'header-icon-pulse bg-warning rounded pulse pulse-warning' : '' }}"></span>
	</a>
</div>

@push('offcanvas-content')
<x-core::offcanvas :id="$id.'_offcanvas'" title="Approvals" position="right" :staticBackdrop="false" :close="false">
	<x-slot:header>
		<div class="d-flex align-items-center justify-content-end w-100 gap-1">
			<x-core::refresh-button id="{{ $id }}_refresh" disabled size="sm" color="light" ignore />
			<button type="button" class="btn-close ms-0" data-bs-dismiss="offcanvas" aria-label="Close"></button>
		</div>
	</x-slot:header>

	<x-core::tab :id="$id.'_tabs'">
		<x-slot:nav>
			<x-core::tab-nav :id="$id.'_tab_pending'" active>
				For Me
				<span id="{{ $id }}_pending_badge" class="badge bg-secondary ms-1 rounded-pill {{ $totalPending > 0 ? '' : 'd-none' }}">{{ $totalPending }}</span>
			</x-core::tab-nav>
			<x-core::tab-nav :id="$id.'_tab_requests'">
				My Requests
				<span id="{{ $id }}_requests_badge" class="badge bg-secondary ms-1 rounded-pill {{ $totalInProgress > 0 ? '' : 'd-none' }}">{{ $totalInProgress }}</span>
			</x-core::tab-nav>
		</x-slot:nav>

		<x-slot:content>
			{{-- For Me tab --}}
			<x-core::tab-content :id="$id.'_tab_pending'" class="border-0" active>
				<ul class="list-unstyled mb-0" id="{{ $id }}_pending_list">
					@foreach ($pendingData as $assignment)
					@php $req = $assignment->level?->request @endphp
					<li class="px-3 py-3 border-bottom">
						<div class="d-flex flex-column gap-1">
							<p class="fw-medium mb-0 fs-14">{{ $req?->name ?? '-' }}</p>
							@if ($req?->description)
								<span class="fs-12 text-muted">{{ $req->description }}</span>
							@endif
							@if ($req?->subject_label && $req?->subject_url)
								<a href="{{ $req->subject_url }}" class="fs-12 text-primary" target="_blank">
									<i class="ri-external-link-line fs-11"></i> {{ $req->subject_label }}
								</a>
							@endif
							@if ($req?->requester)
								<span class="fs-12">Requested by: <strong>{{ $req->requester->name }}</strong></span>
							@endif
							<div class="d-flex justify-content-between align-items-center mt-1">
								<span class="fs-11 text-muted">{{ $assignment->created_at->localized() }}</span>
								<div class="d-flex gap-1">
									<button class="btn btn-sm btn-wave btn-outline-success action-approve" data-id="{{ $assignment->id }}">Approve</button>
									<button class="btn btn-sm btn-wave btn-outline-danger action-reject" data-id="{{ $assignment->id }}">Reject</button>
								</div>
							</div>
						</div>
					</li>
					@endforeach
				</ul>
				<div class="p-5 text-center {{ $pendingData->isEmpty() ? '' : 'd-none' }}" id="{{ $id }}_pending_empty">
					<span class="avatar avatar-xl avatar-rounded bg-success-transparent">
						<i class="ri-checkbox-circle-line fs-2 text-success"></i>
					</span>
					<h6 class="fw-medium mt-3">No Pending Approvals</h6>
				</div>
			</x-core::tab-content>

			{{-- My Requests tab --}}
			<x-core::tab-content :id="$id.'_tab_requests'" class="border-0">
				<ul class="list-unstyled mb-0" id="{{ $id }}_requests_list">
					@foreach ($requestsData as $request)
					@php
						$statusColor = $statusColors[$request->status_id] ?? 'secondary';
						$statusName  = $request->status?->name ?? '-';
						$isPending   = $request->status_id === ApprovalRequestStatusConst::Pending;
						$isApproved  = $request->status_id === ApprovalRequestStatusConst::Approved;
						$isRejected  = $request->status_id === ApprovalRequestStatusConst::Rejected;
						$levels      = $request->levels ?? collect();
						$totalLevels = count($levels);
						$activeLevel = $levels->firstWhere('status_id', ApprovalLevelStatusConst::InProgress);
						$activeIdx   = $activeLevel ? $levels->search(fn($l) => $l->id === $activeLevel->id) + 1 : null;
					@endphp
					<li class="px-3 py-3 border-bottom">
						{{-- Row 1 & 2: name + description (left), status badge (right) --}}
						<div class="d-flex justify-content-between align-items-start gap-2">
							<div class="flex-fill overflow-hidden">
								<p class="fw-medium mb-0 fs-14 text-truncate truncate-toggle" style="cursor:pointer">{{ $request->name ?? '-' }}</p>
								@if ($request->description)
									<span class="fs-12 text-muted d-block text-truncate truncate-toggle" style="cursor:pointer">{{ $request->description }}</span>
								@endif
								@if ($request->subject_label && $request->subject_url)
									<a href="{{ $request->subject_url }}" class="fs-12 text-primary d-inline-block mt-1" target="_blank">
										<i class="ri-external-link-line fs-11"></i> {{ $request->subject_label }}
									</a>
								@endif
							</div>
							<span class="badge bg-{{ $statusColor }}-transparent text-{{ $statusColor }} flex-shrink-0">{{ $statusName }}</span>
						</div>

						<hr class="my-2">

						{{-- Row 3+4: progress line + info text --}}
						<div class="d-flex align-items-center gap-2">
							<div class="d-flex align-items-center flex-shrink-0">
								@foreach ($levels as $lvIdx => $level)
									@php
										$li      = $lvIconMap[$level->status_id] ?? ['icon' => 'ri-circle-line', 'cls' => 'text-muted'];
										$prevLv  = $lvIdx > 0 ? $levels[$lvIdx - 1] : null;
										$connCls = $prevLv ? ($lvConnectorMap[$prevLv->status_id] ?? 'border-secondary') : '';
									@endphp
									@if ($lvIdx > 0)
										<span class="border-top {{ $connCls }}" style="width:16px"></span>
									@endif
									<i class="{{ $li['icon'] }} {{ $li['cls'] }} fs-12" title="Lv {{ $lvIdx + 1 }}: {{ $li['title'] ?? 'Pending' }}"></i>
								@endforeach
							</div>
							<span class="fs-12 text-muted text-truncate">
								@if ($isApproved)
									All levels completed
								@elseif ($activeLevel)
									@php
										$approverName = $activeLevel->user_approver?->name
											?? $activeLevel->role_approver?->name
											?? $activeLevel->permission_approver?->name
											?? $activeLevel->approver_type?->name
											?? '-';
									@endphp
									Level {{ $activeIdx }}/{{ $totalLevels }} &bull; {{ $activeLevel->approver_type?->name }}: {{ $approverName }}
								@elseif ($isRejected)
									@php
										$rejLevel    = $levels->firstWhere('status_id', ApprovalLevelStatusConst::Rejected);
										$rejIdx      = $rejLevel ? $levels->search(fn($l) => $l->id === $rejLevel->id) + 1 : '-';
										$rejApprover = $rejLevel?->user_approver?->name
											?? $rejLevel?->role_approver?->name
											?? $rejLevel?->permission_approver?->name
											?? $rejLevel?->approver_type?->name
											?? '-';
									@endphp
									Rejected at Level {{ $rejIdx }} &bull; {{ $rejLevel?->approver_type?->name }}: {{ $rejApprover }}
								@elseif ($isPending)
									Level 0/{{ $totalLevels }} &bull; Waiting to start
								@else
									{{ $request->status?->name }}
								@endif
							</span>
						</div>

						<hr class="my-2">

						{{-- Row 5: date (left), cancel + expand (right) --}}
						<div class="d-flex justify-content-between align-items-center">
							<span class="fs-11 text-muted">{{ $request->created_at->localized() }}</span>
							<div class="d-flex gap-1">
								@if ($isPending)
									<button class="btn btn-light btn-sm btn-icon text-danger action-cancel" data-id="{{ $request->id }}" title="Cancel Request">
										<i class="ri-close-line fs-14"></i>
									</button>
								@endif
								<button class="btn btn-light btn-sm btn-icon detail-toggle" data-id="{{ $request->id }}" title="Show Details">
									<i class="ri-arrow-down-s-line fs-14"></i>
								</button>
							</div>
						</div>

						{{-- Expanded panel --}}
						<div id="req_detail_{{ $request->id }}" class="d-none mt-2 pt-2 border-top">
							@foreach ($levels as $level)
							@php
								$lvApproverType = $level->approver_type->name;
								$lvApprover     = $level->user_approver?->name
									?? $level->role_approver?->name
									?? $level->permission_approver?->name
									?? $lvApproverType
									?? '-';
								$lvIsActive   = $level->status_id === ApprovalLevelStatusConst::InProgress;
								$lvIsApproved = $level->status_id === ApprovalLevelStatusConst::Approved;
								$lvIsRejected = $level->status_id === ApprovalLevelStatusConst::Rejected;
								$lvIcon       = $lvIconMap[$level->status_id] ?? ['icon' => 'ri-circle-line', 'cls' => 'text-muted'];
								$lvLabel      = match($level->status_id) {
									ApprovalLevelStatusConst::Approved => 'Approved',
									ApprovalLevelStatusConst::Skipped  => 'Skipped',
									ApprovalLevelStatusConst::Pending  => 'Waiting',
									default                            => '',
								};
								$modeLabel       = $level->mode === ApprovalModeConst::Consensus ? 'All must approve' : 'First wins';
								$showAssignments = $lvIsActive || $lvIsApproved || $lvIsRejected;
								$shownAssignments = $level->assignments ?? collect();
								if ($lvIsApproved) $shownAssignments = $shownAssignments->where('status_id', ApprovalAssignmentStatusConst::Approved);
							@endphp
							<div class="d-flex gap-2 align-items-start {{ !$loop->last ? 'mb-2' : '' }}">
								<i class="{{ $lvIcon['icon'] }} {{ $lvIcon['cls'] }} fs-12 flex-shrink-0" title="{{ $lvIcon['title'] ?? 'Pending' }}"></i>
								<div class="flex-fill overflow-hidden">
									@if ($level->user_approver !== null)
										@php
											$userAssignment = $shownAssignments->first();
											$userNotes      = $userAssignment?->notes;
											$userActedAt    = $userAssignment?->acted_at;
										@endphp
										<div class="d-flex justify-content-between align-items-start gap-1">
											<span class="fs-12 fw-medium">Lv {{ $loop->iteration }}&nbsp;&nbsp;User: {{ $level->user_approver->name }}</span>
											<div class="d-flex flex-column align-items-end flex-shrink-0">
												@if ($lvLabel)
													<span class="fs-11 text-muted">{{ $lvLabel }}</span>
												@endif
												@if ($userActedAt)
													<span class="fs-11 text-muted">{{ $userActedAt->localized() }}</span>
												@endif
											</div>
										</div>
										@if ($userNotes)
											<p class="mb-0"><span class="d-inline-block mw-100 text-truncate truncate-toggle fst-italic text-muted fs-11" style="cursor:pointer">"{{ $userNotes }}"</span></p>
										@endif
									@else
										<div class="d-flex justify-content-between align-items-center gap-1">
											<span class="fs-12 fw-medium">Lv {{ $loop->iteration }}&nbsp;&nbsp;{{ $level->approver_type->name.": ".$lvApprover }}</span>
											@if ($lvIsActive || $lvIsRejected)
												<span class="badge bg-secondary-transparent text-secondary fs-10">{{ $modeLabel }}</span>
											@elseif ($lvLabel)
												<span class="fs-11 text-muted">{{ $lvLabel }}</span>
											@endif
										</div>
										@if ($showAssignments)
											@foreach ($shownAssignments as $assignment)
											@php $ai = $assignIconMap[$assignment->status_id] ?? ['icon' => 'ri-circle-line', 'cls' => 'text-muted']; @endphp
											<div class="d-flex align-items-start gap-1 mt-1">
												<i class="{{ $ai['icon'] }} {{ $ai['cls'] }} fs-11 flex-shrink-0" title="{{ $ai['title'] ?? 'Pending' }}"></i>
												<div class="flex-fill overflow-hidden">
													<div class="d-flex justify-content-between align-items-center gap-1">
														<span class="fs-12">{{ $assignment->approver?->name ?? '–' }}</span>
														@if ($assignment->acted_at)
															<span class="text-muted fs-11 flex-shrink-0">{{ $assignment->acted_at->localized() }}</span>
														@endif
													</div>
													@if ($assignment->notes)
														<p class="mb-0"><span class="d-inline-block mw-100 text-truncate truncate-toggle fst-italic text-muted fs-11" style="cursor:pointer">"{{ $assignment->notes }}"</span></p>
													@endif
												</div>
											</div>
											@endforeach
										@endif
									@endif
								</div>
							</div>
							@endforeach
						</div>
					</li>
					@endforeach
				</ul>
				<div class="p-5 text-center {{ $requestsData->isEmpty() ? '' : 'd-none' }}" id="{{ $id }}_requests_empty">
					<span class="avatar avatar-xl avatar-rounded bg-secondary-transparent">
						<i class="ri-file-list-line fs-2"></i>
					</span>
					<h6 class="fw-medium mt-3">No Requests</h6>
				</div>
			</x-core::tab-content>
		</x-slot:content>
	</x-core::tab>
</x-core::offcanvas>
@endpush
