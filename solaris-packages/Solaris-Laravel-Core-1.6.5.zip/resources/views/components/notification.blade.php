@props([
	'id',
	'ignore' => false
])

@php
	use Solaris\Core\Models\Notification;
	use Solaris\Core\Services\Excel\ExcelService;

	$isAuth            = Auth::check();
	$userId            = $isAuth ? Auth::id() : null;

	$notifications     = $isAuth ? Notification::inAppData() : null;
	$totalNonDismissed = $isAuth ? $notifications['total'] : 0;
	$totalUnread       = $isAuth ? $notifications['unreadTotal'] : 0;
	$notifData         = $isAuth ? $notifications['data'] : collect();
	$notifHasMore      = $isAuth ? ($totalNonDismissed > $notifData->count()) : false;
	$notifEmpty        = $totalNonDismissed === 0;

	$exportResult  = $isAuth ? ExcelService::exportLogList($userId, 0, 10) : ['data' => collect(), 'recordsTotal' => 0];
	$importResult  = $isAuth ? ExcelService::importLogList($userId, 0, 10) : ['data' => collect(), 'recordsTotal' => 0];
	$exportData    = collect($exportResult['data']);
	$importData    = collect($importResult['data']);
	$totalExport   = $exportResult['recordsTotal'];
	$totalImport   = $importResult['recordsTotal'];
@endphp

<div id="{{ $id }}"
	solar-ui="notification"
	solar-id="{{ $id }}"
	{{ $attributes->merge([
		'ignore'         => $ignore === true,
		'total'          => $totalNonDismissed,
		'unread-total'   => $totalUnread,
		'notif-has-more' => $notifHasMore ? 'true' : '',
		'total-export'   => $totalExport,
		'total-import'   => $totalImport,
	]) }}
>
	<a id="{{ $id }}_icon" href="javascript:void(0);"
		class="header-link dropdown-toggle"
		data-bs-toggle="offcanvas"
		data-bs-target="#{{ $id }}_offcanvas"
		aria-controls="{{ $id }}_offcanvas">
		<svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6 header-link-icon" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
			<path stroke-linecap="round" stroke-linejoin="round" d="M14.857 17.082a23.848 23.848 0 0 0 5.454-1.31A8.967 8.967 0 0 1 18 9.75V9A6 6 0 0 0 6 9v.75a8.967 8.967 0 0 1-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 0 1-5.714 0m5.714 0a3 3 0 1 1-5.714 0M3.124 7.5A8.969 8.969 0 0 1 5.292 3m13.416 0a8.969 8.969 0 0 1 2.168 4.5" />
		</svg>
		<span id="{{ $id }}_pulse" class="{{ $totalUnread > 0 ? 'header-icon-pulse bg-secondary rounded pulse pulse-secondary' : '' }}"></span>
	</a>
</div>

@push('offcanvas-content')
<x-core::offcanvas :id="$id.'_offcanvas'" title="Notifications" position="right" :staticBackdrop="false" :close="false">
	<x-slot:header>
		<div class="d-flex align-items-center justify-content-end w-100 gap-1">
			<x-core::refresh-button id="{{ $id }}_refresh" disabled size="sm" color="light" ignore />
			<button type="button" class="btn-close ms-0" data-bs-dismiss="offcanvas" aria-label="Close"></button>
		</div>
	</x-slot:header>

	<x-core::tab :id="$id.'_tabs'">
		<x-slot:nav>
			<x-core::tab-nav :id="$id.'_tab_notif'" active>
				Notifications
				<span id="{{ $id }}_notif_badge" class="badge bg-secondary ms-1 rounded-pill {{ $totalUnread > 0 ? '' : 'd-none' }}">{{ $totalUnread }}</span>
			</x-core::tab-nav>
			<x-core::tab-nav :id="$id.'_tab_export'">
				Export
			</x-core::tab-nav>
			<x-core::tab-nav :id="$id.'_tab_import'">
				Import
			</x-core::tab-nav>
		</x-slot:nav>

		<x-slot:content>

			{{-- Notifications tab --}}
			<x-core::tab-content :id="$id.'_tab_notif'" class="border-0" active>
				<ul class="list-unstyled mb-0" id="{{ $id }}_notif_list">
					@foreach ($notifData as $notification)
					@php $isUnread = is_null($notification->read_at); @endphp
					<li class="px-3 py-3 border-bottom{{ $isUnread ? ' notif-unread' : '' }}">
						<div class="d-flex align-items-start justify-content-between">
							<div class="d-flex flex-column gap-1 flex-fill overflow-hidden">
								<p class="mb-0 {{ $isUnread ? 'fw-semibold' : 'fw-medium' }} fs-14">
									@if ($isUnread)
										<i class="ri-circle-fill fs-8 text-primary me-1"></i>
									@endif
									@if (!empty($notification->data['url']))
										<a href="{{ $notification->data['url'] }}">{{ $notification->data['title'] }}</a>
									@else
										{{ $notification->data['title'] }}
									@endif
								</p>
								<div class="text-muted fw-normal fs-12 text-truncate notif-message" style="cursor:pointer">{!! str_replace("\n", "<br>", $notification->data['message']) !!}</div>
								<div class="fw-normal fs-10 text-muted op-8">{{ $notification->time }}</div>
							</div>
							<div class="d-flex align-items-center ms-2 gap-1">
								@if ($isUnread)
									<a href="javascript:void(0);" class="min-w-fit-content mark-read-notification" data-id="{{ $notification->id }}" title="Mark as read">
										<i class="ri-check-line text-success"></i>
									</a>
								@endif
								<a href="javascript:void(0);" class="min-w-fit-content dismiss-notification" data-id="{{ $notification->id }}" title="Dismiss">
									<i class="ri-close-line"></i>
								</a>
							</div>
						</div>
					</li>
					@endforeach
				</ul>
				<div class="p-5 text-center {{ $notifEmpty ? '' : 'd-none' }}" id="{{ $id }}_notif_empty">
					<span class="avatar avatar-xl avatar-rounded bg-secondary-transparent">
						<i class="ri-notification-off-line fs-2"></i>
					</span>
					<h6 class="fw-medium mt-3">No New Notifications</h6>
				</div>
			</x-core::tab-content>

			{{-- Export Log tab --}}
			<x-core::tab-content :id="$id.'_tab_export'" class="border-0">
				<ul class="list-unstyled mb-0" id="{{ $id }}_export_list">
					@foreach ($exportData as $log)
					@php
						$exportStatus = !is_null($log['finished_at']) && is_null($log['error_message'])
							? 'success'
							: (!is_null($log['error_message']) ? 'error' : 'pending');
					@endphp
					<li class="border-bottom">
						<a href="{{ $log['url'] }}" class="d-flex flex-column gap-1 px-3 py-3 text-decoration-none link-body-emphasis">
							<div class="d-flex justify-content-between align-items-start gap-2">
								<span class="fw-medium fs-14 text-truncate flex-fill">{{ $log['file_name'] }}</span>
								@if ($exportStatus === 'success')
									<span class="badge bg-success-transparent text-success flex-shrink-0">Done</span>
								@elseif ($exportStatus === 'error')
									<span class="badge bg-danger-transparent text-danger flex-shrink-0">Error</span>
								@else
									<span class="badge bg-warning-transparent text-warning flex-shrink-0">In Progress</span>
								@endif
							</div>
							<div class="d-flex gap-3 fs-11 text-muted">
								@if (!is_null($log['total_rows']))
									<span>{{ number_format($log['total_rows']) }} rows</span>
								@endif
								<span>{{ $log['created_at'] }}</span>
							</div>
						</a>
					</li>
					@endforeach
				</ul>
				<div class="p-5 text-center {{ $exportData->isEmpty() ? '' : 'd-none' }}" id="{{ $id }}_export_empty">
					<span class="avatar avatar-xl avatar-rounded bg-secondary-transparent">
						<i class="ri-file-download-line fs-2"></i>
					</span>
					<h6 class="fw-medium mt-3">No Export Logs</h6>
				</div>
			</x-core::tab-content>

			{{-- Import Log tab --}}
			<x-core::tab-content :id="$id.'_tab_import'" class="border-0">
				<ul class="list-unstyled mb-0" id="{{ $id }}_import_list">
					@foreach ($importData as $log)
					@php
						$importStatus = !is_null($log['finished_at']) && is_null($log['error_message'])
							? 'success'
							: (!is_null($log['error_message']) ? 'error' : 'pending');
					@endphp
					<li class="border-bottom">
						<a href="{{ $log['url'] }}" class="d-flex flex-column gap-1 px-3 py-3 text-decoration-none link-body-emphasis">
							<div class="d-flex justify-content-between align-items-start gap-2">
								<span class="fw-medium fs-14 text-truncate flex-fill">{{ $log['file_name'] }}</span>
								@if ($importStatus === 'success')
									<span class="badge bg-success-transparent text-success flex-shrink-0">Done</span>
								@elseif ($importStatus === 'error')
									<span class="badge bg-danger-transparent text-danger flex-shrink-0">Error</span>
								@else
									<span class="badge bg-warning-transparent text-warning flex-shrink-0">In Progress</span>
								@endif
							</div>
							<div class="d-flex gap-3 fs-11 text-muted">
								@if (!is_null($log['total_rows']))
									<span>{{ number_format($log['total_rows']) }} rows</span>
								@endif
								@if (!is_null($log['success_count']))
									<span class="text-success">{{ number_format($log['success_count']) }} ok</span>
								@endif
								@if (!is_null($log['error_count']) && $log['error_count'] > 0)
									<span class="text-danger">{{ number_format($log['error_count']) }} err</span>
								@endif
								<span>{{ $log['created_at'] }}</span>
							</div>
						</a>
					</li>
					@endforeach
				</ul>
				<div class="p-5 text-center {{ $importData->isEmpty() ? '' : 'd-none' }}" id="{{ $id }}_import_empty">
					<span class="avatar avatar-xl avatar-rounded bg-secondary-transparent">
						<i class="ri-file-upload-line fs-2"></i>
					</span>
					<h6 class="fw-medium mt-3">No Import Logs</h6>
				</div>
			</x-core::tab-content>

		</x-slot:content>
	</x-core::tab>
</x-core::offcanvas>
@endpush
