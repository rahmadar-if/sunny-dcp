<x-core::table-column name="_selectall" :attributes="$attributes">
    <input class="form-check-input check-all" type="checkbox">
</x-core::table-column>