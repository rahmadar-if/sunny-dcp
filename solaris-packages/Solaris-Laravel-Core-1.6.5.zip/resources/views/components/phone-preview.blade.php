@props([
	'id',
	'device'     => null,
	'type'       => 'iphone',
	'notch'      => 'dynamic-island',
	'size'       => 'md',
	'width'      => null,
	'height'     => null,
	'bezel'      => 'md',
	'color'      => 'dark',
	'scale'      => null,
	'status_bar' => true,
	'nav_bar'    => false,
	'ignore'     => false,
])

@php
	$devicePresets = [
		'iphone-17'         => ['type' => 'iphone',  'notch' => 'dynamic-island', 'size' => 'lg'],
		'iphone-17-pro'     => ['type' => 'iphone',  'notch' => 'dynamic-island', 'size' => 'lg'],
		'iphone-16'         => ['type' => 'iphone',  'notch' => 'dynamic-island', 'size' => 'md'],
		'iphone-16-plus'    => ['type' => 'iphone',  'notch' => 'dynamic-island', 'size' => 'lg'],
		'iphone-15'         => ['type' => 'iphone',  'notch' => 'pill',           'size' => 'md'],
		'iphone-15-pro'     => ['type' => 'iphone',  'notch' => 'dynamic-island', 'size' => 'lg'],
		'samsung-s25-ultra' => ['type' => 'android', 'notch' => 'punch-hole',     'size' => 'xl'],
		'samsung-s25'       => ['type' => 'android', 'notch' => 'punch-hole',     'size' => 'lg'],
		'pixel-9-pro'       => ['type' => 'android', 'notch' => 'punch-hole',     'size' => 'lg'],
		'pixel-9'           => ['type' => 'android', 'notch' => 'punch-hole',     'size' => 'lg'],
		'samsung-a55'       => ['type' => 'android', 'notch' => 'punch-hole',     'size' => 'md'],
		'samsung-a35'       => ['type' => 'android', 'notch' => 'punch-hole',     'size' => 'md'],
		'samsung-a25'       => ['type' => 'android', 'notch' => 'punch-hole',     'size' => 'md'],
		'samsung-a15'       => ['type' => 'android', 'notch' => 'bar',            'size' => 'sm'],
		'samsung-a05'       => ['type' => 'android', 'notch' => 'bar',            'size' => 'sm'],
	];

	$sizeMap = [
		'sm' => ['width' => 300, 'height' => 620],
		'md' => ['width' => 320, 'height' => 660],
		'lg' => ['width' => 360, 'height' => 740],
		'xl' => ['width' => 390, 'height' => 780],
	];

	$bezelMap = [
		'none' => 0,
		'xs'   => 6,
		'sm'   => 10,
		'md'   => 14,
		'lg'   => 20,
	];

	if (!empty($device) && isset($devicePresets[$device])) {
		$preset = $devicePresets[$device];
		$type   = $preset['type'];
		$notch  = $preset['notch'];
		$size   = $preset['size'];
	}

	$resolvedWidth  = !is_null($width)  ? (int) $width  : ($sizeMap[$size]['width']  ?? 320);
	$resolvedHeight = !is_null($height) ? (int) $height : ($sizeMap[$size]['height'] ?? 660);
	$resolvedBezel  = $bezelMap[$bezel] ?? 14;
	$resolvedScale  = !is_null($scale)  ? (float) $scale : 1;

	$isBarNotch   = $notch === 'bar';
	$barHasStatus = $isBarNotch && $status_bar;

	$inlineStyle = implode('; ', [
		"--pc-width: {$resolvedWidth}px",
		"--pc-height: {$resolvedHeight}px",
		"--pc-bezel: {$resolvedBezel}px",
		"--pc-scale: {$resolvedScale}",
	]);
@endphp

<div {{
	$attributes->merge([
		'id'       => $id,
		'solar-ui' => 'phone-preview',
		'ignore'   => $ignore === true,
		'style'    => $inlineStyle,
	])
	->class([
		'phone-preview',
		"pc-type-{$type}",
		"pc-notch-{$notch}",
		"pc-color-{$color}",
	])
}}>
	<div class="pc-frame">
		<div class="pc-btn pc-btn-mute"></div>
		<div class="pc-btn pc-btn-vol-up"></div>
		<div class="pc-btn pc-btn-vol-down"></div>
		<div class="pc-btn pc-btn-power"></div>

		<div class="pc-screen">
			<div class="pc-notch-wrap">
				<div @class(['pc-notch', 'pc-notch-with-status' => $barHasStatus])>
					@if ($barHasStatus)
					<span class="pc-status-time">9:41</span>
					<div class="pc-status-icons">
						<i class="bi bi-reception-4"></i>
						<i class="bi bi-wifi"></i>
						<i class="bi bi-battery-half"></i>
					</div>
					@endif
				</div>
			</div>

			@if ($status_bar && !$isBarNotch)
			<div class="pc-status-bar">
				<span class="pc-status-time">9:41</span>
				<div class="pc-status-icons">
					<i class="bi bi-reception-4"></i>
					<i class="bi bi-wifi"></i>
					<i class="bi bi-battery-half"></i>
				</div>
			</div>
			@endif

			<div class="pc-content">
				{{ $slot }}
			</div>

			@if ($nav_bar && $type === 'android')
			<div class="pc-nav-bar">
				<div class="pc-nav-btn pc-nav-back"></div>
				<div class="pc-nav-btn pc-nav-home"></div>
				<div class="pc-nav-btn pc-nav-recents"></div>
			</div>
			@endif

			<div class="pc-home-indicator"></div>
		</div>
	</div>
</div>
