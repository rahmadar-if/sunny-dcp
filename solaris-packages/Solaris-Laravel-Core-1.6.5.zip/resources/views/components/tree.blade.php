@props([
    "id",
    "lazy" => false,
    "ignore" => false
])

<div {{ $attributes->merge([
    "id" => $id,
    "lazy" => $lazy,
    "ignore" => $ignore
]) }}>
    
    <div id="{{ $id }}_container">
        <ul class="tree-root" id="{{ $id }}_root"></ul>
    </div>

</div>

@push("modal-content")
    <x-core::modal 
        id="{{ $id }}_delete_modal" 
        title="Delete Confirmation" 
        size="md" 
        center
        ignore>
        
        <input type="hidden" name="delete_node_id" />
        <p class="delete_message mb-3"></p>
        
        <div class="d-flex flex-column gap-2">
            <button type="button" class="btn btn-outline-danger delete-all-btn">
                <i class="ri-delete-bin-line me-1"></i>
                <span class="delete-all-label">Delete with all children</span>
            </button>
            <button type="button" class="btn btn-outline-warning delete-parent-btn">
                <i class="ri-subtract-line me-1"></i>
                <span class="delete-parent-label">Delete only this item</span>
            </button>
        </div>

        <x-slot:footer>
            <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
        </x-slot:footer>
    </x-core::modal>
@endpush