@props([
	'id'                => null,
	'value'             => 0,
	'decimals'          => 2,
	'decimalSeparator'  => ',',
	'thousandSeparator' => '.',
	'prefix'            => null,
	'sizeClass'         => 'fs-13',
	'class'             => null,
])

@php
	use Solaris\Core\Helpers\Number;

	$readable = Number::readableNumber($value, $decimals, $decimalSeparator, $thousandSeparator, true);
	$full     = Number::readableNumber($value, $decimals, $decimalSeparator, $thousandSeparator, false);
@endphp

<span {{ $attributes
	->class([$sizeClass, $class])
	->merge([
		'id'                 => $id,
		'solar-ui'           => 'numeral',
		'decimals'           => $decimals,
		'decimal-separator'  => $decimalSeparator,
		'thousand-separator' => $thousandSeparator,
	]) }}>
	@if ($prefix)
		<span class="numeral-prefix">{{ $prefix }}</span>
	@endif
	<span class="numeral-readable">{{ $readable }}</span>
	<span class="numeral-full d-none">{{ $full }}</span>
</span>
