@props([
    'id' => null
])

@php
    $bodyAttrs = new \Illuminate\View\ComponentAttributeBag(
        collect($attributes->whereStartsWith('body:')->all())
            ->mapWithKeys(fn($value, $key) => [Str::after($key, 'body:') => $value])
            ->all()
    );
    $bodyAttrs = $bodyAttrs->class(['card-body']);
@endphp

<div {{ $attributes->merge(['id' => $id])->class(["card", "custom-card"]) }}>
    @if (isset($header))
        <div {{ $header->attributes->class(['card-header']) }}>
            {{ $header }}
        </div>
    @endif
    
    <div {{ $bodyAttrs }}>
        {{ $slot }}
    </div>

    @if (isset($footer))
        <div {{ $footer->attributes->class(['card-footer']) }}>
            {{ $footer }}
        </div>
    @endif
</div>