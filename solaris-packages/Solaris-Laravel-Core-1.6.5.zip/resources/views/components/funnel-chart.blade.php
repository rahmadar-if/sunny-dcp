@props([
    "id",
    "data"     => [],
    "maxWidth" => 100,
    "minWidth" => 20,
    "heigth"   => 100,
    "ignore"   => false,
    "lazy"     => false
])

<div {{ 
    $attributes->merge([
        "id"        => $id,
        "solar-ui"  => "funnel-chart",
        "lazy"      => $lazy,
        "ignore"    => $ignore,
        "max-width" => $maxWidth,
        "min-width" => $minWidth,
        "height"    => $heigth,
        "data"      => json_encode($data),
        "style"     => "width: 100%",
    ])
    ->class(["solar-funnel"])
}}>
</div>