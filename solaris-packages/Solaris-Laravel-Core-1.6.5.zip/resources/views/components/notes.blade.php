@props([
    "id",
    "bind"         => null,
    "lazy"         => false,
    "ignore"       => false,
    "record_id"    => null,
    "model"        => null,
    "column"       => null,
    "pdf_filename" => null,
])

@php
    if(!empty($id) && empty($bind) && str_contains($id, ":")) {
        $splitId = explode(":", $id);
        $id      = $splitId[0];
        $bind    = $splitId[1];
    }
@endphp

<div id="{{ $id }}" {{ 
    $attributes->merge([
        "solar-ui"   => "notes",
        "solar-bind" => !empty($bind) ? $bind : $id,
        "lazy"       => $lazy === true,
        "ignore"     => $ignore === true,
        "record-id"    => $record_id,
        "model"        => $model,
        "column"       => $column,
        "pdf-filename" => $pdf_filename,
    ]) 
}}>
    @if (!$slot->isEmpty())
        <div id="{{ $id }}_value" class="d-none">{{ $slot }}</div>
    @endif

    <div id="{{ $id }}_editor"></div>
</div>