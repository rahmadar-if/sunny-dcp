@props([
    "id"         => null,
    "bind"       => null,
    "label"      => "",
    "required"   => false,
    "disabled"   => false,
    "hidden"     => false,
    "message"    => "",
    "error"      => false,
    "valid"      => false,
    "horizontal" => false,
    "lazy"       => false,
    "ignore"     => false
])

@php
    if(!empty($id) && empty($bind) && str_contains($id, ":")) {
        $splitId = explode(":", $id);
        $id      = $splitId[0];
        $bind    = $splitId[1];
    }

    $labelAttrs = new \Illuminate\View\ComponentAttributeBag(
        collect($attributes->whereStartsWith('label:')->all())
            ->mapWithKeys(fn($value, $key) => [Str::after($key, 'label:') => $value])
            ->all()
    );

    $fieldAttrs = new \Illuminate\View\ComponentAttributeBag(
        collect($attributes->whereStartsWith('field:')->all())
            ->mapWithKeys(fn($value, $key) => [Str::after($key, 'field:') => $value])
            ->all()
    );
    $fieldAttrs = $fieldAttrs->merge([
        "solar-id"   => $id,
        "solar-ui"   => "field",
        "solar-bind" => !empty($bind) ? $bind : $id,
        "required"   => $required === true,
        "disabled"   => $disabled === true,
        "lazy"       => $lazy === true,
        "ignore"     => $ignore === true
    ])
    ->class([
        "mb-3", 
        "row"    => $horizontal === true,
        "d-none" => $hidden === true
    ]);

    $messageAttrs = new \Illuminate\View\ComponentAttributeBag(
        collect($attributes->whereStartsWith('message:')->all())
            ->mapWithKeys(fn($value, $key) => [Str::after($key, 'message:') => $value])
            ->all()
    );
    $messageAttrs = $messageAttrs->toArray();
@endphp

<div {{ $fieldAttrs }}>
    <x-core::label 
        for="{{ $id }}" 
        :horizontal="$horizontal"
        :attributes="$labelAttrs" 
        :required="$required">
        {{ $label }}
    </x-core::label>

    @if ($horizontal === true)
    <div class="col-sm-9">
    @endif
    
    {{ $slot }}

    @if ($horizontal === true)
    
    <x-core::message-feedback 
        id="{{ $id }}-message"
        :error="$error"
        :valid="$valid">
        {{ $message }}
    </x-core::message-feedback>
    </div>

    @else
    
    <x-core::message-feedback 
        id="{{ $id }}-message"
        :error="$error"
        :valid="$valid">
        {{ $message }}
    </x-core::message-feedback>
    
    @endif
</div>