@props([
    "package" => null,
    "path"    => null
])

@php
    $base = "resources/js/pages";
    if($package) {
        $vendor = SolarHelper::config("resource.path.$package");
        if($vendor) {
            $base = $vendor."/js/pages";
        }
    }

    $vite = "";
    if(!is_null($path)) {
        $vite = "{$base}/{$path}.js";
    }

@endphp

{{ $slot }}

@push('scripts')
    @if (!empty($vite))
        @vite([$vite])
    @endif
@endpush