@props([
    "title"       => "Base Page",
    "breadcrumbs" => [],
    "model"       => null,
    "action"      => null,
    "package"     => null,
    "path"        => null
])

@extends('core::layouts.main')

@section('title', $title)
@section('page-title', $title)

@if (!empty($breadcrumbs))
    @section('breadcrumb')
    <x-core::breadcrumb :items="$breadcrumbs"/>
    @endsection
@endif

@section('top-buttons')
    @if (isset($buttons))
        {{ $buttons }}
    @endif
@endsection

@section('content')
    <x-core::page.page 
        :package="$package"
        :path="$path">

        {{ $slot }}

    </x-core::page.page>
@endsection