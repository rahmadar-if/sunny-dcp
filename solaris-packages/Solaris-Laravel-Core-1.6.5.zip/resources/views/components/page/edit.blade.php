@props([
    "id"              => null,
    "title"           => "Edit page",
    "breadcrumbs"     => [],
    "model"           => null,
    "action"          => null,
    "path"            => null,
    "package"         => null,
    "profilePosition" => 'right', // right|left
    "profileClass"    => 'col-xxl-3 col-lg-4',
    "mainClass"       => 'col-xxl-9 col-lg-8',
    "mainCard"        => true,
    "save"            => true
])

<x-core::page.base 
    :title="$title"
    :breadcrumbs="$breadcrumbs"
    :package="$package" 
    :path="$path">

    <x-slot:buttons>
        @if (isset($preButtons)) {{ $preButtons }} @endif

        @if($save) 
            <x-core::button id="_save">Save</x-core::button> 
        @endif
        
        <x-core::cancel-button />
        <x-core::refresh-button id="_refresh" />

        @if (isset($buttons)) {{ $buttons }} @endif
    </x-slot>

    <x-core::form 
        id="_form" 
        :method="is_null($id) ? 'POST' : 'PUT'" 
        :model="$model"
        :action="!is_null($action) ? $action : null">

        <input type="hidden" name="_id" value="{{ $id }}">

        @if (isset($header))
            {{ $header }}
        @endif

        <div class="row">
            @if ($profilePosition == 'left' && isset($profile))
                <div {{ $profile->attributes->class([$profileClass]) }}>
                    {{ $profile }}
                </div>
            @endif

            <div class="{{ isset($profile) ? $mainClass : 'col-lg-12' }}">
                @if($mainCard)
                <x-core::card>
                    {{ $slot }}
                </x-core::card>
                @else
                    {{ $slot }}
                @endif

                @if (isset($footer))
                    {{ $footer }}
                @endif
            </div>

            @if ($profilePosition == 'right' && isset($profile))
                <div {{ $profile->attributes->class([$profileClass]) }}>
                    {{ $profile }}
                </div>
            @endif

        </div>

    </x-core::form>

</x-core::page.base>