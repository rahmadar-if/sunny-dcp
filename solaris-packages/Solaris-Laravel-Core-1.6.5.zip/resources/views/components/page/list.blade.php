@props([
    "id",
    "title"       => "List page",
    "breadcrumbs" => [],
    "package"     => null,
    "path"        => null
])

<x-core::page.base 
    :title="$title"
    :breadcrumbs="$breadcrumbs"
    :package="$package" 
    :path="$path">

    @if (isset($buttons))
    <x-slot:buttons>
        {{ $buttons }}
    </x-slot>
    @endif

    @if (isset($header))
        {{ $header }}
    @endif

    <x-core::table {{ $attributes->merge(['id' => $id.'_list']) }}>

        @if (isset($tableHeader))
            <x-slot:header>
                {{ $tableHeader }}
            </x-slot>
        @endif

        @if (isset($tableAction))
            <x-slot:action>
                {{ $tableAction }}
            </x-slot>
        @endif

        @if (isset($tablePreLeftAction))
            <x-slot:pre-left-action>
                {{ $tablePreLeftAction }}
            </x-slot>
        @endif

        @if (isset($tableLeftAction))
            <x-slot:left-action>
                {{ $tableLeftAction }}
            </x-slot>
        @endif

        @if (isset($tablePreRightAction))
            <x-slot:pre-right-action>
                {{ $tablePreRightAction }}
            </x-slot>
        @endif

        @if (isset($tableRightAction))
            <x-slot:right-action>
                {{ $tableRightAction }}
            </x-slot>
        @endif

        @if (isset($tableColumn))
            <x-slot:column :attributes="$tableColumn->attributes">
                {{ $tableColumn }}
            </x-slot>
        @endif

        @if (isset($tableBody))
            <x-slot:body :attributes="$tableBody->attributes">
                {{ $tableBody }}
            </x-slot>
        @endif
    </x-core::table>

    {{ $slot }}

</x-core::page.base>