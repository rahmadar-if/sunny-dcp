@props([
	"title",
	"package" => null,
	"path"    => null
])

@php
	$authPreset = SolarHelper::config('auth.default', 'default');
@endphp

<x-core::page.blank :title="$title" :package="$package" :path="$path">

	@push('styles')
		@if ($authPreset === 'v1')
			@vite([SolarAsset::css('pages/auth-v1.scss', 'core')])
		@elseif ($authPreset === 'v2')
			@vite([SolarAsset::css('pages/auth-v2.scss', 'core')])
		@else
			@vite([SolarAsset::css('pages/auth.scss', 'core')])
		@endif
	@endpush

	@if ($authPreset === 'v1')
		@include('core::partials.auth.v1', ['slot' => $slot])
	@elseif ($authPreset === 'v2')
		@include('core::partials.auth.v2', ['slot' => $slot])
	@else
		@include('core::partials.auth.default', ['slot' => $slot])
	@endif

</x-core::page.blank>