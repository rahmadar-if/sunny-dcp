@props([
    "id"      => null,
    "title"   => "Blank Page",
    "package" => null,
    "path"    => null
])

@extends('core::layouts.blank')

@section('title', $title)

@section('content')
    <x-core::page.page :package="$package" :path="$path">
        {{ $slot }}
    </x-core::page.page>
@endsection