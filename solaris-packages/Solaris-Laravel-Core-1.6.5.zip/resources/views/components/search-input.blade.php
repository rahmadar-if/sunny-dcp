@props([
    "size"      => null,
    "hidden"    => false,
    "ignore"    => false
]) 

@php
    $wrapAttr = new \Illuminate\View\ComponentAttributeBag(
        collect($attributes->whereStartsWith('wrap:')->all())
            ->mapWithKeys(fn($value, $key) => [Str::after($key, 'wrap:') => $value])
            ->all()
    );
    $wrapAttr = $wrapAttr->class([
        "custom-form-group",
        "d-none" => $hidden === true,
    ]);
@endphp

<div {{ $wrapAttr }}>
    <x-core::input {{ $attributes }} 
        solar-ui="input:search" class="pe-5" size="{{ $size }}" :ignore="$ignore"/>
    <a href="javascript:void(0);" class="custom-form-btn text-muted">
        <i class="ri-close-line align-middle reset-search d-none"></i>
        <i class="ri-search-line align-middle do-search"></i>
    </a>
</div>