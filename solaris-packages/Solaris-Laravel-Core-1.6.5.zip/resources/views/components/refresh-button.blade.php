@props([
    "id",
    "color"    => "secondary",
    "variant"  => "outline",
    "size"     => null,
    "icon"     => "ri-refresh-line",
    "ignore"   => false,
    "disabled" => false
])

<x-core::button 
    id="{{ $id }}" 
    :size="$size" 
    icon 
    :disabled="$disabled"
    :variant="$variant" 
    :ignore="$ignore"
    :color="$color"><i class="{{ $icon }}"></i>
</x-core::button>