@props([
    "id",
    "source" => null,
    "lazy"   => false,
    "ignore" => false
])

<x-core::card>
    <div id="{{ $id }}" {{ 
        $attributes->merge([
            "lazy"     => $lazy === true, 
            "ignore"   => $ignore === true,
            "source"   => $source,
            "solar-ui" => "calendar"
        ]) 
    }}></div>
</x-core::card>