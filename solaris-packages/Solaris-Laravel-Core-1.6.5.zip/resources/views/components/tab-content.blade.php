@props([
    "id",
    "active" => false
])

<div {{ 
    $attributes->class([
        "tab-pane fade overflow-hidden",
        "show active" => $active === true
    ]) 
}} 
    id="{{ $id }}" 
    role="tabpanel" 
    aria-labelledby="{{ $id }}" 
    tabindex="0">
    {{ $slot }}
</div>