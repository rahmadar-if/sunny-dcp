@props(['label'])

<div class="d-flex align-items-center gap-3 mb-3">
    <span class="fs-12 fw-semibold text-muted text-uppercase text-nowrap">{{ $label }}</span>
    <hr class="flex-grow-1 my-0">
</div>