@props([
    "name",
    "bind"     => null,
    "size"     => null, // md, lg
    "outline"  => false,
    "color"    => "primary", // primary, secondary, success, danger, info, light, dark,
    "square"   => false,
    "inline"   => false,
    "switch"   => false,
    "reverse"  => false,
    "options"  => [], // [['label' => '', 'id' => '', 'checked' => false]]
    "hidden"   => false,
    "disabled" => false,
    "lazy"     => false,
    "ignore"   => false
])

@php
    if(!empty($name) && empty($bind) && str_contains($name, ":")) {
        $splitId = explode(":", $name);
        $name    = $splitId[0];
        $bind    = $splitId[1];
    }

    $wrapAttr = new \Illuminate\View\ComponentAttributeBag(
        collect($attributes->whereStartsWith('wrap:')->all())
            ->mapWithKeys(fn($value, $key) => [Str::after($key, 'wrap:') => $value])
            ->all()
    );
    $wrapAttr = $wrapAttr->merge([
        "solar-ui"   => "input:checkbox-group",
        "solar-bind" => !empty($bind) ? $bind : $name,
        "lazy"       => $lazy === true,
        "ignore"     => $ignore === true,
        "solar-id"   => $name,
        "disabled"   => $disabled === true
    ])
    ->class([
        "d-none" => $hidden === true
    ]);
@endphp

<div {{ $wrapAttr }}>
    @foreach ($options as $option)
        @php
            $value    = is_array($option) ? $option['value'] ?? ($option['id'] ?? '') : $option->value ?? ($option->id ?? '');
            $id       = $name . '-' . $value;
            $label    = is_array($option) ? $option['label'] ?? '' : $option->label ?? '';
            $checked  = is_array($option) ? $option['checked'] ?? false : $option->checked ?? false;
            $disabled = is_array($option) ? $option['disabled'] ?? false : $option->disabled ?? false;
        @endphp

        <x-core::checkbox 
            :name="$name"
            :id="$id"
            :value="$value"
            :label="$label"
            :size="$size"
            :outline="$outline"
            :square="$square"
            :inline="$inline"
            :switch="$switch"
            :reverse="$reverse"
            :checked="$checked"
            :disabled="$disabled"
            ignore
        />
    @endforeach
</div>