@props([
    "size"            => null, // sm, lg
    "rounded"         => false,
    "square"          => false,
    "hidden"          => false,
    "options"         => [], // [['name' => '', 'value' => '', 'selected' => false, 'disabled' => false]]
    "attribute"       => [],
    "placeholder"     => null,
    "multiple"        => false,
    "lookup"          => false,
    "value"           => null, // json string
    "source"          => null, // lookup model
    "pagination"      => false,
    "lazy"            => false,
    "ignore"          => false,
    "extend_columns"  => null,
    "extend_search"   => null,
    "order_by"        => null, // "column" or "column:desc"
    "link_url"        => null, // template string e.g. "/users/{id}"
    "link_target"     => "_blank"
])

@if ($lookup)
<x-core::lookup
    :size="$size"
    :hidden="$hidden"
    :options="$options"
    :attribute="$attribute"
    :placeholder="$placeholder"
    :multiple="$multiple"
    :value="$value"
    :source="$source"
    :pagination="$pagination"
    :lazy="$lazy"
    :ignore="$ignore"
    :extend_columns="$extend_columns"
    :extend_search="$extend_search"
    :order_by="$order_by"
    :link_url="$link_url"
    :link_target="$link_target"
    {{ $attributes }}
/>
@else
<select {{
    $attributes->merge([
        "solar-ui" => $multiple === true ? "select:multiple" : "select",
        "multiple" => $multiple === true,
        "lazy"     => $lazy === true,
        "ignore"   => $ignore === true,
    ])
    ->merge($attribute)
    ->class([
        "form-select",
        "form-select-{$size}" => !is_null($size) && in_array($size, ["sm", "lg"]),
        "rounded-pill"        => $rounded === true && $square === false,
        "rounded-0"           => $rounded === false && $square === true,
        "d-none"              => $hidden === true,
    ])
}}>
    @php
        $isNotSelected = count(array_filter($options, fn($option) => is_array($option) ? $option['selected'] ?? false : $option->selected ?? false)) === 0;
    @endphp
    <option value="" {{ $isNotSelected && $multiple === false ? "selected" : "" }} {{ $multiple === true ? "disabled" : "" }}>{{ empty($placeholder) ? ($multiple === true ? "Choose multiple" : "Choose one") : $placeholder }}</option>

    @foreach ($options as $option)
        @php
            $_value  = is_array($option) ? $option['value'] ?? '' : $option->value ?? '';
            $text    = is_array($option) ? ($option['name'] ?? $option['text'] ?? '') : ($option->name ?? $option->text ?? '');
            $selected = is_array($option) ? $option['selected'] ?? false : $option->selected ?? false;

            if (!is_null($value) && $value == $_value) {
                $selected = true;
            }
        @endphp
        <option value="{{ $_value }}" {{ $selected ? "selected" : "" }}>{{ $text }}</option>
    @endforeach

</select>
@endif