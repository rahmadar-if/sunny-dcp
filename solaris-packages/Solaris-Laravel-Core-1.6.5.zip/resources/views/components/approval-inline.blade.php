@props(['model', 'model_id', 'card' => true])

@php
	use Solaris\Core\Models\ApprovalAssignment;

	$assignments = ApprovalAssignment::pending(Auth::id())
		->whereHas('level.request', fn($q) => $q
			->where('subject_type', $model)
			->where('subject_id', $model_id)
		)
		->get();
@endphp

@if ($assignments->isNotEmpty())
	@foreach ($assignments as $assignment)
	@php $req = $assignment->level?->request @endphp
	@if ($card)
	<div class="card custom-card">
		<div class="card-body">
	@endif
			<div class="d-flex flex-column gap-1 solar-approval-inline"
				data-assignment-id="{{ $assignment->id }}">
				<div class="d-flex align-items-start justify-content-between gap-2">
					<div>
						<p class="fw-semibold mb-0 fs-14">{{ $req?->name }}</p>
						@if ($req?->description)
							<span class="fs-12 text-muted">{{ $req->description }}</span>
						@endif
						<span class="fs-12 d-block mt-1">Requested by: <strong>{{ $req?->requester?->name }}</strong></span>
					</div>
					<span class="badge bg-warning-transparent text-warning flex-shrink-0">Pending Approval</span>
				</div>
				<div class="d-flex gap-2 mt-2">
					<x-core::button variant="outline" color="success" size="sm" ignore
						class="inline-approve" :data-id="$assignment->id">
						<i class="ri-checkbox-circle-line me-1"></i>Approve
					</x-core::button>
					<x-core::button variant="outline" color="danger" size="sm" ignore
						class="inline-reject" :data-id="$assignment->id">
						<i class="ri-close-circle-line me-1"></i>Reject
					</x-core::button>
				</div>
			</div>
	@if ($card)
		</div>
	</div>
	@endif
	@endforeach
@endif
