@props([
	'direction',
	'text'       => null,
	'time',
	'status'     => null,
	'type'       => 'text',
	'caption'    => null,
	'filename'   => null,
	'mediaUrl'       => null,
	'mediaThumbnail' => null,
	'date'       => null,
	'messageId'  => null,
	'continued'  => false,
	'attachmentId' => null,
	'imageWidth'   => null,
	'imageHeight'  => null,
	'replyTo'      => null,
])

@php
	use Illuminate\Support\Str;

	$isOutbound = $direction === 'sent';

	$statusIcon = match($status) {
		'read'      => 'ri-check-double-line text-info',
		'delivered' => 'ri-check-double-line',
		'sent'      => 'ri-check-line',
		'pending'   => 'ri-time-line',
		'failed'    => 'ri-error-warning-line text-danger',
		default     => null,
	};

	$formatWa = function (?string $str): string {
		if (!$str) {
			return '';
		}

		$html = e($str);
		$html = preg_replace('/```([\s\S]*?)```/', '<code class="wa-code-block">$1</code>', $html);
		$html = preg_replace('/`([^`\n]+)`/', '<code class="wa-code">$1</code>', $html);
		$html = preg_replace('/\*([^\s*](?:[^*\n]*[^\s*])?)\*/', '<strong>$1</strong>', $html);
		$html = preg_replace('/_([^\s_](?:[^_\n]*[^\s_])?)_/', '<em>$1</em>', $html);
		$html = preg_replace('/~([^\s~](?:[^~\n]*[^\s~])?)~/', '<s>$1</s>', $html);
		$html = str_replace(["\r\n", "\n"], '<br>', $html);

		return $html;
	};
@endphp

@if($date)
	<li class="chat-day-label">
		<span>{{ $date }}</span>
	</li>
@endif

<li class="{{ $isOutbound ? 'chat-item-end' : 'chat-item-start' }}{{ $continued ? ' continued' : '' }}"
	@if($messageId) data-message-id="{{ $messageId }}" @endif>
	<div class="chat-list-inner">
		<div class="main-chat-msg">
			<div>
				@if($replyTo)
					<div class="chat-quote-block{{ ($replyTo['unavailable'] ?? false) ? ' chat-quote-unavailable' : '' }}">
						@if($replyTo['unavailable'] ?? false)
							<span class="chat-quote-snippet fst-italic">Original message unavailable</span>
						@else
							@if($replyTo['thumbnail_url'] ?? null)
								<img src="{{ $replyTo['thumbnail_url'] }}" alt="" class="chat-quote-thumb">
							@endif
							<div class="chat-quote-text">
								<span class="chat-quote-sender">{{ $replyTo['direction'] === 'sent' ? 'You' : 'Contact' }}</span>
								<span class="chat-quote-snippet">{{ Str::limit($replyTo['caption'] ?? $replyTo['text'] ?? ucfirst($replyTo['type']), 60) }}</span>
							</div>
						@endif
					</div>
				@endif

				{{-- Image --}}
				@if($type === 'image' && ($mediaThumbnail || $mediaUrl))
					@php $isMediaReady = $attachmentId !== null; @endphp
					<div class="chat-media-wrap mb-1">
						@if($isMediaReady)
							<a class="img-preview" href="{{ $mediaUrl }}"
							   @if($imageWidth) data-pswp-width="{{ $imageWidth }}" @endif
							   @if($imageHeight) data-pswp-height="{{ $imageHeight }}" @endif>
								<img src="{{ route('core.images.thumbnail', $attachmentId) }}"
									 alt="image" class="chat-media-image" loading="lazy"
									 @if($mediaThumbnail) data-fallback-src="{{ $mediaThumbnail }}" @endif>
							</a>
						@else
							<img src="{{ $mediaThumbnail ?? $mediaUrl }}"
								 alt="image" class="chat-media-image chat-media-blurred" loading="lazy">
							<div class="chat-media-spinner"><i class="ri-loader-4-line"></i></div>
						@endif
					</div>
					@if($caption)
						<p class="mb-0">{!! $formatWa($caption) !!}</p>
					@endif

				{{-- Video --}}
				@elseif($type === 'video')
					@php $isVideoReady = $attachmentId !== null; @endphp
					<div class="chat-media-wrap mb-1{{ $isVideoReady ? ' chat-video-thumb-wrap' : '' }}"
						 @if($isVideoReady && $mediaUrl) data-video-url="{{ $mediaUrl }}" @endif>
						@if($mediaThumbnail || $isVideoReady)
							<img src="{{ $mediaThumbnail ?? '' }}"
								 alt="video thumbnail"
								 class="chat-media-image{{ $isVideoReady ? '' : ' chat-media-blurred' }}"
								 loading="lazy">
						@else
							<div class="chat-video-placeholder"><i class="ri-video-line"></i></div>
						@endif
						@if($isVideoReady)
							<button type="button" class="chat-video-play-btn" aria-label="Play video">
								<i class="ri-play-circle-fill"></i>
							</button>
						@else
							<div class="chat-media-spinner"><i class="ri-loader-4-line"></i></div>
						@endif
					</div>
					@if($caption)
						<p class="mb-0">{!! $formatWa($caption) !!}</p>
					@endif

				{{-- Document --}}
				@elseif($type === 'document' && ($filename || $mediaUrl))
					<div class="chat-bubble-doc">
						<div class="chat-bubble-doc-icon">
							<i class="ri-file-text-line"></i>
						</div>
						<span class="chat-bubble-doc-name">{{ $filename ?? 'Document' }}</span>
						@if($mediaUrl)
							<button type="button" class="chat-bubble-doc-dl"
									data-url="{{ $mediaUrl }}"
									data-filename="{{ $filename ?? 'document' }}"
									title="Download">
								<i class="ri-download-2-line"></i>
							</button>
						@elseif(!$isOutbound)
							<div class="chat-bubble-doc-pending" title="Processing">
								<i class="ri-loader-4-line"></i>
							</div>
						@endif
					</div>
					@if($caption)
						<p class="mb-0 mt-1">{!! $formatWa($caption) !!}</p>
					@endif

				{{-- Audio --}}
				@elseif($type === 'audio')
					<div class="chat-audio-player">
						<button type="button" class="chat-audio-play-btn" aria-label="Play audio">
							<i class="{{ $mediaUrl ? 'ri-play-fill' : 'ri-loader-4-line' }}"></i>
						</button>
						<div class="chat-audio-track">
							<div class="chat-audio-progress">
								<div class="chat-audio-progress-fill"></div>
								<div class="chat-audio-progress-thumb"></div>
								<input type="range" class="chat-audio-range" value="0" min="0" max="100" step="0.1"
									   {{ $mediaUrl ? '' : 'disabled' }}>
							</div>
							<span class="chat-audio-time">0:00</span>
						</div>
						<audio @if($mediaUrl) src="{{ $mediaUrl }}" @endif preload="none" data-audio-el></audio>
					</div>

				{{-- Text (default) --}}
				@else
					<p class="mb-0">{!! $formatWa($text) !!}</p>
				@endif

				{{-- Meta: time + read status --}}
				<div class="chat-bubble-meta">
					@if($isOutbound && $statusIcon)
						<i class="{{ $statusIcon }} fs-14"></i>
					@endif
					<span class="msg-time">{{ $time }}</span>
				</div>
			</div>
		</div>
	</div>
</li>
