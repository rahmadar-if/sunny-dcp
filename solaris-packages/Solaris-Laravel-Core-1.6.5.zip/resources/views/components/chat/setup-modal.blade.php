<x-core::modal-box
    id="setup-modal"
    title="Device Setup"
    size="lg"
    :cancel="false"
    ignore>

    {{-- Loading --}}
    <div id="setup-modal_state-loading" class="text-center py-5">
        <div class="spinner-border text-primary" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
        <p class="text-muted small mt-3 mb-0">Loading device information...</p>
    </div>

    {{-- Info --}}
    <div id="setup-modal_state-info" class="d-none">
        <div class="d-flex align-items-center justify-content-between rounded border px-3 py-3 mb-4">
            <div>
                <div class="fw-semibold" id="setup-modal_device-name">—</div>
                <div class="text-muted small mt-1" id="setup-modal_phone-number">—</div>
            </div>
            <span id="setup-modal_status-badge" class="badge px-3 py-2">—</span>
        </div>

        <div id="setup-modal_quota-section" class="d-none mb-4">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="text-uppercase fw-semibold small text-muted letter-spacing-1">Quota</span>
                <span class="small text-muted">
                    <span id="setup-modal_quota-package" class="badge bg-light text-dark border me-1">—</span>
                    until <span id="setup-modal_quota-expires">—</span>
                </span>
            </div>
            <div class="progress mb-2" style="height: 8px; border-radius: 4px;">
                <div id="setup-modal_quota-bar" class="progress-bar" role="progressbar" style="width: 0%;"></div>
            </div>
            <div class="d-flex justify-content-between small text-muted">
                <span id="setup-modal_quota-used-text">—</span>
                <span id="setup-modal_quota-pct" class="fw-semibold">—</span>
            </div>
        </div>

        <div id="setup-modal_daily-section" class="d-none">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="text-uppercase fw-semibold small text-muted">Daily Limit</span>
                <span class="small text-muted" id="setup-modal_daily-text">—</span>
            </div>
            <div class="progress" style="height: 8px; border-radius: 4px;">
                <div id="setup-modal_daily-bar" class="progress-bar bg-warning" role="progressbar" style="width: 0%;"></div>
            </div>
        </div>
    </div>

    {{-- QR Scan --}}
    <div id="setup-modal_state-qr" class="d-none">
        <div class="d-flex align-items-center justify-content-between rounded border px-3 py-3 mb-4">
            <div class="fw-semibold" id="setup-modal_qr-device-name">—</div>
            <span class="badge bg-warning text-dark px-3 py-2">Waiting for Scan</span>
        </div>

        <div class="text-center">
            <p class="text-muted small mb-4">
                Open WhatsApp → tap the three dots → <strong>Linked Devices</strong>
                → <strong>Link a Device</strong> → point your camera at the QR code below
            </p>

            <div id="setup-modal_qr-spinner" class="py-4">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Waiting for QR...</span>
                </div>
                <p class="text-muted small mt-2 mb-0">Preparing QR code...</p>
            </div>

            <div id="setup-modal_qr-img-wrap" class="d-none">
                <img id="setup-modal_qr-img"
                     src=""
                     alt="QR Code"
                     style="width: 256px; height: 256px; object-fit: contain; border-radius: 8px; border: 1px solid var(--bs-border-color);">
            </div>
        </div>
    </div>

    {{-- Error --}}
    <div id="setup-modal_state-error" class="d-none text-center py-5">
        <i class="ri-error-warning-line fs-1 text-danger"></i>
        <p class="text-muted small mt-2 mb-0" id="setup-modal_error-msg">Failed to load device information.</p>
    </div>

    <x-slot:buttons>
        <x-core::button id="setup-modal_btn-refresh" color="light" class="d-none" ignore>
            <i class="ri-refresh-line me-1"></i>Refresh
        </x-core::button>
        <x-core::button id="setup-modal_btn-connect" color="success" class="d-none" ignore>
            <i class="ri-smartphone-line me-1"></i>Connect
        </x-core::button>
        <x-core::button id="setup-modal_btn-disconnect" color="danger" class="d-none" ignore>
            <i class="ri-logout-box-line me-1"></i>Disconnect
        </x-core::button>
        <x-core::button id="setup-modal_btn-cancel-qr" color="light" class="d-none" ignore>
            Cancel
        </x-core::button>
        <x-core::button data-bs-dismiss="modal" color="light" ignore>Close</x-core::button>
    </x-slot:buttons>

</x-core::modal-box>
