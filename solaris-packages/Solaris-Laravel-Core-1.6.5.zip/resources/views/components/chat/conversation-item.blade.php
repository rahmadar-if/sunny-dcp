@props([
	'conversationId',
	'name',
	'preview'           => '',
	'time'              => '',
	'unreadCount'       => 0,
	'active'            => false,
	'phone'             => null,
	'typing'            => false,
	'profilePictureUrl' => null,
	'previewWidth'		=> null,
	'previewHeight'		=> null,
])

@php
	$initials = collect(explode(' ', trim($name)))
		->filter()
		->take(2)
		->map(fn ($word) => mb_strtoupper(mb_substr($word, 0, 1)))
		->implode('');

	$avatarColors = ['primary', 'secondary', 'success', 'info', 'warning', 'danger'];
	$avatarColor  = $avatarColors[ord(mb_strtolower($initials[0] ?? 'a')) % count($avatarColors)];
@endphp

<li class="{{ $active ? 'active' : '' }}"
	data-conversation-id="{{ $conversationId }}"
	data-name="{{ $name }}"
	data-phone="{{ $phone }}"
	data-initials="{{ $initials }}"
	data-color="{{ $avatarColor }}"
	data-profile-picture-url="{{ $profilePictureUrl ?? '' }}"
	data-active="{{ $active ? 'true' : 'false' }}">
	<div data-conversation-select style="cursor: pointer;">
		<div class="d-flex align-items-top">
			@if($profilePictureUrl)
				<span class="avatar avatar-md avatar-rounded me-2 flex-shrink-0">
					<a class="avatar-preview" href="{{ $profilePictureUrl }}"
					   @if($previewWidth) data-pswp-width="{{ $previewWidth }}" @endif
					   @if($previewHeight) data-pswp-height="{{ $previewHeight }}" @endif>
						<img src="{{ $profilePictureUrl }}" alt="{{ $name }}">
					</a>
				</span>
			@else
				<span class="avatar avatar-md avatar-rounded me-2 flex-shrink-0 fw-semibold
					  bg-{{ $avatarColor }}-transparent text-{{ $avatarColor }}">
					{{ $initials }}
				</span>
			@endif
			<div class="flex-fill min-w-0">
				<p class="mb-0 fw-semibold d-flex justify-content-between align-items-center gap-2">
					<span class="text-truncate">{{ $name }}</span>
					<span class="text-muted fw-normal fs-11 flex-shrink-0">{{ $time }}</span>
				</p>
				<p class="fs-12 mb-0 d-flex justify-content-between align-items-center gap-2">
					@if($typing)
						<span class="text-success fst-italic text-truncate">Typing...</span>
					@else
						<span class="chat-msg text-muted text-truncate">{!! $preview !!}</span>
					@endif
					@if($unreadCount > 0)
						<span class="badge bg-success rounded-pill flex-shrink-0">{{ $unreadCount }}</span>
					@endif
				</p>
			</div>
		</div>
	</div>
</li>
