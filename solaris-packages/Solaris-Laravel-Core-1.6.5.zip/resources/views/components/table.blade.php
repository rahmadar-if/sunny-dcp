@props([
    "id",
    "card_wrapper" => true,
    "mode"         => "simple", // simple, grid, card
    "new"          => true, // string for change label, add @ to action. New, New@account-modal, @account-modal
    "save_all"     => false,
    "discard_all"  => false,
    "search"       => true,
    "refresh"      => true,
    "import"       => false, // string for change label
    "export"       => false, // string for change label
    "pagination"   => true,
    "length"       => 10, 
    "lazy"         => false,
    "ignore"       => false,
    "hidden"       => false,
    "delete_all"   => false,
    "select_all"   => true,
    "vertical"     => null,
    
    // ModelName
    // ModelName@ModelScope
    // ModelName@ModelScope(param,param)
    // ModelName:ControllerName@ControllerMethod
    // ModelName:ControllerName@ControllerMethod(param,param)
    // ModelName:@ControllerMethod(param,param)
    // ModelName@ModelScope:@ControllerMethod(param,param)
    // ModelName@ModelScope(param,param):ControllerName@ControllerMethod(param,param)
    // !ControllerName@ControllerMethod
    // !ControllerName@ControllerMethod(param,param)
    "model" => null,

    // filter by string, or by array
    // ['status_id = 001', 'status_id = 001']
    // status_id = 001
    // name contains name
    // date between [1995-01-01, 1995-01-05]
    // name != udin, age > 10, name = "udin=udin"
    'filter' => null,

    // default order based on table, by string or array
    // name:asc
    // name:desc, budget:desc
    // ["name:desc", "name:desc"]
    'order_by' => null,

    // add another columns which not include in column header. string or array
    // status, type
    // ['status', 'type']
    'extend_columns' => null,

    // add extra columns to search scope without displaying as visible columns
    // string "col1,col2" or array ['col1', 'col2']
    'extend_search' => null,

    'fixedColumn' => false,

    'folder' => false
])

@php
    $isNew     = $new === true || !empty($new) ? true : false;
    $newLabel  = "New";
    $newAction = "";
    if($isNew && is_string($new)) {
        [$label, $newAction] = explode('@', $new . '@');
        $newLabel            = empty($label) ? $newLabel : $label;
    }

    $isImport    = $import === true || !empty($import) ? true : false;
    $importLabel = $isImport && is_string($import) ? $import : "Upload";

    $isExport    = $export === true || !empty($export) ? true : false;
    $exportLabel = $isExport && is_string($export) ? $export : "Download";

    $wrapperAttrs = new \Illuminate\View\ComponentAttributeBag(
        collect($attributes->whereStartsWith('wrapper:')->all())
            ->mapWithKeys(fn($value, $key) => [Str::after($key, 'wrapper:') => $value])
            ->all()
    );
    $wrapperAttrs = $wrapperAttrs->merge([
        "id"             => $id."_solar_wrapper",
        "solar-id"       => $id,
        "solar-ui"       => "table:".$mode,
        "model"          => $model,
        "length"         => is_numeric($length) ? $length : 10, 
        "new-action"     => $newAction,
        "filter"         => is_string($filter) ? $filter : (is_array($filter) && !empty($filter) ? json_encode($filter) : null),
        "order-by"       => is_string($order_by) ? $order_by : (is_array($order_by) && !empty($order_by) ? json_encode($order_by) : null),
        "extend-columns" => is_string($extend_columns) ? $extend_columns : (is_array($extend_columns) && !empty($extend_columns) ? json_encode($extend_columns) : null),
        "extend-search"  => is_string($extend_search) ? $extend_search : (is_array($extend_search) && !empty($extend_search) ? implode(',', $extend_search) : null),
        "lazy"           => $lazy,
        "fixed-column"   => $fixedColumn,
        "vertical"       => $vertical,
        "ignore"         => $ignore
    ])
    ->class([
        "card custom-card" => $card_wrapper === true,
        "d-none" => $hidden === true
    ]);
@endphp

@if ($card_wrapper)
    <div {{ $wrapperAttrs }}>
        @if (isset($header))
            <div {{ $header->attributes->class(["card-header"]) }}>
                {{ $header }}
            </div>
        @endif

        <div class="card-body">
@else
    <div {{ $wrapperAttrs }}>
        @if (isset($header))
            <div {{ $header->attributes->class(["mb-3"]) }}>
                {{ $header }}
            </div>
        @endif
@endif

<div class="d-flex justify-content-between align-items-center mb-3">

    <div class="d-flex flex-wrap align-items-center gap-2">
        @if (isset($preLeftAction))
            {{ $preLeftAction }}
        @endif

        @if ($isNew)
            <x-core::button id="{{ $id }}_table_new" size="sm" disabled ignore>
                <span class="ri-add-fill me-1"></span>{{ $newLabel }}
            </x-core::button>
        @endif
        
        @if (isset($action) || $select_all || $import || $export)
        <div class="dropdown" id="{{ $id }}_table_action">
            <x-core::button icon variant="outline" color="light" size="sm" data-bs-toggle="dropdown" aria-expanded="false" ignore>
                <i class="ri-more-2-fill"></i>
            </x-core::button>

            <ul class="dropdown-menu">
                @if ($select_all)
                    <li><a class="dropdown-item fs-12 select-all-action" href="javascript:void(0);"><i class="ri-checkbox-multiple-line me-1"></i>Multiple select</a></li>
                @endif

                @if ($import)
                    <li><a class="dropdown-item fs-12 import-action" href="javascript:void(0);"><i class="ri-upload-line me-1"></i>{{ $importLabel }}</a></li>
                @endif

                @if ($export)
                    <li><a class="dropdown-item fs-12 export-action" href="javascript:void(0);"><i class="ri-download-line me-1"></i>{{ $exportLabel }}</a></li>
                @endif
                
                @if (isset($action))
                    {{ $action }}
                @endif
            </ul>
        </div>
        @endif
        
        @if ($mode == "grid")
            @if ($save_all === true)
                <x-core::button id="{{ $id }}_table_save-all" size="sm" disabled color="success" class="d-none" ignore>
                    <span class="ri-save-line me-1"></span>Save All
                </x-core::button>
            @endif
            
            @if ($discard_all === true)
                <x-core::button id="{{ $id }}_table_discard-all" size="sm" disabled color="danger" class="d-none" ignore>
                    <span class="ri-close-line me-1"></span>Discard All
                </x-core::button>
            @endif
        @endif
        
        @if ($folder === true)
            <x-core::folder id="{{ $id }}_table_folder" :model="$model" ignore/>
        @endif

        @if (isset($leftAction))
            {{ $leftAction }}
        @endif

        <span id="{{ $id }}_table_selected"></span>
        <div class="dropdown">
            <x-core::button id="{{ $id }}_table_selected_action" variant="outline" color="light" size="sm" data-bs-toggle="dropdown" aria-expanded="false" hidden ignore>
                <i class="ri-more-2-fill"></i> Multiple Action
            </x-core::button>

            <ul class="dropdown-menu">
                <li><a class="dropdown-item fs-12 clear-all-selected-action" href="javascript:void(0);"><i class="ri-close-line me-1"></i>Clear All</a></li>
                
                @if ($delete_all)
                <li><a class="dropdown-item fs-12 delete-all-selected-action" href="javascript:void(0);"><i class="ri-delete-bin-line me-1"></i>Delete All</a></li>
                @endif
                
                @if (isset($selectedAction))
                    {{ $selectedAction }}
                @endif
            </ul>
        </div>

    </div>

    <div class="d-flex flex-wrap align-items-center gap-2">
        @if (isset($preRightAction))
            {{ $preRightAction }}
        @endif

        @if ($search === true)
            <x-core::search-input id="{{ $id }}_table_search" disabled size="sm" placeholder="Search" ignore />
        @endif

        @if ($refresh === true)
            <x-core::refresh-button id="{{ $id }}_table_refresh" disabled size="sm" color="light" ignore />
        @endif

        @if (isset($rightAction))
            {{ $rightAction }}
        @endif
    </div>

</div>

<div class="table-responsive">
    <table {{ 
        $attributes
            ->class([
                "table", 
                "solar-table",
                "card" => $mode === "card"
            ])
            ->merge([
                "id" => $id,
                "style" => $mode === "card" ? "background-color: transparent !important; border-color: transparent;" : null,
            ]) 
    }}>

        @if (isset($column))
            <thead {{ $column->attributes }}>
                {{ $column }}
            </thead>
        @endif

        @if (isset($body))
            <tbody {{ $body->attributes }}>
                {{ $body }}
            </tbody>
        @elseif ($mode === "card")
            <tbody class="d-flex flex-wrap gap-3"></tbody>
        @endif

    </table>

    <div class="table-loading">
        <div class="spinner"></div>
    </div>
</div>

@if ($card_wrapper)
    </div> {{-- card body end --}}
    <div class="card-footer border-top-0">
@endif

@if ($pagination)
    <div id="{{ $id }}_table_pagination" class="d-flex align-items-center {{ $card_wrapper ? "" : "mt-3" }}">
    </div>
@endif

@if ($card_wrapper)
    </div> {{-- card footer end --}}
    </div> {{-- card end --}}
@else
    </div> {{-- wrapper end --}}
@endif

@push('modal-content')
    @if ($export === true)
        @include("core::pages.table.excel.download-modal", ["id" => $id."_table_export_modal"])
    @endif

    @if ($import === true)
        @include("core::pages.table.excel.upload-modal", ["id" => $id."_table_import_modal"])
    @endif

    @if ($delete_all === true)
        @include("core::pages.table.batch-delete-progress", ["id" => $id."_table_batch_delete_modal"])
    @endif
@endpush