@props([
    "id",
    "title"      => null,
    "size"       => "lg",
    "fullscreen" => false,
    "ignore"     => false,
    "model"      => null,
    "action"     => null,
    "method"     => null,
    "center"     => true,
    "save"       => true,
    "cancel"     => true,
])

@php
    $isSave    = $save === true || !empty($save) ? true : false;
    $saveLabel = "Save";
    if($isSave && is_string($save)) {
        $saveLabel = empty($save) ? $saveLabel : $save;
    }
@endphp

<x-core::modal 
    :id="$id" 
    body:class="p-3 p-lg-4" 
    animation="scale" 
    static 
    :center="$center" 
    :size="$size" 
    :fullscreen="$fullscreen" 
    :ignore="$ignore">
    
    <x-slot:header class="border-0">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </x-slot>

    <div class="text-center mb-3">
        <h4 class="mb-2">{{ $title }}</h4>
    </div>

    <div class="p-lg-4 p-2">
        <x-core::form id="{{ $id }}_form" :model="$model" :action="$action" :method="$method" :ignore="$ignore">
            
            {{ $slot }}

            <div class="hstack gap-2 justify-content-center mt-4">
                @if (isset($buttons))
                    {{ $buttons }}
                @endif

                @if ($isSave)
                <x-core::button id="{{ $id }}_save" type="submit">{{ $saveLabel }}</x-core::button>
                @endif

                @if ($cancel)
                <x-core::button data-bs-dismiss="modal" color="light" aria-label="Close">Cancel</x-core::button>
                @endif
            </div>

        </x-core::form>

    </div>
</x-core::modal>