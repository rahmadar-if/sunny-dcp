@props([
    'name',
    'bind'     => null,
    'color'    => 'primary',
    'options'  => [], // [['value', 'label', 'description', 'icon', 'color', 'checked', 'disabled']]
    'hidden'   => false,
    'disabled' => false,
    'lazy'     => false,
    'ignore'   => false,
])

@php
    if (!empty($name) && empty($bind) && str_contains($name, ':')) {
        $splitId = explode(':', $name);
        $name    = $splitId[0];
        $bind    = $splitId[1];
    }

    $wrapAttr = new \Illuminate\View\ComponentAttributeBag(
        collect($attributes->whereStartsWith('wrap:')->all())
            ->mapWithKeys(fn($v, $k) => [\Illuminate\Support\Str::after($k, 'wrap:') => $v])
            ->all()
    );
    $wrapAttr = $wrapAttr->merge([
        'solar-ui'   => 'input:checkbox-card-group',
        'solar-bind' => !empty($bind) ? $bind : $name,
        'lazy'       => $lazy === true,
        'ignore'     => $ignore === true,
        'solar-id'   => $name,
        'disabled'   => $disabled === true,
    ])
    ->class([
        'd-flex flex-column gap-3',
        'd-none' => $hidden === true,
    ]);
@endphp

<div {{ $wrapAttr }}>
    @foreach ($options as $option)
        @php
            $optValue    = is_array($option) ? ($option['value'] ?? ($option['id'] ?? '')) : ($option->value ?? ($option->id ?? ''));
            $optId       = $name . '-' . $optValue;
            $optLabel    = is_array($option) ? ($option['label'] ?? null) : ($option->label ?? null);
            $optDesc     = is_array($option) ? ($option['description'] ?? null) : ($option->description ?? null);
            $optIcon     = is_array($option) ? ($option['icon'] ?? null) : ($option->icon ?? null);
            $optColor    = is_array($option) ? ($option['color'] ?? $color) : ($option->color ?? $color);
            $optChecked  = is_array($option) ? ($option['checked'] ?? false) : ($option->checked ?? false);
            $optDisabled = is_array($option) ? ($option['disabled'] ?? false) : ($option->disabled ?? false);
        @endphp

        <x-core::checkbox-card
            :name="$name"
            :id="$optId"
            :value="$optValue"
            :label="$optLabel"
            :description="$optDesc"
            :icon="$optIcon"
            :color="$optColor"
            :checked="$optChecked"
            :disabled="$optDisabled"
            :lazy="$lazy"
            ignore
        />
    @endforeach
    {{ $slot }}
</div>
