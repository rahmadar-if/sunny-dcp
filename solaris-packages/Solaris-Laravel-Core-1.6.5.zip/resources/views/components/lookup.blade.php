@props([
    "size"           => null, // sm, lg
    "hidden"         => false,
    "options"        => [],
    "attribute"      => [],
    "placeholder"    => null,
    "multiple"       => false,
    "value"          => null, // json encoded LookupItem or LookupItem[]
    "source"         => null,
    "pagination"     => false,
    "lazy"           => false,
    "ignore"         => false,
    "extend_columns" => null,
    "extend_search"  => null,
    "order_by"       => null, // "column" or "column:desc"
    "link_url"       => null, // template string e.g. "/users/{id}"
    "link_target"    => "_blank",
    "copy"           => true,
    "wrapper_class"  => null, // extra classes for .lki-wrapper, e.g. "w-auto" to override default width:100%
    "wrapper_style"  => null, // inline style for .lki-wrapper, e.g. "width: 200px"
    "table_lookup"         => false,  // bool: auto table-lookup mode (single name column, model from source)
    "table_lookup_column"  => 'name', // data column used as display name in auto table-lookup
    "table_lookup_columns" => null,   // override columns: [['label' => 'Name', 'data' => 'name', 'searchable' => true, 'orderable' => true], ...]
])

@php
    $lookupId      = $attributes->get('id');
    $tableLookupId = ($table_lookup === true && !empty($lookupId))
        ? $lookupId . '_tl'
        : null;

    $options       = collect($options);
    $sizeKey       = in_array($size, ['sm', 'lg']) ? $size : 'md';
    $isMultiple    = $multiple === true;
    $wrapperClass  = implode(' ', array_filter([
        'lki-wrapper',
        $isMultiple ? 'lki-multi' : null,
        $sizeKey !== 'md' ? "lki-{$sizeKey}" : null,
        $wrapper_class,
    ]));
    $dataOptions   = ($options->isNotEmpty() && is_null($source))
        ? json_encode($options->map(fn($o) => [
            'id'       => is_array($o) ? ($o['value'] ?? '') : ($o->value ?? ''),
            'name'     => is_array($o) ? ($o['name'] ?? $o['text'] ?? '') : ($o->name ?? $o->text ?? ''),
            'selected' => is_array($o) ? ($o['selected'] ?? false) : ($o->selected ?? false),
          ])->values()->all())
        : null;
@endphp

<div {{
    $attributes->merge([
        "solar-ui"       => "lookup",
        "solar-id"       => $lookupId,
        "multiple"       => $isMultiple,
        "hidden"         => $hidden === true,
        "placeholder"    => $placeholder,
        "value"          => $value,
        "source"         => $source,
        "pagination"     => $pagination === true && !is_null($source),
        "lazy"           => $lazy === true,
        "ignore"         => $ignore === true,
        "extend-columns" => !empty($extend_columns) ? $extend_columns : null,
        "extend-search"  => !empty($extend_search) ? $extend_search : null,
        "order-by"       => !empty($order_by) ? $order_by : null,
        "link-url"       => !empty($link_url) ? url($link_url) : null,
        "link-target"    => !empty($link_url) ? $link_target : null,
        "copy"           => $copy === true,
        "data-options"   => $dataOptions,
        "table-lookup"   => $tableLookupId,
    ])
    ->merge($attribute)
    ->class([
        "d-none" => $hidden === true,
    ])
    ->style("display:none")
}}></div>
<div class="{{ $wrapperClass }}" @if($wrapper_style) style="{{ $wrapper_style }}" @endif>
    <div class="lki-control">
        @if ($isMultiple)
            <div class="lki-tags">
                <span class="lki-placeholder">{{ $placeholder ?? 'Choose one' }}</span>
                <input type="text" class="lki-search" autocomplete="off" style="display:none">
            </div>
        @else
            <span class="lki-placeholder">{{ $placeholder ?? 'Choose one' }}</span>
            <input type="text" class="lki-search" autocomplete="off" style="display:none">
        @endif
        @if ($copy)
            <span class="lki-copy" style="display:none"><i class="ri-file-copy-line"></i></span>
        @endif
        <span class="lki-clear" style="display:none"><i class="ri-close-line"></i></span>
        <span class="lki-arrow"></span>
    </div>
</div>

@if ($table_lookup === true && $tableLookupId)
<x-core::table-lookup
    :id="$tableLookupId"
    :model="$source"
    :title="$placeholder ?? 'Choose'"
    :extend_columns="$extend_columns"
    :extend_search="$extend_search"
    :order_by="$order_by"
    ignore>

    <x-slot:column>
        @if ($isMultiple)
            <x-core::table-select-column/>
        @endif
        @if ($table_lookup_columns)
            @foreach ($table_lookup_columns as $col)
                <x-core::table-column
                    :data="$col['data']"
                    :searchable="($col['searchable'] ?? false) === true"
                    :orderable="($col['orderable'] ?? true) === true">
                    {{ $col['label'] ?? $col['data'] }}
                </x-core::table-column>
            @endforeach
        @else
            <x-core::table-column :data="$table_lookup_column" searchable orderable>Name</x-core::table-column>
        @endif
    </x-slot>

</x-core::table-lookup>
@endif
