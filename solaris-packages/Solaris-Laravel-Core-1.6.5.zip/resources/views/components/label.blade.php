@props([
    "required"   => false,
    "horizontal" => false,
])

<label {{ 
    $attributes->class([
        "form-label"              => $horizontal === false,
        "col-sm-3 col-form-label" => $horizontal === true
    ])
}}>
    {{ $slot }}
    @if($required)
    <span class="text-danger">*</span>
    @endif
</label>