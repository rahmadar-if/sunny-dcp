@extends('core::layouts.master')
@section('layout-content')

@include('core::layouts.partials.switcher')

<div class="page">
    @include('core::layouts.partials.header')
    <x-core::sidebar :menus="SolarHelper::config('interface.menu_access') ?
        \Solaris\Core\Helpers\UserCache::menuTree(Auth::user()) : 
        \Solaris\Core\Services\MenuService::allTree()" />

    <!-- Start::app-content -->
    <div class="main-content app-content">
        <div class="container-fluid">

            <!-- Page Header -->
            <div class="d-flex align-items-center justify-content-between page-header-breadcrumb flex-wrap gap-2">
                <div>

                    @if (isset($breadcrumbs))
                        <x-core::breadcrumb :items="$breadcrumbs"/>
                    @else
                        @yield('breadcrumb')
                    @endif

                    @if (isset($title))
                        <h1 class="page-title fw-medium fs-18 mb-0">{{ $title }}</h1>
                    @else
                        @hasSection ('page-title')
                            <h1 class="page-title fw-medium fs-18 mb-0">@yield('page-title')</h1>
                        @endif
                        @hasSection ('page-subtitle')
                            <p class="fs-13 text-muted mb-0">@yield('page-subtitle')</p>
                        @endif
                    @endif

                    @if (isset($subtitle))
                        <p class="fs-13 text-muted mb-0">{{ $subtitle }}</p>
                    @endif
                    
                </div>
                <div class="d-flex btn-list">
                    @yield('top-buttons')
                </div>
            </div>
            <!-- Page Header Close -->

            <!-- Start::row-1 -->
            <div id="body-content" class="">
                @yield('content')
            </div>
            <!--End::row-1 -->

        </div>
    </div>
    <!-- End::app-content -->

    @include('core::layouts.partials.footer')
    @include('core::layouts.partials.responsive-search-modal')

</div>

<div class="scrollToTop">
    <span class="arrow"><i class="ti ti-arrow-narrow-up fs-20"></i></span>
</div>
<div id="responsive-overlay"></div>

@endsection

@prepend('scripts')
    @vite([SolarAsset::js('main.js')])
@endprepend