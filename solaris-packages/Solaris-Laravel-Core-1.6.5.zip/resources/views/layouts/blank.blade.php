@extends('core::layouts.master')
@section('layout-content')

@yield('content')

@endsection