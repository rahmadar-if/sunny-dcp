<!DOCTYPE html>
<html 
    lang="en" 
    dir="ltr" 
    data-nav-layout="vertical" 
    data-theme-mode="light" 
    data-header-styles="light" 
    data-menu-styles="light" 
    data-toggled="close">

    <head>
        <title>{{ SolarHelper::config('application.title') }} | @yield('title')</title>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <meta name="author" content="{{ SolarHelper::config('application.meta.author') }}" />
        <meta name='viewport' content="{{ SolarHelper::config('application.meta.viewport') }}">
        <meta name="description" content="{{ SolarHelper::config('application.meta.description') }}" />
        <meta name="keywords" content="{{ SolarHelper::config('application.meta.keywords') }}">

        <link rel="icon" href="{{ Vite::asset(SolarHelper::config('application.assets.icon')) }}" type="image/x-icon">

        <script>
            (function() {
                var html        = document.documentElement;
                var dark        = localStorage.getItem('zenodarktheme');
                var bodyBgRGB   = localStorage.getItem('bodyBgRGB');
                var lightRGB    = localStorage.getItem('bodylightRGB');
                var primaryRGB  = localStorage.getItem('primaryRGB');
                var zenoMenu    = localStorage.getItem('zenoMenu');
                var zenoHeader  = localStorage.getItem('zenoHeader');

                if (dark || bodyBgRGB) {
                    html.setAttribute('data-theme-mode', 'dark');
                    html.setAttribute('data-header-styles', 'dark');
                    html.setAttribute('data-menu-styles', 'dark');
                }

                if (bodyBgRGB && lightRGB) {
                    html.style.setProperty('--body-bg-rgb', bodyBgRGB);
                    html.style.setProperty('--body-bg-rgb2', lightRGB);
                    html.style.setProperty('--light-rgb', lightRGB);
                    html.style.setProperty('--form-control-bg', 'rgb(' + lightRGB + ')');
                    html.style.setProperty('--input-border', 'rgba(255,255,255,0.1)');
                    html.style.setProperty('--gray-3', 'rgba(255,255,255,0.1)');
                }

                if (primaryRGB) {
                    html.style.setProperty('--primary-rgb', primaryRGB);
                }

                if (zenoMenu) {
                    html.setAttribute('data-menu-styles', zenoMenu);
                }

                if (zenoHeader) {
                    html.setAttribute('data-header-styles', zenoHeader);
                }
            })();
        </script>

        @vite([
            'resources/css/app.scss', 
            'resources/js/app.js'
        ])

        @stack('styles')

        @php
            $user = Auth::user();
        @endphp

        <script>
            const BASE_URL              = {{ Js::from(url('/')) }};
            const MAX_FILE_SIZE         = {{ Js::from(SolarHelper::config('attachment.max_upload_file', 10)) }};
            const MAX_SIZE              = {{ Js::from(SolarHelper::config('attachment.max_size', 5 * 1024 * 1024 * 1024)) }};
            const USER_ID               = {{ Js::from($user?->id ?? null) }};
            const IS_PUSH_NOTIFICATION  = {{ Js::from($user?->is_push_notification ?? null) }};
        </script>
        @stack('head-scripts')
    </head>
    <body>
        @yield('layout-content')
        @stack('modal-content')
        @stack('offcanvas-content')
        
        @stack('pre-scripts')
        <script src="https://cdn.lordicon.com/lordicon.js"></script>
        @vite([SolarAsset::js('push-notification-check.js')])
        @stack('scripts')
    </body>
</html>