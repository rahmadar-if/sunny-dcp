@extends('core::emails.layout')

@section('content')
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0">

    {{-- Greeting --}}
    <tr>
        <td style="padding-bottom:12px;">
            <p class="dm-text-heading"
               style="margin:0;font-size:20px;font-weight:700;color:#111111;line-height:1.3;font-family:'Poppins',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;">
                Hi {{ $name }},
            </p>
        </td>
    </tr>
    <tr>
        <td style="padding-bottom:32px;">
            <p class="dm-text-body"
               style="margin:0;font-size:14px;color:#555555;line-height:1.75;font-family:'Poppins',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;">
                Use the code below to complete two-factor authentication.
                It expires in <strong class="dm-text-strong" style="color:#111111;font-weight:600;">5 minutes</strong> and can only be used once.
            </p>
        </td>
    </tr>

    {{-- OTP box — nested strip mirrors the outer layout strip --}}
    <tr>
        <td style="padding-bottom:32px;">
            <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0">
                <tr>
                    <td class="dm-otp-strip" width="4"
                        style="width:4px;min-width:4px;background-color:#FFB800;font-size:0;line-height:0;"
                        bgcolor="#FFB800">&nbsp;</td>
                    <td class="dm-otp-bg"
                        style="background-color:#FFFBF0;border:1px solid #FFD966;border-left:0;padding:24px 28px;">
                        <p class="dm-otp-label"
                           style="margin:0 0 10px 0;font-size:10px;font-weight:600;letter-spacing:2px;text-transform:uppercase;color:#AA8800;font-family:'Poppins',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;">
                            Verification Code
                        </p>
                        <p class="dm-otp-code"
                           style="margin:0 0 12px 0;font-size:38px;font-weight:800;letter-spacing:14px;color:#111111;font-family:'Courier New','Lucida Console',Courier,monospace;line-height:1;padding-left:14px;">
                            {{ $otp }}
                        </p>
                        <p class="dm-otp-expiry"
                           style="margin:0;font-size:12px;color:#AAAAAA;font-family:'Poppins',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;">
                            Expires at <strong class="dm-otp-expiry-strong" style="color:#666666;">{{ $expiry }}</strong>
                        </p>
                    </td>
                </tr>
            </table>
        </td>
    </tr>

    {{-- Security notice --}}
    <tr>
        <td>
            <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0">
                <tr>
                    <td class="dm-notice-bg"
                        style="background-color:#F6F6F6;border-left:3px solid #CCCCCC;padding:14px 18px;">
                        <p class="dm-notice-title"
                           style="margin:0 0 4px 0;font-size:12px;font-weight:700;color:#333333;font-family:'Poppins',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;">
                            Security Notice
                        </p>
                        <p class="dm-notice-body"
                           style="margin:0;font-size:12px;color:#777777;line-height:1.6;font-family:'Poppins',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;">
                            Never share this code with anyone. {{ $appName }} will never ask for your verification code.
                            If you did not request this, you can safely ignore this email.
                        </p>
                    </td>
                </tr>
            </table>
        </td>
    </tr>

</table>
@endsection
