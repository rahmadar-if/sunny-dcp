@extends('core::emails.layout')

@section('content')
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0">

    {{-- Title --}}
    <tr>
        <td style="padding-bottom:16px;">
            <p class="dm-text-heading"
               style="margin:0;font-size:20px;font-weight:700;color:#111111;line-height:1.3;font-family:'Poppins',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;">
                {{ $title }}
            </p>
        </td>
    </tr>

    {{-- Body lines --}}
    @foreach($lines as $line)
    <tr>
        <td style="padding-bottom:12px;">
            <p class="dm-text-body"
               style="margin:0;font-size:14px;color:#555555;line-height:1.75;font-family:'Poppins',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;">
                {{ $line }}
            </p>
        </td>
    </tr>
    @endforeach

    {{-- CTA button --}}
    @if(!empty($actionUrl))
    <tr>
        <td style="padding-top:20px;">
            <!--[if mso]>
            <v:roundrect xmlns:v="urn:schemas-microsoft-com:vml" xmlns:w="urn:schemas-microsoft-com:office:word"
                         href="{{ $actionUrl }}"
                         style="height:44px;v-text-anchor:middle;width:180px;"
                         arcsize="0%"
                         strokecolor="#111111"
                         fillcolor="#111111">
                <w:anchorlock/>
                <center style="color:#FFFFFF;font-family:Poppins,Arial,sans-serif;font-size:13px;font-weight:600;letter-spacing:0.4px;">
                    {{ $actionText ?? 'View Details' }}
                </center>
            </v:roundrect>
            <![endif]-->
            <!--[if !mso]><!-->
            <a href="{{ $actionUrl }}"
               class="dm-btn"
               style="display:inline-block;background-color:#111111;color:#FFFFFF;font-family:'Poppins',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;font-size:13px;font-weight:600;letter-spacing:0.4px;text-decoration:none;padding:12px 28px;line-height:1;">
                {{ $actionText ?? 'View Details' }}
            </a>
            <!--<![endif]-->
        </td>
    </tr>
    @endif

</table>
@endsection
