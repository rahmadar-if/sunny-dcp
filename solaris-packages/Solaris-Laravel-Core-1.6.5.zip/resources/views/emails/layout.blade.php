<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="x-apple-disable-message-reformatting">
    <meta name="color-scheme" content="light dark">
    <meta name="supported-color-schemes" content="light dark">
    <title>{{ $appName ?? config('app.name') }}</title>
    <!--[if mso]>
    <noscript>
        <xml>
            <o:OfficeDocumentSettings>
                <o:PixelsPerInch>96</o:PixelsPerInch>
            </o:OfficeDocumentSettings>
        </xml>
    </noscript>
    <![endif]-->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet" type="text/css">
    <style type="text/css">
        /* ── Resets ────────────────────────────────────────────────── */
        body, table, td, p, a, li { -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; }
        table, td { mso-table-lspace: 0pt; mso-table-rspace: 0pt; }
        img { -ms-interpolation-mode: bicubic; border: 0; display: block; outline: none; text-decoration: none; }

        body {
            margin: 0;
            padding: 0;
            background-color: #F2F2F2;
            font-family: 'Poppins', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif;
        }

        /* ── Responsive ─────────────────────────────────────────────── */
        @media screen and (max-width: 600px) {
            .email-wrapper   { width: 100% !important; }
            .strip-cell      { display: none !important; width: 0 !important; max-width: 0 !important; overflow: hidden !important; }
            .content-cell    { padding: 28px 24px !important; border-top: 4px solid #FFB800 !important; }
            .logo-img        { height: 24px !important; }
        }

        /* ── Dark Mode ───────────────────────────────────────────────── */
        @media (prefers-color-scheme: dark) {
            .dm-body         { background-color: #141414 !important; }
            .dm-outer        { background-color: #141414 !important; }
            .dm-card         { background-color: #222222 !important; }
            .dm-strip        { background-color: #FFB800 !important; }
            .dm-content      { background-color: #222222 !important; }
            .dm-divider      { border-top-color: #333333 !important; }
            .dm-footer-text  { color: #555555 !important; }

            /* text */
            .dm-text-heading  { color: #F0F0F0 !important; }
            .dm-text-body     { color: #999999 !important; }
            .dm-text-muted    { color: #555555 !important; }
            .dm-text-strong   { color: #CCCCCC !important; }

            /* CTA button — flip to yellow in dark */
            .dm-btn           { background-color: #FFB800 !important; color: #111111 !important; }

            /* OTP box */
            .dm-otp-strip     { background-color: #FFB800 !important; }
            .dm-otp-bg        { background-color: #1E1800 !important; border-color: #6B4E00 !important; }
            .dm-otp-label     { color: #AA8800 !important; }
            .dm-otp-code      { color: #F0F0F0 !important; }
            .dm-otp-expiry    { color: #555555 !important; }
            .dm-otp-expiry-strong { color: #888888 !important; }

            /* Security notice */
            .dm-notice-bg     { background-color: #282828 !important; border-left-color: #444444 !important; }
            .dm-notice-title  { color: #CCCCCC !important; }
            .dm-notice-body   { color: #888888 !important; }
        }

        /* Outlook.com dark mode */
        [data-ogsc] .dm-body        { background-color: #141414 !important; }
        [data-ogsc] .dm-outer       { background-color: #141414 !important; }
        [data-ogsc] .dm-card        { background-color: #222222 !important; }
        [data-ogsc] .dm-strip       { background-color: #FFB800 !important; }
        [data-ogsc] .dm-content     { background-color: #222222 !important; }
        [data-ogsc] .dm-divider     { border-top-color: #333333 !important; }
        [data-ogsc] .dm-footer-text { color: #555555 !important; }

        [data-ogsc] .dm-text-heading  { color: #F0F0F0 !important; }
        [data-ogsc] .dm-text-body     { color: #999999 !important; }
        [data-ogsc] .dm-text-muted    { color: #555555 !important; }
        [data-ogsc] .dm-text-strong   { color: #CCCCCC !important; }

        [data-ogsc] .dm-btn           { background-color: #FFB800 !important; color: #111111 !important; }

        [data-ogsc] .dm-otp-strip     { background-color: #FFB800 !important; }
        [data-ogsc] .dm-otp-bg        { background-color: #1E1800 !important; border-color: #6B4E00 !important; }
        [data-ogsc] .dm-otp-label     { color: #AA8800 !important; }
        [data-ogsc] .dm-otp-code      { color: #F0F0F0 !important; }
        [data-ogsc] .dm-otp-expiry    { color: #555555 !important; }
        [data-ogsc] .dm-otp-expiry-strong { color: #888888 !important; }

        [data-ogsc] .dm-notice-bg     { background-color: #282828 !important; border-left-color: #444444 !important; }
        [data-ogsc] .dm-notice-title  { color: #CCCCCC !important; }
        [data-ogsc] .dm-notice-body   { color: #888888 !important; }
    </style>
</head>
<body class="dm-body" style="margin:0;padding:0;background-color:#F2F2F2;">

    <!--[if mso]><table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0"><tr><td><![endif]-->

    <table role="presentation" class="dm-outer" width="100%" cellspacing="0" cellpadding="0" border="0"
           style="background-color:#F2F2F2;">
        <tr>
            <td align="center" style="padding:48px 16px;">

                <!-- Email card -->
                <table role="presentation" class="email-wrapper dm-card" width="600" cellspacing="0" cellpadding="0" border="0"
                       style="max-width:600px;width:100%;background-color:#FFFFFF;">
                    <tr>

                        <!-- Yellow left strip -->
                        <td class="strip-cell dm-strip" width="4"
                            style="width:4px;min-width:4px;max-width:4px;background-color:#FFB800;font-size:0;line-height:0;"
                            bgcolor="#FFB800">&nbsp;</td>

                        <!-- Content column -->
                        <td class="content-cell dm-content"
                            style="padding:44px 48px;vertical-align:top;background-color:#FFFFFF;font-family:'Poppins',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;">

                            <!-- Logo -->
                            <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0">
                                <tr>
                                    <td style="padding-bottom:32px;">
                                        <img class="logo-img"
                                             src="{{ $logoUrl ?? '' }}"
                                             alt="{{ $appName ?? config('app.name') }}"
                                             height="28"
                                             style="display:block;height:28px;width:auto;max-height:28px;">
                                    </td>
                                </tr>
                                <tr>
                                    <td class="dm-divider"
                                        style="border-top:1px solid #E8E8E8;font-size:0;line-height:0;padding-bottom:36px;">&nbsp;</td>
                                </tr>
                            </table>

                            <!-- Content slot -->
                            @yield('content')

                            <!-- Footer -->
                            <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0"
                                   style="margin-top:44px;">
                                <tr>
                                    <td class="dm-divider"
                                        style="border-top:1px solid #E8E8E8;font-size:0;line-height:0;padding-bottom:24px;">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="dm-footer-text"
                                        style="font-size:11px;color:#AAAAAA;line-height:1.7;font-family:'Poppins',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;">
                                        &copy; {{ date('Y') }} {{ $appName ?? config('app.name') }}. All rights reserved.<br>
                                        This is an automated message — please do not reply to this email.
                                    </td>
                                </tr>
                            </table>

                        </td>
                    </tr>
                </table>

            </td>
        </tr>
    </table>

    <!--[if mso]></td></tr></table><![endif]-->

</body>
</html>
