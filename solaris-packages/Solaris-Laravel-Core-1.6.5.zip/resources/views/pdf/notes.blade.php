<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body {
            font-family: Poppins, DejaVu Sans, sans-serif;
            font-size: 13px;
            line-height: 1.42;
            color: #333;
            margin: 0;
            padding: 0;
        }
        .ql-editor {
            padding: 0;
        }
        p, h1, h2, h3, h4, h5, h6, ol, ul, pre, blockquote {
            margin: 0;
            padding: 0;
        }
        h1 { font-size: 2em; }
        h2 { font-size: 1.5em; }
        h3 { font-size: 1.17em; }
        h4 { font-size: 1em; }
        h5 { font-size: 0.83em; }
        h6 { font-size: 0.75em; }
        strong, b { font-weight: bold; }
        em, i     { font-style: italic; }
        u         { text-decoration: underline; }
        s         { text-decoration: line-through; }
        sup { vertical-align: super; font-size: 0.8em; }
        sub { vertical-align: sub;   font-size: 0.8em; }
        blockquote {
            border-left: 4px solid #ccc;
            padding: 0.5em 1em;
            color: #666;
        }
        pre {
            background: #f4f4f4;
            padding: 0.75em 1em;
            font-family: DejaVu Sans Mono, monospace;
            font-size: 12px;
            white-space: pre-wrap;
            word-break: break-all;
        }
        ol, ul { padding-left: 1.5em; }
        li { margin: 0; padding: 0; }
        img { max-width: 100%; height: auto; }
        .ql-ui { display: none; }
        .ql-align-center  { text-align: center; }
        .ql-align-right   { text-align: right; }
        .ql-align-justify { text-align: justify; }
        .ql-indent-1 { padding-left: 3em; }
        .ql-indent-2 { padding-left: 6em; }
        .ql-indent-3 { padding-left: 9em; }
        .ql-indent-4 { padding-left: 12em; }
        .ql-size-small { font-size: 0.75em; }
        .ql-size-large { font-size: 1.5em; }
        .ql-size-huge  { font-size: 2.5em; }
    </style>
</head>
<body>
    <div class="ql-editor">{!! $content !!}</div>
</body>
</html>
