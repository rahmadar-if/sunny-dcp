<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        @page {
            size: A4 portrait;
            margin: 20mm 25.4mm;
        }

        body {
            font-family: Poppins, 'DejaVu Sans', sans-serif;
            font-size: 10.5pt;
            line-height: 1.6;
            color: #000;
            margin: 0;
            padding: 0;
        }

        h1 { font-size: 20pt; font-weight: bold; margin: 0.4em 0 0.2em; }
        h2 { font-size: 16pt; font-weight: bold; margin: 0.4em 0 0.2em; }
        h3 { font-size: 13pt; font-weight: bold; margin: 0.4em 0 0.2em; }
        h4 { font-size: 11pt; font-weight: bold; margin: 0.4em 0 0.2em; }
        h5 { font-size: 10.5pt; font-weight: bold; margin: 0.4em 0 0.2em; }
        h6 { font-size: 10pt; font-weight: bold; margin: 0.4em 0 0.2em; }

        p { margin: 0 0 0.6em; }

        strong, b { font-weight: bold; }
        em, i     { font-style: italic; }
        u         { text-decoration: underline; }
        s         { text-decoration: line-through; }
        sup { vertical-align: super; font-size: 0.8em; }
        sub { vertical-align: sub;   font-size: 0.8em; }

        a { color: #0563c1; }

        blockquote {
            border-left: 4px solid #ccc;
            margin: 0.8em 0;
            padding: 0.4em 1em;
            color: #555;
        }

        pre, code {
            background: #f4f4f4;
            font-family: 'DejaVu Sans Mono', monospace;
            font-size: 9pt;
        }
        pre {
            padding: 0.6em 0.8em;
            white-space: pre-wrap;
            word-break: break-all;
        }
        code { padding: 0.1em 0.3em; }

        ol, ul { padding-left: 1.5em; margin: 0.3em 0; }
        li { margin: 0.1em 0; }
        .todo-list { list-style: none; padding-left: 0.5em; }
        .todo-list li::before { content: "[ ] "; }
        .todo-list li.todo-list__item--checked::before { content: "[x] "; }

        hr { border: none; border-top: 1px solid #ccc; margin: 0.8em 0; }

        /* Images */
        img { max-width: 100%; height: auto; }

        figure.image {
            display: block;
            margin-left: auto;
            margin-right: auto;
            margin-top: 0.8em;
            margin-bottom: 0.8em;
            text-align: center;
        }
        figure.image img {
            display: block;
            margin: 0 auto;
            max-width: 100%;
            height: auto;
        }
        figure.image.image-style-align-left,
        figure.image.image-style-block-align-left {
            float: left;
            margin-left: 0;
            margin-right: 1em;
        }
        figure.image.image-style-align-right,
        figure.image.image-style-block-align-right,
        figure.image.image-style-side {
            float: right;
            margin-right: 0;
            margin-left: 1em;
        }
        figcaption {
            font-size: 0.85em;
            color: #666;
            margin-top: 0.2em;
            text-align: center;
        }

        /* Tables */
        table {
            border-collapse: collapse;
            margin: 0.8em 0;
        }
        td, th {
            padding: 0.3em 0.5em;
            vertical-align: top;
            word-break: break-word;
        }
        th { font-weight: bold; background: #f0f0f0; }

        mark { background: #ff0; color: #000; }

        .page-break { page-break-after: always; }
    </style>
</head>
<body>
    <div>{!! $content !!}</div>
</body>
</html>
