@php
	$v2BgImage  = SolarHelper::config('auth.presets.v2.background_image');
	$v2BgColor  = SolarHelper::config('auth.presets.v2.background_color');
	$brandStyle = '';
	if ($v2BgImage) {
		$brandStyle = "--auth-v2-brand-image: url('" . Vite::asset($v2BgImage) . "');";
	} elseif ($v2BgColor) {
		$brandStyle = "--auth-v2-brand-color: {$v2BgColor};";
	}

	$tagline   = SolarHelper::config('auth.presets.v2.tagline') ?? 'The future of customer relationships';
	$highlight = SolarHelper::config('auth.presets.v2.tagline_highlight') ?? 'rises.';
	$subtitle  = SolarHelper::config('auth.presets.v2.subtitle') ?? 'Simple, straightforward — CRM is easy as 1-2-3';
@endphp

<div class="auth-v2">
	<div class="auth-v2__brand{{ $v2BgImage ? ' has-bg-image' : '' }}" @if($brandStyle) style="{{ $brandStyle }}" @endif>
		<div class="auth-v2__brand-content">
			<img src="{{ Vite::asset(SolarHelper::config('application.assets.logo.auth.white')) }}" alt="logo" class="auth-v2__brand-logo auth-v2__brand-logo--light" width="180" height="48">
			<img src="{{ Vite::asset(SolarHelper::config('application.assets.logo.auth.dark')) }}" alt="logo" class="auth-v2__brand-logo auth-v2__brand-logo--dark" width="180" height="48">
			<h1 class="auth-v2__tagline">{{ $tagline }} <span>{{ $highlight }}</span></h1>
			<p class="auth-v2__subtitle">{{ $subtitle }}</p>
		</div>
		<div class="auth-v2__brand-decor">
			<div class="auth-v2__orb auth-v2__orb--1"></div>
			<div class="auth-v2__orb auth-v2__orb--2"></div>
			<div class="auth-v2__orb auth-v2__orb--3"></div>
		</div>
	</div>

	<div class="auth-v2__form">
		<div class="auth-v2__form-inner">
			<span class="mb-4 d-flex justify-content-center d-lg-none">
				<img src="{{ Vite::asset(SolarHelper::config('application.assets.logo.auth.white')) }}" alt="logo" class="auth-logo--light" width="220" height="58">
				<img src="{{ Vite::asset(SolarHelper::config('application.assets.logo.auth.dark')) }}" alt="logo" class="auth-logo--dark" width="220" height="58">
			</span>

			{{ $slot }}

			@session('message')
				<div class="alert alert-solid-danger alert-dismissible fade show w-100 mt-3"> 
					{{ session('message') }}
					<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"><i class="bi bi-x"></i></button> 
				</div>
			@endsession
		</div>
	</div>
</div>
