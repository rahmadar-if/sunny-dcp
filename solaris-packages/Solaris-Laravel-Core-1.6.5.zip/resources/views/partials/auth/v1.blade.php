@php
	$v1BgImage = SolarHelper::config('auth.presets.v1.background_image');
	$v1BgColor = SolarHelper::config('auth.presets.v1.background_color');
	$v1Style = '';
	if ($v1BgImage) {
		$v1Style = "--auth-v1-bg-image: url('" . Vite::asset($v1BgImage) . "');";
	} elseif ($v1BgColor) {
		$v1Style = "--auth-v1-bg-color: {$v1BgColor};";
	}
@endphp

<div class="auth-v1" @if($v1Style) style="{{ $v1Style }}" @endif>
	<div class="auth-v1__card">
		<span class="mb-4 d-flex justify-content-center">
			<img src="{{ Vite::asset(SolarHelper::config('application.assets.logo.auth.dark')) }}" alt="logo" width="220" height="58">
		</span>

		{{ $slot }}

		@session('message')
			<div class="alert alert-solid-danger alert-dismissible fade show w-100 mt-3"> 
				{{ session('message') }}
				<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"><i class="bi bi-x"></i></button> 
			</div>
		@endsession
	</div>

	<div class="auth-v1__footer">
		<span>Powered by <strong>Solaris</strong></span>
	</div>
</div>
