<div class="container-fluid d-flex align-items-center background-image" style="--login-bg: url('{{ Vite::asset(SolarHelper::config('auth.presets.default.background_image')) }}')">
	<div class="row m-0 flex-grow-1 w-100 h-100">
		<div class="col-lg-5 col-12 d-flex flex-column justify-content-center align-items-center bg-white">
			<div class="mx-auto width-form">
				<span class="mb-4 d-flex justify-content-center">
					<img src="{{ Vite::asset(SolarHelper::config('application.assets.logo.auth.white')) }}" alt="logo" class="auth-logo--light" width="256" height="68">
					<img src="{{ Vite::asset(SolarHelper::config('application.assets.logo.auth.dark')) }}" alt="logo" class="auth-logo--dark" width="256" height="68">
				</span>

				{{ $slot }}

			</div>

			@session('message')
				<div class="alert alert-solid-danger alert-dismissible fade show w-100 mt-3"> 
					{{ session('message') }}
					<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"><i class="bi bi-x"></i></button> 
				</div>
			@endsession
		</div>
	</div>
</div>
