import Cropper from 'cropperjs'
import 'cropperjs/dist/cropper.css'
import Compressor from 'compressorjs'
import Helper from './helper'
import PhotoSwipeLightbox from "photoswipe/lightbox"
import PhotoSwipe from "photoswipe"
import "photoswipe/style.css"
import Modal from './modal'
import DropzoneUpload from './dropzone'
import SolarComponent from './solar/solar-component'

export default class ProfilePicture extends SolarComponent {
	_element = null
	_id = null
	_img = null
	_input = null
	_max = null
	_uploadTo = null
	_paramName = null
	_thumbnail = null
	_preview = null
	_modalCrop = null
	_cropper = null
	_cropPreview = null
	_lightbox = null
	_croppedBlob = null
	_croppedName = null
	_croppedHeight = null
	_croppedWidth = null
	_modalSize = 'modal-lg'
	_viewOnly = false

	static supportedEvent() {
		return ['change', 'success', 'cropped']
	}

	constructor(selector) {
		super()

		if (selector instanceof Element) {
			this._element = selector
		} else if (Helper.isString(selector) && !Helper.isEmpty(selector)) {
			this._element = document.querySelector(selector)
			if (!this._element) {
				throw new Error(`Element with query selector ${selector} is not found`)
			}
		} else {
			throw new Error(`Selector is not supported`)
		}

		this._id = this._element.id
		this._img = this._element.querySelector("img")
		this._input = this._element.querySelector(`input[type="file"]`)
		this._viewOnly = !this._input

		if (!this._viewOnly) {
			this._max = parseInt(this._input.getAttribute("max") ?? 5)
			this._uploadTo  = this._input.getAttribute("upload-to")
			this._paramName = this._input.getAttribute("param-name")
			this._thumbnail = parseInt(this._input.getAttribute("thumbnail") ?? 120)
		}

		this._preview = this._element.querySelector("a")
		if (this._preview) {
			this._lightbox = new PhotoSwipeLightbox({
				gallery: `#${this._id} a`,
				pswpModule: PhotoSwipe
			})
			this._lightbox.init()
		}

		if (!this._viewOnly) {
			this._createCropper()
			this.on('change', (image) => {
				this._croppedBlob = null
				this._croppedName = null
				this._croppedHeight = null
				this._croppedWidth = null

				if (!image) {
					return
				}

				const validation = this.validation(image)
				if (!validation.success) {
					this._input.value = null
					Helper.errorAlert({ title: "Oops! There was an error", message: validation.message })
					return
				}

				this.openCropper()
			}, "ProfilePicture")
		}
	}

	on(type, callback, name = null) {
		let oldChangeHandler = null
		if (type === 'change' && name && this._events.has(type)) {
			const existing = this._events.get(type).find(e => e.name === name)
			if (existing) oldChangeHandler = existing.changeHandler
		}

		super.on(type, callback, name)

		if (type !== 'change') {
			return this
		}

		const events = this._events.get(type)
		const event  = name ? events.find(e => e.name === name) : events[events.length - 1]

		if (oldChangeHandler) {
			this._input.removeEventListener('change', oldChangeHandler)
		}

		const changeHandler = () => callback(this.getRawFile())
		event.changeHandler = changeHandler
		if (this._input) {
			this._input.addEventListener('change', changeHandler)
		}

		return this
	}

	off(type, callback = null, name = null) {
		if (!this._events.has(type)) {
			return this
		}

		if (type === 'change') {
			const events = this._events.get(type)
			let toRemove

			if (name) {
				toRemove = events.filter(e => e.name === name)
			} else if (callback) {
				toRemove = events.filter(e => e.callback === callback)
			} else {
				toRemove = [...events]
			}

			toRemove.forEach(event => {
				if (this._input && event.changeHandler) {
					this._input.removeEventListener('change', event.changeHandler)
				}
			})
		}

		return super.off(type, callback, name)
	}

	/**
	 * @returns {boolean}
	 */
	hasPendingCrop() {
		return this._croppedBlob !== null
	}

	getRawFile() {
		if (!this._input) {
			return null
		}
		const files = this._input.files
		return files.length > 0 ? files[0] : null
	}

	getImageCrop() {
		return this._cropper?.getCroppedCanvas() ?? null
	}

	openCropper() {
		this._modalCrop.show()
	}

	closeCropper() {
		this._modalCrop.hide()
	}

	/**
	 * @param {string|null} [url=null]
	 * @param {boolean} [skipLoading=false] - Skip loadingPage calls when Form already manages loading state.
	 * @returns {Promise<boolean>}
	 */
	async upload(url = null, skipLoading = false) {
		return await this._runUpload(url ?? this._uploadTo, skipLoading)
	}

	/**
	 * @param {string} url
	 * @param {boolean} skipLoading
	 * @returns {Promise<boolean>}
	 */
	async _runUpload(url, skipLoading) {
		if (Helper.isEmpty(url)) {
			return false
		}

		let imgCrop, newImgName, height, width

		if (this._cropper) {
			const rawFile = this.getRawFile()
			const imgName = rawFile.name
			const imgSize = rawFile.size

			let canvas = this.getImageCrop()
			height = canvas.height
			width  = canvas.width

			imgCrop = await new Promise((resolve) => {
				canvas.toBlob((blob) => resolve(blob), 'image/webp')
			})

			const MAX_COMPRESS_ATTEMPTS = 5
			const MIN_QUALITY = 0.3

			let quality  = 0.8
			let attempts = 0
			let cropSize = imgCrop.size

			while (cropSize >= imgSize && attempts < MAX_COMPRESS_ATTEMPTS && quality >= MIN_QUALITY) {
				imgCrop  = await this.compress(imgCrop, quality)
				cropSize = imgCrop.size
				quality  = Math.max(quality - 0.1, MIN_QUALITY)
				attempts++
			}

			const imgExt = imgName.substring(imgName.lastIndexOf(".") + 1)
			newImgName = `${imgName.substring(0, imgName.length - imgExt.length)}.webp`
		} else if (this._croppedBlob) {
			imgCrop = this._croppedBlob
			newImgName = this._croppedName
			height = this._croppedHeight
			width = this._croppedWidth
		} else {
			return false
		}

		if (!skipLoading) {
			Helper.loadingPage(true)
		}

		try {
			const res = await this._uploadWithDropzone(imgCrop, newImgName, url)

			const imgBase64 = URL.createObjectURL(imgCrop)
			this._img.src = imgBase64
			if (!this._preview) {
				this._createImgPreview(imgBase64, height, width)
			} else {
				this._preview.href = imgBase64
				this._preview.setAttribute('data-pswp-height', height)
				this._preview.setAttribute('data-pswp-width', width)
			}

			this._croppedBlob = null
			this._croppedName = null
			this._croppedHeight = null
			this._croppedWidth = null

			this.trigger('success', { upload: res, base64: imgBase64 })
			this.closeCropper()

			return true
		} catch (error) {
			console.error({error})
			Helper.errorAlert({ title: "Oops! There was an error", message: error, timeout: null })

			return false
		} finally {
			if (!skipLoading) {
				Helper.loadingPage(false)
			}
		}
	}

	async crop() {
		Helper.loadingPage(true)
		try {
			const rawFile = this.getRawFile()
			const imgName = rawFile.name
			const imgSize = rawFile.size

			let imgCrop = this.getImageCrop()
			const height = imgCrop.height
			const width = imgCrop.width

			imgCrop = await new Promise((resolve) => {
				imgCrop.toBlob((blob) => {
					resolve(blob)
				}, 'image/webp')
			})

			const MAX_COMPRESS_ATTEMPTS = 5
			const MIN_QUALITY = 0.3
			let quality = 0.8
			let attempts = 0
			let cropSize = imgCrop.size
			while (cropSize >= imgSize && attempts < MAX_COMPRESS_ATTEMPTS && quality >= MIN_QUALITY) {
				imgCrop = await this.compress(imgCrop, quality)
				cropSize = imgCrop.size
				quality = Math.max(quality - 0.1, MIN_QUALITY)
				attempts++
			}

			const imgBase64 = URL.createObjectURL(imgCrop)
			this._img.src = imgBase64
			if (!this._preview) {
				this._createImgPreview(imgBase64, height, width)
			} else {
				this._preview.href = imgBase64
				this._preview.setAttribute('data-pswp-height', height)
				this._preview.setAttribute('data-pswp-width', width)
			}

			const imgExt = imgName.substring(imgName.lastIndexOf(".") + 1)
			const newImgName = `${imgName.substring(0, imgName.length - imgExt.length)}.webp`

			this._croppedBlob = imgCrop
			this._croppedName = newImgName
			this._croppedHeight = height
			this._croppedWidth = width

			this.trigger('cropped', {
				blob: imgCrop,
				base64: imgBase64,
				name: newImgName,
				height: height,
				width: width
			})
			this.closeCropper()
		} catch (error) {
			Helper.errorAlert({ title: "Oops! There was an error", message: error, timeout: null })
		} finally {
			Helper.loadingPage(false)
		}
	}

	async compress(file, quality = 0.8) {
		return await new Promise((resolve) => {
			new Compressor(file, {
				quality,
				success: (result) => resolve(result),
			})
		})
	}

	validation(image) {
		let message = 'File is not valid.'
		let isValid = true

		if (!Helper.isFileSizeValid(image, this._max)) {
			isValid = false
			message += ` Maximum size is ${this._max} MB.`
		}

		if (!Helper.isFileMimeValid(image, 'image')) {
			isValid = false
			message += ' File must be image file.'
		}

		return {
			success: isValid,
			message: message
		}
	}

	refreshPreview(id, height, width) {
		this._img.src = `${BASE_URL}/core/images/thumbnail/${id}`
		if (this._preview) {
			this._preview.href = `${BASE_URL}/core/images/${id}`
			this._preview.setAttribute('data-pswp-height', height)
			this._preview.setAttribute('data-pswp-width', width)
		}
	}

	emptyPreview() {
		const imgDummy = new URL("../../assets/images/user-dummy-img.jpg", import.meta.url)
		this._img.src = imgDummy
		if (this._preview) {
			const parent = this._preview.parentNode
			while (this._preview.firstChild) {
				parent.insertBefore(this._preview.firstChild, this._preview)
			}

			this._preview.remove()
			this._preview = null
		}
	}

	_createImgPreview(source, height, width) {
		this._preview = document.createElement("a")
		this._preview.href = source
		this._preview.setAttribute('data-pswp-height', height)
		this._preview.setAttribute('data-pswp-width', width)
		this._preview.setAttribute('target', '_blank')

		this._img.parentNode.insertBefore(this._preview, this._img)
		this._preview.appendChild(this._img)

		this._lightbox?.destroy()
		const lightbox = new PhotoSwipeLightbox({
			gallery: `#${this._id} a`,
			pswpModule: PhotoSwipe
		})
		lightbox.init()
		this._lightbox = lightbox
	}

	_cropperOptions() {
		return {
			aspectRatio: 1,
			viewMode: 2,
			movable: false,
		}
	}

	_createCropper() {
		const modalId = `${this._id}_modalCropper`
		const modalEl = document.createElement("div")
		modalEl.className = 'modal fade'
		modalEl.id = modalId
		modalEl.setAttribute('tabindex', '-1')
		modalEl.setAttribute('aria-hidden', 'true')
		modalEl.setAttribute('data-bs-backdrop', 'static')
		modalEl.setAttribute('data-bs-keyboard', 'false')

		modalEl.innerHTML = `<div class="modal-dialog ${this._modalSize} modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="cropper-img-container">
                        <img id="${this._id}_imgPreview">
                    </div>
                </div>
                <div class="modal-footer">
                    <button id="${this._id}_submit" type="button" class="btn btn-primary">${!Helper.isEmpty(this._uploadTo) ? "Upload" : "Crop"}</button>
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                </div>
            </div>
        </div>`

		document.body.appendChild(modalEl)

		this._modalCrop = new Modal(modalEl)
		this._cropPreview = document.querySelector(`#${this._id}_imgPreview`)

		this._modalCrop.on('show', () => {
			this._cropPreview.classList.add('d-none')
		}, "ProfilePicture")

		this._modalCrop.on('shown', () => {
			const reader = new FileReader()
			reader.onload = (e) => {
				this._cropPreview.src = e.target.result
				this._cropper = new Cropper(this._cropPreview, {
					...this._cropperOptions(),
					ready: () => {
						this._cropPreview.classList.remove('d-none')
					}
				})
			}
			reader.readAsDataURL(this.getRawFile())
		}, "ProfilePicture")

		this._modalCrop.on('hidden', () => {
			this._input.value = null
			this._cropper?.destroy()
			this._cropper = null
		}, "ProfilePicture")

		document.querySelector(`#${this._id}_submit`).addEventListener('click', (e) => {
			if (!Helper.isEmpty(this._uploadTo)) {
				this.upload()
			} else {
				this.crop()
			}
		})
	}

	/**
	 * @param {Blob} blob
	 * @param {string} filename
	 * @param {string} url
	 * @returns {Promise<Object>}
	 */
	async _uploadWithDropzone(blob, filename, url) {
		return new Promise((resolve, reject) => {
			const dz = DropzoneUpload.createHidden({
				url,
				paramName: this._paramName,
				thumbnailSize: this._thumbnail,
			})

			dz.on('success', (file, res) => {
				dz.destroy()
				if (!res.success) {
					reject(res.message)
					return
				}
				resolve(res)
			})

			dz.on('error', (file, message) => {
				dz.destroy()
				reject(message)
			})

			dz.addFile(new File([blob], filename, { type: 'image/webp' }))
		})
	}
}
