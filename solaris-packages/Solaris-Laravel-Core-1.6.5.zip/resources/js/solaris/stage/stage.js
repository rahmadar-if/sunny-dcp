import Helper from "../helper"
import SolarComponent from "../solar/solar-component"

export default class Stage extends SolarComponent {
    constructor(selector) {
        super()

        this._active         = false
        this._selected       = false
        this._confirm        = false
        this._disabled       = false
        this._confirmMessage = "Are you sure ?"
        this._nextManual     = false

        if(selector instanceof Element || (Helper.isString(selector) && !Helper.isEmpty(selector))) {
            if(selector instanceof Element) {
                this._element = selector
            } else if(Helper.isString(selector) && !Helper.isEmpty(selector)) {
                this._element = document.querySelector(selector)
                if(!this._element) {
                    throw new Error(`Element with query selector ${selector} is not found`)
                }
            } else {
                throw new Error(`Selector is not supported`)
            }

            this._stageFromElement()
        } else {
            this._stageFromObject(selector)
        }

        this._init()
    }

    static supportedEvent() {
        return ["onhover", "outhover", "click"]
    }

    /**
     * _stageFromElement create stage from HTMLElement
     * @param {HTMLElement} stage
     */
    _stageFromElement() {
        if(!this._element.classList.contains('stage-button')) {
            throw new Error("Stage must be contains class stage-button")
        }

        this._button = this._element.querySelector('button.btn')
        this._text   = this._button.querySelector('span.stage-text')
        const color = [...this._element.classList].find(cls => cls.includes("stage-color-"))?.replace("stage-color-", "") ?? "primary"
        if(!this._isValidColor(color)) {
            throw new Error(`Color ${color} is not supported, use "primary, secondary, info, success, warning, danger"`)
        }

        this.id              = this._element.dataset.id
        this.name            = this._text.textContent
        this._color          = color
        this._currentColor   = color
        this._active         = false
        this._selected       = false
        this._disabled       = this._element.dataset.disabled == "true" ? true : false
        this._confirm        = this._element.dataset.confirm == "true" ? true : false
        this._confirmMessage = this._element.dataset.confirmMessage ?? this._confirmMessage

        const nextAttr       = this._element.dataset.next
        this._next           = nextAttr && nextAttr !== 'null' ? JSON.parse(nextAttr) : null
        this._staticDisabled = this._disabled
    }

    /**
     * _stageFromObject create stage from object
     * @param {{
     *  id: string,
     *  name: string,
     *  color: string,
     *  confirm: boolean,
     *  disabled: boolean
     * }} stage
     */
    _stageFromObject(stage) {
        if(!Helper.isObject(stage)) {
            throw new Error("Stage must be object")
        }

        if(!["id", "name", "color"].every(prop => stage.hasOwnProperty(prop))) {
            throw new Error("Stage must have id, name, color, and element property")
        }

        if(!this._isValidColor(stage.color)) {
            throw new Error(`Color ${stage.color} is not supported, use "primary, secondary, info, success, warning, danger"`)
        }

        this.id              = stage.id
        this.name            = stage.name
        this._color          = stage.color
        this._currentColor   = stage.color
        this._active         = false
        this._selected       = false
        this._action         = null
        this._confirm        = stage.confirm ?? false
        this._disabled       = stage.disabled ?? false
        this._confirmMessage = stage.confirmMessage ?? this._confirmMessage
        this._next           = stage.next ?? null
        this._staticDisabled = this._disabled

        this._createElement()
    }

    _isValidColor(color) {
        return ["primary", "secondary", "info", "success", "warning", "danger"].includes(color)
    }

    _createElement() {
        const container     = document.createElement('div')
        container.className = `stage-button stage-color-${this._color}`
        container.setAttribute('data-id', this.id)

        const button = document.createElement('button')
        button.className = 'btn'
        button.setAttribute('type', 'button')
        button.setAttribute('data-confirm', this._confirm)

        const text       = document.createElement('span')
        text.className   = 'stage-text'
        text.textContent = this.name

        button.appendChild(text)
        container.appendChild(button)

        this.element = {
            stage : container,
            button: button,
            text  : text
        }
    }

    _init() {
        this._initOnHover()
        this._initOutHover()
        this._initOnClick()

        if(this._disabled) {
            this.disabled()
        }

        setTimeout(() => {
            if(this._text.scrollWidth > this._text.clientWidth) {
                this._button.setAttribute("title", this._text.textContent)
            }
        }, 100)
    }

    _initOnHover() {
        this._element.addEventListener("mouseenter", () => {
            if(this.isDisabled()) {
                return
            }

            this.onHover()
            this.trigger('onhover')
        })
    }

    _initOutHover() {
        this._element.addEventListener("mouseleave", () => {
            if(this.isDisabled()) {
                return
            }

            this.outHover()
            this.trigger('outhover')
        })
    }

    _initOnClick() {
        this._button.addEventListener("click", async () => {
            if(this.isDisabled()) {
                return
            }

            if(this._confirm) {
                if(!await Helper.confirm({title: this._confirmMessage})) {
                    return
                }
            }

            const trigger         = await this.trigger('click')
            const isTriggerExists = trigger && Array.isArray(trigger)
            const isTriggerValid  = isTriggerExists && 
                trigger.every(res => {
                    const isBool  = typeof res === 'boolean' && res === true
                    const isEmpty = res === undefined || res === null

                    return isBool || isEmpty
                })
            
            if(isTriggerExists && isTriggerValid) {
                this.onSelected(true)
            }
        })
    }

    getColor() {
        return this._color
    }

    setColor(color) {
        this._element.classList.remove(`stage-color-${this._currentColor}`)
        this._element.classList.add(`stage-color-${color}`)
        this._currentColor = color
    }

    onHover() {
        if(!this._selected) {
            this._element.classList.add("stage-hover")
        }
    }

    outHover() {
        this._element.classList.remove("stage-hover")
        if(!this._selected) {
            this._element.classList.remove(`stage-color-${this._currentColor}`)
            this._element.classList.add(`stage-color-${this._color}`)
            this._currentColor = this._color
        }
    }

    isSelected() {
        return this._selected
    }

    onSelected(active = false) {
        this._element.classList.add("stage-selected")
        this._selected = true
        this._active   = active
        if(active) {
            this._element.classList.add("stage-active")
            this.setColor(this._color)
        }
    }

    unSelected() {
        this._element.classList.remove("stage-active", "stage-selected")
        this._active   = false
        this._selected = false
    }

    disabled() {
        this._disabled = true
        this._element.classList.add("stage-disabled")
    }

    enabled() {
        this._disabled = false
        this._element.classList.remove("stage-disabled")
    }

    isDisabled() {
        return this._disabled
    }

    isActive() {
        return this._active
    }
}