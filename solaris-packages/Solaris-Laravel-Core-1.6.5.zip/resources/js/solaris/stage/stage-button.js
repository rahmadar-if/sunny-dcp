import Helper from "../helper"
import axios from "../../libs/axios"
import Stage from "./stage"
import DropdownStage from "./dropdown-stage"
import SolarComponent from "../solar/solar-component"

export default class StageButtons extends SolarComponent {
    #stages = []
    #source = null

    /**
     * constructor
     * @param {string|HTMLElement} element
     * @param {string|Array} source
     */
    constructor(selector, source = null) {
        super()

        if(selector instanceof Element) {
            this._element = selector
        } else if(Helper.isString(selector) && !Helper.isEmpty(selector)) {
            this._element = document.querySelector(selector)
            if(!this._element) {
                throw new Error(`Element with query selector ${selector} is not found`)
            }
        } else {
            throw new Error(`Selector is not supported`)
        }

        this._id     = this._element.id
        this._bindTo = this._element.getAttribute("solar-bind")
        if(Helper.isEmpty(this._bindTo)) {
            this._bindTo = this._id
        }
        this.#source = source
        if(!Helper.isString(source)) {
            this.render()
        }
    }

    static supportedEvent() {
        return ["click", "change", "change:after"]
    }

    /**
     * render element
     * @param {string|Array} source
     */
    async render() {
        if(!this._element.classList.contains('stage-container')) {
            this._element.classList.add('stage-container')
        }

        if(this._element.children.length > 0) {
            this._element.querySelectorAll('div.stage-group .stage-button')
                .forEach(stageElem => {
                    if(!stageElem.classList.contains('stage-button-dropdown')) {
                        this.#stages.push(new Stage(stageElem))
                    } else {
                        this.#stages.push(new DropdownStage(stageElem))
                    }
                })
        } else {
            const stageGroup     = document.createElement('div')
            stageGroup.className = "stage-group"
            this._element.appendChild(stageGroup)

            if(Helper.isString(source)) {
                this.#source = await this.#getStageFromServer()
            }

            this.#source.forEach(item => {
                const stage = item.hasOwnProperty('menu') && item.menu.length > 0 ? new DropdownStage(item) : new Stage(item)
                this.#stages.push(stage)
                stageGroup.appendChild(stage.element.stage)
            })
        }

        this.#stages.forEach((stage, index, stages) => {
            stage.on('onhover', () => {
                if(stage.isDisabled()) {
                    return
                }

                const dropdownOpen = stages.find(s => s instanceof DropdownStage && s._menuElement.classList.contains('show'))
                if(!(stage instanceof DropdownStage) && dropdownOpen) {
                    dropdownOpen._menuElement.classList.remove('show')
                    dropdownOpen.outHover()
                    stages.filter(s => s.id != stage.id).forEach(s => s.outHover())
                }

                if(!stage.selected) {
                    for (let i = 0; i <= index; i++) {
                        stages[i].setColor(stage instanceof DropdownStage && dropdownOpen ? stage._menu.find(s => s.selected)?.color ?? stage.getColor() : stage.getColor())
                        stages[i].onHover()
                    }
                }
            })

            stage.on('outhover', () => {
                const activeStage = stages.find(item => item.isActive())
                for (let i = 0; i <= index; i++) {
                    if(activeStage) {
                        stages[i].setColor(activeStage._menu ? activeStage._menu.find(item => item.active)?.color ?? activeStage.getColor() : activeStage.getColor())
                    }

                    stages[i].outHover()
                }
            })

            stage.on('click', async () => await this.#onClick(stage, index))
        })

        const auto = this._element.getAttribute("data-mode")
        if (auto === 'next') {
            this.autoNext()
        } else if (auto === 'next-prev') {
            this.autoNextPrev()
        }

        const value   = this._element.getAttribute("value")
        const initial = this._element.getAttribute("data-initial")

        if (!Helper.isEmpty(value)) {
            this.set(value, true)
        } else if (!Helper.isEmpty(initial)) {
            this.set(initial, true)
        } else {
            this._applyTransitions(null)
        }
    }

    /**
     * 
     * @param {Stage|DropdownStage} stage 
     */
    async #onClick(stage, index, isSilent = false) {
        const menuActive = stage._menu ? stage._menu.find(s => s.active) : null
        const data       = stage instanceof DropdownStage ? { id: menuActive.id, name: menuActive.name } : { id: stage.id, name: stage.name }
        
        const selected = () => {
            this.#stages
                .forEach((s, i) => {
                    if(i != index) {
                        s.unSelected()
                    }
                })

            for (let i = 0; i < index; i++) {
                this.#stages[i].onSelected()
                this.#stages[i].setColor(menuActive?.color ?? stage.getColor())
            }
        }

        if(stage.isDisabled()) {
            selected()
            return
        }

        if(!isSilent) {
            const trigger         = await this.trigger("click", data)
            const isTriggerExists = trigger && Array.isArray(trigger)
            const isTriggerValid  = isTriggerExists && 
                trigger.every(res => {
                    const isBool  = typeof res === 'boolean' && res === true
                    const isEmpty = res === undefined || res === null

                    return isBool || isEmpty
                })

            if(isTriggerExists && !isTriggerValid) {
                return false
            }
        }

        selected()
        this._applyTransitions(stage instanceof DropdownStage ? (menuActive?.id ?? stage.id) : stage.id)

        if(!isSilent) {
            setTimeout(async () =>  {
                await this.trigger("change", data)
                await this.trigger("change:after")
            }, 0)
        }
    }

    /**
     * set stage by id/name to active
     * @param {string} id stage id or stage name
     */
    async set(id, isSilent = false) {
        if(id == null) {
            this.#stages.forEach(stage => {
                stage.unSelected()
            })

            this._applyTransitions(null)
            return
        }

        let index = this.#stages.findIndex(item => item.id == id || item.name == id)
        let stage = this.#stages[index]
        if(!stage) {
            index = this.#stages.findIndex(item => {
                const dropdown = item instanceof DropdownStage
                const menu     = dropdown ? item._menu.find(m => m.id == id || m.name == id) : null
                return menu ? true : false
            })
            stage = this.#stages[index]
        }

        if(!stage) {
            throw new Error(`Stage with id or name ${id} not found`)
        }

        if(stage instanceof DropdownStage) {
            const menu = stage._menu.find(s => s.id == id || s.name == id)

            stage.onSelected(true)
            stage.setColor(menu.color)
            stage.setText(menu.name)
            stage._menu.forEach(m => {
                m.element.classList.remove('active')
                m.active   = false
                m.selected = false
            })
            menu.element.classList.add('active')
            menu.active   = true
            menu.selected = true
            stage._menuElement.classList.remove('show')
        } else {
            stage.onSelected(true)
        }

        await this.#onClick(stage, index, isSilent)
    }

    /**
     * get current stage active
     * @returns {{id: string, name: string}}
     */
    get() {
        const stage = this.#stages.find(item => item.isActive())
        if(stage instanceof DropdownStage) {
            const menuActive = stage._menu.find(s => s.active)
            return menuActive ? { id: menuActive.id, name: menuActive.name } : null
        }

        return stage ? { id: stage.id, name: stage.name } : null
    }

    setConfirm(id, confirm = true, confirmMessage = "") {
        let stage = this.#stages.find(item => item.id == id || item.name == id)
        if(!stage) {
            stage = this.#stages.find(item => {
                const dropdown = item instanceof DropdownStage
                const menu     = dropdown ? dropdown._menu.find(m => m.id == id || m.name == id) : null
                return menu ? true : false
            })
        }

        if(!stage) {
            throw new Error(`Stage with id or name ${id} not found`)
        }

        if(stage instanceof DropdownStage) {
            const menu   = stage._menu.find(s => s.id == id)
            menu.confirm = confirm
            if(confirmMessage != "" && confirmMessage != menu.confirmMessage) {
                menu.confirmMessage = confirmMessage
            }
        } else {
            stage._confirm = confirm
            if(confirmMessage != "" && confirmMessage != stage._confirmMessage) {
                stage._confirmMessage = confirmMessage
            }
        }

        return this
    }

    async #getStageFromServer(url) {
        const req = await axios({
            method: 'POST',
            url: `${BASE_URL}/${url}`
        })

        return req.data.map(item => {
            const data = {
                id: item.id,
                name: item.name,
                color: item.color
            }

            if(data.hasOwnProperty('menu') && data.menu.length > 0) {
                data.menu = item.menu
            }

            return data
        })
    }

    /**
     * @param {string|null} activeId - stage id or dropdown item id
     * @returns {void}
     */
    _applyTransitions(activeId) {
        const dropdownMode   = this._element.getAttribute("data-dropdown-mode") ?? "group"
        const hasTransitions = this.#stages.some(s => {
            if (s._nextManual || s._next !== null) return true
            if (s instanceof DropdownStage) return s._menu.some(m => m._nextManual || m._next !== null)
            return false
        })
        if (!hasTransitions) {
            return
        }

        const enableAll = () => {
            this.#stages.forEach(s => {
                if (!s._staticDisabled) s.enabled()
            })
        }

        const disableAll = () => {
            this.#stages.forEach(s => s.disabled())
        }

        if (activeId === null) {
            enableAll()
            return
        }

        let activeNext    = null
        let activeStageId = null

        const activeTopStage = this.#stages.find(s => s.id == activeId)
        if (activeTopStage) {
            activeNext    = activeTopStage._next
            activeStageId = activeTopStage.id
        } else {
            for (const s of this.#stages) {
                if (!(s instanceof DropdownStage)) continue
                const item = s._menu.find(m => m.id == activeId)
                if (item) {
                    activeNext    = item._next ?? s._next
                    activeStageId = s.id
                    break
                }
            }
        }

        // null  = terminal, no movement allowed
        // []    = free movement, enable all
        // [...] = whitelist, only listed ids accessible
        if (activeNext === null) {
            disableAll()
            return
        }

        if (activeNext.length === 0) {
            enableAll()
            return
        }

        this.#stages.forEach(s => {
            if (s.id == activeStageId) {
                s.disabled()
                return
            }

            if (s instanceof DropdownStage) {
                const menuIds     = s._menu.map(m => m.id)
                const nextMenuIds = activeNext.filter(id => menuIds.includes(id))

                // In 'items' mode the group id is not part of the sequence — skip group-id check
                // to prevent ID collision from triggering a full enable on all items.
                if (dropdownMode !== "items" && activeNext.includes(s.id)) {
                    if (!s._staticDisabled) s.enabled()
                } else if (nextMenuIds.length > 0) {
                    if (!s._staticDisabled) s.enabledItems(nextMenuIds)
                } else {
                    s.disabled()
                }
                return
            }

            if (activeNext.includes(s.id)) {
                if (!s._staticDisabled) s.enabled()
            } else {
                s.disabled()
            }
        })
    }

    /**
     * Disable stage(s) by id, name, or array of ids/names.
     * @param {string|Array|null} id - null disables all stages.
     * @param {boolean} asParent - when true, targets top-level DropdownStage parent; skips item-level lookup.
     * @returns {void}
     */
    disabled(id = null, asParent = false) {
        if (!id) {
            this.#stages.forEach(stage => stage.disabled())
            return
        }

        const ids = Array.isArray(id) ? id : [id]
        ids.forEach(targetId => {
            const stage = this.#stages.find(s => s.id == targetId || s.name == targetId)
            if (stage || asParent) {
                if (!stage) {
                    throw new Error(`Stage with id or name ${targetId} not found`)
                }
                stage.disabled()
                return
            }

            for (const s of this.#stages) {
                if (!(s instanceof DropdownStage)) continue
                const item = s._menu.find(m => m.id == targetId || m.name == targetId)
                if (item) {
                    s.disabledItem(targetId)
                    return
                }
            }

            throw new Error(`Stage or dropdown item with id or name ${targetId} not found`)
        })
    }

    /**
     * Enable stage(s) by id, name, or array of ids/names.
     * @param {string|Array|null} id - null enables all stages.
     * @param {boolean} asParent - when true, targets top-level DropdownStage parent; skips item-level lookup.
     * @returns {void}
     */
    enabled(id = null, asParent = false) {
        if (!id) {
            this.#stages.forEach(stage => stage.enabled())
            return
        }

        const ids = Array.isArray(id) ? id : [id]
        ids.forEach(targetId => {
            const stage = this.#stages.find(s => s.id == targetId || s.name == targetId)
            if (stage || asParent) {
                if (!stage) {
                    throw new Error(`Stage with id or name ${targetId} not found`)
                }
                stage.enabled()
                return
            }

            for (const s of this.#stages) {
                if (!(s instanceof DropdownStage)) continue
                const item = s._menu.find(m => m.id == targetId || m.name == targetId)
                if (item) {
                    s.enabledItem(targetId)
                    return
                }
            }

            throw new Error(`Stage or dropdown item with id or name ${targetId} not found`)
        })
    }

    /**
     * @param {string} id - stage id, stage name, or dropdown item id
     * @param {Array|null} next
     * @returns {this}
     */
    setNext(id, next) {
        const entity = this.#_findEntity(id)
        if (!entity) {
            throw new Error(`Stage with id or name ${id} not found`)
        }

        entity._next       = next
        entity._nextManual = true

        const active = this.get()
        this._applyTransitions(active?.id ?? null)

        return this
    }

    /**
     * Append ids to an entity's _next without replacing existing values.
     * Marks _nextManual = true to prevent auto-next from overwriting.
     * @param {string} id - stage id, stage name, or dropdown item id
     * @param {Array} extraIds - ids to append
     * @returns {this}
     */
    addNext(id, extraIds) {
        const entity = this.#_findEntity(id)
        if (!entity) {
            throw new Error(`Stage with id or name ${id} not found`)
        }

        entity._next       = [...new Set([...(entity._next ?? []), ...extraIds])]
        entity._nextManual = true

        const active = this.get()
        this._applyTransitions(active?.id ?? null)

        return this
    }

    /**
     * Remove specific ids from an entity's _next.
     * Marks _nextManual = true to prevent auto-next from restoring removed ids.
     * @param {string} id - stage id, stage name, or dropdown item id
     * @param {Array} removeIds - ids to remove
     * @returns {this}
     */
    removeNext(id, removeIds) {
        const entity = this.#_findEntity(id)
        if (!entity) {
            throw new Error(`Stage with id or name ${id} not found`)
        }

        if (entity._next === null) {
            return this
        }

        entity._next       = entity._next.filter(nextId => !removeIds.includes(nextId))
        entity._nextManual = true

        const active = this.get()
        this._applyTransitions(active?.id ?? null)

        return this
    }

    /**
     * Auto-set next for each stage: forward only (stage[i] → stage[i+1]).
     * Dropdown items are flattened into the sequence as individual nodes.
     * Last node: terminal by default (null). Set data-final="false" to allow free movement from last stage.
     * @returns {this}
     */
    autoNext() {
        const flat      = this.#_flattenEntities()
        const finalAttr = this._element.getAttribute("data-final")
        const lastNext  = finalAttr === "false" ? [] : null

        flat.forEach((entity, i) => {
            if (entity._nextManual) return
            entity._next = i < flat.length - 1 ? [flat[i + 1].id] : lastNext
        })

        const active = this.get()
        this._applyTransitions(active?.id ?? null)

        return this
    }

    /**
     * Auto-set next for each stage: prev + next (stage[i] → stage[i-1] and stage[i+1]).
     * Dropdown items are flattened into the sequence as individual nodes.
     * First node: next only. Last node: prev only by default. Set data-final="true" to make last stage terminal.
     * @returns {this}
     */
    autoNextPrev() {
        const flat       = this.#_flattenEntities()
        const finalAttr  = this._element.getAttribute("data-final")
        const lastTerminal = finalAttr === "true"

        flat.forEach((entity, i) => {
            if (entity._nextManual) return
            const prev = i > 0 ? flat[i - 1].id : null
            const next = i < flat.length - 1 ? flat[i + 1].id : null

            if (i === flat.length - 1 && lastTerminal) {
                entity._next = null
            } else {
                entity._next = [prev, next].filter(id => id !== null)
            }
        })

        const active = this.get()
        this._applyTransitions(active?.id ?? null)

        return this
    }

    /**
     * Find a Stage or DropdownItem entity by id or name.
     * @param {string} id
     * @returns {Stage|DropdownItem|null}
     */
    #_findEntity(id) {
        const stage = this.#stages.find(s => s.id == id || s.name == id)
        if (stage) {
            return stage
        }

        for (const s of this.#stages) {
            if (!(s instanceof DropdownStage)) continue
            const item = s._menu.find(m => m.id == id || m.name == id)
            if (item) {
                return item
            }
        }

        return null
    }

    /**
     * Flatten stages into a single ordered sequence for auto-next/auto-next-prev.
     * Behaviour depends on data-dropdown-mode attribute (default: 'group'):
     *   'group' — DropdownStage treated as one node; item-level _next ignored.
     *   'items' — DropdownStage expanded into individual item nodes; parent _next nulled.
     * @returns {Array}
     */
    #_flattenEntities() {
        const flat         = []
        const dropdownMode = this._element.getAttribute("data-dropdown-mode") ?? "group"

        this.#stages.forEach(s => {
            if (s instanceof DropdownStage) {
                if (dropdownMode === "items") {
                    s._next = null
                    s._menu.forEach(m => flat.push(m))
                } else {
                    flat.push(s)
                }
            } else {
                flat.push(s)
            }
        })
        return flat
    }

    reset(isSilent = false) {
        this.set(null, isSilent)
    }
}