import Helper from "../helper"
import Stage from "./stage"

class DropdownItem {

    /**
     * @param {{
     *  id: string,
     *  name: string,
     *  color: string,
     *  active: boolean,
     *  selected: boolean,
     *  disabled: boolean,
     *  confirm: boolean,
     *  confirmMessage: string,
     *  action: any,
     *  element: HTMLElement,
     * }} item 
     */
    constructor(item) {
        this.id             = item.id
        this.name           = item.name
        this.color          = item.color
        this.active         = item.active ?? false
        this.selected       = item.selected ?? false
        this._disabled       = item.disabled ?? false
        this._staticDisabled = this._disabled
        this._next           = null
        this._nextManual     = false
        this.confirm         = item.confirm ?? false
        this.confirmMessage  = item.confirmMessage
        this.action          = item.action
        this.element         = item.element

        if(this.element && this._disabled) {
            this.disabled()
        }
    }

    _initOnHover(callback) {
        this.element.addEventListener("mouseenter", () => {
            this.selected = true

            if(Helper.isFunction(callback)) {
                callback()
            }
        })
    }

    _initOutHover(callback) {
        this.element.addEventListener("mouseleave", () => {
            this.selected = false
            
            if(Helper.isFunction(callback)) {
                callback()
            }
        })
    }

    _initOnClick(callback) {
        this.element.addEventListener('click', (e) => {
            e.preventDefault()

            if(Helper.isFunction(callback)) {
                callback()
            }
        })
    }

    disabled() {
        this._disabled = true
        this.element.classList.add("disabled")
    }

    isDisabled() {
        return this._disabled
    }

    enabled() {
        this._disabled = false
        this.element.classList.remove("disabled")
    }

    onSelected() {
        this.element.classList.add("active")
        this.selected = true
        this.active   = true
    }

    unSelected() {
        this.element.classList.remove("active")
        this.selected = false
        this.active   = false
    }
}

export default class DropdownStage extends Stage {
    /**
     * _stageFromElement create stage from HTMLElement
     * @param {HTMLElement} stage
     */
    _stageFromElement() {
        if(!this._element.classList.contains('stage-button-dropdown')) {
            throw new Error("Dropdown Stage must be contains class stage-button and stage-button-dropdown")
        }

        super._stageFromElement()

        this._menuElement = this._element.parentElement.parentElement.querySelector(`div.dropdown-menu[data-id="${this.id}"]`)
        if(!this._menuElement) {
            throw new Error("Dropdown menu not found")
        }

        this._menu = Array.from(this._menuElement.querySelectorAll('a.dropdown-item')).map(item => {
            return new DropdownItem({
                id            : item.dataset.id,
                name          : item.textContent,
                color         : item.dataset.color ?? this._color,
                active        : false,
                selected      : false,
                disabled      : item.dataset.disabled == "true" ? true : this._disabled,
                confirm       : item.dataset.confirm == "true",
                confirmMessage: item.dataset.confirmMessage ?? this._confirmMessage,
                action        : null,
                element       : item
            })
        })
    }

    /**
     * _stageFromObject create stage from object
     * @param {{
     *  id: string,
     *  name: string,
     *  color: string,
     *  confirm: boolean,
     *  disabled: boolean,
     *  menu: Array
     * }} stage
    */
    _stageFromObject(stage) {
        if(!this._container) {
            throw new Error("Container cannot be null")
        }

        if(!["id", "name", "color", "menu"].every(prop => stage.hasOwnProperty(prop))) {
            throw new Error("Stage must have id, name, color, and element property")
        }

        super._stageFromObject(stage)

        this._menu = stage.menu.map(item => {
            return new DropdownItem({
                id            : item.id,
                name          : item.name,
                color         : item.color ?? this._color,
                active        : false,
                selected      : false,
                disabled      : item.disabled ? true : this._disabled,
                confirm       : item.confirm ?? false,
                confirmMessage: item.confirmMessage ?? this._confirmMessage,
                action        : item.action ?? null,
                element       : null
            })
        })

        this._createElement()
    }

    _createElement() {
        super._createElement()

        this.element.stage.classList.add("stage-button-dropdown")

        const spanText     = document.createElement('span')
        spanText.className = "d-flex justify-content-between"

        const arrowSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 16 16" fit="" preserveAspectRatio="xMidYMid meet" focusable="false">
            <g transform="translate(-1783.779 74.455)">
                <g>
                <g>
                    <path d="M1787.779-67.455l4,4,4-4Z" fill="currentColor"></path>
                </g>
                </g>
            </g>
            <rect width="16" height="16" fill="none"></rect>
        </svg>`

        const arrow     = document.createElement('span')
        arrow.className = 'stage-text-arrow'
        arrow.innerHTML = arrowSvg

        const menu     = document.createElement('div')
        menu.className = "dropdown-menu"
        menu.setAttribute('data-id', this.id)

        this._menu.forEach(m => {
            const item     = document.createElement('a')
            item.className = "dropdown-item"
            item.setAttribute('href', '#')
            item.setAttribute('data-id', m.id)
            item.setAttribute('data-color', m.color)
            item.setAttribute('data-confirm', m.confirm)
            item.setAttribute('data-disabled', m.isDisabled())
            item.textContent = m.name

            if(m.isDisabled()) {
                item.classList.add("disabled")
            }

            menu.appendChild(item)
            m.element = item
        })

        spanText.append(text, arrow)

        this.element.button.removeChild()
        this.element.button.appendChild(spanText)

        this._container.appendChild(menu)
        this._menuElement = menu
    }

    _initOnHover() {
        super._initOnHover()
        this._menu.forEach(item => item._initOnHover(() => this.trigger('onhover')))
    }

    _initOutHover() {
        this._element.addEventListener("mouseleave", () => {
            if(this.isDisabled()) {
                return
            }

            if(!this._menuElement.classList.contains('show')) {
                this.outHover()
                this.trigger('outhover')
            }
        })

        this._menu.forEach(item => item._initOutHover())
    }

    _initOnClick() {
        this._button.addEventListener("click", async () => {
            this._menuElement.style.top  = `${this._element.offsetTop + this._element.clientHeight}px`;
            this._menuElement.style.left = `${this._element.offsetLeft}px`;
            this._menuElement.classList.toggle('show')
        })

        this._menu.forEach((item, index, menus) => {
            item._initOnClick(async () => {
                if(this.isDisabled()) {
                    return
                }

                if(item.isDisabled()) {
                    return
                }

                if(item.active) {
                    return
                }

                if(item.confirm) {
                    if(!await Helper.confirm({title: item.confirmMessage})) {
                        this._menuElement.classList.toggle('show')
                        return
                    }
                }

                menus.forEach(m => m.unSelected())
                item.active = true

                const trigger         = await this.trigger('click')
                const isTriggerExists = trigger && Array.isArray(trigger)
                const isTriggerValid  = isTriggerExists && trigger.every(res => typeof res === 'boolean' && res === true)
                const isTriggerNull   = isTriggerExists && trigger.every(res => res === undefined || res === null) || !trigger

                if(isTriggerValid || isTriggerNull) {
                    item.onSelected()

                    this.onSelected(true)
                    this.setColor(item.color)
                    this.setText(item.name)

                    this._menuElement.classList.remove('show')
                    this.activeMenu = item
                } else {
                    menus.forEach(m => m.unSelected())

                    if(this.activeMenu) {
                        this.activeMenu.onSelected()
                        
                        this.outHover()
                        this.trigger('outhover')
                    }
                }
            })
        })

        document.addEventListener("click", (e) => {
            if(!this._menuElement.contains(e.target) && !this._element.contains(e.target)) {
                this._menuElement.classList.remove('show')
                this.outHover()
                this.trigger('outhover')
            }
        })
    }

    disabled() {
        super.disabled()
        this._menu.forEach(m => m.disabled())
    }

    enabled() {
        super.enabled()
        this._menu.forEach(m => { if (!m._staticDisabled) m.enabled() })
    }

    /**
     * Enable stage button and only the specified items. All other items disabled.
     * @param {Array<string>} ids - item ids to enable
     */
    enabledItems(ids) {
        super.enabled()
        this._menu.forEach(m => {
            if (ids.includes(m.id)) {
                if (!m._staticDisabled) m.enabled()
            } else {
                m.disabled()
            }
        })
    }

    unSelected() {
        super.unSelected()
        this.setText(this.name)
        this._menu.forEach(m => m.unSelected())
    }

    /**
     * Disable a single dropdown item by id or name.
     * @param {string} id
     * @returns {void}
     */
    disabledItem(id) {
        const item = this._menu.find(m => m.id == id || m.name == id)
        if (!item) {
            throw new Error(`Dropdown item with id or name ${id} not found`)
        }
        item.disabled()
    }

    /**
     * Enable a single dropdown item by id or name. Respects _staticDisabled.
     * @param {string} id
     * @returns {void}
     */
    enabledItem(id) {
        const item = this._menu.find(m => m.id == id || m.name == id)
        if (!item) {
            throw new Error(`Dropdown item with id or name ${id} not found`)
        }
        if (!item._staticDisabled) {
            item.enabled()
        }
    }

    setText(text) {
        this._text.textContent = text
    }
}