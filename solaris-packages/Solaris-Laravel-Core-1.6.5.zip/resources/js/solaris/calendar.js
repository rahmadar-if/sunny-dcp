import { default as FullCalendar } from "@core-js/libs/fullcalendar"
import axios from "@core-js/libs/axios"
import Helper from "./helper"
import SolarComponent from "./solar/solar-component"
import DateHelper from "./date-helper"

export default class Calendar extends SolarComponent {
    constructor(selector) {
        super()

        if (selector instanceof Element) {
            this._element = selector
        } else if (Helper.isString(selector) && !Helper.isEmpty(selector)) {
            this._element = document.querySelector(selector)
            if (!this._element) {
                throw new Error(`Element with query selector ${selector} is not found`)
            }
        } else {
            throw new Error(`Selector is not supported`)
        }

        this._id = this._element.id
        this._source = this._element.getAttribute("source")
        this._isInit = false
        this._isRendered = false

        this._calendar = new FullCalendar(this._element, {
            timeZone: 'local',
            editable: true,
            droppable: true,
            selectable: true,
            navLinks: true,
            initialView: this.#getInitialView(),
            themeSystem: 'bootstrap',
            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth,timeGridWeek,timeGridDay'
            },
            windowResize: (view) => {
                const newView = this.#getInitialView()
                this._calendar.changeView(newView)
            },
            events: async (fetchInfo, successCallback, failureCallback) => {
                const startDate = DateHelper.dateToString(fetchInfo.start)
                const endDate   = DateHelper.dateToString(fetchInfo.end)
                
                try {
                    const req = await axios({
                        method: 'POST',
                        url: new URL(this._source, BASE_URL + "/").href,
                        data: {
                            start_date: startDate,
                            end_date: endDate,
                        }
                    })

                    if (!this._isInit) {
                        this._isInit = true
                        this.trigger("init", startDate, endDate)
                    } else {
                        this.trigger("fetch", startDate, endDate)
                    }

                    successCallback(req.data)
                } catch (error) {
                    console.error({ error })
                    failureCallback(error.toString())
                }
            },
            dateClick: (info) => this.trigger("dateClick", info),
            eventClick: (info) => this.trigger("eventClick", info),
            eventDrop: (info) => this.trigger("eventDrop", info),
            select: (info) => this.trigger("select", info)
        })

        this._lazy = this._element.hasAttribute('lazy')
        if(!this._lazy) {
            this.render()
        }
    }

    #getInitialView() {
        if (window.innerWidth >= 768 && window.innerWidth < 1200) {
            return 'timeGridWeek'
        } else if (window.innerWidth <= 768) {
            return 'listMonth'
        } else {
            return 'dayGridMonth'
        }
    }

    static supportedEvent() {
        return ["init", "fetch", "dateClick", "eventClick", "eventDrop", "select"]
    }

    render() {
        if(this._isRendered) {
            return
        }
        
        this._isRendered = true
        this._calendar.render()
    }

    refresh() {
        this._calendar.refetchEvents()
    }

    /**
     * @returns {boolean}
     */
    get isInit() {
        return this._isInit
    }

    /**
     * @returns {{ startDate: string, endDate: string }}
     */
    get currentRange() {
        const view = this._calendar.view
        return {
            startDate: DateHelper.dateToString(view.activeStart),
            endDate:   DateHelper.dateToString(view.activeEnd)
        }
    }
}