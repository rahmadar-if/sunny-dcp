import DatePicker from "./form/date-picker"
import TextInput from "./form/text-input"
import Modal from "./modal"
import Button from "./button"
import Helper from "./helper"
import SolarComponent from "./solar/solar-component"

export default class PeriodFilter extends SolarComponent {
    #isCustom = false

    constructor(selector) {
        super()

        if(selector instanceof Element) {
            this._element = selector
        } else if(Helper.isString(selector) && !Helper.isEmpty(selector)) {
            this._element = document.querySelector(selector)
            if(!this._element) {
                throw new Error(`Element with query selector ${selector} is not found`)
            }
        } else {
            throw new Error(`Selector is not supported`)
        }

        this._id        = this._element.id
        this._text      = this._element.querySelector(`#${this._id}_text`)
        this._items     = this._element.querySelectorAll(".dropdown-menu a.dropdown-item")
        this._modal     = new Modal(`#${this._id}_modal`)
        this._dateField = new DatePicker(`#${this._id}_datepicker`)
        this._start     = new TextInput(`#${this._id}_start`)
        this._end       = new TextInput(`#${this._id}_end`)
        this._apply     = new Button(`#${this._id}_apply`)
        this._button    = new Button(`#${this._id}_button`)

        this._rangeDates = []

        this.init()
    }

    static availableItems() {
        return [
            "current-year",
            "previous-year",
            "current-month",
            "previous-month",
            "last-3-months",
            "last-6-months",
            "current-week",
            "last-week",
            "custom-range"
        ]
    }

    static supportedEvent() {
        return ["change"]
    }

    init() {
        this._items.forEach(item => {
            item.addEventListener('click', (e) => {
                const dropdownItem = e.target
                let type = ""
                for (const value of dropdownItem.classList.entries()) {
                    if(this.constructor.availableItems().includes(value[1])) {
                        type = value[1]
                        break
                    }
                }

                this.#onChange(dropdownItem, type)
            })
        })

        this._modal.on("show", () => {
            if(this.#isCustom) {
                this._dateField.set(this._rangeDates)
                this._start.set(Helper.dateToFullString(this._rangeDates[0]))
                this._end.set(Helper.dateToFullString(this._rangeDates[1]))
            }
        }, "PeriodFilter")
        .on("hide", () => {
            this._dateField.reset(true)
            this._start.reset(true)
            this._end.reset(true)
        }, "PeriodFilter")

        this._dateField.on("change", (value) => {
            if(!value || (value && value.length == 0)) {
                this._start.set(null)
                this._end.set(null)
    
                return
            }
    
            this._start.set(Helper.dateToFullString(value[0]))
            this._end.set(value.length == 2 ? Helper.dateToFullString(value[1]) : null) 
        }, "PeriodFilter")

        this._apply.on("click", () => {
            const selectedDates = this._dateField.get()
            if(selectedDates.length != 2) {
                return
            }

            this._text.textContent = `${Helper.dateToFullString(selectedDates[0])} - ${Helper.dateToFullString(selectedDates[1])}`
            this._rangeDates = [selectedDates[0], selectedDates[1]]

            this._items.forEach(item => {
                item.classList.remove('active')
                if(item.classList.contains('custom-range')) {
                    item.classList.add('active')
                }
            })

            this._modal.hide()

            const isChanged = this.isChanged()
            this._oldValue = this._rangeDates

            if(isChanged || !this.#isCustom) {
                this.trigger("change", this.get(), this.toString())
            }

            this.#isCustom = true
        }, "PeriodFilter")

        this.#defaultValue()
        this._oldValue = this._rangeDates
    }

    get() {
        return this._rangeDates
    }

    toString() {
        return this._rangeDates.map(date => Helper.dateToString(date))
    }

    isChanged() {
        if (!Array.isArray(this._oldValue) || !Array.isArray(this._rangeDates)) {
            return true
        }

        if(this._oldValue.length !== this._rangeDates.length) {
            return true
        }

        let isChanged = false
        for (let i = 0; i < this._oldValue.length; i++) {
            const oldVal = Helper.dateToString(this._oldValue[i])
            const newVal = Helper.dateToString(this._rangeDates[i])
            
            if(oldVal != newVal) {
                isChanged = true
                break;
            }
        }

        return isChanged
    }

    disabled() {
        this._button.disabled()
    }

    enabled() {
        this._button.enabled()
    }

    #onChange(item, type) {
        const today = new Date()

        let currentWeek = () => {
            const distanceToStartOfWeek = (today.getDay() - 1 + 7) % 7

            const start = new Date(today)
            start.setDate(today.getDate() - distanceToStartOfWeek)

            const end = new Date(start)
            end.setDate(start.getDate() + 6)

            return { start, end }
        }
        currentWeek = currentWeek()

        let dateStr = ""
        switch (type) {
            case 'current-week':
                const firstDayCurrentWeek = currentWeek.start
                const lastDayCurrentWeek = currentWeek.end

                dateStr = `${Helper.dateToFullString(firstDayCurrentWeek)} - ${Helper.dateToFullString(lastDayCurrentWeek)}`
                this._rangeDates = [firstDayCurrentWeek, lastDayCurrentWeek]
                
                break;

            case 'last-week':
                const firstDayLastWeek = new Date(currentWeek.start)
                firstDayLastWeek.setDate(currentWeek.start.getDate() - 7)

                const lastDayLastWeek = new Date(currentWeek.end)
                lastDayLastWeek.setDate(currentWeek.end.getDate() - 7)

                dateStr = `${Helper.dateToFullString(firstDayLastWeek)} - ${Helper.dateToFullString(lastDayLastWeek)}`
                this._rangeDates = [firstDayLastWeek, lastDayLastWeek]
                
                break;
            
            case 'current-month':
                const firstDayCurrentMonth = new Date(today.getFullYear(), today.getMonth(), 1)
                const lastDayCurrentMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0)

                dateStr = `${Helper.dateToFullString(firstDayCurrentMonth)} - ${Helper.dateToFullString(lastDayCurrentMonth)}`
                this._rangeDates = [firstDayCurrentMonth, lastDayCurrentMonth]
                
                break;

            case 'previous-month':
                const previousMonthStart = new Date(today.getFullYear(), today.getMonth() - 1, 1)

                dateStr = `${Helper.dateToFullString(previousMonthStart)} - ${Helper.dateToFullString(today)}`
                this._rangeDates = [previousMonthStart, today]

                break;

            case 'last-3-months':
                const last3MonthsStart = new Date(today)
                last3MonthsStart.setMonth(today.getMonth() - 3)

                dateStr = `${Helper.dateToFullString(last3MonthsStart)} - ${Helper.dateToFullString(today)}`
                this._rangeDates = [last3MonthsStart, today]

                break;

            case 'last-6-months':
                const last6MonthsStart = new Date(today);
                last6MonthsStart.setMonth(today.getMonth() - 6)

                dateStr = `${Helper.dateToFullString(last6MonthsStart)} - ${Helper.dateToFullString(today)}`
                this._rangeDates = [last6MonthsStart, today]

                break;

            case 'previous-year':
                const previousYearStart = new Date(today.getFullYear() - 1, 0, 1)
                const previousYearEnd = new Date(today.getFullYear() - 1, 11, 31)

                dateStr = `${Helper.dateToFullString(previousYearStart)} - ${Helper.dateToFullString(previousYearEnd)}`
                this._rangeDates = [previousYearStart, previousYearEnd]

                break;

            case 'custom-range':
                this._modal.show()
                return
        
            default:
                const currentYearStart = new Date(today.getFullYear(), 0, 1)
                const currentYearEnd = new Date(today.getFullYear(), 11, 31)

                dateStr = `${Helper.dateToFullString(currentYearStart)} - ${Helper.dateToFullString(currentYearEnd)}`
                this._rangeDates = [currentYearStart, currentYearEnd]

                break
        }

        this._items.forEach(item => item.classList.remove('active'))
        this._text.textContent = dateStr

        item.classList.add('active')

        const isChanged = this.isChanged()
        this._oldValue = this._rangeDates

        if(isChanged || this.#isCustom) {
            this.trigger("change", this.get(), this.toString())
        }

        this.#isCustom = false
    }

    #defaultValue() {
        const today = new Date()
        const currentYearStart = new Date(today.getFullYear(), 0, 1)
        const currentYearEnd = new Date(today.getFullYear(), 11, 31)

        this._text.textContent = `${Helper.dateToFullString(currentYearStart)} - ${Helper.dateToFullString(currentYearEnd)}`
        this._rangeDates = [currentYearStart, currentYearEnd]

        this._items.forEach(item => {
            item.classList.remove('active')
            if(item.classList.contains('current-year')) {
                item.classList.add('active')
            }
        })
    }
}