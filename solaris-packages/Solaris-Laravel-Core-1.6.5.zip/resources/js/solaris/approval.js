import axios from "@core-js/libs/axios"
import Helper from "./helper"
import Toast from "./toast"
import { ApprovalRequestStatus, ApprovalLevelStatus, ApprovalAssignmentStatus } from "../const"
import Button from "./button"

export default class Approval {

    constructor(selector) {
        if (selector instanceof Element) {
            this._element = selector
        } else if (Helper.isString(selector) && !Helper.isEmpty(selector)) {
            this._element = document.querySelector(selector)
            if (!this._element) {
                throw new Error(`Element with query selector ${selector} is not found`)
            }
        } else {
            throw new Error(`Selector is not supported`)
        }

        this._id = this._element.getAttribute('solar-id') || this._element.id

        this._pulse         = document.getElementById(`${this._id}_pulse`)
        this._offcanvasEl   = document.getElementById(`${this._id}_offcanvas`)
        this._offcanvas     = new bootstrap.Offcanvas(this._offcanvasEl)
        this._offcanvasBody = this._offcanvasEl?.querySelector('.offcanvas-body')
        this._pendingPane   = document.getElementById(`${this._id}_tab_pending`)
        this._pendingList   = document.getElementById(`${this._id}_pending_list`)
        this._pendingEmpty  = document.getElementById(`${this._id}_pending_empty`)
        this._requestsPane  = document.getElementById(`${this._id}_tab_requests`)
        this._requestsList  = document.getElementById(`${this._id}_requests_list`)
        this._requestsEmpty = document.getElementById(`${this._id}_requests_empty`)
        this._pendingBadge  = document.getElementById(`${this._id}_pending_badge`)
        this._requestsBadge = document.getElementById(`${this._id}_requests_badge`)

        this._totalPending = parseInt(this._element.getAttribute('total') || '0')

        this._pendingState  = {
            start:   this._pendingList.querySelectorAll('li').length,
            length:  10,
            total:   this._totalPending,
            loading: false,
        }
        this._requestsState = {
            start:   this._requestsList.querySelectorAll('li').length,
            length:  10,
            total:   parseInt(this._element.getAttribute('total-requests') || '0'),
            loading: false,
        }

        this.init()
    }

    init() {
        const refreshBtn = document.getElementById(`${this._id}_refresh`)
        if(refreshBtn) {
            this._refreshBtn = new Button(refreshBtn)
            this._refreshBtn.enabled()
            this._refreshBtn.on("click", () => {
                this._fetchPending()
                this._fetchRequests()
            })
        }
        
        this._setPulse(this._totalPending > 0)
        this._bindPendingActions()
        this._bindRequestsActions()
        this._bindInfiniteScroll()
        this._listenBroadcast()
    }

    refresh() {
        this._pendingState.start  = 0
        this._requestsState.start = 0
        this._fetchPending()
        this._fetchRequests()
    }

    // #region fetch

    async _fetchPending(append = false) {
        const state = this._pendingState
        if (state.loading) return
        if (append && state.start >= state.total) return
        if (!append) state.start = 0

        state.loading = true
        try {
            const res  = await axios.get(`${BASE_URL}/core/approval/pending`, {
                params: { start: state.start, length: state.length },
            })
            const data  = res.data?.data ?? []
            state.total  = res.data?.recordsTotal ?? 0
            state.start += data.length
            if (!append) {
                this._updatePendingBadge(state.total)
                this._setPulse(state.total > 0)
            }
            append ? this._appendPending(data) : this._renderPending(data)
        } catch (e) {
            console.error('Approval: fetch pending error', e)
        } finally {
            state.loading = false
        }
    }

    async _fetchRequests(append = false) {
        const state = this._requestsState
        if (state.loading) return
        if (append && state.start >= state.total) return
        if (!append) state.start = 0

        state.loading = true
        try {
            const res  = await axios.get(`${BASE_URL}/core/approval/my-requests`, {
                params: { start: state.start, length: state.length },
            })
            const data  = res.data?.data ?? []
            state.total  = res.data?.recordsTotal ?? 0
            state.start += data.length
            this._updateRequestsBadge(res.data?.totalInProgress ?? 0)
            append ? this._appendRequests(data) : this._renderRequests(data)
        } catch (e) {
            console.error('Approval: fetch requests error', e)
        } finally {
            state.loading = false
        }
    }

    // #endregion

    // #region render

    _renderPending(items) {
        this._pendingList.innerHTML = items.map(item => this._pendingItemHtml(item)).join('')
        this._pendingEmpty.classList.toggle('d-none', !!items.length)
    }

    _appendPending(items) {
        if (!items.length) return
        this._pendingList.insertAdjacentHTML('beforeend', items.map(item => this._pendingItemHtml(item)).join(''))
    }

    _pendingItemHtml(assignment) {
        const request     = assignment.level?.request ?? {}
        const requester   = request.requester?.name ?? null
        const subjectHtml = (request.subject_label && request.subject_url)
            ? `<a href="${request.subject_url}" class="fs-12 text-primary" target="_blank"><i class="ri-external-link-line fs-11"></i> ${request.subject_label}</a>`
            : ''
        return `<li class="px-3 py-3 border-bottom">
            <div class="d-flex flex-column gap-1">
                <p class="fw-medium mb-0 fs-14">${request.name ?? '-'}</p>
                ${request.description ? `<span class="fs-12 text-muted">${request.description}</span>` : ''}
                ${subjectHtml}
                ${requester ? `<span class="fs-12">Requested by: <strong>${requester}</strong></span>` : ''}
                <div class="d-flex justify-content-between align-items-center mt-1">
                    <span class="fs-11 text-muted">${assignment.created_at ?? ''}</span>
                    <div class="d-flex gap-1">
                        <button class="btn btn-sm btn-wave btn-outline-success action-approve" data-id="${assignment.id}">Approve</button>
                        <button class="btn btn-sm btn-wave btn-outline-danger action-reject" data-id="${assignment.id}">Reject</button>
                    </div>
                </div>
            </div>
        </li>`
    }

    _getLevelApproverName(level) {
        return level.user_approver?.name
            ?? level.role_approver?.name
            ?? level.permission_approver?.name
            ?? level.approver_type?.name
            ?? '–'
    }

    _levelProgressIcon(statusId) {
        const map = {
            [ApprovalLevelStatus.Approved]:   { icon: 'ri-checkbox-circle-fill', cls: 'text-success', title: 'Approved' },
            [ApprovalLevelStatus.InProgress]: { icon: 'ri-loader-3-line', cls: 'text-warning', title: 'In Progress' },
            [ApprovalLevelStatus.Rejected]:   { icon: 'ri-close-circle-fill', cls: 'text-danger', title: 'Rejected' },
            [ApprovalLevelStatus.Skipped]:    { icon: 'ri-indeterminate-circle-line', cls: 'text-muted', title: 'Skipped' },
        }
        return map[statusId] ?? { icon: 'ri-circle-line', cls: 'text-muted', title: 'Pending' }
    }

    _levelConnectorClass(statusId) {
        const map = {
            [ApprovalLevelStatus.Approved]:   'border-success',
            [ApprovalLevelStatus.InProgress]: 'border-warning',
            [ApprovalLevelStatus.Rejected]:   'border-danger',
        }
        return map[statusId] ?? 'border-secondary'
    }

    _assignmentIcon(statusId) {
        const map = {
            [ApprovalAssignmentStatus.Approved]:  { icon: 'ri-checkbox-circle-fill', cls: 'text-success', title: 'Approved' },
            [ApprovalAssignmentStatus.Rejected]:  { icon: 'ri-close-circle-fill', cls: 'text-danger', title: 'Rejected' },
            [ApprovalAssignmentStatus.Dismissed]: { icon: 'ri-indeterminate-circle-line', cls: 'text-muted', title: 'Dismissed' },
            [ApprovalAssignmentStatus.Pending]:   { icon: 'ri-circle-line', cls: 'text-muted', title: 'Pending' },
        }
        return map[statusId] ?? { icon: 'ri-circle-line', cls: 'text-muted', title: 'Pending' }
    }

    _levelInfoText(request, levels) {
        const activeIdx = levels.findIndex(l => l.status_id === ApprovalLevelStatus.InProgress)
        const active    = activeIdx >= 0 ? levels[activeIdx] : null
        const total     = levels.length

        if (request.status_id === ApprovalRequestStatus.Approved) {
            return 'All levels completed'
        }

        if (active) {
            const typeName = active.approver_type?.name ?? 'Approver'
            return `Level ${activeIdx + 1}/${total} &bull; ${typeName}: ${this._getLevelApproverName(active)}`
        }

        if (request.status_id === ApprovalRequestStatus.Rejected) {
            const rejIdx   = levels.findIndex(l => l.status_id === ApprovalLevelStatus.Rejected)
            const rejLevel = rejIdx >= 0 ? levels[rejIdx] : null
            const typeName = rejLevel?.approver_type?.name ?? 'Approver'
            return `Rejected at Level ${rejIdx + 1} &bull; ${typeName}: ${rejLevel ? this._getLevelApproverName(rejLevel) : '-'}`
        }

        if (request.status_id === ApprovalRequestStatus.Pending) {
            return `Level 0/${total} &bull; Waiting to start`
        }

        return request.status?.name ?? ''
    }

    _progressLineHtml(levels) {
        return levels.map((level, idx) => {
            const { icon, cls, title } = this._levelProgressIcon(level.status_id)
            const dot = `<i class="${icon} ${cls} fs-12" title="Lv ${idx + 1}: ${title}"></i>`
            if (idx === 0) return dot
            const connCls = this._levelConnectorClass(levels[idx - 1].status_id)
            return `<span class="border-top ${connCls}" style="width:16px"></span>${dot}`
        }).join('')
    }

    _levelAssignmentsHtml(level) {
        const isApproved = level.status_id === ApprovalLevelStatus.Approved
        const isRejected = level.status_id === ApprovalLevelStatus.Rejected
        let assignments  = level.assignments ?? []

        if (isApproved) assignments = assignments.filter(a => a.status_id === ApprovalAssignmentStatus.Approved)

        return assignments.map(a => {
            const { icon, cls, title } = this._assignmentIcon(a.status_id)
            const actedAt = a.acted_at ? `<span class="text-muted fs-11 flex-shrink-0">${a.acted_at}</span>` : ''
            const notes   = a.notes    ? `<p class="mb-0"><span class="d-inline-block mw-100 text-truncate truncate-toggle fst-italic text-muted fs-11" style="cursor:pointer">"${a.notes}"</span></p>` : ''
            return `<div class="d-flex align-items-start gap-1 mt-1">
                <i class="${icon} ${cls} fs-11 flex-shrink-0" title="${title}"></i>
                <div class="flex-fill overflow-hidden">
                    <div class="d-flex justify-content-between align-items-center gap-1">
                        <span class="fs-12">${a.approver?.name ?? '–'}</span>
                        ${actedAt}
                    </div>
                    ${notes}
                </div>
            </div>`
        }).join('')
    }

    _expandedLevelsHtml(levels) {
        return levels.map((level, idx) => {
            const { icon, cls, title } = this._levelProgressIcon(level.status_id)
            const approverName  = this._getLevelApproverName(level)
            const isActive   = level.status_id === ApprovalLevelStatus.InProgress
            const isApproved = level.status_id === ApprovalLevelStatus.Approved
            const isRejected = level.status_id === ApprovalLevelStatus.Rejected
            const modeLabel  = level.mode === 'consensus' ? 'All must approve' : 'First wins'
            const lvLabel    = { [ApprovalLevelStatus.Approved]: 'Approved', [ApprovalLevelStatus.Skipped]: 'Skipped', [ApprovalLevelStatus.Pending]: 'Waiting' }[level.status_id] ?? ''

            if (level.user_approver) {
                const assignments = level.assignments ?? []
                const acted       = assignments.find(a => a.status_id === ApprovalAssignmentStatus.Approved || a.status_id === ApprovalAssignmentStatus.Rejected)
                const actedAtHtml = acted?.acted_at ? `<span class="fs-11 text-muted">${acted.acted_at}</span>` : ''
                const notesHtml   = acted?.notes    ? `<p class="mb-0"><span class="d-inline-block mw-100 text-truncate truncate-toggle fst-italic text-muted fs-11" style="cursor:pointer">"${acted.notes}"</span></p>` : ''
                return `<div class="d-flex gap-2 align-items-start ${idx < levels.length - 1 ? 'mb-2' : ''}">
                    <i class="${icon} ${cls} fs-12 flex-shrink-0" title="${title}"></i>
                    <div class="flex-fill overflow-hidden">
                        <div class="d-flex justify-content-between align-items-start gap-1">
                            <span class="fs-12 fw-medium">Lv ${idx + 1}&nbsp;&nbsp;User: ${level.user_approver.name}</span>
                            <div class="d-flex flex-column align-items-end flex-shrink-0">
                                ${lvLabel ? `<span class="fs-11 text-muted">${lvLabel}</span>` : ''}
                                ${actedAtHtml}
                            </div>
                        </div>
                        ${notesHtml}
                    </div>
                </div>`
            }

            const rightTag = (isActive || isRejected)
                ? `<span class="badge bg-secondary-transparent text-secondary fs-10">${modeLabel}</span>`
                : (lvLabel ? `<span class="fs-11 text-muted">${lvLabel}</span>` : '')

            const showAssignments = isActive || isApproved || isRejected
            const assignmentsHtml = showAssignments ? this._levelAssignmentsHtml(level) : ''

            return `<div class="d-flex gap-2 align-items-start ${idx < levels.length - 1 ? 'mb-2' : ''}">
                <i class="${icon} ${cls} fs-12 flex-shrink-0" title="${title}"></i>
                <div class="flex-fill overflow-hidden">
                    <div class="d-flex justify-content-between align-items-center gap-1">
                        <span class="fs-12 fw-medium">Lv ${idx + 1}&nbsp;&nbsp;${approverName}</span>
                        ${rightTag}
                    </div>
                    ${assignmentsHtml}
                </div>
            </div>`
        }).join('')
    }

    _renderRequests(items) {
        this._requestsList.innerHTML = items.map(item => this._requestItemHtml(item)).join('')
        this._requestsEmpty.classList.toggle('d-none', !!items.length)
    }

    _appendRequests(items) {
        if (!items.length) return
        this._requestsList.insertAdjacentHTML('beforeend', items.map(item => this._requestItemHtml(item)).join(''))
    }

    _requestItemHtml(request) {
        const status      = request.status?.name ?? '-'
        const statusColor = this._requestStatusColor(request.status_id)
        const isPending   = request.status_id === ApprovalRequestStatus.Pending
        const levels      = request.levels ?? []

        const descHtml    = request.description ? `<span class="fs-12 text-muted d-block text-truncate truncate-toggle" style="cursor:pointer">${request.description}</span>` : ''
        const subjectHtml = (request.subject_label && request.subject_url)
            ? `<a href="${request.subject_url}" class="fs-12 text-primary d-inline-block mt-1" target="_blank"><i class="ri-external-link-line fs-11"></i> ${request.subject_label}</a>`
            : ''
        const progressLine = this._progressLineHtml(levels)
        const infoText     = this._levelInfoText(request, levels)
        const expandedHtml = this._expandedLevelsHtml(levels)

        const cancelBtn = isPending
            ? `<button class="btn btn-light btn-sm btn-icon text-danger action-cancel" data-id="${request.id}" title="Cancel Request">
                   <i class="ri-close-line fs-14"></i>
               </button>`
            : ''

        return `<li class="px-3 py-3 border-bottom">
            <div class="d-flex justify-content-between align-items-start gap-2">
                <div class="flex-fill overflow-hidden">
                    <p class="fw-medium mb-0 fs-14 text-truncate truncate-toggle" style="cursor:pointer">${request.name ?? '-'}</p>
                    ${descHtml}
                    ${subjectHtml}
                </div>
                <span class="badge bg-${statusColor}-transparent text-${statusColor} flex-shrink-0">${status}</span>
            </div>
            <hr class="my-2">
            <div class="d-flex align-items-center gap-2">
                <div class="d-flex align-items-center flex-shrink-0">${progressLine}</div>
                <span class="fs-12 text-muted text-truncate">${infoText}</span>
            </div>
            <hr class="my-2">
            <div class="d-flex justify-content-between align-items-center">
                <span class="fs-11 text-muted">${request.created_at ?? ''}</span>
                <div class="d-flex gap-1">
                    ${cancelBtn}
                    <button class="btn btn-light btn-sm btn-icon detail-toggle" data-id="${request.id}" title="Show Details">
                        <i class="ri-arrow-down-s-line fs-14"></i>
                    </button>
                </div>
            </div>
            <div id="req_detail_${request.id}" class="d-none mt-2 pt-2 border-top">
                ${expandedHtml}
            </div>
        </li>`
    }

    _requestStatusColor(statusId) {
        const map = {
            [ApprovalRequestStatus.Pending]:    'secondary',
            [ApprovalRequestStatus.InProgress]: 'warning',
            [ApprovalRequestStatus.Approved]:   'success',
            [ApprovalRequestStatus.Rejected]:   'danger',
            [ApprovalRequestStatus.Cancelled]:  'secondary',
            [ApprovalRequestStatus.Expired]:    'secondary',
        }
        return map[statusId] ?? 'secondary'
    }

    _updatePendingBadge(count) {
        if (!this._pendingBadge) return
        if (count > 0) {
            this._pendingBadge.textContent = count
            this._pendingBadge.classList.remove('d-none')
        } else {
            this._pendingBadge.classList.add('d-none')
        }
    }

    _updateRequestsBadge(count) {
        if (!this._requestsBadge) return
        if (count > 0) {
            this._requestsBadge.textContent = count
            this._requestsBadge.classList.remove('d-none')
        } else {
            this._requestsBadge.classList.add('d-none')
        }
    }

    // #endregion

    // #region actions

    _bindPendingActions() {
        this._pendingList.addEventListener('click', (e) => {
            const approve = e.target.closest('.action-approve')
            if (approve) { this._approve(approve.dataset.id); return }
            const reject = e.target.closest('.action-reject')
            if (reject) { this._reject(reject.dataset.id) }
        })
    }

    _bindRequestsActions() {
        this._requestsList.addEventListener('click', (e) => {
            const cancel = e.target.closest('.action-cancel')
            if (cancel) { this._cancel(cancel.dataset.id); return }

            const toggle = e.target.closest('.detail-toggle')
            if (toggle) {
                const panel  = document.getElementById(`req_detail_${toggle.dataset.id}`)
                const icon   = toggle.querySelector('i')
                const isOpen = !panel.classList.contains('d-none')
                panel.classList.toggle('d-none')
                icon.className = isOpen ? 'ri-arrow-down-s-line fs-14' : 'ri-arrow-up-s-line fs-14'
                toggle.title   = isOpen ? 'Show Details' : 'Hide Details'
                return
            }

            const truncate = e.target.closest('.truncate-toggle')
            if (truncate) { truncate.classList.toggle('text-truncate') }
        })
    }

    _bindInfiniteScroll() {
        if (!this._offcanvasBody) return
        this._offcanvasBody.addEventListener('scroll', () => {
            const el = this._offcanvasBody
            if (el.scrollHeight - el.scrollTop - el.clientHeight > 150) return
            if (this._pendingPane?.classList.contains('active')) {
                this._fetchPending(true)
            } else {
                this._fetchRequests(true)
            }
        })
    }

    async _approve(assignmentId, onSuccess = null) {
        const confirmed = await Helper.confirm({ title: 'Approve this request?' })
        if (!confirmed) return

        try {
            await axios.post(`${BASE_URL}/core/approval/approve/${assignmentId}`)
            this.refresh()
            onSuccess?.()
        } catch (e) {
            Helper.toast({ title: 'Error', message: 'Failed to approve request.', color: 'danger', timeout: 4000 })
        }
    }

    async _reject(assignmentId, onSuccess = null) {
        const confirmed = await Helper.confirm({ title: 'Reject this request?' })
        if (!confirmed) return

        this._offcanvas.hide()

        const result = await Swal.fire({
            title: 'Rejection Notes',
            input: 'textarea',
            inputLabel: 'Notes',
            inputPlaceholder: 'Enter rejection reason...',
            showCancelButton: true,
            confirmButtonText: 'Confirm Reject',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-danger me-2 mb-1',
                cancelButton: 'btn btn-secondary mb-1',
            },
            buttonsStyling: false,
            didOpen: () => {
                document.querySelector('.swal2-container')?.removeAttribute('inert')
                Swal.getInput()?.focus()
            },
            preConfirm: (notes) => {
                if (!notes?.trim()) {
                    Swal.showValidationMessage('Notes is required')
                    return false
                }
                return notes
            }
        })

        if (!result.value) return

        try {
            await axios.post(`${BASE_URL}/core/approval/reject/${assignmentId}`, { notes: result.value })
            this.refresh()
            onSuccess?.()
        } catch (e) {
            Helper.toast({ title: 'Error', message: 'Failed to reject request.', color: 'danger', timeout: 4000 })
        }
    }

    async _cancel(requestId) {
        const confirmed = await Helper.confirm({ title: 'Cancel this request?' })
        if (!confirmed) return

        try {
            await axios.delete(`${BASE_URL}/core/approval/cancel/${requestId}`)
            this._fetchRequests()
        } catch (e) {
            Helper.toast({ title: 'Error', message: 'Failed to cancel request.', color: 'danger', timeout: 4000 })
        }
    }

    // #endregion

    // #region broadcast

    _listenBroadcast() {
        if (!USER_ID) return

        Echo.private(`approval-request.${USER_ID}`)
            .listen('.ApprovalRequestedEvent', (event) => {
                this._setPulse(true)
                this._fetchPending()
                this._showApprovalToast(event)
            })

        Echo.private(`approval-status.${USER_ID}`)
            .listen('.ApprovalStatusChangedEvent', () => {
                this._fetchRequests()
            })
    }

    _showApprovalToast(event) {
        const { assignmentId, approvalName, approvalDescription, requesterName } = event

        const bodyHtml = `<div class="toast-body">
            <div class="d-flex flex-column gap-1 mb-2">
                <p class="fw-semibold mb-0">${approvalName}</p>
                ${approvalDescription ? `<span class="text-muted fs-12">${approvalDescription}</span>` : ''}
                <span class="fs-12">Requested by: <strong>${requesterName}</strong></span>
            </div>
            <div class="d-flex gap-2">
                <button class="btn btn-sm btn-wave btn-outline-success toast-approve">Approve</button>
                <button class="btn btn-sm btn-wave btn-outline-danger toast-reject">Reject</button>
            </div>
        </div>`

        const result = Toast.show({
            title:   'Approval Request',
            html:    bodyHtml,
            timeout: null,
        })

        if (!result) return

        const { toast, element } = result

        element.querySelector('.toast-approve').addEventListener('click', () => {
            this._approve(assignmentId, () => toast.hide())
        })

        element.querySelector('.toast-reject').addEventListener('click', () => {
            this._reject(assignmentId, () => toast.hide())
        })
    }

    // #endregion

    _setPulse(active) {
        if (!this._pulse) return
        this._pulse.className = active
            ? 'header-icon-pulse bg-warning rounded pulse pulse-warning'
            : ''
    }

    // #region inline component

    static bindInline() {
        document.querySelectorAll('.inline-approve').forEach(el => {
            const btn = new Button(el)
            btn.on('click', () => {
                const wrapper = el.closest('.solar-approval-inline')
                Approval._inlineApprove(el.dataset.id, wrapper, btn)
            })
        })

        document.querySelectorAll('.inline-reject').forEach(el => {
            const btn = new Button(el)
            btn.on('click', () => {
                const wrapper = el.closest('.solar-approval-inline')
                Approval._inlineReject(el.dataset.id, wrapper, btn)
            })
        })
    }

    static async _inlineApprove(assignmentId, el, btn = null) {
        const confirmed = await Helper.confirm({ title: 'Approve this request?' })
        if (!confirmed) return

        btn?.load()
        try {
            await axios.post(`${BASE_URL}/core/approval/approve/${assignmentId}`)
            const toRemove = el.closest('.card') ?? el
            toRemove.remove()
        } catch (e) {
            btn?.unload()
            Helper.toast({ title: 'Error', message: 'Failed to approve request.', color: 'danger', timeout: 4000 })
        }
    }

    static async _inlineReject(assignmentId, el, btn = null) {
        const confirmed = await Helper.confirm({ title: 'Reject this request?' })
        if (!confirmed) return

        const result = await Swal.fire({
            title: 'Rejection Notes',
            input: 'textarea',
            inputLabel: 'Notes',
            inputPlaceholder: 'Enter rejection reason...',
            showCancelButton: true,
            confirmButtonText: 'Confirm Reject',
            cancelButtonText: 'Cancel',
            customClass: {
                confirmButton: 'btn btn-danger me-2 mb-1',
                cancelButton: 'btn btn-secondary mb-1',
            },
            buttonsStyling: false,
            didOpen: () => {
                document.querySelector('.swal2-container')?.removeAttribute('inert')
                Swal.getInput()?.focus()
            },
            preConfirm: (notes) => {
                if (!notes?.trim()) {
                    Swal.showValidationMessage('Notes is required')
                    return false
                }
                return notes
            }
        })

        if (!result.value) return

        btn?.load()
        try {
            await axios.post(`${BASE_URL}/core/approval/reject/${assignmentId}`, { notes: result.value })
            const toRemove = el.closest('.card') ?? el
            toRemove.remove()
        } catch (e) {
            btn?.unload()
            Helper.toast({ title: 'Error', message: 'Failed to reject request.', color: 'danger', timeout: 4000 })
        }
    }

    // #endregion
}
