import Helper from "./helper"
import SolarComponent from "./solar/solar-component"

const _presets = {
	'iphone-17':         { type: 'iphone',  notch: 'dynamic-island', size: 'lg' },
	'iphone-17-pro':     { type: 'iphone',  notch: 'dynamic-island', size: 'lg' },
	'iphone-16':         { type: 'iphone',  notch: 'dynamic-island', size: 'md' },
	'iphone-16-plus':    { type: 'iphone',  notch: 'dynamic-island', size: 'lg' },
	'iphone-15':         { type: 'iphone',  notch: 'pill',           size: 'md' },
	'iphone-15-pro':     { type: 'iphone',  notch: 'dynamic-island', size: 'lg' },
	'samsung-s25-ultra': { type: 'android', notch: 'punch-hole',     size: 'xl' },
	'samsung-s25':       { type: 'android', notch: 'punch-hole',     size: 'lg' },
	'pixel-9-pro':       { type: 'android', notch: 'punch-hole',     size: 'lg' },
	'pixel-9':           { type: 'android', notch: 'punch-hole',     size: 'lg' },
	'samsung-a55':       { type: 'android', notch: 'punch-hole',     size: 'md' },
	'samsung-a35':       { type: 'android', notch: 'punch-hole',     size: 'md' },
	'samsung-a25':       { type: 'android', notch: 'punch-hole',     size: 'md' },
	'samsung-a15':       { type: 'android', notch: 'bar',            size: 'sm' },
	'samsung-a05':       { type: 'android', notch: 'bar',            size: 'sm' },
}

const _sizeMap = {
	sm: { width: 300, height: 620 },
	md: { width: 320, height: 660 },
	lg: { width: 360, height: 740 },
	xl: { width: 390, height: 780 },
}

const _bezelMap = {
	none: 0,
	xs:   6,
	sm:   10,
	md:   14,
	lg:   20,
}

export default class PhonePreview extends SolarComponent {
	static Device = Object.freeze({
		Iphone17:        'iphone-17',
		Iphone17Pro:     'iphone-17-pro',
		Iphone16:        'iphone-16',
		Iphone16Plus:    'iphone-16-plus',
		Iphone15:        'iphone-15',
		Iphone15Pro:     'iphone-15-pro',
		SamsungS25Ultra: 'samsung-s25-ultra',
		SamsungS25:      'samsung-s25',
		Pixel9Pro:       'pixel-9-pro',
		Pixel9:          'pixel-9',
		SamsungA55:      'samsung-a55',
		SamsungA35:      'samsung-a35',
		SamsungA25:      'samsung-a25',
		SamsungA15:      'samsung-a15',
		SamsungA05:      'samsung-a05',
	})

	static Type = Object.freeze({
		Iphone:  'iphone',
		Android: 'android',
	})

	static Notch = Object.freeze({
		DynamicIsland: 'dynamic-island',
		Pill:          'pill',
		Wide:          'wide',
		PunchHole:     'punch-hole',
		Bar:           'bar',
		None:          'none',
	})

	static Color = Object.freeze({
		Dark:   'dark',
		Light:  'light',
		Silver: 'silver',
		Gold:   'gold',
		Blue:   'blue',
		Purple: 'purple',
	})

	static Size = Object.freeze({
		Sm: 'sm',
		Md: 'md',
		Lg: 'lg',
		Xl: 'xl',
	})

	static Bezel = Object.freeze({
		None: 'none',
		Xs:   'xs',
		Sm:   'sm',
		Md:   'md',
		Lg:   'lg',
	})

	_element     = null
	_id          = null
	_clockTimer  = null

	constructor(selector) {
		super()

		if (selector instanceof HTMLElement) {
			this._element = selector
		} else if (Helper.isString(selector) && !Helper.isEmpty(selector)) {
			this._element = document.querySelector(selector)
			if (!this._element) {
				throw new Error(`Element with query selector ${selector} is not found`)
			}
		} else {
			throw new Error(`Selector is not supported`)
		}

		this._id = this._element.id
		this._startClock()
	}

	_startClock() {
		this._tickClock()
		this._clockTimer = setInterval(() => this._tickClock(), 1000)
	}

	_tickClock() {
		const now  = new Date()
		const h    = now.getHours().toString().padStart(2, '0')
		const m    = now.getMinutes().toString().padStart(2, '0')
		const time = `${h}:${m}`

		this._element.querySelectorAll('.pc-status-time').forEach(el => {
			el.textContent = time
		})
	}

	switchDevice(device) {
		const preset = _presets[device]
		if (!preset) {
			console.warn(`PhonePreview: unknown device "${device}"`)
			return this
		}

		this.setType(preset.type)
		this.setNotch(preset.notch)
		this.setSize(preset.size)

		return this
	}

	setType(type) {
		Object.values(PhonePreview.Type).forEach(t => this._element.classList.remove(`pc-type-${t}`))
		this._element.classList.add(`pc-type-${type}`)
		return this
	}

	setNotch(notch) {
		Object.values(PhonePreview.Notch).forEach(n => this._element.classList.remove(`pc-notch-${n}`))
		this._element.classList.add(`pc-notch-${notch}`)
		return this
	}

	setColor(color) {
		Object.values(PhonePreview.Color).forEach(c => this._element.classList.remove(`pc-color-${c}`))
		this._element.classList.add(`pc-color-${color}`)
		return this
	}

	setSize(size) {
		const dimensions = _sizeMap[size]
		if (!dimensions) {
			console.warn(`PhonePreview: unknown size "${size}"`)
			return this
		}

		this._element.style.setProperty('--pc-width',  `${dimensions.width}px`)
		this._element.style.setProperty('--pc-height', `${dimensions.height}px`)
		return this
	}

	setDimensions(width, height) {
		this._element.style.setProperty('--pc-width',  `${width}px`)
		this._element.style.setProperty('--pc-height', `${height}px`)
		return this
	}

	setBezel(bezel) {
		const px = _bezelMap[bezel] ?? bezel
		this._element.style.setProperty('--pc-bezel', `${px}px`)
		return this
	}

	setScale(scale) {
		this._element.style.setProperty('--pc-scale', scale)
		return this
	}

	destroy() {
		clearInterval(this._clockTimer)
		this._clockTimer = null
		this._element    = null
	}
}
