import Helper from "./helper"
import SolarComponent from "./solar/solar-component"

export default class Tab extends SolarComponent {
    constructor(selector) {
        super()

        if (selector instanceof Element) {
            this._element = selector
        } else if (Helper.isString(selector) && !Helper.isEmpty(selector)) {
            this._element = document.querySelector(selector)
            if (!this._element) {
                throw new Error(`Element with query selector ${selector} is not found`)
            }
        } else {
            throw new Error(`Selector is not supported`)
        }

        this._id = this._element.id
        this._navWrapper = this._element.querySelector("ul.nav.nav-tabs")
        this._contentWrapper = this._element.querySelector("div.tab-content")
    }

    _getNavButton(target) {
        const cleanTarget = target.startsWith("#") ? target : `#${target}`
        return this._navWrapper ? this._navWrapper.querySelector(`button[data-bs-target="${cleanTarget}"]`) : null
    }

    _getTabPane(target) {
        const cleanTarget = target.startsWith("#") ? target : `#${target}`
        return this._contentWrapper ? this._contentWrapper.querySelector(cleanTarget) : null
    }

    _processTargets(targets, callback) {
        const ids = Array.isArray(targets) ? targets : [targets]
        ids.forEach(target => callback(target))
    }

    static supportedEvent() {
        return ["change"]
    }

    on(type, callback, name = null) {
        let oldTabHandler = null
        if (name && this._navWrapper && this._events.has(type)) {
            const existing = this._events.get(type).find(e => e.name === name)
            if (existing) oldTabHandler = existing.tabHandler
        }

        super.on(type, callback, name)

        if (!this._navWrapper) {
            return this
        }

        const events  = this._events.get(type)
        const event   = name ? events.find(e => e.name === name) : events[events.length - 1]
        const buttons = this._navWrapper.querySelectorAll("button.nav-link")

        if (oldTabHandler) {
            buttons.forEach(btn => btn.removeEventListener("shown.bs.tab", oldTabHandler))
        }

        const tabHandler = (e) => {
            const target      = e.target.getAttribute("data-bs-target")
            const cleanTarget = target ? target.replace(/^#/, "") : null
            event.handler(cleanTarget, e)
        }
        event.tabHandler = tabHandler
        buttons.forEach(btn => btn.addEventListener("shown.bs.tab", tabHandler))

        return this
    }

    off(type, callback = null, name = null) {
        if (!this._events.has(type)) {
            return this
        }

        if (this._navWrapper) {
            const events  = this._events.get(type)
            const buttons = this._navWrapper.querySelectorAll("button.nav-link")
            let toRemove

            if (name) {
                toRemove = events.filter(e => e.name === name)
            } else if (callback) {
                toRemove = events.filter(e => e.callback === callback)
            } else {
                toRemove = [...events]
            }

            toRemove.forEach(event => {
                if (event.tabHandler) {
                    buttons.forEach(btn => btn.removeEventListener("shown.bs.tab", event.tabHandler))
                }
            })
        }

        return super.off(type, callback, name)
    }

    /**
     * Get active tab target id
     * @returns {string|null}
     */
    getActive() {
        if (!this._navWrapper) return null

        const activeBtn = this._navWrapper.querySelector("button.nav-link.active")
        if (activeBtn) {
            const target = activeBtn.getAttribute("data-bs-target")
            return target ? target.replace(/^#/, "") : null
        }

        return null
    }

    /**
     * Activate tab by target id
     * @param {string} target 
     * @returns {this}
     */
    setActive(target) {
        const btn = this._getNavButton(target)
        if (!btn) {
            return this
        }

        if (typeof bootstrap !== "undefined" && bootstrap.Tab) {
            const tab = bootstrap.Tab.getOrCreateInstance(btn)
            tab.show()
            return this
        }

        btn.click()
        return this
    }

    /**
     * Show tab nav and content pane
     * @param {string|string[]} targets 
     * @returns {this}
     */
    show(targets) {
        this._processTargets(targets, target => {
            const btn = this._getNavButton(target)
            if (btn) {
                const li = btn.closest("li.nav-item")
                if (li) {
                    li.classList.remove("d-none")
                }
            }

            const pane = this._getTabPane(target)
            if (pane) {
                pane.classList.remove("d-none")
            }
        })

        return this
    }

    /**
     * Hide tab nav and content pane
     * @param {string|string[]} targets 
     * @returns {this}
     */
    hide(targets) {
        this._processTargets(targets, target => {
            const btn = this._getNavButton(target)
            if (btn) {
                const li = btn.closest("li.nav-item")
                if (li) {
                    li.classList.add("d-none")
                }
            }

            const pane = this._getTabPane(target)
            if (pane) {
                pane.classList.add("d-none")
            }
        })

        return this
    }

    /**
     * Disable tab nav
     * @param {string|string[]} targets 
     * @returns {this}
     */
    disable(targets) {
        this._processTargets(targets, target => {
            const btn = this._getNavButton(target)
            if (btn) {
                btn.disabled = true
            }
        })

        return this
    }

    /**
     * Enable tab nav
     * @param {string|string[]} targets 
     * @returns {this}
     */
    enable(targets) {
        this._processTargets(targets, target => {
            const btn = this._getNavButton(target)
            if (btn) {
                btn.disabled = false
            }
        })

        return this
    }

    destroy() {
        this._events.forEach((value, key) => this.off(key))

        this._events = null
        this._element = null
        this._navWrapper = null
        this._contentWrapper = null
    }
}