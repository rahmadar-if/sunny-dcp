const INDENT = "  "

/**
 * Dependency-free colorized JSON renderer. Takes an already-decoded value (object, array,
 * primitive) and returns an HTML string — the caller decides what "no data" means for its
 * context (never captured vs. pruned by retention) and renders that separately.
 */
export default class JsonViewer {

    /**
     * @param {*} value
     * @returns {string}
     */
    static render(value) {
        return `<pre class="json-view">${JsonViewer._renderValue(value, 0)}</pre>`
    }

    /**
     * HTML-escapes plain text for safe embedding — for callers showing raw text (e.g. a
     * truncated preview string) alongside `render()`'s colorized output.
     * @param {string} text
     * @returns {string}
     */
    static escape(text) {
        return JsonViewer._escape(text)
    }

    /**
     * @param {*} value
     * @param {number} depth
     * @returns {string}
     */
    static _renderValue(value, depth) {
        if (value === null || value === undefined) {
            return `<span class="j-muted">null</span>`
        }

        if (Array.isArray(value)) {
            return JsonViewer._renderArray(value, depth)
        }

        if (typeof value === "object") {
            return JsonViewer._renderObject(value, depth)
        }

        if (typeof value === "string") {
            return `<span class="js">${JsonViewer._escape(JSON.stringify(value))}</span>`
        }

        if (typeof value === "number") {
            return `<span class="jn">${value}</span>`
        }

        if (typeof value === "boolean") {
            return `<span class="jb">${value}</span>`
        }

        return JsonViewer._escape(String(value))
    }

    /**
     * @param {Object} value
     * @param {number} depth
     * @returns {string}
     */
    static _renderObject(value, depth) {
        const keys = Object.keys(value)

        if (keys.length === 0) {
            return "{}"
        }

        const inner = INDENT.repeat(depth + 1)
        const outer = INDENT.repeat(depth)

        const lines = keys.map(key => {
            const rendered = JsonViewer._renderValue(value[key], depth + 1)
            return `${inner}<span class="jk">${JsonViewer._escape(JSON.stringify(key))}</span>: ${rendered}`
        })

        return `{\n${lines.join(",\n")}\n${outer}}`
    }

    /**
     * @param {Array<*>} value
     * @param {number} depth
     * @returns {string}
     */
    static _renderArray(value, depth) {
        if (value.length === 0) {
            return "[]"
        }

        const inner = INDENT.repeat(depth + 1)
        const outer = INDENT.repeat(depth)

        const lines = value.map(item => `${inner}${JsonViewer._renderValue(item, depth + 1)}`)

        return `[\n${lines.join(",\n")}\n${outer}]`
    }

    /**
     * @param {string} text
     * @returns {string}
     */
    static _escape(text) {
        return text
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
    }
}
