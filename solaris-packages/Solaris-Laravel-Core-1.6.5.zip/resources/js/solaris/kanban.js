import axios from "@core-js/libs/axios"
import Helper from "./helper"
import SolarComponent from "./solar/solar-component"
import DragDropHelper from "./drag-drop"
import Button from "./button"
import SearchInput from "./form/search-input"
import Folder from "./table/folders"
import Model from "./model"
import Filter from "./filter/filter"

export default class Kanban extends SolarComponent {

    /**
     * @param {HTMLElement|string} selector 
     */
    constructor(selector) {
        super()

        if (selector instanceof HTMLElement) {
            this._element = selector
        } else if (Helper.isString(selector) && !Helper.isEmpty(selector)) {
            this._element = document.querySelector(selector)
            if (!this._element) {
                throw new Error(`Element with query selector ${selector} is not found`)
            }
        } else {
            throw new Error(`Selector is not supported`)
        }

        this.id = this._element.id
        this._wrapper = document.querySelector(`#${this.id}_wrapper`)

        this._preInit()

        if (!this._wrapper.getAttribute("lazy")) {
            this.render()
        }
    }

    static supportedEvent() {
        return [
            "rendering", // when kanban rendering
            "ready", // when kanban first init complete
            "fetching", // before every data fetch, receives the request payload
            "board created", // when a board is first rendered
            "board updated", // when a board total is refreshed
            "card render",
            "card created",
            "card click",
            "card dblclick", // when card double click
            "card contextmenu", // when card right click
            "card sort", // when card move same board
            "card sorted", // when card move same board
            "before-move", // async hook before cross-board move; return false to cancel
            "card move", // when card move diff board
            "card moved", // when card move diff board
            "new", // when new button clicked
            "delete",
            "deleting", // when delete button clicked
            "deleted", // when deleted is success
            "view", // when view action clicked
            "edit", // when edit action clicked
        ]
    }

    async render() {
        Helper.loadingPage(true)
        try {
            await this.trigger("rendering")

            const data = await this._fetchData()
            const boards = data.boards
            const items = data.data

            this._boardColumn = data.board_column

            for (let i = 0; i < boards.length; i++) {
                const board = boards[i]
                await this._renderBoard(board, items[board.id])
            }

            this._handleActionButtons()

            await this.trigger("ready")
        } catch (error) {
            console.error({ error })
            Helper.errorAlert({ title: "Something wrong happen", message: error.toString() })

            throw error
        } finally {
            Helper.loadingPage(false)
        }
    }

    /**
     * @param {string} boardId 
     * @param {*} data 
     * @param {boolean} insertToEnd 
     */
    async addCard(boardId, data, insertToEnd = false) {
        const board = this._boards.get(boardId)
        const boardContent = board.element.querySelector(".kanban-tasks.board-content .simplebar-content")

        await this._renderCard(boardContent, boardId, data, insertToEnd)

        board.total += 1
        board.element.querySelector("span.board-total").textContent = board.total

        this._updateBoardEmptyState(boardId)
    }

    async editCard(boardId, data) {
        const board = this._boards.get(boardId)
        const card = board.items.find(item => item.data.id == data.id)
        card.data = data

        const cardRenders = await this.trigger("card render", data)
        const cardRender = cardRenders ? cardRenders[cardRenders.length - 1] : (data.displayValue?.value ?? "")
        const newCard = this._getRenderCard(cardRender)

        const tpl = document.createElement('template')
        tpl.innerHTML = newCard.trim()
        const newCardEl = tpl.content.firstElementChild

        card.element.replaceWith(newCardEl)
        card.element = newCardEl

        this._handleBoardItemAction(card.element, data)
        this._handleActionDropdown(card.element.querySelector('div.dropdown'))
    }

    /**
     * @param {string} boardId 
     */
    async refresh(boardId = null, resetPage = false) {
        try {
            Helper.loadingPage(true)

            if (this._refreshBtn) {
                this._refreshBtn.disabled()
            }

            const start = !boardId ? 0 : this._boards.get(boardId).start
            const data = await this._fetchData(start, boardId)

            for (let i = 0; i < data.boards.length; i++) {
                const boardData = data.boards[i]
                const board = this._boards.get(boardData.id)
                const boardContent = board.element.querySelector('.kanban-tasks.board-content .simplebar-content')

                if (!boardId || resetPage) {
                    board.start = 0
                    board.items = []
                    Array.from(boardContent.children).forEach(child => {
                        if (!child.classList.contains('kanban-drop-placeholder')) {
                            child.remove()
                        }
                    })
                }

                board.total = boardData.total
                board.element.querySelector("span.board-total").textContent = board.total

                for (let j = 0; j < data.data[boardData.id].length; j++) {
                    const item = data.data[boardData.id][j]
                    await this._renderCard(boardContent, boardData.id, item)
                }

                const placeholder = boardContent.querySelector('.kanban-drop-placeholder')
                if (placeholder) boardContent.appendChild(placeholder)

                this._updateBoardEmptyState(boardData.id)

                if (board.total > board.items.length) {
                    board.viewMoreButton?.classList.remove('d-none')
                } else {
                    board.viewMoreButton?.classList.add('d-none')
                }

                await this.trigger("board updated", boardData.id, board.element, boardData)
            }
        } catch (error) {
            console.error("Failed to refresh kanban data.", { error })
        } finally {
            if (this._refreshBtn) {
                this._refreshBtn.enabled()
            }

            Helper.loadingPage(false)
        }
    }

    /**
     * @param {Filter} filter 
     * @param {boolean} refresh 
     */
    async preFilter(filter = null, refresh = true) {
        this._preFilters = filter

        if (refresh) {
            this._boards.forEach(board => board.start = 0)
            await this.refresh()
        }
    }

    /**
     * @param {string} name
     * @param {Filter} filter 
     * @param {boolean} refresh 
     */
    async filter(name, filter = null, refresh = true) {
        if (!this._filters.has(name)) {
            this._filters.set(name, filter)
        } else {
            if (!filter) {
                this._filters.delete(name)
            } else {
                this._filters.set(name, filter)
            }
        }

        if (refresh) {
            this._boards.forEach(board => board.start = 0)
            await this.refresh()
        }
    }

    async search(keyword) {
        if (this._search) {
            this._search.set(keyword)
        } else {
            this._searchValue = keyword
            this._boards.forEach(board => board.start = 0)
            await this.refresh()
        }
    }

    /**
     * Build the request payload used to fetch kanban data.
     * Exposed so consumers can fetch related data with the exact same filter state.
     * @param {number} start
     * @param {string|null} boardId
     * @returns {Object}
     */
    getParamData(start = 0, boardId = null) {
        return {
            columns: this._columns ?? [],
            start: start,
            length: this._length,
            board_id: boardId,
            search: this._searchValue?.trim().toLowerCase() ?? null,
            pre_filters: this._preFilters?.get(),
            filters: this._getFilters()?.get(),
        }
    }

    /**
     * @param {string} boardId
     * @returns {HTMLElement|null}
     */
    getBoardElement(boardId) {
        return this._boards.get(boardId)?.element ?? null
    }

    /**
     * @returns {string|null}
     */
    getBoardColumn() {
        return this._boardColumn ?? null
    }

    /**
     * @param {string} boardId
     * @param {{ new?: boolean }} config
     */
    setBoard(boardId, config) {
        const board = this._boards.get(boardId)
        if (!board) return this

        if (Object.hasOwn(config, 'new') && board.newButton) {
            board.newButton.classList.toggle('d-none', !config.new)
        }

        if (Object.hasOwn(config, 'draggable')) {
            board.draggable = config.draggable
        }

        if (Object.hasOwn(config, 'droppable')) {
            board.droppable = config.droppable
        }

        return this
    }

    /**
     * @param {string} boardId
     * @param {boolean} show
     */
    toggleNew(boardId, show) {
        return this.setBoard(boardId, { new: show })
    }

    /**
     * @param {string} boardId
     * @param {boolean|string[]} value
     */
    toggleDrag(boardId, value) {
        return this.setBoard(boardId, { draggable: value })
    }

    /**
     * @param {string} boardId
     * @param {boolean|string[]} value
     */
    toggleDrop(boardId, value) {
        return this.setBoard(boardId, { droppable: value })
    }

    _preInit() {
        this._model = this._wrapper.getAttribute("model")
        this._parseModel = Helper.parseShorthandModel(this._model)
        this._columns = this._wrapper.getAttribute("columns")

        this._isNew = this._wrapper.hasAttribute("new")
        this._newLabel = this._wrapper.getAttribute("new")
        this._newIcon = this._wrapper.getAttribute("new-icon")
        const newExcept = this._wrapper.getAttribute("new-except")
        this._newExceptBoards = newExcept ? JSON.parse(newExcept) : []

        const noDragBoards = this._wrapper.getAttribute("no-drag-boards")
        this._noDragBoards = noDragBoards ? JSON.parse(noDragBoards) : []

        const noDropBoards = this._wrapper.getAttribute("no-drop-boards")
        this._noDropBoards = noDropBoards ? JSON.parse(noDropBoards) : []
        this._isView = this._wrapper.hasAttribute("view")
        this._isEdit = this._wrapper.hasAttribute("edit")
        this._isDelete = this._wrapper.hasAttribute("delete")

        this._start = 0
        this._length = this._wrapper.hasAttribute("length") ? parseInt(this._wrapper.getAttribute("length")) : 10

        this._filters = new Map()
        this._preFilters = this._wrapper.hasAttribute("filter") ? new Filter(this._wrapper.getAttribute("filter")) : null

        const folderButton = document.querySelector(`#${this.id}_kanban_folder`)
        if (folderButton) {
            this._folder = new Folder(`${this.id}_kanban_folder`, this._parseModel.model)
            this._folder.on("change", async (filter) => await this.filter("folder", filter), "Kanban")
        }

        const refreshBtn = document.querySelector(`#${this.id}_kanban_refresh`)
        if (refreshBtn) {
            this._refreshBtn = new Button(refreshBtn)
        }

        const searchField = document.querySelector(`#${this.id}_kanban_search`)
        this._searchValue = null
        if (searchField) {
            this._search = new SearchInput(searchField)
        }

        this._boards = new Map()

        this._debounceTimer = null
        this._pendingAction = null

        this._draggedEl = null
        this._dragSourceBoardId = null
        this._initDragDrop()
    }

    /**
     * @param {[{id: string, name: string, color: string|null, total: number}]} data 
     * @param {[*]} items 
     */
    async _renderBoard(data, items) {
        const id = data.id
        const name = data.name
        const color = data.color ?? "primary"
        const total = data.total

        this._boards.set(id, { name, color, total, items: [], simplebar: null })
        this._element.insertAdjacentHTML('beforeend', this._getRenderBoard(id, name, color, total))

        const boardElement = this._element.lastElementChild
        const boardContent = boardElement.querySelector(`.kanban-tasks.board-content`)

        for (let i = 0; i < items.length; i++) {
            await this._renderCard(boardContent, id, items[i])
        }

        const board = this._boards.get(id)
        board.start = 0
        board.element = boardElement
        board.simplebar = new SimpleBar(boardContent, { autoHide: true })

        this._updateBoardEmptyState(id)

        const simplebarContent = boardContent.querySelector('.simplebar-content')
        simplebarContent.appendChild(this._createBoardDropPlaceholder(id))

        board.newButton = boardElement.querySelector("button.new-action") ?? null
        board.viewMoreButton = boardElement.querySelector("button.view-more-action") ?? null
        board.draggable = !this._noDragBoards.includes(id)
        board.droppable = !this._noDropBoards.includes(id)

        if (board.newButton) {
            board.newButton.addEventListener("click", () => this.trigger("new", { id, name }))
        }

        if (board.viewMoreButton) {
            board.viewMoreButton.addEventListener("click", async () => {
                board.start = board.items.length

                await this.refresh(id)
            })

            if (total > board.items.length) {
                board.viewMoreButton?.classList.remove('d-none')
            } else {
                board.viewMoreButton?.classList.add('d-none')
            }
        }

        await this.trigger("board created", id, boardElement, data)
    }

    /**
     * @param {HTMLElement} boardContentElement 
     * @param {string} boardId 
     * @param {*} data 
     * @param {boolean} insertToEnd
     */
    async _renderCard(boardContentElement, boardId, data, insertToEnd = true) {
        const cardRenders = await this.trigger("card render", data)
        const cardRender = cardRenders ? cardRenders[cardRenders.length - 1] : (data.displayValue?.value ?? "")
        boardContentElement.insertAdjacentHTML(insertToEnd ? "beforeend" : "afterbegin", this._getRenderCard(cardRender))

        const newCard = !insertToEnd ? boardContentElement.firstElementChild : boardContentElement.lastElementChild
        this._handleBoardItemAction(newCard, data)
        this._handleActionDropdown(newCard.querySelector('div.dropdown'))

        if (insertToEnd) {
            this._boards.get(boardId).items.push({ data: data, element: newCard })
        } else {
            this._boards.get(boardId).items.unshift({ data: data, element: newCard })
        }

        await this.trigger("card created", newCard, data)
    }

    _handleActionButtons() {
        if (this._refreshBtn) {
            this._refreshBtn.enabled()
            this._refreshBtn.on("click", async () => await this.refresh(), "Kanban")
        }

        this._searchValue = null
        if (this._search) {
            this._search.enabled()
            this._search.on("search", async (keyword) => {
                this._searchValue = keyword
                await this.refresh()
            }, "Kanban")
        }
    }

    /**
     * @param {HTMLElement} cardElement 
     * @param {*} data 
     */
    _handleBoardItemAction(cardElement, data) {
        if (this._isView) {
            cardElement
                .querySelector('.view-action')
                .addEventListener('click', async () => await this.trigger("view", data))
        }

        if (this._isEdit) {
            cardElement
                .querySelector('.edit-action')
                .addEventListener('click', async () => await this.trigger("edit", data))
        }

        if (this._isDelete) {
            cardElement
                .querySelector('.delete-action')
                .addEventListener('click', async () => await this._delete(cardElement, data.id))
        }
    }

    /**
     * @param {HTMLElement} dropdownElement 
     */
    _handleActionDropdown(dropdownElement) {
        if (!dropdownElement) return

        dropdownElement.addEventListener('show.bs.dropdown', (event) => {
            const boardElem = dropdownElement.closest('div.kanban-tasks.board-content')
            const simpleabrWrap = dropdownElement.closest('div.simplebar-content-wrapper')
            const dropdownItem = dropdownElement.querySelector('ul')

            let boardHeight = getComputedStyle(boardElem, null).height
            boardHeight = parseFloat(boardHeight.substring(0, boardHeight.length - 2))

            const dropdownHeight = 40 * (dropdownItem.children.length) + 70
            if (dropdownHeight > boardHeight) {
                boardElem.style.paddingBottom = dropdownHeight + 'px'
                simpleabrWrap.style.paddingBottom = dropdownHeight + 'px'
            }
        })

        dropdownElement.addEventListener('hide.bs.dropdown', (event) => {
            const boardElem = dropdownElement.closest('div.kanban-tasks.board-content')
            const simpleabrWrap = dropdownElement.closest('div.simplebar-content-wrapper')

            boardElem.style.paddingBottom = ""
            simpleabrWrap.style.paddingBottom = ""
        })
    }

    _canDrop(sourceBoardId, targetBoardId) {
        if (sourceBoardId === targetBoardId) return true

        const src = this._boards.get(sourceBoardId)
        const tgt = this._boards.get(targetBoardId)
        if (!src || !tgt) return false

        const draggable = src.draggable ?? true
        if (draggable === false) return false
        if (Array.isArray(draggable) && !draggable.includes(targetBoardId)) return false

        const droppable = tgt.droppable ?? true
        if (droppable === false) return false
        if (Array.isArray(droppable) && !droppable.includes(sourceBoardId)) return false

        return true
    }

    _initDragDrop() {
        this._dnd = new DragDropHelper(this._element, {
            draggable: '.card.custom-card',
            dropZone: '.card.custom-card',
            zones: true,
            thresholds: { before: 0.5, after: 0.5 }
        })
        .on('start', this._onDnd_Start.bind(this), "Kanban")
        .on('end', this._onDnd_End.bind(this), "Kanban")
        .on('over', this._onDnd_Over.bind(this), "Kanban")
        .on('leave', this._onDnd_Leave.bind(this), "Kanban")
        .on('drop', this._onDnd_Drop.bind(this), "Kanban")
    }

    _onDnd_Start(e, dragEl) {
        const boardEl = dragEl.closest('.kanban-tasks-type')
        this._dragSourceBoardId = boardEl?.getAttribute('data-id')
        this._draggedEl = dragEl
        setTimeout(() => dragEl.classList.add('dragging'), 0)

        this._boards.forEach((board, boardId) => {
            if (!this._canDrop(this._dragSourceBoardId, boardId)) {
                board.element.classList.add('board-restricted')
            }
        })
    }

    _onDnd_End(e, dragEl) {
        dragEl?.classList.remove('dragging')
        this._draggedEl = null
        this._dragSourceBoardId = null
        this._clearDropIndicators()

        this._boards.forEach(board => {
            board.element.classList.remove('board-restricted', 'board-drop-forbidden')
        })
    }

    _onDnd_Over(e, dragEl, targetEl, zone) {
        if (dragEl === targetEl) return

        const targetBoardEl = targetEl.closest('.kanban-tasks-type')
        const targetBoardId = targetBoardEl?.getAttribute('data-id')

        if (!this._canDrop(this._dragSourceBoardId, targetBoardId)) {
            this._clearDropIndicators()
            e.dataTransfer.dropEffect = 'none'
            targetBoardEl?.classList.add('board-drop-forbidden')
            return
        }

        this._boards.forEach(board => board.element.classList.remove('board-drop-forbidden'))
        this._clearDropIndicators()
        targetEl.classList.add(zone === 'before' ? 'drop-before' : 'drop-after')
    }

    _onDnd_Leave(e, dragEl, targetEl) {
        targetEl.classList.remove('drop-before', 'drop-after')
        targetEl.closest('.kanban-tasks-type')?.classList.remove('board-drop-forbidden')
    }

    async _onDnd_Drop(e, dragEl, targetEl, zone) {
        if (dragEl === targetEl) return
        this._clearDropIndicators()

        const effectiveZone = (zone === 'before') ? 'before' : 'after'
        const sourceBoardId = this._dragSourceBoardId
        const targetBoardEl = targetEl.closest('.kanban-tasks-type')
        const targetBoardId = targetBoardEl?.getAttribute('data-id')
        if (!sourceBoardId || !targetBoardId) return
        if (!this._canDrop(sourceBoardId, targetBoardId)) return

        const sourceBoard = this._boards.get(sourceBoardId)
        const targetBoard = this._boards.get(targetBoardId)

        const oldIndex = sourceBoard.items.findIndex(i => i.element === dragEl)
        if (oldIndex === -1) return
        const draggedItem = sourceBoard.items[oldIndex]

        const targetIndex = targetBoard.items.findIndex(i => i.element === targetEl)
        if (targetIndex === -1) return

        if (sourceBoardId !== targetBoardId) {
            const beforeResults = await this.trigger('before-move', dragEl, draggedItem.data, { old: sourceBoardId, new: targetBoardId })
            if (beforeResults?.some(r => r === false)) return
        }

        const refEl = effectiveZone === 'before' ? targetEl : targetEl.nextSibling
        const targetSimplebarContent = targetEl.closest('.simplebar-content')
        targetSimplebarContent.insertBefore(dragEl, refEl)

        let newIndex = effectiveZone === 'before' ? targetIndex : targetIndex + 1
        const sameBoard = sourceBoardId === targetBoardId

        if (sameBoard) {
            sourceBoard.items.splice(oldIndex, 1)
            if (oldIndex < newIndex) newIndex--
            sourceBoard.items.splice(newIndex, 0, draggedItem)
            sourceBoard.simplebar.recalculate()

            const prevItem = newIndex > 0 ? sourceBoard.items[newIndex - 1] : null
            const nextItem = newIndex < sourceBoard.items.length - 1 ? sourceBoard.items[newIndex + 1] : null

            this.trigger('card sort', dragEl, draggedItem.data, sourceBoardId)
            this._scheduleAction({
                type: 'sort', element: dragEl, data: draggedItem.data,
                prevItem, nextItem, boardId: sourceBoardId
            })
        } else {
            const sourceBoardDomEl = this._element.querySelector(`[data-id="${sourceBoardId}"]`)

            sourceBoard.items.splice(oldIndex, 1)
            draggedItem.data[this._boardColumn] = targetBoardId
            targetBoard.items.splice(newIndex, 0, draggedItem)

            sourceBoard.total -= 1
            sourceBoardDomEl.querySelector('span.board-total').textContent = sourceBoard.total

            targetBoard.total += 1
            targetBoardEl.querySelector('span.board-total').textContent = targetBoard.total

            if (sourceBoard.viewMoreButton) {
                sourceBoard.viewMoreButton.classList.toggle('d-none', !(sourceBoard.total > sourceBoard.items.length))
            }
            if (targetBoard.viewMoreButton) {
                targetBoard.viewMoreButton.classList.toggle('d-none', !(targetBoard.total > targetBoard.items.length))
            }

            sourceBoard.simplebar.recalculate()
            targetBoard.simplebar.recalculate()

            this._updateBoardEmptyState(sourceBoardId)
            this._updateBoardEmptyState(targetBoardId)

            const prevItem = newIndex > 0 ? targetBoard.items[newIndex - 1] : null
            const nextItem = newIndex < targetBoard.items.length - 1 ? targetBoard.items[newIndex + 1] : null

            this.trigger('card move', dragEl, draggedItem.data, { old: sourceBoardId, new: targetBoardId })
            this._scheduleAction({
                type: 'move', element: dragEl, data: draggedItem.data,
                prevItem, nextItem, boardId: { old: sourceBoardId, new: targetBoardId }
            })
        }
    }

    _scheduleAction(action) {
        clearTimeout(this._debounceTimer)
        this._pendingAction = action
        this._debounceTimer = setTimeout(async () => {
            if (!this._pendingAction) return
            await this._commitPendingAction()
        }, 350)
    }

    _createBoardDropPlaceholder(boardId) {
        const placeholder = document.createElement('div')
        placeholder.className = 'kanban-drop-placeholder'
        placeholder.textContent = 'Drop here'

        placeholder.addEventListener('dragover', (e) => {
            e.preventDefault()
            if (!this._draggedEl) return
            if (!this._canDrop(this._dragSourceBoardId, boardId)) {
                e.dataTransfer.dropEffect = 'none'
                placeholder.closest('.kanban-tasks-type')?.classList.add('board-drop-forbidden')
                return
            }
            placeholder.classList.add('drag-over')
        })
        placeholder.addEventListener('dragleave', () => {
            placeholder.classList.remove('drag-over')
            placeholder.closest('.kanban-tasks-type')?.classList.remove('board-drop-forbidden')
        })
        placeholder.addEventListener('drop', async (e) => {
            e.preventDefault()
            placeholder.classList.remove('drag-over')
            if (!this._draggedEl) return
            if (!this._canDrop(this._dragSourceBoardId, boardId)) return
            await this._dropToBoard(this._draggedEl, boardId)
        })

        return placeholder
    }

    async _dropToBoard(dragEl, targetBoardId) {
        this._clearDropIndicators()
        const sourceBoardId = this._dragSourceBoardId
        if (!sourceBoardId || !targetBoardId) return
        if (!this._canDrop(sourceBoardId, targetBoardId)) return

        const sourceBoard = this._boards.get(sourceBoardId)
        const targetBoard = this._boards.get(targetBoardId)

        const oldIndex = sourceBoard.items.findIndex(i => i.element === dragEl)
        if (oldIndex === -1) return
        const draggedItem = sourceBoard.items[oldIndex]

        if (sourceBoardId !== targetBoardId) {
            const beforeResults = await this.trigger('before-move', dragEl, draggedItem.data, { old: sourceBoardId, new: targetBoardId })
            if (beforeResults?.some(r => r === false)) return
        }

        const targetBoardEl = this._element.querySelector(`[data-id="${targetBoardId}"]`)
        const targetSimplebarContent = targetBoardEl.querySelector('.simplebar-content')
        const placeholder = targetSimplebarContent.querySelector('.kanban-drop-placeholder')

        targetSimplebarContent.insertBefore(dragEl, placeholder)

        sourceBoard.items.splice(oldIndex, 1)
        const newIndex = targetBoard.items.length

        if (sourceBoardId !== targetBoardId) {
            draggedItem.data[this._boardColumn] = targetBoardId
            const sourceBoardDomEl = this._element.querySelector(`[data-id="${sourceBoardId}"]`)
            sourceBoard.total -= 1
            sourceBoardDomEl.querySelector('span.board-total').textContent = sourceBoard.total
            targetBoard.total += 1
            targetBoardEl.querySelector('span.board-total').textContent = targetBoard.total

            if (sourceBoard.viewMoreButton) {
                sourceBoard.viewMoreButton.classList.toggle('d-none', !(sourceBoard.total > sourceBoard.items.length))
            }
            if (targetBoard.viewMoreButton) {
                targetBoard.viewMoreButton.classList.toggle('d-none', !(targetBoard.total > targetBoard.items.length))
            }

            sourceBoard.simplebar.recalculate()
            targetBoard.simplebar.recalculate()

            this._updateBoardEmptyState(sourceBoardId)
            this._updateBoardEmptyState(targetBoardId)
        }

        targetBoard.items.push(draggedItem)

        const prevItem = newIndex > 0 ? targetBoard.items[newIndex - 1] : null

        const eventName = sourceBoardId === targetBoardId ? 'card sort' : 'card move'
        const boardId = sourceBoardId === targetBoardId ? sourceBoardId : { old: sourceBoardId, new: targetBoardId }
        this.trigger(eventName, dragEl, draggedItem.data, boardId)
        this._scheduleAction({
            type: sourceBoardId === targetBoardId ? 'sort' : 'move',
            element: dragEl, data: draggedItem.data,
            prevItem, nextItem: null, boardId
        })
    }

    _clearDropIndicators() {
        this._element.querySelectorAll('.drop-before, .drop-after, .drag-over')
            .forEach(el => el.classList.remove('drop-before', 'drop-after', 'drag-over'))
    }

    async _commitPendingAction() {
        const action = this._pendingAction
        this._pendingAction = null

        if (!action) {
            return
        }

        if (action.type === "sort") {
            await this._move(action.type, action.data.id, null, action.prevItem?.data.id, action.nextItem?.data.id)
            await this.trigger("card sorted", action.element, action.data, action.boardId)
            return
        }

        if (action.type === "move") {
            await this._move(action.type, action.data.id, action.boardId.new, action.prevItem?.data.id, action.nextItem?.data.id)
            await this.trigger("card moved", action.element, action.data, action.boardId)
            return
        }
    }

    /**
     * @param {string} id 
     * @param {string} name 
     * @param {string} color 
     * @param {number} total 
     * @returns {string}
     */
    _getRenderBoard(id, name, color, total) {
        const newHidden = this._newExceptBoards.includes(id)
        return `<div class="kanban-tasks-type kanban-${color}" id="${this.id}_${id}" data-id="${id}">
            <div class="pe-3 mb-3 board-header">
                <div class="px-3 py-2 bg-${color}-transparent border border-${color} border-opacity-25 rounded">
                    <div class="d-flex justify-content-between align-items-center">
                        <div class="d-flex align-items-center gap-2">
                            <span class="d-block fw-medium fs-15">${name}</span>
                            <span class="badge badge-task bg-${color} board-total">${total}</span>
                        </div>

                        ${this._newLabel ?
                `<button type="button" class="btn btn-sm btn-outline-${color} btn-wave new-action${newHidden ? ' d-none' : ''}">
                                <i class="${this._newIcon} align-middle me-1 fw-medium"></i>${this._newLabel}
                            </button>` : ''}
                    </div>

                    <div class="board-summary d-none"></div>
                </div>
            </div>
            <div class="kanban-tasks board-content"></div>
            <div class="d-flex view-more-button mt-3 align-items-center board-footer">
                <button type="button" class="btn btn-primary-light btn-wave flex-fill view-more-action">View More</button>
            </div>
        </div>`
    }

    /**
     * @param {{label: string, body: string, footer: string}|string} content 
     * @returns {string}
     */
    _getRenderCard(content) {
        const isObject = Helper.isObject(content)
        const isLabelExists = isObject && content.hasOwnProperty('label')
        const isBodyExists = isObject && content.hasOwnProperty('body')
        const label = isLabelExists ? content.label : ''
        const body = isBodyExists ? content.body : (content ?? '')
        const footer = isObject && content.hasOwnProperty('footer') ? content.footer : ''

        const header = `<div class="d-flex align-items-start justify-content-between mb-3">
            <div class="task-badges">${isLabelExists ? label : (!isBodyExists ? body : '')}</div>

            ${this._isView || this._isEdit || this._isDelete ?
                `<div class="dropdown">
                    <button class="btn btn-sm btn-light" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="ri-more-2-fill"></i>
                    </button>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                        ${this._isView ? '<li><a class="dropdown-item view-action" href="javascript:void(0);">View</a></li>' : ''}
                        ${this._isEdit ? '<li><a class="dropdown-item edit-action" href="javascript:void(0);">Edit</a></li>' : ''}
                        ${this._isDelete ? '<li><a class="dropdown-item delete-action" href="javascript:void(0);">Delete</a></li>' : ''}
                    </ul>
                </div>` : ''}
        </div>`

        return `<div class="card custom-card" draggable="true">
            <div class="card-body">
                ${header}
                ${isBodyExists ? body : ''}
            </div>
            ${footer ? `<div class="p-3 border-top border-block-start-dashed">${footer}</div>` : ''}
        </div>`
    }

    /**
     * @param {number} start 
     * @param {string} type 
     * @returns {Promise<{
     *  boards: [{id: string, name: string, color: string, total: number}],
     *  data: {*}
     * }>}
     */
    async _fetchData(start = 0, boardId = null) {
        const params = this.getParamData(start, boardId)

        await this.trigger("fetching", params)

        try {
            const req = await axios({
                method: "POST",
                url: `${BASE_URL}/core/kanban`,
                data: params,
                headers: {
                    "X-Model": this._model
                }
            })

            return req.data
        } catch (error) {
            console.error("Failed to fetch data:", { error })
            throw error
        }
    }

    async _move(type, id, newBoardId, prevId, nextId) {
        try {
            await axios({
                method: "PUT",
                url: `${BASE_URL}/core/kanban/${id}`,
                data: {
                    type: type,
                    prev_id: prevId ?? null,
                    next_id: nextId ?? null,
                    board_id: newBoardId
                },
                headers: {
                    "X-Model": this._model
                }
            })
        } catch (error) {
            console.error("Failed to move:", { error })
        }
    }

    async _delete(cardElement, id) {
        try {
            const boardElem = cardElement.closest('div.kanban-tasks-type')
            const boardId = boardElem.getAttribute("data-id")
            const board = this._boards.get(boardId)
            const cardIndex = board.items.findIndex(item => item.data.id == id)
            const boardItem = board.items[cardIndex]
            const data = boardItem.data

            await this.trigger("deleting", cardElement, data)

            const model = this._parseModel.model
            if (await Model.delete(model, data.id)) {
                board.total -= 1

                boardElem.querySelector("span.board-total").textContent = board.total

                cardElement.remove()
                board.items.splice(cardIndex, 1)

                this._updateBoardEmptyState(boardId)

                await this.trigger("deleted", data, boardId)

                // await this.refresh()
            }
        } catch (error) {
            console.error("Something wrong happen when delete record...", { error })
        }
    }

    _updateBoardEmptyState(boardId) {
        const board = this._boards.get(boardId)
        board.element.classList.toggle('board-is-empty', board.items.length === 0)
    }

    _getFilters() {
        if (this._filters.size === 0) {
            return null
        }

        const filters = new Filter()
        this._filters.forEach((filter, key) => {
            if (filter && !filter.isEmpty()) {
                filters.group(() => filter)
            }
        })

        return filters
    }
}