import { AxiosError } from "axios"
import axios from "@core-js/libs/axios"
import Helper from "./helper"

const url = `${BASE_URL}/core/form`

export default class Model {
    static async get(modelName, id) {
        if (!Helper.isString(modelName) || Helper.isEmpty(modelName)) {
            throw new Error("Model must be string and cannot empty")
        }

        if (!Helper.isString(id) || Helper.isEmpty(id)) {
            throw new Error("Id must be string and cannot empty")
        }

        try {
            const req = await axios({
                method: "GET",
                url: `${url}/${id}`,
                headers: {
                    'X-Model': modelName
                }
            })

            return req.data
        } catch (error) {
            console.error({ error })
        }

        return null
    }

    static async getList(endpoint, { search, orderBy = 'created_at', direction = 'desc', page = 1, length = 10 }) {
        if (!Helper.isString(endpoint) || Helper.isEmpty(endpoint)) {
            throw new Error("Endpoint must be string and cannot empty")
        }

        if (!Helper.isString(id) || Helper.isEmpty(id)) {
            throw new Error("Id must be string and cannot empty")
        }

        try {
            const req = await axios({
                method: "GET",
                url: `${url}`,
                data: {
                    search: search,
                    orderBy: orderBy,
                    direction: direction,
                    page: page,
                    length: length
                }
            })

            return req.data
        } catch (error) {
            console.error({ error })
        }

        return []
    }

    static async create(modelName, data) {
        if (!Helper.isString(modelName) || Helper.isEmpty(modelName)) {
            throw new Error("Model must be string and cannot empty")
        }

        if (!Helper.isObject(data)) {
            throw new Error("Data must be object")
        }

        try {
            const req = await axios({
                method: "POST",
                url: `${url}`,
                data: data,
                headers: {
                    'X-Model': modelName
                }
            })

            return req.data
        } catch (error) {
            console.error({ error })

            throw error
        }
    }

    static async update(modelName, id, data) {
        if (!Helper.isString(modelName) || Helper.isEmpty(modelName)) {
            throw new Error("Model must be string and cannot empty")
        }

        if (!Helper.isString(id) || Helper.isEmpty(id)) {
            throw new Error("Id must be string and cannot empty")
        }

        if (!Helper.isObject(data)) {
            throw new Error("Data must be object")
        }

        try {
            const req = await axios({
                method: "PUT",
                url: `${url}/${id}`,
                data: data,
                headers: {
                    'X-Model': modelName
                }
            })

            return req.data
        } catch (error) {
            console.error({ error })

            throw error
        }

    }

    static async delete(modelName, id, config = null) {
        if (!Helper.isString(modelName) || Helper.isEmpty(modelName)) {
            throw new Error("Model must be string and cannot empty")
        }

        if (!Helper.isString(id) || Helper.isEmpty(id)) {
            throw new Error("Id must be string and cannot empty")
        }

        const conf = config
        const confirm = conf?.confirm ?? true
        const confirmMessage = conf?.message ?? "Are you sure?"
        const successMessage = conf?.success ?? "Delete data successfully"
        const errorMessage = conf?.error ?? "Oops! There was an error"
        const loading = conf?.loading ?? true

        if (typeof confirm !== 'boolean') {
            throw new Error("Confirm must be boolean")
        }

        if (confirm) {
            const conf = await Helper.confirmDelete({ title: confirmMessage })
            if (!conf) {
                return null
            }
        }

        if (loading) {
            Helper.loadingPage(true)
        }

        try {
            const req = await axios({
                method: "DELETE",
                url: `${url}/${id}`,
                headers: {
                    'X-Model': modelName
                }
            })
            const res = req.data
            if (res.success && !Helper.isEmpty(successMessage)) {
                Helper.successAlert({ title: successMessage })
            }

            if (!res.success) {
                Helper.errorAlert({ title: errorMessage, message: res.message, timeout: null })
            }

            return res.success
        } catch (e) {
            console.error({ e })

            if (!Helper.isEmpty(errorMessage)) {
                const eMessage = e instanceof AxiosError ? e.response?.data?.message : e
                Helper.errorAlert({ title: errorMessage, message: eMessage, timeout: null })
            }

            throw e
        } finally {
            if (loading) {
                Helper.loadingPage(false)
            }
        }
    }
}