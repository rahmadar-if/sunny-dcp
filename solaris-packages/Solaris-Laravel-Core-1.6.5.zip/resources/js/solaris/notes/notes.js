import Quill from 'quill'
import DropzoneUpload from '../dropzone'
import Helper from '../helper'
import SolarComponent from '../solar/solar-component'
import './video-blot'
import FileHelper from '../file-helper'

const _FontStyle = Quill.import('attributors/style/font')
_FontStyle.whitelist = [
	'Poppins', 'PT Serif', 'DejaVu Sans', 'DejaVu Serif', 'DejaVu Sans Mono',
	'Times New Roman', 'Arial', 'Calibri', 'Courier New', 'Georgia',
]
Quill.register(_FontStyle, true)

export default class Notes extends SolarComponent {
	_element      = null
	_id           = null
	_bindTo       = null
	_editor       = null
	_lazy         = false
	_url          = null
	_recordId     = null
	_model        = null
	_column       = null
	_pdfFilename  = 'notes.pdf'

	// #region Static

	static supportedEvent() {
		return []
	}

	// #endregion

	// #region Lifecycle

	/**
	 * @param {Element|string} selector
	 */
	constructor(selector) {
		super()

		if (selector instanceof Element) {
			this._element = selector
		} else if (Helper.isString(selector) && !Helper.isEmpty(selector)) {
			this._element = document.querySelector(selector)
			if (!this._element) {
				throw new Error(`Element with query selector ${selector} is not found`)
			}
		} else {
			throw new Error(`Selector is not supported`)
		}

		this._id          = this._element.id
		this._lazy        = this._element.hasAttribute('lazy')
		this._bindTo      = this._element.getAttribute('solar-bind')
		this._url         = `${BASE_URL}/core/attachment`
		this._recordId    = this._element.getAttribute('record-id') ?? null
		this._model       = this._element.getAttribute('model') ?? null
		this._column      = this._element.getAttribute('column') ?? null
		this._pdfFilename = this._element.getAttribute('pdf-filename') ?? 'notes.pdf'

		if (Helper.isEmpty(this._bindTo)) {
			this._bindTo = this._id
		}

		if (!this._lazy) {
			this.init()
		}
	}

	init() {
		const toolbarGroups = [
			[{ 'header': [1, 2, 3, 4, 5, 6, false] }],
			[{ 'font': [] }],
			['bold', 'italic', 'underline', 'strike'],
			['blockquote', 'code-block'],
			[{ 'header': 1 }, { 'header': 2 }],
			[{ 'list': 'ordered' }, { 'list': 'bullet' }],
			[{ 'script': 'sub' }, { 'script': 'super' }],
			[{ 'indent': '-1' }, { 'indent': '+1' }],
			[{ 'size': ['small', false, 'large', 'huge'] }],
			[{ 'color': [] }, { 'background': [] }],
			[{ 'align': [] }],
			['image', 'video'],
			['clean'],
		]

		this._editor = new Quill(this._element.querySelector(`#${this._id}_editor`), {
			theme: 'snow',
			modules: {
				toolbar: toolbarGroups
			}
		})

		const toolbar = this._editor.getModule('toolbar')
		toolbar.addHandler('image', () => this._mediaHandler('image', 'image/*'))
		toolbar.addHandler('video', () => this._mediaHandler('video', 'video/mp4,video/webm,video/ogg'))

		const pdfBtn = document.createElement('button')
		pdfBtn.type      = 'button'
		pdfBtn.className = 'ql-export-pdf'
		pdfBtn.innerHTML = '<i class="bi bi-file-pdf"></i>'
		pdfBtn.title     = 'Export PDF'
		pdfBtn.addEventListener('click', () => this._exportPdfHandler())

		const lastGroup = toolbar.container.lastElementChild
		if (lastGroup) {
			lastGroup.appendChild(pdfBtn)
		} else {
			toolbar.container.appendChild(pdfBtn)
		}

		const value = this._element.querySelector(`#${this._id}_value`)
		if (value) {
			this._editor.root.innerHTML = value.innerHTML
			value.remove()
		}
	}

	// #endregion

	// #region Public API

	/**
	 * @returns {import('quill').Delta|null}
	 */
	get() {
		return this._editor?.getContents() ?? null
	}

	/**
	 * @returns {string}
	 */
	getJson() {
		return this.isEmpty() ? '' : JSON.stringify(this.get())
	}

	/**
	 * @returns {boolean}
	 */
	isEmpty() {
		return this._editor?.getText().trim().length === 0
	}

	/**
	 * @returns {string|null}
	 */
	getRaw() {
		return this._editor?.root.innerHTML ?? null
	}

	/**
	 * @param {Object|string|null} delta
	 */
	set(delta) {
		if (Helper.isEmpty(delta)) {
			this._editor.setContents([{ insert: '\n' }])
			return
		}

		if (Helper.isString(delta)) {
			try {
				delta = JSON.parse(delta)
			} catch (error) {
				this._editor.root.innerHTML = delta
				return
			}
		}

		if (!Helper.isObject(delta)) {
			throw new Error('Content must be object')
		}

		this._editor.setContents(delta)
	}

	reset() {
		this.set(null)
	}

	/**
	 * @returns {boolean}
	 */
	isDisabled() {
		return !this._editor.isEnabled()
	}

	disabled() {
		this._editor.enable(false)
	}

	enabled() {
		this._editor.enable()
	}

	/**
	 * @param {string} value
	 * @returns {Notes}
	 */
	setRecordId(value) {
		this._recordId = value
		return this
	}

	/**
	 * @param {string} value
	 * @returns {Notes}
	 */
	setModel(value) {
		this._model = value
		return this
	}

	/**
	 * @param {string} value
	 * @returns {Notes}
	 */
	setColumn(value) {
		this._column = value
		return this
	}

	/**
	 * @param {string} value
	 * @returns {Notes}
	 */
	setPdfFilename(value) {
		this._pdfFilename = value
		return this
	}

	/**
	 * @returns {Promise<void>}
	 */
	async exportPdf() {
		await this._exportPdfHandler()
	}

	// #endregion

	// #region Upload

	/**
	 * @param {string} embedType
	 * @param {string} accept
	 * @returns {void}
	 */
	_mediaHandler(embedType, accept) {
		const input = document.createElement('input')
		input.setAttribute('type', 'file')
		input.setAttribute('accept', accept)
		input.click()

		input.onchange = async () => {
			const file = input.files[0]
			if (!file) {
				return
			}

			Helper.loadingPage(true)
			try {
				const id    = await this._upload(file)
				const range = this._editor.getSelection(true)
				this._editor.insertEmbed(range.index, embedType, `${BASE_URL}/core/attachment/preview-media/${id}`)
			} catch (error) {
				Helper.errorAlert({ title: 'Upload failed', message: error })
			} finally {
				Helper.loadingPage(false)
			}
		}
	}

	/**
	 * @param {File} file
	 * @returns {Promise<string>}
	 */
	_upload(file) {
		return new Promise((resolve, reject) => {
			const dz = DropzoneUpload.createHidden({
				url:      this._url,
				model:    this._model,
				recordId: this._recordId,
			})

			dz.on('success', (dzFile, response) => {
				dz.destroy()
				if (!response.success) {
					reject(response.message)
					return
				}
				resolve(response.data.id)
			})

			dz.on('error', (dzFile, message) => {
				dz.destroy()
				reject(message?.message ?? message)
			})

			dz.addFile(file)
		})
	}

	// #endregion

	// #region Export PDF

	/**
	 * @returns {Promise<void>}
	 */
	async _exportPdfHandler() {
		if (this.isEmpty()) {
			Helper.errorAlert({ title: 'Export PDF', message: 'Notes is empty.' })
			return
		}

		if (!this._model || !this._column || !this._recordId) {
			Helper.errorAlert({ title: 'Export PDF', message: 'Notes is not bound to a record yet.' })
			return
		}

		const body = { model: this._model, column: this._column, id: this._recordId, filename: this._pdfFilename, type: 'notes' }

		Helper.loadingPage(true)
		try {
			await FileHelper.downloadFile(`${BASE_URL}/core/html-to-pdf`, 'POST', {
				headers: { Accept: 'application/pdf' },
				data:    body,
			})
		} catch (error) {
			if (!error?.response) {
				Helper.errorAlert({ title: 'Export PDF failed', message: error?.message ?? error })
			}
		} finally {
			Helper.loadingPage(false)
		}
	}

	// #endregion
}
