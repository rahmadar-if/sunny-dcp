import Quill from 'quill'

const BlockEmbed = Quill.import('blots/block/embed')

class VideoBlot extends BlockEmbed {
	/**
	 * @param {string} url
	 * @returns {HTMLVideoElement}
	 */
	static create(url) {
		const node = super.create()
		node.setAttribute('src', url)
		node.setAttribute('controls', '')
		node.style.maxWidth = '100%'
		return node
	}

	/**
	 * @param {HTMLVideoElement} node
	 * @returns {string}
	 */
	static value(node) {
		return node.getAttribute('src')
	}
}

VideoBlot.blotName = 'video'
VideoBlot.tagName  = 'video'

Quill.register(VideoBlot, true)

export default VideoBlot
