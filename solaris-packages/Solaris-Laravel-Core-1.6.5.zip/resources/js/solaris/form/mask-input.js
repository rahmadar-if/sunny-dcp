import Cleave from "../../libs/cleave"
import Helper from "../helper"
import BaseInput from "./base-input"

export default class MaskInput extends BaseInput {
    constructor(selector, config = null) {
        super(selector)
        this._config = config

        if(!this._lazy) {
            this.init()
        }
    }

    init(config = null) {
        if(!config) {
            config = {}
        }

        const phone     = this._element.getAttribute("phone")
        this._isNumber  = this._element.getAttribute("number") ? true : false

        if(this._isNumber) {
            const thousandSeparator = this._element.getAttribute("thousand-separator")
            const decimalSeparator  = this._element.getAttribute("decimal-separator")
            
            const decimal   = parseInt(this._element.getAttribute("decimal")) || 2
            this._isInteger = decimal == 0
            this._isDecimal = decimal > 0

            config.numeral                      = true
            config.delimiter                    = thousandSeparator
            config.numeralDecimalMark           = decimalSeparator
            config.numeralDecimalScale          = decimal
            config.rawValueTrimPrefix           = true
            config.numeralThousandsGroupStyle   = thousandSeparator ? 'thousand' : 'none'
        } else if(phone) {
            config.phone            = true
            config.phoneRegionCode  = phone
        }

        config.numericOnly = this._element.getAttribute("numeric") ? true : false

        if(this._element.hasAttribute("prefix") && !config.prefix) {
            config.prefix = this._element.getAttribute("prefix")
        }

        config.creditCard   = this._element.getAttribute("credit-card") ? true : false
        const uppercase     = this._element.getAttribute("uppercase") ? true : false
        const lowercase     = this._element.getAttribute("lowercase") ? true : false
        config.uppercase    = uppercase && !lowercase
        config.lowercase    = !uppercase && lowercase

        const blocks    = this._element.getAttribute("blocks")?.split(",").map(b => parseInt(b)) ?? null
        config.blocks   = blocks

        const delimiters = this._element.getAttribute("delimiters")
        try {
            if(delimiters) {
                config.delimiters = JSON.parse(delimiters)
            }
        } catch (error) {
            if(delimiters) {
                config.delimiter = delimiters
            }
        }
        
        Object.assign(config, this._config || {})

        this._error     = this._element.classList.contains("is-invalid")
        this._valid     = this._element.classList.contains("is-valid")
        this._visible   = !this._element.classList.contains("d-none") || !this._element.getAttribute("hidden")
        this._disabled  = this._element.disabled

        const initialValue = this._element.value

        this._mask = new Cleave(this._element, config)

        if(this._isNumber && initialValue !== "") {
            this._mask.setRawValue(initialValue)
        }

        this._oldValue = this.get()
    }

    static supportedEvent() {
        return ["input", "change", "keydown", "keyup", "keypress", "focus", "blur"]
    }

    get() {
        if(!this._mask) {
            return super.get()
        }

        const rawValue = this._mask.getRawValue()
        if(this._isNumber) {
            return Helper.isNumber(rawValue) ? (this._isDecimal ? parseFloat(rawValue) : parseInt(rawValue)) : null
        }

        return rawValue
    }

    getFormatted() {
        this._mask.getFormattedValue()
    }

    set(value, isSilent = false) {
        this._mask.setRawValue(value)

        const isChanged = this.isChanged(value)
        this._oldValue = value
        if(!isSilent && isChanged) {
            this.trigger('change', this.get())
        }
    }

    destroy() {
        super.destroy()
        this._mask.destroy()
        this._mask = null
    }
}