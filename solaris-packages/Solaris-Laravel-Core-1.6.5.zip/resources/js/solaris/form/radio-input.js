import CheckboxInput from "./checkbox-input";

export default class RadioInput extends CheckboxInput {
    constructor(selector) {
        super(selector)
    }

    get() {
        return this._element.checked ? {
            id  : this._element.hasAttribute('value') ? this._element.value : this._element.id,
            name: this._label.textContent
        } : null
    }
}