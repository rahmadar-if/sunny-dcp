import TextInput from "./text-input"

export default class Password extends TextInput {
    constructor(selector) {
        super(selector)
    }

    init() {
        super.init()

        this._wrap = this._element.parentElement
        this._eyeButton = this._wrap.querySelector('a.show-password-button')
        if(!this._eyeButton) {
            throw new Error("Icon show password not found")
        }
        this._icon = this._eyeButton.children[0]
        this._toogleHandler = () => this.tooglePassword()
        this._eyeButton.addEventListener('click', this._toogleHandler)
    }

    /**
     * show/hidden password value
     */
    tooglePassword() {
        if(this._element.type == "password") {
            this._element.type = "text"
            this._icon.classList.remove("ri-eye-line")
            this._icon.classList.add("ri-eye-off-line")
        } else {
            this._element.type = "password"
            this._icon.classList.remove("ri-eye-off-line")
            this._icon.classList.add("ri-eye-line")
        }
    }
    
    show() {
        this._wrap.classList.remove("d-none")
        this._visible = true
    }

    hidden() {
        this._wrap.classList.add("d-none")
        this._visible = false
    }

    destroy() {
        super.destroy()
        this._eyeButton.removeEventListener('click', this._toogleHandler)
    }
}