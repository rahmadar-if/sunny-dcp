import CardCheckboxInput from "./card-checkbox-input";

export default class CardRadioInput extends CardCheckboxInput {
    constructor(selector) {
        super(selector)
    }

    // #region Public API

    /**
     * @returns {{id: string, name: string}|null}
     */
    get() {
        if (!this._element.checked) {
            return null
        }

        return {
            id  : this._element.hasAttribute('value') ? this._element.value : this._element.id,
            name: this._label?.textContent?.trim() ?? '',
        }
    }

    // #endregion

}
