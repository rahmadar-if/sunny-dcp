import OptionGroupInput from "./option-group-input";
import CardRadioInput from "./card-radio-input";
import CardCheckboxInput from "./card-checkbox-input";

export default class CardOptionGroupInput extends OptionGroupInput {
    constructor(selector, type) {
        super(selector, type)
    }

    // #region Lifecycle

    init() {
        this._id = this._element.getAttribute("solar-id")
        Array.from(this._element.children).forEach(el => {
            const input     = el.firstElementChild
            const component = this._type === "radio"
                ? new CardRadioInput(input)
                : new CardCheckboxInput(input)
            this._options.push(component)
        })

        this._visible = !this._element.classList.contains("d-none")
        if (this._element.getAttribute("disabled")) {
            this.disabled()
        }

        if (this._type === 'radio') {
            this._options.forEach(opt => {
                opt.on('change', () => this._options.forEach(o => o._updateActiveState()), '_group_active')
            })
        }

        this._oldValue = this.get()
    }

    // #endregion

    // #region Public API

    /**
     * @returns {{id: string, name: string}|Array|null}
     */
    get() {
        const checked = this._options
            .filter(opt => this._type === 'radio' ? opt.get() : true)
            .map(opt => {
                const res = {
                    id  : opt._element.hasAttribute('value') ? opt._element.value : opt._element.id,
                    name: opt._label?.textContent?.trim() ?? '',
                }

                if (this._type === 'checkbox') {
                    res.checked = opt.get()
                }

                return res
            })

        return checked.length === 0 ? null : this._type === 'radio' ? checked[0] : checked
    }

    // #endregion
}
