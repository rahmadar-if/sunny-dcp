import BaseInput from "./base-input";
import CheckboxInput from "./checkbox-input";
import Helper from "../helper";
import RadioInput from "./radio-input";

export default class OptionGroupInput extends BaseInput {
    _options = []

    constructor(selector, type) {
        super(selector)

        if (!["radio", "checkbox"].includes(type)) {
            throw new Error(`Option group ${type} is not supported`)
        }

        this._type = type
        if (!this._lazy) {
            this.init()
        }
    }

    init() {
        this._id = this._element.getAttribute("solar-id")
        Array.from(this._element.children).forEach(el => {
            const component = this._type == "radio" ? new RadioInput(el.firstElementChild) : new CheckboxInput(el.firstElementChild)
            this._options.push(component)
        })

        // this._error = this._element.classList.contains("is-invalid")
        // this._valid = this._element.classList.contains("is-valid")
        this._visible = !this._element.classList.contains("d-none")
        if (this._element.getAttribute("disabled")) {
            this.disabled()
        }

        this._oldValue = this.get()
    }

    static supportedEvent() {
        return ["change"]
    }

    /**
     * get current value element
     * @returns {{id: string, name: string}}
     */
    get() {
        const checked = this._options
            .filter(opt => this._type == 'radio' ? opt.get() : true)
            .map(opt => {
                const res = {
                    id: opt._element.id,
                    name: opt._label.textContent
                }

                if (opt._element.hasAttribute('value')) {
                    res.id = opt._element.value
                }

                if(this._type == 'checkbox') {
                    res.checked = opt.get()
                }

                return res
            })

        return checked.length == 0 ? null : this._type == 'radio' ? checked[0] : checked
    }

    /**
     * set value element
     * @param {{id:string, name:string}|string|array|{id:string, checked:boolean}} value 
     * @param {boolean} isSilent. trigger change event, default is false 
     */
    set(value, isSilent = false) {
        if (value === null) {
            this._options.forEach(opt => opt.set(false, isSilent))
            this._triggerChangeIfNeeded(isSilent)
            return
        }

        if (this._type === 'radio') {
            this._setRadio(value, isSilent)
            return
        }

        this._setCheckbox(value, isSilent)
    }

    _setRadio(value, isSilent) {
        if (Array.isArray(value)) {
            throw new Error("Bulk set (array) is not supported for radio type")
        }

        const targetId = this._extractId(value)

        this._options.forEach(opt => {
            const optVal = opt._element.hasAttribute('value') ? opt._element.value : opt._element.id
            opt.set(optVal == targetId, isSilent)
        })

        this._triggerChangeIfNeeded(isSilent)
    }

    _setCheckbox(value, isSilent) {
        const rawValues = Array.isArray(value) ? value : [value]

        const instructions = rawValues.map(val => {
            const id = this._extractId(val)
            const checked = (typeof val === 'object' && val !== null && 'checked' in val) ? val.checked : true
            return { id, checked }
        })

        instructions.forEach(instruction => {
            const option = this._options.find(opt => {
                const optVal = opt._element.hasAttribute('value') ? opt._element.value : opt._element.id
                return optVal == instruction.id
            })

            if (!option) {
                throw new Error(`Element with id/value ${instruction.id} not found`)
            }

            option.set(instruction.checked, isSilent)
        })

        this._triggerChangeIfNeeded(isSilent)
    }

    _extractId(val) {
        if (Helper.isLookup(val)) {
            return val.id
        }

        if (typeof val === 'object' && val !== null && 'id' in val) {
            return val.id
        }

        if (Helper.isString(val) || typeof val === 'number') {
            return val
        }

        throw new Error("Value must be lookup, string, number, or object with id")
    }

    _triggerChangeIfNeeded(isSilent) {
        const isChanged = this.isChanged()
        this._oldValue = this.get()

        if (!isSilent && isChanged) {
            this.trigger('change', this.get())
        }
    }

    on(type, callback, name = null) {
        this.baseOn(type, callback, name)

        const events = this._events.get(type)
        const event  = name ? events.find(e => e.name === name) : events[events.length - 1]

        this._options.forEach(option => option.on("change", event.handler))
    }

    /**
     * make element disabled
     */
    disabled() {
        this._disabled = true
        this._options.forEach(opt => opt.disabled())
    }

    /**
     * make element enabled
     */
    enabled() {
        this._disabled = false
        this._options.forEach(opt => opt.enabled())
    }

    /**
     * make element looks valid
     */
    valid() {
        this._options.forEach(opt => opt.valid())
        this._error = false
        this._valid = true
    }

    /**
     * make element looks error
     */
    error() {
        this._options.forEach(opt => opt.error())
        this._error = true
        this._valid = false
    }

    resetValidation() {
        this._options.forEach(opt => opt.resetValidation())
        this._error = false
        this._valid = false
    }

    isChanged() {
        const value = this.get()
        if (this._type == 'radio') {
            return this._oldValue?.id !== value?.id
        }

        if ((!value && this._oldValue) || value && !this._oldValue) {
            return true
        }

        if (!value && !this._oldValue) {
            return false
        }

        if (value.length != this._oldValue.length) {
            return true
        }

        const ids1 = new Set(this._oldValue.map(item => item.id))
        const ids2 = new Set(value.map(item => item.id))

        for (const id of ids1) {
            if (!ids2.has(id)) return true
        }

        return false
    }
}