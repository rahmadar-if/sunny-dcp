import BaseInput from "./base-input"
import Tagify from "@yaireo/tagify"

export default class TagInput extends BaseInput {
    constructor(selector, config = {}) {
        super(selector)
        this._config = config

        if (!this._lazy) {
            this.init()
        }
    }

    init(config = {}) {
        const whitelist = this._element.getAttribute("whitelist")
        const maxTags = this._element.getAttribute("max-tags")
        const mode = this._element.getAttribute("mode")
        const pattern = this._element.getAttribute("pattern")
        const duplicates = this._element.hasAttribute("duplicates")

        const settings = {
            whitelist: whitelist ? JSON.parse(decodeURIComponent(whitelist)) : [],
            maxTags: maxTags ? parseInt(maxTags) : Infinity,
            duplicates: duplicates,
            dropdown: {
                enabled: 0,
                closeOnSelect: true
            }
        }

        if (mode === 'mix') {
            settings.mode = 'mix'
            settings.pattern = pattern ? new RegExp(pattern) : /@/
            settings.dropdown.position = "text"
        }

        Object.assign(settings, this._config || {}, config)

        this._tagify = new Tagify(this._element, settings)

        this._tagify.on('change', () => {
            const value = this.get()
            const isChanged = this.isChanged()

            if (isChanged) {
                this._oldValue = value
                this.trigger('change', value)
            }
        })

        this._oldValue = this.get()
    }

    static supportedEvent() {
        return [
            "change", "add", "remove", "invalid", "input", "click", "keydown", "focus", "blur",
            "edit:start", "edit:input", "edit:updated", "edit:keydown",
            "dropdown:show", "dropdown:hide", "dropdown:select", "dropdown:scroll", "dropdown:noMatch", "dropdown:updated"
        ]
    }

    on(type, callback, name = null) {
        this.baseOn(type, callback, name)

        const events = this._events.get(type)
        const event  = name ? events.find(e => e.name === name) : events[events.length - 1]

        if (type !== 'change') {
            event.tagifyHandler = (e) => {
                return callback(this.get(), e.detail)
            }
            this._tagify.on(type, event.tagifyHandler)
        }

        return this
    }

    off(type, callback = null, name = null) {
        if (this._tagify && this._events.has(type)) {
            const events = this._events.get(type)
            let toRemove

            if (name) {
                toRemove = events.filter(e => e.name === name)
            } else if (callback) {
                toRemove = events.filter(e => e.callback === callback)
            } else {
                toRemove = [...events]
            }

            toRemove.forEach(event => {
                if (event.tagifyHandler) {
                    this._tagify.off(type, event.tagifyHandler)
                }
            })
        }

        return super.off(type, callback, name)
    }

    /**
     * @returns {Array|string|null}
     */
    get() {
        if (!this._tagify) {
            return null
        }

        if (this._tagify.settings.mode === 'mix') {
            return this._element.value
        }

        return this._tagify.value
    }

    /**
     * @param {Array|string} value 
     * @param {boolean} isSilent 
     */
    set(value, isSilent = false) {
        if (!this._tagify) {
            return
        }

        if (value === null || value === "") {
            this._tagify.removeAllTags()
        } else {
            if (this._tagify.settings.mode === 'mix') {
                this._element.value = value
                this._tagify.loadOriginalValues()
            } else {
                this._tagify.addTags(value, true, true)
            }
        }

        const currentValue = this.get()
        const isChanged = this.isChanged()
        this._oldValue = currentValue

        if (!isSilent && isChanged) {
            this.trigger('change', currentValue)
        }
    }

    /**
     * @returns {boolean}
     */
    isChanged() {
        const current = this.get()

        if (this._tagify.settings.mode === 'mix') {
            return current !== this._oldValue
        }

        if (!current && !this._oldValue) {
            return false
        }

        if ((!current && this._oldValue) || (current && !this._oldValue)) {
            return true
        }

        if (current.length !== this._oldValue.length) {
            return true
        }

        return JSON.stringify(current) !== JSON.stringify(this._oldValue)
    }

    show() {
        super.show()
        if (this._tagify) {
            this._tagify.DOM.scope.classList.remove("d-none")
        }
    }

    hidden() {
        super.hidden()
        if (this._tagify) {
            this._tagify.DOM.scope.classList.add("d-none")
        }
    }

    disabled() {
        super.disabled()
        if (this._tagify) {
            this._tagify.setDisabled(true)
        }
    }

    enabled() {
        super.enabled()
        if (this._tagify) {
            this._tagify.setDisabled(false)
        }
    }

    valid() {
        this.resetValidation()
        this._element.classList.add("is-valid")
        if (this._tagify) {
            this._tagify.DOM.scope.classList.add("is-valid")
        }
        this._error = false
        this._valid = true
    }

    error() {
        this.resetValidation()
        this._element.classList.add("is-invalid")
        if (this._tagify) {
            this._tagify.DOM.scope.classList.add("is-invalid")
        }
        this._error = true
        this._valid = false
    }

    resetValidation() {
        super.resetValidation()
        if (this._tagify) {
            this._tagify.DOM.scope.classList.remove("is-valid", "is-invalid")
        }
    }

    destroy() {
        if (this._tagify) {
            this._tagify.destroy()
        }
        super.destroy()
    }
}
