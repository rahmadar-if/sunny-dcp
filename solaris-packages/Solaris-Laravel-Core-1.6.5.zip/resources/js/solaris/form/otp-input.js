import SolarComponent from "../solar/solar-component"
import Button from "@core-js/solaris/button"
import axios from "@core-js/libs/axios"

export default class OtpInput extends SolarComponent {

	_length       = 6
	_mode         = 'numeric'
	_error        = false
	_visible      = true
	_resendUrl    = null
	_resendMethod = 'POST'
	_resendParams = {}
	_resendTimer  = null
	_resendBtn    = null

	// #region Static

	static supportedEvent() {
		return ['change', 'resend']
	}

	/**
	 * @param {HTMLElement} container
	 * @param {number} [length=6]
	 * @param {string} [mode='numeric']
	 * @returns {OtpInput}
	 */
	static build(container, length = 6, mode = 'numeric') {
		container.setAttribute('data-length', String(length))
		container.setAttribute('data-mode', mode)

		container.innerHTML = ''

		for (let i = 0; i < length; i++) {
			const input = document.createElement('input')
			input.type          = 'text'
			input.maxLength     = 1
			input.inputMode     = mode === 'numeric' ? 'numeric' : 'text'
			input.autocomplete  = 'one-time-code'
			input.className     = 'form-control text-center fw-bold fs-18 p-0'
			input.style.cssText = 'width: 44px; height: 50px; border-radius: 10px;'

			container.appendChild(input)
		}

		return new OtpInput(container)
	}

	// #endregion

	// #region Lifecycle

	/**
	 * @param {HTMLElement} element
	 */
	constructor(element) {
		super()

		this._element      = element
		this._length       = parseInt(element.getAttribute('data-length') || '6', 10)
		this._mode         = element.getAttribute('data-mode') || 'numeric'
		this._resendUrl    = element.getAttribute('data-resend-url') || null
		this._resendMethod = element.getAttribute('data-resend-method') || 'POST'

		this._bindEvents()
		this._initResend()
	}

	destroy() {
		this._events.forEach((value, key) => this.off(key))
		this._events  = null
		this._element = null
	}

	// #endregion

	// #region Public API

	/**
	 * @returns {number}
	 */
	get length() {
		return this._length
	}

	/**
	 * @returns {string}
	 */
	get() {
		return this._inputs().map(i => i.value).join('')
	}

	/**
	 * @returns {void}
	 */
	reset() {
		this.resetValidation()
		this._inputs().forEach(i => i.value = '')
		this.stopResendTimer()
	}

	/**
	 * @returns {void}
	 */
	focus() {
		this._element.querySelector('input')?.focus()
	}

	/**
	 * @returns {void}
	 */
	show() {
		this._element.classList.remove('d-none')
		this._visible = true
	}

	/**
	 * @returns {void}
	 */
	hidden() {
		this._element.classList.add('d-none')
		this._visible = false
	}

	/**
	 * @returns {void}
	 */
	error() {
		this._inputs().forEach(i => i.classList.add('border-danger'))
		this._error = true
	}

	/**
	 * @returns {void}
	 */
	resetValidation() {
		this._inputs().forEach(i => i.classList.remove('border-danger'))

		if (!this._resendBtn) {
			this._element.classList.remove('flex-wrap')
		}

		const feedback = this._element.querySelector('.otp-feedback')
		if (feedback) {
			feedback.remove()
		}

		this._error = false
	}

	/**
	 * @param {string} message
	 * @returns {void}
	 */
	setMessage(message) {
		if (!message) {
			this.resetValidation()
			return
		}

		this.error()
		this._element.classList.add('flex-wrap')

		let feedback = this._element.querySelector('.otp-feedback')
		if (!feedback) {
			feedback = document.createElement('div')
			feedback.className = 'otp-feedback w-100 text-center text-danger fs-12 mt-1'
			this._element.appendChild(feedback)
		}

		feedback.textContent = message
	}

	/**
	 * @returns {boolean}
	 */
	isError() {
		return this._error
	}

	/**
	 * Override resend URL, method, and body params. Returns this for chaining.
	 * @param {string} url
	 * @param {string} [method='POST']
	 * @param {Object} [params={}]
	 * @returns {this}
	 */
	setResend(url, method = 'POST', params = {}) {
		this._resendUrl    = url
		this._resendMethod = method
		this._resendParams = params
		return this
	}

	/**
	 * Start countdown timer on the resend button. Disables button until timer ends.
	 * @param {number} [seconds=60]
	 * @returns {void}
	 */
	startResendTimer(seconds = 60) {
		if (!this._resendBtn) {
			return
		}

		this.stopResendTimer()
		this._resendBtn.disabled()

		let remaining = seconds
		const tick = () => {
			this._resendBtn._element.textContent = `Resend code (${remaining}s)`
			remaining--

			if (remaining < 0) {
				this._resendBtn._element.textContent = 'Resend code'
				this._resendBtn.enabled()
				this._resendTimer = null
				return
			}

			this._resendTimer = setTimeout(tick, 1000)
		}

		tick()
	}

	/**
	 * Stop countdown timer and reset resend button to its initial disabled state.
	 * @returns {void}
	 */
	stopResendTimer() {
		if (this._resendTimer) {
			clearTimeout(this._resendTimer)
			this._resendTimer = null
		}

		if (this._resendBtn) {
			this._resendBtn._element.textContent = 'Resend code'
			this._resendBtn.disabled()
		}
	}

	// #endregion

	// #region Resend

	/**
	 * @returns {void}
	 */
	_initResend() {
		const btnEl = this._element.querySelector('[data-otp-resend]')
		if (!btnEl) {
			return
		}

		this._element.classList.add('flex-wrap')
		this._resendBtn = new Button(btnEl)
		this._resendBtn.on('click', () => this._handleResend())
	}

	/**
	 * @returns {Promise<void>}
	 */
	async _handleResend() {
		if (!this._resendUrl || !this._resendBtn) {
			return
		}

		this._resendBtn.load()

		try {
			const res = await axios({
				method : this._resendMethod,
				url    : this._resendUrl,
				data   : this._resendParams,
			})

			if (!res.data.success) {
				throw new Error(res.data.message)
			}

			this._resendBtn.unload()
			this.startResendTimer()
			this.trigger('resend', res.data.data ?? res.data)
		} catch (error) {
			if (!error?.response) {
				// axios interceptor handles server errors automatically
			}

			this._resendBtn.unload()
		}
	}

	// #endregion

	// #region Events

	/**
	 * @returns {void}
	 */
	_bindEvents() {
		this._element.addEventListener('input', (e) => {
			if (!(e.target instanceof HTMLInputElement)) {
				return
			}

			const allowed  = this._mode === 'numeric' ? /\D/g : /[^a-zA-Z0-9]/g
			e.target.value = e.target.value.replace(allowed, '')

			if (e.target.value && e.target.nextElementSibling?.tagName === 'INPUT') {
				e.target.nextElementSibling.focus()
			}

			if (this.get().length === this._length) {
				this.trigger('change', this.get())
			}
		})

		this._element.addEventListener('keydown', (e) => {
			if (!(e.target instanceof HTMLInputElement)) {
				return
			}

			if ((e.key === 'Backspace' || e.key === 'Delete') && !e.target.value) {
				const prev = e.target.previousElementSibling
				if (prev?.tagName === 'INPUT') {
					prev.value = ''
					prev.focus()
				}
			}
		})

		this._element.addEventListener('paste', (e) => {
			e.preventDefault()

			const allowed = this._mode === 'numeric' ? /\D/g : /[^a-zA-Z0-9]/g
			const text    = e.clipboardData.getData('text').replace(allowed, '').slice(0, this._length)
			const inputs  = this._inputs()

			text.split('').forEach((ch, idx) => {
				if (inputs[idx]) {
					inputs[idx].value = ch
				}
			})

			inputs[Math.min(text.length, this._length - 1)]?.focus()

			if (text.length === this._length) {
				this.trigger('change', this.get())
			}
		})
	}

	// #endregion

	// #region Internals

	/**
	 * @returns {HTMLInputElement[]}
	 */
	_inputs() {
		return Array.from(this._element.querySelectorAll('input'))
	}

	// #endregion
}
