import CheckboxInput from "./checkbox-input";

export default class CardCheckboxInput extends CheckboxInput {
    constructor(selector) {
        super(selector)
    }

    // #region Lifecycle

    init() {
        this._wrap     = this._element.parentElement
        this._label    = this._wrap.querySelector(".card-option-title")
        this._error    = this._element.classList.contains("is-invalid")
        this._valid    = this._element.classList.contains("is-valid")
        this._visible  = !this._wrap.classList.contains("d-none")
        this._disabled = this._element.disabled
        this._oldValue = this.get()

        this.on('change', () => this._updateActiveState())
        this._updateActiveState()
    }

    // #endregion

    // #region Public API

    /**
     * @param {boolean} value
     * @param {boolean} isSilent
     */
    set(value, isSilent = false) {
        super.set(value, isSilent)
        this._updateActiveState()
    }

    // #endregion

    // #region Active State

    _updateActiveState() {
        const color   = this._wrap.dataset.cardColor || 'primary'
        const checked = this._element.checked
        this._wrap.classList.toggle(`border-${color}`, checked)
    }

    // #endregion
}
