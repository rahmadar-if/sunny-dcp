import BaseInput from "./base-input"
import flatpickr from "flatpickr"
import Helper from "../helper"
import DateHelper from "../date-helper"

export default class DatePicker extends BaseInput {
    #picker        = null

    constructor(selector, mode = "date", config = null) {
        super(selector)
        if(!["datetime", "date", "time"].includes(mode)) {
            throw new Error(`Picker ${mode} mode is not supported`)
        }

        this._mode   = mode
        this._config = config
        this._range  = false
        this._inline = false
        
        if(!this._lazy) {
            this.init()
        }
    }
    
    init(config = null) {
        if(!config) {
            config = {}
        }

        if(this._mode == "datetime") {
            Object.assign(config, DatePicker.dateTimeConfig())
        } else if(this._mode == "time") {
            Object.assign(config, DatePicker.timeConfig())
        } else {
            Object.assign(config, DatePicker.dateConfig())
        }
        
        this._range = this._element.getAttribute("range") ? true : false
        if(this._range && this._mode != "time") {
            config.mode = "range"
        }

        this._inline = this._element.getAttribute("inline") ? true : false
        if(this._mode != "time" && this._inline) {
            config.inline = true
        }

        Object.assign(config, this._config || {})
        this.#picker        = flatpickr(this._element, config)
        this._pickerElement = this._mode == "time" ? this._element : this._element.nextElementSibling
        this._oldValue      = this.get()
    }

    static dateConfig() {
        return {
            altInput     : true,
            altFormat    : "d M Y",
            dateFormat   : "Y-m-d",
            disableMobile: true
        }
    }

    static dateTimeConfig() {
        return {
            enableTime      : true,
            altInput        : true,
            altFormat       : "d M Y G:i K",
            dateFormat      : "Y-m-d H:i",
            disableMobile   : true,
            allowInput      : true,
            minuteIncrement : 1
        }
    }

    static timeConfig() {
        return {
            enableTime      : true,
            noCalendar      : true,
            altFormat       : "H:i",
            dateFormat      : "H:i",
            disableMobile   : true,
            allowInput      : true,
            minuteIncrement : 1
        }
    }

    static supportedEvent() {
        return ["change", "open", "close", "ready", "day-create"]
    }

    /**
     * @returns {Date}
     */
    get() {
        if(this.#picker.selectedDates.length == 0) {
            return null
        }

        return this.#picker.config.mode == "single" ? this.#picker.selectedDates[0] : this.#picker.selectedDates
    }

    /**
     * @param {string|Date} value 
     */
    set(value, isSilent = false) {
        if(Helper.isString(value)) {
            value = new Date(value)
        }

        this.#picker.setDate(value, !isSilent, this.#picker.config.dateFormat)
    }

    /**
     * get current value element in string format
     * @returns {string}
     */
    toString() {
        if(this.#picker.selectedDates.length == 0) {
            return ""
        }   

        const value = this.#picker.selectedDates
        const convert = value.map(val => {
            if(this._mode == "datetime") {
                return val.toISOString()
            }

            if(this._mode == "date") {
                return DateHelper.dateToString(val)
            }

            if(this._mode == "time") {
                const withSeconds = this.#picker.config.enableSeconds === true
                return DateHelper.timeToString(val, false, withSeconds)
            }

            return ""
        })
        
        return this.#picker.config.mode == "single" ? convert[0] : convert
    }

    on(type, callback, name = null) {
        this.baseOn(type, callback, name)

        const events = this._events.get(type)
        const event  = name ? events.find(e => e.name === name) : events[events.length - 1]

        event.handler = (...args) => callback(this.get(), ...args)

        if (type == 'change') {
            this.#picker.config.onChange.push(event.handler)
        } else if (type == 'open') {
            this.#picker.config.onOpen.push(event.handler)
        } else if (type == 'close') {
            this.#picker.config.onClose.push(event.handler)
        } else if (type == 'ready') {
            this.#picker.config.onReady.push(event.handler)
        } else if (type == 'day-create') {
            this.#picker.config.onDayCreate.push(event.handler)
        }
    }

    show() {
        this._pickerElement.classList.remove("d-none")
        this._visible = true
    }

    hidden() {
        this._pickerElement.classList.add("d-none")
        this._visible = false
    }

    disabled() {
        super.disabled()
        this._pickerElement.disabled = true
    }

    enabled() {
        super.enabled()
        this._pickerElement.disabled = false
    }

    valid() {
        super.valid()
        this._pickerElement.classList.remove("is-invalid")
        this._pickerElement.classList.add("is-valid")
    }

    error() {
        super.error()
        this._pickerElement.classList.remove("is-valid")
        this._pickerElement.classList.add("is-invalid")
    }

    resetValidation() {
        super.resetValidation()
        this._pickerElement.classList.remove("is-valid", "is-invalid")
    }

    /**
     * remove all event
     */
    destroy() {
        this.#picker.destroy()
        this.#picker = null
        this._events = null
    }
}