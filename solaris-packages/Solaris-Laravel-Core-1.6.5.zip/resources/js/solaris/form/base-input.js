import Helper from "../helper"
import SolarComponent from "../solar/solar-component"

export default class BaseInput extends SolarComponent {
    _visible  = true
    _required = false
    _disabled = false
    _valid    = false
    _error    = false
    _oldValue = null
    _lazy     = false

    constructor(selector) {
        super()

        if(selector instanceof Element) {
            this._element = selector
        } else if(Helper.isString(selector) && !Helper.isEmpty(selector)) {
            this._element = document.querySelector(selector)
            if(!this._element) {
                throw new Error(`Element with query selector ${selector} is not found`)
            }
        } else {
            throw new Error(`Selector is not supported`)
        }

        this._id   = this._element.id
        this._lazy = this._element.getAttribute("lazy") ? true : false
    }

    /**
     * get current value element
     * @returns {*}
     */
    get() {
        throw new Error("Method 'get()' must be implemented in child class.")
    }

    /**
     * set value element
     * @param {*} value 
     * @param {boolean} isSilent. trigger change event, default is false 
     */
    set(value, isSilent = false) {
        throw new Error("Method 'set()' must be implemented in child class.")
    }

    /**
     * add event to component - base method from SolarComponent
     * @param {string} type
     * @param {Function} callback
     * @param {string|null} name
     */
    baseOn(type, callback, name = null) {
        return super.on(type, callback, name)
    }

    on(type, callback, name = null) {
        let oldDomHandler = null
        if (name && this._events.has(type)) {
            const existing = this._events.get(type).find(e => e.name === name)
            if (existing) oldDomHandler = existing.domHandler
        }

        super.on(type, callback, name)

        const events = this._events.get(type)
        const event  = name ? events.find(e => e.name === name) : events[events.length - 1]

        if (oldDomHandler) {
            this._element.removeEventListener(type, oldDomHandler)
        }

        const domHandler = (e) => {
            const state = typeof this.get === "function" ? this.get() : undefined
            return callback(state, e)
        }

        event.domHandler = domHandler
        this._element.addEventListener(type, domHandler)

        return this
    }

    off(type, callback = null, name = null) {
        if (!this._events.has(type)) {
            return this
        }

        const events = this._events.get(type)
        let toRemove

        if (name) {
            toRemove = events.filter(e => e.name === name)
        } else if (callback) {
            toRemove = events.filter(e => e.callback === callback)
        } else {
            toRemove = [...events]
        }

        toRemove.forEach(event => {
            if (event.domHandler) {
                this._element.removeEventListener(type, event.domHandler)
            }
        })

        return super.off(type, callback, name)
    }

    /**
     * show element
     */
    show() {
        if(this._element.getAttribute("hidden")) {
            this._element.removeAttribute("hidden")
        }
        this._element.classList.remove("d-none")
        this._visible = true
    }

    /**
     * hidden element
     */
    hidden() {
        this._element.classList.add("d-none")
        this._visible = false
    }

    /**
     * make element required
     */
    required() {
        this._required = true
    }

    /**
     * make element optional
     */
    optional() {
        this._required = false
    }

    /**
     * make element disabled
     */
    disabled() {
        this._disabled         = true
        this._element.disabled = true
    }

    /**
     * make element enabled
     */
    enabled() {
        this._disabled         = false
        this._element.disabled = false
    }

    /**
     * make element looks valid
     */
    valid() {
        this._element.classList.remove("is-invalid")
        this._element.classList.add("is-valid")
        this._error = false
        this._valid = true
    }

    /**
     * make element looks error
     */
    error() {
        this._element.classList.remove("is-valid")
        this._element.classList.add("is-invalid")
        this._error = true
        this._valid = false
    }

    resetValidation() {
        this._element.classList.remove("is-valid", "is-invalid")
        this._error = false
        this._valid = false
    }
    
    reset(isSilent = false) {
        this.resetValidation()
        this.set(null, isSilent)
    }

    /**
     * check element is required or not
     * @returns {boolean}
     */
    isRequired() {
        return this._required
    }

    /**
     * check element is disabled or not
     * @returns {boolean}
     */
    isDisabled() {
        return this._disabled
    }

    /**
     * check element is display in document or not
     * @returns {boolean}
     */
    isVisible() {
        return this._visible
    }

    /**
     * check element is error or not
     * @returns {boolean} 
     */
    isError() {
        return this._error
    }

    /**
     * check element is valid or not
     * @returns {boolean} 
     */
    isValid() {
        return this._valid
    }

    /**
     * check element is changed or not
     * @returns {boolean}
     */
    isChanged() {
        return this._oldValue !== this.get()
    }

    /**
     * remove all event
     */
    destroy() {
        this._events.forEach((value, key) => this.off(key))

        this._events  = null
        this._element = null
    }
}