import BaseInput from "./base-input"
import axios from '@core-js/libs/axios'
import TableLookup from '../table/table-lookup'
import Filter from '../filter/filter'

/**
 * @typedef {Object} LookupItem
 * @property {string|number} id
 * @property {string} name
 */

/**
 * @typedef {Object} LookupConfig
 * @property {string|null} source - Model class name sent via X-Model header for remote lookup
 * @property {LookupItem[]|null} data - Static data array; auto-populated from <option> tags if no source/data set
 * @property {boolean} pagination - Enable infinite-scroll pagination via IntersectionObserver sentinel
 * @property {number} pageSize - Number of items per page request
 * @property {string} placeholder - Placeholder text shown when no value is selected
 * @property {number} delay - Debounce delay in ms applied to search input
 * @property {number} minChars - Minimum characters required before a search fires (0 = always search)
 * @property {boolean} allowClear - Show the clear button when a value is selected
 * @property {string|null} extendColumns - Comma-separated extra column names to request from server
 * @property {string|null} extendSearch - Comma-separated extra column names to include in server-side search
 * @property {{name: string, dir: string}|null} orderBy - Force server-side sort; e.g. { name: 'created_at', dir: 'desc' }
 * @property {Function|null} param - Callback `(body) => object` to inject extra POST params per request
 * @property {Function|null} optionsTemplate - `(item: LookupItem) => string` — custom HTML for each dropdown item
 * @property {Function|null} selectionTemplate - `(item: LookupItem) => string` — custom HTML for the selected display
 * @property {{url: Function|null, target: '_self'|'_blank'|'_parent'|'_top'}} link - Render selection as anchor; `url(item)` must return a string; target defaults to '_blank'
 * @property {Object.<string, function(*, Object): string>|null} columnRender - Per-column render overrides for TableLookup; key = field-name, value = (data, rowData) => html
 */

const DEFAULTS = {
	source: null,
	data: null,
	pagination: false,
	pageSize: 10,
	placeholder: 'Choose one',
	delay: 300,
	minChars: 0,
	allowClear: true,
	copy: false,
	multiple: false,
	extendColumns: null,
	extendSearch: null,
	orderBy: null,
	param: null,
	optionsTemplate: null,
	selectionTemplate: null,
	link: { url: null, target: '_blank' },
	tableLookup: null,
	columnRender: null
}

/**
 * @extends BaseInput
 */
export default class LookupInput extends BaseInput {

	// #region Static Cache

	/**
	 * @returns {string[]}
	 */
	static supportedEvent() {
		return ['change', 'search', 'open', 'close']
	}

	static _cache        = new Map()
	static _cacheMaxSize = 50
	static _cacheTTL     = 30000 // 30 seconds

	/**
	 * @param {string} source
	 * @param {string} search
	 * @param {number} page
	 * @param {string|null} extendSearch
	 * @param {{name: string, dir: string}|null} orderBy
	 * @returns {string}
	 */
	static _getCacheKey(source, search, page, extendSearch = null, orderBy = null) {
		return `${source}|${search}|${page}|${extendSearch ?? ''}|${orderBy ? `${orderBy.name}:${orderBy.dir}` : ''}`
	}

	/**
	 * @param {string} source
	 * @param {string} search
	 * @param {number} page
	 * @param {string|null} extendSearch
	 * @param {{name: string, dir: string}|null} orderBy
	 * @returns {{items: LookupItem[], hasMore: boolean}|null}
	 */
	static _getCached(source, search, page, extendSearch = null, orderBy = null) {
		const key   = LookupInput._getCacheKey(source, search, page, extendSearch, orderBy)
		const entry = LookupInput._cache.get(key)

		if (!entry) {
			return null
		}

		if (Date.now() - entry.time > LookupInput._cacheTTL) {
			LookupInput._cache.delete(key)
			return null
		}
		return entry.data
	}

	/**
	 * @param {string} source
	 * @param {string} search
	 * @param {number} page
	 * @param {{items: LookupItem[], hasMore: boolean}} data
	 * @param {string|null} extendSearch
	 * @param {{name: string, dir: string}|null} orderBy
	 */
	static _setCache(source, search, page, data, extendSearch = null, orderBy = null) {
		const key = LookupInput._getCacheKey(source, search, page, extendSearch, orderBy)

		// Evict oldest if at capacity
		if (LookupInput._cache.size >= LookupInput._cacheMaxSize && !LookupInput._cache.has(key)) {
			const oldest = LookupInput._cache.keys().next().value
			LookupInput._cache.delete(oldest)
		}

		LookupInput._cache.set(key, { data, time: Date.now() })
	}

	/**
	 * @param {HTMLElement} container
	 * @param {Partial<LookupConfig>} config
	 * @returns {LookupInput}
	 */
	static create(container, config = {}) {
		const el = document.createElement('div')
		el.setAttribute('solar-ui', 'lookup')
		if (container.hasAttribute('value')) {
			el.setAttribute('value', container.getAttribute('value'))
		}
		container.appendChild(el)
		return new LookupInput(el, config)
	}

	/**
	 * Render complete LookupInput HTML — host element + wrapper.
	 * Client-side equivalent of lookup.blade.php SSR output.
	 *
	 * @param {Partial<LookupConfig> & { value?: string, size?: 'sm'|'md'|'lg', copy?: boolean }} config
	 * @param {Object} hostAttrs - Extra HTML attributes for host element (e.g. id, data-*)
	 * @returns {string}
	 */
	static renderHTML(config = {}, hostAttrs = {}) {
		const isMultiple  = config.multiple === true
		const placeholder = config.placeholder ?? 'Choose one'
		const size        = config.size ?? 'md'
		const allowCopy   = config.copy ?? false

		const wrapperCls = ['lki-wrapper', isMultiple && 'lki-multi', size !== 'md' && `lki-${size}`]
			.filter(Boolean).join(' ')

		const configAttrs = [
			config.source        ? `source="${config.source}"` : '',
			config.placeholder   ? `placeholder="${config.placeholder}"` : '',
			isMultiple           ? 'multiple' : '',
			config.pagination    ? 'pagination' : '',
			allowCopy            ? 'copy' : '',
			config.value         ? `value="${config.value}"` : '',
			config.extendColumns ? `extend-columns="${config.extendColumns}"` : '',
			config.extendSearch  ? `extend-search="${config.extendSearch}"` : '',
			config.orderBy       ? `order-by="${config.orderBy.name}:${config.orderBy.dir}"` : '',
		].filter(Boolean).join(' ')

		const hostAttrStr = Object.entries(hostAttrs)
			.map(([k, v]) => `${k}="${v}"`)
			.join(' ')

		const inner = isMultiple
			? `<div class="lki-tags">
					<span class="lki-placeholder">${placeholder}</span>
					<input type="text" class="lki-search" autocomplete="off" style="display:none">
				</div>`
			: `<span class="lki-placeholder">${placeholder}</span>
				<input type="text" class="lki-search" autocomplete="off" style="display:none">`

		return `<div solar-ui="lookup" ${configAttrs} ${hostAttrStr}></div>
			<div class="${wrapperCls}">
				<div class="lki-control">
					${inner}
					${allowCopy ? `<span class="lki-copy" style="display:none"><i class="ri-file-copy-line"></i></span>` : ''}
					<span class="lki-clear" style="display:none"><i class="ri-close-line"></i></span>
					<span class="lki-arrow"></span>
				</div>
			</div>`
	}

	// #endregion

	// #region Lifecycle

	/**
	 * @param {string|Element} selector
	 * @param {Partial<LookupConfig>|null} config
	 */
	constructor(selector, config = null) {
		super(selector)
		this._config = config
		this._isDiv  = this._element.tagName === 'DIV'
		if (!this._lazy) {
			this.init()
		}
	}

	/**
	 * @param {Partial<LookupConfig>} config
	 * @returns {this}
	 */
	init(config = {}) {
		const isReInit = !!this._wrapper
		if (isReInit) {
			this._teardownDOM()
		}

		const prevTableLookupInst   = this._tableLookupInst ?? null
		const prevTableLookupConfig = this._config?.tableLookup ?? null
		const prevIsOwned           = this._isOwnedTableLookup ?? false

		this._value           = null
		this._currentPage     = 1
		this._hasMore         = false
		this._isOpen          = false
		this._focusedIndex    = -1
		this._abortController = null
		this._debounceTimer   = null
		this._observer        = null
		this._rafId           = null
		this._selection       = null
		this._tableLookupInst      = null
		this._isOwnedTableLookup   = false

		this._isMultiple = this._isDiv ? false : this._element.multiple

		this._resolveConfig(config)

		if (this._isDiv) {
			this._isMultiple = this._config.multiple === true
		}
		this._resolveInitialValue()
		this._buildDOM()
		this._attachEvents()
		this._resolveTableLookup(prevTableLookupInst, prevTableLookupConfig, prevIsOwned)

		if (this._element.hasAttribute('disabled')) {
			this.disabled()
		}

		if (this._isMultiple) {
			this._renderTags()
		} else {
			if (this._value) {
				this._renderSelection(this._value)
			} else {
				this._renderPlaceholder()
			}
		}

		this._oldValue = this.get()

		return this
	}

	/**
	 * @returns {void}
	 */
	destroy() {
		this._teardownDOM()

		if (this._abortController) {
			this._abortController.abort()
			this._abortController = null
		}

		clearTimeout(this._debounceTimer)

		if (this._isOwnedTableLookup) {
			this._tableLookupInst?.destroy()
		}
		this._tableLookupInst    = null
		this._isOwnedTableLookup = false

		this._events  = null
		this._element = null
		this._config  = null
	}

	// #endregion

	// #region Public API

	/**
	 * @returns {this}
	 */
	open() {
		if (this._isOpen || this._disabled) {
			return this
		}

		this._isOpen = true
		this._wrapper.classList.add('lki-open')
		this._focusedIndex = -1

		if (this._isMultiple) {
			this._placeholder.style.display = 'none'
			this._searchInput.style.display = ''
		} else {
			if (this._selection) this._selection.style.display = 'none'
			this._placeholder.style.display = 'none'
			this._searchInput.style.display = ''
			this._searchInput.value = ''
		}

		document.body.appendChild(this._dropdown)
		this._positionDropdown()
		this._loadOptions('', 1)

		setTimeout(() => this._searchInput.focus(), 0)

		document.addEventListener('click', this._onDocumentClick, true)
		window.addEventListener('resize', this._onResize)
		window.addEventListener('scroll', this._onScroll, true)

		this.trigger('open', this._value)

		return this
	}

	/**
	 * @returns {this}
	 */
	close() {
		if (!this._isOpen) {
			return this
		}

		this._isOpen = false
		this._wrapper.classList.remove('lki-open')

		if (this._dropdown.parentNode) {
			this._dropdown.remove()
		}

		if (this._isMultiple) {
			this._searchInput.style.display = 'none'
			this._searchInput.value = ''
			this._placeholder.style.display = (this._value && this._value.length > 0) ? 'none' : ''
		} else {
			this._searchInput.style.display = 'none'

			if (this._value) {
				if (this._selection) this._selection.style.display = ''
				this._placeholder.style.display = 'none'
			} else {
				this._placeholder.style.display = ''
			}
		}

		document.removeEventListener('click', this._onDocumentClick, true)
		window.removeEventListener('resize', this._onResize)
		window.removeEventListener('scroll', this._onScroll, true)

		if (this._rafId) {
			cancelAnimationFrame(this._rafId)
			this._rafId = null
		}

		if (this._abortController) {
			this._abortController.abort()
			this._abortController = null
		}

		this._detachSentinel()
		this.trigger('close', this._value)

		return this
	}

	/**
	 * @returns {LookupItem|LookupItem[]|null}
	 */
	get() {
		return this._value
	}

	/**
	 * @param {LookupItem|LookupItem[]|string|number|null} value
	 * @param {boolean} isSilent
	 * @returns {this}
	 */
	set(value, isSilent = false) {
		if (value === null || value === undefined) {
			return this.clear(isSilent)
		}

		if (this._isMultiple) {
			const arr      = Array.isArray(value) ? value : [value]
			const oldValue = this._value
			this._value    = arr.length > 0 ? arr : null

			this._syncSelect(this._value)
			this._renderTags()

			const isChanged = this._valueChanged(oldValue, this._value)
			this._oldValue  = this._value

			if (!isSilent && isChanged) {
				this.trigger('change', this._value)
			}

			return this
		}

		if (typeof value === 'string' || typeof value === 'number') {
			if (this._config.source) {
				throw new Error('set() with string ID is only valid for static data')
			}
			const found = (this._config.data || []).find(item => String(item.id) === String(value))
			if (!found) {
				throw new Error(`Item with id "${value}" not found in static data`)
			}
			value = found
		}

		const oldValue = this._value
		this._value    = value

		this._syncSelect(value)
		this._renderSelection(value)

		const isChanged = this._valueChanged(oldValue, value)
		this._oldValue  = value

		if (!isSilent && isChanged) {
			this.trigger('change', value)
		}

		return this
	}

	/**
	 * @param {boolean} isSilent
	 * @returns {this}
	 */
	clear(isSilent = false) {
		if (this._isOpen) {
			this.close()
		}

		const oldValue = this._value
		this._value    = null

		this._syncSelect(null)

		if (this._isMultiple) {
			this._renderTags()
		} else {
			this._renderPlaceholder()
		}

		const isChanged = this._valueChanged(oldValue, null)
		this._oldValue  = null

		if (!isSilent && isChanged) {
			this.trigger('change', null)
		}

		return this
	}

	/**
	 * @param {LookupItem[]} data
	 * @returns {this}
	 */
	setOptions(data) {
		if (this._config.source) {
			return this
		}

		if (!Array.isArray(data)) {
			throw new Error('Data must be an array')
		}

		this._config.data = data
		this.clear(true)

		return this
	}

	/**
	 * @returns {boolean}
	 */
	isChanged() {
		return this._valueChanged(this._oldValue, this._value)
	}

	/**
	 * Copies the current selection name to clipboard.
	 * For multiple selection, joins all names with ', '.
	 *
	 * @returns {this}
	 */
	copyValue() {
		if (!this._value) {
			return this
		}

		const text = this._isMultiple
			? (this._value || []).map(i => i.name).join(', ')
			: this._value.name
		navigator.clipboard.writeText(text).catch(() => {})
		return this
	}

	/**
	 * @param {string} type
	 * @param {Function} callback
	 * @param {string|null} name
	 * @returns {this}
	 */
	on(type, callback, name = null) {
		this.baseOn(type, callback, name)
		return this
	}

	/**
	 * @returns {void}
	 */
	show() {
		this._wrapper.classList.remove('d-none')
		this._wrapper.removeAttribute('hidden')
		this._visible = true
	}

	/**
	 * @returns {void}
	 */
	hidden() {
		this._wrapper.classList.add('d-none')
		this._visible = false
	}

	/**
	 * @returns {void}
	 */
	disabled() {
		this._disabled         = true
		this._element.disabled = true
		this._wrapper.classList.add('lki-disabled')
		this._clearBtn.style.display = 'none'
		if (this._copyBtn) this._copyBtn.style.display = 'none'
	}

	/**
	 * @returns {void}
	 */
	enabled() {
		this._disabled         = false
		this._element.disabled = false
		this._wrapper.classList.remove('lki-disabled')

		const hasValue = this._isMultiple
			? (this._value && this._value.length > 0)
			: this._value !== null

		if (this._config.allowClear && hasValue) {
			this._clearBtn.style.display = ''
		}
		if (this._copyBtn && hasValue) {
			this._copyBtn.style.display = ''
		}
	}

	/**
	 * @returns {void}
	 */
	valid() {
		this._wrapper.classList.remove('lki-invalid')
		this._wrapper.classList.add('lki-valid')
		this._element.classList.remove('is-invalid')
		this._element.classList.add('is-valid')
		this._error = false
		this._valid = true
	}

	/**
	 * @returns {void}
	 */
	error() {
		this._wrapper.classList.remove('lki-valid')
		this._wrapper.classList.add('lki-invalid')
		this._element.classList.remove('is-valid')
		this._element.classList.add('is-invalid')
		this._error = true
		this._valid = false
	}

	/**
	 * @returns {void}
	 */
	resetValidation() {
		this._wrapper.classList.remove('lki-valid', 'lki-invalid')
		this._element.classList.remove('is-valid', 'is-invalid')
		this._error = false
		this._valid = false
	}

	// #endregion

	// #region Initialization

	/**
	 * @param {Partial<LookupConfig>} inlineConfig
	 */
	_resolveConfig(inlineConfig = {}) {
		const el = this._element

		const attrs = {}

		if (el.getAttribute('source')) {
			attrs.source = el.getAttribute('source')
		}

		if (el.hasAttribute('pagination')) {
			attrs.pagination = true
		}

		if (el.getAttribute('page-size')) {
			attrs.pageSize = parseInt(el.getAttribute('page-size'))
		}

		if (el.getAttribute('placeholder')) {
			attrs.placeholder = el.getAttribute('placeholder')
		}

		if (el.getAttribute('delay')) {
			attrs.delay = parseInt(el.getAttribute('delay'))
		}

		if (el.getAttribute('min-chars')) {
			attrs.minChars = parseInt(el.getAttribute('min-chars'))
		}

		if (el.hasAttribute('no-clear')) {
			attrs.allowClear = false
		}

		if (el.hasAttribute('copy')) {
			attrs.copy = true
		}

		if (el.hasAttribute('multiple')) {
			attrs.multiple = true
		}

		if (el.getAttribute('data-options')) {
			try { attrs.data = JSON.parse(el.getAttribute('data-options')) } catch (_) {}
		}

		if (el.getAttribute('extend-columns')) {
			attrs.extendColumns = el.getAttribute('extend-columns')
		}

		if (el.getAttribute('extend-search')) {
			attrs.extendSearch = el.getAttribute('extend-search')
		}

		if (el.getAttribute('order-by')) {
			const [name, dir = 'asc'] = el.getAttribute('order-by').split(':')
			attrs.orderBy = { name: name.trim(), dir: dir.trim() }
		}
		if (el.getAttribute('link-url')) {
			const urlTemplate = el.getAttribute('link-url')
			attrs.link = {
				url:    (item) => urlTemplate.replace(/\{([\w.]+)\}/g, (_, path) =>
					path.split('.').reduce((obj, key) => obj?.[key] ?? '', item)
				),
				target: el.getAttribute('link-target') || '_blank'
			}
		}
		if (el.getAttribute('table-lookup')) {
			attrs.tableLookup = el.getAttribute('table-lookup')
		}

		this._config = Object.assign(
			{},
			DEFAULTS,
			{ link: { ...DEFAULTS.link } },
			attrs,
			this._config || {},
			inlineConfig
		)

		// Backward compat: isPagination → pagination (used by datagrid.js)
		if (!this._config.pagination && this._config.isPagination) {
			this._config.pagination = true
		}
	}

	/**
	 * @returns {void}
	 */
	_resolveInitialValue() {
		const raw = this._element.getAttribute('value')
		if (!raw) {
			this._value = null
			return
		}

		try {
			const parsed = JSON.parse(decodeURIComponent(raw))

			if (this._isMultiple) {
				this._value = Array.isArray(parsed) && parsed.length
					? parsed.map(item => ({ ...item, name: item.name || item.text || item.displayValue?.value || '' }))
					: null
			} else {
				this._value = parsed && typeof parsed === 'object' && !Array.isArray(parsed)
					? { ...parsed, name: parsed.name || parsed.text || parsed.displayValue?.value || '' }
					: null
			}
		} catch (e) {
			this._value = null
		}
	}

	/**
	 * @returns {void}
	 */
	_buildDOM() {
		this._wrapper         = null
		this._control         = null
		this._placeholder     = null
		this._searchInput     = null
		this._clearBtn        = null
		this._copyBtn         = null
		this._dropdown        = null
		this._list            = null
		this._empty           = null
		this._sentinel        = null
		this._tags            = null
		this._onDocumentClick = null
		this._onResize        = null
		this._onScroll        = null
		this._onKeydown       = null

		this._element.style.display = 'none'

		// Read <option> tags → static data if no source/data configured (select host only)
		if (!this._isDiv && !this._config.source && !this._config.data) {
			const data = Array.from(this._element.options)
				.filter(opt => opt.value !== '')
				.map(opt => ({ id: opt.value, name: opt.text }))
			if (data.length > 0) {
				this._config.data = data
			}
		}

		const nextEl = this._element.nextElementSibling
		const isSsr  = nextEl?.classList.contains('lki-wrapper')

		if (!isSsr) {
			const size = this._config.size
				?? (this._element.classList.contains('lki-sm') ? 'sm'
					: this._element.classList.contains('lki-lg') ? 'lg' : 'md')

			const temp = document.createElement('div')
			temp.innerHTML = LookupInput.renderHTML({
				multiple:    this._isMultiple,
				placeholder: this._config.placeholder,
				size,
				copy:        this._config.copy ?? false,
			})
			this._element.after(temp.lastElementChild)
		}

		this._wrapper = this._element.nextElementSibling
		this._wrapper.setAttribute('solar-id', this._id)

		this._control     = this._wrapper.querySelector('.lki-control')
		this._placeholder = this._wrapper.querySelector('.lki-placeholder')
		this._searchInput = this._wrapper.querySelector('.lki-search')
		this._clearBtn    = this._wrapper.querySelector('.lki-clear')
		this._copyBtn     = this._wrapper.querySelector('.lki-copy')
		this._tags        = this._wrapper.querySelector('.lki-tags') ?? null

		this._dropdown = document.createElement('div')
		this._dropdown.className = 'lki-dropdown'

		this._list = document.createElement('ul')
		this._list.className = 'lki-list'

		this._empty = document.createElement('div')
		this._empty.className = 'lki-empty'
		this._empty.textContent = 'No results'
		this._empty.style.display = 'none'

		this._sentinel = document.createElement('li')
		this._sentinel.className = 'lki-sentinel'

		this._dropdown.appendChild(this._list)
		this._dropdown.appendChild(this._empty)

		this._onDocumentClick = this._handleDocumentClick.bind(this)
		this._onResize = () => {
			if (!this._rafId) {
				this._rafId = requestAnimationFrame(() => {
					this._positionDropdown()
					this._rafId = null
				})
			}
		}
		this._onScroll  = this._onResize
		this._onKeydown = this._handleKeydown.bind(this)
	}

	/**
	 * @returns {void}
	 */
	_attachEvents() {
		this._control.addEventListener('click', (e) => {
			if (this._disabled) {
				return
			}

			if (this._clearBtn.contains(e.target)) {
				return
			}

			if (this._copyBtn?.contains(e.target)) {
				return
			}

			if (this._isMultiple && e.target.closest('.lki-tag-remove')) {
				return
			}

			if (this._selection?.classList.contains('lki-link') && this._selection.contains(e.target)) {
				return
			}

			if (this._tableLookupInst) {
				if (this._config.param) {
					const result    = this._config.param({})
					const rawArr    = result?.filter
					const filterObj = Array.isArray(rawArr) && rawArr.length > 0
						? new Filter(rawArr)
						: null
					this._tableLookupInst.table.filter('lookup_param', filterObj, false)
				}
				this._tableLookupInst.open()
				return
			}

			this._isOpen ? this.close() : this.open()
		})

		this._clearBtn.addEventListener('click', (e) => {
			e.stopPropagation()
			this.clear()
		})

		this._copyBtn?.addEventListener('click', (e) => {
			e.stopPropagation()
			this.copyValue()
		})

		this._searchInput.addEventListener('input', () => {
			const term = this._searchInput.value
			this.trigger('search', term)
			clearTimeout(this._debounceTimer)
			this._debounceTimer = setTimeout(() => {
				this._loadOptions(term, 1)
			}, this._config.delay)
		})

		this._searchInput.addEventListener('keydown', this._onKeydown)
	}

	/**
	 * Bind an external TableLookup instance to this input.
	 * Use this for custom TableLookup integration instead of the auto-mode prop.
	 * LookupInput must be in lazy mode; call init() first before binding.
	 * @param {TableLookup} instance
	 * @returns {this}
	 */
	bindTableLookup(instance) {
		if (this._tableLookupInst && this._isOwnedTableLookup) {
			this._tableLookupInst.destroy()
		}
		this._tableLookupInst    = instance
		this._isOwnedTableLookup = false
		this._attachTableLookupEvents()
		return this
	}

	/**
	 * @param {TableLookup|null} prevInst
	 * @param {string|null} prevConfig
	 * @param {boolean} prevIsOwned
	 * @returns {void}
	 */
	_resolveTableLookup(prevInst = null, prevConfig = null, prevIsOwned = false) {
		if (!this._config.tableLookup) {
			if (prevInst && prevIsOwned) {
				prevInst.destroy()
			}
			return
		}

		const id        = this._config.tableLookup
		const wrapperEl = document.getElementById(`${id}_wrapper`)
		if (!wrapperEl) {
			if (prevInst && prevIsOwned) {
				prevInst.destroy()
			}
			return
		}

		if (prevInst && prevConfig === id && prevIsOwned) {
			this._tableLookupInst    = prevInst
			this._isOwnedTableLookup = true
			prevInst.reset()
		} else {
			if (prevInst && prevIsOwned) {
				prevInst.destroy()
			}
			this._tableLookupInst    = new TableLookup(wrapperEl)
			this._isOwnedTableLookup = true
		}

		this._attachTableLookupEvents()
	}

	/**
	 * @returns {void}
	 */
	_attachTableLookupEvents() {
		if (this._config.columnRender) {
			Object.entries(this._config.columnRender).forEach(([col, fn]) => {
				this._tableLookupInst.table.on(`column render:${col}`, (data, rowData) => fn(data, rowData), `LookupInput:${col}`)
			})
		}

		this._tableLookupInst.on('choose', (selection, rows) => {
			this._onTableLookupChoose(selection, rows)
		}, "LookupInput")
	}

	/**
	 * @param {{ isSelectAll: boolean, selected: string[], excluded: string[] }} selection
	 * @param {Object[]} rows
	 * @returns {void}
	 */
	_onTableLookupChoose(selection, rows) {
		if (!rows || rows.length === 0) {
			return
		}

		if (this._isMultiple) {
			this.set(rows)
		} else {
			this.set(rows[0])
		}
	}

	// #endregion

	// #region Dropdown

	/**
	 * @returns {void}
	 */
	_positionDropdown() {
		const rect   = this._control.getBoundingClientRect()
		const dropH  = this._dropdown.offsetHeight || 280
		const below  = window.innerHeight - rect.bottom
		const openUp = below < dropH && rect.top > dropH

		Object.assign(this._dropdown.style, {
			position: 'fixed',
			left:     rect.left + 'px',
			width:    rect.width + 'px',
			zIndex:   '9999',
			top:      openUp ? 'auto' : (rect.bottom + 2) + 'px',
			bottom:   openUp ? (window.innerHeight - rect.top + 2) + 'px' : 'auto'
		})
	}

	// #endregion

	// #region Data

	/**
	 * @param {string} search
	 * @param {number} page
	 * @returns {void}
	 */
	_loadOptions(search, page) {
		this._currentPage = page

		if (this._config.data) {
			this._filterStaticData(search)
			return
		}

		if (!this._config.source) {
			return
		}

		if (this._config.minChars > 0 && search.length > 0 && search.length < this._config.minChars) {
			return
		}

		this._fetch(search, page)
	}

	/**
	 * @param {string} search
	 * @returns {void}
	 */
	_filterStaticData(search) {
		const data     = this._config.data || []
		const term     = search.toLowerCase()
		const filtered = term
			? data.filter(item => item.name.toLowerCase().includes(term))
			: data

		this._renderItems(filtered)
		this._detachSentinel()
	}

	/**
	 * @param {string} search
	 * @param {number} page
	 * @returns {Promise<void>}
	 */
	async _fetch(search, page) {
		const source       = this._config.source
		const extendSearch = this._config.extendSearch ?? null
		const orderBy      = this._config.orderBy ?? null

		// Check shared cache first (skip if using dynamic params)
		if (!this._config.param) {
			const cached = LookupInput._getCached(source, search, page, extendSearch, orderBy)
			if (cached) {
				this._hasMore = cached.hasMore
				if (page === 1) {
					this._renderItems(cached.items)
				} else {
					this._appendItems(cached.items)
				}
				if (this._config.pagination && this._hasMore) {
					this._attachSentinel()
				} else {
					this._detachSentinel()
				}
				return
			}
		}

		if (this._abortController) {
			this._abortController.abort()
		}
		this._abortController = new AbortController()

		this._setLoading(true)

		const body = { search, length: this._config.pageSize, page }

		if (this._config.extendColumns) {
			body.columns = this._config.extendColumns
		}

		if (extendSearch) {
			body.extendSearch = extendSearch
		}

		if (orderBy) {
			body.orderBy = orderBy
		}

		if (this._config.param) {
			Object.assign(body, this._config.param(body))
		}

		try {
			const res     = await axios.post(`${BASE_URL}/core/lookup`, body, {
				signal:  this._abortController.signal,
				headers: { 'X-Model': source }
			})
			const resData = res.data

			let items = this._config.pagination
				? (resData.results || [])
				: (Array.isArray(resData) ? resData : (resData.results || []))

			this._hasMore = resData.pagination?.more ?? false

			items = items.map(item => ({
				...item,
				name: item.name || item.text || item.displayValue?.value || ''
			}))

			// Store in shared cache (skip dynamic params — not safe to share)
			if (!this._config.param) {
				LookupInput._setCache(source, search, page, { items, hasMore: this._hasMore }, extendSearch, orderBy)
			}

			if (page === 1) {
				this._renderItems(items)
			} else {
				this._appendItems(items)
			}

			if (this._config.pagination && this._hasMore) {
				this._attachSentinel()
			} else {
				this._detachSentinel()
			}
		} catch (err) {
			if (axios.isCancel(err)) {
				return
			}
		} finally {
			this._setLoading(false)
		}
	}

	// #endregion

	// #region Rendering

	/**
	 * @param {boolean} on
	 * @returns {void}
	 */
	_setLoading(on) {
		this._list.classList.toggle('lki-loading', on)
	}

	/**
	 * @param {LookupItem[]} items
	 * @returns {void}
	 */
	_renderItems(items) {
		this._list.innerHTML = ''
		this._focusedIndex   = -1

		if (items.length === 0) {
			this._empty.style.display = ''
			return
		}

		this._empty.style.display = 'none'
		this._appendItems(items)
	}

	/**
	 * @param {LookupItem[]} items
	 * @returns {void}
	 */
	_appendItems(items) {
		const frag   = document.createDocumentFragment()
		const before = this._sentinel.parentNode === this._list ? this._sentinel : null

		items.forEach(item => {
			const li = this._createItemElement(item)
			frag.appendChild(li)
		})

		if (before) {
			this._list.insertBefore(frag, before)
		} else {
			this._list.appendChild(frag)
		}
	}

	/**
	 * @param {LookupItem} item
	 * @returns {HTMLLIElement}
	 */
	_createItemElement(item) {
		const li = document.createElement('li')
		li.className    = 'lki-item'
		li.dataset.id   = item.id
		li.dataset.name = item.name
		li._lkiData     = item

		if (this._config.optionsTemplate) {
			li.innerHTML = this._config.optionsTemplate(item)
		} else {
			li.textContent = item.name
		}

		const isSelected = this._isMultiple
			? this._isSelected(item.id)
			: (this._value && String(this._value.id) === String(item.id))

		if (isSelected) {
			li.classList.add('lki-selected')
		}

		li.addEventListener('click', () => this._selectItem(li))

		return li
	}

	/**
	 * @param {HTMLLIElement} el
	 * @returns {void}
	 */
	_selectItem(el) {
		const item = el._lkiData || { id: el.dataset.id, name: el.dataset.name }

		if (!this._isMultiple) {
			this.set(item)
			this.close()
			return
		}

		if (this._isSelected(item.id)) {
			this._removeItem(item.id)
			el.classList.remove('lki-selected')
		} else {
			this._addItem(item)
			el.classList.add('lki-selected')
		}

		this._searchInput.value = ''
		this._loadOptions('', 1)
		this._searchInput.focus()
	}

	/**
	 * @param {LookupItem} value
	 * @returns {void}
	 */
	_renderSelection(value) {
		const displayHtml = this._config.selectionTemplate
			? this._config.selectionTemplate(value)
			: (value.name || '')

		this._placeholder.style.display = 'none'

		if (this._selection) {
			this._selection.remove()
			this._selection = null
		}

		if (this._config.link?.url) {
			const target = this._config.link.target || '_blank'
			this._selection        = document.createElement('a')
			this._selection.href   = this._config.link.url(value)
			this._selection.target = target
			if (target === '_blank') {
				this._selection.rel = 'noopener noreferrer'
			}

			if (this._config.selectionTemplate) {
				this._selection.className = 'lki-selection lki-link lki-link--template'
				const contentSpan     = document.createElement('span')
				contentSpan.innerHTML = displayHtml
				const icon            = document.createElement('i')
				icon.className        = 'bi bi-box-arrow-up-right lki-link-icon'
				this._selection.appendChild(contentSpan)
				this._selection.appendChild(icon)
			} else {
				this._selection.className = 'lki-selection lki-link'
				this._selection.innerHTML = displayHtml
			}
		} else {
			this._selection = document.createElement('span')
			this._selection.className = 'lki-selection'
			this._selection.innerHTML = displayHtml
		}

		this._selection.title = value.name || ''

		// Hide selection while dropdown is open
		if (this._isOpen) {
			this._selection.style.display = 'none'
		}

		this._control.insertBefore(this._selection, this._searchInput)

		if (this._config.allowClear && !this._disabled) {
			this._clearBtn.style.display = ''
		}
		if (this._copyBtn && !this._disabled) this._copyBtn.style.display = ''
	}

	/**
	 * @returns {void}
	 */
	_renderPlaceholder() {
		if (this._selection) {
			this._selection.remove()
			this._selection = null
		}

		if (!this._isOpen) {
			this._placeholder.style.display = ''
		}

		this._clearBtn.style.display = 'none'
		if (this._copyBtn) this._copyBtn.style.display = 'none'
	}

	// #endregion

	// #region Multi-select

	/**
	 * @param {string|number} id
	 * @returns {boolean}
	 */
	_isSelected(id) {
		if (!this._value) {
			return false
		}

		return this._value.some(item => String(item.id) === String(id))
	}

	/**
	 * @returns {void}
	 */
	_renderTags() {
		this._tags.querySelectorAll('.lki-tag').forEach(tag => tag.remove())

		if (this._value && this._value.length > 0) {
			this._placeholder.style.display = 'none'
			this._value.forEach(item => {
				this._tags.insertBefore(this._renderTagItem(item), this._searchInput)
			})
			if (this._config.allowClear && !this._disabled) {
				this._clearBtn.style.display = ''
			}
			if (this._copyBtn && !this._disabled) this._copyBtn.style.display = ''
		} else {
			if (!this._isOpen) {
				this._placeholder.style.display = ''
			}
			this._clearBtn.style.display = 'none'
			if (this._copyBtn) this._copyBtn.style.display = 'none'
		}
	}

	/**
	 * @param {LookupItem} item
	 * @returns {HTMLSpanElement}
	 */
	_renderTagItem(item) {
		const tag = document.createElement('span')
		tag.className  = 'lki-tag'
		tag.dataset.id = item.id

		const text = document.createElement('span')
		text.className   = 'lki-tag-text'
		text.textContent = item.name || ''

		const removeBtn = document.createElement('button')
		removeBtn.type      = 'button'
		removeBtn.className = 'lki-tag-remove'
		removeBtn.innerHTML = '&times;'
		removeBtn.addEventListener('click', (e) => {
			e.stopPropagation()
			this._removeItem(item.id)
		})

		tag.appendChild(text)
		tag.appendChild(removeBtn)

		return tag
	}

	/**
	 * @param {LookupItem} item
	 * @returns {void}
	 */
	_addItem(item) {
		if (!this._value) {
			this._value = []
		}
		this._value = [...this._value, item]
		this._syncSelect(this._value)
		this._renderTags()
		this.trigger('change', this._value)
	}

	/**
	 * @param {string|number} id
	 * @returns {void}
	 */
	_removeItem(id) {
		if (!this._value) {
			return
		}

		this._value = this._value.filter(item => String(item.id) !== String(id))
		if (this._value.length === 0) {
			this._value = null
		}
		this._syncSelect(this._value)
		this._renderTags()
		this.trigger('change', this._value)
	}

	// #endregion

	// #region Pagination

	/**
	 * @returns {void}
	 */
	_attachSentinel() {
		if (!this._list.contains(this._sentinel)) {
			this._list.appendChild(this._sentinel)
		}

		if (!this._observer) {
			this._observer = new IntersectionObserver((entries) => {
				if (entries[0].isIntersecting && this._hasMore) {
					this._loadOptions(this._searchInput?.value || '', this._currentPage + 1)
				}
			}, { root: this._dropdown, threshold: 0.1 })
		}

		this._observer.observe(this._sentinel)
	}

	/**
	 * @returns {void}
	 */
	_detachSentinel() {
		if (this._observer) {
			this._observer.disconnect()
		}
		if (this._sentinel.parentNode) {
			this._sentinel.remove()
		}
	}

	// #endregion

	// #region Sync

	/**
	 * @param {LookupItem|LookupItem[]|null} value
	 * @returns {void}
	 */
	_syncSelect(value) {
		if (this._isDiv) {
			return
		}

		this._element.innerHTML = ''

		if (!value) {
			return
		}

		if (this._isMultiple && Array.isArray(value)) {
			value.forEach(item => {
				this._element.add(new Option(item.name || '', item.id, true, true))
			})
		} else if (!this._isMultiple && value) {
			this._element.add(new Option(value.name || '', value.id, true, true))
		}
	}

	/**
	 * @param {LookupItem|LookupItem[]|null} oldValue
	 * @param {LookupItem|LookupItem[]|null} newValue
	 * @returns {boolean}
	 */
	_valueChanged(oldValue, newValue) {
		if (!oldValue && !newValue) {
			return false
		}

		if (!oldValue || !newValue) {
			return true
		}

		if (this._isMultiple) {
			if (!Array.isArray(oldValue) || !Array.isArray(newValue)) {
				return true
			}

			if (oldValue.length !== newValue.length) {
				return true
			}
			const oldIds = oldValue.map(i => String(i.id)).sort()
			const newIds = newValue.map(i => String(i.id)).sort()
			return JSON.stringify(oldIds) !== JSON.stringify(newIds)
		}

		return String(oldValue.id) !== String(newValue.id)
	}

	// #endregion

	// #region Events

	/**
	 * @param {MouseEvent} e
	 * @returns {void}
	 */
	_handleDocumentClick(e) {
		if (!this._wrapper.contains(e.target) && !this._dropdown.contains(e.target)) {
			this.close()
		}
	}

	/**
	 * @param {KeyboardEvent} e
	 * @returns {void}
	 */
	_handleKeydown(e) {
		const items = this._list.querySelectorAll('.lki-item')

		if (e.key === 'ArrowDown') {
			e.preventDefault()
			this._focusedIndex = Math.min(this._focusedIndex + 1, items.length - 1)
			this._updateFocus(items)
		} else if (e.key === 'ArrowUp') {
			e.preventDefault()
			this._focusedIndex = Math.max(this._focusedIndex - 1, 0)
			this._updateFocus(items)
		} else if (e.key === 'Enter') {
			e.preventDefault()
			if (this._focusedIndex >= 0 && items[this._focusedIndex]) {
				this._selectItem(items[this._focusedIndex])
			}
		} else if (e.key === 'Escape' || e.key === 'Tab') {
			this.close()
		}
	}

	/**
	 * @param {NodeListOf<Element>} items
	 * @returns {void}
	 */
	_updateFocus(items) {
		items.forEach((item, i) => {
			item.classList.toggle('lki-focused', i === this._focusedIndex)
		})

		if (this._focusedIndex >= 0 && items[this._focusedIndex]) {
			items[this._focusedIndex].scrollIntoView({ block: 'nearest' })
		}
	}

	// #endregion

	// #region DOM

	/**
	 * @returns {void}
	 */
	_teardownDOM() {
		this.close()

		if (this._observer) {
			this._observer.disconnect()
			this._observer = null
		}

		if (this._wrapper?.parentNode) {
			this._wrapper.remove()
		}

		this._wrapper     = null
		this._control     = null
		this._placeholder = null
		this._selection   = null
		this._searchInput = null
		this._clearBtn    = null
		this._copyBtn     = null
		this._dropdown    = null
		this._list        = null
		this._empty       = null
		this._sentinel    = null
		this._tags        = null

		this._element.style.display = ''
	}

	// #endregion
}
