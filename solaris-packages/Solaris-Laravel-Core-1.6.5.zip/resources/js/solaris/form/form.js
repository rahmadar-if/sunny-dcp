import Helper from "../helper"
import axios from "@core-js/libs/axios"
import SelectInput from "./select-input"
import SelectMultipleInput from "./select-multiple-input"
import LookupInput from "./lookup-input"
import DatePicker from "./date-picker"
import OptionGroupInput from "./option-group-input"
import FieldInput from "./field-input"
import { AxiosError } from "axios"
import BaseInput from "./base-input"
import Model from "../model"
import Notes from "../notes/notes"
import StageButtons from "../stage/stage-button"
import TextInput from "./text-input"
import TextareaInput from "./textarea-input"
import DocumentEditor from "../document-editor"
import SolarComponent from "../solar/solar-component"
import CheckboxInput from "./checkbox-input"
import CardCheckboxInput from "./card-checkbox-input"
import CardOptionGroupInput from "./card-option-group-input"
import Toast from "../toast"
import SolarFactory from "../solar/solar-factory"

export default class Form extends SolarComponent {
    /** @type {Map<string, BaseInput>} */
    _fields = null
    #isActive = true

    /**
     * @param {string|HTMLFormElement} selector - CSS selector string or direct HTMLFormElement reference.
     * @throws {Error} If the selector does not resolve to a valid `<form>` element.
     * @throws {Error} If the resolved HTTP method is not POST, PUT, or PATCH.
     * @throws {Error} If both `action` and `method` are empty.
     */
    constructor(selector) {
        super()

        if (selector instanceof HTMLFormElement) {
            this._element = selector
        } else if (Helper.isString(selector) && !Helper.isEmpty(selector)) {
            this._element = document.querySelector(selector)
            if (!this._element) {
                throw new Error(`Element with query selector ${selector} is not found`)
            }

            if (!(this._element instanceof HTMLFormElement)) {
                throw new Error(`Selector is not Form Element`)
            }
        } else {
            throw new Error(`Selector is not Form Element`)
        }

        const hiddenMethod = this._element.querySelector(`input[type="hidden"][name="_method"]`)
        this._id = this._element.querySelector(`input[type="hidden"][name="_id"]`)?.value

        const method = this._element.method
        this._method = hiddenMethod ? hiddenMethod.value.toUpperCase() : method?.toUpperCase() ?? "POST"
        this._action = this._element.getAttribute("action") ?? ""

        if (!["POST", "PUT", "PATCH"].includes(this._method)) {
            throw new Error(`Method ${this._method} is not support`)
        }

        if (Helper.isEmpty(this._action) && Helper.isEmpty(this._method)) {
            throw new Error(`URL cannot be null or empty`)
        }

        this._successAlertMessage = "Data saved successfully"
        this._errorAlertMessage = "Oops! There was an error"
        this._showSuccessAlert = true
        this._showErrorAlert = true

        this._excludeFields = []
        this._validations = []
        this._customData = {}
        this._file = {}
        this._deferredProfilePictures = []
        this._deferredDropzones = []
        this._type = "json"
        this._model = this._element.getAttribute("model")
        this._parseModel = this._model ? Helper.parseShorthandModel(this._model) : null

        this._getAllComponents()

        this._element.addEventListener("submit", async (e) => {
            e.preventDefault()

            if (this.#isActive) {
                await this.submit()
            }
        })

        this._element.addEventListener("keypress", async (e) => {
            const target = e.target
            const isTextarea = target.tagName === 'TEXTAREA'
            const isNotes = target.tagName === 'DIV' && target.classList.contains('ql-editor')
            const isDocEditor = target.tagName === 'DIV' && target.classList.contains('ck') && target.classList.contains('ck-content')
            const isPreventEl = isTextarea || isNotes || isDocEditor

            if (e.key === 'Enter' && !e.shiftKey) {
                if (this.#isActive && !isPreventEl) {
                    e.preventDefault()
                    await this.submit()
                }
            }
        })
    }

    /**
     * Returns all supported event names for this component.
     * @returns {string[]}
     */
    static supportedEvent() {
        return [
            "submitting", // before form process
            "validating", // before doing client validation
            "invalid", // client validation failed
            "validated", // client validation success
            "sending", // doing request to server
            "failed", // server validation failed
            "error", // something wrong in server
            "success", // process submit is success
        ]
    }

    /**
     * Check whether the form is in edit mode (PUT or PATCH).
     * @returns {boolean}
     */
    isEdit() {
        return ["PUT", "PATCH"].includes(this._method)
    }

    /**
     * Switch form to edit mode.
     * @param {{type?: string, id?: string|null}} config
     * @param {string} [config.type="PUT"] - HTTP method to use. Accepts "PUT" or "PATCH".
     * @param {string|null} [config.id=null] - Record ID to update.
     * @returns {void}
     */
    editMode({ type = "PUT", id = null }) {
        this._method = type
        this._id = id
    }

    /**
     * Switch form to new mode (POST).
     * Clears the current record ID.
     * @returns {void}
     */
    newMode() {
        this._method = "POST"
        this._id = null
    }

    /**
     * Get the current record ID.
     * @returns {string|undefined}
     */
    getId() {
        return this._id
    }

    /**
     * Set the current record ID.
     * @param {string} id
     * @returns {void}
     */
    setId(id) {
        this._id = id
    }

    /**
     * Enable form submission (default state).
     * @returns {Form}
     */
    active() {
        this.#isActive = true
        return this
    }

    /**
     * Disable form submission. Submit and Enter key will have no effect.
     * @returns {Form}
     */
    nonactive() {
        this.#isActive = false
        return this
    }

    /**
     * Exclude one or more fields from being processed during submit.
     * Pass `null` to clear all exclusions.
     * @param {string|string[]|null} fieldName - Field name, array of field names, or `null` to reset.
     * @returns {Form}
     */
    exclude(fieldName) {
        if (fieldName == null) {
            this._excludeFields = []
        } else if (Helper.isString(fieldName)) {
            this._excludeFields.push(fieldName)
        } else if (Array.isArray(fieldName)) {
            this._excludeFields = this._excludeFields.concat(fieldName)
        }

        return this
    }

    /**
     * Validate all fields, build the request payload, and send it to the server.
     * Triggers events in order: `submitting` → `validating` → `invalid|validated` → `sending` → `failed|error|success`.
     * @param {boolean} [showAlert=true] - Whether to show success/error alert after submission.
     * @returns {Promise<boolean>} `true` if submission succeeded, `false` otherwise.
     */
    async submit(showAlert = true) {
        Helper.loadingPage(true)

        const enabledFields = new Map()

        let res = null
        let pendingEvent = null

        try {
            await this.trigger("submitting")

            const fields = this._getAllField()
            fields.forEach((field, key) => {
                if (!(typeof field["isDisabled"] === "function")) {
                    return
                }

                if (!field.isDisabled()) {
                    enabledFields.set(key, field)
                }
            })

            this.disabled(enabledFields)
            this.nonactive()

            await this.trigger("validating", fields)

            const validation = await this.validation(fields)
            if (!validation.success) {
                this.setErrors(validation.errors, fields)
                Helper.toast({ message: "Some fields are invalid or incomplete. Please check again.", color: "danger", position: Toast.Position.BottomCenter })
                pendingEvent = { name: "invalid", args: [validation] }

                return false
            }

            await this.trigger("validated")

            if (this._type.toLowerCase() == 'form-data' && this.isEdit()) {
                if (this.isEdit()) {
                    this.addData("_method", "PUT")
                } else {
                    this.deleteData("_method")
                }
            }

            let data = this.getData(fields)
            if (Helper.isEmpty(data)) {
                throw new Error(`Data cannot be null or empty`)
            }

            let action, header
            if (Helper.isEmpty(this._action) && this._model) {
                action = this.isEdit() && this._id ? `core/form/${this._id}` : "core/form"
                header = { 'X-Model': this._parseModel.model }
            } else {
                action = this._action
            }

            const config = {
                method: this._type.toLowerCase() == 'form-data' ? "POST" : this._method,
                url: Helper.isEmpty(this._action) ? `${BASE_URL}/${action}` : action,
                data: data
            }

            if (header) {
                config.headers = header
            }

            await this.trigger("sending", config)

            const req = await axios(config)
            res = req.data
            if (!res.success) {
                if (res.message && !Helper.isEmpty(res.message)) {
                    throw new Error(res.message)
                }

                if (res.errors) {
                    this.setErrors(res.errors, fields)
                    pendingEvent = { name: "failed", args: [res.errors, res.message] }

                    return false
                }

                throw res
            }

            const pendingPPs = this._deferredProfilePictures.filter(pp => pp.instance.hasPendingCrop())
            const [ppResults, dzResults] = await Promise.all([
                Promise.all(
                    pendingPPs.map(pp => pp.instance.upload(pp.urlResolver(res), true))
                ),
                Promise.all(
                    this._deferredDropzones
                        .filter(dz => dz.instance.hasPendingFiles())
                        .map(dz => dz.instance.upload(dz.configResolver(res)))
                )
            ])

            pendingPPs.forEach(pp => pp.instance.emptyPreview())

            if (ppResults.some(s => !s)) {
                Helper.toast({ message: "Profile picture failed to upload", color: "warning", position: Toast.Position.BottomCenter })
            }

            if (dzResults.some(s => !s)) {
                Helper.toast({ message: "File upload failed", color: "warning", position: Toast.Position.BottomCenter })
            }

            if (this._showSuccessAlert && showAlert) {
                Helper.successAlert({ title: this._successAlertMessage })
            }

            pendingEvent = { name: "success", args: [res] }
        } catch (error) {
            let errorMessage = error
            if (error instanceof AxiosError) {
                errorMessage = error.response?.data?.message
            } else if (error instanceof Error) {
                errorMessage = error.message
            }

            if (this._showErrorAlert) {
                Helper.errorAlert({
                    title: this._errorAlertMessage,
                    message: Helper.isString(errorMessage) ? errorMessage : 'Please contact your system admin',
                    timeout: null
                })
            }

            pendingEvent = { name: "error", args: [error] }

            return false
        } finally {
            this.enabled(enabledFields)
            this.active()

            if (pendingEvent) {
                await this.trigger(pendingEvent.name, ...pendingEvent.args)
            }

            Helper.loadingPage(false)
        }

        return true
    }

    /**
     * Fetch model data from server by ID using the model configured on this form.
     * @param {string} id - Record ID to fetch.
     * @returns {Promise<Object>} The model data object.
     */
    async getModelData(id) {
        return await Model.get(this._parseModel.controller ? `${this._parseModel.model}:${this._parseModel.controller}` : this._parseModel.model, id)
    }

    /**
     * Populate form fields with data from an object or by fetching from the server using an ID.
     * Resets all fields before loading.
     * @param {string|Object} data - Plain object to populate directly, or a record ID string to fetch from the model.
     * @param {boolean} [isSilent=false] - If `true`, field change events are suppressed during population.
     * @param {Map<string, BaseInput>|null} [_fields=null] - Specific field subset to populate. Defaults to all fields.
     * @returns {Promise<Object>} The resolved data object that was loaded into the form.
     */
    async load(data, isSilent = false, _fields = null) {
        this.reset(true, _fields)

        try {
            Helper.loadingPage(true)
            if (this._model && Helper.isString(data)) {
                data = await this.getModelData(data)
            }

            const fields = _fields ? _fields : this._getAllField()
            fields.forEach((value, key) => {
                try {
                    if (!data.hasOwnProperty(key)) {
                        return
                    }

                    const isField = value instanceof FieldInput
                    const isFieldLookup = isField && (value._plugin instanceof LookupInput || value._plugin instanceof OptionGroupInput)
                    const isStage = value instanceof StageButtons
                    const isLookupValue = isFieldLookup || value instanceof LookupInput || value instanceof OptionGroupInput || isStage

                    if (isLookupValue && key.endsWith("_id")) {
                        const keyWitoutId = key.substring(0, key.length - 3)
                        const lookupValue = data[keyWitoutId]
                        if (!lookupValue) {
                            return
                        }

                        if (isStage) {
                            value.set(lookupValue.id, isSilent)
                        } else if (!lookupValue.hasOwnProperty("name") && lookupValue.hasOwnProperty("displayValue") && lookupValue.displayValue?.value) {
                            value.set({ id: lookupValue.id, name: lookupValue.displayValue.value }, isSilent)
                        } else {
                            value.set(lookupValue, isSilent)
                        }

                        return
                    }

                    value.set(data[key], isSilent)
                } catch (error) {
                    console.warn(`${key} is error`, { error })
                }
            })
        } catch (error) {
            console.error("Error when load form with data", { error })
        } finally {
            Helper.loadingPage(false)
        }

        return data
    }

    /**
     * Reset all fields to their default/empty state.
     * @param {boolean} [isSilent=false] - If `true`, field change events are suppressed during reset.
     * @param {Map<string, BaseInput>|null} [_fields=null] - Specific field subset to reset. Defaults to all fields.
     * @returns {void}
     */
    reset(isSilent = false, _fields = null) {
        const fields = _fields ? _fields : this._getAllField()
        fields.forEach(field => {
            field.reset(isSilent)
        })
    }

    /**
     * Disable all fields (or a specific subset).
     * Only fields that implement a `disabled()` method are affected.
     * @param {Map<string, BaseInput>|null} [_fields=null] - Specific field subset to disable. Defaults to all fields.
     * @returns {void}
     */
    disabled(_fields = null) {
        const fields = _fields ? _fields : this._getAllField()
        fields.forEach(field => {
            if (!(typeof field["disabled"] === "function")) {
                return
            }

            field.disabled()
        })
    }

    /**
     * Enable all fields (or a specific subset).
     * Only fields that implement an `enabled()` method are affected.
     * @param {Map<string, BaseInput>|null} [_fields=null] - Specific field subset to enable. Defaults to all fields.
     * @returns {void}
     */
    enabled(_fields = null) {
        const fields = _fields ? _fields : this._getAllField()
        fields.forEach(field => {
            if (!(typeof field["enabled"] === "function")) {
                return
            }

            field.enabled()
        })
    }

    //#region Validation

    /**
     * Set validation error state on fields.
     * Pass `null` as `errors` to clear all field validation errors.
     * @param {Object|null} errors - Key-value map of field name → error message. Pass `null` to reset all.
     * @param {Map<string, BaseInput>|null} [_fields=null] - Specific field subset. Defaults to all fields.
     * @returns {void}
     * @throws {Error} If `errors` is not an object (and not null).
     */
    setErrors(errors, _fields = null) {
        const fields = _fields ? _fields : this._getAllField()
        if (errors === null) {
            fields.forEach(field => {
                if (!(typeof field["resetValidation"] === "function")) {
                    return
                }

                field.resetValidation()
            })

            return
        }

        if (!Helper.isObject(errors)) {
            throw new Error("Errors must be object")
        }

        for (const error in errors) {
            if (fields.has(error)) {
                const field = fields.get(error)
                if (typeof field["error"] === "function") {
                    field.error()
                }

                if (field instanceof FieldInput) {
                    field.setMessage(errors[error])
                }
            }
        }
    }

    /**
     * Add a custom async validation callback for a specific field.
     * Multiple validations can be registered for the same field — they run in order.
     * @param {string} key - The field name/id to attach the validation to.
     * @param {(value: *) => Promise<{success: boolean, message: string}>} callback - Validation function.
     * @returns {Form}
     */
    addValidation(key, callback) {
        const index = this._validations.findIndex(item => item.id == key)
        if (index == -1) {
            this._validations.push({
                id: key,
                validations: [callback]
            })
        } else {
            this._validations[index].validations.push(callback)
        }

        return this
    }

    /**
     * Run all validations: required check + custom validations registered via `addValidation()`.
     * @param {Map<string, BaseInput>|null} [_fields=null] - Field subset to validate. Defaults to all fields.
     * @returns {Promise<{success: boolean, errors: Object|null}>}
     *   `success` is `false` if any validation failed.
     *   `errors` is a key-value map of field name → combined error message string, or `null` if all passed.
     */
    async validation(_fields = null) {
        const errors = []
        const result = {
            success: true,
            errors: null
        }

        const fields = _fields ? _fields : this._getAllField()
        fields.forEach(field => {
            if (!(typeof field["isRequired"] === "function")) {
                return
            }

            if (field.isRequired()) {
                const requiredValidation = this._requiredValidation(field)
                if (!requiredValidation.success) {
                    result.success = false
                    errors.push({
                        id: field._bindTo ?? field._id,
                        errors: [requiredValidation.message]
                    })
                }
            }
        })

        for (let i = 0; i < this._validations.length; i++) {
            const item = this._validations[i]
            const id = item.id

            try {
                if (!fields.has(id)) {
                    console.warn(`Field ${id} not found`)
                    continue
                }

                const field = fields.get(id)
                const value = field.get()
                const validations = item.validations
                for (let j = 0; j < validations.length; j++) {
                    const validation = validations[j]
                    const validationResult = await validation(value)
                    const isValid = validationResult.success
                    const message = validationResult.message

                    if (!isValid) {
                        result.success = false

                        const index = errors.findIndex(e => e.id == id)
                        if (index == -1) {
                            errors.push({
                                id: field._bindTo ?? field._id,
                                errors: [message]
                            })
                        } else {
                            errors[index].errors.push(message)
                        }
                    }
                }
            } catch (error) {
                console.error(`Error when processing validation ${id}`, { error })
                continue
            }
        }

        if (!result.success && errors.length > 0) {
            result.errors = {}
            errors.forEach(e => {
                result.errors[e.id] = e.errors.join(". ")
            })
        }

        return result
    }

    /**
     * Internal required-field validation.
     * Checks if the field's current value is non-empty.
     * @param {BaseInput} field - The field to validate.
     * @returns {{success: boolean, message: string|null}} `message` is `null` if valid.
     */
    _requiredValidation(field) {
        const value = field.get()
        const message = field instanceof FieldInput ? `${field.getLabel()} is required` : "This field is required"
        const isValid = !Helper.isEmpty(value)

        return {
            success: isValid,
            message: isValid ? null : message
        }
    }

    //#endregion

    //#region Data

    /**
     * Get a registered field component instance by key.
     * @param {string} key - The field name/id.
     * @returns {BaseInput|null} The field instance, or `null` if not found.
     */
    get(key) {
        if (this._fields.has(key)) {
            return this._fields.get(key)
        }

        console.warn(`${key} is not registred in form`)

        return null
    }

    /**
     * Get the current value of a field by key.
     * @param {string} key - The field name/id.
     * @returns {*} The field's current value, or `null` if the field is not found.
     */
    getValue(key) {
        return this.get(key)?.get() ?? null
    }

    /**
     * Set a field's value by key.
     * @param {string} key - The field name/id.
     * @param {*} value - The value to set.
     * @param {boolean} [isSilent=false] - If `true`, suppresses change events.
     * @returns {void}
     */
    set(key, value, isSilent = false) {
        if (this._fields.has(key)) {
            this._fields.get(key).set(value, isSilent)
        } else {
            console.warn(`${key} is not registred in form`)
        }

        return this
    }

    /**
     * Switch data submission type to `multipart/form-data`.
     * Required when the form includes file uploads.
     * @returns {Form}
     */
    setToFormData() {
        this._type = 'form-data'
        return this
    }

    /**
     * Switch data submission type to JSON (default).
     * @returns {Form}
     */
    setToJson() {
        this._type = 'json'
        return this
    }

    /**
     * Get the serialized form data in the current type format (`json` or `form-data`).
     * @param {Map<string, BaseInput>|null} [_fields=null] - Field subset to serialize. Defaults to all fields.
     * @returns {Object|FormData|null} Serialized data, or `null` if type is not recognized.
     */
    getData(_fields = null) {
        const fields = _fields ? _fields : this._getAllField()
        if (this._type.toLowerCase() == 'json') {
            return this._getJson(fields)
        }

        if (this._type.toLowerCase() == 'form-data') {
            return this._getFormData(fields)
        }

        return null
    }

    /**
     * Internal: Serialize fields as a plain JSON object.
     * Handles special field types (Select, Lookup, DatePicker, Notes, etc.) with their appropriate value format.
     * @param {Map<string, BaseInput>} fields
     * @returns {Object}
     */
    _getJson(fields) {
        const data = {}
        fields.forEach((field, id) => {
            const component = field instanceof FieldInput ? field._plugin : field
            const value = field.get()

            if ((component instanceof SelectInput) && !(component instanceof SelectMultipleInput)) {
                data[id] = value?.id ?? null
            } else if (component instanceof SelectMultipleInput) {
                data[id] = value?.map(val => val.id) ?? null
            } else if ((component instanceof LookupInput && !component._isMultiple) || component instanceof StageButtons) {
                data[id] = value?.id ?? null
            } else if (component instanceof LookupInput && component._isMultiple) {
                data[id] = value ? value.map(val => val.id) : null
            } else if (component instanceof OptionGroupInput && component._type == 'radio') {
                data[id] = value?.id ?? null
            } else if (component instanceof OptionGroupInput && component._type == 'checkbox') {
                data[id] = value ?? null
            } else if (component instanceof DatePicker) {
                data[id] = component.toString()
            } else if (component instanceof Notes) {
                data[id] = component.getRaw()
            } else {
                data[id] = value
            }
        })

        for (const cData in this._customData) {
            data[cData] = this._customData[cData]
        }

        return data
    }

    /**
     * Internal: Serialize fields as a `FormData` object.
     * Handles special field types and appends custom data and files.
     * @param {Map<string, BaseInput>} fields
     * @returns {FormData}
     */
    _getFormData(fields) {
        const data = new FormData()
        fields.forEach((field, id) => {
            const component = field instanceof FieldInput ? field._plugin : field
            const value = field.get() ?? ""

            if ((component instanceof SelectInput) && !(component instanceof SelectMultipleInput)) {
                data.append(id, value?.id ?? "")
            } else if (component instanceof SelectMultipleInput) {
                const selectMultiValue = value?.map(val => val.id) ?? ""
                data.append(id, selectMultiValue ? JSON.stringify(selectMultiValue) : "")
            } else if ((component instanceof LookupInput && !component._isMultiple) || component instanceof StageButtons) {
                data.append(id, value?.id ?? "")
            } else if (component instanceof LookupInput && component._isMultiple) {
                data.append(id, value ? JSON.stringify(value.map(val => val.id)) : "")
            } else if (component instanceof OptionGroupInput && component._type == 'radio') {
                data.append(id, value?.id ?? "")
            } else if (component instanceof OptionGroupInput && component._type == 'checkbox') {
                data.append(id, !value ? "" : JSON.stringify(component._options.map(opt => {
                    return {
                        id: opt._element.id,
                        checked: opt.get()
                    }
                })))
            } else if (component instanceof DatePicker) {
                const datePickerValue = component.toString()
                data.append(id, Array.isArray(datePickerValue) ? JSON.stringify(datePickerValue) : datePickerValue)
            } else if (component instanceof Notes) {
                data[id] = component.getRaw()
            } else {
                data.append(id, value)
            }
        })

        for (const cData in this._customData) {
            data.append(cData, this._customData[cData])
        }

        for (const fData in this._file) {
            data.append(fData, this._file[fData].file, this._file[fData].filename)
        }

        if (this._method) {
            data.append("_method", this._method)
        }

        return data
    }

    /**
     * Add extra data to be included in the request payload.
     * Cannot use a key that is already registered as a form field.
     * @param {string} key - Data key.
     * @param {*} value - Data value.
     * @returns {Form}
     * @throws {Error} If `key` is already registered as a form field.
     */
    addData(key, value) {
        if (this._fields.has(key)) {
            throw new Error(`Cannot add ${key} because it is already registered`)
        }

        this._customData[key] = value
        return this
    }

    /**
     * Attach a file to be sent with the form (requires `form-data` type).
     * Cannot use a key that is already registered as a form field.
     * @param {string} key - FormData field name.
     * @param {File} file - The file object to upload.
     * @param {string} filename - The filename to send.
     * @returns {Form}
     * @throws {Error} If `key` is already registered as a form field.
     */
    addFile(key, file, filename) {
        if (this._fields.has(key)) {
            throw new Error(`Cannot add ${key} because it is already registered`)
        }

        this._file[key] = { file: file, filename: filename }
        return this
    }

    /**
     * Delete one or more custom data entries added via `addData()`.
     * @param {string|string[]} key - Key or array of keys to remove.
     * @returns {Form}
     */
    deleteData(key) {
        if (Helper.isString(key) && this._customData.hasOwnProperty(key)) {
            delete this._customData[key]
        } else if (Array.isArray(key) && key.length > 0) {
            key.forEach(k => {
                if (this._customData.hasOwnProperty(k)) {
                    delete this._customData[k]
                }
            })
        }

        return this
    }

    /**
     * Delete one or more file entries added via `addFile()`.
     * @param {string|string[]} key - Key or array of keys to remove.
     * @returns {Form}
     */
    deleteFile(key) {
        if (Helper.isString(key) && this._file.hasOwnProperty(key)) {
            delete this._file[key]
        } else if (Array.isArray(key) && key.length > 0) {
            key.forEach(k => {
                if (this._file.hasOwnProperty(k)) {
                    delete this._file[k]
                }
            })
        }

        return this
    }

    /**
     * Get all registered fields, optionally filtering out excluded fields.
     * @param {boolean} [excludeField=true] - If `true`, fields in `_excludeFields` are filtered out.
     * @returns {Map<string, BaseInput>}
     */
    _getAllField(excludeField = true) {
        if (this._excludeFields.length == 0 || !excludeField) {
            return this._fields
        }

        return new Map(
            [...this._fields].filter(([key]) => !this._excludeFields.includes(key))
        )
    }

    //#endregion

    //#region Alert

    /**
     * Set the success alert message shown after successful submission.
     * @param {string} message - Non-empty string.
     * @returns {Form}
     * @throws {Error} If `message` is not a string or is empty.
     */
    setSuccessMessage(message) {
        if (!Helper.isString(message)) {
            throw new Error("Message must be string")
        }

        if (Helper.isEmpty(message)) {
            throw new Error("Message cannot be empty or null")
        }

        this._successAlertMessage = message
        return this
    }

    /**
     * Set the error alert message shown when submission fails.
     * @param {string} message - Non-empty string.
     * @returns {Form}
     * @throws {Error} If `message` is not a string or is empty.
     */
    setErrorMessage(message) {
        if (!Helper.isString(message)) {
            throw new Error("Message must be string")
        }

        if (Helper.isEmpty(message)) {
            throw new Error("Message cannot be empty or null")
        }

        this._errorAlertMessage = message
        return this
    }

    /**
     * Enable the success alert on submit completion (default: enabled).
     * @returns {Form}
     */
    showSuccessAlert() {
        this._showSuccessAlert = true
        return this
    }

    /**
     * Disable the success alert on submit completion.
     * @returns {Form}
     */
    hiddenSuccessAlert() {
        this._showSuccessAlert = false
        return this
    }

    /**
     * Enable the error alert on submit failure (default: enabled).
     * @returns {Form}
     */
    showErrorAlert() {
        this._showErrorAlert = true
        return this
    }

    /**
     * Disable the error alert on submit failure.
     * @returns {Form}
     */
    hiddenErrorAlert() {
        this._showErrorAlert = false
        return this
    }

    //#endregion

    //#region Deferred Uploads

    /**
     * Register a ProfilePicture instance for deferred upload after form submission.
     * After the main form request succeeds, the form will call `instance.upload(url, true)`
     * if the user has a pending crop. On failure, a toast is shown and the success flow continues.
     * Multiple instances are uploaded in parallel.
     * @param {ProfilePicture} instance
     * @param {(res: Object) => string} urlResolver - Callback that receives the server response and returns the upload URL.
     * @returns {Form}
     * @example
     * this.form.registerProfilePicture(
     *     this.profilePicture,
     *     (res) => `${BASE_URL}/master-data/account/avatar/${res.data.id}`
     * )
     */
    registerProfilePicture(instance, urlResolver) {
        this._deferredProfilePictures.push({ instance, urlResolver })
        return this
    }

    /**
     * Register a DropzoneUpload instance for deferred upload after form submission.
     * After the main form request succeeds, the form will call `instance.upload(config)`
     * if the dropzone has queued files. On failure, a toast is shown and the success flow continues.
     * Multiple instances are uploaded in parallel.
     * @param {DropzoneUpload} instance
     * @param {(res: Object) => { url?: string, recordId?: string, tableName?: string }} configResolver - Callback that receives the server response and returns the upload config.
     * @returns {Form}
     * @example
     * // Standard core/attachment endpoint — recordId injected into request body
     * this.form.registerDropzone(
     *     this.dropzone,
     *     (res) => ({ recordId: res.data.id })
     * )
     *
     * @example
     * // Custom upload URL
     * this.form.registerDropzone(
     *     this.dropzone,
     *     (res) => ({ url: `${BASE_URL}/some-module/upload/${res.data.id}` })
     * )
     */
    registerDropzone(instance, configResolver) {
        this._deferredDropzones.push({ instance, configResolver })
        return this
    }

    //#endregion

    /**
     * Scan the form element for all supported Solar UI components and register them into `_fields`.
     * Called once in the constructor.
     * @returns {void}
     */
    _getAllComponents() {
        this._fields = new Map()

        const standaloneGuard = (el) => !el.closest('div[solar-id][solar-ui="field"]')
        const standaloneOptionGuard = (el) => standaloneGuard(el) &&
            !el.closest('div[solar-ui="input:radio-group"]') &&
            !el.closest('div[solar-ui="input:checkbox-group"]')
        const standaloneCardOptionGuard = (el) => standaloneGuard(el) &&
            !el.closest('div[solar-ui="input:radio-card-group"]') &&
            !el.closest('div[solar-ui="input:checkbox-card-group"]')

        const components = [
            {
                selector: 'input[solar-ui]:not([solar-ui="input:checkbox"]):not([solar-ui="input:radio"]):not([solar-ui="input:radio-card"]):not([solar-ui="input:checkbox-card"])',
                component: TextInput,
                guard: standaloneGuard,
                factory: SolarFactory.inputFactory
            },
            {
                selector: 'input[solar-ui="input:checkbox"], input[solar-ui="input:radio"]',
                component: CheckboxInput,
                guard: standaloneOptionGuard,
                factory: SolarFactory.optionFactory
            },
            {
                selector: 'select[solar-ui]',
                component: SelectInput,
                guard: standaloneGuard,
                factory: SolarFactory.selectFactory
            },
            {
                selector: 'div[solar-ui="lookup"]',
                component: LookupInput,
                guard: standaloneGuard,
            },
            {
                selector: 'textarea[solar-ui]',
                component: TextareaInput,
                guard: standaloneGuard,
                factory: SolarFactory.textareaFactory
            },
            {
                selector: 'div[solar-ui="input:radio-group"][solar-id], div[solar-ui="input:checkbox-group"][solar-id]',
                component: OptionGroupInput,
                guard: standaloneGuard,
                factory: SolarFactory.optionGroupFactory
            },
            {
                selector: 'input[solar-ui="input:radio-card"], input[solar-ui="input:checkbox-card"]',
                component: CardCheckboxInput,
                guard: standaloneCardOptionGuard,
                factory: SolarFactory.cardOptionFactory
            },
            {
                selector: 'div[solar-ui="input:radio-card-group"][solar-id], div[solar-ui="input:checkbox-card-group"][solar-id]',
                component: CardOptionGroupInput,
                guard: standaloneGuard,
                factory: SolarFactory.cardOptionGroupFactory
            },
            {
                selector: 'div[solar-id][solar-ui="field"]',
                component: FieldInput
            },
            {
                selector: 'div[solar-ui="notes"]',
                component: Notes
            },
            {
                selector: 'div[solar-ui="document-editor"]',
                component: DocumentEditor
            },
            {
                selector: 'div[solar-ui="stages"]',
                component: StageButtons,
                factory: (el, component) => {
                    const stageComponent = new component(el)

                    setTimeout(() => stageComponent.on("change:after", async () => await this.submit(), "Form"), 100)

                    return stageComponent
                }
            }
        ]

        components.forEach(item => {
            this._element.querySelectorAll(item.selector).forEach(el => {
                const ui = SolarFactory.initialize(el, item.component, item.guard ?? null, item.factory ?? null)
                if (ui) {
                    const id = ui.bindTo ?? ui.id
                    this._fields.set(id, ui.component)
                }
            })
        })
    }
}
