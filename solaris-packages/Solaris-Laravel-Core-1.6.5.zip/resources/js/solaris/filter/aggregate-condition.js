export default class AggregateCondition {

	/**
	 * @param {string} logical
	 * @param {string} aggregate - aggregate type: count, sum, avg, min, max
	 * @param {string} operator
	 * @param {string} left - relation or relation.column
	 * @param {number} right
	 */
	constructor(logical, aggregate, operator, left, right) {
		this.logical = logical
		this.aggregate = aggregate
		this.operator = operator
		this.conditions = {
			left: left,
			right: right
		}
	}
}
