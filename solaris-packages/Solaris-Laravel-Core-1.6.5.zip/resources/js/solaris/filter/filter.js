import AggregateCondition from "./aggregate-condition"
import Condition from "./condition"
import Group from "./group"
import Helper from "../helper"
import FilterConstants from "./filter-constants"

const { LogicalType, OperatorType, PeriodUnit, AggregateType, MULTI_WORD_OPERATORS, SINGLE_OPERATORS, LOGICAL_KEYWORDS, OPERATOR_MAP, NULLARY_OPERATORS } = FilterConstants

export default class Filter {
	_filters = []

	/**
	 * Sentinel value for date-part filters — use current date's month/day/year instead of a literal.
	 * Pass as the value argument to andMonth, andDay, andYear, andMonthDay, and their or-variants.
	 * @example filter.andMonthDay('birthdate', Filter.Now)  // birthday today
	 * @example filter.andYear('created_at', Filter.Now)     // this year
	 */
	static Now = Object.freeze({ source: 'now' })

	/**
	 * @param {string|string[]|object[]|null} source - filter source, accepts:
	 *   - string: filter expression e.g. "status = active, age > 10"
	 *   - string: JSON string e.g. '[{"logical":"AND","conditions":{"left":"name","right":"udin"},"operator":"EQUAL"}]'
	 *   - string[]: array of filter expressions e.g. ["status = active", "age > 10"]
	 *   - object[]: array of pre-built filter objects (passed through directly)
	 */
	constructor(source = null) {
		if (Helper.isEmpty(source)) return

		source = this._tryParseJson(source)

		if (Helper.isString(source)) {
			this._filters = this._processPipeline(source)
			return
		}

		if (Array.isArray(source) && source.every(s => Helper.isString(s))) {
			this._filters = source.flatMap(raw => this._processPipeline(raw))
			return
		}

		if (Array.isArray(source)) {
			this._filters = source
		}
	}

	_tryParseJson(source) {
		if (!Helper.isString(source)) return source

		try {
			return JSON.parse(source)
		} catch (error) {
			return source
		}
	}

	_processPipeline(raw) {
		const tokens = this._tokenizeString(raw)
		const parsed = this._parseToken(tokens)
		return this._normalizeToken(parsed)
	}

	_tokenizeString(input) {
		const tokens = []
		let i = 0

		const isBoundary = (ch) => ch == null || /[\s(),\[\]]/.test(ch)

		const skipWhitespace = () => {
			while (/\s/.test(input[i])) i++
		}

		const readWhile = (condition) => {
			let start = i
			while (i < input.length && condition(input[i])) i++
			return input.slice(start, i)
		}

		const matchKeyword = (keywords) => {
			for (const kw of keywords) {
				const kwLower = kw.toLowerCase()
				const end = i + kw.length

				if (input.slice(i, end).toLowerCase() !== kwLower) continue

				const before = i === 0 ? null : input[i - 1]
				const after = end >= input.length ? null : input[end]

				if (!isBoundary(before) || !isBoundary(after)) continue

				i = end
				return kw
			}

			return null
		}

		const readQuoted = () => {
			const quote = input[i++]
			let value = ''
			while (i < input.length && input[i] !== quote) {
				if (input[i] === '\\') {
					i++;
					if (i < input.length) {
						value += input[i++]
					}
				} else {
					value += input[i++]
				}
			}
			i++
			return value
		}

		const readBracketList = () => {
			i++
			let content = ''
			while (i < input.length && input[i] !== ']') {
				content += input[i++]
			}
			i++
			return content
		}

		const tokenizeSingleOperator = () => {
			for (const op of SINGLE_OPERATORS) {
				if (input.slice(i, i + op.length) !== op) continue

				tokens.push({ type: 'operator', value: op })
				i += op.length
				return true
			}
			return false
		}

		const tokenizeIdentifierOrValue = () => {
			const word = readWhile(ch => /[a-zA-Z0-9._-]/.test(ch))
			if (!word) return false

			const prev = tokens[tokens.length - 1]
			const type = (prev && prev.type === 'operator') ? 'value' : 'identifier'
			tokens.push({ type, value: word })
			return true
		}

		while (i < input.length) {
			skipWhitespace()
			if (i >= input.length) break

			const ch = input[i]

			if (ch === '(' || ch === ')') {
				tokens.push({ type: 'paren', value: ch })
				i++
				continue
			}

			if (ch === ',') {
				tokens.push({ type: 'logical', value: 'AND' })
				i++
				continue
			}

			const logical = matchKeyword(LOGICAL_KEYWORDS);
			if (logical) {
				tokens.push({ type: 'logical', value: logical.toUpperCase() })
				continue
			}

			const multiOp = matchKeyword(MULTI_WORD_OPERATORS);
			if (multiOp) {
				tokens.push({ type: 'operator', value: multiOp.toLowerCase() });
				continue;
			}

			if (tokenizeSingleOperator()) continue

			if (ch === '"' || ch === "'") {
				const value = readQuoted()
				tokens.push({ type: 'value', value })
				continue
			}

			if (ch === '[') {
				const value = readBracketList()
				const list = value
					.split(',')
					.map(v => v.trim().replace(/^['"]|['"]$/g, ''))
				tokens.push({ type: 'value', value: list })
				continue
			}

			if (tokenizeIdentifierOrValue()) continue

			i++
		}

		return tokens
	}

	_parseToken(tokens) {
		let i = 0;

		const next = (expectedType) => {
			const token = tokens[i++]
			if (!token) {
				throw new Error(`Unexpected end of tokens${expectedType ? `, expected ${expectedType}` : ''}`)
			}
			if (expectedType && token.type !== expectedType) {
				throw new Error(`Expected token type '${expectedType}', got '${token.type}' (value: '${token.value}')`)
			}
			return token
		}

		const peek = () => {
			return tokens[i]
		}

		const parseCondition = () => {
			const leftToken = next('identifier')
			const operatorToken = next('operator')
			const rightToken = NULLARY_OPERATORS.includes(operatorToken.value)
				? null : next('value')

			const logicalToken = (peek() && peek().type === 'logical') ? next() : null

			return {
				logical: logicalToken ? logicalToken.value : 'AND',
				conditions: {
					left: leftToken.value,
					right: rightToken ? rightToken.value : null
				},
				operator: operatorToken.value,
			}
		}

		const parseGroup = () => {
			const conditions = []

			while (i < tokens.length) {
				const token = peek()

				if (token.type === 'paren' && token.value === '(') {
					next()
					const inner = parseGroup()
					const logical = (peek() && peek().type === 'logical') ? next().value : 'AND'

					conditions.push({
						logical,
						conditions: inner
					})

					if (peek() && peek().type === 'paren' && peek().value === ')') {
						next()
					}
				} else if (token.type === 'paren' && token.value === ')') {
					break
				} else {
					const condition = parseCondition()
					conditions.push(condition)
				}
			}

			return conditions
		}

		return parseGroup()
	}

	_normalizeToken(parsed) {
		const normalizeOperator = (op) => {
			return OPERATOR_MAP[op.toLowerCase()] || op
		}

		const normalizeRight = (op, right) => {
			if (right == null) return null

			if (Array.isArray(right)) {
				return right.map(r => {
					if (Helper.isNumber(r)) return +r
					return r
				});
			}

			if (Helper.isString(right)) {
				if (Helper.isNumber(right)) {
					return +right
				}

				if (/^\[.*\]$/.test(right)) {
					try {
						const jsonStr = right.replace(/'/g, '"')
						return JSON.parse(jsonStr)
					} catch {
						return right
					}
				}
			}

			return right
		}

		return parsed.map((entry, i) => {
			if (Array.isArray(entry.conditions)) {
				return {
					logical: entry.logical || 'AND',
					conditions: this._normalizeToken(entry.conditions)
				}
			}

			return {
				logical: entry.logical || 'AND',
				conditions: {
					left: entry.conditions.left,
					right: normalizeRight(entry.operator, entry.conditions.right),
				},
				operator: normalizeOperator(entry.operator),
			}
		})
	}

	/**
	 * Add AND condition filter
	 * @param {...(Group|string)} args - accepts 3 forms:
	 *   - (group: Group) — add a group condition
	 *   - (left: string, right: string|number) — shorthand for EQUAL operator
	 *   - (left: string, operator: string, right: string|number) — custom operator
	 * @returns {Filter}
	 *
	 * @example
	 * // group condition
	 * filter.and(myGroup)
	 *
	 * @example
	 * // equal shorthand: WHERE status = 'active'
	 * filter.and('status', 'active')
	 *
	 * @example
	 * // custom operator: WHERE age > 10
	 * filter.and('age', OperatorType.Greater, 10)
	 */
	and(...args) {
		if(args.length == 0 || args.length > 3) {
			throw new Error("Parameter is not valid")
		}

		if(args.length == 1 && !(args[0] instanceof Group)) {
			throw new Error("Parameter is not valid")
		}

		if(args.length == 1) {
			args[0].logical = LogicalType.AND
			this._filters.push(args[0])
			return
		}

		return args.length == 2 ?
			this.add(LogicalType.AND, args[0], OperatorType.Equal, args[1]) :
			this.add(LogicalType.AND, args[0], args[1], args[2])
	}

	/**
	 * Add AND BETWEEN condition filter
	 * @param {string} left - column name
	 * @param {[string|number, string|number]} right - tuple of [min, max]
	 * @returns {Filter}
	 *
	 * @example
	 * // WHERE date BETWEEN '2024-01-01' AND '2024-12-31'
	 * filter.andBetween('date', ['2024-01-01', '2024-12-31'])
	 */
	andBetween(left, right) {
		return this.add(LogicalType.AND, left, OperatorType.Between, right)
	}

	/**
	 * Add AND IN condition filter
	 * @param {string} left - column name
	 * @param {(string|number)[]} right - list of values
	 * @returns {Filter}
	 *
	 * @example
	 * // WHERE status IN ('active', 'pending')
	 * filter.andIn('status', ['active', 'pending'])
	 */
	andIn(left, right) {
		return this.add(LogicalType.AND, left, OperatorType.In, right)
	}

	/**
	 * Add AND IS NULL condition filter
	 * @param {string} left - column name
	 * @returns {Filter}
	 *
	 * @example
	 * // WHERE deleted_at IS NULL
	 * filter.andNull('deleted_at')
	 */
	andNull(left) {
		return this.add(LogicalType.AND, left, OperatorType.IsNull)
	}

	/**
	 * Add AND IS NOT NULL condition filter
	 * @param {string} left - column name
	 * @returns {Filter}
	 *
	 * @example
	 * // WHERE email IS NOT NULL
	 * filter.andNotNull('email')
	 */
	andNotNull(left) {
		return this.add(LogicalType.AND, left, OperatorType.IsNotNull)
	}

	/**
	 * Add AND IS EMPTY condition filter (null or empty string)
	 * @param {string} left - column name
	 * @returns {Filter}
	 *
	 * @example
	 * // WHERE (notes IS NULL OR notes = '')
	 * filter.andEmpty('notes')
	 */
	andEmpty(left) {
		return this.add(LogicalType.AND, left, OperatorType.IsEmpty)
	}

	/**
	 * Add AND IS NOT EMPTY condition filter (not null and not empty string)
	 * @param {string} left - column name
	 * @returns {Filter}
	 *
	 * @example
	 * // WHERE (notes IS NOT NULL AND notes != '')
	 * filter.andNotEmpty('notes')
	 */
	andNotEmpty(left) {
		return this.add(LogicalType.AND, left, OperatorType.IsNotEmpty)
	}

	/**
	 * Add AND SIMILAR condition filter — typo-tolerant text match (trigram similarity on pgsql,
	 * falls back to a plain Contains match on other drivers). Good for name/free-text search
	 * where the user may have misspelled a word.
	 * @param {string} left - column name
	 * @param {string} value - text to match against
	 * @param {number} [threshold] - minimum similarity 0-1 (pgsql only); omit to use the server default
	 * @returns {Filter}
	 *
	 * @example
	 * // WHERE similarity(lower(name), 'jhon') > 0.35 (server default threshold)
	 * filter.andSimilar('name', 'jhon')
	 *
	 * @example
	 * // stricter match
	 * filter.andSimilar('name', 'jhon', 0.5)
	 */
	andSimilar(left, value, threshold) {
		return this.add(LogicalType.AND, left, OperatorType.Similar, threshold != null ? { value, threshold } : value)
	}

	/**
	 * Add OR condition filter
	 * @param {...(Group|string)} args - accepts 3 forms:
	 *   - (group: Group) — add a group condition
	 *   - (left: string, right: string|number) — shorthand for EQUAL operator
	 *   - (left: string, operator: string, right: string|number) — custom operator
	 * @returns {Filter}
	 *
	 * @example
	 * // group condition
	 * filter.or(myGroup)
	 *
	 * @example
	 * // equal shorthand: OR status = 'inactive'
	 * filter.or('status', 'inactive')
	 *
	 * @example
	 * // custom operator: OR age < 5
	 * filter.or('age', OperatorType.Less, 5)
	 */
	or(...args) {
		if(args.length == 0 || args.length > 3) {
			throw new Error("Parameter is not valid")
		}

		if(args.length == 1 && !(args[0] instanceof Group)) {
			throw new Error("Parameter is not valid")
		}

		if(args.length == 1) {
			args[0].logical = LogicalType.OR
			this._filters.push(args[0])
			return
		}

		return args.length == 2 ?
			this.add(LogicalType.OR, args[0], OperatorType.Equal, args[1]) :
			this.add(LogicalType.OR, args[0], args[1], args[2])
	}

	/**
	 * Add OR BETWEEN condition filter
	 * @param {string} left - column name
	 * @param {[string|number, string|number]} right - tuple of [min, max]
	 * @returns {Filter}
	 *
	 * @example
	 * // OR price BETWEEN 100 AND 500
	 * filter.orBetween('price', [100, 500])
	 */
	orBetween(left, right) {
		return this.add(LogicalType.OR, left, OperatorType.Between, right)
	}

	/**
	 * Add OR IN condition filter
	 * @param {string} left - column name
	 * @param {(string|number)[]} right - list of values
	 * @returns {Filter}
	 *
	 * @example
	 * // OR role IN ('admin', 'superadmin')
	 * filter.orIn('role', ['admin', 'superadmin'])
	 */
	orIn(left, right) {
		return this.add(LogicalType.OR, left, OperatorType.In, right)
	}

	/**
	 * Add OR IS NULL condition filter
	 * @param {string} left - column name
	 * @returns {Filter}
	 *
	 * @example
	 * // OR phone IS NULL
	 * filter.orNull('phone')
	 */
	orNull(left) {
		return this.add(LogicalType.OR, left, OperatorType.IsNull)
	}

	/**
	 * Add OR IS NOT NULL condition filter
	 * @param {string} left - column name
	 * @returns {Filter}
	 *
	 * @example
	 * // OR address IS NOT NULL
	 * filter.orNotNull('address')
	 */
	orNotNull(left) {
		return this.add(LogicalType.OR, left, OperatorType.IsNotNull)
	}

	/**
	 * Add OR IS EMPTY condition filter (null or empty string)
	 * @param {string} left - column name
	 * @returns {Filter}
	 *
	 * @example
	 * // OR (notes IS NULL OR notes = '')
	 * filter.orEmpty('notes')
	 */
	orEmpty(left) {
		return this.add(LogicalType.OR, left, OperatorType.IsEmpty)
	}

	/**
	 * Add OR IS NOT EMPTY condition filter (not null and not empty string)
	 * @param {string} left - column name
	 * @returns {Filter}
	 *
	 * @example
	 * // OR (notes IS NOT NULL AND notes != '')
	 * filter.orNotEmpty('notes')
	 */
	orNotEmpty(left) {
		return this.add(LogicalType.OR, left, OperatorType.IsNotEmpty)
	}

	/**
	 * Add OR SIMILAR condition filter — typo-tolerant text match (trigram similarity on pgsql,
	 * falls back to a plain Contains match on other drivers).
	 * @param {string} left - column name
	 * @param {string} value - text to match against
	 * @param {number} [threshold] - minimum similarity 0-1 (pgsql only); omit to use the server default
	 * @returns {Filter}
	 *
	 * @example
	 * filter.orSimilar('name', 'jhon')
	 */
	orSimilar(left, value, threshold) {
		return this.add(LogicalType.OR, left, OperatorType.Similar, threshold != null ? { value, threshold } : value)
	}

	/**
	 * Add AND dynamic period range filter (IS_LAST_N / IS_NEXT_N)
	 * @param {string} left - column name (date or datetime)
	 * @param {string} operator - OperatorType.IsLastN | OperatorType.IsNextN
	 * @param {number} value - number of units
	 * @param {string} unit - Filter.PeriodUnit.*
	 * @returns {Filter}
	 *
	 * @example
	 * // created_at in last 30 days
	 * filter.andPeriod('created_at', OperatorType.IsLastN, 30, Filter.PeriodUnit.Days)
	 */
	andPeriod(left, operator, value, unit) {
		return this.add(LogicalType.AND, left, operator, { value, unit })
	}

	/**
	 * Add OR dynamic period range filter (IS_LAST_N / IS_NEXT_N)
	 * @param {string} left - column name (date or datetime)
	 * @param {string} operator - OperatorType.IsLastN | OperatorType.IsNextN
	 * @param {number} value - number of units
	 * @param {string} unit - Filter.PeriodUnit.*
	 * @returns {Filter}
	 */
	orPeriod(left, operator, value, unit) {
		return this.add(LogicalType.OR, left, operator, { value, unit })
	}

	/**
	 * Add AND relative date comparison filter
	 * @param {string} left - column name (date or datetime)
	 * @param {string} operator - comparison operator from Filter.OperatorType (e.g. LessOrEqual)
	 * @param {string} unit - Filter.PeriodUnit.*
	 * @param {number} offset - number of units
	 * @param {string} [direction='past'] - 'past' | 'future'
	 * @returns {Filter}
	 *
	 * @example
	 * // created_at <= 10 days ago (data older than 10 days)
	 * filter.andRelativeDate('created_at', OperatorType.LessOrEqual, Filter.PeriodUnit.Days, 10)
	 *
	 * @example
	 * // due_date <= 7 days from now
	 * filter.andRelativeDate('due_date', OperatorType.LessOrEqual, Filter.PeriodUnit.Days, 7, 'future')
	 */
	andRelativeDate(left, operator, unit, offset, direction = 'past') {
		return this.add(LogicalType.AND, left, operator, { type: 'relative', unit, offset, direction })
	}

	/**
	 * Add OR relative date comparison filter
	 * @param {string} left - column name (date or datetime)
	 * @param {string} operator - comparison operator from Filter.OperatorType
	 * @param {string} unit - Filter.PeriodUnit.*
	 * @param {number} offset - number of units
	 * @param {string} [direction='past'] - 'past' | 'future'
	 * @returns {Filter}
	 */
	orRelativeDate(left, operator, unit, offset, direction = 'past') {
		return this.add(LogicalType.OR, left, operator, { type: 'relative', unit, offset, direction })
	}

	// ─── Date Period (fixed shortcuts) ──────────────────────────────────────────

	/**
	 * Add AND IS TODAY filter — column date falls on today
	 * @param {string} left - date or datetime column name
	 * @returns {Filter}
	 *
	 * @example
	 * // WHERE created_at BETWEEN '2026-06-19 00:00:00' AND '2026-06-19 23:59:59'
	 * filter.andToday('created_at')
	 */
	andToday(left) {
		return this.add(LogicalType.AND, left, OperatorType.IsToday)
	}

	/**
	 * Add OR IS TODAY filter — column date falls on today
	 * @param {string} left - date or datetime column name
	 * @returns {Filter}
	 *
	 * @example
	 * filter.orToday('updated_at')
	 */
	orToday(left) {
		return this.add(LogicalType.OR, left, OperatorType.IsToday)
	}

	/**
	 * Add AND IS YESTERDAY filter — column date falls on yesterday
	 * @param {string} left - date or datetime column name
	 * @returns {Filter}
	 *
	 * @example
	 * filter.andYesterday('created_at')
	 */
	andYesterday(left) {
		return this.add(LogicalType.AND, left, OperatorType.IsYesterday)
	}

	/**
	 * Add OR IS YESTERDAY filter — column date falls on yesterday
	 * @param {string} left - date or datetime column name
	 * @returns {Filter}
	 *
	 * @example
	 * filter.orYesterday('created_at')
	 */
	orYesterday(left) {
		return this.add(LogicalType.OR, left, OperatorType.IsYesterday)
	}

	/**
	 * Add AND IS THIS WEEK filter — column date falls within the current week (Mon–Sun)
	 * @param {string} left - date or datetime column name
	 * @returns {Filter}
	 *
	 * @example
	 * filter.andThisWeek('created_at')
	 */
	andThisWeek(left) {
		return this.add(LogicalType.AND, left, OperatorType.IsThisWeek)
	}

	/**
	 * Add OR IS THIS WEEK filter — column date falls within the current week
	 * @param {string} left - date or datetime column name
	 * @returns {Filter}
	 *
	 * @example
	 * filter.orThisWeek('created_at')
	 */
	orThisWeek(left) {
		return this.add(LogicalType.OR, left, OperatorType.IsThisWeek)
	}

	/**
	 * Add AND IS LAST WEEK filter — column date falls within last week (Mon–Sun)
	 * @param {string} left - date or datetime column name
	 * @returns {Filter}
	 *
	 * @example
	 * filter.andLastWeek('created_at')
	 */
	andLastWeek(left) {
		return this.add(LogicalType.AND, left, OperatorType.IsLastWeek)
	}

	/**
	 * Add OR IS LAST WEEK filter — column date falls within last week
	 * @param {string} left - date or datetime column name
	 * @returns {Filter}
	 *
	 * @example
	 * filter.orLastWeek('created_at')
	 */
	orLastWeek(left) {
		return this.add(LogicalType.OR, left, OperatorType.IsLastWeek)
	}

	/**
	 * Add AND IS THIS MONTH filter — column date falls within the current calendar month
	 * @param {string} left - date or datetime column name
	 * @returns {Filter}
	 *
	 * @example
	 * // WHERE created_at BETWEEN '2026-06-01' AND '2026-06-30 23:59:59'
	 * filter.andThisMonth('created_at')
	 */
	andThisMonth(left) {
		return this.add(LogicalType.AND, left, OperatorType.IsThisMonth)
	}

	/**
	 * Add OR IS THIS MONTH filter — column date falls within the current calendar month
	 * @param {string} left - date or datetime column name
	 * @returns {Filter}
	 *
	 * @example
	 * filter.orThisMonth('created_at')
	 */
	orThisMonth(left) {
		return this.add(LogicalType.OR, left, OperatorType.IsThisMonth)
	}

	/**
	 * Add AND IS LAST MONTH filter — column date falls within last calendar month
	 * @param {string} left - date or datetime column name
	 * @returns {Filter}
	 *
	 * @example
	 * filter.andLastMonth('created_at')
	 */
	andLastMonth(left) {
		return this.add(LogicalType.AND, left, OperatorType.IsLastMonth)
	}

	/**
	 * Add OR IS LAST MONTH filter — column date falls within last calendar month
	 * @param {string} left - date or datetime column name
	 * @returns {Filter}
	 *
	 * @example
	 * filter.orLastMonth('created_at')
	 */
	orLastMonth(left) {
		return this.add(LogicalType.OR, left, OperatorType.IsLastMonth)
	}

	/**
	 * Add AND IS THIS YEAR filter — column date falls within the current calendar year
	 * @param {string} left - date or datetime column name
	 * @returns {Filter}
	 *
	 * @example
	 * // WHERE created_at BETWEEN '2026-01-01' AND '2026-12-31 23:59:59'
	 * filter.andThisYear('created_at')
	 */
	andThisYear(left) {
		return this.add(LogicalType.AND, left, OperatorType.IsThisYear)
	}

	/**
	 * Add OR IS THIS YEAR filter — column date falls within the current calendar year
	 * @param {string} left - date or datetime column name
	 * @returns {Filter}
	 *
	 * @example
	 * filter.orThisYear('created_at')
	 */
	orThisYear(left) {
		return this.add(LogicalType.OR, left, OperatorType.IsThisYear)
	}

	/**
	 * Add AND IS LAST YEAR filter — column date falls within last calendar year
	 * @param {string} left - date or datetime column name
	 * @returns {Filter}
	 *
	 * @example
	 * filter.andLastYear('created_at')
	 */
	andLastYear(left) {
		return this.add(LogicalType.AND, left, OperatorType.IsLastYear)
	}

	/**
	 * Add OR IS LAST YEAR filter — column date falls within last calendar year
	 * @param {string} left - date or datetime column name
	 * @returns {Filter}
	 *
	 * @example
	 * filter.orLastYear('created_at')
	 */
	orLastYear(left) {
		return this.add(LogicalType.OR, left, OperatorType.IsLastYear)
	}

	// ─── Date Period (dynamic N) ──────────────────────────────────────────────────

	/**
	 * Add AND IN LAST N filter — column falls within the last N units from now (sliding window backward)
	 * @param {string} left - date or datetime column name
	 * @param {number} value - number of units
	 * @param {string} unit - Filter.PeriodUnit.*
	 * @returns {Filter}
	 *
	 * @example
	 * // WHERE created_at BETWEEN (NOW - 30 days) AND NOW
	 * filter.andLastN('created_at', 30, Filter.PeriodUnit.Days)
	 */
	andLastN(left, value, unit) {
		return this.add(LogicalType.AND, left, OperatorType.IsLastN, { value, unit })
	}

	/**
	 * Add OR IN LAST N filter — column falls within the last N units from now
	 * @param {string} left - date or datetime column name
	 * @param {number} value - number of units
	 * @param {string} unit - Filter.PeriodUnit.*
	 * @returns {Filter}
	 *
	 * @example
	 * filter.orLastN('created_at', 7, Filter.PeriodUnit.Days)
	 */
	orLastN(left, value, unit) {
		return this.add(LogicalType.OR, left, OperatorType.IsLastN, { value, unit })
	}

	/**
	 * Add AND IN NEXT N filter — column falls within the next N units from now (sliding window forward)
	 * @param {string} left - date or datetime column name
	 * @param {number} value - number of units
	 * @param {string} unit - Filter.PeriodUnit.*
	 * @returns {Filter}
	 *
	 * @example
	 * // WHERE due_date BETWEEN NOW AND (NOW + 7 days)
	 * filter.andNextN('due_date', 7, Filter.PeriodUnit.Days)
	 */
	andNextN(left, value, unit) {
		return this.add(LogicalType.AND, left, OperatorType.IsNextN, { value, unit })
	}

	/**
	 * Add OR IN NEXT N filter — column falls within the next N units from now
	 * @param {string} left - date or datetime column name
	 * @param {number} value - number of units
	 * @param {string} unit - Filter.PeriodUnit.*
	 * @returns {Filter}
	 *
	 * @example
	 * filter.orNextN('due_date', 14, Filter.PeriodUnit.Days)
	 */
	orNextN(left, value, unit) {
		return this.add(LogicalType.OR, left, OperatorType.IsNextN, { value, unit })
	}

	// ─── Date Part ────────────────────────────────────────────────────────────────

	/**
	 * Add AND YEAR IS filter — matches rows where the year part of the column equals the given value
	 * @param {string} left - date or datetime column name
	 * @param {number|Object} year - year number, or Filter.Now to compare against current year
	 * @returns {Filter}
	 *
	 * @example
	 * // WHERE YEAR(created_at) = 2026
	 * filter.andYear('created_at', 2026)
	 *
	 * @example
	 * // WHERE YEAR(created_at) = YEAR(NOW())
	 * filter.andYear('created_at', Filter.Now)
	 */
	andYear(left, year) {
		return this.add(LogicalType.AND, left, OperatorType.IsYear, year)
	}

	/**
	 * Add OR YEAR IS filter — matches rows where the year part of the column equals the given value
	 * @param {string} left - date or datetime column name
	 * @param {number|Object} year - year number, or Filter.Now for current year
	 * @returns {Filter}
	 *
	 * @example
	 * filter.orYear('created_at', Filter.Now)
	 */
	orYear(left, year) {
		return this.add(LogicalType.OR, left, OperatorType.IsYear, year)
	}

	/**
	 * Add AND MONTH IS filter — matches rows where the month part of the column equals the given value
	 * @param {string} left - date or datetime column name
	 * @param {number|Object} month - month number 1–12, or Filter.Now to compare against current month
	 * @returns {Filter}
	 *
	 * @example
	 * // WHERE MONTH(birthdate) = 6
	 * filter.andMonth('birthdate', 6)
	 *
	 * @example
	 * // WHERE MONTH(birthdate) = MONTH(NOW())
	 * filter.andMonth('birthdate', Filter.Now)
	 */
	andMonth(left, month) {
		return this.add(LogicalType.AND, left, OperatorType.IsMonth, month)
	}

	/**
	 * Add OR MONTH IS filter — matches rows where the month part of the column equals the given value
	 * @param {string} left - date or datetime column name
	 * @param {number|Object} month - month number 1–12, or Filter.Now for current month
	 * @returns {Filter}
	 *
	 * @example
	 * filter.orMonth('birthdate', Filter.Now)
	 */
	orMonth(left, month) {
		return this.add(LogicalType.OR, left, OperatorType.IsMonth, month)
	}

	/**
	 * Add AND DAY IS filter — matches rows where the day-of-month part of the column equals the given value
	 * @param {string} left - date or datetime column name
	 * @param {number|Object} day - day of month 1–31, or Filter.Now to compare against today's day
	 * @returns {Filter}
	 *
	 * @example
	 * // WHERE DAY(birthdate) = 19
	 * filter.andDay('birthdate', 19)
	 *
	 * @example
	 * // WHERE DAY(birthdate) = DAY(NOW())
	 * filter.andDay('birthdate', Filter.Now)
	 */
	andDay(left, day) {
		return this.add(LogicalType.AND, left, OperatorType.IsDay, day)
	}

	/**
	 * Add OR DAY IS filter — matches rows where the day-of-month part of the column equals the given value
	 * @param {string} left - date or datetime column name
	 * @param {number|Object} day - day of month 1–31, or Filter.Now for today's day
	 * @returns {Filter}
	 *
	 * @example
	 * filter.orDay('birthdate', Filter.Now)
	 */
	orDay(left, day) {
		return this.add(LogicalType.OR, left, OperatorType.IsDay, day)
	}

	/**
	 * Add AND MONTH & DAY IS filter — matches rows where both the month and day parts match.
	 * Pass Filter.Now as month to match today's month and day (e.g. find everyone with a birthday today).
	 * @param {string} left - date or datetime column name
	 * @param {number|Object} month - month number 1–12, or Filter.Now to use today's month+day
	 * @param {number|null} [day=null] - day of month 1–31 (ignored when month is Filter.Now)
	 * @returns {Filter}
	 *
	 * @example
	 * // WHERE MONTH(birthdate) = 6 AND DAY(birthdate) = 19
	 * filter.andMonthDay('birthdate', 6, 19)
	 *
	 * @example
	 * // WHERE MONTH(birthdate) = MONTH(NOW()) AND DAY(birthdate) = DAY(NOW())
	 * filter.andMonthDay('birthdate', Filter.Now)
	 */
	andMonthDay(left, month, day = null) {
		const right = month === Filter.Now || month?.source === 'now' ? Filter.Now : { month, day }
		return this.add(LogicalType.AND, left, OperatorType.IsMonthDay, right)
	}

	/**
	 * Add OR MONTH & DAY IS filter — matches rows where both the month and day parts match.
	 * @param {string} left - date or datetime column name
	 * @param {number|Object} month - month number 1–12, or Filter.Now for today's month+day
	 * @param {number|null} [day=null] - day of month 1–31 (ignored when month is Filter.Now)
	 * @returns {Filter}
	 *
	 * @example
	 * // Find all records with today's month+day across any year
	 * filter.orMonthDay('birthdate', Filter.Now)
	 */
	orMonthDay(left, month, day = null) {
		const right = month === Filter.Now || month?.source === 'now' ? Filter.Now : { month, day }
		return this.add(LogicalType.OR, left, OperatorType.IsMonthDay, right)
	}

	/**
	 * Add custom condition with full control over all parameters
	 * @param {string} logical - logical operator: LogicalType.AND | LogicalType.OR
	 * @param {string} left - column name
	 * @param {string} operator - comparison operator from Filter.OperatorType
	 * @param {string|number|Array|undefined} right - value to compare against (omit for IS_NULL / IS_NOT_NULL)
	 * @returns {Filter}
	 *
	 * @example
	 * // AND name LIKE '%udin%'
	 * filter.add(LogicalType.AND, 'name', OperatorType.Contains, 'udin')
	 *
	 * @example
	 * // OR status IS NULL (no right value)
	 * filter.add(LogicalType.OR, 'status', OperatorType.IsNull)
	 */
	add(logical, left, operator, right) {
		if(operator == OperatorType.Between) {
			if(!Array.isArray(right)) {
				throw new Error("If operator is 'Between', then right condition must be array")
			}

			if(right.length != 2) {
				throw new Error("Length of right condition must be 2 item")
			}
		}

		if(operator == OperatorType.In) {
			if(!Array.isArray(right)) {
				throw new Error("If operator is 'In', then right condition must be array")
			}
		}

		this._filters.push(new Condition(logical, left, operator, right))

		return this
	}

	/**
	 * Add grouped condition (sub-filter wrapped in parentheses)
	 * @param {Function} callback - accepts 2 forms:
	 *   - (filter: Filter) => void — receives a Filter instance to build conditions on
	 *   - () => Filter — returns a new Filter instance with conditions
	 * @param {string} [logical=LogicalType.AND] - logical operator for the group
	 * @returns {Filter}
	 *
	 * @example
	 * // callback with parameter: AND (status = 'active' OR status = 'pending')
	 * filter.group(f => {
	 *     f.and('status', 'active')
	 *     f.or('status', 'pending')
	 * })
	 *
	 * @example
	 * // callback returning Filter: OR (age > 18 AND age < 65)
	 * filter.group(() => {
	 *     return new Filter()
	 *         .and('age', OperatorType.Greater, 18)
	 *         .and('age', OperatorType.Less, 65)
	 * }, LogicalType.OR)
	 */
	group(callback, logical = LogicalType.AND) {
		if(!Helper.isFunction(callback)) {
			throw new Error("Group callback must be a function")
		}

		const group   = new Group(logical)
		let subFilter = null

		if (callback.length === 0) {
			const result = callback()
			if (!(result instanceof Filter)) {
				throw new Error("Callback with zero parameters must return an instance of Filter")
			}

			subFilter = result
		} else {
			subFilter = new Filter()
			callback(subFilter)

			if (!(subFilter instanceof Filter)) {
				throw new Error("Callback must operate on an instance of Filter")
			}
		}

		group.add(subFilter)

		this._filters.push(group)

		return this
	}

	/**
	 * Add relation group filter (same-row matching on HasMany)
	 * @param {string} relation - relation name
	 * @param {Function} callback - receives a Filter instance to build inner conditions
	 * @param {string} [logical=LogicalType.AND] - logical operator
	 * @returns {Filter}
	 *
	 * @example
	 * filter.has('addresses', f => {
	 *     f.and('city', 'Jakarta')
	 *     f.and('postal_code', OperatorType.StartWith, '12')
	 * })
	 */
	has(relation, callback, logical = LogicalType.AND) {
		if(!Helper.isString(relation) || Helper.isEmpty(relation)) {
			throw new Error("Relation must be a non-empty string")
		}

		if(!Helper.isFunction(callback)) {
			throw new Error("Callback must be a function")
		}

		const subFilter = new Filter()
		callback(subFilter)

		if(subFilter.isEmpty()) {
			throw new Error("Relation filter callback must add at least one condition")
		}

		this._filters.push({
			logical: logical,
			relation: relation,
			conditions: subFilter.get()
		})

		return this
	}

	/**
	 * Add relation negation filter (no related row matches — or no related row at all)
	 * @param {string} relation - relation name
	 * @param {Function|null} [callback=null] - optional Filter builder; omit to match rows with no related record at all
	 * @param {string} [logical=LogicalType.AND] - logical operator
	 * @returns {Filter}
	 *
	 * @example
	 * // customers with no orders at all
	 * filter.doesntHave('orders')
	 *
	 * @example
	 * // customers with no order in 'pending' status
	 * filter.doesntHave('orders', f => {
	 *     f.and('status', 'pending')
	 * })
	 */
	doesntHave(relation, callback = null, logical = LogicalType.AND) {
		if(!Helper.isString(relation) || Helper.isEmpty(relation)) {
			throw new Error("Relation must be a non-empty string")
		}

		let conditions = []

		if (callback !== null) {
			if(!Helper.isFunction(callback)) {
				throw new Error("Callback must be a function")
			}

			const subFilter = new Filter()
			callback(subFilter)
			conditions = subFilter.get()
		}

		this._filters.push({
			logical: logical,
			relation: relation,
			conditions: conditions,
			negate: true
		})

		return this
	}

	/**
	 * Add AND aggregate condition
	 * @param {string} aggregate - aggregate type from AggregateType
	 * @param {string} left - relation name or relation.column for sum/avg/min/max
	 * @param {string} operator - comparison operator from Filter.OperatorType
	 * @param {number} right - value to compare against
	 * @returns {Filter}
	 *
	 * @example
	 * filter.andAggregate(AggregateType.Count, 'addresses', OperatorType.Greater, 2)
	 * filter.andAggregate(AggregateType.Sum, 'details.amount', OperatorType.Greater, 10000)
	 */
	andAggregate(aggregate, left, operator, right) {
		return this.addAggregate(LogicalType.AND, aggregate, left, operator, right)
	}

	/**
	 * Add OR aggregate condition
	 * @param {string} aggregate - aggregate type from AggregateType
	 * @param {string} left - relation name or relation.column for sum/avg/min/max
	 * @param {string} operator - comparison operator from Filter.OperatorType
	 * @param {number} right - value to compare against
	 * @returns {Filter}
	 *
	 * @example
	 * filter.orAggregate(AggregateType.Count, 'addresses', OperatorType.Greater, 0)
	 */
	orAggregate(aggregate, left, operator, right) {
		return this.addAggregate(LogicalType.OR, aggregate, left, operator, right)
	}

	/**
	 * Add aggregate condition with full control
	 * @param {string} logical - LogicalType.AND | LogicalType.OR
	 * @param {string} aggregate - aggregate type from AggregateType
	 * @param {string} left - relation name (count) or relation.column (sum/avg/min/max)
	 * @param {string} operator - comparison operator from Filter.OperatorType
	 * @param {number} right - value to compare against
	 * @returns {Filter}
	 */
	addAggregate(logical, aggregate, left, operator, right) {
		const validAggregates = Object.values(AggregateType)
		if(!validAggregates.includes(aggregate)) {
			throw new Error(`Invalid aggregate type '${aggregate}'. Must be one of: ${validAggregates.join(', ')}`)
		}

		if(!Helper.isString(left) || Helper.isEmpty(left)) {
			throw new Error("Left condition must be a non-empty string")
		}

		if(aggregate !== AggregateType.Count && !left.includes('.')) {
			throw new Error(`Aggregate type '${aggregate}' requires relation.column format (e.g., 'details.amount')`)
		}

		this._filters.push(new AggregateCondition(logical, aggregate, operator, left, right))

		return this
	}

	/**
	 * @returns {(Condition|AggregateCondition|Group|object)[]} array of filter conditions
	 */
	get() {
		return this._filters
	}

	/**
	 * @returns {boolean} true if no filters have been added
	 */
	isEmpty() {
		return this._filters.length == 0
	}
}
