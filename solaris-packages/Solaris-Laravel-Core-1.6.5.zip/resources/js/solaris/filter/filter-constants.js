export default class FilterConstants {

	static LogicalType = Object.freeze({
		AND: 'AND',
		OR : 'OR'
	})

	static OperatorType = Object.freeze({
		Equal           : 'EQUAL',
		NotEqual        : 'NOT_EQUAL',
		Greater         : 'GREATER',
		GreaterOrEqual  : 'GREATER_OR_EQUAL',
		Less            : 'LESS',
		LessOrEqual     : 'LESS_OR_EQUAL',
		Contains        : 'LIKE',
		StartWith       : 'LIKE_START_WITH',
		EndWith         : 'LIKE_END_WITH',
		FullText        : 'FULLTEXT',
		Similar         : 'SIMILAR',
		In              : 'IN',
		NotIn           : 'NOT_IN',
		Between         : 'BETWEEN',
		NotBetween      : 'NOT_BETWEEN',
		IsNull          : 'IS_NULL',
		IsNotNull       : 'IS_NOT_NULL',
		IsEmpty         : 'IS_EMPTY',
		IsNotEmpty      : 'IS_NOT_EMPTY',
		IsToday         : 'IS_TODAY',
		IsYesterday     : 'IS_YESTERDAY',
		IsThisWeek      : 'IS_THIS_WEEK',
		IsLastWeek      : 'IS_LAST_WEEK',
		IsThisMonth     : 'IS_THIS_MONTH',
		IsLastMonth     : 'IS_LAST_MONTH',
		IsThisYear      : 'IS_THIS_YEAR',
		IsLastYear      : 'IS_LAST_YEAR',
		IsLastN         : 'IS_LAST_N',
		IsNextN         : 'IS_NEXT_N',
		IsMonth         : 'IS_MONTH',
		IsDay           : 'IS_DAY',
		IsMonthDay      : 'IS_MONTH_DAY',
		IsYear          : 'IS_YEAR'
	})

	static PeriodUnit = Object.freeze({
		Days   : 'days',
		Weeks  : 'weeks',
		Months : 'months',
		Years  : 'years',
	})

	static AggregateType = Object.freeze({
		Count : 'count',
		Sum   : 'sum',
		Avg   : 'avg',
		Min   : 'min',
		Max   : 'max'
	})

	static MULTI_WORD_OPERATORS = [
		'is not null',
		'not between',
		'start with',
		'isnotnull',
		'startwith',
		'is null',
		'end with',
		'contains',
		'endwith',
		'not in',
		'isnull',
		'between',
		'in',
	].sort((a, b) => b.length - a.length)

	static SINGLE_OPERATORS = [
		'!=', '<>', '<=', '>=', '=', '<', '>',
	].sort((a, b) => b.length - a.length)

	static NULLARY_OPERATORS = ['is null', 'is not null', 'isnull', 'isnotnull']

	static LOGICAL_KEYWORDS
	static OPERATOR_MAP

	static {
		FilterConstants.LOGICAL_KEYWORDS = [
			FilterConstants.LogicalType.AND,
			FilterConstants.LogicalType.OR
		]

		FilterConstants.OPERATOR_MAP = {
			'='          : FilterConstants.OperatorType.Equal,
			'!='         : FilterConstants.OperatorType.NotEqual,
			'<>'         : FilterConstants.OperatorType.NotEqual,
			'<'          : FilterConstants.OperatorType.Less,
			'<='         : FilterConstants.OperatorType.LessOrEqual,
			'>'          : FilterConstants.OperatorType.Greater,
			'>='         : FilterConstants.OperatorType.GreaterOrEqual,
			'in'         : FilterConstants.OperatorType.In,
			'not in'     : FilterConstants.OperatorType.NotIn,
			'is not null': FilterConstants.OperatorType.IsNotNull,
			'isnotnull'  : FilterConstants.OperatorType.IsNotNull,
			'isnull'     : FilterConstants.OperatorType.IsNull,
			'is null'    : FilterConstants.OperatorType.IsNull,
			'between'    : FilterConstants.OperatorType.Between,
			'not between': FilterConstants.OperatorType.NotBetween,
			'contains'   : FilterConstants.OperatorType.Contains,
			'startwith'  : FilterConstants.OperatorType.StartWith,
			'start with' : FilterConstants.OperatorType.StartWith,
			'endwith'    : FilterConstants.OperatorType.EndWith,
			'end with'   : FilterConstants.OperatorType.EndWith,
		}
	}
}
