import AggregateCondition from "./aggregate-condition"
import Condition from "./condition"
import FilterConstants from "./filter-constants"

export default class Group {
    conditions = []

    /**
     * @param {string} logical default is logical AND
     */
    constructor(logical = FilterConstants.LogicalType.AND) {
        this.logical = logical
    }

    /**
     * add condition to groups
     * @param {Condition|AggregateCondition|Group|import('./filter').default} condition
     * @returns {Group}
     */
    add(condition) {
        if (condition !== null && typeof condition === 'object' && typeof condition.get === 'function') {
            this.conditions = this.conditions.concat(condition.get())
            return this
        }

        if (!(condition instanceof Condition) && !(condition instanceof AggregateCondition) && !(condition instanceof Group)) {
            throw new Error("Condition is not valid")
        }

        this.conditions.push(condition)

        return this
    }
}
