export default class Condition {

    /**
     * @param {string} logical
     * @param {string} leftCondition
     * @param {string} operator
     * @param {any} rightCondition
     */
    constructor(logical, leftCondition, operator, rightCondition) {
        this.logical = logical
        this.operator = operator
        this.conditions = {
            left: leftCondition,
            right: rightCondition ?? null
        }
    }
}