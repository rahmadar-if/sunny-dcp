import Form from "./form/form"
import Helper from "./helper"
import Modal from "./modal"

export default class ModalForm {

    /**
     * @param {Modal} modal 
     * @param {Form} form 
     */
    constructor(modal, form) {
        if (!(modal instanceof Modal)) {
            throw new Error("Modal must be Modal instance")
        }

        if (!(form instanceof Form)) {
            throw new Error("Form must be Form instance")
        }

        this.modal = modal
        this.form = form

        this.#init()
    }

    #init() {
        this.form.on("success", () => this.modal.hide(), "ModalForm")
        this.modal.on("hidden", () => this.form.reset(true), "ModalForm")
    }

    /**
     * @param {string|object|function} data
     * @param {Function} callback Form, data 
     */
    async edit(data, callback = null) {
        if (Helper.isString(data)) {
            this.form.editMode({ id: data })
        }

        data = await this.form.load(!Helper.isFunction(data) ? data : data(), true)
        this.modal.show()

        if (Helper.isFunction(callback)) {
            await callback(this.form, data)
        }
    }

    /**
     * @param {Function} callback Form 
     */
    new(callback = null) {
        this.form.newMode()
        this.modal.show()

        if (Helper.isFunction(callback)) {
            callback(this.form)
        }
    }
}