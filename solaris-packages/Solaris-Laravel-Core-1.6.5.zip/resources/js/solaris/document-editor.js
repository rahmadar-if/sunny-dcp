import {
	DecoupledEditor,
	Plugin,
	ButtonView,
	Alignment,
	AutoImage,
	AutoLink,
	Autosave,
	BalloonToolbar,
	BlockQuote,
	Bold,
	CloudServices,
	Code,
	CodeBlock,
	Emoji,
	Essentials,
	FindAndReplace,
	FontBackgroundColor,
	FontColor,
	FontFamily,
	FontSize,
	Fullscreen,
	GeneralHtmlSupport,
	Heading,
	Highlight,
	HorizontalLine,
	HtmlComment,
	HtmlEmbed,
	ImageBlock,
	ImageCaption,
	ImageEditing,
	ImageInline,
	ImageInsert,
	ImageInsertViaUrl,
	ImageResize,
	ImageStyle,
	ImageTextAlternative,
	ImageToolbar,
	ImageUpload,
	ImageUtils,
	Indent,
	IndentBlock,
	Italic,
	Link,
	LinkImage,
	List,
	ListProperties,
	MediaEmbed,
	Mention,
	PageBreak,
	Paragraph,
	PasteFromOffice,
	PlainTableOutput,
	RemoveFormat,
	ShowBlocks,
	SpecialCharacters,
	SpecialCharactersArrows,
	SpecialCharactersCurrency,
	SpecialCharactersEssentials,
	SpecialCharactersLatin,
	SpecialCharactersMathematical,
	SpecialCharactersText,
	Strikethrough,
	Style,
	Subscript,
	Superscript,
	Table,
	TableCaption,
	TableCellProperties,
	TableColumnResize,
	TableLayout,
	TableProperties,
	TableToolbar,
	TodoList,
	Underline,
	WordCount
} from 'ckeditor5'
import DropzoneUpload from './dropzone'
import Helper from './helper'
import FileHelper from './file-helper'

const _EXPORT_PDF_ICON = '<svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M4 2a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6H4zm7 1.5L16.5 8H11V3.5zM6 11h1.5a1 1 0 1 1 0 2H6.75v1H6v-3zm.75 1.5h.5a.25.25 0 0 0 0-.5h-.5v.5zm2.25 1.5v-3h1a1.5 1.5 0 1 1 0 3H9zm1-.75h.25a.75.75 0 0 0 0-1.5H10v1.5zm1.75-2.25h2.25V12H12.5v.5h1.5v.75h-1.5v1.25h-1V12z"/></svg>'

export default class DocumentEditor {
	_element     = null
	_id          = null
	_bindTo      = null
	_editor      = null
	_url         = `${BASE_URL}/core/attachment`
	_recordId    = null
	_model       = null
	_column      = null
	_pdfFilename = 'document.pdf'

	// #region Static

	static supportedEvent() {
		return []
	}

	// #endregion

	// #region Lifecycle

	/**
	 * @param {Element|string} selector
	 */
	constructor(selector) {
		if (selector instanceof Element) {
			this._element = selector
		} else if (Helper.isString(selector) && !Helper.isEmpty(selector)) {
			this._element = document.querySelector(selector)
			if (!this._element) {
				throw new Error(`Element with query selector ${selector} is not found`)
			}
		} else {
			throw new Error(`Selector is not supported`)
		}

		this._id          = this._element.id
		this._bindTo      = this._element.getAttribute('solar-bind')
		this._recordId    = this._element.getAttribute('record-id') ?? null
		this._model       = this._element.getAttribute('model') ?? null
		this._column      = this._element.getAttribute('column') ?? null
		this._pdfFilename = this._element.getAttribute('pdf-filename') ?? 'document.pdf'

		if (Helper.isEmpty(this._bindTo)) {
			this._bindTo = this._id
		}

		this.init()
	}

	async init() {
		this._editor = await DecoupledEditor.create(document.querySelector(`#${this._id}_editor`), this.#config())

		const wordCount = this._editor.plugins.get('WordCount')
		document.querySelector(`#${this._id}_editor-word-count`).appendChild(wordCount.wordCountContainer)
		document.querySelector(`#${this._id}_editor-toolbar`).appendChild(this._editor.ui.view.toolbar.element)
		document.querySelector(`#${this._id}_editor-menu-bar`).appendChild(this._editor.ui.view.menuBarView.element)
	}

	// #endregion

	// #region Public API

	/**
	 * @returns {string|null}
	 */
	get() {
		return this._editor?.getData() ?? null
	}

	/**
	 * @returns {string|null}
	 */
	getRaw() {
		return this._editor?.getData() ?? null
	}

	/**
	 * @returns {boolean}
	 */
	isEmpty() {
		return (this._editor?.getData() ?? '').trim() === ''
	}

	/**
	 * @param {string} value
	 */
	set(value) {
		this._editor.setData(value ?? '')
	}

	reset() {
		this.set('')
	}

	disabled() {
		this._editor.enableReadOnlyMode('document-editor')
	}

	/**
	 * @returns {boolean}
	 */
	isDisabled() {
		return this._editor.isReadOnly
	}

	enabled() {
		this._editor.disableReadOnlyMode('document-editor')
	}

	/**
	 * @param {string} value
	 * @returns {DocumentEditor}
	 */
	setRecordId(value) {
		this._recordId = value
		return this
	}

	/**
	 * @param {string} value
	 * @returns {DocumentEditor}
	 */
	setModel(value) {
		this._model = value
		return this
	}

	/**
	 * @param {string} value
	 * @returns {DocumentEditor}
	 */
	setColumn(value) {
		this._column = value
		return this
	}

	/**
	 * @param {string} value
	 * @returns {DocumentEditor}
	 */
	setPdfFilename(value) {
		this._pdfFilename = value
		return this
	}

	/**
	 * @returns {Promise<void>}
	 */
	async exportPdf() {
		await this._exportPdfHandler()
	}

	// #endregion

	// #region Upload

	/**
	 * @param {File} file
	 * @returns {Promise<string>}
	 */
	_upload(file) {
		return new Promise((resolve, reject) => {
			const dz = DropzoneUpload.createHidden({
				url:      this._url,
				model:    this._model,
				recordId: this._recordId,
			})

			dz.on('success', (dzFile, response) => {
				dz.destroy()
				if (!response.success) {
					reject(response.message)
					return
				}
				resolve(response.data.id)
			})

			dz.on('error', (dzFile, message) => {
				dz.destroy()
				reject(message?.message ?? message)
			})

			dz.addFile(file)
		})
	}

	/**
	 * @returns {Function}
	 */
	#createUploadAdapterPlugin() {
		const self = this
		return class extends Plugin {
			init() {
				this.editor.plugins.get('FileRepository').createUploadAdapter = (loader) => ({
					upload: () => loader.file.then(file =>
						self._upload(file).then(id => ({
							default: `${BASE_URL}/core/attachment/preview-media/${id}`
						}))
					),
					abort: () => {}
				})
			}
		}
	}

	// #endregion

	// #region Export PDF

	/**
	 * @returns {Promise<void>}
	 */
	async _exportPdfHandler() {
		if (this.isEmpty()) {
			Helper.errorAlert({ title: 'Export PDF', message: 'Document is empty.' })
			return
		}

		if (!this._model || !this._column || !this._recordId) {
			Helper.errorAlert({ title: 'Export PDF', message: 'Document is not bound to a record yet.' })
			return
		}

		const body = { model: this._model, column: this._column, id: this._recordId, filename: this._pdfFilename, type: 'document-editor' }

		Helper.loadingPage(true)
		try {
			await FileHelper.downloadFile(`${BASE_URL}/core/html-to-pdf`, 'POST', {
				headers: { Accept: 'application/pdf' },
				data:    body,
			})
		} catch (error) {
			if (!error?.response) {
				Helper.errorAlert({ title: 'Export PDF failed', message: error?.message ?? error })
			}
		} finally {
			Helper.loadingPage(false)
		}
	}

	/**
	 * @returns {Function}
	 */
	#createExportPdfPlugin() {
		const self = this
		return class extends Plugin {
			init() {
				this.editor.ui.componentFactory.add('exportPdf', () => {
					const button = new ButtonView()
					button.set({
						label:    'Export PDF',
						icon:     _EXPORT_PDF_ICON,
						tooltip:  true,
					})
					button.on('execute', () => self._exportPdfHandler())
					return button
				})
			}
		}
	}

	// #endregion

	// #region Config

	#config() {
		const LICENSE_KEY = 'GPL'
		return {
			toolbar: {
				items: [
					'undo',
					'redo',
					'|',
					'showBlocks',
					'|',
					'heading',
					'style',
					'|',
					'fontSize',
					'fontFamily',
					'fontColor',
					'fontBackgroundColor',
					'|',
					'bold',
					'italic',
					'underline',
					'|',
					'link',
					'insertTable',
					'insertTableLayout',
					'highlight',
					'blockQuote',
					'codeBlock',
					'|',
					'alignment',
					'|',
					'bulletedList',
					'numberedList',
					'todoList',
					'outdent',
					'indent',
					'|',
					'exportPdf',
				],
				shouldNotGroupWhenFull: false
			},
			plugins: [
				Alignment,
				AutoImage,
				AutoLink,
				Autosave,
				BalloonToolbar,
				BlockQuote,
				Bold,
				CloudServices,
				Code,
				CodeBlock,
				Emoji,
				Essentials,
				FindAndReplace,
				FontBackgroundColor,
				FontColor,
				FontFamily,
				FontSize,
				Fullscreen,
				GeneralHtmlSupport,
				Heading,
				Highlight,
				HorizontalLine,
				HtmlComment,
				HtmlEmbed,
				ImageBlock,
				ImageCaption,
				ImageEditing,
				ImageInline,
				ImageInsertViaUrl,
				ImageResize,
				ImageStyle,
				ImageTextAlternative,
				ImageToolbar,
				ImageUpload,
				ImageUtils,
				Indent,
				IndentBlock,
				Italic,
				Link,
				LinkImage,
				List,
				ListProperties,
				MediaEmbed,
				Mention,
				PageBreak,
				Paragraph,
				PasteFromOffice,
				PlainTableOutput,
				RemoveFormat,
				ShowBlocks,
				SpecialCharacters,
				SpecialCharactersArrows,
				SpecialCharactersCurrency,
				SpecialCharactersEssentials,
				SpecialCharactersLatin,
				SpecialCharactersMathematical,
				SpecialCharactersText,
				Strikethrough,
				Style,
				Subscript,
				Superscript,
				Table,
				TableCaption,
				TableCellProperties,
				TableColumnResize,
				TableLayout,
				TableProperties,
				TableToolbar,
				TodoList,
				Underline,
				WordCount
			],
			extraPlugins: [
				this.#createUploadAdapterPlugin(),
				this.#createExportPdfPlugin(),
			],
			balloonToolbar: ['bold', 'italic', '|', 'link', '|', 'bulletedList', 'numberedList'],
			fontFamily: {
				options: [
					'default',
					'Poppins',
					'PT Serif',
					'DejaVu Sans',
					'DejaVu Serif',
					'DejaVu Sans Mono',
					'Times New Roman, serif',
					'Arial, sans-serif',
					'Calibri, sans-serif',
					'Courier New, monospace',
					'Georgia, serif',
				]
			},
			fontSize: {
				options: [10, 12, 14, 'default', 18, 20, 22],
				supportAllValues: true
			},
			fullscreen: {
				onEnterCallback: container =>
					container.classList.add(
						'editor-container',
						'editor-container_document-editor',
						'editor-container_include-style',
						'editor-container_include-word-count',
						'editor-container_include-fullscreen',
						'main-container'
					)
			},
			heading: {
				options: [
					{
						model: 'paragraph',
						title: 'Paragraph',
						class: 'ck-heading_paragraph'
					},
					{
						model: 'heading1',
						view: 'h1',
						title: 'Heading 1',
						class: 'ck-heading_heading1'
					},
					{
						model: 'heading2',
						view: 'h2',
						title: 'Heading 2',
						class: 'ck-heading_heading2'
					},
					{
						model: 'heading3',
						view: 'h3',
						title: 'Heading 3',
						class: 'ck-heading_heading3'
					},
					{
						model: 'heading4',
						view: 'h4',
						title: 'Heading 4',
						class: 'ck-heading_heading4'
					},
					{
						model: 'heading5',
						view: 'h5',
						title: 'Heading 5',
						class: 'ck-heading_heading5'
					},
					{
						model: 'heading6',
						view: 'h6',
						title: 'Heading 6',
						class: 'ck-heading_heading6'
					}
				]
			},
			htmlSupport: {
				allow: [
					{
						name: /^.*$/,
						styles: true,
						attributes: true,
						classes: true
					}
				]
			},
			image: {
				toolbar: [
					'toggleImageCaption',
					'imageTextAlternative',
					'|',
					'imageStyle:inline',
					'imageStyle:wrapText',
					'imageStyle:breakText',
					'|',
					'resizeImage'
				]
			},
			licenseKey: LICENSE_KEY,
			link: {
				addTargetToExternalLinks: true,
				defaultProtocol: 'https://',
				decorators: {
					toggleDownloadable: {
						mode: 'manual',
						label: 'Downloadable',
						attributes: {
							download: 'file'
						}
					}
				}
			},
			list: {
				properties: {
					styles: true,
					startIndex: true,
					reversed: true
				}
			},
			mention: {
				feeds: [
					{
						marker: '@',
						feed: []
					}
				]
			},
			placeholder: 'Type or paste your content here!',
			style: {
				definitions: [
					{
						name: 'Article category',
						element: 'h3',
						classes: ['category']
					},
					{
						name: 'Title',
						element: 'h2',
						classes: ['document-title']
					},
					{
						name: 'Subtitle',
						element: 'h3',
						classes: ['document-subtitle']
					},
					{
						name: 'Info box',
						element: 'p',
						classes: ['info-box']
					},
					{
						name: 'CTA Link Primary',
						element: 'a',
						classes: ['button', 'button--green']
					},
					{
						name: 'CTA Link Secondary',
						element: 'a',
						classes: ['button', 'button--black']
					},
					{
						name: 'Marker',
						element: 'span',
						classes: ['marker']
					},
					{
						name: 'Spoiler',
						element: 'span',
						classes: ['spoiler']
					}
				]
			},
			table: {
				contentToolbar: ['tableColumn', 'tableRow', 'mergeTableCells', 'tableProperties', 'tableCellProperties']
			}
		}
	}

	// #endregion
}
