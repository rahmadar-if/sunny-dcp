import axios from "@core-js/libs/axios"
import Filter from "./filter/filter"
import Helper from "./helper"
import Numeral from "./numeral"
import SolarComponent from "./solar/solar-component"

export default class MetricDashboard extends SolarComponent {

	// #region Static

	/**
	 * @returns {string[]}
	 */
	static supportedEvent() {
		return ['chart']
	}

	/**
	 * Line sparkline — suits summary variant.
	 * @param {Array}  series
	 * @param {string} color  CSS variable name (e.g. 'primary')
	 * @returns {Object}
	 */
	static chartSummary(series, color) {
		return {
			series,
			chart: {
				type: 'line',
				height: 40,
				width: 80,
				sparkline: { enabled: true },
				zoom: { enabled: false },
			},
			stroke: { curve: 'smooth', width: 2 },
			tooltip: {
				enabled: true,
				theme: 'dark',
				x: { show: false },
				y: { title: { formatter: () => '' } },
				marker: { show: false },
			},
			grid: { borderColor: 'transparent' },
			colors: [`var(--${color}-color)`],
		}
	}

	/**
	 * Area sparkline — suits compact variant.
	 * @param {Array}  series
	 * @param {string} color
	 * @returns {Object}
	 */
	static chartCompact(series, color) {
		return {
			series,
			chart: {
				type: 'area',
				height: 40,
				width: 100,
				sparkline: { enabled: true },
			},
			stroke: { show: true, curve: 'smooth', width: 1.9 },
			fill: {
				type: 'gradient',
				gradient: {
					shadeIntensity: 1,
					type: 'horizontal',
					colorStops: [[
						{ offset: 0,  color: `var(--${color}-color)`, opacity: 0.03 },
						{ offset: 90, color: `var(--${color}-color)`, opacity: 0.03 },
					]],
				},
			},
			tooltip: {
				enabled: true,
				theme: 'dark',
				x: { show: false },
				y: { title: { formatter: () => '' } },
				marker: { show: false },
			},
			yaxis: { min: 0, show: false },
			xaxis: { show: false, axisTicks: { show: false }, axisBorder: { show: false } },
			colors: [`var(--${color}-color)`],
		}
	}

	/**
	 * Area sparkline with gradient fill — suits detail variant.
	 * @param {Array}  series
	 * @param {string} color
	 * @returns {Object}
	 */
	static chartDetail(series, color) {
		return {
			series,
			chart: {
				type: 'area',
				height: 40,
				width: 120,
				sparkline: { enabled: true },
			},
			stroke: { show: true, curve: 'smooth', width: 1.7 },
			fill: {
				type: 'gradient',
				gradient: { opacityFrom: 0.8, opacityTo: 0.1, stops: [0, 90] },
			},
			tooltip: {
				enabled: true,
				theme: 'dark',
				x: { show: false },
				y: { title: { formatter: () => '' } },
				marker: { show: false },
			},
			yaxis: { min: 0, show: false, axisBorder: { show: false } },
			xaxis: { show: false, axisBorder: { show: false } },
			colors: [`var(--${color}-color)`],
		}
	}

	// #endregion

	// #region Lifecycle

	/**
	 * @param {HTMLElement|string} selector
	 */
	constructor(selector) {
		super()

		if (selector instanceof HTMLElement) {
			this._element = selector
		} else if (Helper.isString(selector) && !Helper.isEmpty(selector)) {
			this._element = document.querySelector(selector)
			if (!this._element) {
				throw new Error(`Element with query selector ${selector} is not found`)
			}
		} else {
			throw new Error(`Selector is not supported`)
		}

		this.id = this._element.id

		this._model      = this._element.getAttribute('model')
		this._variant    = this._element.getAttribute('variant') ?? 'simple'
		this._color      = this._element.getAttribute('color') ?? 'primary'
		this._period      = this._element.hasAttribute('period') ? JSON.parse(this._element.getAttribute('period')) : null
		this._dateColumn  = this._element.getAttribute('date-column') ?? 'created_at'
		this._dateFormat  = this._element.getAttribute('date-format') ?? 'Y-m-d'
		this._prefix      = this._element.getAttribute('prefix')
		this._decimal     = parseInt(this._element.getAttribute('decimal')) || 2
		this._timezone    = Intl.DateTimeFormat().resolvedOptions().timeZone
		this._readable   = this._element.hasAttribute('readable')
		this._withPeriod = this._element.hasAttribute('with-period')
		this._withChange = this._element.hasAttribute('with-change')
		this._withChart  = this._element.hasAttribute('with-chart')
		this._lazy        = this._element.hasAttribute('lazy')
		this._numeral     = this._element.hasAttribute('numeral')

		const filter = this._element.getAttribute('filter')
		this._filter = filter ? new Filter(filter) : null

		this._valueEl       = this._element.querySelector('[solar-metric="value"]')
		this._changeBadgeEl = this._element.querySelector('[solar-metric="change-badge"]')
		this._changeIconEl  = this._element.querySelector('[solar-metric="change-icon"]')
		this._changeValueEl = this._element.querySelector('[solar-metric="change-value"]')
		this._changeTitleEl = this._element.querySelector('[solar-metric="change-title"]')
		this._chartEl       = this._element.querySelector('[solar-metric="chart"]')
		this._contentEl     = this._element.querySelector('[solar-metric="content"]')
		this._placeholderEl = this._element.querySelector('[solar-metric="placeholder"]')

		// Bind to the inner numeral element so its decimals/separator attributes are honoured.
		const numeralEl = this._valueEl?.querySelector('[solar-ui="numeral"]') ?? this._valueEl

		this._chart           = null
		this._numeralInstance = this._numeral && numeralEl ? new Numeral(numeralEl) : null

		// Hide placeholder initially if present
		this._placeholderEl?.classList.add('d-none')

		if (!this._lazy) {
			this.init()
		}
	}

	destroy() {
		this._events.clear()

		this._chart?.destroy()
		this._numeralInstance?.destroy()

		this._chart          = null
		this._numeralInstance = null
		this._element       = null
		this._valueEl       = null
		this._changeBadgeEl = null
		this._changeIconEl  = null
		this._changeValueEl = null
		this._changeTitleEl = null
		this._chartEl       = null
		this._contentEl     = null
		this._placeholderEl = null
		this._filter        = null
	}

	/**
	 * Fetch and render metric data. Must be called manually when lazy=true.
	 * @returns {Promise<void>}
	 */
	async init() {
		if (!this._model) {
			this.unload()
			return
		}

		this.load()
		await this._renderData(await this._fetchData())
	}

	// #endregion

	// #region Public API

	/**
	 * @returns {Promise<void>}
	 */
	async refresh() {
		if (!this._model) {
			return
		}

		this.load()
		await this._renderData(await this._fetchData())
	}

	/**
	 * @param {string[]} period
	 * @param {boolean}  refresh
	 * @returns {Promise<void>}
	 */
	async setPeriod(period, refresh = false) {
		if (!Array.isArray(period)) {
			throw new Error('Period must be an array')
		}

		this._period = period

		if (refresh) {
			await this.refresh()
		}
	}

	/**
	 * @param {Filter}  filter
	 * @param {boolean} refresh
	 * @returns {Promise<void>}
	 */
	async setFilter(filter, refresh = false) {
		this._filter = filter

		if (refresh) {
			await this.refresh()
		}
	}

	/**
	 * @param {string|number} value
	 */
	setValue(value) {
		this._renderValue(value)
	}

	/**
	 * @param {{value: string, type: string|null, title: string}} change
	 */
	setChange(change) {
		this._renderChange(change)
	}

	/**
	 * @param {Array} series
	 * @returns {Promise<void>}
	 */
	async setChart(series) {
		await this._renderChart(series)
	}

	load() {
		this._contentEl?.classList.add('d-none')

		if (this._placeholderEl) {
			this._placeholderEl.classList.remove('d-none')
			return
		}

		this._element?.classList.add('placeholder-glow')
		this._valueEl?.classList.add('placeholder', 'rounded')
		this._changeValueEl?.classList.add('placeholder', 'rounded')
		this._changeTitleEl?.classList.add('placeholder', 'rounded')
	}

	unload() {
		this._contentEl?.classList.remove('d-none')

		if (this._placeholderEl) {
			this._placeholderEl.classList.add('d-none')
			return
		}

		this._element?.classList.remove('placeholder-glow')
		this._valueEl?.classList.remove('placeholder', 'rounded')
		this._changeValueEl?.classList.remove('placeholder', 'rounded')
		this._changeTitleEl?.classList.remove('placeholder', 'rounded')
	}

	// #endregion

	// #region Data

	/**
	 * @returns {Promise<{value: string, change: {value: string, type: string|null, title: string}, chart: Array}|null>}
	 */
	async _fetchData() {
		try {
			const response = await axios({
				method: 'POST',
				url: `${BASE_URL}/core/dashboard/metric`,
				data: {
					period:      this._period,
					date_column: this._dateColumn,
					date_format: this._dateFormat,
					prefix:      this._prefix,
					decimal:     this._decimal,
					filter:      this._filter?.get(),
					timezone:    this._timezone,
					readable:    this._readable,
					with_period: this._withPeriod,
					with_change: this._withChange,
					with_chart:  this._withChart,
				},
				headers: { 'X-Model': this._model },
			})

			return response.data
		} catch (error) {
			if (!error?.response) {
				Helper.errorAlert({ title: 'Error', message: 'Failed to load metric data.' })
			}

			return null
		}
	}

	/**
	 * @param {{value: string, change: {value: string, type: string|null, title: string}, chart: Array}|null} data
	 * @returns {Promise<void>}
	 */
	async _renderData(data) {
		if (!data) {
			return
		}

		this._renderValue(data.value)
		if (data.change) this._renderChange(data.change)
		await this._renderChart(data.chart)

		this.unload()
	}

	// #endregion

	// #region Rendering

	/**
	 * @param {string|number} value
	 */
	_renderValue(value) {
		if (!this._valueEl) {
			return
		}

		if (this._numeralInstance) {
			this._numeralInstance.set(value)
			return
		}

		this._valueEl.textContent = value
	}

	/**
	 * @param {{value: string, type: string|null, title: string}} change
	 */
	_renderChange(change) {
		if (!change) return

		const { value, type, title } = change
		if (this._changeBadgeEl) {
			const upClasses   = this._changeBadgeEl.dataset.up?.split(' ')   ?? []
			const downClasses = this._changeBadgeEl.dataset.down?.split(' ') ?? []

			this._changeBadgeEl.classList.remove(...upClasses, ...downClasses)
			if (type) {
				this._changeBadgeEl.classList.add(...(type === 'up' ? upClasses : downClasses))
			}
		}

		if (this._changeIconEl) {
			const icon = type === 'up'
				? this._changeIconEl.dataset.up
				: this._changeIconEl.dataset.down

			this._changeIconEl.className = icon ? `${icon} fs-11` : ''
		}

		if (this._changeValueEl) {
			this._changeValueEl.textContent = value ?? ''
		}

		if (this._changeTitleEl) {
			this._changeTitleEl.textContent = title ?? ''
		}
	}

	/**
	 * @param {Array} series
	 * @returns {Promise<void>}
	 */
	async _renderChart(series) {
		if (!this._chartEl || !series) {
			return
		}

		const defaults = this._defaultChartOptions(series)
		const results  = await this.trigger('chart', defaults, series, this._color, this._chartEl)
		const options  = results?.[0] ?? defaults

		if (this._chart) {
			this._chart.updateSeries(options.series ?? series)
			return
		}

		this._chart = new ApexCharts(this._chartEl, options)
		this._chart.render()
	}

	/**
	 * Returns the built-in chart config for the current variant.
	 * Falls back to chartSummary for custom UI or unknown variants.
	 * @param {Array} series
	 * @returns {Object}
	 */
	_defaultChartOptions(series) {
		switch (this._variant) {
			case 'summary': return MetricDashboard.chartSummary(series, this._color)
			case 'compact': return MetricDashboard.chartCompact(series, this._color)
			case 'detail':  return MetricDashboard.chartDetail(series, this._color)
			default:        return MetricDashboard.chartSummary(series, this._color)
		}
	}

	// #endregion
}
