import Helper from './helper'

export default class AudioChat {

	// #region Lifecycle

	/**
	 * @param {HTMLElement|null} list    — [data-messages-list]
	 * @param {HTMLElement|null} content — [data-chat-content]
	 */
	constructor(list, content) {
		this._list    = list
		this._content = content
		this._bindClick()
	}

	// #endregion

	// #region Public API

	/**
	 * Initialize all uninitialized audio players inside the message list.
	 * @returns {void}
	 */
	initPlayers() {
		this._list?.querySelectorAll('.chat-audio-player:not([data-audio-initialized])').forEach(player => {
			this._initPlayer(player)
		})
	}

	/**
	 * Render the audio player HTML for a given message object.
	 * Mirrors the audio branch of chat/message.blade.php.
	 * @param {Object} msg
	 * @returns {string}
	 */
	renderHtml(msg) {
		const isReady  = !!msg.media_url
		const playIcon = isReady ? 'ri-play-fill' : 'ri-loader-4-line'
		const src      = isReady ? `src="${Helper.esc(msg.media_url)}"` : ''
		const disabled = isReady ? '' : ' disabled'

		return `<div class="chat-audio-player">
			<button type="button" class="chat-audio-play-btn" aria-label="Play audio">
				<i class="${playIcon}"></i>
			</button>
			<div class="chat-audio-track">
				<div class="chat-audio-progress">
					<div class="chat-audio-progress-fill"></div>
					<div class="chat-audio-progress-thumb"></div>
					<input type="range" class="chat-audio-range" value="0" min="0" max="100" step="0.1"${disabled}>
				</div>
				<span class="chat-audio-time">0:00</span>
			</div>
			<audio ${src} preload="none" data-audio-el></audio>
		</div>`
	}

	/**
	 * Apply media-ready state to an audio player inside a message <li>.
	 * Called by Chat._handleMediaReady() when WaMessageMediaReady fires for audio.
	 * @param {HTMLElement} li
	 * @param {string} mediaUrl
	 * @returns {void}
	 */
	handleMediaReady(li, mediaUrl) {
		const audio = li.querySelector('[data-audio-el]')
		if (!audio) {
			return
		}

		audio.src = mediaUrl

		const playIcon = li.querySelector('.chat-audio-play-btn i')
		if (playIcon) {
			playIcon.className = 'ri-play-fill'
		}

		li.querySelector('.chat-audio-range')?.removeAttribute('disabled')

		const player = li.querySelector('.chat-audio-player')
		if (player) {
			this._initPlayer(player)
		}
	}

	// #endregion

	// #region Player Init

	/**
	 * Wire up all events for one audio player element.
	 * Guard: data-audio-initialized prevents double init.
	 * @param {HTMLElement} player
	 * @returns {void}
	 */
	_initPlayer(player) {
		if (!player || player.dataset.audioInitialized) {
			return
		}

		const audio    = player.querySelector('[data-audio-el]')
		const fill     = player.querySelector('.chat-audio-progress-fill')
		const thumb    = player.querySelector('.chat-audio-progress-thumb')
		const range    = player.querySelector('.chat-audio-range')
		const timeEl   = player.querySelector('.chat-audio-time')
		const playIcon = player.querySelector('.chat-audio-play-btn i')

		if (!audio) {
			return
		}

		player.dataset.audioInitialized = '1'

		const setProgress = (pct) => {
			if (fill)  fill.style.width = `${pct}%`
			if (thumb) thumb.style.left = `${pct}%`
			if (range) range.value      = pct
		}

		setProgress(0)

		audio.addEventListener('loadedmetadata', () => {
			if (timeEl && audio.paused) {
				timeEl.textContent = this._formatTime(audio.duration)
			}
		})

		let rafId = null

		const tick = () => {
			// Update progress only once duration is known.
			// Keep looping even if duration not yet available so we don't miss
			// the moment playback starts (fixes first-load RAF exit bug).
			if (audio.duration) {
				const pct = (audio.currentTime / audio.duration) * 100
				setProgress(pct)
				if (timeEl) {
					timeEl.textContent = this._formatTime(audio.currentTime)
				}
			}

			if (!audio.paused && !audio.ended) {
				rafId = requestAnimationFrame(tick)
			}
		}

		audio.addEventListener('play', () => {
			if (playIcon) {
				playIcon.className = 'ri-pause-fill'
			}
			rafId = requestAnimationFrame(tick)
		})

		audio.addEventListener('pause', () => {
			if (playIcon) {
				playIcon.className = 'ri-play-fill'
			}
			if (rafId) {
				cancelAnimationFrame(rafId)
			}
		})

		audio.addEventListener('ended', () => {
			if (rafId) {
				cancelAnimationFrame(rafId)
			}
			setProgress(0)
			if (timeEl) {
				timeEl.textContent = this._formatTime(audio.duration || 0)
			}
			if (playIcon) {
				playIcon.className = 'ri-play-fill'
			}
		})

		range?.addEventListener('input', () => {
			if (audio.duration) {
				const pct         = parseFloat(range.value)
				audio.currentTime = (pct / 100) * audio.duration
				setProgress(pct)
				if (timeEl) {
					timeEl.textContent = this._formatTime(audio.currentTime)
				}
			}
		})
	}

	// #endregion

	// #region Events

	/**
	 * Delegated click handler for play/pause buttons.
	 * Pauses all other active players when a new one starts.
	 * @returns {void}
	 */
	_bindClick() {
		this._content?.addEventListener('click', (e) => {
			const playBtn = e.target.closest('.chat-audio-play-btn')
			if (!playBtn) {
				return
			}

			const player = playBtn.closest('.chat-audio-player')
			const audio  = player?.querySelector('[data-audio-el]')
			if (!audio) {
				return
			}

			// Not ready yet (spinner state)
			if (!audio.src || audio.src === window.location.href) {
				return
			}

			// Ensure initialized — catches SSR players not yet wired up
			this._initPlayer(player)

			if (audio.paused) {
				this._list?.querySelectorAll('[data-audio-el]').forEach(a => {
					if (a !== audio && !a.paused) {
						a.pause()
					}
				})
				audio.play().catch(() => {})
			} else {
				audio.pause()
			}
		})
	}

	// #endregion

	// #region Helpers

	/**
	 * @param {number} seconds
	 * @returns {string}
	 */
	_formatTime(seconds) {
		if (!seconds || isNaN(seconds)) {
			return '0:00'
		}
		const m = Math.floor(seconds / 60)
		const s = Math.floor(seconds % 60)
		return `${m}:${s.toString().padStart(2, '0')}`
	}

	// #endregion
}
