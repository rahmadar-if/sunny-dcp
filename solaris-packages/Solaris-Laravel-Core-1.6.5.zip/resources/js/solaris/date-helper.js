export default class DateHelper {

    //#region Internal data

    static _MONTHS_FULL  = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
    static _MONTHS_SHORT = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    static _DAYS_FULL    = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
    static _DAYS_SHORT   = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']

    //#endregion

    //#region Type check

    /**
     * @param {*} value
     * @returns {boolean}
     */
    static isDate(value) {
        return value !== null && value !== undefined && value instanceof Date
    }

    //#endregion

    //#region Date object formatters

    /**
     * Date object to HH:mm or HH:mm:ss.
     * @param {Date} date
     * @param {boolean} [utc=false]
     * @param {boolean} [withSeconds=true]
     * @returns {string}
     */
    static timeToString(date, utc = false, withSeconds = true) {
        if (!DateHelper.isDate(date)) {
            throw `${date} is not valid date`
        }

        const h = (utc ? date.getUTCHours() : date.getHours()).toString().padStart(2, '0')
        const m = (utc ? date.getUTCMinutes() : date.getMinutes()).toString().padStart(2, '0')

        if (!withSeconds) {
            return `${h}:${m}`
        }

        const s = (utc ? date.getUTCSeconds() : date.getSeconds()).toString().padStart(2, '0')

        return `${h}:${m}:${s}`
    }

    /**
     * Date object to YYYY-MM-DD.
     * @param {Date} date
     * @returns {string}
     */
    static dateToString(date) {
        if (!DateHelper.isDate(date)) {
            throw `${date} is not valid date`
        }

        const year  = date.getFullYear()
        const month = String(date.getMonth() + 1).padStart(2, '0')
        const day   = String(date.getDate()).padStart(2, '0')

        return `${year}-${month}-${day}`
    }

    /**
     * Date object to YYYY-MM-DD HH:mm:ss.
     * @param {Date} date
     * @returns {string}
     */
    static dateTimeToString(date) {
        if (!DateHelper.isDate(date)) {
            throw `${date} is not valid date`
        }

        const year   = date.getFullYear()
        const month  = String(date.getMonth() + 1).padStart(2, '0')
        const day    = String(date.getDate()).padStart(2, '0')
        const hour   = String(date.getHours()).padStart(2, '0')
        const minute = String(date.getMinutes()).padStart(2, '0')
        const second = String(date.getSeconds()).padStart(2, '0')

        return `${year}-${month}-${day} ${hour}:${minute}:${second}`
    }

    /**
     * Date object to "DD Mon YYYY" (e.g. "11 May 2026").
     * @param {Date} date
     * @returns {string}
     */
    static dateToFullString(date) {
        if (!DateHelper.isDate(date)) {
            throw `${date} is not valid date`
        }

        return new Intl.DateTimeFormat('en-GB', {
            day: '2-digit', month: 'short', year: 'numeric'
        }).format(date)
    }

    /**
     * Date object to "DD Mon YYYY, HH:mm:ss" (e.g. "11 May 2026, 09:30:00").
     * @param {Date} date
     * @returns {string}
     */
    static datetimeToFullString(date) {
        if (!DateHelper.isDate(date)) {
            throw `${date} is not valid date`
        }

        return new Intl.DateTimeFormat('en-GB', {
            day: '2-digit', month: 'short', year: 'numeric',
            hour: '2-digit', minute: '2-digit', second: '2-digit'
        }).format(date)
    }

    //#endregion

    //#region String formatters

    /**
     * Format a UTC ISO 8601 datetime string to local time using tokens.
     * UTC is automatically converted to the browser's local timezone.
     *
     * Supported tokens:
     * | Token  | Output             | Example   |
     * |--------|--------------------|-----------|
     * | yyyy   | 4-digit year       | 2026      |
     * | yy     | 2-digit year       | 26        |
     * | MMMM   | Full month name    | January   |
     * | MMM    | Short month name   | Jan       |
     * | MM     | Month padded       | 05        |
     * | M      | Month              | 5         |
     * | dddd   | Full weekday name  | Monday    |
     * | ddd    | Short weekday name | Mon       |
     * | dd     | Day padded         | 09        |
     * | d      | Day                | 9         |
     * | HH     | Hour 24h padded    | 09        |
     * | H      | Hour 24h           | 9         |
     * | hh     | Hour 12h padded    | 09        |
     * | h      | Hour 12h           | 9         |
     * | mm     | Minute padded      | 05        |
     * | m      | Minute             | 5         |
     * | ss     | Second padded      | 07        |
     * | s      | Second             | 7         |
     * | A      | AM/PM              | AM        |
     * | a      | am/pm              | am        |
     *
     * @param {string} value - UTC ISO 8601 string (e.g. "2026-05-11T02:55:22.000000Z")
     * @param {string} [format='yyyy-MM-dd HH:mm'] - Token-based format string
     * @returns {string}
     */
    static formatDatetime(value, format = 'dd MMM yyyy hh:mm A') {
        if (!value) {
            return ''
        }

        const date = new Date(value)
        if (isNaN(date)) {
            return String(value)
        }

        return DateHelper._applyFormat(format, date)
    }

    /**
     * Format a date-only string without timezone conversion.
     * Parses date parts directly from the string to avoid off-by-one errors in negative UTC offsets.
     *
     * Supported tokens: yyyy yy | MMMM MMM MM M | dddd ddd dd d
     *
     * @param {string} value - Date string (e.g. "2026-05-11" or "2026-05-11T...")
     * @param {string} [format='yyyy-MM-dd'] - Token-based format string
     * @returns {string}
     */
    static formatDate(value, format = 'dd MMM yyyy') {
        if (!value) {
            return ''
        }

        const [year, month, day] = String(value).split('T')[0].split('-')
        if (!year || !month || !day) {
            return String(value)
        }

        const utcDate = new Date(Date.UTC(Number(year), Number(month) - 1, Number(day)))
        const pad     = (n) => String(n).padStart(2, '0')

        const tokenMap = {
            'yyyy': year,
            'yy'  : String(year).slice(-2),
            'MMMM': DateHelper._MONTHS_FULL[Number(month) - 1],
            'MMM' : DateHelper._MONTHS_SHORT[Number(month) - 1],
            'MM'  : pad(month),
            'M'   : String(Number(month)),
            'dddd': DateHelper._DAYS_FULL[utcDate.getUTCDay()],
            'ddd' : DateHelper._DAYS_SHORT[utcDate.getUTCDay()],
            'dd'  : pad(day),
            'd'   : String(Number(day)),
        }

        return format.replace(/MMMM|MMM|MM|M|dddd|ddd|dd|d|yyyy|yy/g, (token) => tokenMap[token] ?? token)
    }

    //#endregion

    //#region Relative time

    /**
     * Format a UTC ISO 8601 datetime string as a human-readable relative time in English.
     * @param {string} value - UTC ISO 8601 string (e.g. "2026-05-19T02:30:00.000000Z")
     * @returns {string} Relative time string (e.g. "10 minutes ago", "2 hours ago")
     */
    static relativeTime(value) {
        if (!value) {
            return ''
        }

        const diffSeconds = Math.floor((Date.now() - new Date(value).getTime()) / 1000)
        const rtf = new Intl.RelativeTimeFormat('en', { numeric: 'auto' })

        if (diffSeconds < 60) {
            return rtf.format(-diffSeconds, 'second')
        }      
        
        if (diffSeconds < 3600) {
            return rtf.format(-Math.floor(diffSeconds / 60), 'minute')
        }

        if (diffSeconds < 86400) {
            return rtf.format(-Math.floor(diffSeconds / 3600), 'hour')
        }

        if (diffSeconds < 2592000) {
            return rtf.format(-Math.floor(diffSeconds / 86400), 'day')
        }

        if (diffSeconds < 31536000) {
            return rtf.format(-Math.floor(diffSeconds / 2592000), 'month')
        } 

        return rtf.format(-Math.floor(diffSeconds / 31536000), 'year')
    }

    //#endregion

    //#region Private

    /**
     * Apply token-based format to a Date object using local time.
     * @param {string} format
     * @param {Date} date
     * @returns {string}
     */
    static _applyFormat(format, date) {
        const pad     = (n) => String(n).padStart(2, '0')
        const hours24 = date.getHours()
        const hours12 = hours24 % 12 || 12

        const tokenMap = {
            'yyyy': date.getFullYear(),
            'yy'  : String(date.getFullYear()).slice(-2),
            'MMMM': DateHelper._MONTHS_FULL[date.getMonth()],
            'MMM' : DateHelper._MONTHS_SHORT[date.getMonth()],
            'MM'  : pad(date.getMonth() + 1),
            'M'   : String(date.getMonth() + 1),
            'dddd': DateHelper._DAYS_FULL[date.getDay()],
            'ddd' : DateHelper._DAYS_SHORT[date.getDay()],
            'dd'  : pad(date.getDate()),
            'd'   : String(date.getDate()),
            'HH'  : pad(hours24),
            'H'   : String(hours24),
            'hh'  : pad(hours12),
            'h'   : String(hours12),
            'mm'  : pad(date.getMinutes()),
            'm'   : String(date.getMinutes()),
            'ss'  : pad(date.getSeconds()),
            's'   : String(date.getSeconds()),
            'A'   : hours24 < 12 ? 'AM' : 'PM',
            'a'   : hours24 < 12 ? 'am' : 'pm',
        }

        return format.replace(/MMMM|MMM|MM|M|dddd|ddd|dd|d|yyyy|yy|HH|H|hh|h|mm|m|ss|s|A|a/g, (token) => tokenMap[token] ?? token)
    }

    //#endregion
}
