import SolarComponent from "./solar/solar-component"

export default class DragDropHelper extends SolarComponent {
	_container = null
	_options = {}
	_dragEl = null
	_dragAllowed = false
	_listeners = []

	static supportedEvent() {
		return ['start', 'end', 'over', 'leave', 'drop']
	}

	constructor(container, options = {}) {
		super()

		this._container = typeof container === 'string'
			? document.querySelector(container)
			: container

		this._options = {
			draggable: '[draggable]',
			handle: null,
			dropZone: null,
			zones: false,
			selector: null,
			thresholds: { before: 0.25, after: 0.75 },
			data: (el) => el.dataset.id ?? '',
			...options,
		}

		if (this._options.dropZone === null) {
			this._options.dropZone = this._options.draggable
		}

		this._bindSource()
		this._bindDropZone()
	}

	get dragging() {
		return this._dragEl
	}

	getDropZone(y, rect, thresholds = {}) {
		const before = thresholds.before ?? this._options.thresholds.before
		const after = thresholds.after ?? this._options.thresholds.after
		const relY = (y - rect.top) / rect.height

		if (relY < before) return 'before'
		if (relY > after) return 'after'
		return 'inside'
	}

	getDragAfterElement(container, y, selector) {
		const elements = [...container.querySelectorAll(selector)]

		return elements.reduce((closest, el) => {
			const rect = el.getBoundingClientRect()
			const offset = y - rect.top - rect.height / 2

			if (offset < 0 && offset > closest.offset) {
				return { offset, el }
			}
			return closest
		}, { offset: Number.NEGATIVE_INFINITY, el: null }).el
	}

	clearIndicators(root, classes = []) {
		classes.forEach(cls => {
			root.querySelectorAll(`.${cls}`).forEach(el => el.classList.remove(cls))
		})
	}

	destroy() {
		this._listeners.forEach(({ el, type, fn }) => el.removeEventListener(type, fn))
		this._listeners = []
		this._dragEl = null
		this._dragAllowed = false
	}

	_addListener(el, type, fn) {
		el.addEventListener(type, fn)
		this._listeners.push({ el, type, fn })
	}

	_bindSource() {
		const { handle, draggable } = this._options

		if (handle) {
			this._addListener(this._container, 'mousedown', (e) => {
				if (e.target.closest(handle)) {
					this._dragAllowed = true
				}
			})

			this._addListener(this._container, 'mouseup', () => {
				this._dragAllowed = false
			})
		}

		this._addListener(this._container, 'dragstart', (e) => {
			const dragEl = e.target.closest(draggable)
			if (!dragEl) return

			if (handle && !this._dragAllowed) {
				e.preventDefault()
				return
			}

			e.dataTransfer.effectAllowed = 'move'
			e.dataTransfer.setData('text/plain', this._options.data(dragEl))
			this._dragEl = dragEl
			this.trigger('start', e, dragEl)
		})

		this._addListener(this._container, 'dragend', (e) => {
			const dragEl = e.target.closest(draggable)
			if (!dragEl) return

			const el = this._dragEl
			this._dragEl = null
			this._dragAllowed = false
			this.trigger('end', e, el)
		})
	}

	_bindDropZone() {
		const { dropZone, zones, selector } = this._options

		this._addListener(this._container, 'dragover', (e) => {
			const targetEl = e.target.closest(dropZone)
			if (!targetEl || !this._dragEl) return

			e.preventDefault()

			let zone = null
			let afterEl = null

			if (zones) {
				zone = this.getDropZone(e.clientY, targetEl.getBoundingClientRect())
			}

			if (selector || !zones) {
				const sel = selector ?? dropZone
				afterEl = this.getDragAfterElement(this._container, e.clientY, sel)
			}

			this.trigger('over', e, this._dragEl, targetEl, zone, afterEl)
		})

		this._addListener(this._container, 'dragleave', (e) => {
			const targetEl = e.target.closest(dropZone)
			if (!targetEl || !this._dragEl) return

			const related = e.relatedTarget
			if (related && targetEl.contains(related)) return

			this.trigger('leave', e, this._dragEl, targetEl)
		})

		this._addListener(this._container, 'drop', (e) => {
			const targetEl = e.target.closest(dropZone)
			if (!targetEl || !this._dragEl) return

			e.preventDefault()

			let zone = null
			let afterEl = null

			if (zones) {
				zone = this.getDropZone(e.clientY, targetEl.getBoundingClientRect())
			}

			if (selector || !zones) {
				const sel = selector ?? dropZone
				afterEl = this.getDragAfterElement(this._container, e.clientY, sel)
			}

			this.trigger('drop', e, this._dragEl, targetEl, zone, afterEl)
		})
	}
}
