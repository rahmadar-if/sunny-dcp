import Helper from "./helper"
import SolarComponent from "./solar/solar-component"

// #region Static

let _sharedTooltip = null

/**
 * @returns {HTMLElement}
 */
function _getSharedTooltip() {
	if (!_sharedTooltip) {
		_sharedTooltip = document.createElement('div')
		_sharedTooltip.className = 'solar-funnel-tooltip'
		document.body.appendChild(_sharedTooltip)
	}
	return _sharedTooltip
}

// #endregion

export default class FunnelChart extends SolarComponent {

	// #region Static

	static supportedEvent() {
		return ['click', 'tooltip']
	}

	// #endregion

	// #region Lifecycle

	/**
	 * @param {HTMLElement|string} selector
	 */
	constructor(selector) {
		super()

		if (selector instanceof HTMLElement) {
			this._element = selector
		} else if (Helper.isString(selector) && !Helper.isEmpty(selector)) {
			this._element = document.querySelector(selector)
			if (!this._element) {
				throw new Error(`Element with query selector ${selector} is not found`)
			}
		} else {
			throw new Error(`Selector is supported`)
		}

		if (!this._element.classList.contains('solar-funnel')) {
			this._element.classList.add('solar-funnel')
		}

		this.id        = this._element.id
		this._maxWidth = parseInt(this._element.getAttribute("max-width") ?? 100)
		this._minWidth = parseInt(this._element.getAttribute("min-width") ?? 20)
		this._height   = parseInt(this._element.getAttribute("height") ?? 100)
		this._data     = []

		try {
			const data = this._element.getAttribute("data")
			if (data) {
				this._data = JSON.parse(decodeURIComponent(data))
			}
		} catch (error) {
			console.error({ error })
		}

		if (!this._element.hasAttribute("lazy")) {
			this.render()
		}
	}

	render() {
		this._element.innerHTML = ""

		const n = this._data.length
		for (let i = 0; i < n; i++) {
			const item = this._data[i]

			const top    = this._maxWidth - (i * (this._maxWidth - this._minWidth) / n)
			const bottom = this._maxWidth - ((i + 1) * (this._maxWidth - this._minWidth) / n)

			const leftTop     = (100 - top) / 2
			const rightTop    = 100 - leftTop
			const leftBottom  = (100 - bottom) / 2
			const rightBottom = 100 - leftBottom

			const div          = document.createElement("div")
			div.className      = `solar-funnel-item ${item.color ? `solar-funnel-color-${item.color}` : 'solar-funnel-color-primary'}`
			div.style.height   = this._height + "px"
			div.style.clipPath = `polygon(${leftTop}% 0, ${rightTop}% 0, ${rightBottom}% 100%, ${leftBottom}% 100%)`

			if (this._hasEvent('click')) {
				div.style.cursor = 'pointer'
			}

			const title       = document.createElement("div")
			title.className   = "fs-12"
			title.textContent = item.name

			const value       = document.createElement("div")
			value.className   = "fs-16"
			value.textContent = item.value

			div.appendChild(title)
			div.appendChild(value)

			this._bindItemEvents(div, i)

			this._element.appendChild(div)
		}
	}

	// #endregion

	// #region Public API

	/**
	 * @param {number} maxWidth
	 * @param {number} minWidth
	 * @param {number} height
	 */
	setOptions(maxWidth, minWidth, height) {
		this._maxWidth = maxWidth
		this._minWidth = minWidth
		this._height   = height
	}

	/**
	 * @param {Array<{name: string, value: string, color: string}>} data
	 */
	updateData(data) {
		this._data = data
		this.render()
	}

	/**
	 * @param {string} type
	 * @param {Function} callback
	 * @param {string|null} name
	 * @returns {FunnelChart}
	 */
	on(type, callback, name = null) {
		super.on(type, callback, name)

		if (type === 'click') {
			this._element.querySelectorAll('.solar-funnel-item').forEach(el => {
				el.style.cursor = 'pointer'
			})
		}

		return this
	}

	// #endregion

	// #region Events

	/**
	 * @param {HTMLElement} el
	 * @param {number} index
	 */
	_bindItemEvents(el, index) {
		el.addEventListener('mouseenter', (e) => this._onMouseEnter(e, index))
		el.addEventListener('mouseleave', () => this._onMouseLeave())
		el.addEventListener('mousemove', (e) => this._onMouseMove(e))
		el.addEventListener('click', () => this._onClick(index))
	}

	/**
	 * @param {MouseEvent} e
	 * @param {number} index
	 */
	async _onMouseEnter(e, index) {
		const context = {
			item      : this._data[index],
			index,
			totalItems: this._data.length,
			items     : this._data,
		}

		let html
		if (this._hasEvent('tooltip')) {
			const results = await this.trigger('tooltip', context)
			html = results?.[0] ?? this._defaultFormatter(context)
		} else {
			html = this._defaultFormatter(context)
		}

		this._showTooltip(html, e)
	}

	_onMouseLeave() {
		this._hideTooltip()
	}

	/**
	 * @param {MouseEvent} e
	 */
	_onMouseMove(e) {
		this._positionTooltip(e)
	}

	/**
	 * @param {number} index
	 */
	async _onClick(index) {
		if (!this._hasEvent('click')) {
			return
		}
		await this.trigger('click', { item: this._data[index], index })
	}

	// #endregion

	// #region Tooltip

	/**
	 * @param {string} html
	 * @param {MouseEvent} e
	 */
	_showTooltip(html, e) {
		const tooltip = _getSharedTooltip()
		tooltip.innerHTML = html
		tooltip.classList.add('is-visible')
		this._positionTooltip(e)
	}

	_hideTooltip() {
		_getSharedTooltip().classList.remove('is-visible')
	}

	/**
	 * @param {MouseEvent} e
	 */
	_positionTooltip(e) {
		const tooltip = _getSharedTooltip()
		const offset  = 14
		const vw      = window.innerWidth
		const vh      = window.innerHeight
		const tw      = tooltip.offsetWidth
		const th      = tooltip.offsetHeight

		let x = e.clientX + offset
		let y = e.clientY + offset

		if (x + tw > vw) {
			x = e.clientX - tw - offset
		}
		if (y + th > vh) {
			y = e.clientY - th - offset
		}

		tooltip.style.left = x + 'px'
		tooltip.style.top  = y + 'px'
	}

	/**
	 * @param {{ item: Object, index: number, totalItems: number, items: Array }} context
	 * @returns {string}
	 */
	_defaultFormatter({ item, index, totalItems }) {
		return `
			<div class="solar-funnel-tooltip-name">${item.name}</div>
			<div class="solar-funnel-tooltip-value">${item.value}</div>
			<div class="solar-funnel-tooltip-stage">Stage ${index + 1} / ${totalItems}</div>
		`
	}

	// #endregion

	// #region Helpers

	/**
	 * @param {string} type
	 * @returns {boolean}
	 */
	_hasEvent(type) {
		return this._events.has(type) && this._events.get(type).length > 0
	}

	// #endregion
}
