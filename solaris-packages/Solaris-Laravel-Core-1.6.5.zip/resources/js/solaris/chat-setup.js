import axios from "../libs/axios"
import Modal from "./modal"
import Button from "./button"

export default class ChatSetup {

	// #region Lifecycle

	/**
	 * @param {string} device
	 * @param {string} apiBase
	 */
	constructor(device, apiBase) {
		this._device     = device
		this._apiBase    = apiBase
		this._qrSource   = null
		this._deviceName = '—'
	}

	/**
	 * @returns {void}
	 */
	init() {
		/** @type {Modal} */
		this.modal = new Modal(document.getElementById('setup-modal'))

		/** @type {Button} */
		this.btnRefresh = new Button(document.getElementById('setup-modal_btn-refresh'))

		/** @type {Button} */
		this.btnConnect = new Button(document.getElementById('setup-modal_btn-connect'))

		/** @type {Button} */
		this.btnDisconnect = new Button(document.getElementById('setup-modal_btn-disconnect'))

		/** @type {Button} */
		this.btnCancelQr = new Button(document.getElementById('setup-modal_btn-cancel-qr'))

		this.modal?.on('hide', () => this._cancelQr())
		this.btnRefresh?.on('click',    () => this._loadInfo())
		this.btnConnect?.on('click',    () => this._onConnect())
		this.btnDisconnect?.on('click', () => this._onDisconnect())
		this.btnCancelQr?.on('click',   () => this._cancelQr())
	}

	// #endregion

	// #region Public

	/**
	 * @returns {void}
	 */
	open() {
		this.modal?.show()
		this._loadInfo()
	}

	// #endregion

	// #region State

	/**
	 * @param {'loading'|'info'|'qr'|'error'} state
	 * @returns {void}
	 */
	_showState(state) {
		;['loading', 'info', 'qr', 'error'].forEach(s => {
			document.getElementById(`setup-modal_state-${s}`)?.classList.toggle('d-none', s !== state)
		})

		if (state === 'info') {
			this.btnRefresh?.show()
		} else {
			this.btnRefresh?.hidden()
			this.btnConnect?.hidden()
			this.btnDisconnect?.hidden()
		}

		if (state === 'qr') {
			this.btnCancelQr?.show()
		} else {
			this.btnCancelQr?.hidden()
		}
	}

	// #endregion

	// #region Load Info

	/**
	 * @returns {Promise<void>}
	 */
	async _loadInfo() {
		this._showState('loading')

		try {
			const res = await axios.get(`${this._apiBase}/device-info`, {
				headers: { 'X-Device-Id': this._device },
			})
			this._renderInfo(res.data)
			this._showState('info')
		} catch {
			this._showState('error')
		}
	}

	/**
	 * @param {Object} data
	 * @returns {void}
	 */
	_renderInfo(data) {
		this._deviceName = data.name

		document.getElementById('setup-modal_device-name').textContent  = data.name
		document.getElementById('setup-modal_phone-number').textContent = data.phone_number ?? 'No active number'

		const badge = document.getElementById('setup-modal_status-badge')
		if (data.is_connected) {
			badge.textContent = 'CONNECTED'
			badge.className   = 'badge bg-success px-3 py-2'
		} else {
			badge.textContent = 'DISCONNECTED'
			badge.className   = 'badge bg-secondary px-3 py-2'
		}

		const quotaSection = document.getElementById('setup-modal_quota-section')
		if (data.quota) {
			const { used, total, package: pkg, expires_at } = data.quota
			const pct = total > 0 ? Math.round((used / total) * 100) : 0

			document.getElementById('setup-modal_quota-package').textContent =
				pkg ?? '—'
			document.getElementById('setup-modal_quota-expires').textContent =
				new Date(expires_at).toLocaleString('en-US', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })

			const bar       = document.getElementById('setup-modal_quota-bar')
			bar.style.width = `${pct}%`
			bar.className   = `progress-bar ${pct >= 90 ? 'bg-danger' : pct >= 70 ? 'bg-warning' : 'bg-primary'}`

			document.getElementById('setup-modal_quota-used-text').textContent =
				`${used.toLocaleString('en-US')} / ${total.toLocaleString('en-US')} messages`
			document.getElementById('setup-modal_quota-pct').textContent = `${pct}% used`

			quotaSection.classList.remove('d-none')
		} else {
			quotaSection.classList.add('d-none')
		}

		const dailySection = document.getElementById('setup-modal_daily-section')
		if (data.quota?.daily_limit) {
			const used  = data.daily_used ?? 0
			const limit = data.quota.daily_limit
			const pct   = limit > 0 ? Math.round((used / limit) * 100) : 0

			document.getElementById('setup-modal_daily-text').textContent =
				`${used.toLocaleString('en-US')} / ${limit.toLocaleString('en-US')} messages`
			document.getElementById('setup-modal_daily-bar').style.width = `${pct}%`

			dailySection.classList.remove('d-none')
		} else {
			dailySection.classList.add('d-none')
		}

		if (data.is_connected) {
			this.btnConnect?.hidden()
			this.btnDisconnect?.show()
		} else {
			this.btnConnect?.show()
			this.btnDisconnect?.hidden()
		}
	}

	// #endregion

	// #region Connect / Disconnect

	/**
	 * @returns {Promise<void>}
	 */
	async _onConnect() {
		this.btnConnect?.load()

		try {
			await axios.post(`${this._apiBase}/connect`, null, {
				headers: { 'X-Device-Id': this._device },
			})
		} catch {
			this.btnConnect?.unload()
			return
		}

		this.btnConnect?.unload()

		document.getElementById('setup-modal_qr-device-name').textContent = this._deviceName
		document.getElementById('setup-modal_qr-spinner').classList.remove('d-none')
		document.getElementById('setup-modal_qr-img-wrap').classList.add('d-none')

		this._showState('qr')
		this._openQrStream()
	}

	/**
	 * @returns {Promise<void>}
	 */
	async _onDisconnect() {
		this.btnDisconnect?.load()

		try {
			await axios.post(`${this._apiBase}/logout`, null, {
				headers: { 'X-Device-Id': this._device },
			})
			this.btnDisconnect?.unload()
			await this._loadInfo()
		} catch {
			this.btnDisconnect?.unload()
		}
	}

	// #endregion

	// #region QR Stream

	/**
	 * @returns {void}
	 */
	_openQrStream() {
		this._cancelQr()

		const source   = new EventSource(`${this._apiBase}/qr-stream?device=${this._device}`)
		this._qrSource = source

		source.onmessage = (event) => {
			const data = JSON.parse(event.data)

			if (data.type === 'qr') {
				const spinner = document.getElementById('setup-modal_qr-spinner')
				const imgWrap = document.getElementById('setup-modal_qr-img-wrap')
				const img     = document.getElementById('setup-modal_qr-img')

				spinner?.classList.add('d-none')
				imgWrap?.classList.remove('d-none')
				if (img) {
					img.src = data.image
				}
			} else if (data.type === 'status' && data.status === 'CONNECTED') {
				this._cancelQr()
				this._loadInfo()
			} else if (data.type === 'error') {
				this._cancelQr()
				const errEl = document.getElementById('setup-modal_error-msg')
				if (errEl) {
					errEl.textContent = data.message
				}
				this._showState('error')
			}
		}

		source.onerror = () => {
			if (this._qrSource !== source) {
				return
			}
			this._cancelQr()
			this._showState('error')
		}
	}

	/**
	 * @returns {void}
	 */
	_cancelQr() {
		if (this._qrSource) {
			this._qrSource.close()
			this._qrSource = null
		}
	}

	// #endregion
}
