import { AxiosError } from "axios"
import Dropzone from "dropzone"
import Helper from "./helper"
import FileHelper from "./file-helper"
import SolarComponent from "./solar/solar-component"

export default class DropzoneUpload extends SolarComponent {
	constructor(selector) {
		super()

		if (selector instanceof Element) {
			this._element = selector
		} else if (Helper.isString(selector) && !Helper.isEmpty(selector)) {
			this._element = document.querySelector(selector)
			if (!this._element) {
				throw new Error(`Element with query selector ${selector} is not found`)
			}
		} else {
			throw new Error(`Selector is not supported`)
		}

		this._id          = this._element.id
		this._chunkSize   = parseInt(this._element.getAttribute("chunk-size") ?? 2000000)
		this._maxFileSize = this._clampFileSize(this._element.getAttribute("max-file-size") ?? MAX_FILE_SIZE)
		this._url         = this._element.getAttribute("upload-url") ?? `${BASE_URL}/core/attachment`
		this._multiple    = this._element.hasAttribute("multiple")
		this._auto        = this._element.hasAttribute("auto")
		this._paramName   = this._element.getAttribute("param-name") ?? "file"
		this._tableName   = this._element.getAttribute("table-name") ?? null
		this._model       = this._element.getAttribute("model") ?? null
		this._recordId    = this._element.getAttribute("record-id") ?? null
		this._acceptFiles   = this._element.getAttribute("accept-files") ?? null
		this._thumbnailSize = this._element.getAttribute("thumbnail-size") ?? null
		this._dropzone      = null

		if (!this._element.hasAttribute("lazy")) {
			this.init()
		}
	}

	static supportedEvent() {
		return ["addedfile", "sending", "success", "error", "removedfile", "queuecomplete"]
	}

	/**
	 * @param {Object} options
	 * @param {string|null} options.url
	 * @param {string|null} options.tableName
	 * @param {string|null} options.model
	 * @param {string|null} options.recordId
	 * @param {number} options.chunkSize
	 * @returns {DropzoneUpload}
	 */
	static createHidden({ url = null, tableName = null, model = null, recordId = null, chunkSize = 2000000, paramName = null, thumbnailSize = null } = {}) {
		const div = document.createElement('div')
		if (url) {
			div.setAttribute('upload-url', url)
		}

		if (tableName) {
			div.setAttribute('table-name', tableName)
		}
		if (model) {
			div.setAttribute('model', model)
		}
		if (recordId) {
			div.setAttribute('record-id', recordId)
		}
		if (paramName) {
			div.setAttribute('param-name', paramName)
		}
		if (thumbnailSize !== null) {
			div.setAttribute('thumbnail-size', thumbnailSize)
		}

		div.setAttribute('chunk-size', chunkSize)
		div.setAttribute('auto', '')
		document.body.appendChild(div)

		return new DropzoneUpload(div)
	}

	init() {
		const availMimes = FileHelper.getAvailableMime()
		const availExt   = [...new Set(availMimes.map(item => item.ext))]
		const imgMimes   = availMimes.filter(item => item.type == 'image').map(item => item.mime)

		const scope = this
		this._dropzone = new Dropzone(this._element, {
			url: this._url,
			headers: {
				"X-CSRF-TOKEN": Helper.getCsrfToken()
			},
			method: "post",
			paramName: this._paramName,
			chunking: true,
			forceChunking: true,
			chunkSize: this._chunkSize,
			retryChunks: true,
			retryChunksLimit: 3,
			parallelUploads: 1,
			maxFilesize: this._maxFileSize,
            maxFiles: this._multiple ? null : 1,
			acceptedFiles: this._acceptFiles ?? availExt.join(","),
			autoProcessQueue: this._auto,
			accept: async function (file, done) {
				const quota = await FileHelper.canUpload(file.size)
				if (!quota.allowed) {
					done(`Storage quota exceeded. Available: ${quota.available_human}, file size: ${FileHelper.getHumanReadableSize(file.size)}`)
					return
				}

				if (imgMimes.includes(file.type)) {
					const reader = new FileReader()
					reader.onload = function (e) {
						const img = new Image()
						img.onload = function () {
							file.width  = img.width
							file.height = img.height

							done()
						}
						img.src = e.target.result
					}
					reader.readAsDataURL(file)
				} else {
					done()
				}
			},
			init: function () {
				const dzInstance = this

				const removeFile = (file) => {
					setTimeout(() => {
						file.previewElement.style.transition = "opacity 0.5s ease-out"
						file.previewElement.style.opacity   = "0"
						dzInstance.removeFile(file)
					}, 500)
				}

				let _debounceTimer = null
				let _pendingFiles  = 0

				dzInstance.on("addedfile", async function (file) {
					if (!scope._multiple && dzInstance.files.length > 1) {
						const previous = dzInstance.files[0]
						_pendingFiles  = Math.max(0, _pendingFiles - 1)
						dzInstance.removeFile(previous)
					}
					_pendingFiles++
					await scope.trigger("addedfile", file)
				})

				dzInstance.on("sending", async function (file, xhr, formData) {
					formData.append("param_name", scope._paramName)

					if (scope._tableName) {
						formData.append("table_name", scope._tableName)
					}
					if (scope._model) {
						formData.append("model", scope._model)
					}
					if (scope._recordId) {
						formData.append("record_id", scope._recordId)
					}

					if (imgMimes.includes(file.type)) {
						formData.append("thumbnail", scope._thumbnailSize ?? "false")
						if (file.width && file.height) {
							formData.append("image_height", file.height)
							formData.append("image_width", file.width)
						}
					}

					await scope.trigger("sending", file, xhr, formData)
				})

				dzInstance.on("success", async function (file, response) {
					removeFile(file)
					_pendingFiles--

					clearTimeout(_debounceTimer)
					_debounceTimer = setTimeout(async () => {
						if (_pendingFiles === 0) {
							await scope.trigger("queuecomplete")
						}
					}, 500)

					await scope.trigger("success", file, response)
				})

				dzInstance.on("error", async function (file, response, xhr) {
					_pendingFiles--
					const hasErrorListener = scope._events.has('error') && scope._events.get('error').length > 0
					if (!hasErrorListener) {
						Helper.errorAlert({ title: "Upload failed", message: response?.message ?? response })
					}
					removeFile(file)
					await scope.trigger("error", file, response, xhr)
				})

				dzInstance.on("removedfile", async function (file) {
					await scope.trigger("removedfile", file)
				})
			}
		})
	}

	_clampFileSize(value) {
		const parsed = parseInt(value)
		return isNaN(parsed) ? MAX_FILE_SIZE : Math.min(parsed, MAX_FILE_SIZE)
	}

	setMaxFileSize(value) {
		this._maxFileSize = this._clampFileSize(value)
		if (this._dropzone) {
			this._dropzone.options.maxFilesize = this._maxFileSize
		}
		return this
	}

	setMultiple(value) {
		this._multiple = value
		if (this._dropzone) {
			this._dropzone.options.maxFiles = value ? null : 1
			if (this._dropzone.hiddenFileInput) {
				if (value) {
					this._dropzone.hiddenFileInput.setAttribute("multiple", "multiple")
				} else {
					this._dropzone.hiddenFileInput.removeAttribute("multiple")
				}
			}
		}
		return this
	}

	setAcceptFiles(value) {
		this._acceptFiles = value
		if (this._dropzone) {
			const resolved = value ?? [...new Set(Helper.getAvailableMime().map(item => item.ext))].join(",")
			this._dropzone.options.acceptedFiles = resolved
			if (this._dropzone.hiddenFileInput) {
				this._dropzone.hiddenFileInput.setAttribute("accept", resolved)
			}
		}
		return this
	}

	setUrl(value) {
		this._url = value
		if (this._dropzone) {
			this._dropzone.options.url = value
		}
		return this
	}

	setAuto(value) {
		this._auto = value
		if (this._dropzone) {
			this._dropzone.options.autoProcessQueue = value
		}
		return this
	}

	setTableName(value) {
		this._tableName = value
		return this
	}

	setModel(value) {
		this._model = value
		return this
	}

	setRecordId(value) {
		this._recordId = value
		return this
	}

	/**
	 * @returns {boolean}
	 */
	hasPendingFiles() {
		return (this._dropzone?.getQueuedFiles().length ?? 0) > 0
	}

	/**
	 * Set upload config and process the queue. Resolves when all queued files finish (success or error).
	 * Uses native Dropzone events directly to avoid the debounced queuecomplete wrapper.
	 * @param {{ url?: string, recordId?: string, tableName?: string }} config
	 * @returns {Promise<boolean>} - `false` if any file errored, `true` if all succeeded.
	 */
	async upload({ url = null, recordId = null, tableName = null } = {}) {
		if (!this.hasPendingFiles()) {
			return true
		}

		if (url) {
			this.setUrl(url)
		}
		if (recordId) {
			this.setRecordId(recordId)
		}
		if (tableName) {
			this.setTableName(tableName)
		}

		return new Promise((resolve) => {
			let hasError = false

			const onError = () => { hasError = true }
			const onQueueComplete = () => {
				this._dropzone.off('error', onError)
				this._dropzone.off('queuecomplete', onQueueComplete)
				resolve(!hasError)
			}

			this._dropzone.on('error', onError)
			this._dropzone.on('queuecomplete', onQueueComplete)

			this.processQueue()
		})
	}

	/**
	 * @param {File} file
	 * @returns {DropzoneUpload}
	 */
	addFile(file) {
		if (this._dropzone) {
			this._dropzone.addFile(file)
			this._dropzone.processQueue()
		}
		return this
	}

	/**
	 * @returns {void}
	 */
	destroy() {
		if (this._dropzone) {
			this._dropzone.destroy()
			this._dropzone = null
		}
		if (this._element?.parentNode) {
			this._element.remove()
		}
	}

	getFiles() {
		if (!this._dropzone) {
			return []
		}
		return this._dropzone.getAcceptedFiles()
	}

	processQueue() {
		if (this._dropzone) {
			this._dropzone.processQueue()
		}
	}

	clear() {
		if (this._dropzone) {
			this._dropzone.removeAllFiles(true)
		}
	}
}
