export default class Toast {

	static #containers = {}

	static Position = Object.freeze({
		TopEnd:      'top-end',
		TopStart:    'top-start',
		BottomEnd:   'bottom-end',
		BottomStart: 'bottom-start',
		TopCenter:   'top-center',
		BottomCenter:'bottom-center',
	})

	static #CSS = {
		'top-end':      'top-0 end-0',
		'top-start':    'top-0 start-0',
		'bottom-end':   'bottom-0 end-0',
		'bottom-start': 'bottom-0 start-0',
		'top-center':   'top-0 start-50 translate-middle-x',
		'bottom-center':'bottom-0 start-50 translate-middle-x',
	}

	static #getContainer(position) {
		if (this.#containers[position]) return this.#containers[position]

		const posClass = this.#CSS[position] ?? this.#CSS['top-end']
		const el       = document.createElement('div')
		el.className   = `toast-container position-fixed ${posClass} p-3`
		el.style.zIndex = '1100'
		document.body.appendChild(el)

		this.#containers[position] = el
		return el
	}

	static show({ title = 'Notification', message = null, color = null, position = Toast.Position.TopEnd, timeout = 5000, onClick = null, html = null }) {
		const container = this.#getContainer(position)

		const id          = `toast-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`
		const bodyHtml    = html ?? (message ? `<div class="toast-body">${message}</div>` : '')
		const toastClass  = color ? `colored-toast bg-${color} text-fixed-white` : ''
		const headerClass = color ? `bg-${color} text-fixed-white` : 'text-default'
		const closeClass  = color ? 'btn-close btn-close-white' : 'btn-close'

		container.insertAdjacentHTML('beforeend', `
			<div id="${id}" class="toast ${toastClass}" role="alert" aria-live="assertive" aria-atomic="true">
				<div class="toast-header ${headerClass}">
					<strong class="me-auto">${title}</strong>
					<button type="button" class="${closeClass}" data-bs-dismiss="toast" aria-label="Close"></button>
				</div>
				${bodyHtml}
			</div>
		`)

		const toastEl = document.getElementById(id)

		if (onClick) {
			toastEl.style.cursor = 'pointer'
			toastEl.addEventListener('click', (e) => {
				if (!e.target.closest('.btn-close')) {
					onClick()
				}
			})
		}

		const autohide = Number.isInteger(timeout) && timeout > 0
		const toast    = new bootstrap.Toast(toastEl, { autohide, delay: timeout ?? 5000 })

		toastEl.addEventListener('hidden.bs.toast', () => toastEl.remove())
		toast.show()

		return { toast, element: toastEl }
	}
}
