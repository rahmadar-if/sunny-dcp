import Helper from "./helper"
import SolarComponent from "./solar/solar-component"

export default class Modal extends SolarComponent {
    constructor(selector) {
        super()

        if(selector instanceof Element) {
            this._element = selector
        } else if(Helper.isString(selector) && !Helper.isEmpty(selector)) {
            this._element = document.querySelector(selector)
            if(!this._element) {
                throw new Error(`Element with query selector ${selector} is not found`)
            }
        } else {
            throw new Error(`Selector is not supported`)
        }

        this._modal = new bootstrap.Modal(this._element)
    }

    static supportedEvent() {
        return ["hide", "hidden", "show", "shown"]
    }

    show() {
        this._modal.show()
    }

    hide() {
        this._modal.hide()
    }

    on(type, callback, name = null) {
        let oldHandler = null
        if (name && this._events.has(type)) {
            const existing = this._events.get(type).find(e => e.name === name)
            if (existing) oldHandler = existing.handler
        }

        super.on(type, callback, name)

        if (oldHandler) {
            this._element.removeEventListener(`${type}.bs.modal`, oldHandler)
        }

        const events = this._events.get(type)
        const event  = name ? events.find(e => e.name === name) : events[events.length - 1]

        this._element.addEventListener(`${type}.bs.modal`, event.handler)
        return this
    }

    off(type, callback = null, name = null) {
        if (!this._events.has(type)) {
            return this
        }

        const events = this._events.get(type)
        let toRemove

        if (name) {
            toRemove = events.filter(e => e.name === name)
        } else if (callback) {
            toRemove = events.filter(e => e.callback === callback)
        } else {
            toRemove = [...events]
        }

        toRemove.forEach(event => this._element.removeEventListener(`${type}.bs.modal`, event.handler))

        return super.off(type, callback, name)
    }

    /**
     * @returns {void}
     */
    destroy() {
        this._events?.forEach((handlers, type) => {
            handlers.forEach(e => this._element.removeEventListener(`${type}.bs.modal`, e.handler))
        })
        this._events  = new Map()
        this._modal?.dispose()
        this._modal   = null
        this._element = null
    }
}