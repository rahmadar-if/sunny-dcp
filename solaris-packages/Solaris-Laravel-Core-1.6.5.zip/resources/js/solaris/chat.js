import SolarComponent from "./solar/solar-component"
import Toast from "./toast"
import axios from "../libs/axios"
import Helper from "./helper"
import AudioChat from "./audio-chat"
import ChatSetup from "./chat-setup"
import PhotoSwipeLightbox from "photoswipe/lightbox"
import PhotoSwipe from "photoswipe"
import TextareaInput from "./form/textarea-input"
import Button from "./button"
import FileHelper from "./file-helper"

export default class Chat extends SolarComponent {

	// #region Static

	static supportedEvent() {
		return [
			"conversation:select",     // conversation activated
			"message:sent",            // message sent successfully
			"message:received",        // new message from WebSocket
			"message:status",          // delivery/read status updated via WebSocket
			"conversations:refreshed", // conversation list reloaded
		]
	}

	// #endregion

	// #region Lifecycle

	/**
	 * @param {HTMLElement} element
	 */
	constructor(element) {
		super()

		this._element = element

		this._area    = element.querySelector("[data-chat-area]")
		this._content = element.querySelector("[data-chat-content]")
		this._list    = element.querySelector("[data-messages-list]")
		this._input   = new TextareaInput(element.querySelector("[data-chat-input]"))
		this._sendBtn = new Button(element.querySelector("[data-chat-send]"))
		this._footer  = element.querySelector("[data-chat-footer]")
		this._toolbar = element.querySelector("[data-chat-toolbar]")

		this._headerAvatar = element.querySelector("[data-header-avatar]")
		this._headerName   = element.querySelector("[data-header-name]")
		this._headerStatus = element.querySelector("[data-header-status]")

		this._replyBar    = element.querySelector("[data-chat-reply-bar]")
		this._contextMenu = element.querySelector("[data-chat-context-menu]")
		this._replyTo             = null
		this._contextMenuScope    = null
		this._contextMenuTargetId = null

		// Moved to <body> so `position: fixed` is always viewport-relative — an ancestor
		// with a transform (menu/sidebar transitions elsewhere in the theme) would otherwise
		// silently turn it into a new containing block and throw off the cursor-anchored math.
		if (this._contextMenu) {
			document.body.appendChild(this._contextMenu)
		}

		this._device       		   = element.dataset.device ?? 'sunny'
		this._apiBase      		   = `${BASE_URL}/core/whatsapp`
		this._setup        		   = new ChatSetup(this._device, `${BASE_URL}/core/whatsapp/setup`)
		this._activeId     		   = null
		this._convPage     		   = 1
		this._hasMoreConv  		   = element.dataset.hasMoreConv !== 'false'
		this._loadingConv  		   = false
		this._loadingMsg   		   = false
		this._msgCache      	   = new Map()
		this._cacheOrder    	   = []
		this._maxCacheSize  	   = 10
		this._resizeObserver       = null
		this._lastErrorToastAt     = 0
		this._conversationOpenedAt = 0
		this._audio                = new AudioChat(this._list, this._content)

		this._init()
	}

	/**
	 * @returns {void}
	 */
	_init() {
		this._initChatControl()
		this._bindConversationClick()
		this._bindMobileClose()
		this._bindSearch()
		this._bindConvScroll()
		this._bindMsgScroll()
		this._initSSR()
		this._listenBroadcast()
		this._initPhotoSwipe()
		this._initProfilePictureSwipe()
		this._bindDownloadClick()
		this._bindRetryClick()
		this._bindVideoPlayClick()
		this._initScrollObserver()
		this._bindContextMenu()
		this._bindReplyBar()
		this._bindMediaErrorFallback()
		this._setup.init()
	}

	_initChatControl() {
		const inputElement = this._input._element

		this._input.on('input', () => {
			inputElement.style.height = 'auto'
			inputElement.style.height = `${inputElement.scrollHeight}px`
		})

		this._input.on("keydown", (val, e) => {
			if (e.key !== "Enter" || e.shiftKey) {
				return
			}

			e.preventDefault()
			this._handleSend()
		})

		this._sendBtn?.on("click", () => this._handleSend())
	}

	// #endregion

	// #region Public API

	/**
	 * Open the device setup modal.
	 * @returns {void}
	 */
	openSetup() {
		this._setup.open()
	}

	/**
	 * Reload conversation list from page 1.
	 * @returns {Promise<void>}
	 */
	async refreshConversations() {
		this._convPage = 1
		await this._fetchConversations(true)
		this.trigger("conversations:refreshed")
	}

	/**
	 * Load next page of conversations.
	 * @returns {Promise<void>}
	 */
	async nextPageConversations() {
		await this._fetchConversations(false)
	}

	/**
	 * Create or find conversation by phone, prepend to list, and open it.
	 * @param {string} phone
	 * @param {string|null} name
	 * @returns {Promise<void>}
	 */
	async addConversation(phone, name = null) {
		if (!this._apiBase) {
			return
		}

		try {
			const { data } = await axios.post(`${this._apiBase}/add-conversation`, { phone, name }, { headers: { 'X-Device-Id': this._device } })
			const conv     = data.conversation

			// Remove duplicate if already in DOM
			this._element.querySelector(`[data-conversation-id="${conv.id}"]`)?.remove()

			const html    = this._renderConversationItem(conv)
			const allList = this._element.querySelector('#chat-tab-all [data-chat-list]')
			allList?.insertAdjacentHTML('afterbegin', html)

			await this.openConversation(conv.id)
		} catch (error) {
			if (!error?.response) {
				console.error('Failed to add conversation', error)
			}
		}
	}

	/**
	 * Open conversation by ID. Fetches from backend if not in DOM.
	 * @param {string} id
	 * @returns {Promise<void>}
	 */
	async openConversation(id) {
		let li = this._element.querySelector(`[data-conversation-id="${id}"]`)

		if (!li) {
			li = await this._fetchAndInjectConversation(id)
		}

		if (!li) {
			return
		}

		if (this._activeId !== id) {
			this._activateConversationItem(li)
		}

		await this._loadMessagesForConversation(id)
	}

	/**
	 * Send text message to the active conversation.
	 * @param {string} text
	 * @returns {Promise<void>}
	 */
	async sendMessage(text) {
		if (!this._activeId || !this._apiBase || !text?.trim()) {
			return false
		}

		try {
			const { data } = await axios.post(`${this._apiBase}/send`, {
				text:            text.trim(),
				conversation_id: this._activeId,
				reply_to_id:     this._replyTo?.id ?? null,
			}, { headers: { 'X-Device-Id': this._device } })

			const msg       = data.message
			const lastDir   = this._getLastMessageDirection()
			const msgDir    = msg.direction === 'sent' ? 'outbound' : 'inbound'
			const continued = lastDir === msgDir
			const html      = this._renderMessage(msg, continued)

			this._list?.insertAdjacentHTML('beforeend', html)
			this._appendToCache(this._activeId, msg)
			this.scrollToBottom()
			this._clearReplyTo()

			this.trigger("message:sent", { id: msg.id, conversationId: this._activeId, text })

			return true
		} catch (error) {
			const message = error?.response?.data?.message
				?? error?.response?.statusText
				?? error?.message
				?? 'Failed to send message'

			console.error('[Chat] Send error:', message, error)

			Toast.show({
				title:   'WhatsApp',
				message: message,
				color:   'danger',
				timeout: 5000,
			})

			return false
		}
	}

	/**
	 * Filter conversations in DOM by query string.
	 * @param {string} query
	 * @returns {void}
	 */
	search(query) {
		this._filterConversations(query)
	}

	/**
	 * Switch sidebar tab.
	 * @param {'all'|'unread'} tab
	 * @returns {void}
	 */
	switchTab(tab) {
		const target = tab === 'unread' ? '#chat-tab-unread' : '#chat-tab-all'
		this._element.querySelector(`[data-bs-target="${target}"]`)?.click()
	}

	/**
	 * Reload messages for active conversation (bypasses cache).
	 * @returns {Promise<void>}
	 */
	async reloadMessages() {
		if (!this._activeId) {
			return
		}

		this._msgCache.delete(this._activeId)
		await this._loadMessagesForConversation(this._activeId)
	}

	/**
	 * Load older messages (next page) for active conversation.
	 * @returns {Promise<void>}
	 */
	async nextPageMessages() {
		if (!this._activeId) {
			return
		}

		const cached = this._msgCache.get(this._activeId)
		if (!cached?.hasMore || this._loadingMsg) {
			return
		}

		await this._fetchMessages(this._activeId, cached.page + 1, false)
	}

	/**
	 * Inject an incoming WebSocket message into cache and DOM.
	 * @param {string} conversationId
	 * @param {Object} message
	 * @returns {Promise<void>}
	 */
	/**
	 * Inject an incoming WebSocket message into cache and DOM.
	 * @param {string} conversationId
	 * @param {Object} message
	 * @returns {void}
	 */
	receiveMessage(conversationId, message) {
		this._appendToCache(conversationId, message)

		if (this._activeId === conversationId) {
			const lastDir   = this._getLastMessageDirection()
			const msgDir    = message.direction === 'sent' ? 'outbound' : 'inbound'
			const continued = lastDir === msgDir
			const html      = this._renderMessage(message, continued)

			this._list?.insertAdjacentHTML('beforeend', html)
			this.scrollToBottom()
			this._audio.initPlayers()
		}

		this.trigger("message:received", { conversationId, message })
	}

	/**
	 * Get active conversation ID.
	 * @returns {string|null}
	 */
	getActiveId() {
		return this._activeId
	}

	/**
	 * Scroll message content to bottom.
	 * @returns {void}
	 */
	scrollToBottom() {
		if (!this._content) {
			return
		}

		requestAnimationFrame(() => {
			this._content.scrollTop = this._content.scrollHeight
		})
	}

	/**
	 * Watch the chat content for layout changes (e.g. images finishing load)
	 * and auto-scroll to bottom if the user is already near the bottom.
	 * @returns {void}
	 */
	_initScrollObserver() {
		if (!this._content) {
			return
		}

		this._resizeObserver = new ResizeObserver(() => {
			const threshold = 48
			const isNearBottom = this._content.scrollHeight
				- this._content.scrollTop
				- this._content.clientHeight <= threshold

			if (isNearBottom) {
				this._content.scrollTop = this._content.scrollHeight
			}
		})

		this._resizeObserver.observe(this._content)
	}

	/**
	 * Wait for all eager images inside the given element to finish loading.
	 * Lazy images are skipped — they load on demand as user scrolls.
	 * @param {Element} element
	 * @returns {Promise<void>}
	 */
	async _waitForImages(element) {
		const imgs = element?.querySelectorAll('img:not([loading="lazy"])')
		if (!imgs?.length) {
			return
		}

		const promises = []
		for (const img of imgs) {
			if (img.complete) {
				continue
			}

			promises.push(new Promise(resolve => {
				img.addEventListener('load',  resolve, { once: true })
				img.addEventListener('error', resolve, { once: true })
			}))
		}

		if (promises.length) {
			await Promise.all(promises)
		}
	}

	// #endregion

	// #region Realtime

	/**
	 * @returns {void}
	 */
	_listenBroadcast() {
		Echo.channel(`whatsapp-${this._device}-messages`)
			.listen('.WaMessageReceived', (data) => this._handleIncoming(data))
			.listen('.WaMessageStatusUpdated', (data) => this._handleStatusUpdate(data))
			.listen('.WaMessageFailed', (data) => this._handleMessageFailed(data))
			.listen('.WaMessageMediaReady', (data) => this._handleMediaReady(data))
			.listen('.WaProfilePictureUpdated', (data) => this._handleProfilePictureUpdate(data))
	}

	/**
	 * @param {{ conversation_id: string, message: Object, conversation: Object }} data
	 * @returns {void}
	 */
	_handleIncoming(data) {
		this.receiveMessage(data.conversation_id, data.message)
		this._bumpConversationItem(data.conversation_id, data.conversation)

		// Auto mark as read if we're viewing this conversation
		if (this._activeId === data.conversation_id) {
			this._markAsRead(data.conversation_id)
		}
	}

	/**
	 * @param {{ message_id: string, conversation_id: string, status: string }} data
	 * @returns {void}
	 */
	_handleStatusUpdate(data) {
		const li = this._list?.querySelector(`[data-message-id="${data.message_id}"]`)

		if (li && li.classList.contains('chat-item-end')) {
			const meta     = li.querySelector('.chat-bubble-meta')
			const icon     = meta?.querySelector('i')
			const newClass = this._getStatusIcon(data.status)

			if (icon) {
				if (newClass) {
					icon.className = `${newClass} fs-14`
				} else {
					icon.remove()
				}
			} else if (newClass && meta) {
				meta.insertAdjacentHTML('afterbegin', `<i class="${newClass} fs-14"></i>`)
			}
		}

		const cached = this._msgCache.get(data.conversation_id)
		if (cached) {
			const msg = cached.data.find(m => m.id === data.message_id)
			if (msg) {
				msg.status = data.status
			}
		}

		this.trigger("message:status", { messageId: data.message_id, conversationId: data.conversation_id, status: data.status })
	}

	/**
	 * @param {{ message_id: string, conversation_id: string, reason: string }} data
	 * @returns {void}
	 */
	_handleMessageFailed(data) {
		const li = this._list?.querySelector(`[data-message-id="${data.message_id}"]`)

		if (li && li.classList.contains('chat-item-end')) {
			const meta     = li.querySelector('.chat-bubble-meta')
			const icon     = meta?.querySelector('i')
			const newClass = this._getStatusIcon('failed')

			if (icon) {
				icon.className = `${newClass} fs-14`
				icon.title = data.reason ?? ''
			} else if (meta) {
				const newIcon = document.createElement('i')
				newIcon.className = `${newClass} fs-14`
				newIcon.title = data.reason ?? ''
				meta.insertAdjacentElement('afterbegin', newIcon)
			}
		}

		const cached = this._msgCache.get(data.conversation_id)
		if (cached) {
			const msg = cached.data.find(m => m.id === data.message_id)
			if (msg) {
				msg.status = 'failed'
				msg.failure_reason = data.reason
			}
		}

		this.trigger("message:failed", { messageId: data.message_id, conversationId: data.conversation_id, reason: data.reason })
	}

	/**
	 * Build the correct attachment URL for a given message type.
	 * Mirrors WhatsAppCoreController::mediaUrlFor().
	 * @param {string} type
	 * @param {string} attachmentId
	 * @returns {string}
	 */
	_buildMediaUrl(type, attachmentId) {
		if (type === 'video' || type === 'audio') {
			return `${BASE_URL}/core/attachment/preview-media/${attachmentId}`
		}

		if (type === 'document') {
			return `${BASE_URL}/core/attachment/download/${attachmentId}`
		}

		return `${BASE_URL}/core/images/${attachmentId}`
	}

	/**
	 * @param {{ message_id: string, conversation_id: string, type: string, attachment_id: string, image_width: number|null, image_height: number|null }} data
	 * @returns {void}
	 */
	_handleMediaReady(data) {
		const mediaUrl = this._buildMediaUrl(data.type, data.attachment_id)
		const li       = this._list?.querySelector(`[data-message-id="${data.message_id}"]`)

		if (li) {
			const img = li.querySelector('.chat-media-image')
			if (img) {
				if (data.type === 'image') {
					li.querySelector('.chat-media-spinner')?.remove()

					img.style.transition = 'opacity 0.25s ease, filter 0.25s ease'
					img.style.opacity    = '0'
					img.classList.remove('chat-media-blurred')

					const newSrc = `${BASE_URL}/core/images/thumbnail/${data.attachment_id}`

					const onLoad = () => {
						img.removeEventListener('load', onLoad)
						img.style.opacity = '1'

						const link = document.createElement('a')
						link.className = 'img-preview'
						link.href      = mediaUrl
						if (data.image_width)  link.dataset.pswpWidth  = String(data.image_width)
						if (data.image_height) link.dataset.pswpHeight = String(data.image_height)
						img.replaceWith(link)
						link.appendChild(img)
					}

					// Set src after fade-out frame is committed
					requestAnimationFrame(() => {
						img.addEventListener('load', onLoad)
						img.src = newSrc
					})
				} else if (data.type === 'video') {
					img.classList.remove('chat-media-blurred')
					li.querySelector('.chat-media-spinner')?.remove()

					const wrap = img.closest('.chat-media-wrap')
					if (wrap) {
						wrap.classList.add('chat-video-thumb-wrap')
						wrap.dataset.videoUrl = mediaUrl
						wrap.insertAdjacentHTML('beforeend', `<button type="button" class="chat-video-play-btn" aria-label="Play video"><i class="ri-play-circle-fill"></i></button>`)
					}
				}
			} else {
				const video = li.querySelector('video.chat-bubble-video')
				if (video) {
					video.src = mediaUrl
				} else {
					if (li.querySelector('[data-audio-el]')) {
						this._audio.handleMediaReady(li, mediaUrl)
					} else {
						const pending = li.querySelector('.chat-bubble-doc-pending')
						if (pending) {
							const filename = li.querySelector('.chat-bubble-doc-name')?.textContent ?? 'document'
							const btn      = document.createElement('button')
							btn.type        = 'button'
							btn.className   = 'chat-bubble-doc-dl'
							btn.title       = 'Download'
							btn.dataset.url      = `${BASE_URL}/core/attachment/download/${data.attachment_id}`
							btn.dataset.filename = filename
							btn.innerHTML   = '<i class="ri-download-2-line"></i>'
							pending.replaceWith(btn)
						}
					}
				}
			}
		}

		const cached = this._msgCache.get(data.conversation_id)
		if (cached) {
			const msg = cached.data.find(m => m.id === data.message_id)
			if (msg) {
				msg.media_url     = mediaUrl
				msg.attachment_id = data.attachment_id
				if (data.image_width)  msg.image_width  = data.image_width
				if (data.image_height) msg.image_height = data.image_height
			}
		}

		this.trigger('message:media_ready', { messageId: data.message_id, conversationId: data.conversation_id, mediaUrl, attachmentId: data.attachment_id })
	}

	/**
	 * @param {{ conversation_id: string, profile_picture_url: string }} data
	 * @returns {void}
	 */
	_handleProfilePictureUpdate(data) {
		this._element.querySelectorAll(`[data-conversation-id="${data.conversation_id}"]`).forEach(li => {
			li.dataset.profilePictureUrl = data.profile_picture_url

			const avatarSpan = li.querySelector('.avatar')
			if (!avatarSpan) {
				return
			}

			const existingImg = avatarSpan.querySelector('img')
			if (existingImg) {
				existingImg.src = data.profile_picture_url

				const existingLink = avatarSpan.querySelector('a.avatar-preview')
				if (existingLink) {
					existingLink.href = data.profile_picture_url
				}
			} else {
				const name = li.dataset.name ?? ''
				avatarSpan.className = 'avatar avatar-md avatar-rounded me-2 flex-shrink-0'
				avatarSpan.innerHTML = `<a class="avatar-preview" href="${Helper.esc(data.profile_picture_url)}">
					<img src="${Helper.esc(data.profile_picture_url)}" alt="${Helper.esc(name)}">
				</a>`
			}
		})

		if (this._activeId === data.conversation_id && this._headerAvatar) {
			const existingImg = this._headerAvatar.querySelector('img')
			if (existingImg) {
				existingImg.src = data.profile_picture_url

				const existingLink = this._headerAvatar.querySelector('a.avatar-preview')
				if (existingLink) {
					existingLink.href = data.profile_picture_url
				}
			} else {
				this._headerAvatar.innerHTML = `<a class="avatar-preview" href="${Helper.esc(data.profile_picture_url)}">
					<img src="${Helper.esc(data.profile_picture_url)}" alt="" style="width:100%;height:100%;object-fit:cover;">
				</a>`
			}
		}

		this.trigger('conversation:profile_picture', { conversationId: data.conversation_id, profilePictureUrl: data.profile_picture_url })
	}

	/**
	 * Update a conversation's sidebar preview/time in place — no reordering, since deleting a
	 * message can only make a conversation less recent, never more (unlike an incoming message).
	 * @param {string} id
	 * @param {Object} conv
	 * @returns {void}
	 */
	_updateConversationPreview(id, conv) {
		this._element.querySelectorAll(`[data-conversation-id="${id}"]`).forEach(li => {
			const previewEl = li.querySelector('.chat-msg')
			const timeEl    = li.querySelector('.fs-11')

			if (previewEl) {
				previewEl.innerHTML = this._getPreview(conv.latest_message)
			}

			if (timeEl) {
				timeEl.textContent = conv.last_message_at ? this._formatRelativeTime(conv.last_message_at) : ''
			}
		})
	}

	/**
	 * Update or prepend conversation item in sidebar and move it to the top.
	 * @param {string} id
	 * @param {Object} conv
	 * @returns {void}
	 */
	_bumpConversationItem(id, conv) {
		const allList    = this._element.querySelector('#chat-tab-all [data-chat-list]')
		const unreadList = this._element.querySelector('#chat-tab-unread [data-chat-list]')

		let li = this._element.querySelector(`[data-conversation-id="${id}"]`)

		if (!li) {
			allList?.querySelector('.px-3.py-5')?.remove()
			allList?.insertAdjacentHTML('afterbegin', this._renderConversationItem(conv))
			li = allList?.querySelector(`[data-conversation-id="${id}"]`) ?? null
		} else {
			const preview   = this._getPreview(conv.latest_message)
			const time      = conv.last_message_at ? this._formatRelativeTime(conv.last_message_at) : ''
			const unread    = this._activeId === id ? 0 : (conv.unread_count ?? 0)
			const previewEl = li.querySelector('.chat-msg')
			const timeEl    = li.querySelector('.fs-11')
			const badgeEl   = li.querySelector('.badge')

			if (previewEl) {
				previewEl.innerHTML = preview
			}

			if (timeEl) {
				timeEl.textContent = time
			}

			if (unread > 0) {
				if (badgeEl) {
					badgeEl.textContent = unread
				} else {
					li.querySelector('.fs-12')?.insertAdjacentHTML('beforeend',
						`<span class="badge bg-success rounded-pill flex-shrink-0">${unread}</span>`)
				}
			} else if (badgeEl) {
				badgeEl.remove()
			}

			if (conv.profile_picture_url) {
				li.dataset.profilePictureUrl = conv.profile_picture_url
			}

			allList?.prepend(li)
		}

		if (!li || !unreadList) {
			return
		}

		const isActive   = this._activeId === id
		const unreadCount = isActive ? 0 : (conv.unread_count ?? 0)
		const existingUnread = unreadList.querySelector(`[data-conversation-id="${id}"]`)

		if (unreadCount > 0) {
			const clone = li.cloneNode(true)
			if (existingUnread) {
				existingUnread.replaceWith(clone)
			} else {
				unreadList.querySelector('.px-3.py-5')?.remove()
				unreadList.prepend(clone)
			}
		} else if (existingUnread) {
			existingUnread.remove()

			if (unreadList.querySelectorAll('[data-conversation-id]').length === 0) {
				unreadList.innerHTML = this._renderEmptyUnread()
			}
		}
	}

	// #endregion

	// #region SSR + Conversation Activation

	/**
	 * Skip page-1 fetch if SSR already rendered conversations.
	 * Restore active conversation if SSR pre-selected one.
	 * @returns {void}
	 */
	_initSSR() {
		const allList = this._element.querySelector('#chat-tab-all [data-chat-list]')
		const hasSSR  = (allList?.querySelectorAll('[data-conversation-id]').length ?? 0) > 0

		if (hasSSR) {
			this._convPage = 2
		} else if (this._apiBase) {
			this._fetchConversations(true)
		}

		const active = this._element.querySelector('[data-active="true"]')
		if (!active) {
			return
		}

		active.classList.add("active")
		this._activeId = active.dataset.conversationId ?? null

		this._clearUnreadBadge(active)

		this._updateHeader({
			name:               active.dataset.name ?? "—",
			phone:              active.dataset.phone ?? null,
			initials:           active.dataset.initials ?? "?",
			color:              active.dataset.color ?? "primary",
			profilePictureUrl:  active.dataset.profilePictureUrl || null,
		})

		if (this._activeId) {
			this._loadMessagesForConversation(this._activeId)
		}
	}

	/**
	 * @param {HTMLElement} li
	 * @returns {void}
	 */
	_activateConversationItem(li) {
		this._element.querySelectorAll("[data-conversation-id]").forEach(item => {
			item.classList.remove("active")
		})

		li.classList.add("active")
		this._activeId = li.dataset.conversationId ?? null

		this._clearUnreadBadge(li)

		this._updateHeader({
			name:              li.dataset.name ?? "—",
			phone:             li.dataset.phone ?? null,
			initials:          li.dataset.initials ?? "?",
			color:             li.dataset.color ?? "primary",
			profilePictureUrl: li.dataset.profilePictureUrl || null,
		})

		this._element.classList.remove("chat-no-active")
		this._element.classList.add("responsive-chat-open")

		this.trigger("conversation:select", {
			id:    this._activeId,
			name:  li.dataset.name,
			phone: li.dataset.phone,
		})
	}

	/**
	 * @returns {void}
	 */
	_bindConversationClick() {
		this._element.addEventListener("click", (e) => {
			if (e.target.closest('a.avatar-preview')) {
				return
			}

			const link = e.target.closest("[data-conversation-select]")
			if (!link) {
				return
			}

			const li = link.closest("[data-conversation-id]")
			if (!li) {
				return
			}

			if (this._activeId === li.dataset.conversationId) {
				return
			}

			this._activateConversationItem(li)
			this._loadMessagesForConversation(li.dataset.conversationId)
		})
	}

	/**
	 * Fetch a single conversation from backend, inject into All tab list.
	 * @param {string} id
	 * @returns {Promise<HTMLElement|null>}
	 */
	async _fetchAndInjectConversation(id) {
		if (!this._apiBase) {
			return null
		}

		try {
			const { data } = await axios.get(`${this._apiBase}/conversations/${id}`, { headers: { 'X-Device-Id': this._device } })
			const html     = this._renderConversationItem(data.conversation ?? data)
			const allList  = this._element.querySelector('#chat-tab-all [data-chat-list]')
			allList?.insertAdjacentHTML('afterbegin', html)

			return allList?.querySelector(`[data-conversation-id="${id}"]`) ?? null
		} catch {
			return null
		}
	}

	// #endregion

	// #region Fetch Conversations

	/**
	 * @param {boolean} reset
	 * @returns {Promise<void>}
	 */
	async _fetchConversations(reset) {
		if (this._loadingConv || (!reset && !this._hasMoreConv) || !this._apiBase) {
			return
		}

		this._loadingConv = true

		try {
			const page     = reset ? 1 : this._convPage
			const { data } = await axios.get(`${this._apiBase}/conversations`, { params: { page }, headers: { 'X-Device-Id': this._device } })

			const conversations = data.data ?? []
			const allList       = this._element.querySelector('#chat-tab-all [data-chat-list]')
			const unreadList    = this._element.querySelector('#chat-tab-unread [data-chat-list]')

			const allHtml    = conversations.length
				? conversations.map(c => this._renderConversationItem(c)).join('')
				: this._renderEmptyConversations()

			const unreadHtml = (() => {
				const unread = conversations.filter(c => c.unread_count > 0)
				return unread.length ? unread.map(c => this._renderConversationItem(c)).join('') : null
			})()

			if (allList) {
				if (reset) {
					allList.innerHTML = allHtml
				} else {
					allList.insertAdjacentHTML('beforeend', conversations.map(c => this._renderConversationItem(c)).join(''))
				}
			}

			if (unreadList && reset) {
				unreadList.innerHTML = unreadHtml ?? this._renderEmptyUnread()
			} else if (unreadList && !reset && unreadHtml) {
				unreadList.insertAdjacentHTML('beforeend', unreadHtml)
			}

			this._hasMoreConv = data.has_more
			this._convPage    = reset ? 2 : this._convPage + 1
		} catch (error) {
			if (!error?.response) {
				console.error('Failed to load conversations', error)
			}
		} finally {
			this._loadingConv = false
		}
	}

	// #endregion

	// #region Fetch Messages

	/**
	 * @param {string} id
	 * @returns {Promise<void>}
	 */
	async _loadMessagesForConversation(id) {
		if (this._msgCache.has(id)) {
			this._renderCachedMessages(id)
			this._markAsRead(id)
			return
		}

		await this._fetchMessages(id, 1, true)
		this._markAsRead(id)
	}

	/**
	 * @param {string} id
	 * @param {number} page
	 * @param {boolean} reset
	 * @returns {Promise<void>}
	 */
	async _fetchMessages(id, page, reset) {
		if (this._loadingMsg || !this._apiBase) {
			return
		}

		this._loadingMsg = true

		const prevHeight = this._content?.scrollHeight ?? 0

		try {
			const { data } = await axios.get(`${this._apiBase}/messages/${id}`, { params: { page }, headers: { 'X-Device-Id': this._device } })
			const messages = data.data ?? []
			const html     = messages.map(m => this._renderMessage(m)).join('')

			if (reset) {
				if (this._list) {
					this._list.innerHTML = html
				}

				this._msgCache.set(id, { data: messages, page: 1, hasMore: data.has_more })
				this._evictCache(id)
				this._updateMessageGroups()
				this._conversationOpenedAt = Date.now()
				this.scrollToBottom()
				this._snapOnImagesLoad()
				this._audio.initPlayers()
			} else {
				this._list?.insertAdjacentHTML('afterbegin', html)
				this._deduplicateDateLabels()
				this._updateMessageGroups()

				if (this._content) {
					this._content.scrollTop = this._content.scrollHeight - prevHeight
				}

				const cached = this._msgCache.get(id)
				if (cached) {
					cached.data    = [...messages, ...cached.data]
					cached.page    = page
					cached.hasMore = data.has_more
				}
			}
		} catch (error) {
			if (!error?.response) {
				console.error('Failed to load messages', error)
			}
		} finally {
			this._loadingMsg = false
		}
	}

	/**
	 * Remove duplicate date-label elements, keeping the first (topmost) occurrence.
	 * @returns {void}
	 */
	_deduplicateDateLabels() {
		if (!this._list) {
			return
		}

		const seen = new Set()
		this._list.querySelectorAll('.chat-day-label').forEach(el => {
			const text = el.textContent.trim()
			if (seen.has(text)) {
				el.remove()
			} else {
				seen.add(text)
			}
		})
	}

	/**
	 * @param {string} id
	 * @returns {void}
	 */
	_renderCachedMessages(id) {
		const cached = this._msgCache.get(id)
		if (!cached || !this._list) {
			return
		}

		this._list.innerHTML = cached.data.map(m => this._renderMessage(m)).join('')
		this._updateMessageGroups()
		this._conversationOpenedAt = Date.now()
		this.scrollToBottom()
		this._snapOnImagesLoad()
		this._audio.initPlayers()
	}

	/**
	 * Attach load listeners to unloaded images so the view snaps to bottom
	 * when they finish loading. Guard: only snaps within 3s of conversation open
	 * so a user who has already scrolled up is not interrupted.
	 * @returns {void}
	 */
	_snapOnImagesLoad() {
		if (!this._list) {
			return
		}

		const openedAt = this._conversationOpenedAt

		for (const img of this._list.querySelectorAll('img')) {
			if (img.complete) {
				continue
			}

			img.addEventListener('load', () => {
				if (Date.now() - openedAt < 3000) {
					this.scrollToBottom()
				}
			}, { once: true })
		}
	}

	/**
	 * @param {string} id
	 * @param {Object} message
	 * @returns {void}
	 */
	_appendToCache(id, message) {
		const cached = this._msgCache.get(id)
		if (!cached) {
			return
		}

		cached.data.push(message)
	}

	/**
	 * LRU eviction: keep at most _maxCacheSize conversations in cache.
	 * @param {string} latestId
	 * @returns {void}
	 */
	_evictCache(latestId) {
		this._cacheOrder = this._cacheOrder.filter(id => id !== latestId)
		this._cacheOrder.push(latestId)

		while (this._cacheOrder.length > this._maxCacheSize) {
			this._msgCache.delete(this._cacheOrder.shift())
		}
	}

	// #endregion

	// #region Header

	/**
	 * @param {{ name: string, phone: string|null, initials: string, color: string, profilePictureUrl: string|null }} data
	 * @returns {void}
	 */
	_updateHeader(data) {
		if (this._headerAvatar) {
			if (data.profilePictureUrl) {
				this._headerAvatar.className = "avatar avatar-md avatar-rounded lh-1 flex-shrink-0"
				this._headerAvatar.innerHTML = `<a class="avatar-preview" href="${Helper.esc(data.profilePictureUrl)}">
					<img src="${Helper.esc(data.profilePictureUrl)}" alt="${Helper.esc(data.name)}" style="width:100%;height:100%;object-fit:cover;">
				</a>`
			} else {
				this._headerAvatar.textContent = data.initials
				this._headerAvatar.className   = [
					"avatar avatar-md avatar-rounded lh-1 fw-semibold flex-shrink-0",
					`bg-${data.color}-transparent`,
					`text-${data.color}`,
				].join(" ")
			}
		}

		if (this._headerName) {
			this._headerName.textContent = data.name
		}

		if (this._headerStatus) {
			this._headerStatus.textContent = data.phone ?? ""
		}
	}

	// #endregion

	// #region Messaging

	/**
	 * @returns {void}
	 */
	async _handleSend() {
		const text = this._input.get().trim()
		if (!text || !this._activeId) {
			return
		}

		const tempId        = `temp-${Date.now()}`
		const continued     = this._getLastMessageDirection() === 'outbound'
		const replyTo       = this._replyTo
		const optimisticMsg = {
			id:              tempId,
			direction:       'sent',
			type:            'text',
			body:            text,
			status:          'pending',
			wa_timestamp:    new Date().toISOString(),
			date_label:      null,
			caption:         null,
			media_thumbnail: null,
			media_url:       null,
			media_filename:  null,
			attachment_id:   null,
			image_width:     null,
			image_height:    null,
			reply_to:        replyTo ? {
				type:          replyTo.type,
				text:          replyTo.text,
				caption:       replyTo.caption,
				direction:     replyTo.direction,
				thumbnail_url: null,
			} : null,
		}

		this._list?.insertAdjacentHTML('beforeend', this._renderMessage(optimisticMsg, continued))
		this._appendToCache(this._activeId, optimisticMsg)
		this.scrollToBottom()

		this._input.reset(true)
		this._input._element.style.height = 'auto'
		this._input._element.focus()
		this._clearReplyTo()

		this._sendOptimistic(tempId, text, this._activeId, replyTo?.id ?? null)
	}

	/**
	 * @param {string} tempId
	 * @param {string} text
	 * @param {string} conversationId
	 * @param {string|null} [replyToId=null]
	 * @returns {Promise<void>}
	 */
	async _sendOptimistic(tempId, text, conversationId, replyToId = null) {
		if (!this._apiBase) {
			return
		}

		try {
			const { data } = await axios.post(`${this._apiBase}/send`, {
				text:            text,
				conversation_id: conversationId,
				reply_to_id:     replyToId,
			}, { headers: { 'X-Device-Id': this._device } })

			this._confirmBubble(tempId, data.message, conversationId)
		} catch (error) {
			this._failBubble(tempId, text, error)
		}
	}

	/**
	 * @param {string} tempId
	 * @param {Object} msg
	 * @param {string} conversationId
	 * @returns {void}
	 */
	_confirmBubble(tempId, msg, conversationId) {
		const li = this._list?.querySelector(`[data-message-id="${tempId}"]`)
		if (li) {
			li.dataset.messageId = msg.id
			li.classList.remove('chat-bubble-failed')
			this._setMessageStatus(li, msg.status ?? 'sent')
		}

		const cached = this._msgCache.get(conversationId)
		if (cached) {
			const idx = cached.data.findIndex(m => m.id === tempId)
			if (idx !== -1) {
				cached.data[idx] = msg
			}
		}

		this.trigger('message:sent', { id: msg.id, conversationId, text: msg.body })
	}

	/**
	 * @param {string} tempId
	 * @param {string} text
	 * @param {Error} error
	 * @returns {void}
	 */
	_failBubble(tempId, text, error) {
		const li = this._list?.querySelector(`[data-message-id="${tempId}"]`)
		if (li) {
			li.classList.add('chat-bubble-failed')
			li.dataset.retryText = text
			this._setMessageStatus(li, 'failed')
		}

		if (error?.response) {
			const message = error.response.data?.message ?? 'Failed to send message.'
			this._showSendErrorToast(message)
		}
	}

	/**
	 * @param {HTMLElement} li
	 * @param {string} status
	 * @returns {void}
	 */
	_setMessageStatus(li, status) {
		const meta     = li.querySelector('.chat-bubble-meta')
		const icon     = meta?.querySelector('i')
		const newClass = this._getStatusIcon(status)

		if (icon) {
			if (newClass) {
				icon.className = `${newClass} fs-14`
			} else {
				icon.remove()
			}
		} else if (newClass && meta) {
			meta.insertAdjacentHTML('afterbegin', `<i class="${newClass} fs-14"></i>`)
		}
	}

	/**
	 * Show error toast, debounced — max 1 toast per 3s to avoid spam on burst failures.
	 * @param {string} message
	 * @returns {void}
	 */
	_showSendErrorToast(message) {
		const now = Date.now()
		if (now - this._lastErrorToastAt < 3000) {
			return
		}

		this._lastErrorToastAt = now

		Toast.show({
			title:    'WhatsApp',
			message:  message,
			color:    'danger',
			position: Toast.Position.BottomEnd,
			timeout:  5000,
		})
	}

	/**
	 * Retry send on click of a failed bubble.
	 * @returns {void}
	 */
	_bindRetryClick() {
		this._list?.addEventListener('click', (e) => {
			if (e.target.closest('button, a')) {
				return
			}

			const li = e.target.closest('.chat-bubble-failed')
			if (!li) {
				return
			}

			const tempId = li.dataset.messageId
			const text   = li.dataset.retryText
			if (!tempId || !text || !this._activeId) {
				return
			}

			li.classList.remove('chat-bubble-failed')
			delete li.dataset.retryText
			this._setMessageStatus(li, 'pending')
			this._sendOptimistic(tempId, text, this._activeId)
		})
	}

	// #endregion

	// #region Context Menu

	/**
	 * @returns {void}
	 */
	_bindContextMenu() {
		this._element.addEventListener('contextmenu', (e) => {
			const bubble    = e.target.closest('.main-chat-msg')
			const messageLi = bubble?.closest('[data-message-id]')

			if (bubble && messageLi) {
				e.preventDefault()
				this._openContextMenu('message', messageLi.dataset.messageId, e.clientX, e.clientY)
				return
			}

			const convLi = e.target.closest('[data-conversation-id]')
			if (convLi) {
				e.preventDefault()
				this._openContextMenu('conversation', convLi.dataset.conversationId, e.clientX, e.clientY)
			}
		})

		this._contextMenu?.addEventListener('click', (e) => {
			const action = e.target.closest('[data-action]')?.dataset.action
			if (!action) {
				return
			}

			this._handleContextMenuAction(action)
			this._contextMenu.classList.remove('show')
		})

		document.addEventListener('click', () => {
			this._contextMenu?.classList.remove('show')
		})
	}

	/**
	 * Show the shared context menu anchored at the cursor, clamped so it never
	 * renders past the viewport edge — measured while hidden to avoid a flash.
	 * Only items matching `scope` (`data-scope` attribute) are shown.
	 * @param {'message'|'conversation'} scope
	 * @param {string} targetId
	 * @param {number} clientX
	 * @param {number} clientY
	 * @returns {void}
	 */
	_openContextMenu(scope, targetId, clientX, clientY) {
		if (!this._contextMenu) {
			return
		}

		this._contextMenuScope    = scope
		this._contextMenuTargetId = targetId

		this._contextMenu.querySelectorAll('[data-scope]').forEach(item => {
			item.classList.toggle('d-none', item.dataset.scope !== scope)
		})

		this._positionContextMenu(clientX, clientY)
	}

	/**
	 * @param {string} action
	 * @returns {Promise<void>}
	 */
	async _handleContextMenuAction(action) {
		if (action === 'reply') {
			this._startReply(this._contextMenuTargetId)
			return
		}

		if (action === 'delete-message') {
			await this._deleteMessage(this._contextMenuTargetId)
			return
		}

		if (action === 'delete-conversation') {
			await this._deleteConversation(this._contextMenuTargetId)
		}
	}

	/**
	 * Show the shared context menu anchored at the cursor, clamped so it never
	 * renders past the viewport edge — measured while hidden to avoid a flash.
	 * @param {number} clientX
	 * @param {number} clientY
	 * @returns {void}
	 */
	_positionContextMenu(clientX, clientY) {
		if (!this._contextMenu) {
			return
		}

		this._contextMenu.style.visibility = 'hidden'
		this._contextMenu.classList.add('show')

		const rect    = this._contextMenu.getBoundingClientRect()
		const maxLeft = window.innerWidth  - rect.width  - 8
		const maxTop  = window.innerHeight - rect.height - 8

		this._contextMenu.style.left = `${Math.max(8, Math.min(clientX, maxLeft))}px`
		this._contextMenu.style.top  = `${Math.max(8, Math.min(clientY, maxTop))}px`
		this._contextMenu.style.visibility = ''
	}

	/**
	 * @param {string|null} messageId
	 * @returns {Promise<void>}
	 */
	async _deleteMessage(messageId) {
		if (!messageId || !this._apiBase) {
			return
		}

		if (!await Helper.confirmDelete({ title: 'Delete this message?' })) {
			return
		}

		try {
			const { data } = await axios.delete(`${this._apiBase}/messages/${messageId}`, { headers: { 'X-Device-Id': this._device } })

			this._list?.querySelector(`[data-message-id="${messageId}"]`)?.remove()

			const cached = this._activeId ? this._msgCache.get(this._activeId) : null
			if (cached) {
				cached.data = cached.data.filter(m => m.id !== messageId)
			}

			this._updateMessageGroups()

			if (this._activeId && data.conversation) {
				this._updateConversationPreview(this._activeId, data.conversation)
			}
		} catch (error) {
			if (!error?.response) {
				console.error('Failed to delete message', error)
			}
		}
	}

	/**
	 * @param {string|null} conversationId
	 * @returns {Promise<void>}
	 */
	async _deleteConversation(conversationId) {
		if (!conversationId || !this._apiBase) {
			return
		}

		if (!await Helper.confirmDelete({ title: 'Delete this conversation?', message: 'All messages and attachments will be removed.' })) {
			return
		}

		try {
			await axios.delete(`${this._apiBase}/conversations/${conversationId}`, { headers: { 'X-Device-Id': this._device } })

			this._element.querySelectorAll(`[data-conversation-id="${conversationId}"]`).forEach(li => li.remove())
			this._msgCache.delete(conversationId)
			this._cacheOrder = this._cacheOrder.filter(id => id !== conversationId)

			const allList    = this._element.querySelector('#chat-tab-all [data-chat-list]')
			const unreadList = this._element.querySelector('#chat-tab-unread [data-chat-list]')

			if (allList && allList.querySelectorAll('[data-conversation-id]').length === 0) {
				allList.innerHTML = this._renderEmptyConversations()
			}

			if (unreadList && unreadList.querySelectorAll('[data-conversation-id]').length === 0) {
				unreadList.innerHTML = this._renderEmptyUnread()
			}

			if (this._activeId === conversationId) {
				this._activeId = null
				this._element.classList.add('chat-no-active')
				this._element.classList.remove('responsive-chat-open')
				this._updateHeader({ name: '—', phone: null, initials: '?', color: 'primary', profilePictureUrl: null })

				if (this._list) {
					this._list.innerHTML = ''
				}
			}
		} catch (error) {
			if (!error?.response) {
				console.error('Failed to delete conversation', error)
			}
		}
	}

	/**
	 * @param {string|null} messageId
	 * @returns {void}
	 */
	_startReply(messageId) {
		if (!messageId || !this._activeId) {
			return
		}

		const cached = this._msgCache.get(this._activeId)
		const msg    = cached?.data.find(m => m.id === messageId)
		if (!msg) {
			return
		}

		this._replyTo = {
			id:        msg.id,
			type:      msg.type,
			text:      msg.body,
			caption:   msg.caption,
			direction: msg.direction,
		}

		this._renderReplyBar()
		this._input._element.focus()
	}

	/**
	 * @returns {void}
	 */
	_renderReplyBar() {
		if (!this._replyBar || !this._replyTo) {
			return
		}

		const senderEl  = this._replyBar.querySelector('[data-reply-sender]')
		const snippetEl = this._replyBar.querySelector('[data-reply-snippet]')
		const snippet   = this._replyTo.caption || this._replyTo.text || this._capitalize(this._replyTo.type)

		if (senderEl) {
			senderEl.textContent = this._replyTo.direction === 'sent' ? 'You' : 'Contact'
		}

		if (snippetEl) {
			snippetEl.textContent = snippet.length > 80 ? `${snippet.slice(0, 80)}…` : snippet
		}

		this._replyBar.classList.remove('d-none')
	}

	/**
	 * @returns {void}
	 */
	_clearReplyTo() {
		this._replyTo = null
		this._replyBar?.classList.add('d-none')
	}

	/**
	 * @returns {void}
	 */
	_bindReplyBar() {
		this._replyBar?.querySelector('[data-chat-reply-cancel]')?.addEventListener('click', () => this._clearReplyTo())
	}

	/**
	 * Fall back a broken chat image (attachment file missing on disk) to its
	 * embedded blurred thumbnail instead of showing a broken image icon.
	 * `error` doesn't bubble, so this must listen in the capture phase.
	 * @returns {void}
	 */
	_bindMediaErrorFallback() {
		this._content?.addEventListener('error', (e) => {
			const img = e.target
			if (!(img instanceof HTMLImageElement) || !img.classList.contains('chat-media-image')) {
				return
			}

			const fallback = img.dataset.fallbackSrc
			if (!fallback || img.src === fallback) {
				return
			}

			delete img.dataset.fallbackSrc
			img.src = fallback
			img.classList.add('chat-media-blurred')
		}, true)
	}

	// #endregion

	// #region Read Receipts

	/**
	 * Mark conversation as read on the backend.
	 * Resets unread_count and updates received messages' status to 'read'.
	 * Fire-and-forget — non-critical.
	 * @param {string} id
	 * @returns {Promise<void>}
	 */
	async _markAsRead(id) {
		if (!this._apiBase) {
			return
		}

		try {
			await axios.post(`${this._apiBase}/read/${id}`, null, { headers: { 'X-Device-Id': this._device } })
		} catch {
			// silently fail
		}
	}

	/**
	 * Remove unread badge from sidebar item for the given conversation.
	 * Also removes the item from the Unread tab.
	 * @param {HTMLElement} li  The conversation <li> element
	 * @returns {void}
	 */
	_clearUnreadBadge(li) {
		if (!li) {
			return
		}

		// Remove badge from the conversation item
		li.querySelector('.badge')?.remove()

		// Remove from Unread tab
		const unreadList = this._element.querySelector('#chat-tab-unread [data-chat-list]')
		if (!unreadList) {
			return
		}

		const id      = li.dataset.conversationId
		const unreadItem = unreadList.querySelector(`[data-conversation-id="${id}"]`)
		if (!unreadItem) {
			return
		}

		unreadItem.remove()

		if (unreadList.querySelectorAll('[data-conversation-id]').length === 0) {
			unreadList.innerHTML = this._renderEmptyUnread()
		}
	}

	// #endregion

	// #region Search

	/**
	 * @returns {void}
	 */
	_bindSearch() {
		const input = this._element.querySelector("[data-chat-search]")
		if (!input) {
			return
		}

		input.addEventListener("input", () => this._filterConversations(input.value))
	}

	/**
	 * @param {string} query
	 * @returns {void}
	 */
	_filterConversations(query) {
		const q = query.toLowerCase().trim()

		this._element.querySelectorAll("[data-conversation-id]").forEach(li => {
			const name    = (li.dataset.name ?? "").toLowerCase()
			const phone   = (li.dataset.phone ?? "").toLowerCase()
			const visible = !q || name.includes(q) || phone.includes(q)

			li.style.display = visible ? "" : "none"
		})
	}

	// #endregion

	// #region Scroll Pagination

	/**
	 * @returns {void}
	 */
	_bindConvScroll() {
		const sidebar = this._element.querySelector('.chat-info')
		if (!sidebar) {
			return
		}

		sidebar.addEventListener('scroll', () => {
			if (!this._hasMoreConv || this._loadingConv) {
				return
			}

			const dist = sidebar.scrollHeight - sidebar.scrollTop - sidebar.clientHeight
			if (dist <= 150) {
				this._fetchConversations(false)
			}
		})
	}

	/**
	 * @returns {void}
	 */
	_bindMsgScroll() {
		if (!this._content) {
			return
		}

		this._content.addEventListener('scroll', () => {
			if (!this._activeId || this._loadingMsg) {
				return
			}

			const cached = this._msgCache.get(this._activeId)
			if (!cached?.hasMore) {
				return
			}

			if (this._content.scrollTop <= 150) {
				this._fetchMessages(this._activeId, cached.page + 1, false)
			}
		})
	}

	// #endregion

	// #region Mobile

	/**
	 * @returns {void}
	 */
	_bindMobileClose() {
		const btn = this._element.querySelector(".responsive-chat-close")
		if (!btn) {
			return
		}

		btn.addEventListener("click", () => {
			this._element.classList.remove("responsive-chat-open")
		})
	}

	// #endregion

	// #region Render — mirrors Blade components

	/**
	 * Mirror of chat/conversation-item.blade.php
	 * @param {Object} conv
	 * @returns {string}
	 */
	_renderConversationItem(conv) {
		const name     = conv.contact_name || conv.phone_number || 'Unknown'
		const initials = this._getInitials(name)
		const color    = this._getAvatarColor(initials)
		const preview  = this._getPreview(conv.latest_message)
		const time     = conv.last_message_at ? this._formatRelativeTime(conv.last_message_at) : ''
		const unread   = conv.unread_count ?? 0

		const avatarHtml = conv.profile_picture_url
			? `<span class="avatar avatar-md avatar-rounded me-2 flex-shrink-0">
					<a class="avatar-preview" href="${Helper.esc(conv.profile_picture_url)}">
						<img src="${Helper.esc(conv.profile_picture_url)}" alt="${Helper.esc(name)}">
					</a>
				</span>`
			: `<span class="avatar avatar-md avatar-rounded me-2 flex-shrink-0 fw-semibold bg-${Helper.esc(color)}-transparent text-${Helper.esc(color)}">
					${Helper.esc(initials)}
				</span>`

		return `<li
			data-conversation-id="${Helper.esc(conv.id)}"
			data-name="${Helper.esc(name)}"
			data-phone="${Helper.esc(conv.phone_number ?? '')}"
			data-initials="${Helper.esc(initials)}"
			data-color="${Helper.esc(color)}"
			data-profile-picture-url="${Helper.esc(conv.profile_picture_url ?? '')}"
			data-active="false">
			<div data-conversation-select style="cursor: pointer;">
				<div class="d-flex align-items-top">
					${avatarHtml}
					<div class="flex-fill min-w-0">
						<p class="mb-0 fw-semibold d-flex justify-content-between align-items-center gap-2">
							<span class="text-truncate">${Helper.esc(name)}</span>
							<span class="text-muted fw-normal fs-11 flex-shrink-0">${Helper.esc(time)}</span>
						</p>
						<p class="fs-12 mb-0 d-flex justify-content-between align-items-center gap-2">
							<span class="chat-msg text-muted text-truncate">${preview}</span>
							${unread > 0 ? `<span class="badge bg-success rounded-pill flex-shrink-0">${unread}</span>` : ''}
						</p>
					</div>
				</div>
			</div>
		</li>`
	}

	/**
	 * Mirror of chat/message.blade.php
	 * @param {Object} msg
	 * @param {boolean} [continued=false]
	 * @returns {string}
	 */
	_renderMessage(msg, continued = false) {
		const isOutbound = msg.direction === 'sent'
		const statusIcon = this._getStatusIcon(msg.status)
		const time       = msg.wa_timestamp ? this._formatTime(msg.wa_timestamp) : ''

		const dateLabel = msg.date_label
			? `<li class="chat-day-label"><span>${Helper.esc(msg.date_label)}</span></li>`
			: ''

		const quoteHtml = this._renderQuoteBlock(msg.reply_to)

		let content = ''

		if (msg.type === 'image' && (msg.media_thumbnail || msg.media_url)) {
			const isMediaReady = !!msg.attachment_id
			const captionHtml  = msg.caption ? `<p class="mb-0">${this._formatWaText(msg.caption)}</p>` : ''

			if (isMediaReady) {
				const imgWidth    = msg.image_width  ? ` data-pswp-width="${Helper.esc(String(msg.image_width))}"` : ''
				const imgHeight   = msg.image_height ? ` data-pswp-height="${Helper.esc(String(msg.image_height))}"` : ''
				const fallbackAttr = msg.media_thumbnail ? ` data-fallback-src="${Helper.esc(msg.media_thumbnail)}"` : ''
				content = `<div class="chat-media-wrap mb-1">
					<a class="img-preview" href="${Helper.esc(msg.media_url)}"${imgWidth}${imgHeight}>
						<img src="${BASE_URL}/core/images/thumbnail/${Helper.esc(msg.attachment_id)}" alt="image" class="chat-media-image" loading="lazy"${fallbackAttr}>
					</a>
				</div>${captionHtml}`
			} else {
				content = `<div class="chat-media-wrap mb-1">
					<img src="${Helper.esc(msg.media_thumbnail ?? msg.media_url)}" alt="image" class="chat-media-image chat-media-blurred" loading="lazy">
					<div class="chat-media-spinner"><i class="ri-loader-4-line"></i></div>
				</div>${captionHtml}`
			}
		} else if (msg.type === 'video') {
			const isVideoReady = !!msg.attachment_id
			const thumbSrc     = Helper.esc(msg.media_thumbnail ?? '')
			const thumbHtml    = thumbSrc
				? `<img src="${thumbSrc}" alt="video thumbnail" class="chat-media-image${isVideoReady ? '' : ' chat-media-blurred'}" loading="lazy">`
				: `<div class="chat-video-placeholder"><i class="ri-video-line"></i></div>`

			if (isVideoReady) {
				content = `<div class="chat-media-wrap mb-1 chat-video-thumb-wrap" data-video-url="${Helper.esc(msg.media_url)}">
					${thumbHtml}
					<button type="button" class="chat-video-play-btn" aria-label="Play video"><i class="ri-play-circle-fill"></i></button>
				</div>${msg.caption ? `<p class="mb-0">${this._formatWaText(msg.caption)}</p>` : ''}`
			} else {
				content = `<div class="chat-media-wrap mb-1">
					${thumbHtml}
					<div class="chat-media-spinner"><i class="ri-loader-4-line"></i></div>
				</div>${msg.caption ? `<p class="mb-0">${this._formatWaText(msg.caption)}</p>` : ''}`
			}
		} else if (msg.type === 'document' && (msg.media_filename || msg.media_url)) {
			const docFilename = msg.media_filename ?? 'Document'
			let docDl = ''

			if (msg.media_url) {
				docDl = `<button type="button" class="chat-bubble-doc-dl"
					data-url="${Helper.esc(msg.media_url)}"
					data-filename="${Helper.esc(docFilename)}"
					title="Download">
					<i class="ri-download-2-line"></i>
				</button>`
			} else if (msg.direction !== 'sent') {
				docDl = `<div class="chat-bubble-doc-pending" title="Processing">
					<i class="ri-loader-4-line"></i>
				</div>`
			}

			content = `<div class="chat-bubble-doc">
				<div class="chat-bubble-doc-icon"><i class="ri-file-text-line"></i></div>
				<span class="chat-bubble-doc-name">${Helper.esc(docFilename)}</span>
				${docDl}
			</div>${msg.caption ? `<p class="mb-0 mt-1">${this._formatWaText(msg.caption)}</p>` : ''}`
		} else if (msg.type === 'audio') {
			content = this._audio.renderHtml(msg)
		} else {
			content = `<p class="mb-0">${this._formatWaText(msg.body ?? '')}</p>`
		}

		const liClass = isOutbound ? 'chat-item-end' : 'chat-item-start'
		const continuedClass = continued ? ' continued' : ''

		return `${dateLabel}<li class="${liClass}${continuedClass}"${msg.id ? ` data-message-id="${Helper.esc(msg.id)}"` : ''}>
			<div class="chat-list-inner">
				<div class="main-chat-msg">
					<div>
						${quoteHtml}
						${content}
						<div class="chat-bubble-meta">
							${isOutbound && statusIcon ? `<i class="${statusIcon} fs-14"${msg.failure_reason ? ` title="${Helper.esc(msg.failure_reason)}"` : ''}></i>` : ''}
							<span class="msg-time">${Helper.esc(time)}</span>
						</div>
					</div>
				</div>
			</div>
		</li>`
	}

	/**
	 * Mirror of the quote block in chat/message.blade.php
	 * @param {Object|null} replyTo
	 * @returns {string}
	 */
	_renderQuoteBlock(replyTo) {
		if (!replyTo) {
			return ''
		}

		if (replyTo.unavailable) {
			return `<div class="chat-quote-block chat-quote-unavailable">
				<span class="chat-quote-snippet fst-italic">Original message unavailable</span>
			</div>`
		}

		const sender  = replyTo.direction === 'sent' ? 'You' : 'Contact'
		const snippet = Helper.esc(replyTo.caption || replyTo.text || this._capitalize(replyTo.type))
		const thumb   = replyTo.thumbnail_url
			? `<img src="${Helper.esc(replyTo.thumbnail_url)}" alt="" class="chat-quote-thumb">`
			: ''

		return `<div class="chat-quote-block">
			${thumb}
			<div class="chat-quote-text">
				<span class="chat-quote-sender">${Helper.esc(sender)}</span>
				<span class="chat-quote-snippet">${snippet}</span>
			</div>
		</div>`
	}

	/**
	 * @returns {string}
	 */
	_renderEmptyConversations() {
		return `<li class="px-3 py-5 text-center">
			<div class="d-flex flex-column align-items-center gap-3">
				<i class="ri-chat-smile-3-line fs-48 text-primary opacity-25"></i>
				<div>
					<p class="fw-semibold fs-14 mb-1">No conversations yet</p>
					<p class="text-muted fs-12 mb-0">Your conversations will appear here</p>
				</div>
			</div>
		</li>`
	}

	/**
	 * @returns {string}
	 */
	_renderEmptyUnread() {
		return `<li class="px-3 py-5 text-center">
			<div class="d-flex flex-column align-items-center gap-3">
				<i class="ri-checkbox-circle-line fs-48 text-success opacity-25"></i>
				<div>
					<p class="fw-semibold fs-14 mb-1">All caught up!</p>
					<p class="text-muted fs-12 mb-0">No unread messages</p>
				</div>
			</div>
		</li>`
	}

	// #endregion

	// #region Render Helpers

	/**
	 * @param {string} str
	 * @returns {string}
	 */
	_capitalize(str) {
		return str.charAt(0).toUpperCase() + str.slice(1)
	}

	/**
	 * @param {string} name
	 * @returns {string}
	 */
	_getInitials(name) {
		return (name || '').trim().split(/\s+/).filter(Boolean).slice(0, 2)
			.map(w => w[0].toUpperCase()).join('')
	}

	/**
	 * @param {string} initials
	 * @returns {string}
	 */
	_getAvatarColor(initials) {
		const colors = ['primary', 'secondary', 'success', 'info', 'warning', 'danger']
		const char   = (initials[0] || 'a').toLowerCase()
		return colors[char.charCodeAt(0) % colors.length]
	}

	/**
	 * @param {Object|null} latestMessage
	 * @returns {string}
	 */
	_getPreview(latestMessage) {
		if (!latestMessage) {
			return ''
		}

		const txt = (str) => str ? Helper.esc(str) : ''
		const ico = (cls, label) => `<i class="${cls} me-1"></i>${label}`

		if (latestMessage.type === 'image') {
			return ico('ri-image-line', txt(latestMessage.caption || latestMessage.body) || 'Photo')
		}
		if (latestMessage.type === 'video') {
			return ico('ri-video-line', txt(latestMessage.caption || latestMessage.body) || 'Video')
		}
		if (latestMessage.type === 'audio') {
			return ico('ri-mic-line', 'Audio')
		}
		if (latestMessage.type === 'document') {
			return ico('ri-file-line', txt(latestMessage.caption || latestMessage.body || latestMessage.media_filename) || 'Document')
		}
		return txt(latestMessage.body)
	}

	/**
	 * @param {string|null} status
	 * @returns {string|null}
	 */
	_getStatusIcon(status) {
		if (status === 'pending' || status === 'queued') return 'ri-time-line'
		if (status === 'failed')    return 'ri-error-warning-line text-danger'
		if (status === 'read')      return 'ri-check-double-line text-info'
		if (status === 'delivered') return 'ri-check-double-line'
		if (status === 'sent')      return 'ri-check-line'
		return null
	}

	/**
	 * Format ISO timestamp to HH:MM.
	 * @param {string} isoString
	 * @returns {string}
	 */
	_formatTime(isoString) {
		try {
			return new Date(isoString).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
		} catch {
			return ''
		}
	}

	/**
	 * Format ISO timestamp to short relative string (e.g. "5m", "2h", "3d").
	 * @param {string} isoString
	 * @returns {string}
	 */
	_formatRelativeTime(isoString) {
		try {
			const diff = Date.now() - new Date(isoString).getTime()
			const m    = Math.floor(diff / 60000)
			const h    = Math.floor(diff / 3600000)
			const d    = Math.floor(diff / 86400000)

			if (m < 1) return 'now'
			if (m < 60) return `${m}m`
			if (h < 24) return `${h}h`
			if (d < 7) return `${d}d`

			return new Date(isoString).toLocaleDateString([], { day: '2-digit', month: 'short' })
		} catch {
			return ''
		}
	}

	/**
	 * Walk backwards through message list to find the last non-date message direction.
	 * @returns {string|null} 'outbound', 'inbound', or null
	 */
	_getLastMessageDirection() {
		if (!this._list) {
			return null
		}

		for (let i = this._list.children.length - 1; i >= 0; i--) {
			const li = this._list.children[i]
			if (li.classList.contains('chat-day-label')) {
				continue
			}
			if (li.classList.contains('chat-item-end')) {
				return 'outbound'
			}
			if (li.classList.contains('chat-item-start')) {
				return 'inbound'
			}
		}
		return null
	}

	/**
	 * Scan all messages in the list and apply/reconcile the `continued` class
	 * based on consecutive same-direction messages. Date labels reset continuity.
	 * @returns {void}
	 */
	_updateMessageGroups() {
		if (!this._list) {
			return
		}

		let prevDirection = null

		for (const li of this._list.children) {
			if (li.classList.contains('chat-day-label')) {
				prevDirection = null
				continue
			}

			const isEnd   = li.classList.contains('chat-item-end')
			const isStart = li.classList.contains('chat-item-start')
			if (!isEnd && !isStart) {
				continue
			}

			const direction = isEnd ? 'outbound' : 'inbound'

			if (direction === prevDirection) {
				li.classList.add('continued')
			} else {
				li.classList.remove('continued')
			}

			prevDirection = direction
		}
	}

	/**
	 * Convert WhatsApp-style markup to HTML.
	 * @param {string|null} text
	 * @returns {string}
	 */
	_formatWaText(text) {
		if (!text) {
			return ''
		}

		let html = Helper.esc(text)

		html = html.replace(/```([\s\S]*?)```/g, '<code class="wa-code-block">$1</code>')
		html = html.replace(/`([^`\n]+)`/g, '<code class="wa-code">$1</code>')
		html = html.replace(/\*([^\s*](?:[^*\n]*[^\s*])?)\*/g, '<strong>$1</strong>')
		html = html.replace(/_([^\s_](?:[^_\n]*[^\s_])?)_/g, '<em>$1</em>')
		html = html.replace(/~([^\s~](?:[^~\n]*[^\s~])?)~/g, '<s>$1</s>')
		html = html.replace(/\n/g, '<br>')

		return html
	}

	// #endregion

	// #region PhotoSwipe + Download

	/**
	 * Initialize PhotoSwipeLightbox for chat image previews.
	 * @returns {void}
	 */
	_initPhotoSwipe() {
		if (!this._list) {
			return
		}

		const lightbox = new PhotoSwipeLightbox({
			gallery:   this._list,
			children:  'a.img-preview',
			pswpModule: PhotoSwipe,
		})
		lightbox.init()
	}

	/**
	 * Handle profile picture click in conversation list — open PhotoSwipe programmatically.
	 * @returns {void}
	 */
	_initProfilePictureSwipe() {
		this._element.addEventListener('click', (e) => {
			const avatarLink = e.target.closest('a.avatar-preview')
			if (!avatarLink) {
				return
			}

			e.preventDefault()

			const lightbox = new PhotoSwipeLightbox({
				dataSource: [{
					src:    avatarLink.href,
					width:  parseInt(avatarLink.dataset.pswpWidth)  || 800,
					height: parseInt(avatarLink.dataset.pswpHeight) || 800,
				}],
				pswpModule: PhotoSwipe,
			})
			lightbox.init()
			lightbox.loadAndOpen(0)
		})
	}

	/**
	 * Open fullscreen video overlay on play button click.
	 * @returns {void}
	 */
	_bindVideoPlayClick() {
		this._list?.addEventListener('click', (e) => {
			const playBtn = e.target.closest('.chat-video-play-btn')
			if (!playBtn) {
				return
			}

			const wrap     = playBtn.closest('.chat-video-thumb-wrap')
			const videoUrl = wrap?.dataset.videoUrl
			if (!wrap || !videoUrl) {
				return
			}

			this._openVideoOverlay(videoUrl)
		})
	}

	/**
	 * Render a fullscreen overlay with the video player.
	 * Closes on backdrop click, close button, or Escape key.
	 * @param {string} videoUrl
	 * @returns {void}
	 */
	_openVideoOverlay(videoUrl) {
		const overlay = document.createElement('div')
		overlay.className = 'chat-video-overlay'
		overlay.innerHTML = `
			<button type="button" class="chat-video-overlay-close" aria-label="Close">
				<i class="ri-close-line"></i>
			</button>
			<video src="${Helper.esc(videoUrl)}" controls autoplay></video>
		`

		const close = () => {
			overlay.querySelector('video')?.pause()
			overlay.remove()
			document.removeEventListener('keydown', onKeydown)
		}

		const onKeydown = (e) => {
			if (e.key === 'Escape') {
				close()
			}
		}

		overlay.addEventListener('click', (e) => {
			if (e.target === overlay) {
				close()
			}
		})

		overlay.querySelector('.chat-video-overlay-close').addEventListener('click', close)
		document.addEventListener('keydown', onKeydown)
		document.body.appendChild(overlay)
	}

	/**
	 * Bind 2-second cooldown on document download links to prevent burst re-download.
	 * @returns {void}
	 */
	_bindDownloadClick() {
		if (!this._content) {
			return
		}

		this._content.addEventListener('click', async (e) => {
			const btn = e.target.closest('button.chat-bubble-doc-dl')
			if (!btn || btn.disabled) {
				return
			}

			const url  = btn.dataset.url
			const icon = btn.querySelector('i')

			btn.disabled = true
			if (icon) {
				icon.className = 'ri-loader-4-line'
			}

			try {
				await FileHelper.downloadFile(url, 'GET')
			} catch (error) {
				if (!error?.response) {
					console.error('Failed to download document', error)
				}
			} finally {
				setTimeout(() => {
					btn.disabled = false
					if (icon) {
						icon.className = 'ri-download-2-line'
					}
				}, 2000)
			}
		})
	}

	// #endregion
}
