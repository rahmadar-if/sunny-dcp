import Button from "./button";
import SearchInput from "./form/search-input";
import Modal from "./modal";
import SolarPage from "./solar/solar-page";

/**
 * Modal holding a searchable, infinitely scrolling list of cards.
 *
 * Knows nothing about where data comes from, what an item looks like, or what selecting one
 * means — all of that is supplied by the caller through hooks.
 */
export default class ListModal extends SolarPage {

    //#region Lifecycle

    /**
     * @param {string} id
     * @param {Object} [options]
     * @param {number} [options.length=10] Page size for each load.
     */
    constructor(id, options = {}) {
        super(false)

        this.id = id
        this._length = options.length ?? 10
        this._events = []

        this.init()
    }

    /**
     * @returns {string[]}
     */
    static supportedEvent() {
        return [
            "load",
            "guard",
            "render",
            "rendered",
            "opening",
            "opened",
            "closing",
            "closed",
        ]
    }

    init() {
        this.items = []
        this.start = 0
        this.total = 0
        this.keyword = ""
        this.loading = false
        this.locked = false

        /** @type {Modal} */
        this.modal = this.get(`${this.id}`)
        this.modal.on("hidden", this._onHidden.bind(this))

        this.modal._element
            .querySelector(`#${this.id}_close`)
            ?.addEventListener("click", () => this.requestClose())

        /** @type {SearchInput} */
        this._search = this.get(`${this.id}_search`)
        this._search.on("search", this.search.bind(this))

        /** @type {Button} */
        this._refreshBtn = this.get(`${this.id}_refresh`)
        this._refreshBtn.on("click", this.refresh.bind(this))

        this._listContainer = this.modal._element.querySelector("div.list-container")
        this._listContainer.addEventListener("scroll", this._onScroll.bind(this))

        this._emptyState = this.modal._element.querySelector("div.empty-state")
        this._footer = this.modal._element.querySelector("div.modal-footer")
    }

    //#endregion

    //#region Public API

    /**
     * @returns {Promise<void>}
     */
    async show() {
        this.helper.loadingPage(true)
        try {
            await this.trigger("opening")

            this._search.enabled()
            this._refreshBtn.enabled()

            await this._load()

            this.modal.show()

            await this.trigger("opened")
        } finally {
            this.helper.loadingPage(false)
        }
    }

    /**
     * @returns {void}
     */
    hide() {
        this.modal.hide()
    }

    /**
     * Asks the caller first: a `closing` handler returning `false` keeps the modal open.
     * Every close path goes through here, so there is no way around the check.
     * @returns {Promise<void>}
     */
    async requestClose() {
        const allowed = await this.trigger("closing")

        if (allowed === false) {
            return
        }

        this.modal.hide()
    }

    /**
     * Clears the list and pages back to the start without touching the search box — the caller
     * changed what is being listed, not what is being searched for.
     * @returns {Promise<void>}
     */
    async reload() {
        this.start = 0
        this.items = []

        // The old rows stay on screen until the new ones are ready — clearing first leaves an
        // empty box for the length of the request, which reads as a flicker.
        await this._load()
    }

    /**
     * @param {string} html
     * @returns {void}
     */
    setFooter(html) {
        if (!this._footer) {
            return
        }

        this._footer.innerHTML = html
    }

    /**
     * Blocks every input that could race with an in-flight write.
     * @param {boolean} locked
     * @returns {void}
     */
    lock(locked) {
        this.locked = locked

        if (locked) {
            this._search.disabled()
            this._refreshBtn.disabled()
            return
        }

        this._search.enabled()
        this._refreshBtn.enabled()
    }

    /**
     * @param {string} keyword
     * @returns {Promise<void>}
     */
    async search(keyword) {
        if (!await this._guard()) {
            return
        }

        this.keyword = keyword

        await this.reload()
    }

    /**
     * @returns {Promise<void>}
     */
    async refresh() {
        if (!await this._guard()) {
            return
        }

        this._refreshBtn.disabled()
        setTimeout(() => {
            if (!this.locked) {
                this._refreshBtn.enabled()
            }
        }, 2000)

        this.helper.loadingPage(true)
        try {
            await this.reload()
            this._listContainer.scrollTop = 0
        } finally {
            this.helper.loadingPage(false)
        }
    }

    //#endregion

    //#region Data

    /**
     * Asked before a user-initiated reload so the caller can finish pending work first. A
     * handler returning `false` aborts the action before the list is cleared.
     * @returns {Promise<boolean>}
     */
    async _guard() {
        return await this.trigger("guard") !== false
    }

    /**
     * @param {boolean} [append=false]
     * @returns {Promise<void>}
     */
    async _load(append = false) {
        if (this.loading) {
            return
        }

        this.loading = true

        try {
            const result = await this.trigger("load", {
                search: this.keyword,
                start: this.start,
                length: this._length,
            })

            const items = result?.items ?? []
            this.total = result?.total ?? 0

            this.items = append ? [...this.items, ...items] : items

            await this._render(items, append)
            this._updateUIState()
        } catch (error) {
            console.error(error)
            this.helper.errorAlert({ title: "Error", message: "Failed to load data" })
        } finally {
            this.loading = false
        }
    }

    /**
     * @returns {Promise<void>}
     */
    async _onScroll() {
        if (this.loading || this.locked || this.items.length >= this.total) {
            return
        }

        const { scrollTop, scrollHeight, clientHeight } = this._listContainer
        if (scrollTop + clientHeight < scrollHeight - 10) {
            return
        }

        this.start += this._length
        await this._load(true)
    }

    //#endregion

    //#region Rendering

    /**
     * @param {Array<Object>} items
     * @param {boolean} append
     * @returns {Promise<void>}
     */
    async _render(items, append) {
        const rendered = []

        for (const item of items) {
            const html = await this.trigger("render", item)
            if (!html) {
                continue
            }

            rendered.push({ html: html, item: item })
        }

        // Written in one pass rather than card by card: inserting inside the loop makes the
        // browser lay out and paint on every item, which is what shows up as flicker.
        const offset = append ? this._listContainer.children.length : 0
        const markup = rendered.map(entry => entry.html).join("")

        if (append) {
            this._listContainer.insertAdjacentHTML("beforeend", markup)
        } else {
            this._listContainer.innerHTML = markup
            this._listContainer.scrollTop = 0
        }

        for (let i = 0; i < rendered.length; i++) {
            const element = this._listContainer.children[offset + i]
            if (!element) {
                continue
            }

            await this.trigger("rendered", element, rendered[i].item)
        }
    }

    /**
     * @returns {void}
     */
    _updateUIState() {
        const empty = this.items.length === 0

        this._listContainer.classList.toggle("d-none", empty)
        this._emptyState.classList.toggle("d-none", !empty)
    }

    //#endregion

    //#region Modal Events

    /**
     * @returns {Promise<void>}
     */
    async _onHidden() {
        this._listContainer.scrollTop = 0
        this.items = []
        this.start = 0
        this.total = 0
        this.keyword = ""

        this._search.disabled()
        this._refreshBtn.disabled()
        this._search.reset(true)

        this._listContainer.innerHTML = ""

        await this.trigger("closed")
    }

    //#endregion

    //#region Events

    /**
     * @param {string} type
     * @param {Function} callback
     * @returns {ListModal}
     */
    on(type, callback) {
        if (!this.constructor.supportedEvent().includes(type)) {
            throw new Error(`Event ${type} does not support`)
        }

        if (!this.helper.isFunction(callback)) {
            throw new Error(`Callback must be function`)
        }

        this._events.push({ type: type, callback: callback })

        return this
    }

    /**
     * Returns the last handler's value so hooks can answer, not just observe.
     * @param {string} type
     * @param {...*} data
     * @returns {Promise<*>}
     */
    async trigger(type, ...data) {
        const events = this._events.filter(event => event.type == type)
        let result = null

        for (let i = 0; i < events.length; i++) {
            result = await events[i].callback(...data)
        }

        return result
    }

    //#endregion
}
