import axios from "@core-js/libs/axios"

export default class PushNotification {
    constructor() {
        this._serviceWorkerPath = "/sw.js"
        this._url = `${BASE_URL}/core/notification`
    }

    async isSupported() {
        return 'serviceWorker' in navigator && 'PushManager' in window
    }

    async isSubscribed() {
        return await this.getSubscription() ? true : false
    }

    async getPermission() {
        return Notification.permission
    }

    async getSubscription() {
        if (!await this.isSupported()) {
            return null
        }

        const registration = await this.register()
        if (!registration) {
            return null
        }

        return await registration.pushManager.getSubscription()
    }

    async checkSubscription() {
        const subscription = await this.getSubscription()
        if (subscription) {
            const serverSubscription = await axios({
                method: "POST",
                url: `${this._url}/check-subscribe`,
                data: {
                    endpoint: subscription.endpoint
                }
            }).then(res => res.data)
            if (serverSubscription.success) {
                await this.unsubscribe()
                await this.subscribe()
            }
        }
    }

    async register() {
        if (!await this.isSupported()) {
            return null
        }

        if (await this.getPermission() !== 'granted') {
            if (await Notification.requestPermission() !== 'granted') {
                console.warn("User is not give notification permission")
                return null
            }
        }

        let registration = await navigator.serviceWorker.getRegistration()
        if (!registration) {
            registration = await navigator.serviceWorker.register(this._serviceWorkerPath)
        }

        return registration
    }

    async subscribe() {
        const urlBase64ToUint8Array = (base64String) => {
            const padding = '='.repeat((4 - base64String.length % 4) % 4)
            const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/')
            const raw = atob(base64)
            return Uint8Array.from([...raw].map(char => char.charCodeAt(0)))
        }

        const vapidKey = await axios({
            method: "GET",
            url: `${this._url}/key`
        }).then(res => res.data)

        const registration = await this.register()
        if (!registration) {
            return false
        }

        const subscription = await registration.pushManager.subscribe({
            userVisibleOnly: true,
            applicationServerKey: urlBase64ToUint8Array(vapidKey)
        })

        const saveSub = await axios({
            method: "POST",
            url: `${this._url}/subscribe`,
            data: subscription
        }).then(res => res.data)

        return saveSub
    }

    async unsubscribe() {
        const subscription = await this.getSubscription()
        if (subscription) {
            const result = await subscription.unsubscribe()

            await axios({
                method: "POST",
                url: `${this._url}/unsubscribe`,
                data: {
                    endpoint: subscription.endpoint
                }
            }).then(res => res.data)

            return result
        }

        return false
    }
}