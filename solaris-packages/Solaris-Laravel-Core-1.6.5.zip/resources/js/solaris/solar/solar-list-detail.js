import SolarListPage from "./solar-list-page"

export default class SolarListDetail extends SolarListPage {

    /**
     * @param {string} id 
     * @param {string} parentColumn 
     * @param {*} parentValue 
     */
    constructor(id, parentColumn, parentValue) {
        super(id)

        this.parentColumn = parentColumn
        this.parentValue  = parentValue
        this._events      = []
    }

    static supportedEvent() {
        return [
            "ready", // when detail table is ready
            "saving", // when detail is trigger new/edit
            "saved", // when detail record is created/updated
            "deleting", // when record in detail is deleting
            "deleted", // when record in detail is deleted
        ]
    }

    _initPage() {
        super._initPage()

        if(this.hasModalForm()) {
            this.form
                .on("submitting", async () => await this.trigger("saving"), "SolarListDetail")
                .on("success", async (res) => this.trigger("saved", res), "SolarListDetail")

            this.modal
                .on("show", () => {
                    const parent = this.form.get(this.parentColumn)
                    if(parent) {
                        parent.set(this.parentValue, true)
                        parent.disabled()
                    } else {
                        this.form.addData(this.parentColumn, this.helper.isLookup(this.parentValue) ? this.parentValue.id : this.parentValue)
                    }
                }, "SolarListDetail")
        }

        if(!this.table._table) {
            this.table
                .on("ready", async (settings, json) => await this.trigger("ready", settings, json), "SolarListDetail")
                .on("deleting", async (row, data) => await this.trigger("deleting", row, data), "SolarListDetail")
                .on("deleted", async (data) => await this.trigger("deleted", data), "SolarListDetail")
        }
    }

    rowDoubleClick(row, data) {
        if(this.hasModalForm()) {
            this.modalForm.edit(data.id)
        }
    }

    on(type, callback) {
        if(!this.constructor.supportedEvent().includes(type)) {
            throw new Error(`Event ${type} does not support`)
        }

        if(!this.helper.isFunction(callback)) {
            throw new Error(`Callback must be function`)
        }

        this._events.push({
            type: type,
            callback: callback
        })

        return this
    }

    async trigger(type, ...data) {
        const events = this._events.filter(event => event.type == type)
        for (let i = 0; i < events.length; i++) {
            const event = events[i]
            await event.callback(...data)
        }
    }
}