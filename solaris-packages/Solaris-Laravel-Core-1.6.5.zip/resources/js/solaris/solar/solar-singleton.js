let _solarUI = null

export default class SolarSingleton {

    static set(instance) {
        _solarUI = instance
    }

    static getSolarUI() {
        return _solarUI
    }
}
