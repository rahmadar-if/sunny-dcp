import Button from "../button"
import BaseInput from "../form/base-input"
import FieldInput from "../form/field-input"
import Form from "../form/form"
import SolarListDetail from "./solar-list-detail"
import SolarPage from "./solar-page"

export default class SolarEditPage extends SolarPage {

    #isChanged = false
    displayValueName = "name"

    constructor() {
        super(false)

        this._initPage()
        this._handleUnsavedForm()

        this.init()

        this._initDiscard()
        this._initDetails()
        this.initDetail()
    }

    _initPage() {

        /** @type {Form} */
        this.form = this.get('_form')

        /** @type {Button} */
        this.saveButton = this.get("_save")

        /** @type {Button} */
        this.refreshButton = this.get("_refresh")

        this.id = this.form?.getId()
        this.breadcrumbName = document.querySelector("nav ol.breadcrumb li.breadcrumb-item.active")

        /** @type {Array<{name: string, propertyName: string, detailClass: typeof SolarListDetail, parentColumn: string, parentValue: {id: string, name: string}|null}>} */
        this.details = []

        this.saveButton?.on("click", async () => await this.save(), "SolarEditPage")
        this.refreshButton?.on("click", async () => {
            this.refreshButton.disabled()
            await this.refresh()

            setTimeout(() => this.refreshButton.enabled(), 2000)
        }, "SolarEditPage")

        if (this.form) {
            this.form
                .on("submitting", this.submitting.bind(this), "SolarEditPage")
                .on("validating", this.validating.bind(this), "SolarEditPage")
                .on("invalid", this.invalid.bind(this), "SolarEditPage")
                .on("validated", this.validated.bind(this), "SolarEditPage")
                .on("sending", this.sending.bind(this), "SolarEditPage")
                .on("failed", this.failed.bind(this), "SolarEditPage")
                .on("error", this.error.bind(this), "SolarEditPage")
                .on("success", async (res) => {
                    this.#isChanged = false
                    await this.success(res)   
                }, "SolarEditPage")
                .on("success", (res) => {
                    this.details.forEach(detail => {
                        if (!detail.parentValue) {
                            this[detail.propertyName].parentValue = {
                                id: this.id,
                                name: this.form.get(this.displayValueName)?.get()
                            }
                        }
                    })
                }, "SolarEditPage.UpdateDetail")
        }
    }

    /**
     * Track field changes to mark form as dirty.
     * Iterates all form fields and attaches a "change" listener
     * on fields that support it.
     */
    _initDiscard() {
        this.form?._fields.forEach((field, key) => {
            const isChangedExists = typeof field["isChanged"] === "function"
            const isOnExists = typeof field["on"] === "function"
            const isField = field instanceof FieldInput

            const supportedEventExists = isField ?
                'supportedEvent' in field._plugin.constructor :
                'supportedEvent' in field.constructor

            const supportedEvent = supportedEventExists ?
                (isField ? field._plugin.constructor.supportedEvent : field.constructor.supportedEvent) : null

            if (isChangedExists && isOnExists && supportedEventExists && supportedEvent && supportedEvent().includes("change")) {
                field.on("change", (val) => this.#isChanged = true, "SolarEditPage")
            }
        })
    }

    /**
     * Instantiate all registered details and bind the "saving" event handler.
     * Called automatically in constructor after `init()`.
     */
    _initDetails() {
        this.details.forEach(detail => {
            this[detail.propertyName] = new detail.detailClass(
                detail.name,
                detail.parentColumn,
                detail.parentValue ?? { id: this.id, name: this.form.get(this.displayValueName)?.get() }
            )
            this[detail.propertyName].on("saving", this._onSavingDetail.bind(this), "SolarEditPage")
        })
    }

    /**
     * Override to add custom initialization logic.
     * Called before `_initDiscard` and `_initDetails`.
     * Typically used to call `registerDetail()`.
     * @virtual
     */
    init() {

    }

    /**
     * Override to add custom detail-specific initialization logic.
     * Called after `_initDetails`, when all detail instances are ready.
     * @virtual
     */
    initDetail() {

    }

    //#region form event

    /**
     * Submit the form.
     * @param {boolean} [showAlert=true] - Whether to show an alert on success/failure.
     * @returns {Promise<boolean>} `true` if the form was saved successfully.
     */
    async save(showAlert = true) {
        const result = await this.form?.submit(showAlert)
        if (result) {
            this.#isChanged = false
        }

        return result
    }

    /**
     * Override to implement discard/reset behavior.
     * @virtual
     */
    discard() {

    }

    /**
     * Returns whether the form has unsaved changes.
     * @returns {boolean}
     */
    isChanged() {
        return this.#isChanged
    }

    /**
     * Called when the form begins the submission cycle.
     * Override to add pre-submit logic.
     * @virtual
     * @returns {Promise<void>}
     */
    async submitting() {

    }

    /**
     * Called when client-side validation is running.
     * Override to add custom validation logic.
     * @virtual
     * @param {Map<string, BaseInput>} fields - All form fields being validated.
     * @returns {Promise<void>}
     */
    async validating(fields) {

    }

    /**
     * Called when client-side validation fails.
     * Override to handle invalid state.
     * @virtual
     * @param {{result: boolean, errors: Array}} result - Validation result object.
     * @returns {Promise<void>}
     */
    async invalid(result) {

    }

    /**
     * Called when client-side validation passes.
     * Override to add post-validation logic.
     * @virtual
     * @returns {Promise<void>}
     */
    async validated() {

    }

    /**
     * Called when the form is sending data to the server.
     * Override to modify or inspect the request config.
     * @virtual
     * @param {any} config - Axios-like request config object.
     * @returns {Promise<void>}
     */
    async sending(config) {

    }

    /**
     * Called when the server returns a validation failure (e.g. HTTP 422).
     * Override to handle server-side errors.
     * @virtual
     * @param {Object} errors - Field-keyed error messages from server.
     * @param {string} message - General error message from server.
     * @returns {Promise<void>}
     */
    async failed(errors, message) {

    }

    /**
     * Called when the request encounters a non-validation error (e.g. HTTP 500).
     * Override to handle unexpected errors.
     * @virtual
     * @param {any} error - The raw error object.
     * @returns {Promise<void>}
     */
    async error(error) {

    }

    /**
     * Called when the form is submitted successfully.
     * Override to add post-save logic.
     * @virtual
     * @param {any} response - The server response data.
     * @returns {Promise<void>}
     */
    async success(response) {
        
    }

    //#endregion

    /**
     * Reload form data from server using the current record ID.
     * @returns {Promise<any>} The loaded form data.
     */
    async refreshForm() {
        return await this.form?.load(this.id, true)
    }

    /**
     * Refresh form data, trigger `onRefreshed` callback, reset dirty flag,
     * then refresh all registered details.
     * @param {boolean} detail
     * @returns {Promise<void>}
     */
    async refresh(detail = true) {
        const data = await this.refreshForm()
        await this.onRefreshed(data)

        this.#isChanged = false

        if(detail) {
            await this.refreshDetail()
        }
    }

    /**
     * Called after the form is refreshed.
     * Override to react to new form data.
     * @virtual
     * @param {any} data - The refreshed form data.
     * @returns {Promise<void>}
     */
    async onRefreshed(data) {

    }

    /**
     * Refresh one or all registered details.
     * @param {string|null} [name=null] - Detail name or property name to refresh. If `null`, refreshes all.
     * @returns {Promise<void>}
     */
    async refreshDetail(name = null) {
        if (this.details.length == 0) {
            return
        }

        if (!this.helper.isEmpty(name)) {
            const detail = this.details.find(d => d.name == name || d.propertyName == name)
            if (detail) {
                return await this[detail.propertyName].refresh()
            }
        }

        const details = this.details.map(detail => this[detail.propertyName].refresh())
        Promise.all(details)
    }

    /**
     * Internal handler triggered when a detail attempts to save.
     * Auto-saves the parent form first if it has unsaved changes.
     * @returns {Promise<void>}
     * @throws {null} Throws `null` to abort the detail save if parent form save fails.
     */
    async _onSavingDetail() {
        if (this.isChanged()) {
            if (!await this.save(false)) {
                throw null
            }
        }
    }

    /**
     * Register a detail section to be managed by this edit page.
     * If a detail with the same `name` is already registered, it will be replaced.
     *
     * @param {string} name - Unique identifier for this detail. Used to derive the property name.
     * @param {typeof SolarListDetail} detailClass - Class constructor for the detail (must extend `SolarListDetail`).
     * @param {string} parentColumn - The column name on the detail that references this page's record.
     * @param {{id: string, name: string}|null} [parentValue=null] - Optional explicit parent value. Defaults to current form ID and display value.
     * @returns {void}
     * @throws {Error} If `detailClass` is not a subclass of `SolarListDetail`.
     * @throws {Error} If the derived property name already exists on the instance.
     */
    registerDetail(name, detailClass, parentColumn, parentValue = null) {
        if (!(detailClass.prototype instanceof SolarListDetail)) {
            throw new Error("Detail must be instance of SolarListDetail")
        }

        const propertyName = this.helper.toCamelCase(name)
        if (Object.prototype.hasOwnProperty.call(this, propertyName)) {
            throw new Error(`Property '${propertyName}' already exists in instance.`)
        }

        const index = this.details.findIndex(detail => detail.name === name)
        if (index >= 0) {
            this.details[index] = { name, propertyName, detailClass, parentColumn, parentValue }
        } else {
            this.details.push({ name, propertyName, detailClass, parentColumn, parentValue })
        }
    }

    /**
     * Unregister one or more previously registered details by name.
     * Also removes the corresponding instance property if it exists.
     *
     * @param {string|string[]} names - Detail name or array of detail names to unregister.
     * @returns {void}
     */
    unregisterDetail(names) {
        const targets = Array.isArray(names) ? names : [names]

        targets.forEach(name => {
            const index = this.details.findIndex(detail => detail.name === name)
            if (index < 0) {
                return
            }

            const { propertyName } = this.details[index]
            this.details.splice(index, 1)

            if (Object.prototype.hasOwnProperty.call(this, propertyName)) {
                delete this[propertyName]
            }
        })
    }

    _handleUnsavedForm() {
        window.addEventListener("beforeunload", (e) => {
            if (this.isChanged()) {
                e.preventDefault()
                e.returnValue = ""

                this.helper.loadingPage(false)

                return ""
            }
        })

        document.addEventListener("click", async (e) => {
            const link = e.target.closest("a[href]")
            if (!link) {
                return
            }

            const href = link.getAttribute("href")
            if (href === "#" || href === "" || href.startsWith("javascript:")) {
                return
            }

            if (this.isChanged()) {
                e.preventDefault()

                if (await this.helper.confirm({ title: "You have unsaved changes", message: "Are you sure you want to leave this page?" })) {
                    this.#isChanged = false
                    window.location.href = link.href
                }
            }
        })
    }
}