import Helper from "../helper"

export default class SolarComponent {

    _events = new Map()

    static supportedEvent() {
        return []
    }

    /**
     * add event to component
     * @param {string} type
     * @param {Function} callback
     * @param {string|null} name unique name — if given and already exists, overwrites the existing handler
     * @returns {SolarComponent}
     */
    on(type, callback, name = null) {
        if(!this.constructor.supportedEvent().includes(type)) {
            throw new Error(`Event ${type} does not support`)
        }

        if(!Helper.isFunction(callback)) {
            throw new Error(`Callback must be function`)
        }

        const handler = (...args) => callback(...args)

        if(!this._events.has(type)) {
            this._events.set(type, [{handler, callback, name}])
            return this
        }

        const events = this._events.get(type)

        if(name) {
            const index = events.findIndex(event => event.name === name)
            if(index !== -1) {
                events[index] = {handler, callback, name}
                return this
            }
        }

        events.push({handler, callback, name})

        return this
    }

    /**
     * remove event from component
     * @param {string} type
     * @param {Function|null} callback ignored if name is given
     * @param {string|null} name if given, removes by name and ignores callback
     * @returns {SolarComponent}
     */
    off(type, callback = null, name = null) {
        if(!this._events.has(type)) {
            throw new Error(`Event ${type} does not exists`)
        }

        if(name) {
            this._events.set(
                type,
                this._events.get(type).filter(event => event.name !== name)
            )
            return this
        }

        if(!callback) {
            this._events.delete(type)
        } else {
            this._events.set(
                type,
                this._events.get(type)
                    .filter(event => event.callback !== callback)
            )
        }

        return this
    }

    /**
     * trigger event manually
     * @param {string} type event type 
     * @param {*} data 
     * @returns {Promise<[*]>}
     */
    async trigger(type, ...data) {
        if(!this._events.has(type)) {
            return
        }

        const result = []
        const events = this._events.get(type)

        for (let i = 0; i < events.length; i++) {
            const event = events[i]
            let res     = null
            
            res = await event.handler(...data)

            result.push(res)
        }

        return result
    }
}