import Helper from "../helper"
import Password from "../form/password-input"
import SearchInput from "../form/search-input"
import TagInput from "../form/tag-input"
import MaskInput from "../form/mask-input"
import SelectMultipleInput from "../form/select-multiple-input"
import RadioInput from "../form/radio-input"
import CardRadioInput from "../form/card-radio-input"
import CardCheckboxInput from "../form/card-checkbox-input"
import CardOptionGroupInput from "../form/card-option-group-input"
import DatePicker from "../form/date-picker"
import CheckboxInput from "../form/checkbox-input"
import TextInput from "../form/text-input"

export default class SolarFactory {

    /**
     * @param {HTMLElement} el 
     * @param {*} component 
     * @param {Function} guard callback for filtering element selector, must return boolean, true to continue, false to not process. callback have 1 param el: HTMLElement
     * @param {Function} factory callback for create custom component. callback have 2 param el: HTMLElement, component: Class Component
     * @returns {{id: string, component: *, bindTo: string}}
     */
    static initialize(el, component, guard = null, factory = null) {
        if (Helper.isFunction(guard) && !guard(el)) {
            return null
        }

        const id = el.hasAttribute("solar-id") ? el.getAttribute("solar-id") : el.id
        const ignore = el.hasAttribute("ignore")
        const bindTo = el.getAttribute("solar-bind")

        if (!id || ignore) {
            return null
        }

        const instance = Helper.isFunction(factory) ? factory(el, component) : new component(el)
        return { id, component: instance, bindTo }
    }

    /**
     * @param {HTMLElement} el 
     * @param {TextInput} component 
     * @returns {TextInput|MaskInput|Password|SearchInput|DatePicker|CheckboxInput|RadioInput}
     */
    static inputFactory(el, component) {
        const type = el.getAttribute('solar-ui')
        switch (type) {
            case "input:password":
                return new Password(el)

            case "input:search":
                return new SearchInput(el)

            case "input:tag":
                return new TagInput(el)

            case "input:date":
            case "input:datetime":
            case "input:time":
                const pickerMode = type.split(":")[1]
                return new DatePicker(el, pickerMode)

            case "input":
            default:
                if (el.getAttribute("mask")) {
                    return new MaskInput(el)
                }

                return new component(el)
        }
    }

    static textareaFactory(el, component) {
        const type = el.getAttribute('solar-ui')
        switch (type) {
            case "input:tag":
                return new TagInput(el)

            default:
                return new component(el)
        }
    }

    /**
     * @param {HTMLElement} el 
     * @param {SelectInput} component
     * @returns {SelectInput|SelectMultipleInput} 
     */
    static selectFactory(el, component) {
        const type = el.getAttribute('solar-ui')
        switch (type) {
            case "select:multiple":
                return new SelectMultipleInput(el)

            case "select":
            default:
                return new component(el)
        }
    }

    /**
     * @param {HTMLElement} el 
     * @param {CheckboxInput} component
     * @returns {CheckboxInput|RadioInput} 
     */
    static optionFactory(el, component) {
        const type = el.getAttribute('solar-ui')
        switch (type) {
            case "input:radio":
                return new RadioInput(el)

            case "input:checkbox":
            default:
                return new component(el)
        }
    }

    /**
     * @param {HTMLElement} el
     * @param {SelectInput} component
     * @returns {OptionGroupInput}
     */
    static optionGroupFactory(el, component) {
        const type = el.getAttribute('solar-ui')
        const groupType = type.split(":")[1].split("-")[0]

        return new component(el, groupType)
    }

    /**
     * @param {HTMLElement} el
     * @param {CardCheckboxInput} component
     * @returns {CardRadioInput|CardCheckboxInput}
     */
    static cardOptionFactory(el, component) {
        if (el.getAttribute('solar-ui') === 'input:radio-card') {
            return new CardRadioInput(el)
        }

        return new CardCheckboxInput(el)
    }

    /**
     * @param {HTMLElement} el
     * @param {CardOptionGroupInput} component
     * @returns {CardOptionGroupInput}
     */
    static cardOptionGroupFactory(el, component) {
        const type      = el.getAttribute('solar-ui')
        const groupType = type.includes('radio') ? 'radio' : 'checkbox'

        return new CardOptionGroupInput(el, groupType)
    }
}