import Form from "../form/form"
import Helper from "../helper"
import ModalForm from "../modal-form"
import SolarPage from "./solar-page"

export default class SolarModalPage extends SolarPage {
    
    /**
     * @param {ModalForm|string} modalForm 
     */
    constructor(modalForm = null) {
        super(false)

        if(modalForm && modalForm instanceof ModalForm) {
            this.modalForm = modalForm
        } else if(Helper.isString(modalForm)) {
            /** @type {ModalForm} */
            this.modalForm = this.get(`${modalForm}_ModalForm`)

            if(!this.modalForm) {
                this.modalForm = this.get(`${modalForm}`)
            }

            if(!this.modalForm) {
                throw new Error("Modal Form is not found")
            }
        } else {
            throw new Error("Modal Form is not found")
        }

        this._preInit()
        this.init()
    }

    _preInit() {
        this.modal = this.modalForm.modal
        this.form  = this.modalForm.form
    }

    /**
     * @param {Function} callback param form 
     */
    new() {
        this.modalForm.new(this.onNew.bind(this))
    }

    /**
     * @param {*} data 
     */
    async edit(data) {
        await this.modalForm.edit(data, this.onEdit.bind(this))
    }

    /**
     * @param {Form} form 
     */
    onNew(form) {

    }

    /**
     * @param {Form} form
     * @param {*} data
     */
    async onEdit(form, data) {

    }
}