import CheckboxInput from "../form/checkbox-input"
import CardCheckboxInput from "../form/card-checkbox-input"
import CardOptionGroupInput from "../form/card-option-group-input"
import FieldInput from "../form/field-input"
import TextInput from "../form/text-input"
import SelectInput from "../form/select-input"
import LookupInput from "../form/lookup-input"
import TextareaInput from "../form/textarea-input"
import OptionGroupInput from "../form/option-group-input"
import Form from "../form/form"
import Modal from "../modal"
import ModalForm from "../modal-form"
import Notes from "../notes/notes"
import DocumentEditor from "../document-editor"
import Button from "../button"
import Tab from "../tab"
import Table from "../table/table"
import TableLookup from "../table/table-lookup"
import DataGrid from "../table/datagrid"
import ProfileBanner from "../profile-banner"
import ProfilePicture from "../profile-picture"
import Attachment from "../attachment"
import StageButtons from "../stage/stage-button"
import Calendar from "../calendar"
import MetricDashboard from "../metric-dashboard"
import PeriodFilter from "../period-filter"
import InAppNotification from "../in-app-notification"
import Kanban from "../kanban"
import FunnelChart from "../funnel-chart"
import Approval from "../approval"
import PhonePreview from "../phone-preview"
import OtpInput from "../form/otp-input"
import DropzoneUpload from "../dropzone"
import Numeral from "../numeral"
import Chat from "../chat"
import SolarFactory from "./solar-factory"

export default class SolarUI {
    #ui = null
    #init = false

    constructor() {
        this.#ui = []
        this._registerDefaultComponents()
    }

    static components = []

    /**
     * @param {string} selector 
     * @param {*} component 
     * @param {Function} guard callback for filtering element selector, must return boolean, true to continue, false to not process. callback have 1 param el: HTMLElement
     * @param {Function} factory callback for create custom component. callback have 2 param el: HTMLElement, component: Class Component
     */
    static register(selector, component, guard = null, factory = null) {
        this.components.push({ selector, component, guard, factory })
    }

    init() {
        if (this.#init) {
            this.#ui.forEach(item => {
                item.component.destroy()
            })

            this.#ui = []
        }

        this.constructor.components.forEach(item => {
            document.querySelectorAll(item.selector).forEach(el => {
                const ui = SolarFactory.initialize(el, item.component, item.guard ?? null, item.factory ?? null)
                if (ui) {
                    this.#ui.push(ui)
                }
            })
        })

        this._initModalForm()

        this.#init = true
    }

    _registerDefaultComponents() {
        const notInFormGuard = (el) => !el.closest('form[solar-ui]')

        this.constructor.register('div[solar-ui="notification"]', InAppNotification)
        this.constructor.register('div[solar-ui="approval"]', Approval)
        this.constructor.register('button[solar-ui]', Button)
        this.constructor.register('form[solar-ui]', Form)
        this.constructor.register('div[solar-id][solar-ui="field"]', FieldInput, notInFormGuard)
        this.constructor.register('div[solar-ui="notes"]', Notes, notInFormGuard)
        this.constructor.register('div[solar-ui="document-editor"]', DocumentEditor, notInFormGuard)
        this.constructor.register('div[solar-ui="stages"]', StageButtons, notInFormGuard)
        this.constructor.register('div[solar-ui="profile-picture"]', ProfilePicture)
        this.constructor.register('div[solar-ui="profile-banner"]', ProfileBanner)
        this.constructor.register('div[solar-ui="period-filter"]', PeriodFilter)
        this.constructor.register('div[solar-ui="attachment"]', Attachment)
        this.constructor.register('div[solar-ui="calendar"]', Calendar)
        this.constructor.register('div[solar-ui="modal"]', Modal)
        this.constructor.register('div[solar-ui="tab"]', Tab)
        this.constructor.register('div[solar-ui="table-lookup"]', TableLookup)
        this.constructor.register('div[solar-ui="table:simple"] table.solar-table, div[solar-ui="table:card"] table.solar-table', Table)
        this.constructor.register('div[solar-ui="table:grid"]', DataGrid)
        this.constructor.register('div[solar-ui="metric"]', MetricDashboard)
        this.constructor.register('div[solar-ui="kanban"] div.TASK-kanban-board', Kanban)
        this.constructor.register('div[solar-ui="funnel-chart"]', FunnelChart)
        this.constructor.register('div[solar-ui="chat"]', Chat)
        this.constructor.register('div[solar-ui="phone-preview"]', PhonePreview)
        this.constructor.register('div[solar-ui="dropzone"]', DropzoneUpload)
        this.constructor.register('div[solar-ui="input:otp"]', OtpInput)
        this.constructor.register('span[solar-ui="numeral"]', Numeral)

        Approval.bindInline()
        this._initStandalone()
    }

    _initStandalone() {
        const standaloneGuard = (el) => !el.closest('div[solar-id][solar-ui="field"]') && !el.closest('form[solar-ui]')
        const standaloneOptionGuard = (el) => standaloneGuard(el) &&
            !el.closest('div[solar-ui="input:radio-group"]') &&
            !el.closest('div[solar-ui="input:checkbox-group"]')

        this.constructor.register('input[solar-ui]:not([solar-ui="input:checkbox"]):not([solar-ui="input:radio"]):not([solar-ui="input:radio-card"]):not([solar-ui="input:checkbox-card"])', TextInput, standaloneGuard, SolarFactory.inputFactory)
        this.constructor.register('input[solar-ui="input:checkbox"], input[solar-ui="input:radio"]', CheckboxInput, standaloneOptionGuard, SolarFactory.optionFactory)
        this.constructor.register('div[solar-ui="lookup"]', LookupInput, standaloneGuard)
        this.constructor.register('select[solar-ui]', SelectInput, standaloneGuard, SolarFactory.selectFactory)
        this.constructor.register('textarea[solar-ui]', TextareaInput, standaloneGuard, SolarFactory.textareaFactory)
        this.constructor.register(
            'div[solar-ui="input:radio-group"][solar-id], div[solar-ui="input:checkbox-group"][solar-id]',
            OptionGroupInput,
            standaloneGuard,
            SolarFactory.optionGroupFactory
        )
        this.constructor.register(
            'input[solar-ui="input:radio-card"], input[solar-ui="input:checkbox-card"]',
            CardCheckboxInput,
            (el) => standaloneGuard(el) &&
                !el.closest('div[solar-ui="input:radio-card-group"]') &&
                !el.closest('div[solar-ui="input:checkbox-card-group"]'),
            SolarFactory.cardOptionFactory
        )
        this.constructor.register(
            'div[solar-ui="input:radio-card-group"][solar-id], div[solar-ui="input:checkbox-card-group"][solar-id]',
            CardOptionGroupInput,
            standaloneGuard,
            SolarFactory.cardOptionGroupFactory
        )
    }

    _initModalForm() {
        this.#ui.forEach(item => {
            const key = item.id
            const component = item.component

            if (component instanceof Modal) {
                const form = component._element.querySelector(`form[solar-ui]`)
                const formUI = form ? this.get(form.id) : null
                if (form && formUI) {
                    this.#ui.push({ id: `${key}_ModalForm`, component: new ModalForm(component, formUI) })
                }
            }

            if (component instanceof Table || component instanceof DataGrid) {
                this._integrateModalFormToTable(component)
            } else if (component instanceof Kanban) {
                this._integrateModalFormToKanban(component)
            }
        })
    }

    /**
     * @param {Table|DataGrid} table 
     */
    _integrateModalFormToTable(table) {
        const newAction = table._wrapper.getAttribute("new-action")
        const modalForm = newAction ? this.get(`${newAction}_ModalForm`) : null

        if (newAction && modalForm) {
            table.on("new", () => modalForm.new(), "SolarUI")
            table.on("edit", (row, data) => modalForm.edit(data.id), "SolarUI")
            modalForm.form.on("success", () => table.refresh(), "SolarUI.Table")
        }
    }

    /**
     * @param {Kanban} kanban 
     */
    _integrateModalFormToKanban(kanban) {
        const newAction = kanban._wrapper.getAttribute("new-action")
        const modalForm = newAction ? this.get(`${newAction}_ModalForm`) : null

        if (newAction && modalForm) {
            kanban.on("new", (board) => {
                modalForm.new((form) => {
                    const boardColumn = form.get(kanban.getBoardColumn())
                    if (boardColumn) {
                        boardColumn.set(board)
                        boardColumn.disabled()
                    } else {
                        form.addData(kanban.getBoardColumn(), board.id)
                    }
                })
            }, "SolarUI")

            kanban.on("edit", async (data) => {
                await modalForm.edit(data.id, (form, editData) => {
                    const boardColumn = form.get(kanban.getBoardColumn())
                    if (boardColumn) {
                        boardColumn.disabled()
                    }
                })
            }, "SolarUI")

            modalForm.modal.on("hide", () => {
                const boardColumn = modalForm.form.get(kanban.getBoardColumn())
                if (boardColumn) {
                    boardColumn.enabled()
                } else {
                    modalForm.form.deleteData(kanban.getBoardColumn())
                }
            }, "SolarUI.Kanban")

            modalForm.form.on("success", (res) => {
                if (!modalForm.form.isEdit()) {
                    kanban.addCard(res.data[kanban.getBoardColumn()], res.data)
                } else {
                    kanban.editCard(res.data[kanban.getBoardColumn()], res.data)
                }
            }, "SolarUI.Kanban")
        }
    }

    /**
     * Get SolarUI Component
     * @param {string} id 
     * @returns {*}
     */
    get(id) {
        return this.#ui.find(item => item.id === id)?.component ?? null
    }

    /**
     * Set add new or override existing SolarUI Componet
     * @param {string} id 
     * @param {*} component 
     */
    set(id, component) {
        const index = this.#ui.findIndex(item => item.id === id)
        if (index == -1) {
            throw new Error("Id is not found")
        }

        this.#ui[index].component = component
    }
}