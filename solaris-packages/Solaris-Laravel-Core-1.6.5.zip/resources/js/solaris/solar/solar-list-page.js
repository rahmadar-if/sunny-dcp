import Form from "../form/form"
import Modal from "../modal"
import ModalForm from "../modal-form"
import Table from "../table/table"
import SolarPage from "./solar-page"

export default class SolarListPage extends SolarPage {

    /**
     * @param {string} id 
     * @param {boolean} autoRender 
     */
    constructor(id, autoRender = true) {
        super(false)

        this.id = id

        this._initPage()
        this.init()

        if (!this.table._table && autoRender) {
            this.table.render()
        }
    }

    _initPage() {
        /** @type {Table} */
        this.table = this.get(`${this.id}_list`)

        /** @type {ModalForm} */
        this.modalForm = null

        /** @type {Modal} */
        this.modal = null

        /** @type {Form} */
        this.form = null

        const newAction = this.table._wrapper.getAttribute("new-action")
        if (newAction) {
            this.modalForm = this.get(`${newAction}_ModalForm`)
            if (this.modalForm) {
                this.modal = this.modalForm.modal
                this.form = this.modalForm.form
            }
        }

        if (!this.table._table) {
            this.table
                .on("rendering", this.rendering.bind(this), "SolarListPage")
                .on("ready", this.ready.bind(this), "SolarListPage")
                .on("draw", this.draw.bind(this), "SolarListPage")
                .on("row created", this.rowCreated.bind(this), "SolarListPage")
                .on("column created", this.columnsCreated.bind(this), "SolarListPage")

            if (!this.helper.isFunctionEmpty(this.new)) {
                if (this.table._events.has("new")) {
                    this.table.off("new", null, "SolarUI")
                }

                this.table.on("new", this.new.bind(this), "SolarListPage")
            }

            if (!this.helper.isFunctionEmpty(this.edit)) {
                if (this.table._events.has("edit")) {
                    this.table.off("edit", null, "SolarUI")
                }

                this.table.on("edit", this.edit.bind(this), "SolarListPage")
            }

            if (!this.helper.isFunctionEmpty(this.delete)) {
                this.table.on("delete", this.delete.bind(this), "SolarListPage")
            }
        }

        this.table
            .on("row click", this.rowClick.bind(this), "SolarListPage")
            .on("row dblclick", this.rowDoubleClick.bind(this), "SolarListPage")
            .on("row contextmenu", this.rowContextMenu.bind(this), "SolarListPage")
            .on("deleting", this.deleting.bind(this), "SolarListPage")
            .on("deleted", this.deleted.bind(this), "SolarListPage")
            .on("view", this.view.bind(this), "SolarListPage")
            .on("column created:_action", (row, cell, cellData, rowData) => this.onActionCreated(row, cell, rowData), "`SolarListPage._action`")
    }

    /** @virtual */
    init() {

    }

    //#region table action

    /** @virtual */
    async new() {

    }

    /**
     * @virtual
     * @param {HTMLTableRowElement} row
     * @param {object} data
     */
    async edit(row, data) {

    }

    /**
     * @virtual
     * @param {HTMLTableRowElement} row
     * @param {object} data
     */
    async view(row, data) {

    }

    //#endregion

    //#region table event

    /** @virtual */
    async rendering() {

    }

    /**
     * @virtual
     * @param {object} settings
     * @param {object} json
     */
    async ready(settings, json) {

    }

    /**
     * @virtual
     * @param {Event} e
     * @param {object} settings
     */
    async draw(e, settings) {

    }

    /**
     * @virtual
     * @param {HTMLTableRowElement} row
     * @param {object} data
     * @param {number} dataIndex
     */
    rowCreated(row, data, dataIndex) {

    }

    /**
     * @virtual
     * @param {HTMLTableRowElement} row
     * @param {object} data
     */
    rowClick(row, data) {

    }

    /**
     * @virtual
     * @param {HTMLTableRowElement} row
     * @param {object} data
     */
    rowDoubleClick(row, data) {

    }

    /**
     * @virtual
     * @param {HTMLTableRowElement} row
     * @param {object} data
     */
    rowContextMenu(row, data) {

    }

    /**
     * @virtual
     * @param {string} columnName
     * @param {HTMLTableRowElement} row
     * @param {HTMLTableCellElement} cell
     * @param {any} cellData
     * @param {object} RowData
     */
    async columnsCreated(columnName, row, cell, cellData, RowData) {

    }

    /**
     * @virtual
     * @param {HTMLTableRowElement} row
     * @param {HTMLTableCellElement} cell
     * @param {object} rowData
     */
    onActionCreated(row, cell, rowData) {

    }

    /**
     * @virtual
     * @param {HTMLTableRowElement} row
     * @param {object} data
     */
    async deleting(row, data) {

    }

    /**
     * @virtual
     * @param {object} data
     */
    async delete(data) {

    }

    /**
     * @virtual
     * @param {object} data
     */
    async deleted(data) {

    }

    //#endregion

    /**
     * @param {string} name
     * @param {Function} renderCallback - callback (data: any, rowData: object)
     */
    columnRender(name, renderCallback) {
        if (this.table._table) {
            throw new Error("columnRender cannot define if table is rendered")
        }

        this.table.on(`column render:${name}`, renderCallback, `SolarListPage.${name}`)
    }

    /**
     * @param {string} name
     * @param {Function} createdCallback - callback (row: HTMLTableRowElement, cell: HTMLTableCellElement, cellData: any, rowData: object)
     */
    columnCreated(name, createdCallback) {
        if (this.table._table) {
            throw new Error("columnCreated cannot define if table is rendered")
        }

        this.table.on(`column created:${name}`, createdCallback, `SolarListPage.${name}`)
    }

    /**
     * @param {boolean} show
     */
    loading(show) {
        this.table.loading(show)
    }

    /**
     * @returns {Promise<void>}
     */
    async refresh() {
        await this.table.refresh()
    }

    /**
     * @returns {boolean}
     */
    hasModalForm() {
        return this.modal && this.form ? true : false
    }

    //#region action helpers

    /**
     * @param {HTMLTableRowElement} row
     * @returns {HTMLElement|null}
     */
    _getActionButton(row) {
        return row.querySelector('td div.button-action')
    }

    /**
     * @param {boolean} isDropdown
     * @param {string} selector
     * @param {string} label
     * @param {string} icon
     * @param {string|null} color
     * @param {Function|null} callback
     * @returns {HTMLElement}
     */
    _buildActionElement(isDropdown, selector, label, icon, color, callback) {
        if (isDropdown) {
            const li = document.createElement('li')
            const btn = document.createElement('a')
            btn.className = `dropdown-item ${selector}`
            btn.href = 'javascript:void(0);'
            btn.innerHTML = `<i class="${icon} ${color ? `text-${color}` : ''} me-1"></i>${label}`
            if (this.helper.isFunction(callback)) {
                btn.addEventListener('click', callback)
            }
            li.append(btn)
            return li
        }

        const btn = document.createElement('button')
        btn.setAttribute('title', label)
        btn.className = `btn btn-${color ?? 'primary'} btn-wave btn-icon btn-sm ${selector}`
        btn.innerHTML = `<i class="${icon}"></i>`
        if (this.helper.isFunction(callback)) {
            btn.addEventListener('click', callback)
        }
        return btn
    }

    /**
     * @returns {HTMLElement}
     */
    _buildDividerElement() {
        const li = document.createElement('li')
        li.innerHTML = '<hr class="dropdown-divider">'
        return li
    }

    /**
     * @param {HTMLElement} actionButton
     * @param {string} refSelector
     * @returns {HTMLElement|null}
     */
    _findRefElement(actionButton, refSelector) {
        if (actionButton.classList.contains('dropdown')) {
            return actionButton.querySelector(`ul.dropdown-menu .${refSelector}`)?.closest('li') ?? null
        }
        return actionButton.querySelector(`.${refSelector}`) ?? null
    }

    /**
     * @param {HTMLElement} actionButton
     * @returns {HTMLElement}
     */
    _getDropdownMenu(actionButton) {
        return actionButton.querySelector('ul.dropdown-menu')
    }

    /**
     * @param {HTMLTableRowElement} row
     * @param {{ selector: string, label: string, icon: string, color?: string|null, callback?: Function|null }} action
     */
    actionAppend(row, { selector, label, icon, color = null, callback = null }) {
        const actionButton = this._getActionButton(row)
        if (!actionButton) { 
            return 
        }
        const isDropdown = actionButton.classList.contains('dropdown')
        const el         = this._buildActionElement(isDropdown, selector, label, icon, color, callback)
        isDropdown ? this._getDropdownMenu(actionButton).append(el) : actionButton.append(el)
    }

    /**
     * @param {HTMLTableRowElement} row
     * @param {{ selector: string, label: string, icon: string, color?: string|null, callback?: Function|null }} action
     */
    actionPrepend(row, { selector, label, icon, color = null, callback = null }) {
        const actionButton = this._getActionButton(row)
        if (!actionButton) { 
            return 
        }
        const isDropdown = actionButton.classList.contains('dropdown')
        const el         = this._buildActionElement(isDropdown, selector, label, icon, color, callback)
        isDropdown ? this._getDropdownMenu(actionButton).prepend(el) : actionButton.prepend(el)
    }

    /**
     * @param {HTMLTableRowElement} row
     * @param {string} refSelector
     * @param {{ selector: string, label: string, icon: string, color?: string|null, callback?: Function|null }} action
     */
    actionAfter(row, refSelector, { selector, label, icon, color = null, callback = null }) {
        const actionButton = this._getActionButton(row)
        if (!actionButton) { 
            return 
        }
        const refEl = this._findRefElement(actionButton, refSelector)
        if (!refEl) { 
            return this.actionAppend(row, { selector, label, icon, color, callback }) 
        }
        const isDropdown = actionButton.classList.contains('dropdown')
        refEl.insertAdjacentElement('afterend', this._buildActionElement(isDropdown, selector, label, icon, color, callback))
    }

    /**
     * @param {HTMLTableRowElement} row
     * @param {string} refSelector
     * @param {{ selector: string, label: string, icon: string, color?: string|null, callback?: Function|null }} action
     */
    actionBefore(row, refSelector, { selector, label, icon, color = null, callback = null }) {
        const actionButton = this._getActionButton(row)
        if (!actionButton) { 
            return 
        }
        const refEl = this._findRefElement(actionButton, refSelector)
        if (!refEl) { 
            return this.actionPrepend(row, { selector, label, icon, color, callback }) 
        }

        const isDropdown = actionButton.classList.contains('dropdown')
        refEl.insertAdjacentElement('beforebegin', this._buildActionElement(isDropdown, selector, label, icon, color, callback))
    }

    /**
     * Append a divider. Dropdown group only.
     * @param {HTMLTableRowElement} row
     */
    actionDividerAppend(row) {
        const actionButton = this._getActionButton(row)
        if (!actionButton?.classList.contains('dropdown')) { 
            return 
        }
        this._getDropdownMenu(actionButton).append(this._buildDividerElement())
    }

    /**
     * Prepend a divider. Dropdown group only.
     * @param {HTMLTableRowElement} row
     */
    actionDividerPrepend(row) {
        const actionButton = this._getActionButton(row)
        if (!actionButton?.classList.contains('dropdown')) { 
            return 
        }
        this._getDropdownMenu(actionButton).prepend(this._buildDividerElement())
    }

    /**
     * Insert a divider after refSelector. Dropdown group only.
     * @param {HTMLTableRowElement} row
     * @param {string} refSelector
     */
    actionDividerAfter(row, refSelector) {
        const actionButton = this._getActionButton(row)
        if (!actionButton?.classList.contains('dropdown')) { 
            return 
        }
        const refEl = this._findRefElement(actionButton, refSelector)
        if (!refEl) { return this.actionDividerAppend(row) }
        refEl.insertAdjacentElement('afterend', this._buildDividerElement())
    }

    /**
     * Insert a divider before refSelector. Dropdown group only.
     * @param {HTMLTableRowElement} row
     * @param {string} refSelector
     */
    actionDividerBefore(row, refSelector) {
        const actionButton = this._getActionButton(row)
        if (!actionButton?.classList.contains('dropdown')) { 
            return 
        }
        const refEl = this._findRefElement(actionButton, refSelector)
        if (!refEl) { 
            return this.actionDividerPrepend(row) 
        }
        refEl.insertAdjacentElement('beforebegin', this._buildDividerElement())
    }

    /**
     * @param {HTMLTableRowElement} row
     * @param {string} selector
     */
    actionRemove(row, selector) {
        const actionButton = this._getActionButton(row)
        if (!actionButton) { 
            return 
        }
        const el = this._findRefElement(actionButton, selector)
        if (!el) { 
            return 
        }
        el.remove()
    }

    //#endregion
}