import SolarSingleton from "@core-js/solaris/solar/solar-singleton"
import axios from "@core-js/libs/axios"
import Helper from "../helper"
import SolarUI from "./solar-ui"

export default class SolarPage {

    constructor(autoInit = true) {
        /** @type {SolarUI} */
        this.solarUI = SolarSingleton.getSolarUI()
        this.axios = axios
        this.helper = Helper

        if (autoInit) {
            this.init()
        }
    }

    init() {

    }

    /**
     * @param {string} key 
     * @returns {*}
     */
    get(key) {
        return this.solarUI.get(key)
    }
}