import ProfilePicture from './profile-picture'

export default class ProfileBanner extends ProfilePicture {
	_modalSize = 'modal-xl'

	constructor(selector) {
		super(selector)
		this._thumbnail = null
	}

	_cropperOptions() {
		return {
			aspectRatio: 4,
			viewMode: 2,
			movable: true,
		}
	}
}
