import BaseAssign from "./base-assign";

export default class IntegrationAssign extends BaseAssign {

    /**
     * @returns {Array<{key: string, label: string, endpoint: string}>}
     */
    types() {
        return [
            { key: "role", label: "Role", endpoint: "admin/assignment/user/role-integration" },
            { key: "permission", label: "Permission", endpoint: "admin/assignment/user/permission-integration" },
        ]
    }
}
