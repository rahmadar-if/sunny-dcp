import BaseAssign from "./base-assign";

export default class AiAssign extends BaseAssign {

    /**
     * @returns {Array<{key: string, label: string, endpoint: string}>}
     */
    types() {
        return [
            { key: "role", label: "Role", endpoint: "admin/assignment/user/role-ai" },
            { key: "permission", label: "Permission", endpoint: "admin/assignment/user/permission-ai" },
        ]
    }
}
