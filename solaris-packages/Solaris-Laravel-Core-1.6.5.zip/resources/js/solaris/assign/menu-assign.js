import BaseAssign from "./base-assign";

export default class MenuAssign extends BaseAssign {

    /**
     * @returns {Array<{key: string, label: string, endpoint: string}>}
     */
    types() {
        return [
            { key: "user", label: "User", endpoint: "admin/assignment/menu/user" },
            { key: "role", label: "Role", endpoint: "admin/assignment/menu/role" },
            { key: "permission", label: "Permission", endpoint: "admin/assignment/menu/permission" },
        ]
    }
}
