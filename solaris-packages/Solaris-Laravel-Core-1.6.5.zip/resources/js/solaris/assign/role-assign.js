import BaseAssign from "./base-assign";

export default class RoleAssign extends BaseAssign {

    /**
     * @returns {Array<{key: string, label: string, endpoint: string}>}
     */
    types() {
        return [
            { key: "user", label: "User", endpoint: "admin/assignment/role/user" },
            { key: "permission", label: "Permission", endpoint: "admin/assignment/role/permission" },
        ]
    }
}
