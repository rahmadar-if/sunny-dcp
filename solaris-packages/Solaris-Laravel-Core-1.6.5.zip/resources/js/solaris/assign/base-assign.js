import CheckboxInput from "../form/checkbox-input";
import ListModal from "../list-modal";
import SolarPage from "../solar/solar-page";

const DEBOUNCE_DELAY = 1200

/**
 * Assign mechanics on top of {@link ListModal}: type switching, pending buffer, debounced batch
 * writes and the per-type counter.
 *
 * The debounce is deliberately longer than a typing debounce — it has to outlast the pause
 * between deliberate clicks so a run of toggles becomes one request.
 *
 * Subclasses only declare their types, and optionally override how a card is rendered.
 */
export default class BaseAssign extends SolarPage {

    //#region Lifecycle

    /**
     * @param {string} id Modal id declared in Blade.
     */
    constructor(id) {
        super(false)

        this.id = id
        this._events = []

        this.init()
    }

    /**
     * @returns {string[]}
     */
    static supportedEvent() {
        return [
            "changed",
            "closed",
        ]
    }

    /**
     * Must be implemented by the subclass.
     * @returns {Array<{key: string, label: string, endpoint: string}>}
     */
    types() {
        throw new Error("types() must be implemented")
    }

    init() {
        this._types = this.types()
        this._activeType = this._types[0].key
        this._ownerId = null

        this._resetState()

        this.listModal = new ListModal(this.id)
        this.listModal
            .on("load", this._onLoad.bind(this))
            .on("guard", this._onGuard.bind(this))
            .on("render", this.renderItem.bind(this))
            .on("rendered", this._onItemRendered.bind(this))
            .on("closing", this._onClosing.bind(this))
            .on("closed", this._onClosed.bind(this))

        this._initTypeRadios()
        this._initCancelButton()
    }

    //#endregion

    //#region Public API

    /**
     * @param {string} ownerId Record the selections belong to.
     * @returns {Promise<void>}
     */
    async show(ownerId) {
        this._ownerId = ownerId
        this._activeType = this._types[0].key
        this._resetState()
        this._syncTypeRadios()
        this._refreshFooter()

        // Fire-and-refresh: the active type's count arrives through the normal _onLoad flow
        // triggered by listModal.show() below, so this only needs the other tabs — otherwise
        // the footer only fills in a type's count once the user has actually clicked its tab.
        this._loadOtherCounts()

        await this.listModal.show()
    }

    /**
     * Flushes anything still buffered or in flight, then resolves. Every action that changes
     * context awaits this first, so a pending edit is never silently dropped.
     * @returns {Promise<void>}
     */
    async settle() {
        if (this._settlePromise) {
            return this._settlePromise
        }

        if (this._timer) {
            clearTimeout(this._timer)
            this._timer = null
        }

        if (Object.keys(this._pending).length === 0) {
            return
        }

        this._settlePromise = this._flush()

        try {
            await this._settlePromise
        } finally {
            this._settlePromise = null
        }
    }

    //#endregion

    //#region Type

    /**
     * @returns {{key: string, label: string, endpoint: string}}
     */
    activeType() {
        return this._types.find(type => type.key === this._activeType)
    }

    /**
     * @param {string} key
     * @returns {Promise<void>}
     */
    async switchType(key) {
        // A second click while the first switch is still settling would race: both would flush,
        // then both would assign _activeType, and the list could end up showing the other type.
        if (this._switching || key === this._activeType) {
            this._syncTypeRadios()
            return
        }

        this._switching = true

        try {
            await this.settle()
        } catch (e) {
            this._syncTypeRadios()
            return
        } finally {
            this._switching = false
        }

        this._activeType = key
        this._pending = {}
        this._serverState = {}

        await this.listModal.reload()
        this._refreshFooter()
    }

    /**
     * @returns {void}
     */
    _initTypeRadios() {
        if (this._types.length < 2) {
            return
        }

        this._radios = this.listModal.modal._element.querySelectorAll(`input[name="${this.id}_type"]`)
        this._radios.forEach(radio => {
            radio.addEventListener("change", async (e) => {
                if (!e.target.checked) {
                    return
                }

                await this.switchType(e.target.value)
            })
        })
    }

    /**
     * @returns {void}
     */
    _syncTypeRadios() {
        this._radios?.forEach(radio => radio.checked = radio.value === this._activeType)
    }

    //#endregion

    //#region Data

    /**
     * @param {{search: string, start: number, length: number}} params
     * @returns {Promise<{items: Array<Object>, total: number}>}
     */
    async _onLoad({ search, start, length }) {
        const req = await this.axios.get(`${BASE_URL}/${this.activeType().endpoint}/${this._ownerId}`, {
            params: { start, length, search },
        })

        const res = req.data

        if (res.recordsChecked !== undefined) {
            this._counts[this._activeType] = res.recordsChecked
            this._refreshFooter()
        }

        // Buffered toggles win over the server: the user already flipped these, they just have
        // not been written yet.
        const items = (res.data ?? []).map(item => {
            this._serverState[item.id] = item.checked ?? false

            return Object.hasOwn(this._pending, item.id)
                ? { ...item, checked: this._pending[item.id] }
                : item
        })

        return { items: items, total: res.recordsFiltered ?? 0 }
    }

    /**
     * Populates {@link _counts} for every type except the active one, so the footer summary is
     * complete as soon as the modal opens instead of filling in one tab at a time as each gets
     * clicked. `length: 0` keeps each request to just the count, no rows.
     * @returns {Promise<void>}
     */
    async _loadOtherCounts() {
        const ownerId = this._ownerId
        const pending = this._types.filter(type => type.key !== this._activeType)

        if (pending.length === 0) {
            return
        }

        const results = await Promise.all(pending.map(type =>
            this.axios.get(`${BASE_URL}/${type.endpoint}/${ownerId}`, { params: { start: 0, length: 0 } })
        ))

        // The owner may have been switched (or the modal closed) while these were in flight.
        if (ownerId !== this._ownerId) {
            return
        }

        pending.forEach((type, i) => {
            const recordsChecked = results[i].data.recordsChecked
            if (recordsChecked !== undefined) {
                this._counts[type.key] = recordsChecked
            }
        })

        this._refreshFooter()
    }

    //#endregion

    //#region Selection

    /**
     * @param {Object} item
     * @param {boolean} checked
     * @returns {void}
     */
    toggle(item, checked) {
        const serverChecked = this._serverState[item.id] ?? false

        // Store the difference against the server, not the click history — flipping back to the
        // original value leaves nothing to send.
        if (checked === serverChecked) {
            delete this._pending[item.id]
        } else {
            this._pending[item.id] = checked
        }

        this._refreshFooter()
        this._scheduleFlush()
    }

    /**
     * @returns {void}
     */
    _scheduleFlush() {
        if (this._timer) {
            clearTimeout(this._timer)
        }

        this._timer = setTimeout(() => {
            this._timer = null
            this.settle().catch(() => {})
        }, DEBOUNCE_DELAY)
    }

    /**
     * @returns {Promise<void>}
     */
    async _flush() {
        const pending = { ...this._pending }
        const ids = Object.keys(pending)

        const attach = ids.filter(id => pending[id] === true)
        const detach = ids.filter(id => pending[id] === false)

        this._setItemsDisabled(ids, true)
        this.listModal.lock(true)
        this.helper.loadingPage(true)

        try {
            const req = await this.axios.post(
                `${BASE_URL}/${this.activeType().endpoint}/${this._ownerId}`,
                { attach: attach, detach: detach }
            )

            if (!req.data.success) {
                throw new Error(req.data.message ?? "Failed to save data")
            }

            ids.forEach(id => this._serverState[id] = pending[id])
            ids.forEach(id => delete this._pending[id])

            this._counts[this._activeType] = (this._counts[this._activeType] ?? 0)
                + attach.length - detach.length

            this._changed = true
            this._refreshFooter()

            await this.trigger("changed")
        } catch (e) {
            // The buffer is deliberately kept: the user can retry, and the switches keep showing
            // what they asked for rather than snapping back to a state nobody chose.
            this.helper.toast({ message: e.response?.data?.message ?? e.message, color: "danger" })
            throw e
        } finally {
            this.helper.loadingPage(false)
            this.listModal.lock(false)
            this._setItemsDisabled(ids, false)
        }
    }

    /**
     * @param {string[]} ids
     * @param {boolean} disabled
     * @returns {void}
     */
    _setItemsDisabled(ids, disabled) {
        ids.forEach(id => {
            const checkbox = this.listModal.modal._element.querySelector(`input[type="checkbox"][id="${id}"]`)
            if (checkbox) {
                checkbox.disabled = disabled
            }
        })
    }

    //#endregion

    //#region Rendering

    /**
     * @param {Object} item
     * @returns {string}
     */
    renderItem(item) {
        const checked = item.checked ?? false

        return `<div class="card custom-card border mb-0">
            <div class="card-body">
                <div class="d-flex align-items-start justify-content-between">
                    <div class="flex-grow-1 me-3">
                        <span class="fw-medium fs-13">${item.name}</span>
                        ${item.group_name ? `<span class="badge bg-light text-muted ms-1">${item.group_name}</span>` : ""}
                        <p class="text-muted mb-0">${item.description ?? ""}</p>
                    </div>
                    <div class="form-check form-switch form-check-lg">
                        <input
                            role="switch"
                            class="form-check-input form-checked-primary"
                            type="checkbox"
                            id="${item.id}" ${checked ? "checked" : ""}>
                    </div>
                </div>
            </div>
        </div>`
    }

    /**
     * @param {HTMLElement} element
     * @param {Object} item
     * @returns {void}
     */
    _onItemRendered(element, item) {
        const input = element.querySelector(`.form-check.form-switch input[type="checkbox"]`)
        if (!input) {
            return
        }

        const checkbox = new CheckboxInput(input)
        checkbox.on("change", (checked) => this.toggle(item, checked))
    }

    /**
     * @returns {void}
     */
    _refreshFooter() {
        const summary = this._types
            .filter(type => this._counts[type.key] !== undefined)
            .map(type => `<span class="me-3"><span class="fw-bold text-dark">${this._pendingCount(type.key)}</span> ${type.label}</span>`)
            .join("")

        this.listModal.setFooter(`
            <div class="d-flex w-100 justify-content-between align-items-center">
                <div class="text-muted">${summary}</div>
                <button type="button" class="btn btn-light" id="${this.id}_cancel">Cancel</button>
            </div>
        `)

        this._bindCancelButton()
    }

    /**
     * Counter reflects what the user sees, so unwritten toggles are included.
     * @param {string} typeKey
     * @returns {number}
     */
    _pendingCount(typeKey) {
        const base = this._counts[typeKey] ?? 0

        if (typeKey !== this._activeType) {
            return base
        }

        return Object.values(this._pending).reduce((total, checked) => total + (checked ? 1 : -1), base)
    }

    //#endregion

    //#region Close

    /**
     * @returns {void}
     */
    _initCancelButton() {
        this._refreshFooter()
    }

    /**
     * @returns {void}
     */
    _bindCancelButton() {
        this.listModal.modal._element
            .querySelector(`#${this.id}_cancel`)
            ?.addEventListener("click", () => this.listModal.requestClose())
    }

    /**
     * Search and refresh both replace the list, so anything still buffered is written first.
     * @returns {Promise<boolean>}
     */
    async _onGuard() {
        try {
            await this.settle()
        } catch (e) {
            return false
        }

        return true
    }

    /**
     * @returns {Promise<boolean>}
     */
    async _onClosing() {
        try {
            await this.settle()
        } catch (e) {
            return false
        }

        return true
    }

    /**
     * @returns {Promise<void>}
     */
    async _onClosed() {
        const changed = this._changed

        this._resetState()

        if (changed) {
            await this.trigger("closed", true)
            return
        }

        await this.trigger("closed", false)
    }

    /**
     * @returns {void}
     */
    _resetState() {
        this._pending = {}
        this._serverState = {}
        this._counts = {}
        this._timer = null
        this._settlePromise = null
        this._switching = false
        this._changed = false
    }

    //#endregion

    //#region Events

    /**
     * @param {string} type
     * @param {Function} callback
     * @returns {BaseAssign}
     */
    on(type, callback) {
        if (!this.constructor.supportedEvent().includes(type)) {
            throw new Error(`Event ${type} does not support`)
        }

        if (!this.helper.isFunction(callback)) {
            throw new Error(`Callback must be function`)
        }

        this._events.push({ type: type, callback: callback })

        return this
    }

    /**
     * @param {string} type
     * @param {...*} data
     * @returns {Promise<void>}
     */
    async trigger(type, ...data) {
        const events = this._events.filter(event => event.type == type)

        for (let i = 0; i < events.length; i++) {
            await events[i].callback(...data)
        }
    }

    //#endregion
}
