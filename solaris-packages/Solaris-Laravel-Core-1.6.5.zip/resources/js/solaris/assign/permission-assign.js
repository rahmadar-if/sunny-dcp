import BaseAssign from "./base-assign";

export default class PermissionAssign extends BaseAssign {

    /**
     * Single type, so BaseAssign renders no type radios at all.
     * @returns {Array<{key: string, label: string, endpoint: string}>}
     */
    types() {
        return [
            { key: "user", label: "User", endpoint: "admin/assignment/permission/user" },
        ]
    }
}
