import Helper from "./helper"
import SolarComponent from "./solar/solar-component"

export default class Button extends SolarComponent {    
    constructor(selector) {
        super()

        if(selector instanceof Element) {
            this._element = selector
        } else if(Helper.isString(selector) && !Helper.isEmpty(selector)) {
            this._element = document.querySelector(selector)
            if(!this._element) {
                throw new Error(`Element with query selector ${selector} is not found`)
            }
        } else {
            throw new Error(`Selector is not supported`)
        }

        this._id       = this._element.id
        this._visible  = this._element.classList.contains("d-none") || this._element.getAttribute("hidden")
        this._disabled = this._element.disabled ?? false
        this._loading  = false
        this._savedChildren = []
    }

    static supportedEvent() {
        return ["click"]
    }

    on(type, callback, name = null) {
        let oldHandler = null
        if (name && this._events.has(type)) {
            const existing = this._events.get(type).find(e => e.name === name)
            if (existing) {
                oldHandler = existing.handler
            }
        }

        super.on(type, callback, name)

        if (oldHandler) {
            this._element.removeEventListener('click', oldHandler)
        }

        const events = this._events.get(type)
        const event  = name ? events.find(e => e.name === name) : events[events.length - 1]
        this._element.addEventListener('click', event.handler)

        return this
    }

    off(type, callback = null, name = null) {
        if (!this._events.has(type)) {
            return this
        }

        const events = this._events.get(type)
        let toRemove

        if (name) {
            toRemove = events.filter(e => e.name === name)
        } else if (callback) {
            toRemove = events.filter(e => e.callback === callback)
        } else {
            toRemove = [...events]
        }

        toRemove.forEach(event => this._element.removeEventListener('click', event.handler))

        return super.off(type, callback, name)
    }

    hidden() {
        this._element.classList.add("d-none")
        this._visible = false
    }

    show() {
        if(this._element.getAttribute("hidden")) {
            this._element.removeAttribute("hidden")
        }
        this._element.classList.remove("d-none")
        this._visible = true
    }

    disabled() {
        this._element.disabled = true
        this._disabled = true
    }

    enabled() {
        this._element.disabled = false
        this._disabled = false
    }

    /**
     * @returns {void}
     */
    load() {
        if (!this._loading) {
            this._savedChildren = Array.from(this._element.childNodes)
        }

        this._element.replaceChildren(this.#addLoader())
        this._element.classList.add("btn-loader")
        this._loading = true
        this.disabled()
    }

    /**
     * @returns {void}
     */
    unload() {
        if (!this._loading) {
            return
        }
        
        this._element.replaceChildren(...this._savedChildren)
        this._savedChildren = []
        this._element.classList.remove("btn-loader")
        this._loading = false
        this.enabled()
    }

    /**
     * @returns {HTMLElement}
     */
    #addLoader() {
        const span = document.createElement("span")
        span.className = "loading"

        const icon = document.createElement("i")
        icon.className = "ri-loader-4-line"

        span.append(icon)

        return span
    }

    destroy() {
        this._events.forEach((value, key) => this.off(key))

        this._events  = null
        this._element = null
    }
}