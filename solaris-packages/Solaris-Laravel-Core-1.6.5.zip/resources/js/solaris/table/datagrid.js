import axios from "@core-js/libs/axios"
import Helper from "@core-js/solaris/helper"
import Table from "./table"
import Button from "@core-js/solaris/button"
import TextInput from "@core-js/solaris/form/text-input"
import TextareaInput from "@core-js/solaris/form/textarea-input"
import MaskInput from "@core-js/solaris/form/mask-input"
import LookupInput from "@core-js/solaris/form/lookup-input"
import { AxiosError } from "axios"

export default class DataGrid extends Table {

    /**
     * @param {HTMLElement|string} selector 
     */
    constructor(selector) {
        super(selector)

        this._decimalSeparator = "."
        this._decimalScale = 2
        this._thousandSeparator = ","
    }

    static supportedEvent() {
        return [
            ...super.supportedEvent(),
            "saving", // when row save button clicked
            "saved", // when row save is success
            "save all", // when save all clicked
            "discarding", // when row discard button clicked
            "discarded", // when discarded is success
            "discard all", // when dicard all clicked
            "column change", // when editor editable on change
            "column config", // change or update config
        ]
    }

    /**
     * @param {{
     *  name: string, 
     *  data: string,
     *  render: Function,
     *  created: Function,
     *  className: string,
     *  searchable: boolean,
     *  orderable: boolean,
     *  width: string,
     *  editable: {
     *      editor: string,
     *      decimal: int,
     *      placeholder: string,
     *      source: string,
     *      isPagination: string,
     *      onChange: Function,
     *      config: *
     *  }
     * }} config 
     * @returns {DataGrid}
     */
    addColumn(config) {
        const { editable, ...baseConfig } = config

        super.addColumn(baseConfig)

        const column = this._columns[this._columns.length - 1]

        if (editable) {
            column.editable = editable
            column.render = (data, type, row, meta) => this._renderEditor(column.name, column.data, data, editable, meta)
            column.createdCell = (td, cellData, rowData, row, col) => {
                this._applyEditor(td, rowData, editable.editor, editable.onChange, editable.config)
            }
        }

        return this
    }

    /**
     * @param {*} data
     */
    addRow(data) {
        this._newBtn.disabled()

        const minIndex = Math.min(
            0,
            ...this._table
                .column("_index:name")
                .data()
                .toArray()
        )

        data._index = minIndex - 1
        data._state = "new"

        const rowNode = this._table.row.add(data).draw(false).node()
        this._table.order([{ name: '_index', dir: 'asc' }]).draw()

        rowNode.classList.add("new-row")
        rowNode.addEventListener("animationend", () => {
            rowNode.classList.remove("new-row")
            this._newBtn.enabled()
        })
    }

    /**
     * @param {HTMLTableRowElement} tr 
     * @param {string} fieldName 
     * @param {*} value 
     */
    updateCell(tr, fieldName, value) {
        const row = this._table.row(tr)
        const data = row.data()
        const columnIndex = this._table.column(`${fieldName}:name`).index()
        const cell = row.cell(row.index(), columnIndex)

        data[fieldName] = value
        cell.invalidate('data')
    }

    /**
     * @param {HTMLTableRowElement} tr 
     * @param {*} data 
     */
    async save(tr, data) {
        const row = this._table.row(tr)
        try {
            row.node().classList.add("row-saving")

            const isNew = data._state == 'new'

            const config = {
                method: isNew ? 'POST' : 'PUT',
                headers: { 'X-Model': this._model },
                url: `${BASE_URL}/core/form${!isNew ? `/${data.id}` : ''}`,
                data: data
            }

            await this.trigger("saving", row, data, config)

            const req = await axios(config)
            const res = req.data
            if (!res.success) {
                if (res.errors) {
                    this._handleError(res.message, res.errors, row, data)
                }

                if (!Helper.isEmpty(res.message)) {
                    Helper.toast({ message: res.message, color: 'danger' })
                }

                return
            }

            if (isNew) {
                this._pagination?.update(this._start, this._recordsTotal + 1, this._recordsFiltered + 1, this._currentPage, this._totalPage)
            }

            this._handleSave(res, row, data)

            if (this.getDirtyRows().length == 0) {
                this._saveAllBtn?.hidden()
                this._discardAllBtn?.hidden()
            }
        } catch (error) {
            console.error("Something wrong happen when save record...", { error })

            const eMessage = error instanceof AxiosError ? error.response?.data?.message : error
            Helper.errorAlert({ title: "Oops! There was an error", message: eMessage, timeout: null })
        } finally {
            row.node().classList.remove("row-saving")
        }
    }

    async saveAll() {
        try {
            this._saveAllBtn?.disabled()

            const saveRows = []
            this._table.rows().every(function () {
                const row = this
                const data = this.data()
                const tr = row.node()
                if (data._state !== 'clean') {
                    row.node().classList.add("row-saving")
                    saveRows.push({ tr, row, data, state: data._state })
                }
            })

            const results = await this.trigger("save all", saveRows)
            if (results) {
                saveRows.forEach((item, index) => {
                    const result = results[results.length - 1][index]
                    if (!result.success && result.errors) {
                        this._handleError(result.message, result.errors, item.row, item.data)
                    } else {
                        this._handleSave(result, item.row, item.data)
                    }

                    item.row.node().classList.remove("row-saving")
                })

                if (results[results.length - 1].every(res => res.success)) {
                    await this.refresh()
                }

                return
            }

            saveRows.forEach(item => item.row.node().classList.remove("row-saving"))
        } catch (error) {
            Helper.errorAlert({ title: "Something wrong happen", message: error.toString() })
            console.error("Something wrong happen when save all...", { error })
        } finally {
            this._saveAllBtn?.enabled()

            if (this.getDirtyRows().length == 0) {
                this._saveAllBtn?.hidden()
                this._discardAllBtn?.hidden()
            }
        }
    }

    /**
     * @param {HTMLTableRowElement} tr 
     * @param {*} data 
     */
    async discard(tr, data) {
        const row = this._table.row(tr)
        const state = data._state

        try {
            row.node().classList.add("row-saving")

            await this.trigger("discarding", data)

            if (state === "new") {
                row.remove().draw(false)
            } else if (state === "dirty") {
                const originalData = data._oldValue
                Object.assign(data, originalData)

                data._state = 'clean'
                data._error = null
                this._columns
                    .filter(col => col.data)
                    .forEach(col => {
                        if (col.editable) {
                            const editor = this.getEditor(tr, col.name)
                            editor.set(data[editor instanceof LookupInput ? col.data : col.name], true)
                            editor.resetValidation()
                        } else {
                            const columnIndex = this._table.column(`${col.name}:name`).index()
                            const cell = row.cell(row.index(), columnIndex)
                            cell.invalidate('data')
                        }
                    })

                row.cell(row.index(), '_action:name').invalidate('data')
                row.node().classList.remove("row-saving")
            }

            if (this.getDirtyRows().length == 0) {
                this._saveAllBtn?.hidden()
                this._discardAllBtn?.hidden()
            }

            await this.trigger("discarded", data)
        } catch (error) {
            console.error("Something wrong happen when discard...", { error })
        } finally {
            row?.node()?.classList.remove("row-saving")
        }
    }

    async discardAll() {
        try {
            this._discardAllBtn?.disabled()

            const discardRows = []
            this._table.rows().every(function () {
                const row = this
                const data = this.data()
                const tr = row.node()
                if (data._state !== 'clean') {
                    discardRows.push({ data, row, tr })
                }
            })

            await this.trigger("discard all", discardRows)

            const discardPromise = []
            discardRows.forEach(item => discardPromise.push(this.discard(item.tr, item.data)))

            await Promise.all(discardPromise)
        } catch (error) {
            console.error("Something wrong happen when discard all...", { error })
        } finally {
            this._discardAllBtn?.enabled()
        }
    }

    /**
     * get all data in table in current page
     * @returns {array}
     */
    getAllData() {
        return this._table.rows().data().toArray()
    }

    /**
     * get all data in table in current page that have changes
     * @returns {array}
     */
    getDirtyRows(notIncludeNew = false) {
        return this.getAllData().filter(data => {
            if (notIncludeNew) {
                return data._state != 'clean' && data._state != 'new'
            }

            return data._state != 'clean'
        })
    }

    async refresh() {
        if (this.getDirtyRows(true).length > 0) {
            if (!await Helper.confirm({ title: "You have unsaved changes", message: "Are you sure you want to leave this page?" })) {
                return
            }
        }

        await super.refresh()

        if (this.getDirtyRows().length == 0) {
            this._saveAllBtn?.hidden()
            this._discardAllBtn?.hidden()
        }
    }

    /**
     * @param {number} scale 
     */
    setDecimalScale(scale) {
        this._decimalScale = scale
    }

    /**
     * @param {string} separator 
     */
    setDecimalSeparator(separator) {
        this._decimalSeparator = separator
    }

    /**
     * @param {string} separator 
     */
    setThousandSeparator(separator) {
        this._thousandSeparator = separator
    }

    _preInit() {
        super._preInit()

        const saveAll = document.querySelector(`#${this.id}_table_save-all`)
        if (saveAll) {
            this._saveAllBtn = new Button(saveAll)
        }

        const discardAll = document.querySelector(`#${this.id}_table_discard-all`)
        if (discardAll) {
            this._discardAllBtn = new Button(discardAll)
        }
    }

    async _initCallback(settings, json) {
        await super._initCallback(settings, json)

        window.addEventListener("beforeunload", (e) => {
            if (this.getDirtyRows().length > 0) {
                e.preventDefault()
                e.returnValue = ""
                return ""
            }
        })

        document.addEventListener("click", async (e) => {
            const link = e.target.closest("a[href]")
            if (!link) {
                return
            }

            const href = link.getAttribute("href")
            if (href === "#" || href === "" || href.startsWith("javascript:")) {
                return
            }

            if (this.getDirtyRows().length > 0) {
                e.preventDefault()

                if (await Helper.confirm({ title: "You have unsaved changes", message: "Are you sure you want to leave this page?" })) {
                    await this.discardAll()
                    window.location.href = link.href
                }
            }
        })
    }

    _initColumns() {
        const columnRowHeaders = this._element.querySelectorAll("thead tr")
        const lastRowHeader = columnRowHeaders[columnRowHeaders.length - 1]

        const thIndex = document.createElement('th')
        thIndex.style.display = 'none'
        thIndex.setAttribute("field-name", "_index")
        thIndex.setAttribute("field-data", "_index")
        lastRowHeader.appendChild(thIndex)

        const orderedTh = this._getOrderedColumnHeader()
        orderedTh.forEach((th) => {
            const name = th.getAttribute("field-name")
            const data = th.getAttribute("field-data")
            const orderable = th.hasAttribute("order")
            const searchable = th.hasAttribute("searchable")
            const width = th.getAttribute("width")
            const className = th.getAttribute("cell-class")
            const editable = th.getAttribute("editable")

            if (th.classList.contains("orderable")) {
                this._handleSort(name, th)
            }

            let column = {
                name: name,
                data: data,
                className: className,
                searchable: searchable,
                orderable: orderable,
                width: width
            }

            if (editable) {
                column.editable = JSON.parse(editable)
            }

            if (name === '_action') {
                column = this._registerActionColumn(th, column)
            } else if (name === '_autoincrement') {
                column = this._registerAutoincrementColumn(th, column)
            } else if (name === '_selectall') {
                column = this._registerSelectAllColumn(th, column)
            }

            this.addColumn(column)

            if (name === '_action') {
                const actionIndex = this._columns.findIndex(col => col.name == '_action')
                this._columns[actionIndex].view = column.view
                this._columns[actionIndex].edit = column.edit
                this._columns[actionIndex].delete = column.delete
            }
        })

        this._columns[this._columns.length - 1].visible = false
    }

    _handleActionButtons() {
        super._handleActionButtons()

        this._saveAllBtn?.enabled()
        this._saveAllBtn?.on("click", async () => await this.saveAll())

        this._discardAllBtn?.enabled()
        this._discardAllBtn?.on("click", async () => await this.discardAll())
    }

    _handleRowActionButtons() {
        super._handleRowActionButtons()

        this._table.on("click", 'tbody tr td .save-action', async (e) => {
            const tr = e.target.closest('tr')
            const row = this._table.row(tr)
            const data = row.data()

            await this.save(tr, data)
        })

        this._table.on("click", 'tbody tr td .discard-action', async (e) => {
            const tr = e.target.closest('tr')
            const row = this._table.row(tr)
            const data = row.data()

            await this.discard(tr, data)
        })
    }

    _handleColumnEvents() {
        const columnEvents = []
        this._events.forEach((value, key) => {
            if (key.startsWith("column")) {
                columnEvents.push(key)
            }
        })

        if (columnEvents.length == 0) {
            return
        }

        this._columns = this._columns.map(column => {
            const name = column.name
            const originalCreated = column.createdCell

            if (this._events.has(`column render:${name}`)) {
                const renderCallback = this._events.get(`column render:${name}`)
                column.render = (data, type, row, meta) => renderCallback[renderCallback.length - 1].handler(data, row)
            }

            column.createdCell = async (cell, cellData, rowData, rowIndex, columnIndex) => {
                const row = cell.closest("tr")

                if (Helper.isFunction(originalCreated) && !column.editable) {
                    await originalCreated(cell, cellData, rowData, rowIndex, columnIndex)
                }

                columnEvents
                    .filter(e => !e.includes("column render") && !e.includes("column created") && !e.includes("column change") && !e.includes("column config"))
                    .forEach(e => {
                        const [, eventSpec] = e.split(" ", 2)
                        const [domEvent, targetColumn] = eventSpec.split(":")

                        cell.addEventListener(domEvent, async (ev) => {
                            if (!targetColumn) {
                                await this.trigger(e, name, row, cell, cellData, rowData)
                            }

                            if (targetColumn === name) {
                                await this.trigger(e, row, cell, cellData, rowData)
                            }
                        })
                    })

                if (column.editable) {
                    const onChange = this._events.get(`column change:${name}`)
                    const config = this._events.get(`column config:${name}`)
                    let finalConfig = column.editable.config ?? null

                    if (config) {
                        const eventConfig = config[config.length - 1].handler() ?? {}
                        finalConfig = {
                            ...finalConfig,
                            ...eventConfig
                        }
                    }

                    this._applyEditor(cell, rowData, column.editable.editor, onChange ? (onChange[onChange.length - 1]?.handler ?? null) : null, finalConfig)
                }
            }

            return column
        })
    }

    async _handlePagination(page) {
        const dirtyRows = this.getDirtyRows(true)
        if (dirtyRows.length > 0) {
            if (!await Helper.confirm({ title: "You have unsaved changes", message: "Are you sure you want to leave this page?" })) {
                return
            }

            this._table.rows().every(function () {
                const data = this.data()
                if (data._state !== 'clean' && data._state !== 'new') {
                    this.remove()
                }
            })
        }

        await super._handlePagination(page)
    }

    async _onNew() {
        const data = await super._onNew()

        this.addRow(data[data.length - 1] ?? null)

        this._saveAllBtn?.show()
        this._discardAllBtn?.show()
    }

    _renderColumnAction({ data, rowData, view = true, edit = true, remove = true, discard = false, group = true }) {
        const state = rowData._state
        const error = rowData._error ?? null

        let buttons = ""

        if (group) {
            buttons += `<div class="dropdown">
                <button type="button" class="btn btn-sm btn-light" data-bs-toggle="dropdown" aria-expanded="false"><i class="ri-more-fill"></i></button>
                <ul class="dropdown-menu">`

            if (state !== "clean") {
                buttons += this._getSaveBtn(true)

                if (discard) {
                    buttons += this._getDiscardBtn(true)
                }
            }

            if (state === "clean") {
                if (view) {
                    buttons += this._getViewBtn(true)
                }

                if (remove) {
                    buttons += this._getDeleteBtn(true)
                }
            }

            if (error) {
                buttons += this._getErrorBtn(error, true)
            }

            buttons += `</ul></div>`

            return buttons
        }

        if (state !== "clean") {
            buttons += this._getSaveBtn()

            if (discard) {
                buttons += this._getDiscardBtn()
            }
        }

        if (state === "clean") {
            if (view) {
                buttons += this._getViewBtn()
            }

            if (remove) {
                buttons += this._getDeleteBtn()
            }
        }

        if (error) {
            buttons += this._getErrorBtn(error)
        }

        return `<div class="d-flex justify-content-center align-items-center gap-1">${buttons}</div>`
    }

    _getSaveBtn(group = false) {
        if (group) {
            return `<li><a class="dropdown-item save-action" href="javascript:void(0);"><i class="ri-save-line me-1"></i>Save</a></li>`
        }

        return `<button class="btn btn-wave btn-success btn-icon btn-sm save-action" title="Save record"><i class="ri-save-line"></i></button>`
    }

    _getErrorBtn(error, group = false) {
        if (group) {
            return `<li><a class="dropdown-item error-action" href="javascript:void(0);" title="${error}"><i class="ri-error-warning-line me-1"></i>Error</a></li>`
        }

        return `<button class="btn btn-wave btn-danger btn-icon btn-sm rounded error-action" title="${error}"><i class="ri-error-warning-line"></i></button>`
    }

    _handleSave(res, row, data) {
        if (data._state == 'new') {
            data.id = res.data?.id ?? res.id
        }

        data._state = "clean"
        data._error = null
        data._oldValue = { ...data }
        row.cell(row.index(), '_action:name').invalidate('data')

        this.trigger("saved", res, row, data)
    }

    _handleError(message, error, row, data) {
        const tr = row.node()
        const messages = []
        for (const key in error) {
            messages.push(error[key])

            const editor = this.getEditor(tr, key)
            if (editor) {
                editor.error()
            }
        }

        data._error = !Helper.isEmpty(message) ? `${message}. ${messages.join(" ")}`.trim() : messages.join(" ").trim()
        row.cell(row.index(), '_action:name').invalidate('data')
    }

    _getDefaultOrder() {
        return [[{ name: '_index', dir: 'asc' }]]
    }

    /**
     * @param {Array[*]} data 
     * @returns {Array[*]}
     */
    _normalizeFetchData(data) {
        return data.map((d, i) => ({
            ...d,
            _index: i,
            _state: 'clean',
            _oldValue: { ...d }
        }))
    }

    //#region editor editable

    /**
     * @param {string} fieldName 
     * @param {string} fieldData
     * @param {string} value 
     * @param {int} meta 
     * @param {string} type
     * @returns {string}
     */
    _renderInputEditor(fieldName, fieldData, value, rowIndex, type = "text") {
        return `<input 
            id="${this._element.id}_${fieldName}_${rowIndex}" 
            data-fielddata="${fieldData}" 
            type="${type}" 
            class="form-control form-control-sm" 
            value="${value ?? ""}" />`
    }

    /**
     * 
     * @param {string} fieldName 
     * @param {string} fieldData 
     * @param {number} value 
     * @param {int} decimal 
     * @param {int} rowIndex 
     * @returns {string}
     */
    _renderNumberEditor(fieldName, fieldData, value, decimal, rowIndex) {
        return `<input 
            id="${this._element.id}_${fieldName}_${rowIndex}" 
            data-fielddata="${fieldData}" 
            type="text"
            mask="mask"
            number="number"
            thousand-separator="${this._thousandSeparator}"
            decimal-separator="${this._decimalSeparator}"
            decimal="${decimal}"
            class="form-control form-control-sm text-end" 
            value="${value ?? ""}" />`
    }

    /**
     * @param {string} fieldName 
     * @param {string} fieldData
     * @param {string} value 
     * @param {int} meta 
     * @returns {string}
     */
    _renderTextareaEditor(fieldName, fieldData, value, rowIndex) {
        return `<textarea 
            id="${this._element.id}_${fieldName}_${rowIndex}" 
            data-fielddata="${fieldData}" 
            class="form-control form-control-sm"
            rows="1">${value ?? ""}</textarea>`
    }

    /**
     * 
     * @param {string} fieldName 
     * @param {string} fieldData 
     * @param {string} value JSON string with {id: string, name: string}
     * @param {string} placeholder 
     * @param {string} source 
     * @param {bool} isPagination 
     * @param {int} rowIndex 
     * @returns 
     */
    _renderLookupEditor(fieldName, fieldData, value, placeholder, source, isPagination, rowIndex) {
        return LookupInput.renderHTML(
            {
                source,
                placeholder:  placeholder ?? 'Choose',
                pagination:   isPagination ?? false,
                value,
                size:         'sm',
            },
            {
                id:               `${this._element.id}_${fieldName}_${rowIndex}`,
                'data-fieldname': fieldName,
                'data-fielddata': fieldData,
            }
        )
    }

    /**
     * @param {string} fieldName 
     * @param {string} fieldData 
     * @param {string} value 
     * @param {string} mode 
     * @param {int} rowIndex 
     * @returns 
     */
    _renderDatePickerEditor(fieldName, fieldData, value, mode, rowIndex) {
        return `<input 
            id="${this._element.id}_${fieldName}_${rowIndex}" 
            data-fielddata="${fieldData}"
            mode="${mode}"
            type="text" 
            class="form-control form-control-sm" 
            value="${value ?? ""}" />`
    }

    /**
     * @param {HTMLTableCellElement} td 
     * @param {*} rowData 
     * @param {Function} onChange 
     */
    _initInputEditor(td, rowData, onChange = null) {
        const tr = td.closest('tr')
        const row = this._table.row(tr)

        const inputElement = td.querySelector('input')
        const input = new TextInput(inputElement)
        $(td).data('editor', input)

        input.on("change", (val) => {
            input.resetValidation()

            this._saveAllBtn?.show()
            this._discardAllBtn?.show()

            if (Helper.isFunction(onChange)) {
                onChange(tr, val, rowData)
            }

            if (rowData._state !== 'new') {
                rowData._state = 'dirty'
                row.cell(row.index(), '_action:name').invalidate('data')
                this._handleActionDropdown()
            }

            rowData[inputElement.getAttribute("data-fielddata")] = val
        })
    }

    /**
     * @param {HTMLTableCellElement} td 
     * @param {*} rowData 
     * @param {Function} onChange 
     */
    _initTextareaEditor(td, rowData, onChange = null) {
        const tr = td.closest('tr')
        const row = this._table.row(tr)

        const inputElement = td.querySelector('textarea')
        const input = new TextareaInput(inputElement)
        $(td).data('editor', input)

        input.on("change", (val) => {
            input.resetValidation()

            this._saveAllBtn?.show()
            this._discardAllBtn?.show()

            rowData[inputElement.getAttribute("data-fielddata")] = val

            if (Helper.isFunction(onChange)) {
                onChange(tr, val, rowData)
            }

            if (rowData._state !== 'new') {
                rowData._state = 'dirty'
                row.cell(row.index(), '_action:name').invalidate('data')
                this._handleActionDropdown()
            }
        })
    }

    /**
     * @param {HTMLTableCellElement} td 
     * @param {*} rowData 
     * @param {Function} onChange 
     * @param {*} config 
     */
    _initNumberEditor(td, rowData, onChange = null, config = null) {
        const tr = td.closest('tr')
        const row = this._table.row(tr)

        const inputElement = td.querySelector('input[type="text"]')
        const input = new MaskInput(inputElement, config)
        $(td).data('editor', input)

        input.on("change", (val) => {
            input.resetValidation()

            this._saveAllBtn?.show()
            this._discardAllBtn?.show()

            rowData[inputElement.getAttribute("data-fielddata")] = val

            if (Helper.isFunction(onChange)) {
                onChange(tr, val, rowData)
            }

            if (rowData._state !== 'new') {
                rowData._state = 'dirty'
                row.cell(row.index(), '_action:name').invalidate('data')
                this._handleActionDropdown()
            }
        })
    }

    /**
     * @param {HTMLTableCellElement} td 
     * @param {*} rowData 
     * @param {Function} onChange 
     * @param {*} config 
     */
    _initLookupEditor(td, rowData, onChange = null, config = null) {
        const tr = td.closest('tr')
        const row = this._table.row(tr)

        const finalConfig = { ...config }

        if (config?.param) {
            finalConfig.param = (param) => config.param(tr, rowData, param)
        }

        if (config?.createNew) {
            finalConfig.createNew = {
                ...config.createNew,
                callback: (term) => config.createNew.callback(tr, rowData, term)
            }
        }

        const el     = td.querySelector('[solar-ui="lookup"]')
        const lookup = new LookupInput(el, finalConfig)
        $(td).data('editor', lookup)

        lookup.on("change", (val) => {
            lookup.resetValidation()

            this._saveAllBtn?.show()
            this._discardAllBtn?.show()

            rowData[el.getAttribute("data-fielddata")] = val
            rowData[el.getAttribute("data-fieldname")] = val?.id ?? null

            if (Helper.isFunction(onChange)) {
                onChange(tr, val, rowData)
            }

            if (rowData._state !== 'new') {
                rowData._state = 'dirty'
                row.cell(row.index(), '_action:name').invalidate('data')
                this._handleActionDropdown()
            }
        })
    }

    /**
     * @param {HTMLTableCellElement} td 
     * @param {*} rowData 
     * @param {Function} onChange 
     * @param {*} config 
     */
    _initDatePickerEditor(td, rowData, onChange = null, config = null) {
        const tr = td.closest('tr')
        const row = this._table.row(tr)

        const inputElement = td.querySelector('input[type="text"]')
        const input = new DatePicker(inputElement, inputElement.getAttribute("mode"), config)
        $(td).data('editor', input)

        input.on("change", (val) => {
            input.resetValidation()

            this._saveAllBtn?.show()
            this._discardAllBtn?.show()

            rowData[inputElement.getAttribute("data-fielddata")] = input.toString()

            if (Helper.isFunction(onChange)) {
                onChange(tr, val, rowData)
            }

            if (rowData._state !== 'new') {
                rowData._state = 'dirty'
                row.cell(row.index(), '_action:name').invalidate('data')
                this._handleActionDropdown()
            }
        })
    }

    /**
     * @param {HTMLTableCellElement} td 
     * @param {*} rowData 
     * @param {string} editor 
     * @param {Function} onChange 
     * @param {*} config 
     */
    _applyEditor(td, rowData, editor, onChange = null, config = null) {
        switch (editor) {
            case 'lookup':
                this._initLookupEditor(td, rowData, onChange, config)
                break

            case 'number':
                this._initNumberEditor(td, rowData, onChange, config)
                break

            case 'textarea':
                this._initTextareaEditor(td, rowData, onChange)
                break

            case 'date':
            case 'datetime':
            case 'time':
                this._initDatePickerEditor(td, rowData, onChange, config)
                break

            default:
                this._initInputEditor(td, rowData, onChange)
                break
        }
    }

    _renderEditor(fieldName, fieldData, data, editable, meta) {
        switch (editable.editor) {
            case 'lookup':
                return this._renderLookupEditor(
                    fieldName,
                    fieldData,
                    encodeURIComponent(JSON.stringify(data)),
                    editable.placeholder ?? "Choose",
                    editable.source,
                    editable.isPagination ?? false,
                    meta.row
                )

            case 'number':
                return this._renderNumberEditor(fieldName, fieldData, data, editable.decimal ?? this._decimalScale, meta.row)

            case 'textarea':
                return this._renderTextareaEditor(fieldName, fieldData, data, meta.row)

            case 'date':
            case 'datetime':
            case 'time':
                return this._renderDatePickerEditor(fieldName, fieldData, data, editable.editor, meta.row)

            default:
                const editorSplit = editable.editor.split(":")
                const type = editorSplit.length > 1 ? editorSplit[1] : "text"

                return this._renderInputEditor(fieldName, fieldData, data, meta.row, type)
        }
    }

    /**
     * @param {HTMLTableRowElement} tr 
     * @param {string} fieldName 
     * @returns {BaseInput} 
     */
    getEditor(tr, fieldName) {
        const row = this._table.row(tr)
        const columnIndex = this._table.column(`${fieldName}:name`).index()
        const cell = row.cell(row.index(), columnIndex)

        return $(cell.node()).data('editor')
    }

    //#endregion
}