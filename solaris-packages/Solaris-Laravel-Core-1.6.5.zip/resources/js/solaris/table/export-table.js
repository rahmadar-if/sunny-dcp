import Button from "@core-js/solaris/button"
import FieldInput from "@core-js/solaris/form/field-input"
import Helper from "@core-js/solaris/helper"
import Modal from "@core-js/solaris/modal"
import Table from "./table"
import axios from "@core-js/libs/axios"

export default class ExportTable {

	/**
	 * @param {Table} table
	 */
	constructor(table) {
		this.id = `${table.id}_table_export_modal`
		this._table = table
		this._validModel = Helper.getValidModel(table._model)
		this._rawModel = table._model

		this.init()
	}

	init() {
		this._columns = []
		this._relations = []
		this._isColumnsRender = false
		this._columnsCache = new Map()

		this._modal = new Modal(document.querySelector(`#${this.id}`))
		this._exportType = new FieldInput(document.querySelector(`div[solar-id="${this.id}_export_type"`))
		this._exportScope = new FieldInput(document.querySelector(`div[solar-id="${this.id}_export_scope"`))
		this._totalRowsInfo = this._modal._element.querySelector(`#${this.id}_total_rows`)
		this._downloadBtn = new Button(document.querySelector(`#${this.id}_export`))
		this._customElement = this._modal._element.querySelector("div.custom-columns")
		this._columnsElement = this._customElement.querySelector(`#${this.id}_tabs_columns`)
		this._detailsElement = this._customElement.querySelector(`#${this.id}_tabs_details`)
		this._detailsNavElement = this._customElement.querySelector(`#${this.id}_tabs_details_button`)?.parentElement

		this._modal.on("hide", () => {
			this._exportType.reset(true)
			this._exportScope.reset(true)

			this._columns = []
			this._relations = []
			this._isColumnsRender = false
			this._columnsElement.querySelectorAll('input.is-invalid').forEach(el => el.classList.remove('is-invalid'))
			this._columnsElement.innerHTML = ''
			this._detailsElement.innerHTML = ''
			this._detailsNavElement?.classList.add('d-none')
			this._customElement.classList.add('d-none')
			this._totalRowsInfo.textContent = ''
			this._columnsCache.clear()
		})

		this._exportType.on("change", (val) => this.exportTypeChange(val))
		this._exportScope.on("change", (val) => this.exportScopeChange(val))
		this._downloadBtn.on("click", async () => await this.download())
	}

	async showModal() {
		Helper.loadingPage(true)

		try {
			const res = await this._fetchColumns(this._validModel)
			this._columns = res.columns
			this._relations = res.relations ?? []
			this._modal.show()
		} catch (error) {
			console.error({ error })
			// Helper.errorAlert({ title: "Whoops! 🙀", message: error })
		} finally {
			Helper.loadingPage(false)
		}
	}

	async download() {
		const params = {
			export_type: this._exportType.get()?.id ?? null,
			export_scope: this._exportScope.get()?.id ?? null,
			export_columns: this._getSelectedColumns()
		}

		let isValid = true
		if (!params.export_type) {
			this._exportType.error()
			this._exportType.setMessage("Export type is required")
			isValid = false
		}

		if (!params.export_scope) {
			this._exportScope.error()
			this._exportScope.setMessage("Export scope is required")
			isValid = false
		}

		if (params.export_columns.length == 0 && params.export_type == 'custom') {
			Helper.toast({ message: "Columns is required", color: "danger" })
			isValid = false
		}

		let hasInvalidLookup = false
		this._columnsElement.querySelectorAll('input[data-lookup]:checked').forEach(checkbox => {
			const collapseEl = this._columnsElement.querySelector(`#${checkbox.id}_collapse`)
			if (!collapseEl || collapseEl.querySelector('input[type="checkbox"]:checked')) return
			checkbox.classList.add('is-invalid')
			hasInvalidLookup = true
		})

		if (hasInvalidLookup) {
			Helper.toast({ message: "Select at least one sub-column for each lookup", color: "danger" })
			isValid = false
		}

		if (!isValid) {
			return
		}

		Object.assign(params, this._table._getParamData())

		Helper.loadingPage(true)

		this._downloadBtn.disabled()
		try {
			const res = await axios({
				method: "POST",
				url: `${BASE_URL}/core/excel/export`,
				headers: { 'X-Export-Model': this._rawModel },
				data: params
			}).then(res => res.data)

			if (!res.success) {
				throw res.message
			}

			Helper.successAlert({ title: "Export started", message: res.message })
				.then(res => this._modal.hide())
		} catch (error) {
			console.error({ error })
			Helper.errorAlert({ title: "Export failed", message: error })
		} finally {
			this._downloadBtn.enabled()
			Helper.loadingPage(false)
		}
	}

	/**
	 * @param {{id: string, name: string}|null} val
	 */
	exportTypeChange(val) {
		if (!val || (val && val.id != 'custom')) {
			if (!this._customElement.classList.contains('d-none')) {
				this._customElement.classList.add('d-none')
			}
			return
		}

		this._customElement.classList.remove('d-none')

		if (!this._isColumnsRender) {
			let columnsContent = ''
			this._columns.forEach(col => {
				const id = `${this.id}_${col.name}`
				columnsContent += col.type === 'lookup'
					? this._renderLookupCheckbox(col.displayName, id, col.name, col.lookup, col.default)
					: this._renderCheckbox(col.displayName, id, col.name, col.default)
			})

			if (!Helper.isEmpty(columnsContent)) {
				this._columnsElement.innerHTML = `<label class="form-label">Select Columns to Export <span class="text-danger">*</span></label>
					${this._renderCheckbox("Select all", `${this.id}_select_all`, 'select_all', false)}
					<hr>
					${columnsContent}`

				this._selectAll = this._columnsElement.querySelector(`#${this.id}_select_all`)
				this._checkboxes = this._columnsElement.querySelectorAll(`input[type="checkbox"]:not(#${this.id}_select_all)`)
				this._iconCollapses = this._columnsElement.querySelectorAll(`i[data-bs-toggle="collapse"]`)

				// Sync initial selected state from col.default after DOM is built
				this._columns.forEach(col => {
					col.selected = col.default
				})

				this._checkboxes.forEach(checkbox => {
					const col = this._columns.find(c => c.name === checkbox.value)
					if (col) checkbox._exportCol = col
					this._onColumnCheckboxChange(checkbox)
				})
				this._iconCollapses.forEach(icon => {
					icon.addEventListener("click", () => {
						icon.classList.toggle("ri-arrow-down-s-line")
						icon.classList.toggle("ri-arrow-up-s-line")
					})
				})

				this._onColumnSelectAllChange(this._selectAll)
			}

			if (this._relations.length > 0) {
				let relationsContent = ''
				this._relations.forEach(rel => {
					relationsContent += this._renderRelationLabel(rel.displayName)
				})
				this._detailsElement.innerHTML = `<label class="form-label">Relations</label><hr>${relationsContent}`
				this._detailsNavElement?.classList.remove('d-none')
			}

			this._isColumnsRender = true
		}
	}

	/**
	 * @param {{id: string, name: string}|null} val
	 */
	exportScopeChange(val) {
		if (!val) {
			this._totalRowsInfo.textContent = ""
			return
		}

		const totalRows = val.id == "all" ? this._table._recordsTotal : this._table._recordsFiltered
		this._totalRowsInfo.textContent = `You are exporting ${Intl.NumberFormat("id", { minimumFractionDigits: 0 }).format(totalRows)} matching rows`
	}

	/**
	 * @param {string} label
	 * @param {string} id
	 * @param {string} value
	 * @param {boolean} checked
	 * @returns {string}
	 */
	_renderCheckbox(label, id, value, checked = false) {
		return `<div class="form-check form-switch">
			<input class="form-check-input" type="checkbox" role="switch" id="${id}" value="${value}"${checked ? ' checked' : ''}>
			<label class="form-check-label" for="${id}">${label}</label>
		</div>`
	}

	/**
	 * @param {string} label
	 * @param {string} id
	 * @param {string} value
	 * @param {string} lookup
	 * @param {boolean} checked
	 * @returns {string}
	 */
	_renderLookupCheckbox(label, id, value, lookup, checked = false) {
		return `<div class="d-flex align-items-center">
			<div class="form-check form-switch flex-grow-1">
				<input class="form-check-input" data-lookup="${lookup}" type="checkbox" role="switch" id="${id}" value="${value}"${checked ? ' checked' : ''}>
				<label class="form-check-label" for="${id}">${label} <span class="badge bg-secondary">Lookup</span></label>
				<div class="invalid-feedback">Sub-column is required</div>
			</div>
			<i class="fs-16 ri-arrow-down-s-line cursor-pointer d-none" data-bs-toggle="collapse" data-checkbox="${id}" data-bs-target="#${id}_collapse"></i>
		</div>
		<div class="collapse ms-4" id="${id}_collapse"></div>`
	}

	/**
	 * @param {string} label
	 * @returns {string}
	 */
	_renderRelationLabel(label) {
		return `<div class="d-flex align-items-center gap-2 mb-1">
			<span class="text-muted">${label}</span>
			<span class="badge bg-secondary">Relation</span>
		</div>`
	}

	/**
	 * @param {HTMLInputElement} checkbox
	 */
	_onColumnSelectAllChange(checkbox) {
		checkbox.addEventListener("change", (e) => {
			const checked = checkbox.checked
			this._checkboxes.forEach(c => {
				if (checked && !c.checked) {
					c.click()
				} else if (!checked && c.checked) {
					c.click()
				}
			})
		})
	}

	/**
	 * @param {HTMLInputElement} checkbox
	 */
	_onColumnCheckboxChange(checkbox) {
		checkbox.addEventListener("change", async (e) => {
			const checked = checkbox.checked
			if (!checked && this._selectAll.checked) {
				this._selectAll.checked = false
			}

			const id = checkbox.id
			const lookup = checkbox.getAttribute("data-lookup")
			const icon = this._columnsElement.querySelector(`i[data-bs-toggle="collapse"][data-checkbox="${id}"]`)
			const collapseEl = icon ? this._columnsElement.querySelector(`#${id}_collapse`) : null
			const exportCol = checkbox._exportCol ?? null

			if (exportCol) {
				exportCol.selected = checked
			}

			if (checked) {
				const closestCollapse = checkbox.closest('.collapse')
				if (closestCollapse) {
					const parentCheckboxId = closestCollapse.id.replace(/_collapse$/, '')
					const parentCheckbox = this._columnsElement.querySelector(`#${parentCheckboxId}`)
					if (parentCheckbox) parentCheckbox.classList.remove('is-invalid')
				}
			}

			if (lookup && icon) {
				if (checked) {
					if (collapseEl && collapseEl.innerHTML.trim() === '') {
						const res = await this._fetchColumns(lookup)
						if (res.columns) {
							this._renderSubColumns(exportCol, res.columns, collapseEl, id)
						}
					}

					if (icon.classList.contains("ri-arrow-down-s-line")) {
						icon.click()
					}
				} else {
					if (exportCol?.sub_columns) {
						this._uncheckSubs(exportCol, collapseEl)
					}

					if (icon.classList.contains("ri-arrow-up-s-line")) {
						icon.click()
					}
				}
			}
		})
	}

	/**
	 * @param {string} modelKey
	 * @returns {Promise<{columns: Array, relations: Array}>}
	 */
	async _fetchColumns(modelKey) {
		if (this._columnsCache.has(modelKey)) {
			return this._columnsCache.get(modelKey)
		}
		const res = await axios({
			method: "POST",
			url: `${BASE_URL}/core/excel/export/columns`,
			headers: { 'X-Export-Model': modelKey }
		}).then(res => res.data)
		this._columnsCache.set(modelKey, res)
		return res
	}

	/**
	 * @param {object} col
	 * @param {Array} subColumns
	 * @param {HTMLElement} collapseEl
	 * @param {string} parentId
	 */
	_renderSubColumns(col, subColumns, collapseEl, parentId) {
		col.sub_columns = subColumns.map(sub => ({
			...sub,
			selected: sub.name === col.display_value,
			is_display_value: sub.name === col.display_value,
		}))

		let subContent = ''
		col.sub_columns.forEach(sub => {
			const subId = `${parentId}_${sub.name}`
			subContent += sub.type === 'lookup'
				? this._renderLookupCheckbox(sub.displayName, subId, sub.name, sub.lookup, sub.is_display_value)
				: this._renderCheckbox(sub.displayName, subId, sub.name, sub.is_display_value)
		})

		collapseEl.innerHTML = `<div class="border-start ps-3">${subContent}</div>`

		collapseEl.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
			const sub = col.sub_columns.find(s => s.name === checkbox.value)
			if (sub) checkbox._exportCol = sub
			this._onColumnCheckboxChange(checkbox)
		})

		collapseEl.querySelectorAll('i[data-bs-toggle="collapse"]').forEach(icon => {
			icon.addEventListener("click", () => {
				icon.classList.toggle("ri-arrow-down-s-line")
				icon.classList.toggle("ri-arrow-up-s-line")
			})
		})

		const parentIcon = this._columnsElement.querySelector(`i[data-bs-toggle="collapse"][data-checkbox="${parentId}"]`)
		if (parentIcon) {
			parentIcon.classList.remove('d-none')
		}
	}

	/**
	 * @param {object} col
	 * @param {HTMLElement|null} collapseEl
	 */
	_uncheckSubs(col, collapseEl) {
		if (!col?.sub_columns) return
		col.sub_columns.forEach(sub => {
			sub.selected = false
			this._uncheckSubs(sub, null)
		})
		if (collapseEl) {
			collapseEl.querySelectorAll('input[type="checkbox"]').forEach(cb => { cb.checked = false })
		}
	}

	/**
	 * @returns {string[]}
	 */
	_getSelectedColumns() {
		return this._columns
			.filter(col => col.selected)
			.map(col => {
				const subCols = col.sub_columns ?? []
				const selectedSubs = subCols.filter(s => s.selected)

				if (subCols.length === 0 || selectedSubs.length === 0) {
					return col.name
				}

				// Only display value selected: send column name (server resolves to displayValue)
				const onlyDisplayValue = selectedSubs.length === 1 && selectedSubs[0].is_display_value
				if (onlyDisplayValue) {
					return col.name
				}

				const baseName = col.name.replace(/_id$/, '')
				return selectedSubs.map(s => `${baseName}.${s.name}`)
			})
			.flat()
	}
}
