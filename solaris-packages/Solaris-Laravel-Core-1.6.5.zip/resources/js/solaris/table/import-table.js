import Dropzone from "dropzone"
import axios from "@core-js/libs/axios"
import Button from "@core-js/solaris/button"
import Helper from "@core-js/solaris/helper"
import Modal from "@core-js/solaris/modal"
import LookupInput from "@core-js/solaris/form/lookup-input"
import Table from "./table"

export default class ImportTable {

	/**
	 * @param {Table} table
	 */
	constructor(table) {
		this.id = `${table.id}_table_import_modal`
		this._table = table
		this._validModel = Helper.getValidModel(table._model)
		this._rawModel = table._model

		this.init()
	}

	init() {
		this._attachmentId = null
		this._importConfirmed = false
		this._modelColumns = []
		this._modelColumnsMap = new Map()
		this._dropzoneInstance = null
		this._lookupInstances = new Map()
		this._matchByInstances = new Map()
		this._checkboxMap = new Map()
		this._refreshing = false

		this._modal = new Modal(document.querySelector(`#${this.id}`))
		this._step1El = this._modal._element.querySelector('.import-step-1')
		this._step2El = this._modal._element.querySelector('.import-step-2')
		this._mappingInfo = this._modal._element.querySelector(`#${this.id}_mapping_info`)
		this._mappingList = this._modal._element.querySelector(`#${this.id}_mapping_list`)
		this._templateBtn = new Button(document.querySelector(`#${this.id}_template`))
		this._nextBtn = new Button(document.querySelector(`#${this.id}_next`))
		this._backBtn = new Button(document.querySelector(`#${this.id}_back`))
		this._proceedBtn = new Button(document.querySelector(`#${this.id}_proceed`))

		this._modal.on("hide", () => this._onModalHide())
		this._nextBtn.on("click", () => this._showStep(2))
		this._backBtn.on("click", () => this._showStep(1))
		this._proceedBtn.on("click", async () => await this._confirm())
		this._templateBtn.on("click", async () => await this._downloadTemplate())

		this._initDropzone()
	}

	async showModal() {
		Helper.loadingPage(true)

		try {
			const res = await axios({
				method: "POST",
				url: `${BASE_URL}/core/excel/import/validation`,
				headers: { 'X-Import-Model': this._rawModel }
			}).then(res => res.data)

			if (!res.success) {
				throw res.message
			}

			this._modal.show()
		} catch (error) {
			console.error({ error })
			Helper.errorAlert({ title: "Whoops! 🙀", message: error })
		} finally {
			Helper.loadingPage(false)
		}
	}

	_initDropzone() {
		const availMimes = Helper.getAvailableMime(".xlsx")
		const availExt = [...new Set(availMimes.map(item => item.ext))]

		const scope = this
		this._dropzoneInstance = new Dropzone(document.querySelector(`#${this.id}_upload`), {
			url: `${BASE_URL}/core/excel/import/upload`,
			headers: {
				"X-CSRF-TOKEN": Helper.getCsrfToken(),
				"X-Import-Model": this._rawModel
			},
			method: "post",
			paramName: "file",
			chunking: true,
			forceChunking: true,
			chunkSize: 2000000,
			retryChunks: true,
			retryChunksLimit: 3,
			maxFiles: 1,
			parallelUploads: 1,
			acceptedFiles: availExt.join(","),
			init: function () {
				const removeFile = (file) => {
					setTimeout(() => {
						file.previewElement.style.transition = "opacity 0.5s ease-out"
						file.previewElement.style.opacity = "0"
						setTimeout(() => this.removeFile(file), 500)
					}, 2000)
				}

				this.on("addedfile", async function () {
					// Delete prior attachment if any before accepting new file
					if (scope._attachmentId) {
						await scope._deleteUpload(scope._attachmentId)
					}
					scope._attachmentId = null
					scope._lookupInstances.clear()
					scope._matchByInstances.clear()
					scope._checkboxMap.clear()
					scope._mappingList.innerHTML = ''
					scope._mappingInfo.textContent = ''
					scope._nextBtn.hidden()
				})

				this.on("sending", function () {
					scope._templateBtn.disabled()
				})

				this.on("success", function (file, response) {
					removeFile(file)
					scope._templateBtn.enabled()

					if (!response.success) {
						Helper.errorAlert({ title: "Upload failed", message: response.message })
						return
					}

					scope._attachmentId = response.attachment_id
					scope._fetchMapping()
				})

				this.on("error", function (file, response) {
					removeFile(file)
					scope._templateBtn.enabled()
					Helper.errorAlert({ title: "Upload failed", message: response.message ?? response })
				})
			}
		})
	}

	async _fetchMapping() {
		Helper.loadingPage(true)

		try {
			const res = await axios({
				method: "POST",
				url: `${BASE_URL}/core/excel/import/columns`,
				headers: { 'X-Import-Model': this._rawModel },
				data: {
					attachment_id: this._attachmentId,
					model: this._validModel
				}
			}).then(res => res.data)

			if (!res.success) {
				throw res.message
			}

			this._renderMapping(res)
		} catch (error) {
			console.error({ error })
			Helper.errorAlert({ title: "Whoops! 🙀", message: error })
		} finally {
			Helper.loadingPage(false)
		}
	}

	/**
	 * @param {{ file_headers: string[], model_columns: object[], auto_mapping: object }} data
	 */
	_renderMapping(data) {
		const { file_headers, model_columns, auto_mapping } = data

		this._modelColumns = model_columns.map(col => ({ id: col.name, name: col.displayName }))
		this._modelColumnsMap = new Map(model_columns.map(col => [col.name, col]))

		this._lookupInstances.clear()
		this._matchByInstances.clear()
		this._checkboxMap.clear()

		this._mappingList.innerHTML = file_headers.map((header, index) =>
			this._buildMappingRow(header, index)
		).join('')

		this._initMappingLookups(auto_mapping)
		this._showStep(2)
	}

	/**
	 * @param {string} header
	 * @param {number} index
	 * @returns {string}
	 */
	_buildMappingRow(header, index) {
		const escaped = this._escapeHtml(header)
		return `<div class="import-mapping-row d-flex align-items-center gap-2 py-2 border-bottom" data-header="${escaped}">
			<div class="form-check mb-0 flex-shrink-0">
				<input type="checkbox" class="form-check-input mapping-checkbox" checked>
			</div>
			<span class="flex-shrink-0 fw-semibold text-truncate" style="min-width: 160px; max-width: 220px;" title="${escaped}">${escaped}</span>
			<div class="flex-grow-1">
				<div class="mapping-lookup" id="mapping-lookup-${index}"></div>
			</div>
			<div class="mapping-matchby-container d-none flex-shrink-0" style="width: 180px;">
				<div class="mapping-matchby" id="mapping-matchby-${index}"></div>
			</div>
		</div>`
	}

	/**
	 * @param {object} autoMapping  — format: { header: { column, match_by } }
	 */
	_initMappingLookups(autoMapping) {
		const rows = this._mappingList.querySelectorAll('.import-mapping-row')

		rows.forEach(row => {
			const header = row.getAttribute('data-header')
			const selectEl = row.querySelector('.mapping-lookup')
			const checkboxEl = row.querySelector('.mapping-checkbox')

			const lookup = LookupInput.create(row.querySelector('.mapping-lookup'), { placeholder: '— Map to column —' })
			lookup.setOptions([...this._modelColumns])

			const autoEntry = autoMapping[header]
			const autoColumn = autoEntry?.column ?? null
			const autoMatchBy = autoEntry?.match_by ?? null

			if (autoColumn) {
				const col = this._modelColumns.find(c => c.id === autoColumn)
				if (col) {
					lookup.set(col)
				}
			}

			this._lookupInstances.set(header, lookup)
			this._checkboxMap.set(header, checkboxEl)

			lookup.on('change', () => this._onMappingChange(header))
			checkboxEl.addEventListener('change', () => this._onCheckboxToggle(header))

			// Init match-by if auto-mapped to a lookup column
			if (autoColumn) {
				const colMeta = this._modelColumnsMap.get(autoColumn)
				if (colMeta?.type === 'lookup') {
					this._showMatchBy(header, row, colMeta, autoMatchBy)
				}
			}
		})

		this._refreshLookupOptions()
		this._updateMappingInfo()
	}

	/**
	 * @param {string} header
	 */
	_onCheckboxToggle(header) {
		const lookup = this._lookupInstances.get(header)
		const checkbox = this._checkboxMap.get(header)
		const row = this._mappingList.querySelector(`.import-mapping-row[data-header="${CSS.escape(header)}"]`)

		if (!checkbox.checked) {
			lookup.disabled()
			lookup.clear()
			this._hideMatchBy(header, row)
		} else {
			lookup.enabled()
			lookup.resetValidation()
		}

		this._refreshLookupOptions()
		this._updateMappingInfo()
	}

	/**
	 * @param {string} header
	 */
	_onMappingChange(header) {
		const lookup = this._lookupInstances.get(header)
		const val = lookup.get()
		const row = this._mappingList.querySelector(`.import-mapping-row[data-header="${CSS.escape(header)}"]`)

		lookup.resetValidation()

		if (val) {
			const colMeta = this._modelColumnsMap.get(val.id)
			if (colMeta?.type === 'lookup') {
				this._showMatchBy(header, row, colMeta, null)
			} else {
				this._hideMatchBy(header, row)
			}
		} else {
			this._hideMatchBy(header, row)
		}

		this._refreshLookupOptions()
		this._updateMappingInfo()
	}

	/**
	 * @param {string} header
	 * @param {Element} row
	 * @param {object} colMeta
	 * @param {string|null} defaultValue
	 */
	_showMatchBy(header, row, colMeta, defaultValue) {
		const container = row.querySelector('.mapping-matchby-container')
		container.classList.remove('d-none')

		let matchByLookup = this._matchByInstances.get(header)
		if (!matchByLookup) {
			matchByLookup = LookupInput.create(row.querySelector('.mapping-matchby'), { placeholder: '— Match by —', allowClear: false })
			this._matchByInstances.set(header, matchByLookup)

			matchByLookup.on('change', () => {
				matchByLookup.resetValidation()
				this._updateMappingInfo()
			})
		}

		const opts = (colMeta.lookup_columns ?? []).map(c => ({ id: c.name, name: c.displayName }))
		matchByLookup.setOptions(opts)

		const def = defaultValue ?? colMeta.lookup_display_value ?? null
		if (def) {
			const opt = opts.find(o => o.id === def)
			if (opt) {
				matchByLookup.set(opt)
			}
		}
	}

	/**
	 * @param {string} header
	 * @param {Element} row
	 */
	_hideMatchBy(header, row) {
		const container = row.querySelector('.mapping-matchby-container')
		container.classList.add('d-none')
		this._matchByInstances.get(header)?.clear()
	}

	_refreshLookupOptions() {
		if (this._refreshing) return
		this._refreshing = true

		// Collect all selected column IDs from checked rows
		const selected = new Set()
		for (const [header, lookup] of this._lookupInstances) {
			const checkbox = this._checkboxMap.get(header)
			if (!checkbox.checked) continue
			const val = lookup.get()
			if (val) {
				selected.add(val.id)
			}
		}

		// Per row: available options = all columns minus those selected in OTHER rows
		for (const [header, lookup] of this._lookupInstances) {
			const checkbox = this._checkboxMap.get(header)
			if (!checkbox.checked) continue

			const currentVal = lookup.get()
			const excluded = new Set(selected)
			if (currentVal) {
				excluded.delete(currentVal.id) // keep own selection available
			}

			const available = this._modelColumns.filter(col => !excluded.has(col.id))
			lookup.setOptions(available)

			// Re-apply selection since setOptions clears it
			if (currentVal) {
				const colFull = available.find(col => col.id === currentVal.id)
				if (colFull) lookup.set(colFull)
			}
		}

		this._refreshing = false
	}

	_updateMappingInfo() {
		let checked = 0, mapped = 0
		for (const [header, checkbox] of this._checkboxMap) {
			if (!checkbox.checked) continue
			checked++
			const val = this._lookupInstances.get(header)?.get()
			if (val) mapped++
		}
		this._mappingInfo.textContent = `${checked} selected · ${mapped} mapped · ${mapped} will import`
	}

	/**
	 * @returns {boolean}
	 */
	_validateMapping() {
		let valid = true
		for (const [header, checkbox] of this._checkboxMap) {
			if (!checkbox.checked) continue

			const lookup = this._lookupInstances.get(header)
			const val = lookup.get()
			if (!val) {
				lookup.error()
				valid = false
				continue
			}

			const colMeta = this._modelColumnsMap.get(val.id)
			if (colMeta?.type === 'lookup') {
				const matchByLookup = this._matchByInstances.get(header)
				if (!matchByLookup?.get()) {
					matchByLookup?.error()
					valid = false
				}
			}
		}
		return valid
	}

	/**
	 * @param {number} step
	 */
	_showStep(step) {
		if (step === 1) {
			this._step1El.classList.remove('d-none')
			this._step2El.classList.add('d-none')
			if (this._attachmentId) {
				this._nextBtn.show()
			}
		} else {
			this._step1El.classList.add('d-none')
			this._step2El.classList.remove('d-none')
		}
	}

	async _confirm() {
		if (!this._validateMapping()) {
			Helper.toast({ message: "Some columns are not fully mapped. Please review highlighted rows.", color: "danger" })
			return
		}

		const mapping = []
		for (const [header, checkbox] of this._checkboxMap) {
			if (!checkbox.checked) continue
			const val = this._lookupInstances.get(header).get()
			const colMeta = this._modelColumnsMap.get(val.id)
			const matchBy = colMeta?.type === 'lookup'
				? (this._matchByInstances.get(header)?.get()?.id ?? null)
				: null
			mapping.push({ header, column: val.id, match_by: matchBy })
		}

		Helper.loadingPage(true)
		this._proceedBtn.disabled()

		try {
			const res = await axios({
				method: "POST",
				url: `${BASE_URL}/core/excel/import/confirm`,
				headers: { 'X-Import-Model': this._rawModel },
				data: {
					attachment_id: this._attachmentId,
					model: this._validModel,
					mapping
				}
			}).then(res => res.data)

			if (!res.success) {
				throw res.message
			}

			this._importConfirmed = true
			Helper.successAlert({ title: "Import started", message: res.message })
				.then(() => this._modal.hide())
		} catch (error) {
			console.error({ error })
			Helper.errorAlert({ title: "Import failed", message: error })
		} finally {
			this._proceedBtn.enabled()
			Helper.loadingPage(false)
		}
	}

	async _downloadTemplate() {
		this._templateBtn.disabled()
		try {
			await Helper.downloadFile(
				`${BASE_URL}/core/excel/import/template`,
				"GET",
				{ headers: { 'X-Import-Model': this._rawModel } }
			)
		} catch (error) {
			console.error({ error })
			Helper.errorAlert({ title: "Download failed", message: error })
		} finally {
			this._templateBtn.enabled()
		}
	}

	async _deleteUpload(attachmentId) {
		try {
			await axios({
				method: "DELETE",
				url: `${BASE_URL}/core/excel/import/upload/${attachmentId}`,
				headers: { 'X-CSRF-TOKEN': Helper.getCsrfToken() }
			})
		} catch (error) {
			console.error('Failed to delete upload', { error })
		}
	}

	async _onModalHide() {
		if (this._attachmentId && !this._importConfirmed) {
			await this._deleteUpload(this._attachmentId)
		}
		this._reset()
	}

	/**
	 * @param {string} str
	 * @returns {string}
	 */
	_escapeHtml(str) {
		const div = document.createElement('div')
		div.textContent = str
		return div.innerHTML
	}

	_reset() {
		this._attachmentId = null
		this._importConfirmed = false
		this._modelColumns = []
		this._modelColumnsMap = new Map()
		this._lookupInstances.clear()
		this._matchByInstances.clear()
		this._checkboxMap.clear()
		this._mappingList.innerHTML = ''
		this._mappingInfo.textContent = ''
		this._templateBtn.enabled()
		this._nextBtn.hidden()
		this._proceedBtn.enabled()
		this._showStep(1)

		if (this._dropzoneInstance) {
			this._dropzoneInstance.removeAllFiles(true)
		}
	}
}
