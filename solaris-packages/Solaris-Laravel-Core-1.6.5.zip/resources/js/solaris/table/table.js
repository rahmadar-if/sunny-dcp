import axios from "@core-js/libs/axios"
import DataTable from "datatables.net-dt"
import "datatables.net-fixedcolumns-dt"
import Paginator from "./paginator"
import Filter from "@core-js/solaris/filter/filter"
import Helper from "@core-js/solaris/helper"
import Model from "@core-js/solaris/model"
import Button from "@core-js/solaris/button"
import SearchInput from "@core-js/solaris/form/search-input"
import Folder from "./folders"
import ExportTable from "./export-table"
import ImportTable from "./import-table"
import SolarComponent from "../solar/solar-component"
import Modal from "../modal"
import DateHelper from "@core-js/solaris/date-helper"

export default class Table extends SolarComponent {

    /**
     * @param {HTMLTableElement|string} selector - Direct `<table>` element or a CSS selector string.
     * @throws {Error} If the selector does not resolve to a valid `<table>` element.
     */
    constructor(selector) {
        super()

        if (selector instanceof HTMLTableElement) {
            this._element = selector
        } else if (Helper.isString(selector) && !Helper.isEmpty(selector)) {
            this._element = document.querySelector(selector)
            if (!this._element) {
                throw new Error(`Element with query selector ${selector} is not found`)
            }

            if (!(this._element instanceof HTMLTableElement)) {
                throw new Error(`Selector is not table element`)
            }
        } else {
            throw new Error(`Selector is not table element`)
        }

        this.id = this._element.id
        this._wrapper = document.querySelector(`#${this.id}_solar_wrapper`)

        this._preInit().then(() => {
            if (!this._wrapper.getAttribute("lazy")) {
                this.render()
            }
        })
    }

    /**
     * Returns all supported event names for this component.
     * Column events support a colon-suffix to target a specific column: e.g. `"column created:column_name"`.
     * @returns {string[]}
     */
    static supportedEvent() {
        return [
            "rendering",        // before DataTable is initialized
            "ready",            // after DataTable first init and data load
            "draw",             // after every DataTable draw
            "row created",      // when a row DOM element is created
            "row click",
            "row dblclick",     // when a row is double-clicked
            "row contextmenu",  // when a row is right-clicked
            "column render",    // cell render hook (use suffix: column render:column_name)
            "column created",   // cell created hook (use suffix: column created:column_name)
            "column click",     // cell click (use suffix: column click:column_name)
            "column dblclick",  // cell double click
            "column contextmenu", // cell right click
            "new",              // when the New button is clicked
            "deleting",         // before a row delete is attempted
            "delete",           // custom delete handler (return true[] to confirm deletion)
            "deleted",          // after a row is successfully deleted
            "view",             // when the View action button is clicked
            "edit",             // when the Edit action button is clicked
        ]
    }

    /**
     * Format a boolean value as plain text or a Bootstrap badge.
     *
     * Format string syntax:
     * - `"Yes|No"`                          → plain text
     * - `"badge@Yes|No"`                    → badge, default success/danger colors
     * - `"badge:colorTrue|colorFalse@Yes|No"` → badge with custom Bootstrap color names
     *
     * @param {*} value - Raw value (boolean, 0/1, "true"/"false", "1"/"0")
     * @param {string|null} [format=null] - Format string; defaults to "Yes|No"
     * @returns {string}
     */
    static formatBool(value, format = null) {
        const boolValue = value === true || value === 1 || value === '1' || value === 'true'
        const raw = format ?? 'Yes|No'

        if (raw.includes('@')) {
            const atIndex = raw.indexOf('@')
            const badgeConfig = raw.substring(0, atIndex)
            const [labelTrue = 'Yes', labelFalse = 'No'] = raw.substring(atIndex + 1).split('|')

            let colorTrue = 'success'
            let colorFalse = 'danger'

            if (badgeConfig.includes(':')) {
                const [colorTrue_, colorFalse_] = badgeConfig.split(':')[1].split('|')
                colorTrue = colorTrue_ ?? 'success'
                colorFalse = colorFalse_ ?? 'danger'
            }

            const color = boolValue ? colorTrue : colorFalse
            const label = boolValue ? labelTrue : labelFalse

            return `<span class="badge bg-${color}">${label}</span>`
        }

        const [labelTrue = 'Yes', labelFalse = 'No'] = raw.split('|')

        return boolValue ? labelTrue : labelFalse
    }

    /**
     * Format a numeric value based on the given format string.
     * Returns `0` when value is null or undefined.
     *
     * Format options:
     * - `null` / empty     → formatted number with 2 decimals
     * - `"readable"`       → `Helper.readableNumber(value)`
     * - `"currency"`       → IDR with `Rp` prefix, 2 decimals
     * - `"currency:USD"`   → USD with symbol prefix, 2 decimals
     *
     * @param {*} value - Raw cell value
     * @param {string|null} [format=null] - Format string
     * @param {string} [thousandSep='.'] - Thousands separator character
     * @param {string} [decimalSep=','] - Decimal separator character
     * @returns {string}
     */
    static formatNumber(value, format = null, thousandSep = '.', decimalSep = ',') {
        const num = value === null || value === undefined ? 0 : value

        if (format === 'readable') {
            return Helper.readableNumber(num)
        }

        if (format && format.startsWith('currency')) {
            const currencyCode = format.includes(':') ? format.split(':')[1].trim().toUpperCase() : 'IDR'
            const symbol = Table._getCurrencySymbol(currencyCode)
            return `${symbol} ${Helper.readableNumber(num, 2, decimalSep, thousandSep, false)}`
        }

        return Helper.readableNumber(num, 2, decimalSep, thousandSep, false)
    }

    /**
     * Resolve a currency code to its narrow display symbol.
     * Overrides IDR → 'Rp'. Falls back to Intl or the code itself.
     * @param {string} code - ISO 4217 currency code (e.g. 'USD', 'IDR')
     * @returns {string}
     */
    static _getCurrencySymbol(code) {
        const overrides = { IDR: 'Rp' }

        if (overrides[code]) {
            return overrides[code]
        }

        try {
            return new Intl.NumberFormat('en-US', {
                style: 'currency',
                currency: code,
                currencyDisplay: 'narrowSymbol'
            }).formatToParts(0).find(p => p.type === 'currency')?.value ?? code
        } catch {
            return code
        }
    }

    /**
     * Format a string value with optional case transform and/or badge wrapping.
     *
     * Format string syntax:
     * - `"uppercase"` / `"lowercase"` / `"title"` / `"camel"` / `"headline"` → case transform only
     * - `"badge"`                → badge, default `primary` color, no transform
     * - `"badge:success"`        → badge with custom Bootstrap color
     * - `"badge@uppercase"`      → badge + case transform, default `primary` color
     * - `"badge:warning@title"`  → badge with color + case transform
     *
     * @param {*} value - Raw cell value
     * @param {string|null} [format=null] - Format string
     * @returns {string}
     */
    static formatString(value, format = null) {
        const str = value == null || value === undefined ? '' : String(value)

        if (!format) {
            return str
        }

        let caseTransform = null
        let badgeColor = null

        if (format.includes('@')) {
            const atIndex = format.indexOf('@')
            const badgePart = format.substring(0, atIndex)
            caseTransform = format.substring(atIndex + 1)
            badgeColor = badgePart.includes(':') ? badgePart.split(':')[1] : 'primary'
        } else if (format.startsWith('badge')) {
            badgeColor = format.includes(':') ? format.split(':')[1] : 'primary'
        } else {
            caseTransform = format
        }

        let result = str
        if (caseTransform === 'uppercase') {
            result = str.toUpperCase()
        } else if (caseTransform === 'lowercase') {
            result = str.toLowerCase()
        } else if (caseTransform === 'title') {
            result = Helper.toTitleCase(str)
        } else if (caseTransform === 'camel') {
            result = Helper.toCamelCase(str)
        } else if (caseTransform === 'headline') {
            result = Helper.toHeadline(str)
        }

        if (badgeColor) {
            return `<span class="badge bg-${badgeColor}">${result}</span>`
        }

        return result
    }

    /**
     * Apply a quick-render transformation based on a column's field type.
     * Called internally when `field-type` is set on a column `<th>`.
     * If a manual `column render` event is also registered, it takes full control and this is ignored.
     * @param {string} type - Field type (e.g. 'datetime', 'date', 'bool', 'string')
     * @param {*} value - Raw cell value from the server
     * @param {string|null} [format=null] - Format string; falls back to type default when null
     * @returns {string}
     */
    static formatByType(type, value, format = null, thousandSep = '.', decimalSep = ',') {
        if (type === 'datetime') {
            return format ? DateHelper.formatDatetime(value, format) : DateHelper.formatDatetime(value)
        }

        if (type === 'date') {
            return format ? DateHelper.formatDate(value, format) : DateHelper.formatDate(value)
        }

        if (type === 'bool') {
            return Table.formatBool(value, format)
        }

        if (type === 'number') {
            return Table.formatNumber(value, format, thousandSep, decimalSep)
        }

        if (type === 'string') {
            return Table.formatString(value, format)
        }

        return value ?? ''
    }

    /**
     * Add a column definition to the table. Must be called before `render()`.
     * @param {{
     *   name: string,
     *   data: string,
     *   render?: Function,
     *   created?: Function,
     *   className?: string,
     *   searchable?: boolean,
     *   orderable?: boolean,
     *   width?: string|null,
     *   lookup?: boolean|string
     * }} config - Column configuration.
     *   - `name`: Column identifier (used for events and referencing).
     *   - `data`: Data property name from the row object.
     *   - `render`: Custom render function `(data, type, row, meta) => string`.
     *   - `created`: Default cell created callback `(row, cell, cellData, rowData)`. Skipped if a `column created:{name}` event is registered.
     *   - `className`: CSS class applied to each cell.
     *   - `searchable`: Whether this column participates in server-side search.
     *   - `orderable`: Whether this column participates in server-side ordering.
     *   - `width`: CSS width string (e.g. `"10%"`).
     *   - `lookup`: `true` to treat column as lookup, or a string path for nested lookup.
     * @returns {Table}
     */
    addColumn({ name, data, render, created, className = "", searchable = false, orderable = false, width = null, lookup = false }) {
        const column = {
            name: name,
            data: data ?? null,
            searchable: searchable,
            order: orderable,
            orderable: false,
            className: className,
            width: width
        }

        const isDot = data && data.split(".").length > 1
        const isLookupStr = Helper.isString(lookup) && !Helper.isEmpty(lookup)

        let isLookup = isDot || (lookup === true || isLookupStr)
        if (!isLookup && name.endsWith("_id") && (data && data === name.substring(0, name.length - 3))) {
            isLookup = true
        }

        column.lookup = isLookup ? (isLookupStr && lookup != "lookup" ? lookup : isLookup) : isLookup

        if (Helper.isFunction(render)) {
            column.render = (data, type, row, meta) => render(data, type, row, meta)
        }

        column.createdCell = async (cell, cellData, rowData, rowIndex, columnIndex) => {
            const row = cell.closest('tr')

            await this.trigger("column created", name, row, cell, cellData, rowData)
            await this.trigger("column created:" + name, row, cell, cellData, rowData)

            if (Helper.isFunction(created) && !this._events.has(`column created:${name}`)) {
                created(row, cell, cellData, rowData)
            }
        }

        this._columns.push(column)

        return this
    }

    /**
     * Initialize and render the DataTable.
     * Triggers `"rendering"` event before initialization.
     * Triggers `"ready"` event after the first data load completes.
     * Called automatically in the constructor unless the wrapper has `lazy` attribute.
     * @returns {Promise<void>}
     */
    async render() {
        this._handleColumnEvents()

        await this.trigger("rendering")

        const config = {
            layout: null,
            fixedColumns: this._fixedColumn,
            scrollX: true,
            order: this._getDefaultOrder(),
            pageLength: -1,
            deferRender: true,
            columns: this._columns,
            createdRow: (row, data, dataIndex) => {
                this.trigger("row created", row, data, dataIndex)
            },
            initComplete: async (settings, json) => {
                await this._initCallback(settings, json)
            }
        }

        if (this._vertical) {
            config.scrollY = this._vertical + "px"
        }

        this._table = new DataTable(this._element, config)
    }

    /**
     * Show or hide the table loading overlay.
     * @param {boolean} show - `true` to show loading, `false` to hide.
     * @returns {void}
     */
    loading(show) {
        if (show) {
            this._wrapper.classList.add("loading")
        } else {
            this._wrapper.classList.remove("loading")
        }
    }

    /**
     * Refresh table data from the server.
     * Removes all non-new rows, re-fetches, and redraws without resetting pagination.
     * Disables `_refreshBtn` during the operation and re-enables it after.
     * @returns {Promise<void>}
     */
    async refresh() {
        try {
            this._table.rows().every(function () {
                const data = this.data()
                if (data._state !== 'new') {
                    this.remove()
                }
            })

            const data = await this._fetchData()
            this._table.rows.add(data).draw(false)

        } catch (error) {
            console.error("Failed to refresh table data.", { error })
        }
    }

    /**
     * Clear all rows and reset all table state: pagination, sort, search, and filters.
     * @returns {void}
     */
    clear() {
        this._start = 0
        this._recordsTotal = 0
        this._recordsFiltered = 0
        this._currentPage = 1
        this._totalPage = 1
        this._currentSort = []
        this._searchValue = null
        this._filters = new Map()
        this._preFilters = this._wrapper.hasAttribute("filter") ? new Filter(this._wrapper.getAttribute("filter")) : null

        this._element.querySelectorAll("thead th.sorted").forEach(th => {
            th.classList.remove("sorted", "sorted-asc", "sorted-desc")
        })

        if (this._search) {
            this._search.set("", true)
        }

        this._setCache()

        this.clearAllSelected()
        this._table.clear().draw()
        this._pagination?.update(this._start, this._recordsTotal, this._recordsFiltered, this._currentPage, this._totalPage)
    }

    /**
     * Show or hide a column by its name.
     * @param {string} column - Column name as defined in `addColumn()`.
     * @param {boolean} visible - `true` to show, `false` to hide.
     * @returns {void}
     */
    visibleColumn(column, visible) {
        this._table.column(`${column}:name`).visible(visible)
    }

    //#region Filter and searching

    /**
     * Set the global search keyword and trigger a refresh.
     * If a `SearchInput` component is present, delegates to it; otherwise updates `_searchValue` directly.
     * @param {string} keyword - Search keyword.
     * @returns {Promise<void>}
     */
    async search(keyword) {
        if (this._search) {
            this._search.set(keyword)
        } else {
            this._searchValue = keyword
            await this.refresh()
        }
    }

    /**
     * Set a global pre-filter applied to all requests.
     * Pre-filters are always combined with column filters.
     * @param {Filter|null} [filter=null] - Filter instance, or `null` to clear.
     * @param {boolean} [refresh=true] - Whether to refresh data immediately after setting.
     * @param {boolean} [resetPage=true] - Whether to reset pagination to page 1.
     * @returns {Promise<void>}
     */
    async preFilter(filter = null, refresh = true, resetPage = true) {
        this._preFilters = filter

        if (resetPage) {
            this._start = 0
            this._setCache()
        }

        if (refresh) {
            await this.refresh()
        }
    }

    /**
     * Set or remove a named filter.
     * Multiple named filters can coexist and are combined via AND grouping.
     * @param {string} name - Unique filter identifier.
     * @param {Filter|null} [filter=null] - Filter instance, or `null` to remove the filter.
     * @param {boolean} [refresh=true] - Whether to refresh data immediately.
     * @param {boolean} [resetPage=true] - Whether to reset pagination to page 1.
     * @returns {Promise<void>}
     */
    async filter(name, filter = null, refresh = true, resetPage = true) {
        if (!this._filters.has(name)) {
            this._filters.set(name, filter)
        } else {
            if (!filter) {
                this._filters.delete(name)
            } else {
                this._filters.set(name, filter)
            }
        }

        if (resetPage) {
            this._start = 0
            this._setCache()
        }

        if (refresh) {
            await this.refresh()
        }
    }

    //#endregion

    /**
     * Register an event listener for a supported table event.
     * Column events support a colon-suffix to target a specific column: e.g. `"column created:column_name"`.
     * @param {string} type - Event type (see `supportedEvent()`).
     * @param {Function} callback - Event handler function.
     * @returns {Table}
     * @throws {Error} If the event type is not supported.
     * @throws {Error} If `callback` is not a function.
     */
    on(type, callback, name = null) {
        const typeSplit = type.split(":")
        if (!this.constructor.supportedEvent().includes(typeSplit[0])) {
            throw new Error(`Event ${type} does not support`)
        }

        if (!Helper.isFunction(callback)) {
            throw new Error(`Callback must be function`)
        }

        const handler = (...args) => callback(...args)

        if (!this._events.has(type)) {
            this._events.set(type, [{ handler, callback, name }])
            return this
        }

        const events = this._events.get(type)

        if (name) {
            const index = events.findIndex(event => event.name === name)
            if (index !== -1) {
                events[index] = { handler, callback, name }
                return this
            }
        }

        events.push({ handler, callback, name })

        return this
    }

    /**
     * Delete a single row.
     * Triggers `"deleting"` first, then either the default model delete or a custom `"delete"` event handler.
     * If deletion is confirmed, removes the row from the table and triggers `"deleted"`.
     * @param {HTMLTableRowElement} row - The row DOM element.
     * @param {Object} data - The row's data object (must contain `id`).
     * @returns {Promise<void>}
     */
    async delete(row, data) {
        try {
            row.classList.add("row-saving")

            await this.trigger("deleting", row, data)

            const model = this._parseModel.model

            let deleteAction = null
            if (!this._events.has("delete")) {
                deleteAction = await Model.delete(model, data.id, { success: "", loading: false })
            } else {
                const delTrigger = await this.trigger("delete", data)
                const isTriggerExists = delTrigger && Array.isArray(delTrigger)
                const isTriggerValid = isTriggerExists && delTrigger.every(res => typeof res === 'boolean' && res === true)

                if (isTriggerExists && isTriggerValid) {
                    deleteAction = true
                }
            }

            if (deleteAction) {
                this._table.row(row).remove()
                await this.trigger("deleted", data)
                await this.refresh()
            }

        } catch (error) {
            console.error("Something wrong happen when delete record...", { error })
        } finally {
            row?.classList.remove("row-saving")
        }
    }

    /**
     * Deselect all rows: uncheck the select-all checkbox and clear selection state.
     * @returns {void}
     */
    clearAllSelected() {
        if (this._selectAll) {
            this._selectAll.checked = false
        }

        this._isSelectAll = false
        this._handleSelectAll(false)
    }

    /**
     * Get the current selection state.
     * - `isSelectAll`: whether "select all" mode is active.
     * - `selected`: IDs of individually selected rows (when not in select-all mode).
     * - `excluded`: IDs excluded from the select-all selection.
     * @returns {{isSelectAll: boolean, selected: string[], excluded: string[]}}
     */
    getSelected() {
        return {
            isSelectAll: this._isSelectAll,
            selected: this._selected,
            excluded: this._excludeSelected
        }
    }

    /**
     * Delete all currently selected records via a batch delete API call.
     * Shows a confirmation dialog and a final type-to-confirm dialog before proceeding.
     * Displays a progress modal that listens to `BatchDeleteEvent` via Laravel Echo.
     * @returns {Promise<void>}
     */
    async deleteAllSelected() {
        const selected = this.getSelected()
        const deleteCount = selected.isSelectAll ? this._recordsFiltered - selected.excluded.length : selected.selected.length

        if (deleteCount == 0) {
            return await Helper.errorAlert({ title: "Please select at least one record" })
        }

        if (!await Helper.confirm({ title: "Delete All Confirmation", message: `You are about to delete ${deleteCount} records` })) {
            return
        }

        const finalConfirm = new Promise((resolve) => {
            const config = {
                title: 'Final Confirmation',
                html: `
					<p><strong>${deleteCount} records</strong> and their related data will be permanently deleted.</p>
					<p>Type <strong>DELETE</strong> to continue.</p>
				`,
                icon: 'error',
                input: 'text',
                showCancelButton: true,
                confirmButtonText: 'Delete',
                cancelButtonText: 'Cancel',
                confirmButtonColor: '#d33',
                preConfirm: (value) => {
                    if (value !== 'DELETE') {
                        Swal.showValidationMessage('Type DELETE exactly');
                        return false;
                    }
                    return true;
                }
            }
            Swal.fire(config).then(result => resolve(result.dismiss == "backdrop" ? undefined : (result.value ?? false)))
        })

        if (!await finalConfirm) {
            return
        }

        this._setBatchDeleteProgress(0, deleteCount, 0, 0)
        this._deleteAllModal.show()

        const req = await axios({
            method: "DELETE",
            url: `${BASE_URL}/core/form`,
            headers: {
                'X-Model': this._model
            },
            data: {
                batch_delete: true,
                select_all: selected.isSelectAll,
                selected: selected.selected,
                excluded: selected.excluded,
                filters: {
                    search: this._searchValue?.trim().toLowerCase() ?? null,
                    preFilters: this._preFilters?.get() ?? null,
                    filters: this._getFilters()?.get() ?? null,
                }
            }
        })

        const res = req.data
        this._deleteAllJobId = res.data.job_id
        this._setBatchDeleteProgress(0, res.data.delete_count, 0, 0)
    }

    /**
     * Enable the New button.
     * @returns {void}
     */
    enableNew() {
        this._newBtn?.enabled()
    }

    /**
     * Disable the New button.
     * @returns {void}
     */
    disableNew() {
        this._newBtn?.disabled()
    }

    /**
     * Show the New button.
     * @returns {void}
     */
    showNew() {
        this._newBtn?.show()
    }

    /**
     * Hide the New button.
     * @returns {void}
     */
    hideNew() {
        this._newBtn?.hidden()
    }

    /**
     * Get the current search and filter state.
     * Exposed so consumers can fetch related data with the exact same filter state.
     * @returns {{search: string|null, pre_filters: Object|null, filters: Object|null}}
     */
    getParamData() {
        return {
            search: this._searchValue?.trim().toLowerCase() ?? null,
            pre_filters: this._preFilters?.get() ?? null,
            filters: this._getFilters()?.get() ?? null,
        }
    }

    /**
     * Get total records count from last fetch.
     * @returns {number}
     */
    getRecordsTotal() {
        return this._recordsTotal
    }

    /**
     * Get filtered records count from last fetch.
     * @returns {number}
     */
    getRecordsFiltered() {
        return this._recordsFiltered
    }

    /**
     * Enable localStorage caching of table state (pagination, order, search).
     * Caching is enabled by default.
     * @returns {Table}
     */
    enableCache() {
        this._cacheEnabled = true
        return this
    }

    /**
     * Disable localStorage caching and remove any existing cached state.
     * @returns {Table}
     */
    disableCache() {
        this._cacheEnabled = false
        localStorage.removeItem(`${this.id}_table_cache`)
        return this
    }

    /**
     * Change page length and refresh.
     * @param {number} length
     * @returns {Promise<void>}
     */
    async setLength(length) {
        this._length = length
        this._start = 0
        this._setCache()
        await this.refresh()
    }

    /**
     * Change the model for subsequent requests.
     * Takes effect on the next refresh() or render().
     * @param {string} model
     * @returns {Table}
     */
    setModel(model) {
        this._model = model
        this._parseModel = Helper.parseShorthandModel(model)
        return this
    }

    /**
     * Change extend-columns for subsequent requests.
     * @param {string|null} extendColumns
     * @returns {Table}
     */
    setExtendColumns(extendColumns) {
        this._extendColumns = extendColumns
        return this
    }

    /**
     * Change pre-orders for subsequent requests.
     * @param {string|{name: string, dir: string}[]} preOrders
     * @returns {Table}
     */
    setPreOrders(preOrders) {
        if (typeof preOrders === 'string') {
            this._preOrders = this._parseOrderBy(preOrders)
        } else {
            this._preOrders = preOrders ?? []
        }
        return this
    }

    /**
     * Get all current row data objects displayed in the table.
     * @returns {Array<Object>}
     */
    getData() {
        return this._table.rows().data().toArray()
    }

    /**
     * @returns {void}
     */
    destroy() {
        this._table?.destroy(false)
        this._events = new Map()
        this._table  = null
    }

    /**
     * Programmatically open the export modal.
     * Only works if export prop is enabled in the blade component.
     * @returns {Promise<void>}
     */
    async showExportModal() {
        await this._exportTable?.showModal()
    }

    /**
     * Programmatically open the import modal.
     * Only works if import prop is enabled in the blade component.
     * @returns {Promise<void>}
     */
    async showImportModal() {
        await this._importTable?.showModal()
    }

    /**
     * Toggle the multiple-select column visibility.
     * Also clears any existing selections before toggling.
     * @returns {void}
     */
    toggleMultipleSelect() {
        this.toogleMultipleSelect()
    }

    /**
     * Toggle the multiple-select column visibility.
     * Also clears any existing selections before toggling.
     * @returns {void}
     */
    toogleMultipleSelect() {
        this.clearAllSelected()

        const column = this._table.column(0)
        column.visible(!column.visible())
    }

    /**
     * Update batch delete progress modal UI.
     * When `percent` reaches 100, switches the modal to a "completed" state.
     * @param {number} percent - Completion percentage (0–100).
     * @param {number} estimated - Total number of records to delete.
     * @param {number} deleted - Number of records successfully deleted.
     * @param {number} failed - Number of records that failed to delete.
     * @returns {void}
     */
    _setBatchDeleteProgress(percent, estimated, deleted, failed) {
        const element = this._deleteAllModal._element

        element.querySelector('.batch-delete-percent').textContent = `${percent}%`
        element.querySelector('.batch-delete-progress').style.width = `${percent}%`
        element.querySelector('.batch-delete-estimated').textContent = `${estimated}`
        element.querySelector('.batch-delete-deleted').textContent = `${deleted}`
        element.querySelector('.batch-delete-failed').textContent = `${failed}`

        if (percent == 100) {
            element.querySelector('.loading-icon').classList.add('d-none')
            element.querySelector('.success-icon').classList.remove('d-none')
            element.querySelector('.modal-title').textContent = "Delete All Completed"
            element.querySelector('.modal-subtitle').classList.add("d-none")
            element.querySelector('.modal-message span').textContent = ""
            element.querySelector('.modal-message button').removeAttribute("hidden")
        }
    }

    /**
     * Reset the batch delete progress modal back to its initial state.
     * @returns {void}
     */
    _resetBatchDeleteProgress() {
        const element = this._deleteAllModal._element

        element.querySelector('.batch-delete-percent').textContent = "0%"
        element.querySelector('.batch-delete-progress').style.width = "0%"
        element.querySelector('.batch-delete-estimated').textContent = "0"
        element.querySelector('.batch-delete-deleted').textContent = "0"
        element.querySelector('.batch-delete-failed').textContent = "0"

        element.querySelector('.loading-icon').classList.remove('d-none')
        element.querySelector('.success-icon').classList.add('d-none')
        element.querySelector('.modal-title').textContent = "Deleting Records..."
        element.querySelector('.modal-subtitle').classList.remove("d-none")
        element.querySelector('.modal-message span').textContent = "Do not close this window"
        element.querySelector('.modal-message button').setAttribute("hidden", "hidden")
    }

    /**
     * Pre-initialization: reads all wrapper attributes and sets up internal state.
     * Initializes columns, pagination, search, action buttons, and folder if present.
     * Called automatically in the constructor before `render()`.
     * @returns {void}
     */
    async _preInit() {
        this._model = this._wrapper.getAttribute("model")
        this._parseModel = Helper.parseShorthandModel(this._model)
        this._columns = []
        this._headers = []
        this._currentSort = []

        this._selectAllVisible = true
        this._selected = []
        this._excludeSelected = []
        this._isSelectAll = false
        this._selectedInfo = document.querySelector(`#${this.id}_table_selected`)

        const selectedAction = document.querySelector(`#${this.id}_table_selected_action`)
        if (selectedAction) {
            this._selectedAction = new Button(selectedAction)
        }

        this._initColumns()

        this._cacheEnabled = true
        const cache = JSON.parse(localStorage.getItem(`${this.id}_table_cache`))
        if (cache) {
            this._page = 1
            this._start = cache.start ?? 0
            this._currentSort = cache.order ?? []
            this._searchValue = cache.search ?? null
            this._folderSelected = cache.folder ?? null
        } else {
            this._page = 1
            this._start = 0
        }

        this._vertical = this._wrapper.getAttribute("vertical")

        this._length = this._wrapper.hasAttribute("length") ? parseInt(this._wrapper.getAttribute("length")) : 10
        this._currentPage = 1
        this._totalPage = 1
        this._recordsTotal = 0
        this._recordsFiltered = 0

        this._fixedColumn = this._wrapper.hasAttribute("fixed-column")

        this._filters = new Map()
        this._preFilters = this._wrapper.hasAttribute("filter") ? new Filter(this._wrapper.getAttribute("filter")) : null

        this._extendColumns = this._wrapper.getAttribute("extend-columns")
        this._extendSearch = this._wrapper.getAttribute("extend-search")

        const orderByAttr = this._wrapper.getAttribute("order-by")
        this._preOrders = orderByAttr ? this._parseOrderBy(orderByAttr) : []

        const newButton = document.querySelector(`#${this.id}_table_new`)
        if (newButton) {
            this._newBtn = new Button(newButton)
        }

        const folderButton = document.querySelector(`#${this.id}_table_folder`)
        if (folderButton) {
            this._folder = new Folder(`${this.id}_table_folder`, this._parseModel.model)
            this._folder.on("change", async (folderId, filter, isSilent) => await this._handleFolder(folderId, filter, !isSilent))
        }

        const exportActionEl = this._wrapper.querySelector('.export-action')
        if (exportActionEl) {
            this._exportTable = new ExportTable(this)
        }

        const importActionEl = this._wrapper.querySelector('.import-action')
        if (importActionEl) {
            this._importTable = new ImportTable(this)
        }

        const refreshBtn = document.querySelector(`#${this.id}_table_refresh`)
        if (refreshBtn) {
            this._refreshBtn = new Button(refreshBtn)
        }

        const searchField = document.querySelector(`#${this.id}_table_search`)
        if (!this._searchValue) {
            this._searchValue = null
        }
        if (searchField) {
            this._search = new SearchInput(searchField)
            if (this._searchValue) {
                this._search.set(this._searchValue, true)
                this._search._resetIcon.classList.remove("d-none")
            }
        }

        this._mode = this._wrapper.getAttribute("solar-ui")?.split(":")[1] ?? "simple"

        const pagination = document.querySelector(`#${this.id}_table_pagination`)
        if (pagination) {
            this._pagination = new Paginator(pagination, this._length)
            this._pagination.on("change", async (page) => await this._handlePagination(page))
        }

        this._restoreCachedOrder()
    }

    /**
     * Parse all `<th>` column headers from the table's `<thead>` and call `addColumn()` for each.
     * Handles special columns: `_action`, `_autoincrement`, `_selectall`.
     * Automatically injects a hidden `_selectall` column if one is not defined in the markup.
     * @returns {void}
     */
    _initColumns() {
        const orderedTh = this._getOrderedColumnHeader()
        orderedTh.forEach((th) => {
            const name = th.getAttribute("field-name")
            const data = th.getAttribute("field-data")
            const orderable = th.hasAttribute("order")
            // `searchable` can be absent (not searchable), "searchable"/"true" (boolean-style attr,
            // model's own $searchColumns mode applies), or a Filter::OperatorType key like
            // "FullText"/"Contains" that overrides the model's default mode for this column.
            const searchableAttr = th.getAttribute("searchable")
            const searchable = searchableAttr === null
                ? false
                : (searchableAttr === "searchable" || searchableAttr === "true" || searchableAttr === "" ? true : searchableAttr)
            const width = th.getAttribute("width")
            const className = th.getAttribute("cell-class")
            const isLookup = th.hasAttribute("lookup")
            const fieldType   = th.getAttribute("field-type")
            const fieldFormat = th.getAttribute("field-format")
            const fieldExpand = th.getAttribute("field-expand")
            const decimalSep  = th.getAttribute("field-decimal-separator") ?? ','
            const thousandSep = th.getAttribute("field-thousand-separator") ?? '.'
            const prefix      = th.getAttribute("field-prefix") ?? null

            if (th.classList.contains("orderable")) {
                this._handleSort(name, th)
            }

            let column = {
                name: name,
                data: data,
                className: className,
                orderable: orderable,
                searchable: searchable,
                width: width,
                lookup: isLookup ? th.getAttribute("lookup") : false
            }

            if (name === '_action') {
                column = this._registerActionColumn(th, column)
            } else if (name === '_autoincrement') {
                column = this._registerAutoincrementColumn(th, column)
            } else if (name === '_selectall') {
                column = this._registerSelectAllColumn(th, column)
            }

            if ((fieldType || fieldFormat || prefix) && !name.startsWith('_')) {
                column.render = (data) => {
                    const type = fieldType ?? (fieldFormat ? 'string' : null)
                    const rendered = type
                        ? Table.formatByType(type, data, fieldFormat, thousandSep, decimalSep)
                        : (data ?? '')
                    return prefix ? `${prefix}${rendered}` : rendered
                }
            }

            if (fieldExpand && !name.startsWith('_')) {
                const existingRender = column.render
                column.render = (data, type, row, meta) => {
                    const value = existingRender ? existingRender(data, type, row, meta) : (data ?? '')
                    return `<span class="d-inline-block text-truncate align-middle" title="Click to expand" style="max-width: ${fieldExpand};">${value}</span>`
                }
                column.created = (row, cell) => {
                    const span = cell.querySelector('span.text-truncate')
                    span?.addEventListener('click', () => {
                        span.classList.toggle('d-inline-block')
                        span.classList.toggle('text-truncate')
                    })
                }
            }

            this.addColumn(column)

            if (name === '_action') {
                const actionIndex = this._columns.length - 1
                this._columns[actionIndex].view = column.view
                this._columns[actionIndex].edit = column.edit
                this._columns[actionIndex].delete = column.delete
            }
        })
    }

    /**
     * Configure a column as the action column (`_action`).
     * Reads action type attributes from the `<th>` and sets up the render function.
     * @param {HTMLTableCellElement} th - The `<th>` element for the action column.
     * @param {Object} column - The base column config object to configure.
     * @returns {Object} The configured action column object.
     */
    _registerActionColumn(th, column) {
        const actionView = th.hasAttribute("action-view")
        const actionEdit = th.hasAttribute("action-edit")
        const actionDelete = th.hasAttribute("action-delete")
        const actionDiscard = th.hasAttribute("action-discard")
        const actionGroup = th.hasAttribute("action-group")

        column.searchable = false
        column.orderable = false
        column.className = "text-center"
        column.view = actionView
        column.edit = actionEdit
        column.delete = actionDelete
        column.discard = actionDiscard
        column.width = "5%"

        column.render = (data, type, rowData, meta) => this._renderColumnAction({ data, rowData, view: actionView, edit: actionEdit, remove: actionDelete, discard: actionDiscard, group: actionGroup })

        return column
    }

    /**
     * Configure a column as the auto-increment row number column (`_autoincrement`).
     * Renders the current row number based on pagination offset.
     * @param {HTMLTableCellElement} th - The `<th>` element for this column.
     * @param {Object} column - The base column config object to configure.
     * @returns {Object} The configured autoincrement column object.
     */
    _registerAutoincrementColumn(th, column) {
        column.searchable = false
        column.orderable = false
        column.width = "3%"
        column.render = (data, type, rowData, meta) => (this._start + meta.row) + 1

        return column
    }

    /**
     * Configure a column as the select-all checkbox column (`_selectall`).
     * Renders a checkbox input in each row cell.
     * @param {HTMLTableCellElement} th - The `<th>` element for this column.
     * @param {Object} column - The base column config object to configure.
     * @returns {Object} The configured select-all column object.
     */
    _registerSelectAllColumn(th, column) {
        column.searchable = false
        column.orderable = false
        column.width = "3%"
        column.render = (data, type, rowData, meta) => `<input class="form-check-input check" type="checkbox">`

        return column
    }

    /**
     * Parse the `<thead>` to produce an ordered, flat list of leaf-level `<th>` elements.
     * Handles `colspan` and `rowspan` attributes correctly via a 2D grid algorithm.
     * Automatically injects a hidden `_selectall` `<th>` if not present.
     * @returns {HTMLTableCellElement[]} Ordered array of leaf-level `<th>` elements for the last header row.
     */
    _getOrderedColumnHeader() {
        const thead = this._element.querySelector("thead")
        const rows = thead.querySelectorAll("tr")

        const depth = rows.length
        const grid = Array.from({ length: depth }, () => [])

        const hasSelectAll = Array.from(rows)
            .some(tr =>
                Array.from(tr.querySelectorAll("th"))
                    .some(th => th.getAttribute("field-name") === "_selectall")
            )

        if (!hasSelectAll) {
            const selectAllTh = document.createElement("th")
            selectAllTh.setAttribute("field-name", "_selectall")
            selectAllTh.setAttribute("rowspan", depth)
            selectAllTh.innerHTML = `<input class="form-check-input check-all" type="checkbox">`

            rows[0].insertBefore(selectAllTh, rows[0].firstChild)

            this._selectAllVisible = false
        }

        rows.forEach((tr, rIndex) => {
            let colIndex = 0
            tr.querySelectorAll("th").forEach(th => {
                const colspan = parseInt(th.getAttribute("colspan") || 1)
                const rowspan = parseInt(th.getAttribute("rowspan") || 1)

                while (grid[rIndex][colIndex]) {
                    colIndex++
                }

                for (let rr = 0; rr < rowspan; rr++) {
                    for (let cc = 0; cc < colspan; cc++) {
                        grid[rIndex + rr][colIndex + cc] = th
                    }
                }

                colIndex += colspan
            })
        })

        return grid[depth - 1].filter(Boolean)
    }

    /**
     * Called by DataTable's `initComplete` callback.
     * Fetches initial data, sets up action buttons, checked state, dropdowns, and row events.
     * Triggers the `"ready"` event after setup.
     * @param {Object} settings - DataTables settings object.
     * @param {Object} json - DataTables initial JSON data (unused; data is fetched separately).
     * @returns {Promise<void>}
     */
    async _initCallback(settings, json) {
        if(this._folder && this._folderSelected) {
            await this._folder.apply(this._folderSelected, true)
        }

        const data = await this._fetchData()
        this._table.clear().rows.add(data).draw()

        this._handleActionButtons()
        this._handleActionChecked()
        this._handleActionDropdown()

        if (!this._selectAllVisible) {
            this.visibleColumn("_selectall", false)
        }

        await this.trigger("ready", settings, json)

        this._table.on("draw", async (e, settings) => {
            this._handleChecked()
            this._handleAutoIncrement()
            this._handleActionDropdown()

            await this.trigger("draw", e, settings)
        })

        this._handleRowEvents()
        this._handleRowActionButtons()
    }

    /**
     * Attach row-level click, double-click, and context-menu event listeners.
     * Triggers the corresponding `"row click"`, `"row dblclick"`, `"row contextmenu"` events.
     * @returns {void}
     */
    _handleRowEvents() {
        this._table.on("click", `tbody tr`, async (e) => {
            const row = e.target.closest('tr')
            const data = this._table.row(row).data()

            this.trigger("row click", row, data)
        })

        this._table.on("dblclick", `tbody tr`, async (e) => {
            const row = e.target.closest('tr')
            const data = this._table.row(row).data()

            this.trigger("row dblclick", row, data)
        })

        this._table.on("contextmenu", `tbody tr`, async (e) => {
            e.preventDefault()

            const row = e.target.closest('tr')
            const data = this._table.row(row).data()

            this.trigger("row contextmenu", row, data)
        })
    }

    /**
     * Attach a click listener to a sortable column header `<th>`.
     * Cycles through: no sort → asc → desc → no sort.
     * Debounces the refresh call by 500ms to avoid rapid re-fetches.
     * @param {string} name - Column name identifier.
     * @param {HTMLTableCellElement} th - The `<th>` element to attach the listener to.
     * @returns {void}
     */
    _handleSort(name, th) {
        const debounceSort = Helper.debounce(async () => await this.refresh(), 500)
        th.addEventListener("click", () => {
            const sortIndex = this._currentSort.findIndex(sort => sort.name == name)
            const currentSort = sortIndex != -1 ? this._currentSort[sortIndex] : null
            const isSorted = currentSort && !Helper.isEmpty(currentSort.dir) ? true : false
            const dir = isSorted ? (currentSort.dir === "asc" ? "desc" : "") : "asc"

            if (!currentSort) {
                this._currentSort.push({ name: name, dir: dir })
            } else if (isSorted) {
                currentSort.dir = dir
            }

            th.classList.remove("sorted", "sorted-asc", "sorted-desc")

            if (!Helper.isEmpty(dir)) {
                th.classList.add("sorted", "sorted-" + dir)
            } else {
                this._currentSort.splice(sortIndex, 1)
            }

            debounceSort()
        })
    }

    /**
     * Bind action buttons in the table toolbar: New, Refresh, Search, Select All, Delete All Selected.
     * Sets up Laravel Echo listener for batch delete progress updates if applicable.
     * @returns {void}
     */
    _handleActionButtons() {
        if (this._newBtn) {
            this._newBtn.enabled()
            this._newBtn.on("click", async () => await this._onNew())
        }

        const multipleSelect = this._wrapper.querySelector('.select-all-action')
        if (multipleSelect) {
            multipleSelect.addEventListener('click', (e) => this.toogleMultipleSelect())
        }

        const importAction = this._wrapper.querySelector('.import-action')
        if (importAction) {
            importAction.addEventListener('click', async () => await this._importTable.showModal())
        }

        const exportAction = this._wrapper.querySelector('.export-action')
        if (exportAction) {
            exportAction.addEventListener('click', async () => await this._exportTable.showModal())
        }

        if (this._selectedAction) {
            this._selectedAction.enabled()

            this._clearAllSelected = this._wrapper.querySelector('.clear-all-selected-action')
            this._clearAllSelected?.addEventListener('click', (e) => this.clearAllSelected())

            this._deleteAllSelected = this._wrapper.querySelector('.delete-all-selected-action')
            if (this._deleteAllSelected) {
                this._deleteAllJobId = null

                this._deleteAllModal = new Modal(document.querySelector(`#${this.id}_table_batch_delete_modal`))
                this._deleteAllModal.on("hide", () => {
                    this._deleteAllJobId = null
                    this._resetBatchDeleteProgress()
                })

                this._deleteAllSelected.addEventListener('click', async (e) => await this.deleteAllSelected())
                Echo.private(`batch-delete.${USER_ID}`)
                    .listen(".BatchDeleteEvent", async (event) => {
                        if (event.job_id == this._deleteAllJobId) {
                            this._setBatchDeleteProgress(event.percent, event.estimated, event.deleted, event.failed)
                            if (event.percent == 100) {
                                await this.refresh()
                            }
                        }
                    })
            }
        }

        if (this._refreshBtn) {
            this._refreshBtn.enabled()
            this._refreshBtn.on("click", async () => {
                this._refreshBtn.disabled()
                await this.refresh()
                setTimeout(() => this._refreshBtn.enabled(), 2000)
            })
        }

        if (this._search) {
            this._search.enabled()
            this._search.on("search", async (keyword) => {
                this._searchValue = keyword
                this._search.disabled()

                await this.refresh()

                this._search.enabled()
                this._search._element.focus()
            })
        }
    }

    /**
     * Update the auto-increment column's cell values after each draw
     * to reflect the correct row numbers based on the current pagination offset.
     * @returns {void}
     */
    _handleAutoIncrement() {
        const columnIndex = this._columns.findIndex(col => col.name == "_autoincrement")
        if (columnIndex == -1) {
            return
        }

        this._table.column(columnIndex, { search: 'applied', order: 'applied' })
            .nodes()
            .each((cell, i) => {
                let no = i + 1
                cell.innerHTML = this._start + no
            })
    }

    /**
     * Sync checkbox states in all visible rows based on current selection state.
     * Called on every DataTable draw.
     * @returns {void}
     */
    _handleChecked() {
        if (!this._selectAll) {
            return
        }

        if (this._isSelectAll && this._recordsFiltered == 0) {
            this.clearAllSelected()
        } else if (this._isSelectAll) {
            this._handleSelectAll(true)
        } else {
            const checkboxes = document.querySelectorAll(`#${this._element.id}_wrapper .dt-scroll-body input[type="checkbox"].check`)
            checkboxes.forEach((checkbox) => {
                const row = checkbox.closest('tr')
                const data = this._table.row(row).data()

                checkbox.checked = this._selected.find(s => s == data.id) ? true : false
            })
        }
    }

    /**
     * Bind the select-all header checkbox and individual row checkboxes.
     * Manages `_selected` and `_excludeSelected` arrays based on user interaction.
     * Updates the selection info label and controls `_selectedAction` visibility.
     * @returns {void}
     */
    _handleActionChecked() {
        this._selectAll = document.querySelector(`#${this._element.id}_wrapper .dt-scroll-head input[type="checkbox"].check-all`)
        if (!this._selectAll) {
            return
        }

        // select all
        this._selectAll.addEventListener("click", (e) => {
            const checkbox = e.target
            const checked = checkbox.checked
            this._isSelectAll = checked

            this._handleSelectAll(checked)
        })

        // select one
        this._table.on("click", `tbody tr td input[type="checkbox"].check`, (e) => {
            const checkbox = e.target
            const checked = checkbox.checked
            const row = checkbox.closest('tr')
            const data = this._table.row(row).data()
            const index = this._selected.findIndex(s => s == data.id)

            if (checked) {
                row.classList.add("table-active")

                if (this._isSelectAll) {
                    const excludeIndex = this._excludeSelected.findIndex(s => s == data.id)
                    this._excludeSelected.splice(excludeIndex, 1)
                } else {
                    this._selected.push(data.id)
                }
            } else {
                row.classList.remove("table-active")

                if (this._isSelectAll) {
                    this._excludeSelected.push(data.id)
                } else {
                    this._selected.splice(index, 1)
                }
            }

            this._selectedAction.show()

            if (this._isSelectAll) {
                this._selectedInfo.textContent = `${this._recordsFiltered - this._excludeSelected.length} record selected`
            } else if (this._selected.length > 0) {
                this._selectedInfo.textContent = `${this._selected.length} record selected`
            } else {
                this._selectedAction.hidden()
                this._selectedInfo.textContent = ""
            }
        })
    }

    /**
     * Apply the select-all or deselect-all state to all visible row checkboxes.
     * Respects excluded IDs when `checked` is `true`.
     * @param {boolean} checked - `true` to select all, `false` to deselect all.
     * @returns {void}
     */
    _handleSelectAll(checked) {
        const checkboxes = document.querySelectorAll(`#${this._element.id}_wrapper .dt-scroll-body input[type="checkbox"].check`)
        checkboxes.forEach((checkbox) => {
            const row = checkbox.closest('tr')
            const data = this._table.row(row).data()

            checkbox.checked = checked

            const unselected = this._excludeSelected.find(s => s == data.id)
            if (checked && unselected) {
                checkbox.checked = false
                row.classList.remove("table-active")
            } else if (checked && !unselected) {
                row.classList.add("table-active")
            } else {
                row.classList.remove("table-active")
            }
        })

        this._selected = []

        if (checked) {
            this._selectedAction.show()
            this._selectedInfo.textContent = `${this._recordsFiltered - this._excludeSelected.length} record selected`
        } else {
            this._excludeSelected = []
            this._selectedAction.hidden()
            this._selectedInfo.textContent = ''
        }
    }

    /**
     * Re-initialize dropdown positioning for all action dropdowns in the table body.
     * Called after each DataTable draw to handle newly rendered rows.
     * @returns {void}
     */
    _handleActionDropdown() {
        const tableBody = document.querySelector(`#${this._element.id}_wrapper .dt-scroll-body`)
        const dropdowns = document.querySelectorAll(`#${this._element.id}_wrapper table .dropdown`)

        dropdowns?.forEach(el => this._handleDropdown(el, tableBody))
    }

    /**
     * Add dynamic padding to the table body when a dropdown opens
     * to prevent the dropdown from being clipped by the scroll container.
     * @param {HTMLElement} dropdown - The dropdown wrapper element.
     * @param {HTMLElement} tableBody - The table scroll body element.
     * @returns {void}
     */
    _handleDropdown(dropdown, tableBody) {
        dropdown.addEventListener('show.bs.dropdown', (event) => {
            const dropdownItem = dropdown.querySelector('ul')

            let tableHeight = getComputedStyle(tableBody, null).height
            tableHeight = parseFloat(tableHeight.substring(0, tableHeight.length - 2))

            const dropdownHeight = 40 * (dropdownItem.children.length) + 70
            if (dropdownHeight > tableHeight) {
                tableBody.style.paddingBottom = dropdownHeight + 'px'
            }
        })

        dropdown.addEventListener('hide.bs.dropdown', (event) => tableBody.style.paddingBottom = "")
    }

    /**
     * Bind click listeners to per-row action buttons (view, edit, delete).
     * Only binds buttons that are enabled in the `_action` column configuration.
     * @returns {void}
     */
    _handleRowActionButtons() {
        const rowAction = this._columns.find(col => col.name == "_action")
        if (!rowAction) {
            return
        }

        const actions = [
            rowAction?.view ? "view" : null,
            rowAction?.edit ? "edit" : null,
            rowAction?.delete ? "delete" : null,
        ]
        actions.filter(act => act)
            .forEach(act => {
                this._table.on("click", `tbody tr td .${act}-action`, async (e) => {
                    const row = e.target.closest('tr')
                    const data = this._table.row(row).data()

                    if (act == "delete") {
                        await this.delete(row, data)
                    } else {
                        this.trigger(act, row, data)
                    }
                })
            })
    }

    /**
     * Inject column-level event listeners (`column click`, `column dblclick`, etc.)
     * and column render overrides registered via `on()` into each column's `createdCell` callback.
     * Called before DataTable initialization in `render()`.
     * @returns {void}
     */
    _handleColumnEvents() {
        const columnEvents = []
        this._events.forEach((value, key) => {
            if (key.startsWith("column")) {
                columnEvents.push(key)
            }
        })

        if (columnEvents.length == 0) {
            return
        }

        this._columns = this._columns.map(column => {
            const name = column.name
            const originalCreated = column.createdCell

            if (this._events.has(`column render:${name}`)) {
                const renderCallback = this._events.get(`column render:${name}`)
                column.render = (data, type, row, meta) => renderCallback[renderCallback.length - 1].handler(data, row)
            }

            column.createdCell = async (cell, cellData, rowData, rowIndex, columnIndex) => {
                const row = cell.closest("tr")

                if (Helper.isFunction(originalCreated)) {
                    await originalCreated(cell, cellData, rowData, rowIndex, columnIndex)
                }

                columnEvents
                    .filter(e => !e.includes("column render") && !e.includes("column created"))
                    .forEach(e => {
                        const [, eventSpec] = e.split(" ", 2)
                        const [domEvent, targetColumn] = eventSpec.split(":")

                        cell.addEventListener(domEvent, async (ev) => {
                            if (!targetColumn) {
                                await this.trigger(e, name, row, cell, cellData, rowData)
                            }

                            if (targetColumn === name) {
                                await this.trigger(e, row, cell, cellData, rowData)
                            }
                        })
                    })
            }

            return column
        })
    }

    /**
     * Handle pagination page change: recalculate `_start` offset, persist to cache, and refresh.
     * @param {number} page - The new page number (1-indexed).
     * @returns {Promise<void>}
     */
    async _handlePagination(page) {
        this._start = (page - 1) * this._length
        this._setCache()

        await this.refresh()
    }

    /**
     * @param {?string} folderId 
     * @param {?Filter} filter 
     * @param {boolean} isRefresh 
     */
    async _handleFolder(folderId, filter, isRefresh) {
        this._folderSelected = folderId
        this._setCache()

        await this.filter("folder", filter, isRefresh)
    }

    /**
     * Render the action column cell HTML.
     * Supports grouped (dropdown) or ungrouped (inline buttons) layouts.
     * @param {{
     *   data: *,
     *   rowData: Object,
     *   view?: boolean,
     *   edit?: boolean,
     *   remove?: boolean,
     *   discard?: boolean,
     *   group?: boolean
     * }} config
     * @returns {string} HTML string for the action cell.
     */
    _renderColumnAction({ data, rowData, view = true, edit = true, remove = true, discard = false, group = true }) {
        if (group) {
            return `<div class="dropdown button-action">
				<button type="button" class="btn btn-sm btn-light" data-bs-toggle="dropdown" aria-expanded="false"><i class="ri-more-fill"></i></button>
				<ul class="dropdown-menu">
					${view ? this._getViewBtn(true) : ''}
					${edit ? this._getEditBtn(true) : ''}
					${discard ? this._getDiscardBtn(true) : ''}
					${remove ? this._getDeleteBtn(true) : ''}
				</ul>
			</div>`
        }

        return `<div class="d-flex justify-content-center align-items-center gap-1 button-action">
			${view ? this._getViewBtn() : ''}
			${edit ? this._getEditBtn() : ''}
			${discard ? this._getDiscardBtn() : ''}
			${remove ? this._getDeleteBtn() : ''}
		</div>`
    }

    /**
     * Render the View action button HTML.
     * @param {boolean} [group=false] - If `true`, renders as a dropdown item; otherwise as an icon button.
     * @returns {string} HTML string.
     */
    _getViewBtn(group = false) {
        if (group) {
            return `<li><a class="dropdown-item view-action" href="javascript:void(0);"><i class="ri-eye-line me-1"></i>View</a></li>`
        }

        return `<button title="View" class="btn btn-info btn-wave btn-icon btn-sm view-action"><i class="ri-eye-line"></i></button>`
    }

    /**
     * Render the Edit action button HTML.
     * @param {boolean} [group=false] - If `true`, renders as a dropdown item; otherwise as an icon button.
     * @returns {string} HTML string.
     */
    _getEditBtn(group = false) {
        if (group) {
            return `<li><a class="dropdown-item edit-action" href="javascript:void(0);"><i class="ri-pencil-line me-1"></i>Edit</a></li>`
        }

        return `<button title="Edit" class="btn btn-success btn-wave btn-icon btn-sm edit-action"><i class="ri-pencil-line"></i></button>`
    }

    /**
     * Render the Discard action button HTML.
     * @param {boolean} [group=false] - If `true`, renders as a dropdown item; otherwise as an icon button.
     * @returns {string} HTML string.
     */
    _getDiscardBtn(group = false) {
        if (group) {
            return `<li><a class="dropdown-item discard-action" href="javascript:void(0);"><i class="ri-close-line me-1"></i>Discard</a></li>`
        }

        return `<button title="Discard changes" class="btn btn-warning btn-wave btn-icon btn-sm discard-action"><i class="ri-close-line"></i></button>`
    }

    /**
     * Render the Delete action button HTML.
     * @param {boolean} [group=false] - If `true`, renders as a dropdown item; otherwise as an icon button.
     * @returns {string} HTML string.
     */
    _getDeleteBtn(group = false) {
        if (group) {
            return `<li><a class="dropdown-item text-danger delete-action" href="javascript:void(0);"><i class="ri-delete-bin-fill me-1"></i>Delete</a></li>`
        }

        return `<button title="Delete" class="btn btn-danger btn-wave btn-icon btn-sm delete-action"><i class="ri-delete-bin-fill"></i></button>`
    }

    /**
     * Internal handler for the New button click.
     * Triggers the `"new"` event.
     * @returns {Promise<*>}
     */
    async _onNew() {
        return await this.trigger("new")
    }

    /**
     * Fetch table data from the server using current pagination, search, filter, and sort state.
     * Updates `_recordsTotal`, `_recordsFiltered`, `_currentPage`, `_totalPage`, and the paginator.
     * @returns {Promise<Array<Object>>} Normalized array of row data objects.
     */
    async _fetchData() {
        try {
            this.loading(true)

            const req = await axios({
                method: "POST",
                url: `${BASE_URL}/core/datatable`,
                data: this._getParamData(),
                headers: {
                    'X-Model'    : this._model,
                    'X-Timezone' : Intl.DateTimeFormat().resolvedOptions().timeZone,
                }
            })

            const res = req.data
            this._recordsTotal = res.recordsTotal
            this._recordsFiltered = res.recordsFiltered

            let currentPage = Math.floor(this._start / this._length) + 1
            let totalPage = Math.ceil(this._recordsFiltered / this._length) || 1

            if (currentPage > totalPage) {
                currentPage = totalPage
                this._start = (currentPage - 1) * this._length
            }

            this._setCache()

            this._currentPage = currentPage
            this._totalPage = totalPage
            this._pagination?.update(this._start, this._recordsTotal, this._recordsFiltered, this._currentPage, this._totalPage)

            return this._normalizeFetchData(res.data)
        } catch (error) {
            console.error("Failed to fetch data:", { error })
            return { data: [], recordsTotal: 0, recordsFiltered: 0 }
        } finally {
            this.loading(false)
        }
    }

    /**
     * Normalize raw server data by adding `_state` and `_oldValue` tracking fields.
     * `_state` is set to `'clean'` for server-fetched rows.
     * `_oldValue` stores a snapshot of the original data for change tracking.
     * @param {Array<Object>} data - Raw array of row objects from the server.
     * @returns {Array<Object>} Normalized row data array.
     */
    _normalizeFetchData(data) {
        return data.map(d => ({
            ...d,
            _state: 'clean',
            _oldValue: { ...d }
        }))
    }

    /**
     * Returns the default DataTable column order configuration.
     * Override to specify a default sort.
     * @returns {Array} DataTables `order` config array.
     */
    _getDefaultOrder() {
        return []
    }

    /**
     * Build the request body for the `/core/datatable` API endpoint.
     * @returns {{
     *   columns: Array<{name: string, data: string, searchable: boolean, orderable: boolean, lookup: boolean|string}>,
     *   start: number,
     *   length: number,
     *   extendColumns: string|null,
     *   extendSearch: string|null,
     *   order: Array<{name: string, dir: string}>,
     *   search: string|null,
     *   preFilters: Object|null,
     *   filters: Object|null
     * }}
     */
    _getParamData() {
        return {
            columns: this._getColumnsParam(),
            start: this._start,
            length: this._length,
            extendColumns: this._extendColumns,
            extendSearch: this._extendSearch ?? null,
            order: this._currentSort,
            preOrders: this._preOrders?.length > 0 ? this._preOrders : null,
            search: this._searchValue?.trim().toLowerCase() ?? null,
            preFilters: this._preFilters?.get() ?? [],
            filters: this._getFilters()?.get() ?? [],
        }
    }

    /**
     * @param {string} raw
     * @returns {{name: string, dir: string}[]}
     */
    _parseOrderBy(raw) {
        let items
        try {
            const parsed = JSON.parse(raw)
            items = Array.isArray(parsed) ? parsed : [raw]
        } catch {
            items = raw.split(',').map(s => s.trim()).filter(Boolean)
        }

        return items.map(item => {
            const [name, dir = 'asc'] = item.split(':').map(s => s.trim())
            return { name, dir }
        })
    }

    /**
     * Build the column definitions array to send to the server.
     * Filters out special columns (those whose name starts with `_`) and columns with no data field.
     * @returns {Array<{name: string, data: string, searchable: boolean, orderable: boolean, lookup: boolean|string}>}
     */
    _getColumnsParam() {
        return this._columns
            .filter(col => col.data && !col.name.startsWith("_"))
            .map(col => {
                return {
                    name: col.name,
                    data: col.data,
                    searchable: col.searchable,
                    orderable: col.order,
                    lookup: col.lookup
                }
            })
    }

    /**
     * Merge all named filters into a single combined `Filter` object for the request.
     * Skips empty filters. Returns `null` if no filters are set.
     * @returns {Filter|null}
     */
    _getFilters() {
        if (this._filters.size === 0) {
            return null
        }

        const filters = new Filter()
        this._filters.forEach((filter, key) => {
            if (filter && !filter.isEmpty()) {
                filters.group(() => filter)
            }
        })

        return filters
    }

    /**
     * Persist current table state (pagination, order, search) to localStorage
     * so it can be restored on the next page load.
     * @returns {void}
     */
    _setCache() {
        if (!this._cacheEnabled) {
            return
        }

        localStorage.setItem(`${this.id}_table_cache`, JSON.stringify({
            start: this._start,
            order: this._currentSort,
            search: this._searchValue ?? null,
            folder: this._folderSelected
        }))
    }

    /**
     * Restore sort header visual state (CSS classes) from cached order on init.
     * @returns {void}
     */
    _restoreCachedOrder() {
        if (!this._currentSort.length) {
            return
        }

        const thead = this._element.querySelector("thead")
        this._currentSort.forEach(({ name, dir }) => {
            if (!dir) {
                return
            }
            const th = thead.querySelector(`th[field-name="${name}"]`)
            th?.classList.add("sorted", `sorted-${dir}`)
        })
    }
}