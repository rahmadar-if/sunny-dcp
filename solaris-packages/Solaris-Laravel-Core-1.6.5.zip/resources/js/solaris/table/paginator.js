import Helper from "@core-js/solaris/helper"
import SolarComponent from "../solar/solar-component"

export default class Paginator extends SolarComponent {

    /**
     * @param {string|HTMLElement} selector 
     * @param {number} length
     */
    constructor(selector, length = 10) {
        super()

        if (selector instanceof HTMLElement) {
            this._element = selector
        } else if (Helper.isString(selector) && !Helper.isEmpty(selector)) {
            this._element = document.querySelector(selector)
            if (!this._element) {
                throw new Error(`Element with query selector ${selector} is not found`)
            }
        } else {
            throw new Error(`Selector is supported`)
        }

        this.id = this._element.id

        this._start = 0
        this._length = length
        this._currentPage = 1
        this._recordsTotal = 0
        this._recordsFiltered = 0

        const pageInfo = document.createElement("div")
        pageInfo.className = "page-info"
        this._element.appendChild(pageInfo)

        this._pageInfo = this._element.querySelector("div.page-info")
        this._pageInfo_default = "Showing _start_ to _end_ of _recordsFiltered_ entries"
        this._pageInfo_empty = ""
        this._pageInfo_notFound = "No entries found for your search"
        this._pageInfo_filtered = "(filtered from _recordsTotal_ total entries)"

        const pagination = document.createElement("div")
        pagination.className = "pagination ms-auto"
        pagination.innerHTML = `<nav aria-label="Page navigation" class="pagination-style-4">
            <ul class="pagination pagination-sm mb-0"></ul>
        </nav>`
        this._element.appendChild(pagination)

        this._pagination = this._element.querySelector("div nav ul")

        this._init()
    }

    static supportedEvent() {
        return [
            "prev",
            "next",
            "change"
        ]
    }

    _init() {
        this._pageSlots = []

        this._prevBtn = this._createButton("Prev", false, true, "prev-paginate", async () => await this.prev())
        this._nextBtn = this._createButton("Next", false, true, "next-paginate", async () => await this.next())

        this._pagination.appendChild(this._prevBtn)
        this._pagination.appendChild(this._nextBtn)
    }

    async prev() {
        const page = this._currentPage - 1

        await this.trigger("prev", page)
        await this.goTo(page)
    }

    async next() {
        const page = this._currentPage + 1

        await this.trigger("next", page)
        await this.goTo(page)
    }

    /**
     * @param {number} page 
     */
    async goTo(page) {
        if (page < 1 || page > this._recordsTotal || page == this._currentPage) {
            return
        }

        await this.trigger("change", page)
    }

    /**
     * @param {number} start
     * @param {number} recordTotal
     * @param {number} recordsFiltered
     * @param {number} currentPage 
     * @param {number} totalPage 
     */
    update(start, recordTotal, recordsFiltered, currentPage, totalPage) {
        this._start = start
        this._currentPage = currentPage
        this._recordsTotal = recordTotal
        this._recordsFiltered = recordsFiltered

        if (currentPage === 1) {
            this._prevBtn.classList.add("disabled")
        } else {
            this._prevBtn.classList.remove("disabled")
        }

        if (currentPage === totalPage || totalPage == 0) {
            this._nextBtn.classList.add("disabled")
        } else {
            this._nextBtn.classList.remove("disabled")
        }

        this._pageSlots.forEach(li => li.remove())
        this._pageSlots = []

        const frag = document.createDocumentFragment()
        const pages = this._generatePages(currentPage, totalPage)
        pages.forEach(p => {
            const li = this._createButton(
                p,
                p === currentPage,
                p === "...",
                "",
                async () => await this.goTo(p)
            )

            frag.appendChild(li)
            this._pageSlots.push(li)
        });

        this._pagination.insertBefore(frag, this._nextBtn)

        this._updatePageInfo()
    }

    /**
     * @param {string} label 
     * @param {boolean} active 
     * @param {boolean} disabled 
     * @param {string} className 
     * @param {Function} handler 
     * @returns {HTMLLIElement}
     */
    _createButton(label, active = false, disabled = false, className = "", handler = null) {
        const li = document.createElement("li")
        li.className = `page-item ${className}`
        if (disabled) {
            li.classList.add("disabled")
        }

        if (active) {
            li.classList.add("active")
        }

        const a = document.createElement("a")
        a.className = "page-link"
        a.href = "javascript:void(0);"
        a.textContent = label

        a.addEventListener("click", handler)

        li.appendChild(a)
        return li
    }

    /**
     * @param {number} current 
     * @param {number} total 
     * @returns {Array}
     */
    _generatePages(current, total) {
        const pages = []
        if (total <= 6) {
            for (let i = 1; i <= total; i++) {
                pages.push(i)
            }
        } else {
            pages.push(1)
            if (current > 3) {
                pages.push("...")
            }

            const start = Math.max(2, current - 1)
            const end = Math.min(total - 1, current + 1)
            for (let i = start; i <= end; i++) {
                pages.push(i)
            }
            if (current < total - 2) {
                pages.push("...")
            }

            pages.push(total)
        }

        return pages
    }

    /**
     * @param {string} text 
     * @param {number} start 
     * @param {number} end 
     * @param {number} recordsTotal 
     * @param {number} recordsDisplay 
     */
    _compilePageInfo(text, start, end, recordsTotal, recordsDisplay) {
        return text
            .replace("_start_", start + 1)
            .replace("_end_", end)
            .replace("_recordsFiltered_", recordsDisplay)
            .replace("_recordsTotal_", recordsTotal)
    }

    _updatePageInfo() {
        const end = Math.min(this._start + this._length, this._recordsFiltered)
        let text = this._recordsTotal > 0 ? this._pageInfo_default : this._pageInfo_empty
        if (this._recordsTotal != this._recordsFiltered) {
            text = this._recordsTotal > 0 && this._recordsFiltered == 0 ? this._pageInfo_notFound : `${this._pageInfo_default} ${this._pageInfo_filtered}`
        }

        this._pageInfo.textContent = this._compilePageInfo(
            text,
            this._start,
            end,
            this._recordsTotal,
            this._recordsFiltered
        )
    }
}