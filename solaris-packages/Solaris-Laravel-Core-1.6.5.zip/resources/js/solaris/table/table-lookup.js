import Helper from "@core-js/solaris/helper"
import SolarComponent from "@core-js/solaris/solar/solar-component"
import Modal from "@core-js/solaris/modal"
import Button from "@core-js/solaris/button"
import Table from "./table"

export default class TableLookup extends SolarComponent {

    // #region Static

    /**
     * @returns {string[]}
     */
    static supportedEvent() {
        return ['open', 'close', 'choose', 'choose-no-close', 'cancel']
    }

    // #endregion

    // #region Lifecycle

    /**
     * @param {HTMLElement|string} selector
     * @throws {Error}
     */
    constructor(selector) {
        super()

        if (selector instanceof HTMLElement) {
            this._element = selector
        } else if (Helper.isString(selector) && !Helper.isEmpty(selector)) {
            this._element = document.querySelector(selector)
        }

        if (!this._element) {
            throw new Error(`TableLookup: element not found`)
        }

        this._preInit()
        this.init()
    }

    /**
     * @returns {void}
     */
    _preInit() {
        this.id              = this._element.getAttribute('solar-id')
        this._isRendered     = false
        this._chosen         = false
        this._highlightedRow = null

        const modalEl = this._element.querySelector('div[solar-ui="modal"]')
        this.modal    = new Modal(modalEl)

        const chooseBtnEl = this._element.querySelector(`#${this.id}_choose`)
        this._chooseBtn   = chooseBtnEl ? new Button(chooseBtnEl) : null

        const tableEl = this._element.querySelector(`#${this.id}_table`)
        if (tableEl) {
            this.table = new Table(tableEl)
            this.table.disableCache()
            this._setupSingleSelect()
        }
    }

    /**
     * @returns {void}
     */
    destroy() {
        this.modal?.destroy()
        this._isRendered = false
        this._chosen     = false
        this._events     = new Map()
    }

    // #endregion

    // #region Public API

    /**
     * @param {import('../filter/filter').default|null} preFilter
     * @returns {Promise<this>}
     */
    async open(preFilter = null) {
        if (preFilter) {
            await this.table.preFilter(preFilter, false)
        }
        this.modal.show()
        return this
    }

    /**
     * @returns {this}
     */
    close() {
        this.modal.hide()
        return this
    }

    /**
     * @returns {Table}
     */
    getTable() {
        return this.table
    }

    /**
     * Reset to fresh state without full destroy.
     * Resets render state, selection, and table filters.
     * Called when the parent lookup is re-initialized with the same table-lookup config.
     * @returns {void}
     */
    reset() {
        this._chosen         = false
        this._highlightedRow = null
        this.table.clear()
    }

    /**
     * Change the model for subsequent requests.
     * Takes effect on the next refresh() (second open) or render() (first open).
     * @param {string} model
     * @returns {this}
     */
    setModel(model) {
        this.table.setModel(model)
        return this
    }

    /**
     * Change extend-columns for subsequent requests.
     * @param {string|null} extendColumns
     * @returns {this}
     */
    setExtendColumns(extendColumns) {
        this.table.setExtendColumns(extendColumns)
        return this
    }

    /**
     * Change pre-orders for subsequent requests.
     * @param {string|{name: string, dir: string}[]} preOrders
     * @returns {this}
     */
    setPreOrders(preOrders) {
        this.table.setPreOrders(preOrders)
        return this
    }

    /**
     * Set page length without triggering a refresh.
     * Takes effect on the next render() or refresh().
     * @param {number} length
     * @returns {this}
     */
    setLength(length) {
        this.table._length = length
        this.table._start  = 0
        return this
    }

    // #endregion

    // #region Init

    /**
     * Single-select mode: no checkbox column detected.
     * Row click = highlight only. Row dblclick = auto-choose.
     * Table draw (search/sort/filter) = reset highlight.
     * @returns {void}
     */
    _setupSingleSelect() {
        if (this.table._selectAllVisible) {
            return
        }

        this.table.on('row click', (row, data) => {
            this._element.querySelectorAll('table tbody tr.table-active')
                .forEach(r => r.classList.remove('table-active'))
            row.classList.add('table-active')
            this._highlightedRow = data
        })

        this.table.on('row dblclick', async (row, data) => {
            const hasNoClose = this._events.has('choose-no-close')
            this._chosen     = true

            if (hasNoClose) {
                await this.trigger('choose-no-close', { isSelectAll: false, selected: [String(data.id)], excluded: [] }, [data])
            } else {
                await this.trigger('choose', { isSelectAll: false, selected: [String(data.id)], excluded: [] }, [data])
                this.close()
            }
        })

        this.table.on('draw', () => {
            this._highlightedRow = null
        })
    }

    /**
     * @returns {void}
     */
    init() {
        this.modal
            .on('shown', async () => {
                if (!this._isRendered) {
                    this._isRendered = true
                    await this.table.render()
                } else {
                    await this.table.refresh()
                }
                await this.trigger('open')
            })
            .on('hide', async () => {
                if (!this._chosen) {
                    await this.trigger('cancel')
                }
                this._chosen = false
                await this.trigger('close')
            })
            .on('hidden', () => this.reset())

        if (this._chooseBtn) {
            this._chooseBtn.on('click', async () => {
                await this._handleChoose()
            })
        }

        this._handleFolderZIndex()
    }

    // #endregion

    // #region Events

    /**
     * @returns {Promise<void>}
     */
    async _handleChoose() {
        const hasNoClose = this._events.has('choose-no-close')

        if (!this.table._selectAllVisible) {
            if (!this._highlightedRow) {
                return
            }
            this._chosen = true

            if (hasNoClose) {
                await this.trigger('choose-no-close', { isSelectAll: false, selected: [String(this._highlightedRow.id)], excluded: [] }, [this._highlightedRow])
            } else {
                await this.trigger('choose', { isSelectAll: false, selected: [String(this._highlightedRow.id)], excluded: [] }, [this._highlightedRow])
                this.close()
            }
            return
        }

        const selection = this.table.getSelected()
        const rows      = this.table.getData()

        this._chosen = true

        if (hasNoClose) {
            await this.trigger('choose-no-close', selection, rows)
        } else {
            await this.trigger('choose', selection, rows)
            this.close()
        }
    }

    /**
     * Handle z-index layering when a folder modal opens inside this table-lookup modal.
     * Bootstrap stacks backdrops; the folder modal must sit above the table-lookup modal.
     * @returns {void}
     */
    _handleFolderZIndex() {
        if (!this.table?._folder) {
            return
        }

        this.table._folder._modal
            .on('show', () => {
                this.table._folder._modal._element.style.zIndex = 1057

                const backdrop = document.querySelectorAll('.modal-backdrop.show')[0]
                if (backdrop) {
                    backdrop.style.zIndex = 1050
                }

                setTimeout(() => {
                    const backdrops = document.querySelectorAll('.modal-backdrop.show')
                    if (backdrops.length > 1) {
                        backdrops[backdrops.length - 1].style.zIndex = 1056
                    }
                }, 10)
            })
            .on('hide', () => {
                const backdrop = document.querySelector('.modal-backdrop.show')
                if (backdrop) {
                    backdrop.style.zIndex = null
                }
            })
    }

    // #endregion
}
