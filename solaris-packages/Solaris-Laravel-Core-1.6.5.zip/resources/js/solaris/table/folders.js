import Button from "../button"
import Filter from "../filter/filter"
import FilterConstants from "../filter/filter-constants"
import Form from "../form/form"
import LookupInput from "../form/lookup-input"
import Modal from "../modal"
import axios from "@core-js/libs/axios"
import TextInput from "../form/text-input"
import DatePicker from "../form/date-picker"
import MaskInput from "../form/mask-input"
import CheckboxInput from "../form/checkbox-input"
import ModalForm from "../modal-form"
import OptionGroupInput from "../form/option-group-input"
import Helper from "../helper"
import Table from "./table"
import Model from "../model"
import SolarComponent from "../solar/solar-component"
import DragDropHelper from "../drag-drop"

export default class Folder extends SolarComponent {

	constructor(selector, model) {
		super()

		this._model = model

		this._folderBtn 	 = new Button(document.querySelector(`#${selector}`))
		this._folderSelected = document.querySelector(`#${selector}_selected`)

		this._offCanvasElement = document.querySelector(`#${selector}_offcanvas`)
		this._offCanvas		   = new bootstrap.Offcanvas(this._offCanvasElement)

		this._list = new Table(document.querySelector(`#${selector}_offcanvas_list`))

		this._modalForm = new ModalForm(
			new Modal(document.querySelector(`#${selector}_modal`)),
			new Form(document.querySelector(`#${selector}_modal_form`))
		)
		this._modal = this._modalForm.modal
		this._form  = this._modalForm.form

		this._filterContainer = this._form._element.querySelector('.filter-container')
		this._addFilterBtn 	  = new Button(document.querySelector(`#${selector}_modal_add_filter`))
		this._addGroupBtn 	  = new Button(document.querySelector(`#${selector}_modal_add_group`))

		this._filterMap 	  = new Map()
		this._allColumnsCache = new Map()
		this._index 	  	  = 0
		this._mergeTarget 	  = null

		const DROP_ZONES = '.filter-container, .filter-group-container, [id^="filter-item-sub-container-"]'

		this._dnd = new DragDropHelper(this._filterContainer, {
			draggable: '[data-index]',
			handle: '.ri-draggable',
			dropZone: DROP_ZONES,
		})
		.on('start', this._onDnd_Start.bind(this))
		.on('end', this._onDnd_End.bind(this))
		.on('over', this._onDnd_Over.bind(this))
		.on('leave', this._onDnd_Leave.bind(this))
		.on('drop', this._onDnd_Drop.bind(this))

		this.init()
	}

	static supportedEvent() {
		return [
			"change",
		]
	}

	async init() {
		const data = await this._getAllColumns()

		this._columns = [
			...data.columns.map(col => ({ ...col, id: col.name, name: col.displayName })),
			...data.relations.map(rel => ({
				id: rel.name,
				name: rel.displayName,
				displayName: rel.displayName,
				type: 'relation',
				columns: rel.columns
			}))
		]

		this._conditions = Object.keys(FilterConstants.OperatorType).map(item => {
			const labelOverrides = {
				IsNull      : 'Has No Value',
				IsNotNull   : 'Has Value',
				IsEmpty     : 'Is Empty',
				IsNotEmpty  : 'Is Not Empty',
				IsToday     : 'Is Today',
				IsYesterday : 'Is Yesterday',
				IsThisWeek  : 'Is This Week',
				IsLastWeek  : 'Is Last Week',
				IsThisMonth : 'Is This Month',
				IsLastMonth : 'Is Last Month',
				IsThisYear  : 'Is This Year',
				IsLastYear  : 'Is Last Year',
				IsLastN     : 'In The Last',
				IsNextN     : 'In The Next',
				IsMonth     : 'Month Is',
				IsDay       : 'Day Is',
				IsMonthDay  : 'Month & Day Is',
				IsYear      : 'Year Is',
				In          : 'Is Any Of',
				NotIn       : 'Is None Of',
				FullText    : 'Search',
				Similar     : 'Similar To',
			}

			const text = labelOverrides[item] ?? item.replace(/([a-z])([A-Z])/g, '$1 $2')

			return {
				id: FilterConstants.OperatorType[item],
				name: text
			}
		})

		this._logicals = Object.values(FilterConstants.LogicalType)

		this._folderBtn.enabled()
		this._folderBtn.on("click", this.open.bind(this))

		this._list
			.on("column render:name", this._nameColumnRender.bind(this))
			.on("column created:name", this._nameColumnCreated.bind(this))
			.on("row dblclick", async (row, data) => await this.apply(data.id))
			.on("new", this.new.bind(this))
			.on("edit", async (row, data) => await this.edit(data.id))
			.render()

		this._modal
			.on("hide", () => this._onModalHide())

		this._addFilterBtn.on("click", this.addFilter.bind(this))
		this._addGroupBtn.on("click", this.addGroup.bind(this))

		this._form
			.on("submitting", this.save.bind(this))
			.on("sending", (config) => config.headers['X-Folder-Model'] = this._model)
			.on("failed", (errors, message) => {
				if (errors.filters) {
					Helper.toast({ message: errors.filters, color: "danger" })
				}
			})
			.on("success", async (res) => {
				this._list.refresh()

				if (await Helper.confirm({ title: "Apply this folder?" })) {
					await this.apply(res.data.id)
				}
			})
	}

	open() {
		this._offCanvas.show()
	}

	hide() {
		this._offCanvas.hide()
	}

	_onModalHide() {
		this._filterMap.forEach((item) => {
			if (item.type === 'condition') {
				item.field.destroy()
				item.condition.destroy()
				item.criteria?.destroy()
				item.logical?.destroy()
				item.criteriaAggregate?.column?.destroy()
				item.criteriaAggregate?.operator?.destroy()
				item.criteriaAggregate?.value?.destroy()
				item.criteriaPeriod?.n?.destroy()
				item.criteriaPeriod?.unit?.destroy()
				item.criteriaRelative?.n?.destroy()
				item.criteriaRelative?.unit?.destroy()
				item.criteriaRelative?.direction?.destroy()
				item.criteriaDatePart?.month?.destroy()
				item.criteriaDatePart?.day?.destroy()
				item.criteriaDatePart?.year?.destroy()
			} else if (item.type === 'group') {
				item.logical?.destroy()
			}
		})

		this._filterMap.clear()
		this._filterContainer.innerHTML = ""

		this._index = 0

		this._offCanvas.show()
	}

	//#region filter list

	new() {
		this.hide()
		this._modalForm.new()
	}

	async apply(id, isSilent = false) {
		Helper.loadingPage(true)

		try {
			const data = await Model.get('folder', id)

			this._folderSelected.innerHTML = `${data.name} <span class="ri-close-line" style="cursor: pointer;"></span>`
			this._folderSelected.classList.remove('d-none')

			await this.trigger("change", data.id, new Filter(data.filters), isSilent)

			this.hide()

			this._folderSelected.querySelector('span').addEventListener('click', async (e) => {
				this._folderSelected.innerHTML = ''
				this._folderSelected.classList.add('d-none')

				await this.trigger("change", null, null, false)
			})

		} catch (error) {
			console.error({ error })
		} finally {
			Helper.loadingPage(false)
		}
	}

	async edit(id) {
		try {
			await this._modalForm.edit(id, async (form, data) => {
				const filters = JSON.parse(data.filters)
				await this._loadFiltersToContainer(this._filterContainer, filters)
			})

			this.hide()
		} catch (error) {
			console.error({ error })
			this._onModalHide()
		}
	}

	_nameColumnRender(data, row) {
		return `<div class="d-flex justify-content-between">
            <div class="d-flex flex-column gap-1">
                <p class="fw-medium mb-0">${data}</p>
                <span class="fs-12 text-muted">${row.description ?? ''}</span>
                <span class="fs-12 text-muted"><i class="ri-user-line me-1"></i>${row.created_by.name}</span>
            </div>

            <div class="d-flex gap-1">
                <button data-id="${row.id}" class="btn btn-wave btn-outline-success btn-icon btn-sm waves-effect waves-light action-apply" type="button" title="Apply folder">
                    <i class="ri-check-line"></i>
                </button>
                ${USER_ID == row.created_by.id ?
				`<button data-id="${row.id}" class="btn btn-wave btn-outline-info btn-icon btn-sm waves-effect waves-light action-edit" type="button" title="Edit">
                        <i class="ri-pencil-line"></i>
                    </button>
                    <button data-id="${row.id}" class="btn btn-wave btn-outline-danger btn-icon btn-sm waves-effect waves-light action-delete" type="button" title="Delete">
                        <i class="ri-delete-bin-fill"></i>
                    </button>`
				: ''
			}
            </div>
        </div>`
	}

	_nameColumnCreated(row, cell, cellData, rowData) {
		const applyBtn = cell.querySelector("button.action-apply")
		if (applyBtn) {
			applyBtn.addEventListener("click", async () => this.apply(rowData.id))
		}

		const editBtn = cell.querySelector("button.action-edit")
		if (editBtn) {
			editBtn.addEventListener("click", () => this._list.trigger("edit", row, rowData))
		}

		const deleteBtn = cell.querySelector("button.action-delete")
		if (deleteBtn) {
			deleteBtn.addEventListener("click", async () => await this._list.delete(row, rowData))
		}
	}

	//#endregion

	//#region filter form

	async save() {
		const isValid = this._validateFilters(this._filterContainer)

		if (!isValid) {
			Helper.toast({ message: "Some filter fields are invalid or incomplete.", color: "danger" })
			this._form.hiddenErrorAlert()
			setTimeout(() => this._form.showErrorAlert(), 0)
			throw new Error("filter-validation-failed")
		}

		const filter = new Filter()

		this._buildFilterFromContainer(this._filterContainer, filter)

		const filterResult = filter.get()

		if (filterResult.length > 0) {
			this._form.addData('filters', JSON.stringify(filter.get()))
		} else {
			this._form.deleteData('filters')
		}
	}

	_validateFilters(container) {
		let isValid = true

		Array.from(container.querySelectorAll(':scope > [data-index]')).forEach(el => {
			const index = parseInt(el.dataset.index)
			const type  = el.dataset.type

			if (type === 'group') {
				const groupWrapper = el.querySelector('.flex-fill.border.rounded-3.p-2')
				groupWrapper?.classList.remove('border-danger')

				const groupContainer = document.getElementById(`filter-group-container-${index}`)
				const hasChildren = groupContainer?.querySelectorAll(':scope > [data-index]').length > 0

				if (!hasChildren) {
					groupWrapper?.classList.add('border-danger')
					isValid = false
				} else if (!this._validateFilters(groupContainer)) {
					isValid = false
				}

				return
			}

			const item = this._filterMap.get(index)
			if (!item) {
				return
			}

			item.field.resetValidation()
			item.condition.resetValidation()

			const fieldValue = item.field.get()
			const conditionValue = item.condition.get()?.id ?? null

			if (!fieldValue) {
				item.field.error()
				isValid = false
			}

			if (!conditionValue) {
				item.condition.error()
				isValid = false
			}

			if (!fieldValue || !conditionValue) {
				return
			}

			if (conditionValue === 'WHERE_HAS' || conditionValue === 'WHERE_DOESNT_HAVE') {
				const subWrapper   = document.getElementById(`filter-item-sub-${index}`)
				const subContainer = document.getElementById(`filter-item-sub-container-${index}`)
				subWrapper?.classList.remove('border-danger')

				const hasChildren    = subContainer?.querySelectorAll(':scope > [data-index]').length > 0
				const requireChildren = conditionValue === 'WHERE_HAS'

				// "Has" needs at least one condition; "Doesn't Have" allows empty (no related row at all)
				if (requireChildren && !hasChildren) {
					subWrapper?.classList.add('border-danger')
					isValid = false
				} else if (hasChildren && !this._validateFilters(subContainer)) {
					isValid = false
				}

				return
			}

			if (item.criteriaAggregate !== null) {
				const agg = item.criteriaAggregate

				if (agg.column !== null) {
					agg.column.resetValidation()
					if (!agg.column.get()) {
						agg.column.error()
						isValid = false
					}
				}

				agg.operator.resetValidation()
				if (!agg.operator.get()) {
					agg.operator.error()
					isValid = false
				}

				agg.value.resetValidation()
				if (!agg.value.get()) {
					agg.value.error()
					isValid = false
				}

				return
			}

			if (item.criteriaPeriod) {
				const period = item.criteriaPeriod

				period.n.resetValidation()
				const nVal = parseFloat(period.n.get())
				if (!nVal || nVal <= 0) {
					period.n.error()
					isValid = false
				}

				period.unit.resetValidation()
				if (!period.unit.get()) {
					period.unit.error()
					isValid = false
				}

				return
			}

			if (item.criteriaRelative) {
				const rel = item.criteriaRelative

				rel.n.resetValidation()
				const nVal = parseFloat(rel.n.get())
				if (!nVal || nVal <= 0) {
					rel.n.error()
					isValid = false
				}

				rel.unit.resetValidation()
				if (!rel.unit.get()) {
					rel.unit.error()
					isValid = false
				}

				rel.direction.resetValidation()
				if (!rel.direction.get()) {
					rel.direction.error()
					isValid = false
				}

				return
			}

			if (item.criteriaDatePart) {
				const isNow = document.getElementById(`filter-item-dp-now-${index}`)?.checked ?? false
				if (isNow) {
					return
				}

				const dp = item.criteriaDatePart

				if (dp.month) {
					dp.month.resetValidation()
					if (!dp.month.get()) {
						dp.month.error()
						isValid = false
					}
				}

				if (dp.day) {
					dp.day.resetValidation()
					const dayVal = parseInt(dp.day.get())
					if (!dayVal || dayVal < 1 || dayVal > 31) {
						dp.day.error()
						isValid = false
					}
				}

				if (dp.year) {
					dp.year.resetValidation()
					const yearVal = parseInt(dp.year.get())
					if (!yearVal || yearVal < 1) {
						dp.year.error()
						isValid = false
					}
				}

				return
			}

			const noValueConditions = [
				FilterConstants.OperatorType.IsNull,
				FilterConstants.OperatorType.IsNotNull,
				FilterConstants.OperatorType.IsEmpty,
				FilterConstants.OperatorType.IsNotEmpty,
				FilterConstants.OperatorType.IsToday,
				FilterConstants.OperatorType.IsYesterday,
				FilterConstants.OperatorType.IsThisWeek,
				FilterConstants.OperatorType.IsLastWeek,
				FilterConstants.OperatorType.IsThisMonth,
				FilterConstants.OperatorType.IsLastMonth,
				FilterConstants.OperatorType.IsThisYear,
				FilterConstants.OperatorType.IsLastYear,
			]
			if (noValueConditions.includes(conditionValue)) {
				return
			}

			const fieldId = fieldValue?.id ?? fieldValue
			const column  = item.columns?.find(col => col.id == fieldId)

			if (column?.type === 'boolean') {
				return
			}

			item.criteria.resetValidation()
			const criteriaValue    = item.criteria.get()
			const isLookupMultiple = item.criteria instanceof LookupInput && item.criteria._isMultiple
			const criteriaInvalid  = isLookupMultiple
				? (!criteriaValue || criteriaValue.length === 0)
				: column?.type === 'number'
					? (criteriaValue === null || criteriaValue === undefined || criteriaValue === '')
					: !criteriaValue

			if (criteriaInvalid) {
				item.criteria.error()
				isValid = false
			}
		})

		return isValid
	}

	addFilter(container = null) {
		const target = (container instanceof Element) ? container : this._filterContainer
		this._addConditionToContainer(target)
		this._updateLogicalVisibility()
	}

	addGroup() {
		this._addGroupToContainer(this._filterContainer)
		this._updateLogicalVisibility()
	}

	_addConditionToContainer(container, overrideColumns = null) {
		const index 	 = this._index
		const filterElem = this._renderFilterForm(index)

		container.insertAdjacentHTML('beforeend', filterElem)

		const _relationBadge = (item) => `<div class="d-flex align-items-center">${item.name} <span class="badge bg-info text-white ms-1" style="font-size:0.65em">Relation</span></div>`
		const _lookupBadge   = (item) => `<div class="d-flex align-items-center">${item.name} <span class="badge bg-primary text-white ms-1" style="font-size:0.65em">Lookup</span></div>`
		
		const _field = LookupInput.create(document.getElementById(`filter-item-field-${index}`), {
			size: 'sm',
			optionsTemplate: (item) => {
				if (item.type === 'relation') {
					return _relationBadge(item)
				}
				if (item.type === 'lookup') {
					return _lookupBadge(item)
				}
				return item.name
			},
			selectionTemplate: (item) => {
				if (item.type === 'relation') {
					return _relationBadge(item)
				}
				if (item.type === 'lookup') {
					return _lookupBadge(item)
				}
				return item.name || ''
			}
		})

		const _condition 	 = LookupInput.create(document.getElementById(`filter-item-condition-${index}`), { size: 'sm' })
		const _criteria  	 = new TextInput(document.getElementById(`filter-item-criteria-${index}`))
		const logical 	 	 = new OptionGroupInput(document.getElementById(`filter-item-logical-${index}`), "radio")
		const criteriaParent = document.getElementById(`filter-item-criteria-${index}`).parentElement
		const columns 		 = overrideColumns ?? this._columns

		_condition.disabled()
		_criteria.disabled()

		_field.setOptions(columns)
		_field.on("change", (value) => this._onFieldChanged(_field, value, index))

		_condition.setOptions(this._conditions)
		_condition.on("change", (value) => this._onConditionChanged(_condition, value, index))

		this._filterMap.set(index, {
			type: 'condition',
			index,
			container,
			field: _field,
			condition: _condition,
			criteria: _criteria,
			logical,
			columns,
			criteriaParent,
			relationColumns: null,
			criteriaAggregate: null,
			criteriaPeriod: null,
			criteriaRelative: null,
			criteriaDatePart: null,
		})

		document.getElementById(`filter-item-relative-toggle-${index}`)
			?.addEventListener('click', () => {
				const item = this._filterMap.get(index)
				if (item.criteriaRelative) {
					this._destroyRelativeDateCriteria(item, index)
				} else {
					this._renderRelativeDateCriteria(item, index)
				}
			})

		document.getElementById(`filter-item-remove-${index}`)
			.addEventListener("click", () => this._removeFilter(index))

		const subContainerEl = document.getElementById(`filter-item-sub-container-${index}`)

		document.getElementById(`filter-item-sub-add-${index}`)
			.addEventListener("click", () => {
				const item = this._filterMap.get(index)
				this._addConditionToContainer(subContainerEl, item.relationColumns)
				this._updateLogicalVisibility()
			})

		this._index++

		return index
	}

	_addGroupToContainer(container) {
		const index = this._index
		const groupElem = this._renderGroupForm(index)

		container.insertAdjacentHTML('beforeend', groupElem)

		const groupEl 		 = container.querySelector(`.filter-group-${index}`)
		const groupContainer = document.getElementById(`filter-group-container-${index}`)

		const logical = new OptionGroupInput(document.getElementById(`filter-group-logical-${index}`), "radio")

		this._filterMap.set(index, {
			type: 'group',
			index,
			logical
		})

		document.getElementById(`filter-group-add-${index}`)
			.addEventListener("click", () => {
				this._addConditionToContainer(groupContainer)
				this._updateLogicalVisibility()
			})

		document.getElementById(`filter-group-add-group-${index}`)
			.addEventListener("click", () => {
				this._addGroupToContainer(groupContainer)
				this._updateLogicalVisibility()
			})

		document.getElementById(`filter-group-remove-${index}`)
			.addEventListener("click", () => this._removeGroup(index))

		this._index++

		return index
	}

	_removeFilter(index) {
		const item = this._filterMap.get(index)

		this._destroySubContainerConditions(index)

		item.field.destroy()
		item.condition.destroy()
		item.criteria?.destroy()
		item.logical?.destroy()
		item.criteriaAggregate?.column?.destroy()
		item.criteriaAggregate?.operator?.destroy()
		item.criteriaAggregate?.value?.destroy()
		item.criteriaPeriod?.n?.destroy()
		item.criteriaPeriod?.unit?.destroy()
		item.criteriaRelative?.n?.destroy()
		item.criteriaRelative?.unit?.destroy()
		item.criteriaRelative?.direction?.destroy()
		item.criteriaDatePart?.month?.destroy()
		item.criteriaDatePart?.day?.destroy()

		document.querySelector(`.filter-item-${index}`)?.remove()
		this._filterMap.delete(index)

		this._updateLogicalVisibility()
	}

	_removeGroup(index) {
		const item 			 = this._filterMap.get(index)
		const groupContainer = document.getElementById(`filter-group-container-${index}`)

		groupContainer.querySelectorAll('[data-index]').forEach(el => {
			const childIndex = parseInt(el.dataset.index)
			const childItem  = this._filterMap.get(childIndex)

			if (!childItem) {
				return
			}

			if (childItem.type === 'condition') {
				this._destroySubContainerConditions(childIndex)
				childItem.field.destroy()
				childItem.condition.destroy()
				childItem.criteria?.destroy()
				childItem.logical?.destroy()
				childItem.criteriaAggregate?.column?.destroy()
				childItem.criteriaAggregate?.operator?.destroy()
				childItem.criteriaAggregate?.value?.destroy()
				childItem.criteriaPeriod?.n?.destroy()
				childItem.criteriaPeriod?.unit?.destroy()
				childItem.criteriaRelative?.n?.destroy()
				childItem.criteriaRelative?.unit?.destroy()
				childItem.criteriaRelative?.direction?.destroy()
				childItem.criteriaDatePart?.month?.destroy()
				childItem.criteriaDatePart?.day?.destroy()
			}

			this._filterMap.delete(childIndex)
		})

		item.logical?.destroy()
		this._filterMap.delete(index)

		document.querySelector(`.filter-group-${index}`)?.remove()
		this._updateLogicalVisibility()
	}

	_buildFilterFromContainer(container, filter) {
		Array.from(container.querySelectorAll(':scope > [data-index]')).forEach(el => {
			const index = parseInt(el.dataset.index)
			const type  = el.dataset.type

			if (type === 'group') {
				const groupContainer = document.getElementById(`filter-group-container-${index}`)
				const item = this._filterMap.get(index)

				const tempFilter = new Filter()
				this._buildFilterFromContainer(groupContainer, tempFilter)

				if (tempFilter.isEmpty()) {
					return
				}

				const logical = item.logical.get()?.id ?? FilterConstants.LogicalType.AND
				filter.group(() => tempFilter, logical)

				return
			}

			const item = this._filterMap.get(index)

			if (!item) {
				return
			}

			const field = item.field.get()?.id ?? null

			if (!field) {
				return
			}

			const logical = item.logical.get()?.id ?? FilterConstants.LogicalType.AND
			const column  = item.columns.find(col => col.id == field)

			if (column?.type === 'relation') {
				const condition = item.condition.get()?.id ?? null
				if (!condition) {
					return
				}

				if (condition === 'WHERE_HAS' || condition === 'WHERE_DOESNT_HAVE') {
					const subContainer = document.getElementById(`filter-item-sub-container-${index}`)
					if (!subContainer) {
						return
					}

					const subFilter = new Filter()
					this._buildFilterFromContainer(subContainer, subFilter)

					const negate = condition === 'WHERE_DOESNT_HAVE'

					// "Has" needs conditions; "Doesn't Have" allows empty (no related row at all)
					if (!negate && subFilter.isEmpty()) {
						return
					}

					filter._filters.push({ logical, relation: field, conditions: subFilter.get(), negate })
				} else {
					const agg = item.criteriaAggregate
					if (!agg) {
						return
					}

					const op = agg.operator.get()?.id ?? null
					const val = parseFloat(agg.value.get())
					if (!op || isNaN(val)) {
						return
					}

					let left = field
					if (condition !== 'count') {
						const col = agg.column.get()?.id ?? null
						if (!col) {
							return
						}
						left = `${field}.${col}`
					}

					filter.addAggregate(logical, condition, left, op, val)
				}
				return
			}

			if (column?.type === 'lookup') {
				const condition = item.condition.get()?.id ?? null
				if (condition === 'WHERE_HAS' || condition === 'WHERE_DOESNT_HAVE') {
					const subContainer = document.getElementById(`filter-item-sub-container-${index}`)
					if (!subContainer) {
						return
					}

					const subFilter = new Filter()
					this._buildFilterFromContainer(subContainer, subFilter)

					const negate = condition === 'WHERE_DOESNT_HAVE'

					// "Has" needs conditions; "Doesn't Have" allows empty (no related row at all)
					if (!negate && subFilter.isEmpty()) {
						return
					}

					filter._filters.push({ logical, relation: field, conditions: subFilter.get(), negate })
					return
				}
			}

			const condition = item.condition.get()?.id ?? null

			// Date part filter (Month Is, Day Is, Month & Day Is)
			if (item.criteriaDatePart) {
				const dp    = item.criteriaDatePart
				const isNow = document.getElementById(`filter-item-dp-now-${index}`)?.checked ?? false
				if (!condition) return

				if (isNow) {
					filter.add(logical, field, condition, { source: 'now' })
					return
				}

				if (condition === FilterConstants.OperatorType.IsMonthDay) {
					const month = dp.month?.get()?.id ?? null
					const day   = parseInt(dp.day?.get()) || 0
					if (!month || !day) return
					filter.add(logical, field, condition, { month, day })
				} else if (condition === FilterConstants.OperatorType.IsMonth) {
					const month = dp.month?.get()?.id ?? null
					if (!month) return
					filter.add(logical, field, condition, month)
				} else if (condition === FilterConstants.OperatorType.IsYear) {
					const year = parseInt(dp.year?.get()) || 0
					if (!year) return
					filter.add(logical, field, condition, year)
				} else {
					const day = parseInt(dp.day?.get()) || 0
					if (!day) return
					filter.add(logical, field, condition, day)
				}
				return
			}

			// Relative date comparison (e.g. created_at <= 10 days ago)
			if (item.criteriaRelative) {
				const rel     = item.criteriaRelative
				const nVal    = parseFloat(rel.n.get()) || 0
				const unit    = rel.unit.get()?.id ?? null
				const dir     = rel.direction.get()?.id ?? null
				if (!condition || !nVal || !unit || !dir) {
					return
				}
				filter.add(logical, field, condition, { type: 'relative', unit, offset: nVal, direction: dir })
				return
			}

			// Dynamic period (IS_LAST_N / IS_NEXT_N)
			if (item.criteriaPeriod) {
				const nVal = parseFloat(item.criteriaPeriod.n.get()) || 0
				const unit = item.criteriaPeriod.unit.get()?.id ?? null
				if (!condition || !nVal || !unit) {
					return
				}
				filter.add(logical, field, condition, { value: nVal, unit })
				return
			}

			// Fixed period (no input needed)
			const _fixedPeriodConditions = [
				FilterConstants.OperatorType.IsToday, FilterConstants.OperatorType.IsYesterday,
				FilterConstants.OperatorType.IsThisWeek, FilterConstants.OperatorType.IsLastWeek,
				FilterConstants.OperatorType.IsThisMonth, FilterConstants.OperatorType.IsLastMonth,
				FilterConstants.OperatorType.IsThisYear, FilterConstants.OperatorType.IsLastYear,
			]
			if (_fixedPeriodConditions.includes(condition)) {
				filter.add(logical, field, condition, null)
				return
			}

			const criteria    = item.criteria.get()
			let criteriaValue = criteria

			if (column.type == 'lookup') {
				criteriaValue = (condition == FilterConstants.OperatorType.In || condition == FilterConstants.OperatorType.NotIn) ?
					criteria?.map(c => ({ id: c.id, name: c.name })) : criteria
			} else if (column.type == 'date' || column.type == 'datetime') {
				criteriaValue = item.criteria.toString()
			}

			filter.add(logical, field, condition, criteriaValue ?? null)
		})
	}

	async _loadFiltersToContainer(container, filters, overrideColumns = null) {
		for (const item of filters) {
			// WHERE_HAS / WHERE_DOESNT_HAVE
			if (item.relation && Array.isArray(item.conditions)) {
				const columns  = overrideColumns ?? this._columns
				const fieldObj = columns.find(col => col.id === item.relation)
				if (!fieldObj) {
					continue
				}

				const index    = this._addConditionToContainer(container, overrideColumns)
				const condItem = this._filterMap.get(index)

				condItem.field.set(fieldObj, true)
				this._onFieldChanged(condItem.field, item.relation, index)

				const relationCondition = item.negate ? 'WHERE_DOESNT_HAVE' : 'WHERE_HAS'
				condItem.condition.set(relationCondition, true)
				await this._onConditionChanged(condItem.condition, relationCondition, index)

				const subContainer = document.getElementById(`filter-item-sub-container-${index}`)
				await this._loadFiltersToContainer(subContainer, item.conditions, condItem.relationColumns)

				condItem.logical.set(item.logical, true)
				continue
			}

			// Aggregate
			if (item.aggregate) {
				const aggregate = item.aggregate
				const left  	= item.conditions.left
				const right 	= item.conditions.right
				const relation  = aggregate === 'count' ? left : left.substring(0, left.lastIndexOf('.'))
				const col 		= aggregate === 'count' ? null : left.substring(left.lastIndexOf('.') + 1)

				const columns  = overrideColumns ?? this._columns
				const fieldObj = columns.find(c => c.id === relation)
				if (!fieldObj) {
					continue
				}

				const index    = this._addConditionToContainer(container, overrideColumns)
				const condItem = this._filterMap.get(index)

				condItem.field.set(fieldObj, true)
				this._onFieldChanged(condItem.field, relation, index)

				condItem.condition.set(aggregate, true)
				await this._onConditionChanged(condItem.condition, aggregate, index)

				if (col) {
					condItem.criteriaAggregate.column.set(col, true)
				}
				condItem.criteriaAggregate.operator.set(item.operator, true)
				condItem.criteriaAggregate.value.set(right)

				condItem.logical.set(item.logical, true)
				continue
			}

			// Group
			if (Array.isArray(item.conditions)) {
				const index 		 = this._addGroupToContainer(container)
				const groupContainer = document.getElementById(`filter-group-container-${index}`)

				await this._loadFiltersToContainer(groupContainer, item.conditions, overrideColumns)

				const groupItem = this._filterMap.get(index)
				groupItem.logical.set(item.logical, true)
				continue
			}

			// Regular condition
			const columns  = overrideColumns ?? this._columns
			const fieldObj = columns.find(col => col.id === item.conditions.left)
			if (!fieldObj) {
				continue
			}

			const index    = this._addConditionToContainer(container, overrideColumns)
			const condItem = this._filterMap.get(index)

			condItem.field.set(fieldObj, true)
			this._onFieldChanged(condItem.field, item.conditions.left, index)

			condItem.condition.set(item.operator, true)
			await this._onConditionChanged(condItem.condition, item.operator, index)

			const _isDynPeriod  = item.operator === FilterConstants.OperatorType.IsLastN || item.operator === FilterConstants.OperatorType.IsNextN
			const _isRelative   = item.conditions.right?.type === 'relative'
			const _isDatePart   = [FilterConstants.OperatorType.IsMonth, FilterConstants.OperatorType.IsDay, FilterConstants.OperatorType.IsMonthDay, FilterConstants.OperatorType.IsYear].includes(item.operator)

			if (_isDynPeriod && condItem.criteriaPeriod && item.conditions.right) {
				condItem.criteriaPeriod.n.set(item.conditions.right.value)
				condItem.criteriaPeriod.unit.set(item.conditions.right.unit, true)
			} else if (_isRelative) {
				this._renderRelativeDateCriteria(condItem, index)
				condItem.criteriaRelative.n.set(item.conditions.right.offset)
				condItem.criteriaRelative.unit.set(item.conditions.right.unit, true)
				condItem.criteriaRelative.direction.set(item.conditions.right.direction, true)
			} else if (_isDatePart && condItem.criteriaDatePart) {
				const right  = item.conditions.right
				const isNow  = right?.source === 'now'
				const nowBtn = document.getElementById(`filter-item-dp-now-${index}`)

				if (isNow) {
					if (nowBtn) {
						nowBtn.checked = true
					}
					condItem.criteriaDatePart.month?.disabled()
					condItem.criteriaDatePart.day?.disabled()
					condItem.criteriaDatePart.year?.disabled()
				} else if (item.operator === FilterConstants.OperatorType.IsMonthDay) {
					condItem.criteriaDatePart.month?.set(right?.month, true)
					condItem.criteriaDatePart.day?.set(right?.day)
				} else if (item.operator === FilterConstants.OperatorType.IsMonth) {
					condItem.criteriaDatePart.month?.set(right, true)
				} else if (item.operator === FilterConstants.OperatorType.IsYear) {
					condItem.criteriaDatePart.year?.set(right)
				} else {
					condItem.criteriaDatePart.day?.set(right)
				}
			} else {
				condItem.criteria?.set(item.conditions.right)
			}

			condItem.logical.set(item.logical, true)
		}

		this._updateLogicalVisibility()
	}

	_onFieldChanged(field, value, index) {
		const filter = this._filterMap.get(index)

		if (!value) {
			this._destroyAggregateCriteria(filter, index)
			this._destroyPeriodCriteria(filter, index)
			this._destroyRelativeDateCriteria(filter, index)
			this._destroyDatePartCriteria(filter, index)
			this._destroySubContainerConditions(index)
			document.getElementById(`filter-item-sub-${index}`)?.classList.add('d-none')
			document.getElementById(`filter-item-relative-toggle-${index}`)?.classList.add('d-none')
			document.getElementById(`filter-item-relative-toggle-${index}`)?.classList.remove('active')
			filter.criteria = this._resetCriteria(filter.criteria, index)
			filter.condition.set(null)
			filter.condition.disabled()
			return
		}

		const column = filter.columns.find(col => col.id == (value?.id ?? value))

		if (column?.type === 'relation') {
			this._destroyAggregateCriteria(filter, index)
			this._destroyPeriodCriteria(filter, index)
			this._destroyRelativeDateCriteria(filter, index)
			this._destroyDatePartCriteria(filter, index)
			this._destroySubContainerConditions(index)
			filter.criteria = this._resetCriteria(filter.criteria, index)
			filter.relationColumns = column.columns.map(col => ({ ...col, id: col.name, name: col.displayName }))
			document.getElementById(`filter-item-sub-${index}`)?.classList.add('d-none')
			filter.condition.set(null)
			filter.condition.setOptions(this._getConditions('relation'))
			filter.condition.enabled()
			return
		}

		// Clear relation state when switching away from a relation field
		filter.relationColumns = null
		this._destroyAggregateCriteria(filter, index)
		this._destroyPeriodCriteria(filter, index)
		this._destroyRelativeDateCriteria(filter, index)
		this._destroyDatePartCriteria(filter, index)
		this._destroySubContainerConditions(index)
		document.getElementById(`filter-item-sub-${index}`)?.classList.add('d-none')

		if (column.type == 'lookup') {
			filter.criteria = this._lookupCriteria(filter.criteria, index, {
				placeholder: `Choose ${column.displayName}`,
				source: column.lookup,
				pagination: "pagination"
			}, true)
		} else if (column.type == 'date' || column.type == 'datetime') {
			filter.criteria = this._datePickerCriteria(filter.criteria, column.type, false, index)
		} else if (column.type == 'number') {
			filter.criteria = this._numberCriteria(filter.criteria, index)
		} else if (column.type == 'boolean') {
			filter.criteria = this._booleanCriteria(filter.criteria, index)
		} else {
			filter.criteria = this._resetCriteria(filter.criteria, index)
		}

		filter.condition.setOptions(this._getConditions(column.type))
		filter.condition.enabled()
	}

	async _onConditionChanged(condition, value, index) {
		const filter = this._filterMap.get(index)

		if (!value) {
			if (filter.criteriaRelative) {
				this._destroyRelativeDateCriteria(filter, index)
			}
			if (filter.criteriaPeriod) {
				this._destroyPeriodCriteria(filter, index)
			}
			if (filter.criteriaDatePart) {
				this._destroyDatePartCriteria(filter, index)
			}
			if (filter.criteria) {
				filter.criteria instanceof CheckboxInput
					? filter.criteria.set(false, true)
					: filter.criteria.set(null, true)
				filter.criteria.disabled()
			}
			const _tb = document.getElementById(`filter-item-relative-toggle-${index}`)
			_tb?.classList.add('d-none')
			_tb?.classList.remove('active')
			return
		}

		value = value.id ?? value

		const fieldId = filter.field.get()?.id
		const column  = filter.columns.find(col => col.id == fieldId)

		// Manage relative toggle — always runs before early returns
		const _relativeToggleBtn = document.getElementById(`filter-item-relative-toggle-${index}`)
		const _isDateColumn      = column?.type === 'date' || column?.type === 'datetime'
		const _isComparisonOp    = [
			FilterConstants.OperatorType.Equal, FilterConstants.OperatorType.NotEqual,
			FilterConstants.OperatorType.Greater, FilterConstants.OperatorType.GreaterOrEqual,
			FilterConstants.OperatorType.Less, FilterConstants.OperatorType.LessOrEqual,
		].includes(value)

		if (_isDateColumn && _isComparisonOp) {
			_relativeToggleBtn?.classList.remove('d-none')
		} else {
			_relativeToggleBtn?.classList.add('d-none')
			_relativeToggleBtn?.classList.remove('active')
			if (filter.criteriaRelative) {
				this._destroyRelativeDateCriteria(filter, index)
			}
		}

		if (column?.type === 'relation') {
			const subEl = document.getElementById(`filter-item-sub-${index}`)

			if (value === 'WHERE_HAS' || value === 'WHERE_DOESNT_HAVE') {
				this._destroyAggregateCriteria(filter, index)
				filter.criteria.set(null, true)
				filter.criteria.disabled()
				subEl?.classList.remove('d-none')
			} else {
				subEl?.classList.add('d-none')
				this._destroySubContainerConditions(index)
				this._renderAggregateCriteria(filter, index, value)
			}
			return
		}

		if (column?.type === 'lookup') {
			if (value === 'WHERE_HAS' || value === 'WHERE_DOESNT_HAVE') {
				filter.criteria.set(null, true)
				filter.criteria.disabled()
				document.getElementById(`filter-item-sub-${index}`)?.classList.remove('d-none')

				const allCols = await this._getAllColumns(column.lookup)
				filter.relationColumns = [
					...allCols.columns.map(col => ({ ...col, id: col.name, name: col.displayName })),
					...allCols.relations.map(rel => ({
						id: rel.name,
						name: rel.displayName,
						displayName: rel.displayName,
						type: 'relation',
						columns: rel.columns
					}))
				]
			} else {
				document.getElementById(`filter-item-sub-${index}`)?.classList.add('d-none')
				this._destroySubContainerConditions(index)
				filter.relationColumns = null

				const noValueConditions = [FilterConstants.OperatorType.IsNull, FilterConstants.OperatorType.IsNotNull]
				if (noValueConditions.includes(value)) {
					filter.criteria.set(null, true)
					filter.criteria.disabled()
					return
				}

				const isMultiple = value === FilterConstants.OperatorType.In || value === FilterConstants.OperatorType.NotIn
				if (isMultiple !== filter.criteria._isMultiple) {
					filter.criteria = this._lookupCriteria(filter.criteria, index, {
						placeholder: `Choose ${column.displayName}`,
						source: column.lookup,
						pagination: "pagination",
						...(isMultiple ? { multiple: "multiple" } : {})
					}, true)
				}

				filter.criteria.enabled()
			}
			return
		}

		const _fixedPeriodOps = [
			FilterConstants.OperatorType.IsToday, FilterConstants.OperatorType.IsYesterday,
			FilterConstants.OperatorType.IsThisWeek, FilterConstants.OperatorType.IsLastWeek,
			FilterConstants.OperatorType.IsThisMonth, FilterConstants.OperatorType.IsLastMonth,
			FilterConstants.OperatorType.IsThisYear, FilterConstants.OperatorType.IsLastYear,
		]
		const _isDynamicPeriod = value === FilterConstants.OperatorType.IsLastN || value === FilterConstants.OperatorType.IsNextN

		if (_fixedPeriodOps.includes(value)) {
			this._destroyPeriodCriteria(filter, index)
			filter.criteria?.set(null, true)
			filter.criteria?.disabled()
			return
		}

		if (_isDynamicPeriod) {
			if (filter.criteriaPeriod) {
				filter.criteriaPeriod.n?.destroy()
				filter.criteriaPeriod.unit?.destroy()
				filter.criteriaPeriod = null
			}
			this._renderPeriodCriteria(filter, index)
			return
		}

		const _datePartOps = [FilterConstants.OperatorType.IsMonth, FilterConstants.OperatorType.IsDay, FilterConstants.OperatorType.IsMonthDay, FilterConstants.OperatorType.IsYear]
		if (_datePartOps.includes(value)) {
			this._destroyPeriodCriteria(filter, index)
			this._destroyRelativeDateCriteria(filter, index)
			if (filter.criteriaDatePart) {
				filter.criteriaDatePart.month?.destroy()
				filter.criteriaDatePart.day?.destroy()
				filter.criteriaDatePart = null
			}
			document.getElementById(`filter-item-relative-toggle-${index}`)?.classList.add('d-none')
			this._renderDatePartCriteria(filter, index, value)
			return
		}

		// Switching away from any special criteria to normal operator
		if (filter.criteriaPeriod) {
			this._destroyPeriodCriteria(filter, index)
			if (column?.type === 'date' || column?.type === 'datetime') {
				const isBtw = value === FilterConstants.OperatorType.Between || value === FilterConstants.OperatorType.NotBetween
				filter.criteria = this._datePickerCriteria(filter.criteria, column.type, isBtw, index)
			}
		}

		if (filter.criteriaDatePart) {
			this._destroyDatePartCriteria(filter, index)
		}

		// Re-init DatePicker if date column and criteria is not DatePicker
		// (can happen after switching from fixed period operator)
		if ((column?.type === 'date' || column?.type === 'datetime') && !(filter.criteria instanceof DatePicker)) {
			const isBtw = value === FilterConstants.OperatorType.Between || value === FilterConstants.OperatorType.NotBetween
			filter.criteria = this._datePickerCriteria(filter.criteria, column.type, isBtw, index)
		}

		const isDatePicker = filter.criteria instanceof DatePicker
		const isLookup     = filter.criteria instanceof LookupInput
		const isBetween    = value == FilterConstants.OperatorType.Between || value == FilterConstants.OperatorType.NotBetween
		const isMultiple   = value == FilterConstants.OperatorType.In || value == FilterConstants.OperatorType.NotIn

		if (isBetween && isDatePicker && !filter.criteria._range) {
			filter.criteria = this._datePickerCriteria(filter.criteria, column.type, true, index)
		} else if (!isBetween && isDatePicker && filter.criteria._range) {
			filter.criteria.set(null, true)
			filter.criteria = this._datePickerCriteria(filter.criteria, column.type, false, index)
		} else if (isLookup && (isMultiple || filter.criteria._isMultiple)) {
			const attributes = {
				placeholder: `Choose ${column.displayName}`,
				source: column.lookup,
				pagination: "pagination",
				...(isMultiple ? { multiple: "multiple" } : {})
			}
			filter.criteria = this._lookupCriteria(filter.criteria, index, attributes, true)
		}

		const disableCondition = [
			FilterConstants.OperatorType.IsNull,
			FilterConstants.OperatorType.IsNotNull,
			FilterConstants.OperatorType.IsEmpty,
			FilterConstants.OperatorType.IsNotEmpty,
			..._fixedPeriodOps,
		]

		if (disableCondition.includes(value)) {
			filter.criteria?.set(null, true)
			filter.criteria?.disabled()
		} else if (!filter.criteriaRelative) {
			filter.criteria?.enabled()
		}
	}

	_renderFilterForm(index) {
		return `<div class="filter-item filter-item-${index} mb-2" draggable="true" data-type="condition" data-index="${index}">
            <div class="d-flex align-items-center gap-2">
                <span class="ri-draggable" style="cursor: pointer;"></span>

                <div class="row flex-fill">
                    <div class="col-4">
                        ${this._renderLookupInput("field", index, { placeholder: "Choose field" })}
                    </div>
                    <div class="col-4">
                        ${this._renderLookupInput("condition", index, { placeholder: "Choose condition" })}
                    </div>
                    <div class="col-4">
                        ${this._renderCriteriaInput(index)}
                    </div>
                </div>

                <div class="d-flex align-items-center gap-1">
                    <button id="filter-item-relative-toggle-${index}" class="btn btn-outline-secondary btn-icon btn-sm waves-effect d-none" type="button" title="Switch to relative date">
                        <i class="ri-time-line"></i>
                    </button>

                    ${this._renderLogicalRadio(index, 'item')}

                    <button id="filter-item-remove-${index}" class="btn btn-wave btn-danger btn-icon btn-sm waves-effect waves-light" type="button" title="Remove filter">
                        <i class="ri-close-line"></i>
                    </button>
                </div>
            </div>
            <div id="filter-item-sub-${index}" class="d-none ms-4 mt-2 border rounded p-2">
                <div id="filter-item-sub-container-${index}"></div>
                <button id="filter-item-sub-add-${index}" type="button" class="btn btn-secondary btn-sm mt-1">
                    <i class="ri-add-line me-1"></i>Add condition
                </button>
            </div>
        </div>`
	}

	_renderGroupForm(index) {
		return `<div class="filter-group filter-group-${index} mb-2" draggable="true" data-type="group" data-index="${index}">
            <div class="d-flex align-items-start gap-2">
                <span class="ri-draggable mt-2" style="cursor: pointer;"></span>

                <div class="flex-fill border rounded-3 p-2">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="fw-medium fs-12 text-muted"><i class="ri-stack-line me-1"></i>Group</span>
                        <div class="d-flex gap-1">
                            <button id="filter-group-add-${index}" type="button" class="btn btn-wave btn-secondary btn-icon btn-sm waves-effect waves-light" title="Add filter">
                                <i class="ri-add-line"></i>
                            </button>
                            <button id="filter-group-add-group-${index}" type="button" class="btn btn-wave btn-secondary btn-icon btn-sm waves-effect waves-light" title="Add group">
                                <i class="ri-stack-line"></i>
                            </button>
                        </div>
                    </div>
                    <div id="filter-group-container-${index}" class="filter-group-container" style="min-height: 2rem;"></div>
                </div>

                <div class="d-flex align-items-center gap-1">
                    ${this._renderLogicalRadio(index, 'group')}

                    <button id="filter-group-remove-${index}" class="btn btn-wave btn-danger btn-icon btn-sm waves-effect waves-light" type="button" title="Remove group">
                        <i class="ri-close-line"></i>
                    </button>
                </div>
            </div>
        </div>`
	}

	_renderLookupInput(id, index) {
		return `<div id="filter-item-${id}-${index}"></div>`
	}

	_renderCriteriaInput(index, attributes = null) {
		return `<input
            class="form-control form-control-sm"
            type="text"
            id="filter-item-criteria-${index}"
            placeholder="Enter criteria" ${attributes ?
				Object.entries(attributes)
					.map(([key, value]) => `${key}="${value}"`)
					.join(" ") : ''}>`
	}

	_renderLogicalRadio(index, type = 'item') {
		const radios = this._logicals.map(item => {
			const logicalLower = item.toLowerCase()

			return `<div>
                    <input
                        type="radio"
                        class="btn-check"
                        autocomplete="off"
                        id="filter-${type}-logical-${logicalLower}-${index}"
                        name="filter-${type}-logical-${index}"
                        value="${item}"
                        ${logicalLower == 'and' ? `checked="checked"` : ''}>
                    <label class="btn btn-outline-secondary btn-sm" for="filter-${type}-logical-${logicalLower}-${index}">${item}</label>
                </div>`
		}).join("")

		return `<div id="filter-${type}-logical-${index}" class="d-flex gap-1">${radios}</div>`
	}

	_resetCriteria(criteria, index) {
		if (!(criteria instanceof TextInput)) {
			const filter = this._filterMap.get(index)
			criteria.destroy()
			filter.criteriaParent.innerHTML = this._renderCriteriaInput(index)
			criteria = new TextInput(document.getElementById(`filter-item-criteria-${index}`))
		}

		criteria.set(null, true)
		criteria.disabled()

		return criteria
	}

	_lookupCriteria(criteria, index, attributes = null, reset = false) {
		if (!(criteria instanceof LookupInput) || reset) {
			const filter = this._filterMap.get(index)
			criteria.destroy()

			filter.criteriaParent.innerHTML = `<div id="filter-item-criteria-${index}"></div>`

			const container = document.getElementById(`filter-item-criteria-${index}`)
			const config = { size: 'sm' }
			if (attributes) {
				if (attributes.placeholder) {
					config.placeholder = attributes.placeholder
				}
				if (attributes.source) {
					config.source = attributes.source
				}
				if (attributes.pagination) {
					config.pagination = true
				}
				if (attributes.multiple) {
					config.multiple = true
				}
			}

			criteria = LookupInput.create(container, config)
			criteria.disabled()
		}

		return criteria
	}

	_datePickerCriteria(criteria, mode, range, index) {
		const filter = this._filterMap.get(index)
		criteria.destroy()
		filter.criteriaParent.innerHTML = this._renderCriteriaInput(index, range ? { range: "range" } : null)
		criteria = new DatePicker(document.getElementById(`filter-item-criteria-${index}`), mode)
		criteria.disabled()

		return criteria
	}

	_numberCriteria(criteria, index) {
		const attributes = {
			number: "number",
			"thousand-separator": ",",
			"decimal-separator": ".",
			"decimal": "2"
		}

		const filter = this._filterMap.get(index)
		criteria.destroy()
		filter.criteriaParent.innerHTML = this._renderCriteriaInput(index, attributes)
		criteria = new MaskInput(document.getElementById(`filter-item-criteria-${index}`))
		criteria.disabled()

		return criteria
	}

	/**
	 * @param {object} criteria
	 * @param {number} index
	 * @returns {CheckboxInput}
	 */
	_booleanCriteria(criteria, index) {
		const filter = this._filterMap.get(index)
		criteria.destroy()
		filter.criteriaParent.innerHTML = `<div class="form-check form-switch pt-1">
			<input class="form-check-input" type="checkbox" role="switch" id="filter-item-criteria-${index}">
		</div>`

		criteria = new CheckboxInput(document.getElementById(`filter-item-criteria-${index}`))
		criteria.disabled()

		return criteria
	}

	_getConditions(type) {
		if (type === 'relation') {
			return [
				{ id: FilterConstants.AggregateType.Count, name: 'Count' },
				{ id: FilterConstants.AggregateType.Sum, name: 'Sum' },
				{ id: FilterConstants.AggregateType.Avg, name: 'Avg' },
				{ id: FilterConstants.AggregateType.Min, name: 'Min' },
				{ id: FilterConstants.AggregateType.Max, name: 'Max' },
				{ id: 'WHERE_HAS', name: 'Has' },
				{ id: 'WHERE_DOESNT_HAVE', name: "Doesn't Have" },
			]
		}

		if (type === 'lookup') {
			const regular = this._conditions.filter(item =>
				['Equal', 'NotEqual', 'In', 'NotIn', 'IsNull', 'IsNotNull']
					.map(m => FilterConstants.OperatorType[m]).includes(item.id)
			)
			return [
				...regular,
				{ id: 'WHERE_HAS', name: 'Has' },
				{ id: 'WHERE_DOESNT_HAVE', name: "Doesn't Have" },
			]
		}

		const map = {
			string: ['Equal', 'NotEqual', 'Contains', 'StartWith', 'EndWith', 'FullText', 'Similar', 'IsEmpty', 'IsNotEmpty'],
			number: ['Equal', 'NotEqual', 'Greater', 'GreaterOrEqual', 'Less', 'LessOrEqual', 'IsNull', 'IsNotNull'],
			boolean: ['Equal'],
			date: [
				'Equal', 'NotEqual', 'Greater', 'GreaterOrEqual', 'Less', 'LessOrEqual', 'Between', 'NotBetween',
				'IsNull', 'IsNotNull',
				'IsToday', 'IsYesterday', 'IsThisWeek', 'IsLastWeek', 'IsThisMonth', 'IsLastMonth', 'IsThisYear', 'IsLastYear',
				'IsYear', 'IsMonth', 'IsDay', 'IsMonthDay',
				'IsLastN', 'IsNextN',
			],
			datetime: [
				'Equal', 'NotEqual', 'Greater', 'GreaterOrEqual', 'Less', 'LessOrEqual', 'Between', 'NotBetween',
				'IsNull', 'IsNotNull',
				'IsToday', 'IsYesterday', 'IsThisWeek', 'IsLastWeek', 'IsThisMonth', 'IsLastMonth', 'IsThisYear', 'IsLastYear',
				'IsYear', 'IsMonth', 'IsDay', 'IsMonthDay',
				'IsLastN', 'IsNextN',
			],
		}

		return this._conditions.filter(item => map[type].map(m => FilterConstants.OperatorType[m]).includes(item.id))
	}

	//#endregion

	//#region drag and drop

	_onDnd_Start(e, dragEl) {
		requestAnimationFrame(() => dragEl.classList.add('opacity-50'))
	}

	_onDnd_End(e, dragEl) {
		dragEl.classList.remove('opacity-50')
		this._dnd.clearIndicators(document.body, ['drag-over', 'merge-target'])
		this._mergeTarget = null
		this._updateLogicalVisibility()
	}

	_onDnd_Over(e, dragEl, targetEl) {
		if (this._getDragScope(dragEl) !== this._getDragScope(targetEl)) {
			return
		}
		if (dragEl.contains(targetEl)) {
			return
		}

		if (dragEl.dataset.type === 'condition') {
			const mergeCandidate = this._getMergeTarget(targetEl, e.clientY)
			if (mergeCandidate) {
				this._mergeTarget = mergeCandidate
				this._dnd.clearIndicators(document.body, ['merge-target'])
				mergeCandidate.classList.add('merge-target')
				targetEl.classList.add('drag-over')
				return
			}
		}

		this._mergeTarget = null
		this._dnd.clearIndicators(document.body, ['merge-target'])
		targetEl.classList.add('drag-over')

		const afterEl = this._dnd.getDragAfterElement(
			targetEl,
			e.clientY,
			':scope > [data-index]:not(.opacity-50)'
		)
		afterEl ? targetEl.insertBefore(dragEl, afterEl) : targetEl.appendChild(dragEl)
	}

	_onDnd_Leave(e, dragEl, targetEl) {
		targetEl.classList.remove('drag-over')
	}

	_onDnd_Drop(e, dragEl, targetEl) {
		targetEl.classList.remove('drag-over')
		this._dnd.clearIndicators(document.body, ['merge-target'])

		if (this._getDragScope(dragEl) !== this._getDragScope(targetEl)) {
			return
		}

		if (this._mergeTarget) {
			this._mergeIntoGroup(dragEl, this._mergeTarget, targetEl)
			this._mergeTarget = null
			return
		}

		this._updateLogicalVisibility()
	}

	_getDragScope(element) {
		let el = element
		while (el) {
			if (el.id?.startsWith('filter-item-sub-container-')) {
				return el.id
			}
			el = el.parentElement
		}
		return 'main'
	}

	_getMergeTarget(container, y) {
		const items = Array.from(container.querySelectorAll(':scope > [data-index][data-type="condition"]:not(.opacity-50)'))
		for (const item of items) {
			const box  = item.getBoundingClientRect()
			const relY = y - box.top
			const zone = box.height * 0.25
			if (relY > zone && relY < box.height - zone) {
				return item
			}
		}
		return null
	}

	_mergeIntoGroup(dragging, target, container) {
		if (target.parentElement !== container) {
			return
		}
		const groupIndex 	 = this._addGroupToContainer(container)
		const groupEl 	 	 = container.querySelector(`.filter-group-${groupIndex}`)
		const groupContainer = document.getElementById(`filter-group-container-${groupIndex}`)

		container.insertBefore(groupEl, target)

		groupContainer.appendChild(target)
		groupContainer.appendChild(dragging)

		this._updateLogicalVisibility()
	}

	_updateLogicalVisibility() {
		const update = (container) => {
			Array.from(container.querySelectorAll(':scope > [data-index]')).forEach((el) => {
				const logicalEl = el.querySelector('[id^="filter-item-logical-"], [id^="filter-group-logical-"]')
				if (logicalEl) {
					logicalEl.style.display = ''
				}
			})
		}
		update(this._filterContainer)
		document.querySelectorAll('.filter-group-container').forEach(c => update(c))
	}

	//#endregion

	_renderAggregateCriteria(filter, index, aggregateType) {
		if (filter.criteria) {
			filter.criteria.destroy()
			filter.criteria = null
		}

		if (filter.criteriaAggregate) {
			filter.criteriaAggregate.column?.destroy()
			filter.criteriaAggregate.operator?.destroy()
			filter.criteriaAggregate.value?.destroy()
			filter.criteriaAggregate = null
		}

		const aggOpKeys = ['Equal', 'NotEqual', 'Greater', 'GreaterOrEqual', 'Less', 'LessOrEqual']
		const aggOpOptions = this._conditions.filter(c => aggOpKeys.map(k => FilterConstants.OperatorType[k]).includes(c.id))

		if (aggregateType === FilterConstants.AggregateType.Count) {
			filter.criteriaParent.innerHTML = `<div class="d-flex gap-1">
                ${this._renderLookupInput("agg-op", index)}
                <input id="filter-item-agg-val-${index}" class="form-control form-control-sm" type="text" number="number" thousand-separator="," decimal-separator="." decimal="0">
            </div>`

			const opInput = LookupInput.create(document.getElementById(`filter-item-agg-op-${index}`), { placeholder: "Op", size: 'sm' })
			const valInput = new MaskInput(document.getElementById(`filter-item-agg-val-${index}`))

			opInput.setOptions(aggOpOptions)

			filter.criteriaAggregate = { column: null, operator: opInput, value: valInput }
		} else {
			const isSumAvg = aggregateType === FilterConstants.AggregateType.Sum || aggregateType === FilterConstants.AggregateType.Avg
			const aggCols = (filter.relationColumns ?? [])
				.filter(col => isSumAvg
					? col.type === 'number'
					: ['number', 'date', 'datetime'].includes(col.type)
				)
				.map(col => ({ id: col.id, name: col.displayName }))

			filter.criteriaParent.innerHTML = `<div class="d-flex flex-column gap-1">
                ${this._renderLookupInput("agg-col", index)}
                <div class="d-flex gap-1">
                    ${this._renderLookupInput("agg-op", index)}
                    <input id="filter-item-agg-val-${index}" class="form-control form-control-sm" type="text" number="number" thousand-separator="," decimal-separator="." decimal="2">
                </div>
            </div>`

			const colInput = LookupInput.create(document.getElementById(`filter-item-agg-col-${index}`), { placeholder: "Column", size: 'sm' })
			const opInput = LookupInput.create(document.getElementById(`filter-item-agg-op-${index}`), { placeholder: "Op", size: 'sm' })
			const valInput = new MaskInput(document.getElementById(`filter-item-agg-val-${index}`))

			colInput.setOptions(aggCols)
			opInput.setOptions(aggOpOptions)

			filter.criteriaAggregate = { column: colInput, operator: opInput, value: valInput }
		}
	}

	_destroyAggregateCriteria(filter, index) {
		if (!filter.criteriaAggregate) {
			return
		}

		filter.criteriaAggregate.column?.destroy()
		filter.criteriaAggregate.operator?.destroy()
		filter.criteriaAggregate.value?.destroy()
		filter.criteriaAggregate = null

		filter.criteriaParent.innerHTML = this._renderCriteriaInput(index)
		filter.criteria = new TextInput(document.getElementById(`filter-item-criteria-${index}`))
		filter.criteria.set(null, true)
		filter.criteria.disabled()
	}

	/**
	 * @param {object} filter
	 * @param {number} index
	 * @param {string} operator
	 */
	_renderDatePartCriteria(filter, index, operator) {
		if (filter.criteria) {
			filter.criteria.destroy()
			filter.criteria = null
		}

		const monthOptions = [
			{ id: 1, name: 'January' }, { id: 2, name: 'February' }, { id: 3, name: 'March' },
			{ id: 4, name: 'April' }, { id: 5, name: 'May' }, { id: 6, name: 'June' },
			{ id: 7, name: 'July' }, { id: 8, name: 'August' }, { id: 9, name: 'September' },
			{ id: 10, name: 'October' }, { id: 11, name: 'November' }, { id: 12, name: 'December' },
		]

		const _nowToggle = () => `
			<input type="checkbox" class="btn-check" id="filter-item-dp-now-${index}" autocomplete="off">
			<label class="btn btn-outline-primary btn-sm" for="filter-item-dp-now-${index}">Now</label>`

		const isMonth    = operator === FilterConstants.OperatorType.IsMonth
		const isDay      = operator === FilterConstants.OperatorType.IsDay
		const isYear     = operator === FilterConstants.OperatorType.IsYear
		const isMonthDay = operator === FilterConstants.OperatorType.IsMonthDay

		let monthInput = null
		let dayInput   = null
		let yearInput  = null

		if (isMonth) {
			filter.criteriaParent.innerHTML = `<div class="d-flex align-items-center gap-1">
				<div id="filter-item-dp-month-${index}" style="flex: 1"></div>
				${_nowToggle()}
			</div>`
			monthInput = LookupInput.create(document.getElementById(`filter-item-dp-month-${index}`), { placeholder: 'Month', size: 'sm' })
			monthInput.setOptions(monthOptions)
		} else if (isDay) {
			filter.criteriaParent.innerHTML = `<div class="d-flex align-items-center gap-1">
				<input id="filter-item-dp-day-${index}" class="form-control form-control-sm" style="flex: 1" type="text" number="number" thousand-separator="" decimal-separator="." decimal="0" placeholder="1 – 31">
				${_nowToggle()}
			</div>`
			dayInput = new MaskInput(document.getElementById(`filter-item-dp-day-${index}`))
		} else if (isYear) {
			filter.criteriaParent.innerHTML = `<div class="d-flex align-items-center gap-1">
				<input id="filter-item-dp-year-${index}" class="form-control form-control-sm" style="flex: 1" type="text" number="number" thousand-separator="" decimal-separator="." decimal="0" placeholder="Year">
				${_nowToggle()}
			</div>`
			yearInput = new MaskInput(document.getElementById(`filter-item-dp-year-${index}`))
		} else {
			filter.criteriaParent.innerHTML = `<div class="d-flex align-items-center gap-1">
				<div id="filter-item-dp-month-${index}" style="flex: 1"></div>
				<input id="filter-item-dp-day-${index}" class="form-control form-control-sm" style="max-width: 60px" type="text" number="number" thousand-separator="" decimal-separator="." decimal="0" placeholder="Day">
				${_nowToggle()}
			</div>`
			monthInput = LookupInput.create(document.getElementById(`filter-item-dp-month-${index}`), { placeholder: 'Month', size: 'sm' })
			monthInput.setOptions(monthOptions)
			dayInput = new MaskInput(document.getElementById(`filter-item-dp-day-${index}`))
		}

		const nowCheck = document.getElementById(`filter-item-dp-now-${index}`)
		nowCheck?.addEventListener('change', () => {
			if (nowCheck.checked) {
				monthInput?.disabled()
				dayInput?.disabled()
				yearInput?.disabled()
			} else {
				monthInput?.enabled()
				dayInput?.enabled()
				yearInput?.enabled()
			}
		})

		filter.criteriaDatePart = { month: monthInput, day: dayInput, year: yearInput }
	}

	/**
	 * @param {object} filter
	 * @param {number} index
	 */
	_destroyDatePartCriteria(filter, index) {
		if (!filter.criteriaDatePart) {
			return
		}

		filter.criteriaDatePart.month?.destroy()
		filter.criteriaDatePart.day?.destroy()
		filter.criteriaDatePart.year?.destroy()
		filter.criteriaDatePart = null

		const col = filter.columns.find(c => c.id == filter.field.get()?.id)
		filter.criteriaParent.innerHTML = this._renderCriteriaInput(index)
		filter.criteria = (col?.type === 'date' || col?.type === 'datetime')
			? this._datePickerCriteria(new TextInput(document.getElementById(`filter-item-criteria-${index}`)), col.type, false, index)
			: new TextInput(document.getElementById(`filter-item-criteria-${index}`))
		filter.criteria.disabled()
	}

	/**
	 * @param {object} filter
	 * @param {number} index
	 */
	_renderRelativeDateCriteria(filter, index) {
		if (filter.criteria) {
			filter.criteria.destroy()
			filter.criteria = null
		}

		const unitOptions = Object.entries(FilterConstants.PeriodUnit).map(([key, val]) => ({ id: val, name: key }))
		const dirOptions  = [
			{ id: 'past',   name: 'Ago' },
			{ id: 'future', name: 'From Now' },
		]

		filter.criteriaParent.innerHTML = `<div class="d-flex flex-column gap-1">
			<div class="d-flex gap-1">
				<input id="filter-item-rel-n-${index}" class="form-control form-control-sm" style="flex: 1" type="text" number="number" thousand-separator="" decimal-separator="." decimal="0">
				<div id="filter-item-rel-unit-${index}" style="flex: 1"></div>
			</div>
			<div id="filter-item-rel-dir-${index}"></div>
		</div>`

		const nInput   = new MaskInput(document.getElementById(`filter-item-rel-n-${index}`))
		const unitInput = LookupInput.create(document.getElementById(`filter-item-rel-unit-${index}`), { placeholder: 'Unit', size: 'sm' })
		const dirInput  = LookupInput.create(document.getElementById(`filter-item-rel-dir-${index}`), { placeholder: 'Direction', size: 'sm' })

		unitInput.setOptions(unitOptions)
		dirInput.setOptions(dirOptions)

		filter.criteriaRelative = { n: nInput, unit: unitInput, direction: dirInput }

		document.getElementById(`filter-item-relative-toggle-${index}`)?.classList.add('active')
	}

	/**
	 * @param {object} filter
	 * @param {number} index
	 */
	_destroyRelativeDateCriteria(filter, index) {
		if (!filter.criteriaRelative) {
			return
		}

		filter.criteriaRelative.n?.destroy()
		filter.criteriaRelative.unit?.destroy()
		filter.criteriaRelative.direction?.destroy()
		filter.criteriaRelative = null

		const col = filter.columns.find(c => c.id == filter.field.get()?.id)
		filter.criteriaParent.innerHTML = this._renderCriteriaInput(index)
		filter.criteria = col?.type === 'date' || col?.type === 'datetime'
			? this._datePickerCriteria(new TextInput(document.getElementById(`filter-item-criteria-${index}`)), col.type, false, index)
			: new TextInput(document.getElementById(`filter-item-criteria-${index}`))
		filter.criteria.enabled()

		document.getElementById(`filter-item-relative-toggle-${index}`)?.classList.remove('active')
	}

	/**
	 * @param {object} filter
	 * @param {number} index
	 */
	_renderPeriodCriteria(filter, index) {
		if (filter.criteria) {
			filter.criteria.destroy()
			filter.criteria = null
		}

		const unitOptions = Object.entries(FilterConstants.PeriodUnit).map(([key, val]) => ({ id: val, name: key }))

		filter.criteriaParent.innerHTML = `<div class="d-flex gap-1">
			<input id="filter-item-period-n-${index}" class="form-control form-control-sm" style="flex: 1" type="text" number="number" thousand-separator="" decimal-separator="." decimal="0">
			<div id="filter-item-period-unit-${index}" style="flex: 1"></div>
		</div>`

		const nInput   = new MaskInput(document.getElementById(`filter-item-period-n-${index}`))
		const unitInput = LookupInput.create(document.getElementById(`filter-item-period-unit-${index}`), { placeholder: 'Unit', size: 'sm' })
		unitInput.setOptions(unitOptions)

		filter.criteriaPeriod = { n: nInput, unit: unitInput }
	}

	/**
	 * @param {object} filter
	 * @param {number} index
	 */
	_destroyPeriodCriteria(filter, index) {
		if (!filter.criteriaPeriod) {
			return
		}

		filter.criteriaPeriod.n?.destroy()
		filter.criteriaPeriod.unit?.destroy()
		filter.criteriaPeriod = null

		filter.criteriaParent.innerHTML = this._renderCriteriaInput(index)
		filter.criteria = new TextInput(document.getElementById(`filter-item-criteria-${index}`))
		filter.criteria.set(null, true)
		filter.criteria.disabled()
	}

	_destroySubContainerConditions(index) {
		const subContainer = document.getElementById(`filter-item-sub-container-${index}`)
		if (!subContainer) {
			return
		}

		subContainer.querySelectorAll('[data-index]').forEach(el => {
			const childIndex = parseInt(el.dataset.index)
			const childItem = this._filterMap.get(childIndex)
			if (!childItem || childItem.type !== 'condition') {
				return
			}

			childItem.field.destroy()
			childItem.condition.destroy()
			childItem.criteria?.destroy()
			childItem.logical?.destroy()
			childItem.criteriaAggregate?.column?.destroy()
			childItem.criteriaAggregate?.operator?.destroy()
			childItem.criteriaAggregate?.value?.destroy()
			childItem.criteriaPeriod?.n?.destroy()
			childItem.criteriaPeriod?.unit?.destroy()
			childItem.criteriaRelative?.n?.destroy()
			childItem.criteriaRelative?.unit?.destroy()
			childItem.criteriaRelative?.direction?.destroy()
			childItem.criteriaDatePart?.month?.destroy()
			childItem.criteriaDatePart?.day?.destroy()

			this._filterMap.delete(childIndex)
		})

		subContainer.innerHTML = ''
	}

	async _getAllColumns(model = null) {
		const key = model ?? this._model
		if (this._allColumnsCache.has(key)) {
			return this._allColumnsCache.get(key)
		}

		const req = await axios({
			method: "GET",
			url: `${BASE_URL}/core/folder/all-columns`,
			headers: { 'X-Folder-Model': key }
		})

		this._allColumnsCache.set(key, req.data)
		return req.data
	}
}
