import Helper from "./helper";
import Modal from "./modal";
import SolarComponent from "./solar/solar-component";
import DragDropHelper from "./drag-drop";

export default class Tree extends SolarComponent {
    constructor(selector) {
        super()

        if (selector instanceof HTMLElement) {
            this._element = selector
        } else if (Helper.isString(selector) && !Helper.isEmpty(selector)) {
            this._element = document.querySelector(selector)
            if (!this._element) {
                throw new Error(`Element with query selector ${selector} is not found`)
            }
        } else {
            throw new Error(`Selector is not valid`)
        }

        this.id = this._element.id
        this._index = 0

        this._preInit()
        if (!this._element.hasAttribute("lazy")) {
            this.render()
        }
    }

    static supportedEvent() {
        return [
            "ready",
            "adding",
            "added",
            "edit",
            "editing",
            "edited",
            "delete",
            "move",
            "select",
            "node-created"
        ];
    }

    _preInit() {
        this._root = this._element.querySelector("ul.tree-root")

        this._initDeleteModal()
        this._initDefaults()
        this._initDragDrop()
    }

    _initDragDrop() {
        this._dnd = new DragDropHelper(this._element, {
            draggable: '.tree-item',
            handle: '.tree-drag-handle',
            dropZone: '.tree-item',
            zones: true,
            data: (el) => el.closest('.tree-node')?.dataset.id ?? ''
        })
        .on('start', this._onDnd_Start.bind(this), "Tree")
        .on('end', this._onDnd_End.bind(this), "Tree")
        .on('over', this._onDnd_Over.bind(this), "Tree")
        .on('leave', this._onDnd_Leave.bind(this), "Tree")
        .on('drop', this._onDnd_Drop.bind(this), "Tree")
    }

    _initDefaults() {
        this._config = {
            defaultName: "New Item",
            placeholderText: "Drop here to move to end",
            icons: {
                drag: "ri-draggable",
                collapse: "ri-arrow-down-s-line",
                dropdown: "ri-more-fill",
                addChild: "ri-add-line",
                edit: "ri-pencil-line",
                delete: "ri-delete-bin-line",
                save: "ri-check-line",
                discard: "ri-close-line"
            },
            labels: {
                addChild: "Add Child",
                edit: "Edit",
                delete: "Delete",
                save: "Save",
                discard: "Discard"
            }
        }
    }

    _initDeleteModal() {
        this._deleteModal = new Modal(`#${this.id}_delete_modal`)

        this._deleteMessage = this._deleteModal._element.querySelector('.delete_message')
        this._deleteAllBtn = this._deleteModal._element.querySelector('.delete-all-btn')
        this._deleteParentBtn = this._deleteModal._element.querySelector('.delete-parent-btn')
        this._deleteNodeId = this._deleteModal._element.querySelector('input[name="delete_node_id"]')
        this._deleteMessage = this._deleteModal._element.querySelector('.delete_message')
        this._deleteAllLabel = this._deleteModal._element.querySelector('.delete-all-label')
        this._deleteParentLabel = this._deleteModal._element.querySelector('.delete-parent-label')

        this._deleteAllBtn.addEventListener("click", () => {
            this._deleteAll(this._deleteNodeId.value)
            this._deleteModal.hide()
        })

        this._deleteParentBtn.addEventListener("click", () => {
            this._deleteNodeOnly(this._deleteNodeId.value)
            this._deleteModal.hide()
        })
    }

    async render() {
        this._root.innerHTML = ""

        this._data.forEach(node => {
            node.element = this._renderNode(node, 0)
            this._root.appendChild(node.element)
        })

        this._initRootPlaceholder()

        await this.trigger("ready")
    }

    async addRoot() {
        const node = this._createNode()

        node.element = this._renderNode(node, 0)

        const placeholder = this._root.querySelector(".tree-root-placeholder")
        if (placeholder) {
            this._root.insertBefore(node.element, placeholder)
        } else {
            this._root.appendChild(node.element)
            this._initRootPlaceholder()
        }

        this._data.push(node)

        await this.trigger("adding", node)
    }

    async addChild(parentId) {
        const parent = this.find(parentId)
        if (!parent) {
            return
        }

        if (parent._state == "new") {
            return
        }

        const node = this._createNode({
            parent_id: parentId
        })
        node.element = this._renderNode(node, 0)

        if (!parent.children) {
            parent.children = []

            const childrenUl = document.createElement("ul")
            childrenUl.className = "tree-children"

            parent.element.querySelector(".tree-toggle").classList.remove("invisible")
            parent.element.appendChild(childrenUl)
        }

        if (parent.element.classList.contains("collapsed")) {
            parent.element.classList.remove("collapsed")
        }

        parent.children.push(node)
        parent.element.querySelector(".tree-children").appendChild(node.element)

        await this.trigger("adding", node)
    }

    find(nodeId, nodes = this._data) {
        for (const node of nodes) {
            if (node.id === nodeId) {
                return node
            }

            if (node.children && node.children.length > 0) {
                const found = this.find(nodeId, node.children)
                if (found) {
                    return found;
                }
            }
        }

        return null
    }

    async delete(nodeId, withChildren = true) {
        return withChildren ? this._deleteAll(nodeId) : this._deleteNodeOnly(nodeId)
    }

    toogle(nodeId) {
        const node = this.find(nodeId)
        if (!node) {
            return
        }

        node.element?.classList.toggle("collapsed")
    }

    collapseAll() {
        this._toggleAll(this._data, true)
    }

    expandAll() {
        this._toggleAll(this._data, false)
    }

    _toggleAll(nodes, collapse) {
        if (!nodes) return
        nodes.forEach(node => {
            if (node.children && node.children.length > 0) {
                if (collapse) {
                    node.element?.classList.add("collapsed")
                } else {
                    node.element?.classList.remove("collapsed")
                }
                this._toggleAll(node.children, collapse)
            }
        })
    }

    setDefaultName(name) {
        this._config.defaultName = name
    }

    setPlaceholderText(text) {
        this._config.placeholderText = text
    }

    setIcons(icons) {
        Object.assign(this._config.icons, icons)
    }

    setLabels(labels) {
        Object.assign(this._config.labels, labels)
    }

    setData(data, forceRender = false) {
        if (!Array.isArray(data)) {
            throw new Error("Data must be an array")
        }

        this._data = this._normalizeData(data)
        this._updateMaxIndex(this._data)

        if (forceRender) {
            this.render()
        }
    }

    getData() {
        return this._cleanData(this._data)
    }

    _normalizeData(nodes, parentId = null) {
        return nodes
            .map(node => ({
                id: node.id?.toString() || (this._index++).toString(),
                name: node.name || this._config.defaultName,
                position: node.position || 0,
                parent_id: parentId,
                children: node.children && node.children.length > 0
                    ? this._normalizeData(node.children, node.id?.toString())
                    : null,
                _state: "clean"
            }))
            .sort((a, b) => a.position - b.position)
    }

    _cleanData(nodes) {
        if (!nodes) return null

        return nodes.map(node => ({
            id: node.id,
            name: node.name,
            position: node.position,
            parent_id: node.parent_id,
            children: this._cleanData(node.children)
        }))
    }

    _updateMaxIndex(nodes) {
        nodes.forEach(node => {
            const numId = parseInt(node.id, 10)
            if (!isNaN(numId) && numId >= this._index) {
                this._index = numId + 1
            }
            if (node.children) {
                this._updateMaxIndex(node.children)
            }
        })
    }

    _renderNode(node, level) {
        const li = document.createElement("li")
        li.className = "tree-node"
        li.dataset.id = node.id

        const hasChildren = node.children && node.children.length > 0
        if (hasChildren) {
            li.classList.add("has-children")
        }

        const item = document.createElement("div")
        item.className = "tree-item d-flex align-items-center gap-2 py-2 px-3"
        item.innerHTML = this._nodeTemplate(node, hasChildren)
        li.appendChild(item)

        if (node._state !== "new") {
            item.setAttribute("draggable", "true")
        }

        this._bindNodeEvents(item, node)
        if (node._state !== "new") {
            this.trigger("node-created", item, node)
        }

        if (hasChildren) {
            const childrenUl = document.createElement("ul")
            childrenUl.className = "tree-children"

            node.children.forEach(child => {
                child.element = this._renderNode(child, level + 1)
                childrenUl.appendChild(child.element)
            })

            const placeholder = this._createDropPlaceholder()
            childrenUl.appendChild(placeholder)

            li.appendChild(childrenUl)
        }

        return li
    }

    _nodeTemplate(node, hasChildren) {
        const isNew = node._state === "new"
        const { icons, labels } = this._config

        return `
            <span class="tree-drag-handle d-flex align-items-center justify-content-center ${isNew ? 'd-none' : ''}">
                <i class="${icons.drag}"></i>
            </span>
            <span class="tree-toggle d-flex align-items-center justify-content-center ${hasChildren ? '' : 'invisible'}">
                <i class="${icons.collapse}"></i>
            </span>
            <div class="dropdown ${isNew ? 'd-none' : ''}">
                <button type="button" class="btn btn-sm btn-light btn-icon" data-bs-toggle="dropdown">
                    <i class="${icons.dropdown}"></i>
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item action-add-child" href="#"><i class="${icons.addChild} me-2"></i>${labels.addChild}</a></li>
                    <li><a class="dropdown-item action-edit" href="#"><i class="${icons.edit} me-2"></i>${labels.edit}</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item text-danger action-delete" href="#"><i class="${icons.delete} me-2"></i>${labels.delete}</a></li>
                </ul>
            </div>
            <span class="tree-actions d-flex gap-1 ${isNew ? '' : 'd-none'}">
                <button type="button" class="btn btn-sm btn-success btn-icon action-save" title="${labels.save}">
                    <i class="${icons.save}"></i>
                </button>
                <button type="button" class="btn btn-sm btn-light btn-icon action-discard" title="${labels.discard}">
                    <i class="${icons.discard}"></i>
                </button>
            </span>
            <span class="flex-grow-1 text-truncate">
                <input type="text" class="tree-input form-control form-control-sm ${isNew ? '' : 'd-none'}" value="${node.name}" />
                <span class="tree-name ${isNew ? 'd-none' : ''}">${node.name}</span>
            </span>
        `
    }

    _createNode(overrides = {}) {
        const GAP = 1000
        const siblings = overrides.parent_id
            ? this.find(overrides.parent_id)?.children || []
            : this._data
        const maxPosition = siblings.reduce((max, n) => Math.max(max, n.position || 0), 0)

        return {
            id: (this._index++).toString(),
            name: this._config.defaultName,
            children: null,
            parent_id: null,
            position: maxPosition + GAP,
            _state: "new",
            ...overrides
        }
    }

    async _deleteAll(nodeId, isSilent = false) {
        const node = this.find(nodeId)
        if (!node) {
            return false
        }

        if (!isSilent && !await this._triggerEvent("delete", node, "all")) {
            return false
        }

        if (node.parent_id) {
            const parent = this.find(node.parent_id)
            if (parent && parent.children) {
                parent.children = parent.children.filter(n => n.id !== nodeId)
                if (parent.children.length === 0) {
                    parent.children = null
                    parent.element.querySelector(".tree-toggle").classList.add("invisible")
                    parent.element.querySelector(".tree-children")?.remove()
                }
            }
        } else {
            this._data = this._data.filter(n => n.id !== nodeId)
        }

        node.element?.remove()

        return true
    }

    async _deleteNodeOnly(nodeId, isSilent = false) {
        const node = this.find(nodeId)
        if (!node) {
            return false
        }

        if (!isSilent && !await this._triggerEvent("delete", node, "node-only")) {
            return false
        }

        const children = node.children || []

        if (node.parent_id != null) {
            const parent = this.find(node.parent_id)
            if (parent && parent.children) {
                const nodeIndex = parent.children.findIndex(n => n.id === nodeId)

                children.forEach(child => {
                    child.parent_id = node.parent_id
                })

                parent.children.splice(nodeIndex, 1, ...children)

                if (children.length > 0) {
                    const parentChildrenUl = parent.element.querySelector(".tree-children")
                    children.forEach(child => {
                        parentChildrenUl.insertBefore(child.element, node.element)
                    })
                }

                if (parent.children.length === 0) {
                    parent.children = null
                    parent.element.querySelector(".tree-toggle").classList.add("invisible")
                    parent.element.querySelector(".tree-children")?.remove()
                }
            }
        } else {
            const nodeIndex = this._data.findIndex(n => n.id === nodeId)

            children.forEach(child => {
                child.parent_id = null
            })

            this._data.splice(nodeIndex, 1, ...children)

            children.forEach(child => {
                this._root.insertBefore(child.element, node.element)
            })
        }

        node.element?.remove()

        return true
    }

    async _triggerEvent(eventName, ...args) {
        const results = await this.trigger(eventName, ...args)
        const hasListeners = results && Array.isArray(results) && results.length > 0
        const allSuccess = hasListeners && results.every(res => res !== false)

        if (hasListeners) {
            return allSuccess
        }

        return true
    }

    /**
     * Update node data and sync UI
     * @param {string} nodeId 
     * @param {object} data - { id?, name?, ...other fields }
     * @returns {object|null} The updated node or null if not found
     */
    updateNode(nodeId, data) {
        const node = this.find(nodeId)
        if (!node) return null

        const oldId = node.id
        Object.assign(node, data)

        if (data.id !== undefined && data.id !== oldId && node.element) {
            node.element.dataset.id = node.id
        }

        if (data.name !== undefined) {
            const nameEl = node.element?.querySelector(".tree-name")
            if (nameEl) nameEl.textContent = node.name
        }

        node._state = "clean"

        return node
    }

    _bindNodeEvents(item, node) {
        const dropdown = item.querySelector(".dropdown")
        const saveBtn = item.querySelector(".action-save")
        const discardBtn = item.querySelector(".action-discard")
        const addChildBtn = item.querySelector(".action-add-child")
        const editBtn = item.querySelector(".action-edit")
        const deleteBtn = item.querySelector(".action-delete")
        const input = item.querySelector(".tree-input")
        const displayName = item.querySelector(".tree-name")
        const toggle = item.querySelector(".tree-toggle")
        const actions = item.querySelector(".tree-actions")

        const elements = { displayName, input, dropdown, actions }

        toggle?.addEventListener("click", (e) => {
            e.stopPropagation()
            this.toogle(node.id)
        })

        // Double click = always inline edit
        displayName?.addEventListener("dblclick", async (e) => {
            e.stopPropagation()
            await this._startEdit(node, elements)
        })

        // Dropdown Edit = interceptable via 'edit' event
        editBtn?.addEventListener("click", async (e) => {
            e.preventDefault()
            if (this._events.has("edit")) {
                node._state = "edit"
                await this.trigger("edit", node)
            } else {
                await this._startEdit(node, elements)
            }
        })

        addChildBtn?.addEventListener("click", async (e) => {
            e.preventDefault()
            await this.addChild(node.id)
        })

        deleteBtn?.addEventListener("click", async (e) => {
            e.preventDefault()

            this._deleteNodeId.value = node.id

            if (node.children && node.children.length > 0) {
                this._deleteMessage.textContent = `"${node.name}" has ${node.children.length} submenu(s). How do you want to delete?`
                this._deleteAllLabel.textContent = `Delete menu and all ${node.children.length} submenu(s)`
                this._deleteParentLabel.textContent = `Delete menu only (submenus move up)`

                this._deleteModal.show()
            } else if (await Helper.confirmDelete({ title: "Delete confirmation", message: "Are you sure" })) {
                await this._deleteNodeOnly(node.id)
            }
        })

        saveBtn?.addEventListener("click", async (e) => {
            e.stopPropagation()
            await this._saveNode(node, elements)
        })

        discardBtn?.addEventListener("click", (e) => {
            e.stopPropagation()
            this._discardEdit(node, elements)
        })

        input?.addEventListener("keydown", async (e) => {
            if (e.key === "Enter") {
                e.preventDefault()
                await this._saveNode(node, elements)
            } else if (e.key === "Escape") {
                e.preventDefault()
                this._discardEdit(node, elements)
            }
        })

        if (node._state === "new") {
            setTimeout(() => {
                input?.focus()
                input?.select()
            }, 0)
        }
    }

    async _startEdit(node, { displayName, input, dropdown, actions }) {
        if (node._state === "new" || node._state === "edit") {
            return
        }

        node._originalName = node.name
        node._state = "edit"

        input.value = node.name
        displayName.classList.add("d-none")
        input.classList.remove("d-none")
        dropdown.classList.add("d-none")
        actions.classList.remove("d-none")

        input.focus()
        input.select()

        await this.trigger("editing", node)
    }

    async _saveNode(node, { displayName, dropdown, input, actions }) {
        const wasNew = node._state === "new"
        const originalName = node._originalName
        const newName = input.value.trim() || this._config.defaultName

        // Optimistically update UI first
        node.name = newName
        node._state = "clean"
        delete node._originalName

        displayName.textContent = node.name
        displayName.classList.remove("d-none")
        dropdown.classList.remove("d-none")
        input.classList.add("d-none")
        actions.classList.add("d-none")

        if (wasNew) {
            const item = node.element.querySelector(".tree-item")
            const dragHandle = item.querySelector(".tree-drag-handle")

            dragHandle?.classList.remove("d-none")
            item.setAttribute("draggable", "true")

            const success = await this._triggerEvent("added", node)
            if (!success) {
                // Revert: delete the node
                this._deleteNodeOnly(node.id, true)
            } else {
                this.trigger("node-created", item, node)
            }
        } else {
            const success = await this._triggerEvent("edited", node)
            if (!success) {
                // Revert: restore original name
                node.name = originalName
                node._state = "clean"
                displayName.textContent = node.name
            }
        }
    }

    _discardEdit(node, { displayName, input, dropdown, actions }) {
        if (node._state === "new") {
            this._deleteNodeOnly(node.id, true)
            return
        }

        if (node._state === "edit") {
            node.name = node._originalName
            node._state = "clean"
            delete node._originalName

            displayName.textContent = node.name
            displayName.classList.remove("d-none")
            input.classList.add("d-none")
            dropdown.classList.remove("d-none")
            actions.classList.add("d-none")
        }
    }

    _createDropPlaceholder() {
        const placeholder = document.createElement("li")
        placeholder.className = "tree-drop-placeholder"
        placeholder.innerHTML = `<div class="tree-drop-zone">${this._config.placeholderText}</div>`

        placeholder.addEventListener("dragover", (e) => {
            e.preventDefault()
            placeholder.classList.add("drag-over")
        })

        placeholder.addEventListener("dragleave", () => {
            placeholder.classList.remove("drag-over")
        })

        placeholder.addEventListener("drop", (e) => {
            e.preventDefault()
            placeholder.classList.remove("drag-over")

            const nodeId = e.dataTransfer.getData("text/plain")
            const parentLi = placeholder.closest(".tree-node")
            const parentId = parentLi ? parentLi.dataset.id : null

            this.move(nodeId, parentId, "last")
        })

        return placeholder
    }

    _initRootPlaceholder() {
        const placeholder = this._createDropPlaceholder()
        placeholder.classList.add("tree-root-placeholder")
        this._root.appendChild(placeholder)
    }

    _onDnd_Start(e, dragEl) {
        const nodeId = dragEl.closest('.tree-node')?.dataset.id
        const node = this.find(nodeId)
        if (!node) return
        this._draggedNode = node
        setTimeout(() => { node.element.classList.add('dragging') }, 0)
    }

    _onDnd_End(e, dragEl) {
        this._draggedNode?.element.classList.remove('dragging')
        this._draggedNode = null
        this._clearDropIndicators()
    }

    _onDnd_Over(e, dragEl, targetEl, zone) {
        const targetNode = this.find(targetEl.closest('.tree-node')?.dataset.id)
        if (!this._draggedNode || !targetNode) return
        if (this._draggedNode.id === targetNode.id) return
        if (this._isDescendantOf(targetNode.id, this._draggedNode.id)) return

        this._clearDropIndicators()

        if (zone === 'before') targetEl.classList.add('drop-before')
        else if (zone === 'after') targetEl.classList.add('drop-after')
        else targetEl.classList.add('drop-inside')
    }

    _onDnd_Leave(e, dragEl, targetEl) {
        targetEl.classList.remove('drop-before', 'drop-after', 'drop-inside')
    }

    _onDnd_Drop(e, dragEl, targetEl, zone) {
        const dragNodeId = dragEl.closest('.tree-node')?.dataset.id
        const targetNode = this.find(targetEl.closest('.tree-node')?.dataset.id)
        if (!targetNode || dragNodeId === targetNode.id) return
        if (this._isDescendantOf(targetNode.id, dragNodeId)) return

        this._clearDropIndicators()

        if (zone === 'before') {
            this.move(dragNodeId, targetNode.parent_id, 'before', targetNode.id)
        } else if (zone === 'after') {
            this.move(dragNodeId, targetNode.parent_id, 'after', targetNode.id)
        } else {
            this.move(dragNodeId, targetNode.id, 'last')
        }
    }

    _clearDropIndicators() {
        this._element.querySelectorAll(".drop-before, .drop-after, .drop-inside, .drag-over").forEach(el => {
            el.classList.remove("drop-before", "drop-after", "drop-inside", "drag-over")
        })
    }

    _isDescendantOf(childId, parentId) {
        const parent = this.find(parentId)
        if (!parent || !parent.children) return false

        for (const child of parent.children) {
            if (child.id === childId) return true
            if (this._isDescendantOf(childId, child.id)) return true
        }
        return false
    }

    async move(nodeId, newParentId, position, referenceId = null) {
        const node = this.find(nodeId)
        if (!node) return false

        if (node.id === newParentId) return false
        if (newParentId && this._isDescendantOf(newParentId, nodeId)) return false

        const oldParentId = node.parent_id
        const oldParent = oldParentId ? this.find(oldParentId) : null
        const newParent = newParentId ? this.find(newParentId) : null

        if (oldParent && oldParent.children) {
            oldParent.children = oldParent.children.filter(n => n.id !== nodeId)
            if (oldParent.children.length === 0) {
                oldParent.children = null
                oldParent.element.querySelector(".tree-toggle")?.classList.add("invisible")
                oldParent.element.querySelector(".tree-children")?.remove()
            }
        } else if (!oldParentId) {
            this._data = this._data.filter(n => n.id !== nodeId)
        }

        node.parent_id = newParentId

        let targetList, targetData
        if (newParent) {
            if (!newParent.children) {
                newParent.children = []
                const childrenUl = document.createElement("ul")
                childrenUl.className = "tree-children"

                const placeholder = this._createDropPlaceholder()
                childrenUl.appendChild(placeholder)

                newParent.element.querySelector(".tree-toggle")?.classList.remove("invisible")
                newParent.element.appendChild(childrenUl)
            }
            targetList = newParent.element.querySelector(".tree-children")
            targetData = newParent.children
        } else {
            targetList = this._root
            targetData = this._data
        }

        if (position === "last") {
            const placeholder = targetList.querySelector(":scope > .tree-drop-placeholder")
            if (placeholder) {
                targetList.insertBefore(node.element, placeholder)
            } else {
                targetList.appendChild(node.element)
            }
            targetData.push(node)
        } else if (position === "before" && referenceId) {
            const refNode = this.find(referenceId)
            if (refNode && refNode.element.parentNode) {
                refNode.element.parentNode.insertBefore(node.element, refNode.element)
                const refIndex = targetData.findIndex(n => n.id === referenceId)
                targetData.splice(refIndex, 0, node)
            }
        } else if (position === "after" && referenceId) {
            const refNode = this.find(referenceId)
            if (refNode && refNode.element.parentNode) {
                refNode.element.parentNode.insertBefore(node.element, refNode.element.nextSibling)
                const refIndex = targetData.findIndex(n => n.id === referenceId)
                targetData.splice(refIndex + 1, 0, node)
            }
        }

        node.position = this._calculateNewPosition(targetData, position, referenceId)

        const success = await this._triggerEvent("move", node, node.parent_id, node.position, oldParentId)
        if (!success) {
            // Event handler returned false - but we already moved the node
            // For now, log warning. Full revert would require storing original state.
            console.warn("Move event handler returned false. Manual refresh may be needed.")
        }

        return true
    }

    _calculateNewPosition(siblings, position, referenceId = null) {
        const GAP = 1000
        const sortedSiblings = [...siblings].sort((a, b) => a.position - b.position)

        if (position === "last" || !referenceId) {
            const maxPos = sortedSiblings.length > 0
                ? sortedSiblings[sortedSiblings.length - 1].position
                : 0
            return maxPos + GAP
        }

        const refIndex = sortedSiblings.findIndex(n => n.id === referenceId)
        if (refIndex === -1) {
            return GAP
        }

        const refNode = sortedSiblings[refIndex]

        if (position === "before") {
            const prevNode = refIndex > 0 ? sortedSiblings[refIndex - 1] : null
            const prevPos = prevNode ? prevNode.position : 0
            return (prevPos + refNode.position) / 2
        }

        if (position === "after") {
            const nextNode = refIndex < sortedSiblings.length - 1 ? sortedSiblings[refIndex + 1] : null
            const nextPos = nextNode ? nextNode.position : refNode.position + GAP
            return (refNode.position + nextPos) / 2
        }

        return GAP
    }
}