import Button from "./button"
import Helper from "./helper"
import axios from "@core-js/libs/axios"
import Toast from "./toast"

export default class InAppNotification {

	constructor(selector) {
		if (selector instanceof Element) {
			this._element = selector
		} else if (Helper.isString(selector) && !Helper.isEmpty(selector)) {
			this._element = document.querySelector(selector)
			if (!this._element) {
				throw new Error(`Element with query selector ${selector} is not found`)
			}
		} else {
			throw new Error(`Selector is not supported`)
		}

		this._id            = this._element.getAttribute('solar-id') || this._element.id
		this._pulse         = document.getElementById(`${this._id}_pulse`)
		this._offcanvasEl   = document.getElementById(`${this._id}_offcanvas`)
		this._offcanvasBody = this._offcanvasEl?.querySelector('.offcanvas-body')
		this._notifPane     = document.getElementById(`${this._id}_tab_notif`)
		this._exportPane    = document.getElementById(`${this._id}_tab_export`)
		this._importPane    = document.getElementById(`${this._id}_tab_import`)
		this._notifList     = document.getElementById(`${this._id}_notif_list`)
		this._notifEmpty    = document.getElementById(`${this._id}_notif_empty`)
		this._exportList    = document.getElementById(`${this._id}_export_list`)
		this._exportEmpty   = document.getElementById(`${this._id}_export_empty`)
		this._importList    = document.getElementById(`${this._id}_import_list`)
		this._importEmpty   = document.getElementById(`${this._id}_import_empty`)
		this._notifBadge    = document.getElementById(`${this._id}_notif_badge`)

		const totalNonDismissed = parseInt(this._element.getAttribute('total') || '0')
		const totalUnread       = parseInt(this._element.getAttribute('unread-total') || '0')

		this._notifState  = {
			page:        2,
			length:      10,
			total:       totalNonDismissed,
			unreadTotal: totalUnread,
			hasMore:     this._element.getAttribute('notif-has-more') === 'true',
			loading:     false,
		}
		this._exportState = {
			start:   this._exportList?.querySelectorAll('li').length ?? 0,
			length:  10,
			total:   parseInt(this._element.getAttribute('total-export') || '0'),
			loading: false,
		}
		this._importState = {
			start:   this._importList?.querySelectorAll('li').length ?? 0,
			length:  10,
			total:   parseInt(this._element.getAttribute('total-import') || '0'),
			loading: false,
		}

		this.init()
	}

	init() {
		const refreshBtn = document.getElementById(`${this._id}_refresh`)
		if (refreshBtn) {
			this._refreshBtn = new Button(refreshBtn)
			this._refreshBtn.enabled()
			this._refreshBtn.on('click', () => this.refresh())
		}

		this._setPulse(this._notifState.unreadTotal > 0)
		this._bindNotifActions()
		this._bindExpandText()
		this._bindInfiniteScroll()
		this._listenBroadcast()
	}

	refresh() {
		this.refreshInapp()
		this.refreshExport()
		this.refreshImport()
	}

	refreshInapp() {
		this._notifState.page    = 1
		this._notifState.hasMore = true
		this._fetchNotif()
	}

	refreshExport() {
		this._exportState.start = 0
		this._fetchExport()
	}

	refreshImport() {
		this._importState.start = 0
		this._fetchImport()
	}

	// #region fetch

	async _fetchNotif(append = false) {
		const state = this._notifState
		if (state.loading) return
		if (append && !state.hasMore) return
		if (!append) state.page = 1

		state.loading = true
		try {
			const res        = await axios.get(`${BASE_URL}/core/notification/undismiss`, {
				params: { page: state.page },
			})
			const data       = res.data?.data ?? []
			state.total      = res.data?.total ?? 0
			state.unreadTotal = res.data?.unreadTotal ?? 0
			state.hasMore    = res.data?.hasMorePage ?? false
			state.page      += 1

			this._updateNotifBadge(state.unreadTotal)
			this._setPulse(state.unreadTotal > 0)
			append ? this._appendNotif(data) : this._renderNotif(data)
		} catch (e) {
			console.error('Notification: fetch error', e)
		} finally {
			state.loading = false
		}
	}

	async _fetchExport(append = false) {
		const state = this._exportState
		if (state.loading) return
		if (append && state.start >= state.total) return
		if (!append) state.start = 0

		state.loading = true
		try {
			const res  = await axios.get(`${BASE_URL}/core/excel/export/logs`, {
				params: { start: state.start, length: state.length },
			})
			const data   = res.data?.data ?? []
			state.total  = res.data?.recordsTotal ?? 0
			state.start += data.length
			append ? this._appendExport(data) : this._renderExport(data)
		} catch (e) {
			console.error('Notification: fetch export logs error', e)
		} finally {
			state.loading = false
		}
	}

	async _fetchImport(append = false) {
		const state = this._importState
		if (state.loading) return
		if (append && state.start >= state.total) return
		if (!append) state.start = 0

		state.loading = true
		try {
			const res  = await axios.get(`${BASE_URL}/core/excel/import/logs`, {
				params: { start: state.start, length: state.length },
			})
			const data   = res.data?.data ?? []
			state.total  = res.data?.recordsTotal ?? 0
			state.start += data.length
			append ? this._appendImport(data) : this._renderImport(data)
		} catch (e) {
			console.error('Notification: fetch import logs error', e)
		} finally {
			state.loading = false
		}
	}

	// #endregion

	// #region render

	_renderNotif(items) {
		this._notifList.innerHTML = items.map(item => this._notifItemHtml(item)).join('')
		this._notifEmpty.classList.toggle('d-none', items.length > 0)
		this._bindNotifActions()
	}

	_appendNotif(items) {
		if (!items.length) return
		this._notifList.insertAdjacentHTML('beforeend', items.map(item => this._notifItemHtml(item)).join(''))
		this._bindNotifActions()
	}

	_renderExport(items) {
		this._exportList.innerHTML = items.map(item => this._exportItemHtml(item)).join('')
		this._exportEmpty.classList.toggle('d-none', items.length > 0)
	}

	_appendExport(items) {
		if (!items.length) return
		this._exportList.insertAdjacentHTML('beforeend', items.map(item => this._exportItemHtml(item)).join(''))
	}

	_renderImport(items) {
		this._importList.innerHTML = items.map(item => this._importItemHtml(item)).join('')
		this._importEmpty.classList.toggle('d-none', items.length > 0)
	}

	_appendImport(items) {
		if (!items.length) return
		this._importList.insertAdjacentHTML('beforeend', items.map(item => this._importItemHtml(item)).join(''))
	}

	/**
	 * @param {object} item
	 * @returns {string}
	 */
	_notifItemHtml(item) {
		const msg      = item.data ?? {}
		const isUnread = !item.read_at
		const dot      = isUnread ? `<i class="ri-circle-fill fs-8 text-primary me-1"></i>` : ''
		const label    = msg.title ?? ''
		const title    = !Helper.isEmpty(msg.url)
			? `<a href="${msg.url}">${dot}${label}</a>`
			: `${dot}${label}`
		const message  = (msg.message ?? '').replaceAll('\n', '<br>')

		const markReadBtn = isUnread
			? `<a href="javascript:void(0);" class="min-w-fit-content mark-read-notification" data-id="${item.id}" title="Mark as read">
					<i class="ri-check-line text-success"></i>
				</a>`
			: ''

		return `<li class="px-3 py-3 border-bottom${isUnread ? ' notif-unread' : ''}">
			<div class="d-flex align-items-start justify-content-between">
				<div class="d-flex flex-column gap-1 flex-fill overflow-hidden">
					<p class="mb-0 ${isUnread ? 'fw-semibold' : 'fw-medium'} fs-14">${title}</p>
					<div class="text-muted fw-normal fs-12 text-truncate notif-message" style="cursor:pointer">${message}</div>
					<div class="fw-normal fs-10 text-muted op-8">${item.time ?? ''}</div>
				</div>
				<div class="d-flex align-items-center ms-2 gap-1">
					${markReadBtn}
					<a href="javascript:void(0);" class="min-w-fit-content dismiss-notification" data-id="${item.id}" title="Dismiss">
						<i class="ri-close-line"></i>
					</a>
				</div>
			</div>
		</li>`
	}

	/**
	 * @param {object} log
	 * @returns {string}
	 */
	_exportItemHtml(log) {
		const badge = this._statusBadge(log.finished_at, log.error_message)
		const rows  = log.total_rows != null ? `<span>${Number(log.total_rows).toLocaleString()} rows</span>` : ''

		return `<li class="border-bottom">
			<a href="${log.url}" class="d-flex flex-column gap-1 px-3 py-3 text-decoration-none link-body-emphasis">
				<div class="d-flex justify-content-between align-items-start gap-2">
					<span class="fw-medium fs-14 text-truncate flex-fill">${log.file_name ?? ''}</span>
					${badge}
				</div>
				<div class="d-flex gap-3 fs-11 text-muted">
					${rows}
					<span>${log.created_at ?? ''}</span>
				</div>
			</a>
		</li>`
	}

	/**
	 * @param {object} log
	 * @returns {string}
	 */
	_importItemHtml(log) {
		const badge       = this._statusBadge(log.finished_at, log.error_message)
		const rows        = log.total_rows != null ? `<span>${Number(log.total_rows).toLocaleString()} rows</span>` : ''
		const successSpan = log.success_count != null ? `<span class="text-success">${Number(log.success_count).toLocaleString()} ok</span>` : ''
		const errorSpan   = log.error_count > 0 ? `<span class="text-danger">${Number(log.error_count).toLocaleString()} err</span>` : ''

		return `<li class="border-bottom">
			<a href="${log.url}" class="d-flex flex-column gap-1 px-3 py-3 text-decoration-none link-body-emphasis">
				<div class="d-flex justify-content-between align-items-start gap-2">
					<span class="fw-medium fs-14 text-truncate flex-fill">${log.file_name ?? ''}</span>
					${badge}
				</div>
				<div class="d-flex gap-3 fs-11 text-muted">
					${rows}${successSpan}${errorSpan}
					<span>${log.created_at ?? ''}</span>
				</div>
			</a>
		</li>`
	}

	/**
	 * @param {string|null} finishedAt
	 * @param {string|null} errorMessage
	 * @returns {string}
	 */
	_statusBadge(finishedAt, errorMessage) {
		if (errorMessage) {
			return `<span class="badge bg-danger-transparent text-danger flex-shrink-0">Error</span>`
		}
		if (finishedAt) {
			return `<span class="badge bg-success-transparent text-success flex-shrink-0">Done</span>`
		}
		return `<span class="badge bg-warning-transparent text-warning flex-shrink-0">In Progress</span>`
	}

	// #endregion

	// #region actions

	_bindNotifActions() {
		this._notifList.querySelectorAll('.mark-read-notification').forEach(btn => {
			btn.addEventListener('click', (e) => {
				e.preventDefault()
				this._markRead(btn.closest('li'), btn.getAttribute('data-id'))
			})
		})

		this._notifList.querySelectorAll('.dismiss-notification').forEach(btn => {
			btn.addEventListener('click', (e) => {
				e.preventDefault()
				this._markDismiss(btn.closest('li'), btn.getAttribute('data-id'))
			})
		})
	}

	/**
	 * @param {HTMLLIElement} li
	 * @param {string} id
	 */
	async _markRead(li, id) {
		try {
			await axios({ method: 'PUT', url: `${BASE_URL}/core/notification/mark-as-read/${id}` })

			li.classList.remove('notif-unread')

			const titleEl = li.querySelector('p')
			if (titleEl) {
				titleEl.classList.replace('fw-semibold', 'fw-medium')
				titleEl.querySelector('i.ri-circle-fill')?.remove()
			}

			li.querySelector('.mark-read-notification')?.remove()

			this._notifState.unreadTotal = Math.max(0, this._notifState.unreadTotal - 1)
			this._updateNotifBadge(this._notifState.unreadTotal)
			this._setPulse(this._notifState.unreadTotal > 0)
		} catch (e) {
			console.error('Notification: mark read error', e)
		}
	}

	/**
	 * @param {HTMLLIElement} li
	 * @param {string} id
	 */
	async _markDismiss(li, id) {
		try {
			await axios({ method: 'PUT', url: `${BASE_URL}/core/notification/dismiss/${id}` })

			const wasUnread = li.classList.contains('notif-unread')
			li.remove()

			this._notifState.total = Math.max(0, this._notifState.total - 1)

			if (wasUnread) {
				this._notifState.unreadTotal = Math.max(0, this._notifState.unreadTotal - 1)
				this._updateNotifBadge(this._notifState.unreadTotal)
				this._setPulse(this._notifState.unreadTotal > 0)
			}

			if (this._notifList.children.length === 0) {
				if (this._notifState.hasMore) {
					this._fetchNotif(true)
				} else {
					this._notifEmpty.classList.remove('d-none')
				}
			}
		} catch (e) {
			console.error('Notification: dismiss error', e)
		}
	}

	_bindExpandText() {
		this._offcanvasEl?.addEventListener('click', (e) => {
			const el = e.target.closest('.notif-message')
			if (!el) return
			el.classList.toggle('text-truncate')
		})
	}

	_bindInfiniteScroll() {
		if (!this._offcanvasBody) return
		this._offcanvasBody.addEventListener('scroll', () => {
			const el = this._offcanvasBody
			if (el.scrollHeight - el.scrollTop - el.clientHeight > 150) return

			if (this._notifPane?.classList.contains('active')) {
				this._fetchNotif(true)
			} else if (this._exportPane?.classList.contains('active')) {
				this._fetchExport(true)
			} else if (this._importPane?.classList.contains('active')) {
				this._fetchImport(true)
			}
		})
	}

	_listenBroadcast() {
		Echo.private(`in-app-notification.${USER_ID}`)
			.listen('.InAppNotificationEvent', (event) => {
				this.refreshInapp()

				Helper.toast({
					message: `${event.title}:\n ${event.message}`,
					position: Toast.Position.TopEnd,
					color: 'info'
				})
			})

		Echo.private(`export-download.${USER_ID}`)
			.listen('.ExportDownloadEvent', async (event) => {
				this.refreshExport()

				let delay        = 1000
				let attempt      = 0
				const maxAttempt = 3

				await Helper.delay(delay)
				Helper.toast({ message: "Download export file started.." })

				while (attempt < maxAttempt) {
					attempt++

					try {
						await Helper.downloadFile(`${BASE_URL}/core/excel/export/download/${event.exportId}`)
						break
					} catch (error) {
						console.warn("Download failed, will try again", { error })
					}

					await Helper.delay(delay)
				}

				if (attempt === maxAttempt) {
					Helper.toast({ message: "❌ Auto download is failed, please download from export log" })
				} else {
					Helper.toast({ message: "✔️ Download finish, check your download history" })
				}
			})

		Echo.private(`import-complete.${USER_ID}`)
			.listen('.ImportCompleteEvent', () => {
				this.refreshImport()
			})
	}

	// #endregion

	// #region helpers

	/**
	 * @param {boolean} active
	 */
	_setPulse(active) {
		if (!this._pulse) return
		if (active) {
			this._pulse.className = 'header-icon-pulse bg-secondary rounded pulse pulse-secondary'
		} else {
			this._pulse.className = ''
		}
	}

	/**
	 * @param {number} total
	 */
	_updateNotifBadge(total) {
		if (!this._notifBadge) return
		this._notifBadge.textContent = total
		this._notifBadge.classList.toggle('d-none', total === 0)
	}

	// #endregion
}
