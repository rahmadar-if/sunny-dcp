import axios from "@core-js/libs/axios"
import { AxiosError } from "axios"
import Helper from "./helper"
import PhotoSwipeLightbox from "photoswipe/lightbox"
import PhotoSwipe from "photoswipe"
import "photoswipe/style.css"
import Table from "./table/table"
import DropzoneUpload from "./dropzone"
import Modal from "./modal"
import SolarComponent from "./solar/solar-component"

export default class Attachment extends SolarComponent {
	_previewHiddenHandler = null

	constructor(selector) {
		super()

		if (selector instanceof Element) {
			this._element = selector
		} else if (Helper.isString(selector) && !Helper.isEmpty(selector)) {
			this._element = document.querySelector(selector)
			if (!this._element) {
				throw new Error(`Element with query selector ${selector} is not found`)
			}
		} else {
			throw new Error(`Selector is not supported`)
		}

		this._id = this._element.id

		this._table = new Table(document.getElementById(`${this._id}_table`))

		const dropzoneEl = document.getElementById(`${this._id}_upload`)
		this._dropzone = new DropzoneUpload(dropzoneEl)

		const modalEl = document.getElementById(`${this._id}_preview`)
		this._modal = new Modal(modalEl)

		this._initTable()
		this._initUpload()
	}

	_initTable() {
		const availMimes = Helper.getAvailableMime()
		const imgExt     = availMimes.filter(item => item.type == 'image').map(item => item.ext.substring(1))
		const archiveExt = availMimes.filter(item => item.type == 'compress').map(item => item.ext.substring(1))
		const textExt    = availMimes.filter(item => item.type == 'text').map(item => item.ext.substring(1))

		const imgDummy = {
			archive: new URL("../../assets/images/attachment/archive.png", import.meta.url),
			file:    new URL("../../assets/images/attachment/file.png", import.meta.url),
			pdf:     new URL("../../assets/images/attachment/pdf.png", import.meta.url),
			word:    new URL("../../assets/images/attachment/word.png", import.meta.url),
			excel:   new URL("../../assets/images/attachment/excel.png", import.meta.url),
			ppt:     new URL("../../assets/images/attachment/powerpoint.png", import.meta.url),
			text:    new URL("../../assets/images/attachment/txt.png", import.meta.url)
		}

		this._table
			.on("ready", () => {
				this._handlePreview()
			})
			.on("draw", () => {
				this._handlePreview()
			})
			.on("column render:file_name", (data, row) => {
				const ext = row.file_extension.toLowerCase()
				let isImage = false
				let isPdf   = false
				let isText  = false
				let imgSrc  = null

				if (imgExt.includes(ext)) {
					imgSrc  = `${BASE_URL}/core/images/thumbnail/${row.id}`
					isImage = true
				} else if (archiveExt.includes(ext)) {
					imgSrc = imgDummy.archive
				} else if (ext === 'pdf') {
					imgSrc = imgDummy.pdf
					isPdf  = true
				} else if (ext === 'docx') {
					imgSrc = imgDummy.word
				} else if (['xlsx', 'csv'].includes(ext)) {
					imgSrc  = imgDummy.excel
					if (ext === 'csv') isText = true
				} else if (ext === 'pptx') {
					imgSrc = imgDummy.ppt
				} else if (textExt.includes(ext)) {
					imgSrc = imgDummy.text
					isText = true
				} else {
					imgSrc = imgDummy.file
				}

				const imgWrapOpen = isImage
					? `<a class="img-preview" href="${BASE_URL}/core/images/${row.id}" data-pswp-width="${row.image_width}" data-pswp-height="${row.image_height}" target="_blank">`
					: isPdf
						? `<a class="file-preview" href="javascript:void(0)" data-id="${row.id}" data-name="${row.file_name}" data-type="pdf">`
						: isText
							? `<a class="file-preview" href="javascript:void(0)" data-id="${row.id}" data-name="${row.file_name}" data-type="text">`
							: ''
				const imgWrapClose = (isImage || isPdf || isText) ? '</a>' : ''

				return `<div class="d-flex gap-2 overflow-hidden">
					${imgWrapOpen}
						<img class="img-fluid rounded d-block flex-shrink-0" src="${imgSrc}" alt="image" width="36">
					${imgWrapClose}
					<div class="d-flex flex-column flex-shrink-1 overflow-hidden">
						<p class="mb-0 text-truncate">${row.file_name}</p>
						<p class="text-muted mb-0">${row.file_size_human ?? row.file_size}</p>
					</div>
				</div>`
			})
			.on("column created:_action", (row, cell, cellData, rowData) => {
				const downloadElem = document.createElement("a")
				downloadElem.className  = "dropdown-item download-action"
				downloadElem.href       = "javascript:void(0)"
				downloadElem.innerHTML  = `<i class="ri-download-2-line me-1"></i>Download`
				downloadElem.addEventListener("click", () => this.download(rowData.id))

				cell.querySelector(".dropdown ul.dropdown-menu").prepend(downloadElem)
			})
			.on("delete", async (data) => {
				const conf = await Helper.confirmDelete({ title: "Are you sure?" })
				if (conf) {
					try {
						const req = await axios({
							method: "DELETE",
							url: `${BASE_URL}/core/attachment/${data.id}`
						})
						const res = req.data

						return res.success
					} catch (e) {
						console.error({ e })

						const eMessage = e instanceof AxiosError ? e.response?.data?.message : e
						Helper.errorAlert({ title: "Oops! There was an error", message: eMessage, timeout: null })

						throw e
					}
				}

				return false
			})
			.render()
	}

	_initUpload() {
		this._dropzone
			.on("queuecomplete", () => this.refresh())
			.init()
	}

	async refresh() {
		await this._table.refresh()
	}

	async download(id) {
		Helper.downloadFile(`${BASE_URL}/core/attachment/download/${id}`)
	}

	_handlePreview() {
		const lightbox = new PhotoSwipeLightbox({
			gallery: `#${this._id}_table tbody tr td a.img-preview`,
			pswpModule: PhotoSwipe
		})
		lightbox.init()

		this._element.querySelectorAll('a.file-preview').forEach(link => {
			link.addEventListener('click', () => this._openPreview(
				link.dataset.id,
				link.dataset.name,
				link.dataset.type
			))
		})
	}

	_openPreview(id, name, type) {
		const titleEl   = document.getElementById(`${this._id}_preview_title`)
		const contentEl = document.getElementById(`${this._id}_preview_content`)

		titleEl.textContent = name
		contentEl.innerHTML = ''

		if (!this._previewHiddenHandler) {
			this._previewHiddenHandler = () => {
				contentEl.innerHTML = ''
				this._modal.off('hidden')
				this._previewHiddenHandler = null
			}
			this._modal.on('hidden', this._previewHiddenHandler)
		}

		this._modal.show()

		if (type === 'pdf') {
			contentEl.innerHTML = `<embed src="${BASE_URL}/core/attachment/preview-text/${id}" type="application/pdf" style="width:100%;height:100%;display:block">`
		} else if (type === 'text') {
			contentEl.innerHTML = `<div class="d-flex align-items-center justify-content-center h-100"><span>Loading...</span></div>`
			this._loadTextPreview(id, contentEl)
		}
	}

	async _loadTextPreview(id, contentEl) {
		const pre = document.createElement('pre')
		pre.className = 'p-3 m-0 overflow-auto'
		pre.style     = 'height:100%;tab-size:4;white-space:pre-wrap;word-break:break-all'

		const MAX_BYTES = 2 * 1024 * 1024
		const decoder  = new TextDecoder()
		let totalBytes = 0
		let truncated  = false

		try {
			const response = await fetch(`${BASE_URL}/core/attachment/preview-text/${id}`, {
				headers: { 'X-Requested-With': 'XMLHttpRequest' }
			})
			if (!response.ok) throw new Error(response.statusText)

			contentEl.innerHTML = ''
			contentEl.appendChild(pre)

			const reader = response.body.getReader()

			while (true) {
				const { done, value } = await reader.read()
				if (done) break

				totalBytes      += value.byteLength
				pre.textContent += decoder.decode(value, { stream: true })

				if (totalBytes >= MAX_BYTES) {
					reader.cancel()
					truncated = true
					break
				}
			}

			if (truncated) {
				const notice = document.createElement('div')
				notice.className   = 'p-2 bg-warning-subtle text-warning-emphasis text-center small'
				notice.textContent = 'Preview truncated at 2MB. Download the file to view full content.'
				contentEl.insertBefore(notice, pre)
			}
		} catch (e) {
			contentEl.innerHTML = `<div class="p-3 text-danger">Failed to load file.</div>`
		}
	}
}
