import axios from "@core-js/libs/axios"

export default class FileHelper {

	// #region File Validation

	/**
	 * @param {File} file
	 * @param {number} maxSizeInMB
	 * @param {string|null} mimeType
	 * @returns {boolean}
	 */
	static isFileValid(file, maxSizeInMB, mimeType = null) {
		return FileHelper.isFileSizeValid(file, maxSizeInMB) && FileHelper.isFileMimeValid(file, mimeType)
	}

	/**
	 * @param {File} file
	 * @param {number} maxSizeInMB
	 * @returns {boolean}
	 */
	static isFileSizeValid(file, maxSizeInMB) {
		const sizeMB = file.size / (1024 * 1024)
		return sizeMB <= maxSizeInMB
	}

	/**
	 * @param {File} file
	 * @param {string|null} mimeType
	 * @returns {boolean}
	 */
	static isFileMimeValid(file, mimeType = null) {
		const availMimes = FileHelper.getAvailableMime(mimeType)
		return availMimes.filter(item => item.mime == file.type).length > 0
	}

	// #endregion

	// #region MIME Types

	/**
	 * @param {string|null} type
	 * @returns {Array<{type: string, ext: string, mime: string}>|null}
	 */
	static getAvailableMime(type = null) {
		const mimes = [
			{ type: "office_document", ext: ".xlsx", mime: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" },
			{ type: "office_document", ext: ".docx", mime: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" },
			{ type: "office_document", ext: ".pptx", mime: "application/vnd.openxmlformats-officedocument.presentationml.presentation" },
			{ type: "pdf",             ext: ".pdf",  mime: "application/pdf" },
			{ type: "csv",             ext: ".csv",  mime: "text/csv" },
			{ type: "text",            ext: ".txt",  mime: "text/plain" },
			{ type: "text",            ext: ".log",  mime: "text/plain" },
			{ type: "text",            ext: ".md",   mime: "text/markdown" },
			{ type: "text",            ext: ".xml",  mime: "text/xml" },
			{ type: "text",            ext: ".json", mime: "application/json" },
			{ type: "text",            ext: ".yaml", mime: "application/x-yaml" },
			{ type: "text",            ext: ".yml",  mime: "application/x-yaml" },
			{ type: "text",            ext: ".sql",  mime: "application/sql" },
			{ type: "image",           ext: ".gif",  mime: "image/gif" },
			{ type: "image",           ext: ".jpg",  mime: "image/jpeg" },
			{ type: "image",           ext: ".jpeg", mime: "image/jpeg" },
			{ type: "image",           ext: ".png",  mime: "image/png" },
			{ type: "image",           ext: ".svg",  mime: "image/svg+xml" },
			{ type: "image",           ext: ".webp", mime: "image/webp" },
			{ type: "video",           ext: ".avi",  mime: "video/x-msvideo" },
			{ type: "video",           ext: ".mp4",  mime: "video/mp4" },
			{ type: "compress",        ext: ".zip",  mime: "application/zip" },
			{ type: "compress",        ext: ".zip",  mime: "application/x-zip-compressed" },
			{ type: "compress",        ext: ".rar",  mime: "application/vnd.rar" },
		]

		if (type === null || type === undefined || type === '') {
			return mimes
		}

		const filterType = mimes.filter(item => item.type == type)
		if (filterType.length > 0) {
			return filterType
		}

		const filterExt = mimes.filter(item => item.ext == type)
		if (filterExt.length > 0) {
			return filterExt
		}

		const filterMime = mimes.filter(item => item.mime == type)
		if (filterMime.length > 0) {
			return filterMime
		}

		return null
	}

	// #endregion

	// #region File Size

	/**
	 * @param {number} size - size in bytes
	 * @returns {string}
	 */
	static getHumanReadableSize(size) {
		const units = ['B', 'KB', 'MB', 'GB', 'TB']
		let i = 0

		while (size >= 1024 && i < units.length - 1) {
			size /= 1024
			i++
		}

		return size.toFixed(2) + ' ' + units[i]
	}

	// #endregion

	// #region File Download

	/**
	 * @param {string} url
	 * @param {string} method
	 * @param {{ headers?: object, data?: object }} options
	 * @returns {Promise<void>}
	 */
	static async downloadFile(url, method = "GET", options = {}) {
		const req = await axios({
			method: method,
			url: url,
			responseType: 'blob',
			headers: options.headers ?? {},
			data: options.data ?? undefined,
		})

		const contentDisposition      = req.headers['content-disposition']
		const contentDispositionSplit = contentDisposition.split(';')
		const fileName                = contentDispositionSplit[1].trim().replaceAll('"', "").replaceAll("'", "").substring(9)

		const a  = document.createElement('a')
		a.href   = window.URL.createObjectURL(req.data)
		a.download = fileName
		document.body.appendChild(a)
		a.click()
		a.remove()
	}

	// #endregion

	// #region Quota

	/**
	 * Check if user can upload a file of the given size against their storage quota.
	 * Fails open on network/server error — backend is the authoritative guard.
	 * @param {number} fileSize - file size in bytes
	 * @returns {Promise<{ allowed: boolean, used_human: string, limit_human: string, available_human: string }>}
	 */
	static async canUpload(fileSize) {
		try {
			const res  = await axios.get(`${BASE_URL}/core/attachment/quota`)
			const data = res.data?.data ?? res.data

			return {
				allowed:         data.available >= fileSize,
				used_human:      data.used_human,
				limit_human:     data.limit_human,
				available_human: data.available_human,
			}
		} catch {
			// fail open — backend validates on first chunk
			return { allowed: true, used_human: '', limit_human: '', available_human: '' }
		}
	}

	// #endregion
}
