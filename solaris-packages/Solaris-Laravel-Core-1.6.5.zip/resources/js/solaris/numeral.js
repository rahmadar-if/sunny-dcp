import Helper from "./helper"

export default class Numeral {

	// #region Static

	/**
	 * Build numeral markup identical to the `x-core::numeral` blade component,
	 * for cases where the element is rendered at runtime instead of server-side.
	 * Bind it afterwards with `new Numeral(element)` to enable the click toggle.
	 * @param {{
	 *  value?: number,
	 *  decimals?: number,
	 *  decimalSeparator?: string,
	 *  thousandSeparator?: string,
	 *  prefix?: string|null,
	 *  class?: string|null
	 * }} options
	 * @returns {string}
	 */
	static render(options = {}) {
		const value             = options.value ?? 0
		const decimals          = options.decimals ?? 2
		const decimalSeparator  = options.decimalSeparator ?? ','
		const thousandSeparator = options.thousandSeparator ?? '.'
		const prefix            = options.prefix ?? null
		const className         = options.class ?? 'fs-13'

		const readable = Helper.readableNumber(value, decimals, decimalSeparator, thousandSeparator, true)
		const full     = Helper.readableNumber(value, decimals, decimalSeparator, thousandSeparator, false)

		return `<span class="${className}" solar-ui="numeral" decimals="${decimals}" decimal-separator="${decimalSeparator}" thousand-separator="${thousandSeparator}">
			${prefix ? `<span class="numeral-prefix">${prefix}</span>` : ''}
			<span class="numeral-readable">${readable}</span>
			<span class="numeral-full d-none">${full}</span>
		</span>`
	}

	// #endregion

	// #region Lifecycle

	_element           = null
	_readable          = null
	_full              = null
	_clickHandler      = null
	_decimals          = 2
	_decimalSeparator  = ','
	_thousandSeparator = '.'

	/**
	 * @param {HTMLElement|string} selector
	 */
	constructor(selector) {
		if (selector instanceof Element) {
			this._element = selector
		} else if (typeof selector === 'string' && selector.trim() !== '') {
			this._element = document.querySelector(selector)
			if (!this._element) {
				throw new Error(`Element with query selector ${selector} is not found`)
			}
		} else {
			throw new Error(`Selector is not supported`)
		}

		this._decimals          = parseInt(this._element.getAttribute('decimals') ?? 2)
		this._decimalSeparator  = this._element.getAttribute('decimal-separator') ?? ','
		this._thousandSeparator = this._element.getAttribute('thousand-separator') ?? '.'
		this._readable          = this._element.querySelector('.numeral-readable')
		this._full              = this._element.querySelector('.numeral-full')

		this._bindEvents()
	}

	/**
	 * @returns {void}
	 */
	destroy() {
		if (this._clickHandler) {
			this._element.removeEventListener('click', this._clickHandler)
		}

		this._element           = null
		this._readable          = null
		this._full              = null
		this._clickHandler      = null
	}

	// #endregion

	// #region Public API

	/**
	 * @param {number} number
	 * @returns {void}
	 */
	set(number) {
		const readable = Helper.readableNumber(number, this._decimals, this._decimalSeparator, this._thousandSeparator, true)
		const full     = Helper.readableNumber(number, this._decimals, this._decimalSeparator, this._thousandSeparator, false)

		this._readable.textContent = readable
		this._full.textContent     = full

		this._readable.classList.remove('d-none')
		this._full.classList.add('d-none')
	}

	// #endregion

	// #region Events

	/**
	 * @returns {void}
	 */
	_bindEvents() {
		this._element.style.cursor     = 'pointer'
		this._element.style.userSelect = 'none'

		this._clickHandler = () => this.toggle()
		this._element.addEventListener('click', this._clickHandler)
	}

	/**
	 * @returns {void}
	 */
	toggle() {
		this._readable.classList.toggle('d-none')
		this._full.classList.toggle('d-none')
	}

	// #endregion
}
