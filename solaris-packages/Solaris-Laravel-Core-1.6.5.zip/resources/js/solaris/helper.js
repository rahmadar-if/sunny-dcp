import Toast from "./toast"
import DateHelper from "@core-js/solaris/date-helper"
import FileHelper from "@core-js/solaris/file-helper"

export default class Helper {

    /**
     * @param {*} value 
     * @returns {boolean}
     */
    static isDefined(value) {
        return typeof value !== 'undefined' && value !== null
    }

    /**
     * @param {*} value 
     * @returns {boolean}
     */
    static isFunction(value) {
        return !!(value && value.constructor && value.call && value.apply)
    }

    /**
     * @param {*} value 
     * @returns {boolean} 
     */
    static isString(value) {
        return Helper.isDefined(value) && typeof value == "string"
    }

    /**
     * @param {*} value 
     * @returns {boolean}
     */
    static isNumber(value) {
        if (typeof value === 'number') {
            return !isNaN(value)
        }

        if (typeof value === 'string' && value === value.trim() && value.trim().length != 0) {
            return !isNaN(Number(value));
        }

        return false
    }

    /**
     * @param {*} value 
     * @returns {boolean}
     */
    static isInteger(value) {
        return Helper.isNumber(value) && Number.isInteger(value)
    }

    /**
     * @param {*} value 
     * @returns {boolean}
     */
    static isFloat(value) {
        return Helper.isNumber(value) && !Number.isInteger(value)
    }

    /**
     * @param {*} value 
     * @returns {boolean}
     */
    static isValidURL(value) {
        if (!Helper.isString(value) || Helper.isEmpty(value)) {
            return false
        }

        try {
            new URL(value)
        } catch (error) {
            return false
        }

        return true
    }

    /**
     * @param {*} value 
     * @returns {boolean}
     */
    static isDate(value) {
        return Helper.isDefined(value) && value instanceof Date
    }

    /**
     * @param {*} value 
     * @returns {boolean}
     */
    static isObject(value) {
        return Helper.isDefined(value) && typeof value === 'object' && Object.prototype.toString.call(value) === '[object Object]'
    }

    /**
     * @param {*} value 
     * @returns {boolean}
     */
    static isLookup(value) {
        const isObject = Helper.isObject(value)
        const hasDisplayValue = isObject && value.hasOwnProperty("displayValue") && value.displayValue.hasOwnProperty("column") && value.displayValue.hasOwnProperty("value")
        if (hasDisplayValue) {
            return true
        }

        return isObject && value.hasOwnProperty("id") && value.hasOwnProperty("name")
    }

    /**
     * @param {*} value 
     * @returns {boolean}
     */
    static isEmpty(value) {
        if (!Helper.isDefined(value)) {
            return true
        }

        if (Helper.isString(value) && value?.trim().length == 0) {
            return true
        }

        if (Array.isArray(value) && value.length == 0) {
            return true
        }

        if (Helper.isObject(value)) {
            for (const prop in value) {
                if (Object.hasOwn(value, prop)) {
                    return false
                }
            }

            return true
        }

        if (value instanceof FormData) {
            return [...value.entries()].length == 0 ? true : false
        }

        if (typeof value === "boolean") {
            return !value
        }

        if (Helper.isNumber(value)) {
            return value <= 0
        }

        return false
    }

    static emptyUuid() {
        return "00000000-0000-0000-0000-000000000000"
    }

    static slug(str, separator = '-') {
        return str
            .toString()
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/[^a-z0-9\s-]/g, '')
            .trim()
            .replace(/[\s-]+/g, separator)
    }

    /**
     * Date to HH:mm:ss
     * @deprecated Use DateHelper.timeToString instead
     * @param {Date} date
     * @param {boolean} utc
     * @returns {string}
     */
    static timeToString(date, utc = false) {
        return DateHelper.timeToString(date, utc)
    }

    /**
     * Date to YYYY-MM-DD
     * @deprecated Use DateHelper.dateToString instead
     * @param {Date} date
     * @returns {string}
     */
    static dateToString(date) {
        return DateHelper.dateToString(date)
    }

    /**
     * Date to YYYY-MM-DD HH:mm:ss
     * @deprecated Use DateHelper.dateTimeToString instead
     * @param {Date} date
     * @returns {string}
     */
    static dateTimeToString(date) {
        return DateHelper.dateTimeToString(date)
    }

    /**
     * Date to "DD Mon YYYY" (e.g. "11 May 2026")
     * @deprecated Use DateHelper.dateToFullString instead
     * @param {Date} date
     * @returns {string}
     */
    static dateToFullString(date) {
        return DateHelper.dateToFullString(date)
    }

    /**
     * Date to "DD Mon YYYY, HH:mm:ss" (e.g. "11 May 2026, 09:30:00")
     * @deprecated Use DateHelper.datetimeToFullString instead
     * @param {Date} date
     * @returns {string}
     */
    static datetimeToFullString(date) {
        return DateHelper.datetimeToFullString(date)
    }

    /**
     * @returns {string} 
     */
    static getCsrfToken() {
        return document.querySelector('meta[name="csrf-token"]').getAttribute('content')
    }

    /**
     * @param {int} timeout in microsecond
     * @returns 
     */
    static async delay(timeout) {
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve()
            }, timeout)
        })
    }

    /**
     * @param {string} name 
     * @returns {string}
     */
    static getInitialName(name) {
        return name
            .split(/\s+/)
            .map(word => {
                const match = word.match(/[a-zA-Z]/);
                return match ? match[0].toUpperCase() : '';
            })
            .filter(Boolean)
            .slice(0, 3)
            .join('');
    }

    /**
     * Normalizes a phone number to international format without leading '+' or '00'.
     * Strips all non-digit characters, then applies country code prefix if needed.
     *
     * @param {string} phone
     * @param {string} countryCode - Default '62' (Indonesia)
     * @returns {string}
     */
    static normalizePhoneNumber(phone, countryCode = '62') {
        let digits = (phone ?? '').replace(/\D/g, '')

        if (digits.startsWith('00')) {
            digits = digits.substring(2)
        } else if (digits.startsWith('0')) {
            digits = countryCode + digits.substring(1)
        }

        return digits
    }

    /**
     * Converts a floating-point number to a currency-formatted string using the Indonesian locale.
     *
     * @param {number} float - The number to be formatted as currency.
     * @returns {string} The formatted currency string.
     * @throws {Error} Throws an error if the input is not a valid floating-point number.
     */
    static numberToCurrency(float) {
        if (!Helper.isNumber(float)) {
            throw new Error("Value must be a valid number");
        }
        return Intl.NumberFormat("id", {
            minimumFractionDigits: 2
        }).format(float);
    }

    /**
     * @param {number} number
     * @param {number} decimal
     * @param {string} decimalSeparator
     * @param {string} thousandSeparator
     * @param {boolean} minimize
     * @returns {string}
     */
    static readableNumber(number, decimal = 2, decimalSeparator = ',', thousandSeparator = '.', minimize = true) {
        const units = ['', 'K', 'M', 'B', 'T']
        let i = 0

        if (minimize) {
            while (Math.abs(number) >= 1000 && i < units.length - 1) {
                number /= 1000
                i++
            }
        }

        const [intPart, decPart] = number.toFixed(decimal).split('.')
        const formattedInt       = intPart.replace(/\B(?=(\d{3})+(?!\d))/g, thousandSeparator)
        const formatted          = decimal > 0 ? `${formattedInt}${decimalSeparator}${decPart}` : formattedInt

        return minimize ? `${formatted} ${units[i]}`.trim() : formatted
    }

    /**
     * @deprecated Use FileHelper.getHumanReadableSize instead
     * @param {number} size
     * @returns {string}
     */
    static getHumanReadableSize(size) {
        return FileHelper.getHumanReadableSize(size)
    }

    /**
     * DEPRECATED
     * Get valid model in component attribute
     * @param {string} model
     * @returns {string}
     */
    static getValidModel(model) {
        if (Helper.isEmpty(model)) {
            return null
        }

        const isControllerOnly = model.startsWith("ctrl:") || model.startsWith("!")
        if (isControllerOnly) {
            return null
        }

        const rawSplit = (model + "@").split("@")
        const source = rawSplit[0]

        const sourceSplit = (source + ".").split(".")
        const modelPart = (sourceSplit[0] + ":").split(":")
        const modelName = modelPart[0]

        return Helper.isEmpty(modelName) ? null : modelName
    }

    static parseShorthandModel(raw) {
        const result = {
            model: null,
            scope: null,
            scopeArgs: [],
            controller: null,
            method: null,
            methodArgs: [],
            aggregate: null,
            aggregateColumns: []
        }

        let aggregatePart = null
        if (raw.includes(".")) {
            const parts = raw.split(".", 2)

            raw = parts[0]
            aggregatePart = parts[1]
            const aggMatch = aggregatePart.match(/^([a-zA-Z0-9_]+)\(([^)]*)\)$/)
            if (aggMatch) {
                result.aggregate = aggMatch[1]
                result.aggregateColumns = aggMatch[2]
                    .split(",")
                    .map((s) => s.trim())
                    .filter((s) => s.length > 0)
            }
        }

        if (raw.startsWith("!")) {
            raw = raw.substring(1)

            const ctrlMatch = raw.match(/^([^@]+)@([^(]+)(?:\((.*)\))?$/)
            if (ctrlMatch) {
                result.controller = ctrlMatch[1]
                result.method = ctrlMatch[2]
                result.methodArgs = ctrlMatch[3] ?
                    ctrlMatch[3].split(",").map((s) => s.trim()).filter((s) => s.length > 0) : []
            } else {
                result.controller = raw
            }

            return result
        }

        const [modelScopePart, controllerPart] = raw.split(":", 2)

        if (modelScopePart) {
            const msMatch = modelScopePart.match(/^([^@]+)(?:@([^(]+)(?:\((.*)\))?)?$/)
            if (msMatch) {
                result.model = msMatch[1] || null
                result.scope = msMatch[2] || null
                result.scopeArgs = msMatch[3] ?
                    msMatch[3].split(",").map((s) => s.trim()).filter((s) => s.length > 0) : []
            }
        }

        if (controllerPart) {
            const cMatch = controllerPart.match(/^(?:([^@]+))?@([^(]+)(?:\((.*)\))?$/)
            if (cMatch) {
                result.controller = cMatch[1] ? cMatch[1] : (result.model ? result.model : null)
                result.method = cMatch[2]
                result.methodArgs = cMatch[3] ? cMatch[3].split(",").map((s) => s.trim()).filter((s) => s.length > 0) : []
            } else {
                result.controller = controllerPart
            }
        }

        return result
    }

    //#region loading

    /**
     * Loading with specific element/selector
     * @param {Element|string} selector
     * @param {boolean} show
     * @param {int} timeout
     */
    static loading(selector, show, timeout = null) {
        if (!Helper.isString(selector) && !(selector instanceof Element)) {
            throw new Error("Selector must be string or Element")
        }

        if (typeof show !== 'boolean') {
            throw new Error("Show must be boolean")
        }

        if (show) {
            const config = {
                message: '<div class="spinner-border text-white" role="status"></div>',
                css: {
                    backgroundColor: 'transparent',
                    border: '0'
                },
                overlayCSS: {
                    opacity: 0.5
                }
            }

            if (Helper.isInteger(timeout)) {
                config.timeout = timeout
            }

            $(selector).block(config)
        } else {
            $(selector).unblock()
        }
    }

    /**
     * Loading with block all document
     * @param {boolean} show
     * @param {int} timeout timeout with millisecond
     */
    static loadingPage(show, timeout = null) {
        if (typeof show !== 'boolean') {
            throw new Error("Show must be boolean")
        }

        if (show) {
            const config = {
                message: '<div class="spinner-border text-white" role="status"></div>',
                css: {
                    backgroundColor: 'transparent',
                    border: '0'
                },
                overlayCSS: {
                    opacity: 0.5
                }
            }

            if (Helper.isInteger(timeout)) {
                config.timeout = timeout
            }

            $.blockUI(config)
        } else {
            $.unblockUI()
        }
    }

    //#endregion

    //#region alert

    /**
     * show sweetalert
     * @param {Object} config
     * @param {string} config.title
     * @param {string} config.message
     * @param {string} config.icon default is info. success, info, warning, error
     * @param {int} config.timeout default is 2000ms
     * @returns {Promise<SweetAlertResult>}
     */
    static async alert({ title, message = '', icon = 'info', timeout = 3000 }) {
        const config = {
            title: title,
            text: message,
            icon: icon,
            customClass: {
                confirmButton: 'btn btn-primary waves-effect waves-light'
            },
            buttonsStyling: false
        }

        if (Helper.isInteger(timeout)) {
            config.timer = timeout
        }

        return new Promise((resolve) => {
            Swal.fire(config).then((result) => resolve(result))
        })
    }

    /**
     * show success sweetalert with lord icon
     * @param {Object} config
     * @param {string} config.title
     * @param {string} config.message
     * @param {int} config.timeout default is 2000ms
     * @returns {Promise<SweetAlertResult>}
     */
    static async successAlert({ title, message = '', timeout = 3000 }) {
        const config = {
            html: '<div class="mt-3">' +
                '<lord-icon src="https://cdn.lordicon.com/lupuorrc.json" trigger="loop" colors="primary:#0ab39c,secondary:#405189" style="width:120px;height:120px"></lord-icon>' +
                '<div class="mt-4 pt-2 fs-15">' +
                `<h4>${title}</h4>` +
                (!Helper.isEmpty(message) ? `<p class="text-muted mx-4 mb-0">${message}</p>` : '') +
                '</div>' +
                '</div>',
            customClass: {
                cancelButton: 'btn btn-primary mb-1',
            },
            showCancelButton: true,
            showConfirmButton: false,
            customClass: {
                cancelButton: 'btn btn-primary mb-1',
            },
            cancelButtonText: 'Ok',
            buttonsStyling: false,
            showCloseButton: false
        }

        if (Helper.isInteger(timeout)) {
            config.timer = timeout
        }

        return new Promise((resolve) => {
            Swal.fire(config).then((result) => resolve(result))
        })
    }

    /**
     * show error sweetalert with lord icon
     * @param {Object} config
     * @param {string} config.title
     * @param {string} config.message
     * @param {int} config.timeout default is 2000ms
     * @returns {Promise<SweetAlertResult>}
     */
    static async errorAlert({ title, message = '', timeout = null }) {
        const config = {
            html: '<div class="mt-3">' +
                '<lord-icon src="https://cdn.lordicon.com/tdrtiskw.json" trigger="loop" colors="primary:#f06548,secondary:#f7b84b" style="width:120px;height:120px"></lord-icon>' +
                '<div class="mt-2 pt-2 fs-15">' +
                `<h4>${title}</h4>` +
                (!Helper.isEmpty(message) ? `<p class="text-muted mx-4 mb-0">${message}</p>` : '') +
                '</div>' +
                '</div>',
            showCancelButton: true,
            showConfirmButton: false,
            customClass: {
                cancelButton: 'btn btn-primary mb-1',
            },
            cancelButtonText: 'Dismiss',
            buttonsStyling: false,
            showCloseButton: false
        }

        if (Helper.isInteger(timeout)) {
            config.timer = timeout
        }

        return new Promise((resolve) => {
            Swal.fire(config).then((result) => resolve(result))
        })
    }

    /**
     * show confirm sweetalert
     * @param {Object} config
     * @param {string} config.title
     * @param {string} config.message
     * @returns {Promise<SweetAlertResult>}
     */
    static async confirm({ title, message = '' }) {
        const config = {
            title: title,
            text: message,
            icon: "warning",
            customClass: {
                confirmButton: 'btn btn-primary me-2 mt-2',
                cancelButton: 'btn btn-danger mt-2',
            },
            showCancelButton: true,
            confirmButtonText: 'Yes',
            cancelButtonText: 'No',
            buttonsStyling: false
        }

        return new Promise((resolve) => {
            Swal.fire(config).then(result => resolve(result.dismiss == "backdrop" ? undefined : (result.value ?? false)))
        })
    }

    /**
     * show confirm delete sweetalert with lord icon
     * @param {Object} config
     * @param {string} config.title
     * @param {string} config.message
     * @returns {Promise<SweetAlertResult>}
     */
    static async confirmDelete({ title, message = '' }) {
        const config = {
            html: '<div class="mt-3">' +
                '<lord-icon src="https://cdn.lordicon.com/gsqxdxog.json" trigger="loop" colors="primary:#f7b84b,secondary:#f06548" style="width:100px;height:100px"></lord-icon>' +
                '<div class="mt-2 pt-2 fs-15 mx-5">' +
                `<h4>${title}</h4>` +
                (!Helper.isEmpty(message) ? `<p class="text-muted mx-4 mb-0">${message}</p>` : '') +
                '</div>' +
                '</div>',
            customClass: {
                confirmButton: 'btn btn-primary me-2 mb-1',
                cancelButton: 'btn btn-danger mb-1',
            },
            showCancelButton: true,
            confirmButtonText: 'Yes, Delete It!',
            cancelButtonText: 'No',
            buttonsStyling: false
        }

        return new Promise((resolve) => {
            Swal.fire(config).then(result => resolve(result.value))
        })
    }

    static toast({ title = 'Notification', message = null, color = null, position = Toast.Position.TopEnd, timeout = 3000, onClick = null }) {
        return Toast.show({ title, message, color, position, timeout, onClick })
    }

    //#endregion

    /**
     * @param {Function} fn 
     * @param {number} delay 
     * @returns 
     */
    static debounce(fn, delay = 200) {
        let timeout
        return (...args) => {
            clearTimeout(timeout)
            timeout = setTimeout(() => fn(...args), delay)
        }
    }

    /**
     * @deprecated Use FileHelper.downloadFile instead
     * @param {string} url
     * @param {string} method
     * @param {{ headers?: object, data?: object }} options
     * @returns {Promise<void>}
     */
    static async downloadFile(url, method = "GET", options = {}) {
        return FileHelper.downloadFile(url, method, options)
    }

    /**
     * @param {[string]} suffixes 
     */
    static clearCacheBySuffix(suffixes) {
        Object.keys(localStorage).forEach((key) => {
            if (suffixes.some(suffix => key.endsWith(suffix))) {
                localStorage.removeItem(key);
            }
        })
    }

    /**
     * Escape a value for safe insertion into HTML attribute or text content.
     * @param {*} value
     * @returns {string}
     */
    static esc(value) {
        if (value === null || value === undefined) {
            return ''
        }

        return String(value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;')
    }

    static isFunctionEmpty(func) {
        const m = func.toString().match(/\{([\s\S]*)\}/m)[1]
        const bodyFunc = m.replace(/^\s*\/\/.*$/mg, '').trim()

        return bodyFunc.length > 0 ? false : true
    }

    /**
     * @param {string} value
     * @returns {string}
     */
    static toCamelCase(value) {
        return value
            .replace(/[-_\s]+(.)?/g, (_, c) => (c ? c.toUpperCase() : ''))
            .replace(/^(.)/, c => c.toLowerCase())
    }

    /**
     * @param {string} value
     * @returns {string}
     */
    static toTitleCase(value) {
        return value
            .toString()
            .toLowerCase()
            .replace(/(?:^|\s)\S/g, c => c.toUpperCase())
    }

    /**
     * @param {string} value
     * @returns {string}
     */
    static toHeadline(value) {
        return value
            .toString()
            .replace(/([a-z])([A-Z])/g, '$1 $2')
            .replace(/[-_]+/g, ' ')
            .replace(/\s+/g, ' ')
            .trim()
            .toLowerCase()
            .replace(/(?:^|\s)\S/g, c => c.toUpperCase())
    }

    //#region file helper

    /**
     * @deprecated Use FileHelper.isFileValid instead
     * @param {File} file
     * @param {number} maxSizeInMB
     * @param {string|null} mimeType
     * @returns {boolean}
     */
    static isFileValid(file, maxSizeInMB, mimeType = null) {
        return FileHelper.isFileValid(file, maxSizeInMB, mimeType)
    }

    /**
     * @deprecated Use FileHelper.isFileSizeValid instead
     * @param {File} file
     * @param {number} maxSizeInMB
     * @returns {boolean}
     */
    static isFileSizeValid(file, maxSizeInMB) {
        return FileHelper.isFileSizeValid(file, maxSizeInMB)
    }

    /**
     * @deprecated Use FileHelper.isFileMimeValid instead
     * @param {File} file
     * @param {string|null} mimeType
     * @returns {boolean}
     */
    static isFileMimeValid(file, mimeType = null) {
        return FileHelper.isFileMimeValid(file, mimeType)
    }

    /**
     * @deprecated Use FileHelper.getAvailableMime instead
     * @param {string|null} type
     * @returns {Array<{type: string, ext: string, mime: string}>|null}
     */
    static getAvailableMime(type = null) {
        return FileHelper.getAvailableMime(type)
    }

    //#endregion
}
