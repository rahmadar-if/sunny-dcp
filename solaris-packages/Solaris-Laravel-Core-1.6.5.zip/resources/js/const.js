const Currency = {
    Rupiah: "57875bec-ae54-44ff-b526-9e1aa751ee2f",
    SingaporeDollar: "7f944852-388d-4eb0-b609-fc52d2edbaca",
    MalaysianRinggit: "f3935633-3b26-4cff-8dfc-6f8b3f1af842",
    Baht: "fed65eab-0b13-47cb-9255-6d26c98c767e",
    Dong: "fb3ce081-add4-47f8-afd6-a08a6987a227",
    PhilippinePeso: "1bd9d83e-671f-4248-9368-089dd169cf94",
    Kyat: "f49e7d58-9919-4e12-9460-d5424ec5a0ba",
    Riel: "5b89781f-925f-4dc9-8f66-e9f12d751f6a",
    Kip: "4ae4b24c-444a-4cb9-b0da-83be3cd8d246",
    USDollar: "7aa0fb09-04b7-45c5-8217-c5b12b14ec44",
    Euro: "b8bfb12a-d18b-41f0-a2ed-fad54b4cec2a",
    PoundSterling: "5f50e078-7d35-4c5e-b184-555e07b16c94",
    YuanRenminbi: "c59ad70b-16a1-4743-b7de-bceee3c84447",
    Yen: "8ab5d939-15d9-4a26-860e-95a6f667c3c5",
    Won: "516320b7-5b10-4e3c-9d1a-2b5c9e4a3268",
    IndianRupee: "391ee811-8048-46a9-a099-49879ca90fbb"
}

const Salutation = {
    Mr: "c34330df-6e12-4e07-a664-32df528c7557",
    Ms: "a76672f4-a1f2-4cc8-b208-58608a1636ff",
    Dr: "6451fe25-5da0-46cc-8078-5ef4df017ec3",
    Mrs: "1cf46056-f297-4b39-8004-10493d84e718"
}

const Gender = {
    Male: "d8e1d02a-8273-42d4-bc24-8bc8dd9e459b",
    Female: "fe8d58e4-024c-4598-a138-d2b0d6108467"
}

const ActivityStatus = {
    OnSchedule: "f6613bbe-06bb-4062-b632-4f05695bcfb8",
    InProgress: "d029cad7-f4b3-477c-9e42-40a8246d63fb",
    Finish: "808f166e-038c-4b55-85bc-2f86916ba98d"
}

const Role = {
    User: '019c27d4-831f-7e33-8b9f-f328320c4d8b',
    Admin: '019c27d4-831f-74b3-859f-a48dcca44e07'
}

const PermissionType = {
    User: '0199329a-aaf7-7d59-bca6-d91b349f489e',
    Role: '0199329a-aaf7-73ed-80a3-ece242100c97',
    Permission: '0199329a-aaf7-7b04-9972-e84c648197b5',
}

const RightLevel = {
    Grant: '0199329b-a4d5-7276-a28f-ff9ab24a6a04',
    GrantDelegate: '0199329b-a4d5-77cf-9e77-047989a4790e',
    Deny: '0199329b-a4d5-73a7-8205-1a1afd8d9565'
}

const RightOperation = {
    Create: '019932a6-2c91-70ce-b9c7-c3e185b53621',
    Read: '019932a6-2c91-74f2-9a5b-2d52c803b2a8',
    Update: '019932a6-2c91-7879-b6a6-2c4438bdc6ea',
    Delete: '019932a6-2c91-7618-a769-3f25fa0ac0af'
}

const ApprovalRequestStatus = {
    Pending:    '019cac97-f75e-7da5-9f61-c5e2ed7b525f',
    InProgress: '019cac97-f75e-74f2-90f9-031ecc5840ae',
    Approved:   '019cac97-f75e-76dc-b36c-a44d9dfa0d23',
    Rejected:   '019cac97-f75e-7d85-a569-33b4678f6e31',
    Cancelled:  '019cac97-f75e-7a96-be23-8f20aca26ff9',
    Expired:    '019cac97-f75e-756e-89a0-72190588bec5',
}

const ApprovalLevelStatus = {
    Pending:    '019cac96-2dcd-78cc-84a7-a2cc514ea200',
    InProgress: '019cac96-2dcd-7d5c-896d-39a84b339122',
    Approved:   '019cac96-2dcd-75b3-bce7-ba0111518a26',
    Rejected:   '019cac96-2dcd-7205-a922-07921c6205f6',
    Skipped:    '019cac96-2dcd-7740-8427-e2c6f9ffe150',
}

const ApprovalAssignmentStatus = {
    Pending:   '019cac97-782c-7b12-86cc-0cdba64270f4',
    Approved:  '019cac97-782c-73bc-b5ad-89c3bcbcb914',
    Rejected:  '019cac97-782c-78dc-ab5e-58941eede283',
    Dismissed: '019cac97-782c-770b-8140-54f1e1893afa',
}

export {
    Currency,
    Salutation,
    Gender,
    ActivityStatus,
    Role,
    PermissionType,
    RightLevel,
    RightOperation,
    ApprovalRequestStatus,
    ApprovalLevelStatus,
    ApprovalAssignmentStatus
}