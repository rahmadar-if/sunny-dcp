import $ from 'jquery'
import * as Popper from '@popperjs/core'
import * as bootstrap from 'bootstrap'
import 'block-ui/jquery.blockUI'
import Waves from 'node-waves/src/js/waves'
import SimpleBar from 'simplebar'
import ApexCharts from 'apexcharts'
import Swal from 'sweetalert2/dist/sweetalert2.js'
import Pickr from '@simonwep/pickr/dist/pickr.es5.min'
import SolarSingleton from './solaris/solar/solar-singleton'
import SolarUI from './solaris/solar/solar-ui'
import "./echo"

import.meta.glob([
    '../../../../../resources/assets/**',
    '../assets/images/**'
])

window.jQuery     = window.$ = $
window.Popper     = Popper
window.bootstrap  = bootstrap
window.SimpleBar  = SimpleBar
window.ApexCharts = ApexCharts
window.Swal       = Swal
window.Pickr      = Pickr

Waves.attach(".btn-wave", ["waves-light"])
Waves.init()

const solarUI = new SolarUI()
SolarSingleton.set(solarUI)
solarUI.init()
