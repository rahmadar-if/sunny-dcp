import SolarListDetail from "@core-js/solaris/solar/solar-list-detail"
import JsonViewer from "../../solaris/json-viewer"
import DateHelper from "../../solaris/date-helper"

export default class ApiRequestLogDetail extends SolarListDetail {
    init() {
        this.detailModal = this.get("audit-log-detail-modal")
        this.detailBody = document.getElementById("audit-log-detail-body")

        this.columnRender("method", this.methodRender.bind(this))
        this.columnRender("status", this.statusRender.bind(this))
        this.columnRender("api_key", this.apiKeyRender.bind(this))
    }

    /**
     * @param {string} data
     * @returns {string}
     */
    methodRender(data) {
        return `<span class="badge bg-${this._methodColor(data)}">${data}</span>`
    }

    /**
     * @param {number} data
     * @returns {string}
     */
    statusRender(data) {
        return `<span class="badge bg-${this._statusColor(data)}">${data}</span>`
    }

    /**
     * @param {*} data
     * @param {Object} rowData
     * @returns {string}
     */
    apiKeyRender(data, rowData) {
        return rowData.api_key?.name ?? `<span class="text-muted">—</span>`
    }

    /**
     * @param {HTMLTableRowElement} row
     * @param {Object} data
     * @returns {Promise<void>}
     */
    async view(row, data) {
        await this._showDetail(data)
    }

    /**
     * @param {HTMLTableRowElement} row
     * @param {Object} data
     * @returns {Promise<void>}
     */
    async rowDoubleClick(row, data) {
        await this._showDetail(data)
    }

    /**
     * @param {Object} data
     * @returns {Promise<void>}
     */
    async _showDetail(data) {
        this.helper.loadingPage(true)

        try {
            const req = await this.axios.get(`${BASE_URL}/admin/user/${this.parentValue}/audit-log/${data.id}`)
            const res = req.data

            if (!res.success) {
                this.helper.errorAlert({ title: res.message })
                return
            }

            this._renderDetail(res.data)
            this.detailModal?.show()
        } catch (e) {
            if (!e?.response) {
                this.helper.errorAlert({ title: "Something went wrong" })
            }
        } finally {
            this.helper.loadingPage(false)
        }
    }

    /**
     * @param {string} method
     * @returns {string}
     */
    _methodColor(method) {
        switch (method) {
            case "GET":
                return "success"
            case "POST":
                return "primary"
            case "PATCH":
            case "PUT":
                return "warning"
            case "DELETE":
                return "danger"
            default:
                return "secondary"
        }
    }

    /**
     * @param {number} status
     * @returns {string}
     */
    _statusColor(status) {
        if (status >= 500) {
            return "danger"
        }

        if (status >= 400) {
            return "warning"
        }

        return "success"
    }

    /**
     * @param {string} label
     * @param {*} value
     * @param {string} emptyLabel
     * @returns {string}
     */
    _section(label, value, emptyLabel) {
        const body = this._sectionBody(value, emptyLabel)

        return `<div class="mb-3">
            <div class="fs-11 fw-semibold text-uppercase text-muted mb-2">${label}</div>
            ${body}
        </div>`
    }

    /**
     * `boundBody()` on the server caps request/response bodies at a byte limit — past that it
     * stores `{_truncated, _bytes, _preview}` instead of the parsed body, and `_preview` is a raw
     * JSON string cut off mid-object, not something the JSON viewer can parse. Show it as what it
     * is (a truncated excerpt) instead of running it through the colorized renderer.
     * @param {*} value
     * @param {string} emptyLabel
     * @returns {string}
     */
    _sectionBody(value, emptyLabel) {
        if (value === null || value === undefined) {
            return `<div class="audit-log-empty-block">${emptyLabel}</div>`
        }

        if (value._truncated) {
            return `
                <div class="audit-log-empty-block text-start mb-2">
                    <i class="ri-alert-line me-1"></i>Truncated — the full body was ${value._bytes.toLocaleString()} bytes, only the first part below is stored.
                </div>
                <pre class="json-view" style="white-space: pre-wrap;">${JsonViewer.escape(value._preview)}</pre>
            `
        }

        return JsonViewer.render(value)
    }

    /**
     * @param {Object} log
     * @returns {void}
     */
    _renderDetail(log) {
        this.detailBody.innerHTML = `
            <div class="d-flex align-items-center justify-content-between mb-2">
                <div>
                    <span class="badge bg-${this._methodColor(log.method)} me-2">${log.method}</span>
                    <span class="fs-13">${log.path}</span>
                </div>
                <span class="badge bg-${this._statusColor(log.status)}">${log.status}</span>
            </div>
            <p class="fs-11 text-muted mb-3">
                ${DateHelper.formatDatetime(log.created_at, "dd MMM yyyy hh:mm:ss A")}
                · ${log.duration_ms ?? "—"}ms
                · ${log.api_key?.name ?? "Unknown key"}
                · ${log.ip_address ?? "—"}
            </p>

            ${this._section("Query", log.query, "No query parameters")}
            ${this._section("Request Headers", log.request_headers, "No headers captured")}
            ${this._section("Request Body", log.request_body, "No request body — GET request, or no longer retained")}
            ${this._section("Response Body", log.response_body, "No response body, or no longer retained")}
        `
    }
}
