import SolarListPage from "../../solaris/solar/solar-list-page";
import UserAssign from "../../solaris/assign/user-assign";
import AiAssign from "../../solaris/assign/ai-assign";
import IntegrationAssign from "../../solaris/assign/integration-assign";
import DateHelper from "../../solaris/date-helper";
import FileHelper from "../../solaris/file-helper";
import ProfilePicture from "@core-js/solaris/profile-picture";

const VISIBLE_ROLE = 2

export default class UserListPage extends SolarListPage {
    init() {
        this.initModal()

        this.columnRender("name", this.nameColumnRender.bind(this))
        this.columnRender("email", this.emailColumnRender.bind(this))
        this.columnRender("email_verified_at", this.emailVerifiedColumnRender.bind(this))
        this.columnRender("role", this.roleColumnRender.bind(this))
        this.columnCreated("role", this.roleColumnCreated.bind(this))
        this.columnRender("ai_access", this.aiAccessColumnRender.bind(this))
        this.columnCreated("ai_access", this.aiAccessColumnCreated.bind(this))
        this.columnRender("total_attachment", this.totalAttachmentColumnRender.bind(this))

        this.roleModal = this.get("user-role-modal")
        this.roleModalBody = document.getElementById("user-role-modal-body")

        this.aiRoleModal = this.get("user-ai-role-modal")
        this.aiRoleModalBody = document.getElementById("user-ai-role-modal-body")

        this.assign = new UserAssign("user-assign-modal")
        this.assign.on("closed", (changed) => changed ? this.refresh() : null)

        this.aiAssign = new AiAssign("ai-assign-modal")
        this.aiAssign.on("closed", (changed) => changed ? this.refresh() : null)

        this.integrationAssign = new IntegrationAssign("integration-assign-modal")
        this.integrationAssign.on("closed", (changed) => changed ? this.refresh() : null)
    }

    async ready(settings, json) {
        this.table.visibleColumn("username", false)
    }

    openViewPage(id) {
        this.helper.loadingPage(true)
        window.location = `${BASE_URL}/admin/user/${id}`
    }

    rowDoubleClick(row, data) {
        this.openViewPage(data.id)
    }

    async view(row, data) {
        this.openViewPage(data.id)
    }

    initModal() {
        /** @type {ProfilePicture} */
        const profilePicture  = this.get("user-modal-profile_picture")
        const password        = this.form.get("password")
        const confirmPassword = this.form.get("password_confirmation")
        const passwordMode    = this.form.get("password_mode")

        passwordMode.on("change", (val) => {
            if (val && val.id == "manual") {
                password.show()
                password.required()

                confirmPassword.show()
                confirmPassword.required()
            } else {
                password.hidden()
                password.reset()
                password.optional()

                confirmPassword.hidden()
                confirmPassword.reset()
                confirmPassword.optional()
            }
        })

        password.on("change", (value) => {
            const isPasswordConfEmpty = this.helper.isEmpty(confirmPassword.get())
            const isMatch = !isPasswordConfEmpty && !this.helper.isEmpty(value) && value === confirmPassword.get()

            if (!isPasswordConfEmpty && !isMatch) {
                confirmPassword.error()
                confirmPassword.setMessage("Confirm password does not match")
            }
        })

        confirmPassword.on("change", (value) => {
            if (!this.helper.isEmpty(password.get()) && password.get() !== value) {
                confirmPassword.error()
                confirmPassword.setMessage("Confirm password does not match")
            }
        })

        this.form
            .registerProfilePicture(profilePicture, (res) => `${BASE_URL}/admin/user/avatar/${res.data.id}`)
            .addValidation("password_confirmation", (value) => {
                const isPasswordManual = passwordMode.get()?.id == "manual" ?? "auto"
                const isValid = isPasswordManual ? true :
                    (!this.helper.isEmpty(value) && (password.get() !== value) ? false : true)

                return {
                    success: isValid,
                    message: "Confirm password does not match",
                }
            })
            .on("success", (res) => {
                if (res.data?.password) {
                    this.showPasswordGeneratedAlert(res.data.password)
                }
            })

        this.modal.on("hidden", () => {
            passwordMode.set("auto")
        })
    }

    nameColumnRender(data, rowData) {
        const initialName = this.helper.getInitialName(data)

        return `<div class="d-flex align-items-center gap-2">
            <div class="lh-1">
                <span class="avatar avatar-rounded avatar-md ${!rowData.profile_picture_id ? "bg-secondary" : ""}">
                    ${rowData.profile_picture_id ? `<img src="${BASE_URL}/core/images/thumbnail/${rowData.profile_picture_id}" alt="">` : initialName}
                </span>
            </div>
            <div class="d-flex align-items-center gap-1">
                <a class="text-decoration-underline" href="${BASE_URL}/admin/user/${rowData.id}">${data}</a>
            </div>
        </div>`
    }

    emailColumnRender(data, rowData) {
        return `<div class="d-flex flex-column gap-1">
            <span><i class="ri-mail-line me-2"></i>${data}</span>
            <span class="text-muted fs-12"><i class="ri-user-line me-2"></i>${rowData.username ?? '-'}</span>
        </div>`
    }

    emailVerifiedColumnRender(data, rowData) {
        const message = !data ? 'Awaiting Verification' : 'Confirmed'
        const color = !data ? 'danger' : 'success'
        const badge = `<span class="badge bg-${color}">${message}</span>`

        return data ?
            `<div class="d-flex align-items-start flex-column gap-2">
                ${badge}
                <span><i class="ri-time-line me-2"></i>${DateHelper.formatDatetime(data)}</span>
            </div>`
            : badge
    }

    totalAttachmentColumnRender(data, rowData) {
        const used           = rowData.total_uploaded_size ?? 0
        const percentage     = MAX_SIZE > 0 ? Math.min(100, Math.round((used / MAX_SIZE) * 10000) / 100) : 0
        const barColor       = percentage >= 90 ? 'danger' : (percentage >= 70 ? 'warning' : 'success')
        const usedFormatted  = FileHelper.getHumanReadableSize(used)
        const limitFormatted = FileHelper.getHumanReadableSize(MAX_SIZE)

        return `<div class="d-flex flex-column gap-1">
            <div class="d-flex align-items-center justify-content-between">
                <span class="fs-12 text-muted">${rowData.total_file ?? 0} files</span>
                <span class="fs-12 text-muted">${usedFormatted} / ${limitFormatted}</span>
            </div>
            <div class="progress" style="height: 4px;">
                <div class="progress-bar bg-${barColor}"
                     role="progressbar"
                     style="width: ${percentage}%"
                     aria-valuenow="${percentage}"
                     aria-valuemin="0"
                     aria-valuemax="100"></div>
            </div>
            <span class="fs-12 text-muted">${percentage}% used</span>
        </div>`
    }

    roleColumnRender(data, rowData) {
        return this._roleBadgesHtml(this._userRoles(rowData), "data-role-more")
    }

    roleColumnCreated(row, cell, cellData, rowData) {
        cell.querySelector("[data-role-more]")?.addEventListener("click", () => {
            this._showRoleModal(this.roleModalBody, this.roleModal, this._userRoles(rowData))
        })
    }

    aiAccessColumnRender(data, rowData) {
        return this._roleBadgesHtml(this._rolesByGroup(rowData, "ai"), "data-ai-role-more")
    }

    aiAccessColumnCreated(row, cell, cellData, rowData) {
        cell.querySelector("[data-ai-role-more]")?.addEventListener("click", () => {
            this._showRoleModal(this.aiRoleModalBody, this.aiRoleModal, this._rolesByGroup(rowData, "ai"))
        })
    }

    /**
     * Role column only ever shows the row's own kind — a regular user's assignable roles are
     * `group_name=user`, an integration user's are `group_name=integration`.
     * @param {Object} rowData
     * @returns {Array<Object>}
     */
    _userRoles(rowData) {
        return this._rolesByGroup(rowData, rowData.is_integration ? "integration" : "user")
    }

    /**
     * @param {Object} rowData
     * @param {string} group
     * @returns {Array<Object>}
     */
    _rolesByGroup(rowData, group) {
        return (rowData.roles ?? []).filter(role => role.group_name === group)
    }

    /**
     * @param {Array<Object>} roles
     * @param {string} overflowAttr
     * @returns {string}
     */
    _roleBadgesHtml(roles, overflowAttr) {
        if (roles.length === 0) {
            return `<div class="d-flex flex-wrap align-items-center gap-1"><span class="badge bg-danger">None</span></div>`
        }

        const remaining = roles.length - VISIBLE_ROLE

        let badges = roles.slice(0, VISIBLE_ROLE).map(this._roleBadge).join("")
        if (remaining > 0) {
            badges += `<span class="badge bg-secondary" role="button" ${overflowAttr}>${remaining}+</span>`
        }

        return `<div class="d-flex flex-wrap align-items-center gap-1">${badges}</div>`
    }

    /**
     * Shows every role in the group, including the ones already visible as badges, so the modal
     * reads on its own without cross-referencing the row.
     * @param {HTMLElement} body
     * @param {*} modal
     * @param {Array<Object>} roles
     * @returns {void}
     */
    _showRoleModal(body, modal, roles) {
        body.innerHTML = roles
            .map(role => `<tr><td>${this._roleBadge(role)}</td></tr>`)
            .join("")

        modal?.show()
    }

    /**
     * @param {Object} role
     * @returns {string}
     */
    _roleBadge(role) {
        return `<span class="badge bg-success">${role.name}</span>`
    }

    onActionCreated(row, cell, rowData) {
        if (USER_ID == rowData.id) {
            cell.querySelector(".delete-action").remove()
        }

        if (rowData.is_integration) {
            this._integrationActions(row, cell, rowData)
            return
        }

        this._defaultActions(row, cell, rowData)
    }

    /**
     * Integration rows only get identity-scoped actions — no password/mobile/WhatsApp toggles
     * that don't apply to a machine account, no delete (revoke its API keys instead).
     * @param {HTMLElement} row
     * @param {HTMLElement} cell
     * @param {Object} rowData
     * @returns {void}
     */
    _integrationActions(row, cell, rowData) {
        cell.querySelector(".delete-action")?.remove()

        this.actionAfter(row, "view-action", {
            selector: "assign-action",
            label: "Assign Access",
            icon: "ri-user-settings-line",
            callback: async () => await this.integrationAssign.show(rowData.id)
        })

        this.actionAfter(row, "assign-action", {
            selector: "toggle-active-action",
            label: rowData.is_active ? "Nonactive" : "Active",
            icon: rowData.is_active ? "ri-forbid-line" : "ri-check-line",
            color: rowData.is_active ? "danger" : "success",
            callback: async () => await this.toggleActive(rowData.id, !rowData.is_active)
        })
    }

    /**
     * @param {HTMLElement} row
     * @param {HTMLElement} cell
     * @param {Object} rowData
     * @returns {void}
     */
    _defaultActions(row, cell, rowData) {
        let anchor = "view-action"

        if (!rowData.email_verified_at) {
            this.actionAfter(row, anchor, {
                selector: "verify-email-action",
                label: "Resend verification",
                icon: "ri-mail-check-line",
                callback: async () => await this.resendVerification(rowData.id)
            })
            anchor = "verify-email-action"
        }

        if (rowData.email_verified_at) {
            this.actionAfter(row, anchor, {
                selector: "reset-password-action",
                label: "Reset password",
                icon: "ri-refresh-line",
                callback: async () => await this.resetPassword(rowData.id)
            })
            anchor = "reset-password-action"

            if (rowData.is_active) {
                this.actionAfter(row, anchor, {
                    selector: "mobile-access-action",
                    label: rowData.is_mobile_access ? "Denied Mobile Access" : "Allow Mobile Access",
                    icon: "ri-smartphone-line",
                    color: rowData.is_mobile_access ? "danger" : "success",
                    callback: async () => await this.mobileAccess(rowData.id, !rowData.is_mobile_access)
                })
                anchor = "mobile-access-action"
            }
        }

        this.actionAfter(row, anchor, {
            selector: "assign-action",
            label: "Assign Access",
            icon: "ri-user-settings-line",
            callback: async () => await this.assign.show(rowData.id)
        })
        anchor = "assign-action"

        this.actionAfter(row, anchor, {
            selector: "assign-ai-action",
            label: "Assign AI Access",
            icon: "ri-robot-line",
            callback: async () => await this.aiAssign.show(rowData.id)
        })
        anchor = "assign-ai-action"

        if (rowData.email_verified_at && rowData.is_active) {
            this.actionAfter(row, anchor, {
                selector: "whatsapp-ai-action",
                label: rowData.whatsapp_enabled ? "Disabled WhatsApp AI" : "Enabled WhatsApp AI",
                icon: "ri-whatsapp-line",
                color: rowData.whatsapp_enabled ? "danger" : "success",
                callback: async () => await this.whatsappAI(rowData.id, !rowData.whatsapp_enabled)
            })
            anchor = "whatsapp-ai-action"

            this.actionAfter(row, anchor, {
                selector: "nonactive-action",
                label: "Nonactive",
                icon: "ri-forbid-line",
                color: "danger",
                callback: async () => await this.toggleActive(rowData.id, false)
            })
        } else if (rowData.email_verified_at && !rowData.is_active) {
            this.actionAfter(row, anchor, {
                selector: "active-action",
                label: "Active",
                icon: "ri-check-line",
                color: "success",
                callback: async () => await this.toggleActive(rowData.id, true)
            })
        }
    }

    async resetPassword(id) {
        const confirmed = await this.helper.confirm({
            title: "Are you sure?",
            message: "You will send a password reset link to this user's email."
        })

        if (!confirmed) {
            return
        }

        this.helper.loadingPage(true)

        try {
            const req = await this.axios.post(`${BASE_URL}/admin/user/reset-password/${id}`)
            const res = req.data

            if (res.success) {
                this.helper.successAlert({ title: res.message })
            } else {
                this.helper.errorAlert({ title: res.message })
            }
        } catch (e) {
            console.error(e)
            this.helper.errorAlert({ title: "Something went wrong" })
        } finally {
            this.helper.loadingPage(false)
        }
    }

    /**
     * @param {string} id
     * @param {boolean} status
     * @returns {Promise<void>}
     */
    async toggleActive(id, status) {
        const message = status
            ? "This user will be able to access the system again."
            : "This user will no longer be able to access the system."

        const confirmed = await this.helper.confirm({ title: "Are you sure?", message })

        if (!confirmed) {
            return
        }

        this.helper.loadingPage(true)

        try {
            const req = await this.axios.post(`${BASE_URL}/admin/user/active/${id}`, { status })
            const res = req.data

            if (res.success) {
                this.refresh()
                this.helper.successAlert({ title: res.message })
            } else {
                this.helper.errorAlert({ title: res.message })
            }
        } catch (e) {
            console.error(e)
            this.helper.errorAlert({ title: "Something went wrong" })
        } finally {
            this.helper.loadingPage(false)
        }
    }

    /**
     * @param {string} id
     * @param {boolean} status
     * @returns {Promise<void>}
     */
    async mobileAccess(id, status) {
        const message = status
            ? "This user will be granted mobile access."
            : "This user's mobile access will be revoked."

        const confirmed = await this.helper.confirm({ title: "Are you sure?", message })

        if (!confirmed) {
            return
        }

        this.helper.loadingPage(true)

        try {
            const req = await this.axios.post(`${BASE_URL}/admin/user/mobile-access/${id}`, { status })
            const res = req.data

            if (res.success) {
                this.refresh()
                this.helper.successAlert({ title: res.message })
            } else {
                this.helper.errorAlert({ title: res.message })
            }
        } catch (e) {
            console.error(e)
            this.helper.errorAlert({ title: "Something went wrong" })
        } finally {
            this.helper.loadingPage(false)
        }
    }

    /**
     * @param {string} id
     * @param {boolean} status
     * @returns {Promise<void>}
     */
    async whatsappAI(id, status) {
        const message = status
            ? "This user will be granted WhatsApp AI access."
            : "This user's WhatsApp AI access will be revoked."

        const confirmed = await this.helper.confirm({ title: "Are you sure?", message })

        if (!confirmed) {
            return
        }

        this.helper.loadingPage(true)

        try {
            const req = await this.axios.post(`${BASE_URL}/admin/user/whatsapp-ai/${id}`, { status })
            const res = req.data

            if (res.success) {
                this.refresh()
                this.helper.successAlert({ title: res.message })
            } else {
                this.helper.errorAlert({ title: res.message })
            }
        } catch (e) {
            console.error(e)
            this.helper.errorAlert({ title: "Something went wrong" })
        } finally {
            this.helper.loadingPage(false)
        }
    }

    async resendVerification(id) {
        const req = await this.axios.post(`${BASE_URL}/admin/user/verify-email/${id}`)

        const res = req.data
        if (!res.success) {
            await this.helper.errorAlert({ title: "Oops! There was an error", message: res.message, timeout: 3000 })
        } else {
            await this.helper.successAlert({ title: "Resend success", message: res.message, timeout: 3000 })
        }
    }

    showPasswordGeneratedAlert(password) {
        Swal.fire({
            title: 'User Created',
            html: `<div class="text-start mt-3">
                <p class="mb-2">Generated password:</p>
                <div class="input-group">
                    <input type="text" id="generated-password" value="${password}" readonly class="form-control font-monospace"/>
                    <button id="copy-password-btn" class="btn btn-primary">Copy</button>
                </div>
                <p class="mt-2 mb-0 text-muted small">
                    Make sure to save this password - it won't be shown again.
                </p>
            </div>`,
            icon: 'success',
            confirmButtonText: 'Done',
            didOpen: () => {
                document.getElementById('copy-password-btn').addEventListener('click', () => {
                    const input = document.getElementById('generated-password')
                    input.select()
                    navigator.clipboard.writeText(input.value)

                    const btn = document.getElementById('copy-password-btn')
                    btn.textContent = 'Copied!'
                    setTimeout(() => btn.textContent = 'Copy', 1500)
                });
            }
        })
    }
}