import IntegrationPage from "./integration-page"

export default new IntegrationPage()
