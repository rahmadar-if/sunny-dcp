import SolarListDetail from "@core-js/solaris/solar/solar-list-detail"

export default class ApiKeyDetail extends SolarListDetail {
    init() {
        this.columnRender("rate_limit", this.tierRender.bind(this))
    }

    /**
     * @param {string|null} data
     * @returns {string}
     */
    tierRender(data) {
        return `<span class="badge bg-light text-muted border">${data ?? "default"}</span>`
    }

    /**
     * @param {HTMLTableRowElement} row
     * @param {HTMLElement} cell
     * @param {Object} rowData
     * @returns {void}
     */
    onActionCreated(row, cell, rowData) {
        this.actionAppend(row, {
            selector: "revoke-action",
            label: "Revoke",
            icon: "ri-forbid-line",
            color: "danger",
            callback: async () => await this._revoke(rowData.id)
        })

        if (rowData.revoked_at) {
            cell.querySelector(".revoke-action")?.classList.add("disabled")
        }
    }

    /**
     * @param {string} id
     * @returns {Promise<void>}
     */
    async _revoke(id) {
        const confirmed = await this.helper.confirm({
            title: "Revoke this key?",
            message: "Any integration still using it will start failing authentication immediately."
        })

        if (!confirmed) {
            return
        }

        this.helper.loadingPage(true)

        try {
            const req = await this.axios.post(`${BASE_URL}/admin/user/${this.parentValue}/api-key/${id}/revoke`)
            const res = req.data

            if (res.success) {
                await this.refresh()
                this.helper.successAlert({ title: "Key revoked" })
            } else {
                this.helper.errorAlert({ title: res.message })
            }
        } catch (e) {
            if (!e?.response) {
                this.helper.errorAlert({ title: "Something went wrong" })
            }
        } finally {
            this.helper.loadingPage(false)
        }
    }
}
