import UserListPage from "./list"

new UserListPage("user")