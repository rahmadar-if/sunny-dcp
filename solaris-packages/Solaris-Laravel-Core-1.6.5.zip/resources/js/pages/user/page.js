import SolarEditPage from "@core-js/solaris/solar/solar-edit-page"
import UserSessionDetail from "./session-detail"

export default class UserPage extends SolarEditPage {

	//#region Lifecycle

	init() {
		this.nameDisplay = document.getElementById('name-display')
		this.form.nonactive()

		this.initRoles()

		this.registerDetail("user-sessions", UserSessionDetail, "user_id")
	}

	//#endregion

	//#region Roles

	initRoles() {
		this.rolesModal = this.get('roles-modal')
		this.aiRolesModal = this.get('ai-roles-modal')

		document.getElementById('roles-display')?.addEventListener('click', (e) => {
			if (e.target.closest('#roles-more-badge')) {
				this.rolesModal?.show()
			}
		})

		document.getElementById('ai-roles-display')?.addEventListener('click', (e) => {
			if (e.target.closest('#ai-roles-more-badge')) {
				this.aiRolesModal?.show()
			}
		})
	}

	/**
	 * Identity roles mirror the user list's Role column: the row's own kind only. Null
	 * group_name (pre-migration role, not yet tagged) falls back to "user".
	 * @param {Array<Object>} roles
	 * @param {boolean} isIntegration
	 * @returns {void}
	 */
	_renderRoles(roles, isIntegration) {
		const identityGroup = isIntegration ? 'integration' : 'user'
		const identityRoles = (roles ?? []).filter(role => identityGroup === 'integration'
			? role.group_name === 'integration'
			: (role.group_name === 'user' || role.group_name == null))
		const aiRoles = (roles ?? []).filter(role => role.group_name === 'ai')

		this._renderRoleGroup(identityRoles, 'roles-display', 'roles-more-badge', 'roles-modal-body',
			(role) => `bg-${role.name == "Admin" ? "success" : "info"}`)

		this._renderRoleGroup(aiRoles, 'ai-roles-display', 'ai-roles-more-badge', 'ai-roles-modal-body', () => 'bg-info')
	}

	/**
	 * @param {Array<Object>} roles
	 * @param {string} displayId
	 * @param {string} moreBadgeId
	 * @param {string} modalBodyId
	 * @param {(role: Object) => string} badgeClass
	 * @returns {void}
	 */
	_renderRoleGroup(roles, displayId, moreBadgeId, modalBodyId, badgeClass) {
		const display = document.getElementById(displayId)
		const modalBody = document.getElementById(modalBodyId)
		const badge = (role) => `<span class="badge ${badgeClass(role)}">${role.name}</span>`

		let html = roles.length === 0
			? `<span class="badge bg-danger">None</span>`
			: roles.slice(0, 2).map(badge).join('')

		if (roles.length > 2) {
			html += `<span class="badge bg-secondary" role="button" id="${moreBadgeId}">${roles.length - 2}+</span>`
		}
		display.innerHTML = html

		modalBody.innerHTML = roles.map(role => `<tr><td>${badge(role)}</td></tr>`).join('')
	}

	//#endregion

	//#region Form Events

	/**
	 * @param {Object} data
	 * @returns {Promise<void>}
	 */
	async onRefreshed(data) {
		this.nameDisplay.innerText    = data.name
		this.breadcrumbName.innerText = data.name

		this._renderRoles(data.roles, data.user.is_integration)

		this._updateStorage(data)
		this._updateAccessCard(data)

		this.form.get('username')?.set(data.user.username)
	}

	/**
	 * @param {Object} data
	 * @returns {void}
	 */
	_updateAccessCard(data) {
		const user = data.user

		// Mobile access
		const mobileAccessBadge = document.getElementById('mobile-access-badge')
		if (mobileAccessBadge) {
			mobileAccessBadge.textContent = user.is_mobile_access ? 'Allowed' : 'Denied'
			mobileAccessBadge.className   = `badge ${user.is_mobile_access ? 'bg-success' : 'bg-danger'}`
		}

		// Notifications
		this._setNotifBadge('notif-badge-app',    user.is_app_notification)
		this._setNotifBadge('notif-badge-push',   user.is_push_notification)
		this._setNotifBadge('notif-badge-mobile', user.is_mobile_notification)
		this._setNotifBadge('notif-badge-email',  user.is_email_notification)

		// Two-Factor Authentication
		const is2fa    = !!user.two_factor_confirmed_at
		const method   = user.two_factor_method
		const since2fa = user.two_factor_confirmed_at
			? new Date(user.two_factor_confirmed_at).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
			: null

		const badgeActive   = document.getElementById('2fa-badge-active')
		const badgeMethod   = document.getElementById('2fa-badge-method')
		const badgeInactive = document.getElementById('2fa-badge-inactive')
		const sinceEl       = document.getElementById('2fa-since')

		if (is2fa) {
			badgeInactive?.classList.add('d-none')
			badgeActive?.classList.remove('d-none')
			if (badgeMethod) {
				badgeMethod.textContent = method === 'totp' ? 'Authenticator App' : 'Email OTP'
				badgeMethod.classList.remove('d-none')
			}
			if (sinceEl && since2fa) {
				sinceEl.textContent = `Since ${since2fa}`
				sinceEl.classList.remove('d-none')
			}
		} else {
			badgeActive?.classList.add('d-none')
			badgeMethod?.classList.add('d-none')
			badgeInactive?.classList.remove('d-none')
			sinceEl?.classList.add('d-none')
		}

		// SSO — Google
		const googleEmail   = data.sso?.google ?? null
		const googleEmailEl = document.getElementById('sso-google-email')
		const googleBadge   = document.getElementById('sso-google-badge')

		if (googleEmailEl) {
			googleEmailEl.textContent = googleEmail ?? 'Not connected'
		}

		if (googleBadge) {
			googleBadge.classList.toggle('d-none', !googleEmail)
		}
	}

	/**
	 * @param {string} id
	 * @param {boolean} isActive
	 * @returns {void}
	 */
	_setNotifBadge(id, isActive) {
		const el = document.getElementById(id)
		if (!el) {
			return
		}

		el.textContent = isActive ? 'On' : 'Off'
		el.className   = `badge ${isActive ? 'bg-success' : 'bg-danger'}`
	}

	/**
	 * @param {Object} data
	 * @returns {void}
	 */
	_updateStorage(data) {
		const storageInfo  = document.getElementById('storage-info')
		const maxSize      = parseInt(storageInfo?.dataset.maxSize ?? 10737418240)
		const maxFormatted = storageInfo?.dataset.maxFormatted ?? ''
		const usedBytes    = data.total_uploaded_size_raw ?? 0
		const percentage   = maxSize > 0 ? Math.min(100, parseFloat(((usedBytes / maxSize) * 100).toFixed(2))) : 0
		const barColor     = percentage >= 90 ? 'danger' : (percentage >= 70 ? 'warning' : 'success')

		const progressBar      = document.getElementById('storage-progress-bar')
		const fileSizeDisplay  = document.getElementById('file-size-display')
		const fileCountDisplay = document.getElementById('file-count-display')
		const storagePercent   = document.getElementById('storage-percentage')

		if (progressBar) {
			progressBar.style.width = `${percentage}%`
			progressBar.className   = `progress-bar bg-${barColor}`
			progressBar.setAttribute('aria-valuenow', percentage)
		}

		if (fileSizeDisplay)  fileSizeDisplay.innerText  = `${data.total_uploaded_size} / ${maxFormatted}`
		if (fileCountDisplay) fileCountDisplay.innerText = `${data.total_file} files`
		if (storagePercent)   storagePercent.innerText   = `${percentage}% used`
	}

	//#endregion
}
