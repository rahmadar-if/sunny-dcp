import ProfileSessionDetail from "../profile/session-detail";

export default class UserSessionDetail extends ProfileSessionDetail {

	onActionCreated(row, cell, rowData) {
		const isActive = !rowData.logged_out_at && !rowData.terminated_at;

		this.actionAppend(row, {
			selector: "terminate-action",
			label: "Terminate",
			icon: "ri-logout-box-r-line",
			color: "danger",
			callback: async () => await this._terminate(rowData.id)
		});

		if (!isActive) {
			cell.querySelector(".terminate-action")?.classList.add("disabled");
		}
	}

	/**
	 * @param {string} id
	 * @returns {Promise<void>}
	 */
	async _terminate(id) {
		const confirmed = await this.helper.confirm({
			title: "Terminate Session?",
			message: "This will forcefully log out the session. The user will be disconnected immediately."
		});

		if (!confirmed) {
			return;
		}

		this.helper.loadingPage(true);

		try {
			const req = await this.axios.post(`${BASE_URL}/admin/user/session-terminate/${id}`);
			const res = req.data;

			if (res.success) {
				this.refresh();
				this.helper.successAlert({ title: res.message });
			} else {
				this.helper.errorAlert({ title: res.message });
			}
		} catch (e) {
			if (!e?.response) {
				this.helper.errorAlert({ title: "Something went wrong" });
			}
		} finally {
			this.helper.loadingPage(false);
		}
	}
}
