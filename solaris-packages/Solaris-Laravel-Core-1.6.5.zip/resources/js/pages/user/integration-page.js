import SolarEditPage from "@core-js/solaris/solar/solar-edit-page"
import IntegrationAssign from "../../solaris/assign/integration-assign"
import ApiRequestLogDetail from "./api-request-log-detail"
import ApiKeyDetail from "./api-key-detail"
import GenerateKeyModal from "./generate-key-modal"

export default class IntegrationPage extends SolarEditPage {
    init() {
        this.nameDisplay = document.getElementById("name-display")
        this.userId = document.getElementById("integration-identity")?.dataset.userId

        this.initAccess()
        this.initApiKeys()
        this.initAuditLog()
    }

    //#region Access

    /**
     * @returns {void}
     */
    initAccess() {
        this.assign = new IntegrationAssign("integration-assign-modal")
        this.assign.on("closed", (changed) => changed ? this.refresh() : null)

        document.getElementById("btn-assign-access")?.addEventListener("click", async () => {
            await this.assign.show(this.userId)
        })
    }

    /**
     * @param {Array<Object>} roles
     * @param {Array<Object>} permissions
     * @returns {void}
     */
    _renderAccess(roles, permissions) {
        const container = document.getElementById("integration-access-badges")

        if (!container) {
            return
        }

        const badges = [
            ...(roles ?? [])
                .filter(role => role.group_name === "integration")
                .map(role => `<span class="badge bg-primary">${role.name}</span>`),
            ...(permissions ?? [])
                .filter(permission => permission.group_name === "integration")
                .map(permission => `<span class="badge bg-light text-muted border">${permission.name}</span>`)
        ]

        container.innerHTML = badges.length > 0 ? badges.join("") : `<span class="badge bg-danger">None</span>`
    }

    //#endregion

    //#region API Keys

    /**
     * @returns {void}
     */
    initApiKeys() {
        this.apiKeyTable = new ApiKeyDetail("api-key", "user_id", this.userId)

        this.generateKeyModal = new GenerateKeyModal()
        this.generateKeyModal.form.on("success", () => this.apiKeyTable.refresh())
    }

    //#endregion

    //#region Audit Log

    /**
     * @returns {void}
     */
    initAuditLog() {
        this.auditLog = new ApiRequestLogDetail("audit-log", "user_id", this.userId)
    }

    //#endregion

    //#region Form Events

    /**
     * @param {Object} data
     * @returns {void}
     */
    onRefreshed(data) {
        this.nameDisplay.innerText = data.name
        this.breadcrumbName.innerText = data.name

        this._renderAccess(data.roles, data.permissions)
        this._updateStorage(data)
    }

    /**
     * @param {Object} data
     * @returns {void}
     */
    _updateStorage(data) {
        const storageInfo  = document.getElementById("storage-info")
        const maxSize      = parseInt(storageInfo?.dataset.maxSize ?? 10737418240)
        const maxFormatted = storageInfo?.dataset.maxFormatted ?? ""
        const usedBytes    = data.total_uploaded_size_raw ?? 0
        const percentage   = maxSize > 0 ? Math.min(100, parseFloat(((usedBytes / maxSize) * 100).toFixed(2))) : 0
        const barColor     = percentage >= 90 ? "danger" : (percentage >= 70 ? "warning" : "success")

        const progressBar      = document.getElementById("storage-progress-bar")
        const fileSizeDisplay  = document.getElementById("file-size-display")
        const fileCountDisplay = document.getElementById("file-count-display")
        const storagePercent   = document.getElementById("storage-percentage")

        if (progressBar) {
            progressBar.style.width = `${percentage}%`
            progressBar.className   = `progress-bar bg-${barColor}`
            progressBar.setAttribute("aria-valuenow", percentage)
        }

        if (fileSizeDisplay) {
            fileSizeDisplay.innerText = `${data.total_uploaded_size} / ${maxFormatted}`
        }

        if (fileCountDisplay) {
            fileCountDisplay.innerText = `${data.total_file} files`
        }

        if (storagePercent) {
            storagePercent.innerText = `${percentage}% used`
        }
    }

    //#endregion
}
