import UserPage from "./page"

export default new UserPage()
