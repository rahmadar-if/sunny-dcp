import SolarModalPage from "@core-js/solaris/solar/solar-modal-page"

export default class GenerateKeyModal extends SolarModalPage {
    constructor() {
        super("generate-key-modal")
    }

    init() {
        this.form.hiddenSuccessAlert()

        this.form.on("success", (res) => {
            if (res.data?.key) {
                this._showGeneratedKeyAlert(res.data.key)
            }
        })
    }

    /**
     * Printed once and never recoverable — only the hash is stored server-side.
     * @param {string} key
     * @returns {void}
     */
    _showGeneratedKeyAlert(key) {
        Swal.fire({
            title: "API Key Generated",
            html: `<div class="text-start mt-3">
                <p class="mb-2">Copy this key now. It cannot be shown again:</p>
                <div class="input-group">
                    <input type="text" id="generated-key" value="${key}" readonly class="form-control font-monospace"/>
                    <button id="copy-key-btn" class="btn btn-primary">Copy</button>
                </div>
            </div>`,
            icon: "success",
            confirmButtonText: "Done",
            didOpen: () => {
                document.getElementById("copy-key-btn").addEventListener("click", () => {
                    const input = document.getElementById("generated-key")
                    input.select()
                    navigator.clipboard.writeText(input.value)

                    const btn = document.getElementById("copy-key-btn")
                    btn.textContent = "Copied!"
                    setTimeout(() => btn.textContent = "Copy", 1500)
                })
            }
        })
    }
}
