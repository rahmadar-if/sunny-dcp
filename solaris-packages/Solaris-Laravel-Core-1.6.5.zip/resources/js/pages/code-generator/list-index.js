import CodeGeneratorListPage from "./list"

new CodeGeneratorListPage("code-generator")