import SolarListPage from "@core-js/solaris/solar/solar-list-page";
import MaskFormat from "./mask-format";
import Filter from "@core-js/solaris/filter/filter";
import axios from "@core-js/libs/axios";
import TableLookup from "@core-js/solaris/table/table-lookup";

export default class CodeGeneratorListPage extends SolarListPage {
    init() {
        this.columnRender("active", this.activeColumnRender.bind(this))

        this.initModal()
        this.initView()
        this.initTrigger()
    }

    initModal() {
        const code = this.form.get("code")
        const column = this.form.get("column")
        const active = this.form.get("active")

        this.maskFormat = new MaskFormat('.mask-format-wrap')

        code.on("change", (val) => {
            this.maskFormat.setTable(val?.id)
            column.reset()

            if (val) {
                column.enabled()
            } else {
                column.disabled()
            }
        })

        column.init({
            param: (param) => {
                param.table = code.get()?.id
                return param
            }
        })

        this.maskFormat.on("change", (val) => {
            if (!this.helper.isEmpty(val)) {
                this.maskFormat.resetValidation()
            }
        })

        this.modal
            .on("show", () => {
                if (!this.form.isEdit()) {
                    active.set(true, true)
                }
            })
            .on("hide", () => {
                this.maskFormat.reset()
            })

        this.form.on("submitting", () => {
            this.form.showErrorAlert()

            if (this.helper.isEmpty(this.maskFormat.get())) {
                this.hiddenErrorAlert()
                this.maskFormat.error()
                throw "Mask format is required"
            }

            this.form.addData("mask", this.maskFormat.get())
        })
    }

    async edit(row, data) {
        await this.modalForm.edit(data.id, (form, formData) => {
            this.form.get("column").enabled()
            this.maskFormat.setTable(formData.code?.id)
            this.maskFormat.set(formData.mask)
        })
    }

    activeColumnRender(data, rowData) {
        return `<span class="badge bg-${data ? 'success' : 'danger'}">${data ? 'Yes' : 'No'}</span>`
    }

    initView() {
        this._viewLookup     = this.get('code-generator-view-lookup')
        this._resetModalForm = this.get('code-generator-reset-form_ModalForm')

        this._viewLookup.on('choose-no-close', async (selection, rows) => {
            this._viewLookup.close()
            await this._resetModalForm.edit(rows[0].id)
        })
    }

    initTrigger() {
        /** @type {TableLookup}  */
        this._triggerLookup     = this.get('code-generator-trigger-lookup')
        this._triggerLookupCode = null

        this._triggerLookup.on('choose', async (selection, rows) => {
            await this._executeTrigger(this._triggerLookupCode, rows[0].id)
        })
    }

    onActionCreated(row, cell, rowData) {
        this.actionAfter(row, "edit-action", {
            selector: "trigger-action",
            label: "Trigger",
            icon: "ri-focus-3-line",
            callback: async () => await this.trigger(rowData)
        })
    }

    async trigger(rowData) {
        const res = await axios({
            method: 'GET',
            url: `${BASE_URL}/admin/code-generator/record-model`,
            params: { code: rowData.code }
        })
        const { model, column } = res.data.data

        this._triggerLookup.setModel(model)

        const nameColumn = this._triggerLookup.table._columns.find(col => col.name == 'name')
        nameColumn.data  = column

        this._triggerLookupCode = rowData.code

        await this._triggerLookup.open()
    }

    /**
     * @param {string} code
     * @param {string} recordId
     * @returns {Promise<void>}
     */
    async _executeTrigger(code, recordId) {
        const res = await axios({
            method: 'POST',
            url: `${BASE_URL}/admin/code-generator/trigger`,
            data: { code, record_id: recordId }
        })

        await this.helper.successAlert({ title: 'Code Generated', message: res.data.data.code })
    }

    async view(row, data) {
        const filter = new Filter().and('code_generator_id', data.id)
        await this._viewLookup.open(filter)
    }
}