import Helper from "@core-js/solaris/helper"
import SolarComponent from "@core-js/solaris/solar/solar-component"
import axios from "@core-js/libs/axios"


// ═══════════════════════════════════════════════════════════════
// CLASS
// ═══════════════════════════════════════════════════════════════

export default class MaskFormat extends SolarComponent {

    static supportedEvent() {
        return ['change']
    }

    // ── Constructor & Init ────────────────────────────────────

    constructor(selector) {
        super()

        if (selector instanceof HTMLElement) {
            this._element = selector
        } else if (Helper.isString(selector) && !Helper.isEmpty(selector)) {
            this._element = document.querySelector(selector)
            if (!this._element) {
                throw new Error(`Element with query selector ${selector} is not found`)
            }
        } else {
            throw new Error(`Selector is not element`)
        }

        this.editor = this._element.querySelector(".mask-format-editor")

        // Create dropdown and transform on document.body
        // position:fixed inside modal breaks due to CSS transform on .modal-dialog
        this.dropdown = document.createElement('div')
        this.dropdown.className = 'mask-format-dropdown'
        document.body.appendChild(this.dropdown)

        this.transform = document.createElement('div')
        this.transform.className = 'mask-format-transform-popover'
        document.body.appendChild(this.transform)

        this._init()
    }

    _init() {
        this._dropdownItems = []
        this._dropdownActiveIndex = -1
        this._triggerNode = null
        this._triggerChar = null
        this._triggerOffset = 0
        this._table = null
        this._cachedColumnsByPath = {}
        this._activeTagEl = null

        // State flags
        this._visible = true
        this._required = false
        this._disabled = false
        this._valid = false
        this._error = false
        this._oldValue = ''

        // Bound references for cleanup
        this._boundOnKeyDown = this._onKeyDown.bind(this)
        this._boundOnInput = this._onInput.bind(this)
        this._boundOnDocumentClick = this._onDocumentClick.bind(this)
        this._boundOnScroll = () => this._repositionAll()
        this._boundOnResize = () => this._repositionAll()

        this.editor.addEventListener('keydown', this._boundOnKeyDown)
        this.editor.addEventListener('input', () => {
            // Force true empty state for CSS :empty placeholder
            if (this.editor.innerText.trim() === '') {
                this.editor.innerHTML = ''
            }
            this._boundOnInput()
        })
        document.addEventListener('mousedown', this._boundOnDocumentClick)
        window.addEventListener('scroll', this._boundOnScroll, true)
        window.addEventListener('resize', this._boundOnResize)
    }

    // ── Caret Utilities ───────────────────────────────────────

    _getCaretInfo() {
        const sel = window.getSelection()
        if (!sel || sel.rangeCount === 0) {
            return null
        }

        const range = sel.getRangeAt(0)
        return {
            range,
            node: range.startContainer,
            offset: range.startOffset
        }
    }

    _getCaretRect() {
        const sel = window.getSelection()
        if (!sel || sel.rangeCount === 0) {
            return null
        }

        const range = sel.getRangeAt(0).cloneRange()
        range.collapse(true)
        return range.getBoundingClientRect()
    }

    // ── Dropdown ──────────────────────────────────────────────

    _showDropdown(items) {
        this._dropdownItems = items
        this._dropdownActiveIndex = items.length > 0 ? 0 : -1
        this._renderDropdown()
        this._positionDropdown()
        this.dropdown.classList.add('visible')
    }

    _showLoading() {
        this.dropdown.innerHTML = '<div class="mf-dd-loading">Loading...</div>'
        this._positionDropdown()
        this.dropdown.classList.add('visible')
    }

    _hideDropdown() {
        this.dropdown.classList.remove('visible')
        this.dropdown.innerHTML = ''
        this._dropdownItems = []
        this._dropdownActiveIndex = -1
    }

    _renderDropdown() {
        if (this._dropdownItems.length === 0) {
            this.dropdown.innerHTML = '<div class="mf-dd-loading">No results</div>'
            return
        }

        this.dropdown.innerHTML = this._dropdownItems.map((item, i) => `
			<div class="mf-dd-item ${i === this._dropdownActiveIndex ? 'active' : ''}" data-trigger="${item.trigger}" data-idx="${i}">
				<span class="mf-dd-trigger">${item.trigger}</span>
				<span class="mf-dd-label">${item.value}</span>
				${item.desc ? `<span class="mf-dd-desc">${item.desc}</span>` : ''}
			</div>
		`).join('')

        this.dropdown.querySelectorAll('.mf-dd-item').forEach(el => {
            el.addEventListener('mousedown', (e) => {
                e.preventDefault()
                const idx = parseInt(el.dataset.idx, 10)
                this._selectItem(this._dropdownItems[idx])
            })
        })
    }

    _positionDropdown() {
        const rect = this._getCaretRect()
        if (!rect) {
            return
        }

        const gap = 4
        const ddH = 240
        const ddW = 280
        const viewH = window.innerHeight
        const viewW = window.innerWidth

        let top = rect.bottom + gap
        let left = rect.left

        if (rect.bottom + gap + ddH > viewH) {
            top = rect.top - gap - Math.min(ddH, this._dropdownItems.length * 40)
        }

        if (left + ddW > viewW) {
            left = viewW - ddW - 8
        }

        this.dropdown.style.top = `${top}px`
        this.dropdown.style.left = `${left}px`
    }

    _setActive(idx) {
        this._dropdownActiveIndex = idx
        this._renderDropdown()

        const activeEl = this.dropdown.querySelector('.mf-dd-item.active')
        if (activeEl) {
            activeEl.scrollIntoView({ block: 'nearest' })
        }
    }

    // ── Tag Creation ──────────────────────────────────────────

    _createTagEl(value, trigger, colType, transform) {
        const tag = document.createElement('span')
        tag.className = 'mf-tag'
        tag.contentEditable = 'false'
        tag.dataset.trigger = trigger
        tag.dataset.value = value
        let type = colType || (trigger === '@' ? 'static' : 'string')
        if (type === 'lookup') {
            type = 'string'
        }
        tag.dataset.colType = type
        tag.dataset.transform = transform || ''

        this._refreshTagLabel(tag)

        tag.addEventListener('mousedown', (e) => {
            if (e.target.classList.contains('mf-tag-remove')) {
                return
            }
            e.preventDefault()
            if (trigger === '#') {
                this._openTransformPopover(tag)
            }
        })

        const btn = document.createElement('span')
        btn.className = 'mf-tag-remove'
        btn.textContent = '×'
        btn.title = 'Remove'
        btn.addEventListener('mousedown', (e) => {
            e.preventDefault()
            this._closeTransformPopover()
            tag.remove()
            this.editor.focus()
            this.trigger('change', this.get())
        })
        tag.appendChild(btn)

        return tag
    }

    _refreshTagLabel(tag) {
        const existing = tag.querySelector('.mf-tag-label')
        if (existing) {
            existing.remove()
        }

        const transform = tag.dataset.transform
        const value = tag.dataset.value

        const label = document.createElement('span')
        label.className = 'mf-tag-label'

        if (transform) {
            label.innerHTML = `{${value}<span class="mf-tag-transform">|${transform}</span>}`
        } else {
            label.textContent = `{${value}}`
        }

        const btn = tag.querySelector('.mf-tag-remove')
        if (btn) {
            tag.insertBefore(label, btn)
        } else {
            tag.appendChild(label)
        }
    }

    _selectItem(item) {
        this._insertAtTrigger(item, true)
    }

    _autocompleteItem(item) {
        this._insertAtTrigger(item, false)
        // Re-run input logic to update dropdown/state for the new text
        this._onInput()
    }

    _insertAtTrigger(item, asTag = true) {
        if (!this._triggerNode) {
            this._hideDropdown()
            return
        }

        const caret = this._getCaretInfo()
        if (!caret) {
            this._hideDropdown()
            return
        }

        const sel = window.getSelection()
        const range = document.createRange()

        range.setStart(this._triggerNode, this._triggerOffset)

        if (caret.node === this._triggerNode) {
            range.setEnd(this._triggerNode, caret.offset)
        } else {
            range.setEnd(this._triggerNode, this._triggerNode.textContent.length)
        }

        range.deleteContents()

        if (asTag) {
            const tag = this._createTagEl(item.value, item.trigger, item.type || null)
            range.insertNode(tag)

            // Zero-width space as caret anchor
            const spacer = document.createTextNode('\u200B')
            tag.after(spacer)

            const newRange = document.createRange()
            newRange.setStart(spacer, 1)
            newRange.collapse(true)
            sel.removeAllRanges()
            sel.addRange(newRange)

            this._hideDropdown()
            this._resetTriggerState()
        } else {
            const text = document.createTextNode(item.trigger + item.value)
            range.insertNode(text)

            const newRange = document.createRange()
            newRange.setStart(text, text.textContent.length)
            newRange.collapse(true)
            sel.removeAllRanges()
            sel.addRange(newRange)

            // For autocomplete, we don't hide dropdown or reset state
            // _onInput will re-evaluate based on the new text
        }

        this.trigger('change', this.get())
    }

    _resetTriggerState() {
        this._triggerChar = null
        this._triggerNode = null
        this._triggerOffset = 0
    }

    // ── Transform Popover ─────────────────────────────────────

    _openTransformPopover(tagEl) {
        if (this._activeTagEl && this._activeTagEl !== tagEl) {
            this._activeTagEl.classList.remove('selected')
        }

        this._activeTagEl = tagEl
        tagEl.classList.add('selected')

        const colType = tagEl.dataset.colType || 'auto'
        const curTrans = tagEl.dataset.transform || ''
        const colValue = tagEl.dataset.value
        const groups = MASK_FORMAT_TRANSFORMS[colType] || MASK_FORMAT_TRANSFORMS.auto

        let html = `<div class="mf-tp-header">
			<span class="mf-tp-colname">${colValue}</span>
			<span class="mf-tp-type">${colType}</span>
		</div>`

        groups.forEach(group => {
            html += `<div class="mf-tp-group-label">${group.group}</div>`
            html += `<div class="mf-tp-pills">`
            group.items.forEach(t => {
                const isActive = curTrans === t.value
                html += `<span class="mf-tp-pill ${isActive ? 'active' : ''}"
				data-transform="${t.value}"
				title="${t.desc}">${t.label}</span>`
            })
            html += `</div>`
        })

        if (curTrans) {
            html += `<div class="mf-tp-remove" data-action="clear">✕ Remove transform</div>`
        }

        this.transform.innerHTML = html

        this.transform.querySelectorAll('.mf-tp-pill').forEach(pill => {
            pill.addEventListener('mousedown', (e) => {
                e.preventDefault()
                const tv = pill.dataset.transform
                tagEl.dataset.transform = (tagEl.dataset.transform === tv) ? '' : tv
                this._refreshTagLabel(tagEl)
                this._openTransformPopover(tagEl)
                this.trigger('change', this.get())
            })
        })

        const clearBtn = this.transform.querySelector('[data-action="clear"]')
        if (clearBtn) {
            clearBtn.addEventListener('mousedown', (e) => {
                e.preventDefault()
                tagEl.dataset.transform = ''
                this._refreshTagLabel(tagEl)
                this._openTransformPopover(tagEl)
                this.trigger('change', this.get())
            })
        }

        this._positionTransformPopover(tagEl)
        this.transform.classList.add('visible')
    }

    _closeTransformPopover() {
        this.transform.classList.remove('visible')
        if (this._activeTagEl) {
            this._activeTagEl.classList.remove('selected')
            this._activeTagEl = null
        }
    }

    _positionTransformPopover(tagEl) {
        const rect = tagEl.getBoundingClientRect()
        const popW = 240
        const popH = 300
        const gap = 4
        const viewH = window.innerHeight
        const viewW = window.innerWidth

        let top = rect.bottom + gap
        let left = rect.left

        if (top + popH > viewH) {
            top = rect.top - popH - gap
        }
        if (left + popW > viewW) {
            left = viewW - popW - 8
        }
        if (left < 8) {
            left = 8
        }

        this.transform.style.top = `${top}px`
        this.transform.style.left = `${left}px`
    }

    // ── Event Handlers ────────────────────────────────────────

    _onKeyDown(e) {
        if (this._disabled) {
            e.preventDefault()
            return
        }

        if (!this.dropdown.classList.contains('visible')) {
            return
        }

        if (e.key === 'ArrowDown') {
            e.preventDefault()
            this._setActive(Math.min(this._dropdownActiveIndex + 1, this._dropdownItems.length - 1))
        } else if (e.key === 'ArrowUp') {
            e.preventDefault()
            this._setActive(Math.max(this._dropdownActiveIndex - 1, 0))
        } else if (e.key === 'Enter') {
            if (this._dropdownActiveIndex >= 0 && this._dropdownItems[this._dropdownActiveIndex]) {
                e.preventDefault()
                this._selectItem(this._dropdownItems[this._dropdownActiveIndex])
            }
        } else if (e.key === 'Tab') {
            if (this._dropdownActiveIndex >= 0 && this._dropdownItems[this._dropdownActiveIndex]) {
                e.preventDefault()
                const item = this._dropdownItems[this._dropdownActiveIndex]
                if (item.trigger === '#') {
                    this._autocompleteItem(item)
                } else {
                    this._selectItem(item)
                }
            }
        } else if (e.key === 'Escape') {
            this._hideDropdown()
            this._resetTriggerState()
        }
    }

    async _onInput() {
        if (this._disabled) {
            return
        }

        const caret = this._getCaretInfo()
        if (!caret || caret.node.nodeType !== Node.TEXT_NODE) {
            this._hideDropdown()
            this._resetTriggerState()
            return
        }

        const text = caret.node.textContent.slice(0, caret.offset)

        const atIdx = text.lastIndexOf('@')
        const hashIdx = text.lastIndexOf('#')
        const trigIdx = Math.max(atIdx, hashIdx)

        if (trigIdx === -1) {
            this._hideDropdown()
            this._resetTriggerState()
            return
        }

        const detectedTrigger = text[trigIdx]
        const query = text.slice(trigIdx + 1)

        if (query.includes(' ')) {
            this._hideDropdown()
            this._resetTriggerState()
            return
        }

        this._triggerChar = detectedTrigger
        this._triggerNode = caret.node
        this._triggerOffset = trigIdx

        if (detectedTrigger === '@') {
            const filtered = MASK_FORMAT_PLACEHOLDER.filter(i =>
                !query || i.value.toLowerCase().includes(query.toLowerCase())
            )
            this._showDropdown(filtered)
            return
        }

        // # trigger — columns from server
        if (!this._table) {
            this._hideDropdown()
            return
        }

        const lastDot = query.lastIndexOf('.')
        const subQuery = lastDot !== -1 ? query.slice(lastDot + 1) : query

        // Determine which table/class to fetch from
        let fetchLookup = null
        let cacheKey = '__root__'
        let valuePrefix = ''

        if (lastDot !== -1) {
            // Trying to drill into a lookup — find the lookup info from cached data
            const parts = query.slice(0, lastDot).split('.')
            const depth = parts.length

            if (depth > 3) {
                this._hideDropdown()
                return
            }

            // Walk the lookup chain through cached columns
            let currentLookup = null // Initial fetch is by table
            let currentCacheKey = '__root__'
            let resolved = true

            for (const part of parts) {
                const cachedCols = this._cachedColumnsByPath[currentCacheKey]
                if (!cachedCols) {
                    resolved = false
                    break
                }

                const col = cachedCols.find(c => c.value.split('.').pop() === part && c.hasLookup)
                if (!col?.lookup) {
                    resolved = false
                    break
                }

                currentLookup = col.lookup
                currentCacheKey = col.lookup // Cache by class name for lookups
            }

            if (!resolved) {
                this._hideDropdown()
                return
            }

            fetchLookup = currentLookup
            cacheKey = currentLookup
            valuePrefix = query.slice(0, lastDot + 1)
        }

        let cols = this._cachedColumnsByPath[cacheKey]
        if (!cols) {
            this._showLoading()
            cols = await this._fetchColumns(this._table, fetchLookup)
            this._cachedColumnsByPath[cacheKey] = cols
        }

        // Apply prefix for nested lookups in display
        let displayCols = cols
        if (valuePrefix) {
            displayCols = cols.map(c => ({ ...c, value: `${valuePrefix}${c.value}` }))
        }

        const filtered = displayCols.filter(c =>
            !subQuery || c.value.split('.').pop().toLowerCase().includes(subQuery.toLowerCase())
        )
        this._showDropdown(filtered)
    }

    _onDocumentClick(e) {
        // Close dropdown on click outside
        if (!this.dropdown.contains(e.target) && e.target !== this.editor) {
            this._hideDropdown()
            this._resetTriggerState()
        }

        // Close transform popover on click outside
        if (
            this._activeTagEl &&
            !this.transform.contains(e.target) &&
            !e.target.classList.contains('mf-tag') &&
            !e.target.closest?.('.mf-tag')
        ) {
            this._closeTransformPopover()
        }
    }

    _repositionAll() {
        if (this.dropdown.classList.contains('visible')) {
            this._positionDropdown()
        }
        if (this._activeTagEl && this.transform.classList.contains('visible')) {
            this._positionTransformPopover(this._activeTagEl)
        }
    }

    // ── Column Fetching ──────────────────────────────────────

    setTable(table) {
        this._table = table || null
        this._cachedColumnsByPath = {}
    }

    async _fetchColumns(table, lookup = null) {
        try {
            const response = await axios({
                method: 'POST',
                url: `${BASE_URL}/admin/code-generator/mask-columns`,
                data: { table, lookup }
            })
            return response.data || []
        } catch {
            return []
        }
    }

    // ── Public API ────────────────────────────────────────────

    get() {
        let result = ''
        this.editor.childNodes.forEach(node => {
            if (node.nodeType === Node.TEXT_NODE) {
                result += node.textContent.replace(/\u200B/g, '')
            } else if (node.classList?.contains('mf-tag')) {
                const val = node.dataset.value
                const tr = node.dataset.transform
                result += tr ? `{${val}|${tr}}` : `{${val}}`
            } else if (node.nodeName === 'BR') {
                result += '\n'
            } else {
                result += node.innerText || node.textContent
            }
        })
        return result.trim()
    }

    set(expression) {
        this.editor.innerHTML = ''
        this._hideDropdown()
        this._resetTriggerState()
        this._closeTransformPopover()

        if (!expression) {
            return
        }

        // Parse expression like: INV-{YYYY}-{type.name|upper}-{0:0000}
        const frag = document.createDocumentFragment()
        const regex = /\{([^}]+)\}/g
        let lastIndex = 0
        let match

        while ((match = regex.exec(expression)) !== null) {
            // Add text before this tag
            if (match.index > lastIndex) {
                frag.appendChild(document.createTextNode(expression.slice(lastIndex, match.index)))
            }

            const inner = match[1]
            const pipeIdx = inner.indexOf('|')
            let value, transform

            if (pipeIdx !== -1) {
                value = inner.slice(0, pipeIdx)
                transform = inner.slice(pipeIdx + 1)
            } else {
                value = inner
                transform = ''
            }

            // Determine trigger: static whitelist = @, otherwise #
            const isStatic = MASK_FORMAT_PLACEHOLDER.some(s => s.value === value)
            const trigger = isStatic ? '@' : '#'

            frag.appendChild(this._createTagEl(value, trigger, null, transform))
            lastIndex = regex.lastIndex
        }

        // Remaining text after last tag
        if (lastIndex < expression.length) {
            frag.appendChild(document.createTextNode(expression.slice(lastIndex)))
        }

        this.editor.appendChild(frag)
    }

    show() {
        this._element.classList.remove('d-none')
        this._visible = true
    }

    hidden() {
        this._element.classList.add('d-none')
        this._visible = false
    }

    required() {
        this._required = true
    }

    optional() {
        this._required = false
    }

    disabled() {
        this._disabled = true
        this.editor.contentEditable = 'false'
        this.editor.classList.add('disabled')
        this._hideDropdown()
        this._closeTransformPopover()
    }

    enabled() {
        this._disabled = false
        this.editor.contentEditable = 'true'
        this.editor.classList.remove('disabled')
    }

    valid() {
        this.editor.classList.remove('is-invalid')
        this.editor.classList.add('is-valid')
        this._error = false
        this._valid = true
    }

    error() {
        this.editor.classList.remove('is-valid')
        this.editor.classList.add('is-invalid')
        this._error = true
        this._valid = false
    }

    resetValidation() {
        this.editor.classList.remove('is-valid', 'is-invalid')
        this._error = false
        this._valid = false
    }

    reset() {
        this.resetValidation()
        this.editor.innerHTML = ''
        this._cachedColumnsByPath = {}
        this._hideDropdown()
        this._closeTransformPopover()
        this._resetTriggerState()
        this.trigger('change', '')
    }

    isRequired() {
        return this._required
    }

    isDisabled() {
        return this._disabled
    }

    isVisible() {
        return this._visible
    }

    isError() {
        return this._error
    }

    isValid() {
        return this._valid
    }

    isChanged() {
        return this._oldValue !== this.get()
    }

    destroy() {
        this.editor.removeEventListener('keydown', this._boundOnKeyDown)
        this.editor.removeEventListener('input', this._boundOnInput)
        document.removeEventListener('mousedown', this._boundOnDocumentClick)
        window.removeEventListener('scroll', this._boundOnScroll, true)
        window.removeEventListener('resize', this._boundOnResize)

        this._hideDropdown()
        this._closeTransformPopover()

        this.dropdown.remove()
        this.transform.remove()
    }
}