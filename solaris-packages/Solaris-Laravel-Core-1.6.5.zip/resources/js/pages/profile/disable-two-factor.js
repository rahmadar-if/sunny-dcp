import Button from "@core-js/solaris/button"
import StageButtons from "@core-js/solaris/stage/stage-button"
import OtpInput from "@core-js/solaris/form/otp-input"
import TwoFactorBase from "./two-factor-base"

const STEPS = {
    CONFIRM: 'confirm',
    TOTP   : 'totp',
    EMAIL  : 'email',
}

export default class DisableTwoFactor extends TwoFactorBase {

    static supportedEvent() {
        return ['disabled']
    }

    //#region Lifecycle

    constructor() {
        super("disable-two-factor-modal")
    }

    init() {
        this.form.nonactive()

        this.initButtons()

        /** @type {StageButtons} */
        this.stage = this.form.get('disable2fa-steps')
        this.stage?.disabled()

        this.totpContainer  = document.getElementById("disable2fa-step-totp")
        this.emailContainer = document.getElementById("disable2fa-step-email")

        /** @type {OtpInput} */
        this.totpOtp = this.get("disable2fa-totp-otp-input")

        /** @type {OtpInput} */
        this.emailOtp = this.get("disable2fa-email-otp-input")
        this.emailOtp?.on('resend', (data) => {
            document.getElementById('disable2fa-email-masked').textContent = data.masked_email
            this.helper.successAlert({ title: 'Code resent to your email', timeout: 3000 })
        })

        this._bindPasswordEnter('disable2fa-password')
        this._bindOtpAutoSubmit(this.totpOtp)
        this._bindOtpAutoSubmit(this.emailOtp)

        this.modal?.on('hidden', () => this.reset(), 'DisableTwoFactor')
    }

    initButtons() {
        /** @type {Button} */
        this.prevBtn = this.get("disable2fa-btn-prev")
        this.prevBtn?.on("click", this._handlePrev.bind(this))

        /** @type {Button} */
        this.nextBtn = this.get("disable2fa-btn-next")
        this.nextBtn?.on("click", this._handleNext.bind(this))

    }

    /**
     * @param {'totp'|'email'} method
     */
    open(method) {
        this._method = method
        this.modal.show()
        this.confirmStage()
    }

    //#endregion

    //#region Stages

    confirmStage() {
        this._hiddenAll()
        this.stage?.set(STEPS.CONFIRM, true)
        this._step = STEPS.CONFIRM

        const password = this.form.get("disable2fa-password")
        password.show()
        password.reset(true)

        this._nextAsContinue()
        this.prevBtn?.hidden()
        this.nextBtn?.show()
    }

    verifyStage() {
        this._hiddenAll()
        this.stage?.set('verify', true)

        if (this._method === 'totp') {
            this._step = STEPS.TOTP
            this.totpContainer.classList.remove("d-none")
            this.totpOtp?.reset()
            this.totpOtp?.focus()
        } else {
            this._step = STEPS.EMAIL
            this.emailContainer.classList.remove("d-none")
            this.emailOtp?.reset()
            this.emailOtp?.focus()
            this.emailOtp.startResendTimer()
        }

        this._nextAsDanger()
        this.prevBtn?.show()
        this.nextBtn?.show()
    }

    _hiddenAll() {
        this.form.get("disable2fa-password")?.hidden()
        this.totpContainer.classList.add("d-none")
        this.emailContainer.classList.add("d-none")
    }

    //#endregion

    //#region Navigation

    _handleNext() {
        switch (this._step) {
            case STEPS.CONFIRM:
                return this._submitPassword()
            case STEPS.TOTP:
            case STEPS.EMAIL:
                return this._submitDisable()
        }
    }

    _handlePrev() {
        if (this._step !== STEPS.TOTP && this._step !== STEPS.EMAIL) return
        this.emailOtp?.reset()
        this.confirmStage()
    }

    reset() {
        this._step   = null
        this._method = null

        this._hiddenAll()

        this.form.get("disable2fa-password")?.reset()
        this.totpOtp?.reset()
        this.emailOtp?.reset()

        this._nextAsContinue()
    }

    //#endregion

    //#region AJAX

    async _submitPassword() {
        const field = this.form.get("disable2fa-password")
        if (this.helper.isEmpty(field.get())) {
            field.error()
            field.setMessage('Current Password is required')
            return
        }

        this.nextBtn?.load()

        try {
            await this._doConfirmPassword(`${BASE_URL}/core/two-factor/confirm-password`, field.get())
            field.resetValidation()
        } catch (error) {
            this.nextBtn?.unload()
            field.error()
            field.setMessage(error)
            return
        }

        try {
            if (this._method === 'email') {
                const data = await this._doLoadEmailSetup(`${BASE_URL}/core/two-factor/disable/send-otp`)
                document.getElementById('disable2fa-email-masked').textContent = data.masked_email
            }
            this.verifyStage()
        } catch (error) {
            this.helper.errorAlert({ title: error, timeout: 5000 })
        } finally {
            this.nextBtn?.unload()
        }
    }

    async _submitDisable() {
        const otp  = this._step === STEPS.TOTP ? this.totpOtp : this.emailOtp
        const code = otp.get()

        if (code.length !== otp.length) {
            otp.setMessage('Enter the 6-digit verification code')
            return
        }

        try {
            otp.resetValidation()
            this.nextBtn?.load()
            await this._doVerifyCode(`${BASE_URL}/core/two-factor/disable`, code)
            this.emailOtp.stopResendTimer()
            await this.trigger('disabled')
            this.helper.successAlert({ title: '2FA Disabled', message: 'Two-factor authentication has been disabled.', timeout: 4000 })
            this.modal?.hide()
        } catch (error) {
            otp.setMessage(error)
        } finally {
            this.nextBtn?.unload()
        }
    }

    //#endregion

}
