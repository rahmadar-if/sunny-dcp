import Button from "@core-js/solaris/button"
import StageButtons from "@core-js/solaris/stage/stage-button"
import OtpInput from "@core-js/solaris/form/otp-input"
import TwoFactorBase from "./two-factor-base"

const STEPS = {
    CONFIRM: 'confirm',
    METHOD : 'method',
    TOTP   : 'totp',
    EMAIL  : 'email',
    BACKUP : 'backup',
}

const STEP_TITLE = {
    CONFIRM: 'Enable Two-Factor Authentication',
    METHOD : 'Choose Verification Method',
    TOTP   : 'Authenticator App Setup',
    EMAIL  : 'Email Verification Setup',
    BACKUP : 'Save Your Backup Codes',
}

export default class EnableTwoFactor extends TwoFactorBase {

    static supportedEvent() {
        return ['enabled']
    }

    //#region Lifecycle

    constructor() {
        super("two-factor-setup-modal")
    }

    init() {
        this.form.nonactive()

        this.initButtons()

        this.title = document.getElementById('twofa-modal-title')

        /** @type {StageButtons} */
        this.stage = this.form.get('twofa-steps')
        this.stage?.disabled()

        this.totpContainer   = document.getElementById("twofa-step-totp")
        this.emailContainer  = document.getElementById("twofa-step-email")
        this.backupContainer = document.getElementById("twofa-step-backup")

        /** @type {OtpInput} */
        this.totpOtp = this.get("twofa-totp-otp-input")

        /** @type {OtpInput} */
        this.emailOtp = this.get("twofa-email-otp-input")
        this.emailOtp?.on('resend', (data) => {
            document.getElementById('twofa-email-masked').textContent = data.masked_email
            this.helper.successAlert({ title: 'Code resent to your email', timeout: 3000 })
        })

        this._bindPasswordEnter('twofa-password')
        this._bindOtpAutoSubmit(this.totpOtp)
        this._bindOtpAutoSubmit(this.emailOtp)

        this.modal?.on('show', () => this.confirmStage())
        this.modal?.on('hidden', () => this.reset(), 'EnableTwoFactor')
    }

    initButtons() {
        /** @type {Button} */
        this.prevBtn = this.get("twofa-btn-prev")
        this.prevBtn?.on("click", this._handlePrev.bind(this))

        /** @type {Button} */
        this.nextBtn = this.get("twofa-btn-next")
        this.nextBtn?.on("click", this._handleNext.bind(this))

        /** @type {Button} */
        this.downloadCodesBtn = this.get("twofa-download-codes")
        this.downloadCodesBtn?.on("click", this._downloadBackupCodes.bind(this))

        /** @type {Button} */
        this.copyCodesBtn = this.get("twofa-copy-codes")
        this.copyCodesBtn?.on("click", this._copyBackupCodes.bind(this))
    }

    //#endregion

    //#region Stages

    confirmStage() {
        this._hiddenAll()
        this.stage?.set(STEPS.CONFIRM, true)
        this._step = STEPS.CONFIRM

        const password = this.form.get("twofa-password")
        password.show()
        password.reset(true)

        this.title.textContent = STEP_TITLE.CONFIRM

        this._nextAsContinue()
        this.prevBtn?.hidden()
        this.nextBtn?.show()
    }

    methodStage() {
        this._hiddenAll()
        this.stage?.set(STEPS.METHOD, true)
        this._step = STEPS.METHOD

        const method = this.form.get("twofa-method")
        method.show()
        method.reset()

        this.title.textContent = STEP_TITLE.METHOD

        this._nextAsContinue()
        this.prevBtn?.show()
        this.nextBtn?.show()
    }

    verifyStage() {
        this._hiddenAll()
        this.stage?.set('verify', true)

        const method = this.form.getValue("twofa-method").id

        this.title.textContent = STEP_TITLE[method === 'totp' ? STEPS.TOTP : STEPS.EMAIL]

        if (method === 'totp') {
            this.totpContainer.classList.remove("d-none")
            this.totpOtp?.reset()
            this.totpOtp?.focus()
            this._nextAsContinue()
            this.nextBtn?.show()
            this._step = STEPS.TOTP
        } else {
            this.emailContainer.classList.remove("d-none")
            this.emailOtp?.reset()
            this.emailOtp?.focus()
            this.emailOtp.startResendTimer()
            this._nextAsDone()
            this.nextBtn?.show()
            this._step = STEPS.EMAIL
        }

        this.prevBtn?.show()
    }

    backupStage() {
        this.stage?.set(STEPS.BACKUP, true)
        this._step = STEPS.BACKUP

        this.totpContainer.classList.add("d-none")
        this.backupContainer.classList.remove("d-none")
        this.title.textContent = STEP_TITLE.BACKUP

        this._nextAsDone()
        this.prevBtn?.hidden()
        this.nextBtn?.show()
        this.nextBtn?.disabled()
    }

    _hiddenAll() {
        this.form.get("twofa-password").hidden()
        this.form.get("twofa-method").hidden()

        this.totpContainer.classList.add("d-none")
        this.emailContainer.classList.add("d-none")
        this.backupContainer.classList.add("d-none")
    }

    //#endregion

    //#region Navigation

    _handleNext() {
        switch (this._step) {
            case STEPS.CONFIRM: return this._submitPassword()
            case STEPS.METHOD:  return this._submitMethod()
            case STEPS.TOTP:    return this._submitTotpVerify()
            case STEPS.EMAIL:   return this._submitEmailVerify()
            case STEPS.BACKUP:
                this.trigger('enabled', { method: 'totp' })
                this.helper.successAlert({ title: '2FA Enabled', message: 'Two-factor authentication via Authenticator App is now active.', timeout: 4000 })
                this.modal.hide()
                return
        }
    }

    _handlePrev() {
        switch (this._step) {
            case STEPS.METHOD: return this.confirmStage()
            case STEPS.TOTP:   return this.methodStage()
            case STEPS.EMAIL:
                this.emailOtp?.reset()
                return this.methodStage()
        }
    }

    reset() {
        this._step        = null
        this._backupCodes = []

        this._hiddenAll()

        this.form.get("twofa-password").reset()
        this.form.get("twofa-method").reset()

        this.totpOtp?.reset()
        this.emailOtp?.reset()

        this._nextAsContinue()
    }

    //#endregion

    //#region AJAX

    async _submitPassword() {
        const field = this.form.get("twofa-password")
        if (this.helper.isEmpty(field.get())) {
            field.error()
            field.setMessage('Current Password is required')
            return
        }

        try {
            this.nextBtn?.load()
            await this._doConfirmPassword(`${BASE_URL}/core/two-factor/confirm-password`, field.get())
            field.resetValidation()
            this.methodStage()
        } catch (error) {
            field.error()
            field.setMessage(error)
        } finally {
            this.nextBtn?.unload()
        }
    }

    async _submitMethod() {
        const method = this.form.get("twofa-method")
        if (!method.get()) {
            method.error()
            method.setMessage("Please select a method")
            return
        }

        try {
            this.nextBtn?.load()

            if (method.get().id === 'totp') {
                const data = await this._doLoadTotpSetup(`${BASE_URL}/core/two-factor/setup/totp`)
                document.getElementById('twofa-totp-qr').innerHTML           = data.qr_code
                document.getElementById('twofa-totp-manual-key').textContent = data.manual_key
            } else {
                const data = await this._doLoadEmailSetup(`${BASE_URL}/core/two-factor/setup/email`)
                document.getElementById('twofa-email-masked').textContent = data.masked_email
            }

            method.resetValidation()
            this.verifyStage()
        } catch (error) {
            method.error()
            method.setMessage(error)
        } finally {
            this.nextBtn?.unload()
        }
    }

    async _submitTotpVerify() {
        const code = this.totpOtp.get()
        if (code.length !== this.totpOtp.length) {
            this.totpOtp.setMessage('Enter the 6-digit code from your authenticator app')
            return
        }

        try {
            this.totpOtp.resetValidation()
            this.nextBtn?.load()
            const data = await this._doVerifyCode(`${BASE_URL}/core/two-factor/setup/totp/verify`, code)
            this._backupCodes = data?.backup_codes ?? []
            this._populateBackupCodes(this._backupCodes, document.getElementById('twofa-backup-codes-grid'))
            this.backupStage()
        } catch (error) {
            this.totpOtp.setMessage(error)
        } finally {
            this.nextBtn?.unload()
        }
    }

    async _submitEmailVerify() {
        const code = this.emailOtp.get()
        if (code.length !== this.emailOtp.length) {
            this.emailOtp.setMessage('Enter the 6-digit verification code')
            return
        }

        try {
            this.emailOtp.resetValidation()
            this.nextBtn?.load()
            await this._doVerifyCode(`${BASE_URL}/core/two-factor/setup/email/verify`, code)
            this.emailOtp.stopResendTimer()
            await this.trigger('enabled', { method: 'email' })
            this.helper.successAlert({ title: '2FA Enabled', message: 'Two-factor authentication via Email OTP is now active.', timeout: 4000 })
            this.modal?.hide()
        } catch (error) {
            this.emailOtp.setMessage(error)
        } finally {
            this.nextBtn?.unload()
        }
    }

    //#endregion

}
