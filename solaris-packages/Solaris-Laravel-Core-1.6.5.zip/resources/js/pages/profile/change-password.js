import SolarModalPage from "@core-js/solaris/solar/solar-modal-page";

export default class ChangePasswordModal extends SolarModalPage {
    constructor() {
        super("change-password-modal")
    }

    init() {
        this.initForm()
    }

    initForm() {
        this.form.setSuccessMessage("Password changed successfully")

        const current_password      = this.form.get("current_password")
		const password              = this.form.get("password")
		const password_confirmation = this.form.get("password_confirmation")

        password?.on("change", (value) => {
			const isPasswordConfEmpty = this.helper.isEmpty(password_confirmation.get())
			const isMatch             = !isPasswordConfEmpty && !this.helper.isEmpty(value) && value === password_confirmation.get()
			const isSameNewPassword   = !this.helper.isEmpty(current_password.get()) && value === current_password.get()

			if (!isPasswordConfEmpty && !isMatch) {
				password_confirmation.error()
				password_confirmation.setMessage("Confirm password does not match")
			}

			if (isSameNewPassword) {
				password.error()
				password.setMessage("The new password cannot be the same as the current password")
			}
		}, "ProfilePage")

		password_confirmation?.on("change", (value) => {
			if (!this.helper.isEmpty(password.get()) && password.get() !== value) {
				password_confirmation.error()
				password_confirmation.setMessage("Confirm password does not match")
			}
		}, "ProfilePage")
    }
}