import Button from "@core-js/solaris/button"
import StageButtons from "@core-js/solaris/stage/stage-button"
import OtpInput from "@core-js/solaris/form/otp-input"
import TwoFactorBase from "./two-factor-base"

const STEPS = {
    CONFIRM        : 'confirm',
    VERIFY_CURRENT : 'verify-current',
    METHOD         : 'method',
    VERIFY_TOTP    : 'verify-totp',
    VERIFY_EMAIL   : 'verify-email',
    BACKUP         : 'backup',
}

const STEP_TITLE = {
    CONFIRM        : 'Change Two-Factor Method',
    VERIFY_CURRENT : 'Verify Current Method',
    METHOD         : 'Choose New Method',
    VERIFY_TOTP    : 'Set Up Authenticator App',
    VERIFY_EMAIL   : 'Verify New Email Method',
    BACKUP         : 'Save Your Backup Codes',
}

export default class ChangeTwoFactor extends TwoFactorBase {

    static supportedEvent() {
        return ['changed']
    }

    //#region Lifecycle

    constructor() {
        super("change-two-factor-modal")
    }

    init() {
        this.form.nonactive()

        this.initButtons()

        this.title = document.getElementById('change2fa-modal-title')

        /** @type {StageButtons} */
        this.stage = this.form.get('change2fa-steps')
        this.stage?.disabled()

        this.verifyCurrentTotpContainer  = document.getElementById("change2fa-verify-current-totp")
        this.verifyCurrentEmailContainer = document.getElementById("change2fa-verify-current-email")
        this.verifyNewTotpContainer      = document.getElementById("change2fa-step-totp")
        this.verifyNewEmailContainer     = document.getElementById("change2fa-step-email")
        this.backupContainer             = document.getElementById("change2fa-step-backup")

        /** @type {OtpInput} */
        this.currentTotpOtp = this.get("change2fa-current-totp-otp-input")

        /** @type {OtpInput} */
        this.currentEmailOtp = this.get("change2fa-current-email-otp-input")

        /** @type {OtpInput} */
        this.newTotpOtp = this.get("change2fa-new-totp-otp-input")

        /** @type {OtpInput} */
        this.newEmailOtp = this.get("change2fa-new-email-otp-input")

        this.currentEmailOtp?.on('resend', (data) => {
            document.getElementById('change2fa-current-email-masked').textContent = data.masked_email
            this.helper.successAlert({ title: 'Code resent to your email', timeout: 3000 })
        })
        this.newEmailOtp?.on('resend', (data) => {
            document.getElementById('change2fa-new-email-masked').textContent = data.masked_email
            this.helper.successAlert({ title: 'Code resent to your email', timeout: 3000 })
        })

        this._bindPasswordEnter('change2fa-password')
        this._bindOtpAutoSubmit(this.currentTotpOtp)
        this._bindOtpAutoSubmit(this.currentEmailOtp)
        this._bindOtpAutoSubmit(this.newTotpOtp)
        this._bindOtpAutoSubmit(this.newEmailOtp)

        this.modal?.on('hidden', () => this.reset(), 'ChangeTwoFactor')
    }

    initButtons() {
        /** @type {Button} */
        this.prevBtn = this.get("change2fa-btn-prev")
        this.prevBtn?.on("click", this._handlePrev.bind(this))

        /** @type {Button} */
        this.nextBtn = this.get("change2fa-btn-next")
        this.nextBtn?.on("click", this._handleNext.bind(this))

        /** @type {Button} */
        this.downloadCodesBtn = this.get("change2fa-download-codes")
        this.downloadCodesBtn?.on("click", this._downloadBackupCodes.bind(this))

        /** @type {Button} */
        this.copyCodesBtn = this.get("change2fa-copy-codes")
        this.copyCodesBtn?.on("click", this._copyBackupCodes.bind(this))
    }

    /**
     * @param {'totp'|'email'} currentMethod
     */
    open(currentMethod) {
        this._method = currentMethod
        this.modal.show()
        this.confirmStage()
    }

    //#endregion

    //#region Stages

    confirmStage() {
        this._hiddenAll()
        this.stage?.set(STEPS.CONFIRM, true)
        this._step = STEPS.CONFIRM

        const password = this.form.get("change2fa-password")
        password.show()
        password.reset(true)

        this.title.textContent = STEP_TITLE.CONFIRM

        this._nextAsContinue()
        this.prevBtn?.hidden()
        this.nextBtn?.show()
    }

    verifyCurrentStage() {
        this._hiddenAll()
        this.stage?.set(STEPS.VERIFY_CURRENT, true)
        this._step = STEPS.VERIFY_CURRENT

        this.title.textContent = STEP_TITLE.VERIFY_CURRENT

        if (this._method === 'totp') {
            this.verifyCurrentTotpContainer.classList.remove("d-none")
            this.currentTotpOtp?.reset()
            this.currentTotpOtp?.focus()
        } else {
            this.verifyCurrentEmailContainer.classList.remove("d-none")
            this.currentEmailOtp?.reset()
            this.currentEmailOtp?.focus()
            this.currentEmailOtp.startResendTimer()
        }

        this._nextAsContinue()
        this.prevBtn?.show()
        this.nextBtn?.show()
    }

    methodStage() {
        this._hiddenAll()
        this.stage?.set(STEPS.METHOD, true)
        this._step = STEPS.METHOD

        this.title.textContent = STEP_TITLE.METHOD

        const method = this.form.get("change2fa-method")
        method.show()
        method.reset()

        this._nextAsContinue()
        this.prevBtn?.show()
        this.nextBtn?.show()
    }

    verifyNewTotpStage() {
        this._hiddenAll()
        this.stage?.set('verify-new', true)
        this._step = STEPS.VERIFY_TOTP

        this.title.textContent = STEP_TITLE.VERIFY_TOTP

        this.verifyNewTotpContainer.classList.remove("d-none")
        this.newTotpOtp?.reset()
        this.newTotpOtp?.focus()

        this._nextAsContinue()
        this.prevBtn?.show()
        this.nextBtn?.show()
    }

    verifyNewEmailStage() {
        this._hiddenAll()
        this.stage?.set('verify-new', true)
        this._step = STEPS.VERIFY_EMAIL

        this.title.textContent = STEP_TITLE.VERIFY_EMAIL

        this.verifyNewEmailContainer.classList.remove("d-none")
        this.newEmailOtp?.reset()
        this.newEmailOtp?.focus()
        this.newEmailOtp.startResendTimer()

        this._nextAsDone()
        this.prevBtn?.show()
        this.nextBtn?.show()
    }

    backupStage() {
        this.stage?.set(STEPS.BACKUP, true)
        this._step = STEPS.BACKUP

        this.backupContainer.classList.remove("d-none")
        this.title.textContent = STEP_TITLE.BACKUP

        this._nextAsDone()
        this.prevBtn?.hidden()
        this.nextBtn?.show()
        this.nextBtn?.disabled()
    }

    _hiddenAll() {
        this.form.get("change2fa-password")?.hidden()
        this.form.get("change2fa-method")?.hidden()

        this.verifyCurrentTotpContainer.classList.add("d-none")
        this.verifyCurrentEmailContainer.classList.add("d-none")
        this.verifyNewTotpContainer.classList.add("d-none")
        this.verifyNewEmailContainer.classList.add("d-none")
        this.backupContainer.classList.add("d-none")
    }

    //#endregion

    //#region Navigation

    _handleNext() {
        switch (this._step) {
            case STEPS.CONFIRM:        return this._submitPassword()
            case STEPS.VERIFY_CURRENT: return this._submitVerifyCurrent()
            case STEPS.METHOD:         return this._submitMethod()
            case STEPS.VERIFY_TOTP:    return this._submitNewTotpVerify()
            case STEPS.VERIFY_EMAIL:   return this._submitNewEmailVerify()
            case STEPS.BACKUP:
                this.trigger('changed', { method: 'totp' })
                this.helper.successAlert({ title: '2FA Method Changed', message: 'Two-factor authentication via Authenticator App is now active.', timeout: 4000 })
                this.modal.hide()
                return
        }
    }

    _handlePrev() {
        switch (this._step) {
            case STEPS.VERIFY_CURRENT:
                this.currentEmailOtp?.stopResendTimer()
                return this.confirmStage()
            case STEPS.METHOD:
                return this.verifyCurrentStage()
            case STEPS.VERIFY_TOTP:
            case STEPS.VERIFY_EMAIL:
                this.newTotpOtp?.reset()
                this.newEmailOtp?.reset()
                return this.methodStage()
        }
    }

    reset() {
        this._step        = null
        this._method      = null
        this._backupCodes = []

        this._hiddenAll()

        this.form.get("change2fa-password")?.reset()
        this.form.get("change2fa-method")?.reset()
        this.currentTotpOtp?.reset()
        this.currentEmailOtp?.reset()
        this.newTotpOtp?.reset()
        this.newEmailOtp?.reset()

        this._nextAsContinue()
    }

    //#endregion

    //#region AJAX

    async _submitPassword() {
        const field = this.form.get("change2fa-password")
        if (this.helper.isEmpty(field.get())) {
            field.error()
            field.setMessage('Current Password is required')
            return
        }

        this.nextBtn?.load()

        try {
            await this._doConfirmPassword(`${BASE_URL}/core/two-factor/confirm-password`, field.get())
            field.resetValidation()
        } catch (error) {
            this.nextBtn?.unload()
            field.error()
            field.setMessage(error)
            return
        }

        try {
            if (this._method === 'email') {
                const data = await this._doLoadEmailSetup(`${BASE_URL}/core/two-factor/disable/send-otp`)
                document.getElementById('change2fa-current-email-masked').textContent = data.masked_email
            }
            this.verifyCurrentStage()
        } catch (error) {
            this.helper.errorAlert({ title: error, timeout: 5000 })
        } finally {
            this.nextBtn?.unload()
        }
    }

    async _submitVerifyCurrent() {
        const otp  = this._method === 'totp' ? this.currentTotpOtp : this.currentEmailOtp
        const code = otp.get()

        if (code.length !== otp.length) {
            otp.setMessage('Enter the 6-digit verification code')
            return
        }

        try {
            otp.resetValidation()
            this.nextBtn?.load()
            await this._doVerifyCode(`${BASE_URL}/core/two-factor/change/verify-current`, code)
            this.currentEmailOtp.stopResendTimer()
            this.methodStage()
        } catch (error) {
            otp.setMessage(error)
        } finally {
            this.nextBtn?.unload()
        }
    }

    async _submitMethod() {
        const method = this.form.get("change2fa-method")
        if (!method.get()) {
            method.error()
            method.setMessage("Please select a method")
            return
        }

        try {
            this.nextBtn?.load()

            if (method.get().id === 'totp') {
                const data = await this._doLoadTotpSetup(`${BASE_URL}/core/two-factor/setup/totp`)
                document.getElementById('change2fa-new-totp-qr').innerHTML            = data.qr_code
                document.getElementById('change2fa-new-totp-manual-key').textContent  = data.manual_key
                method.resetValidation()
                this.verifyNewTotpStage()
            } else {
                const data = await this._doLoadEmailSetup(`${BASE_URL}/core/two-factor/setup/email`)
                document.getElementById('change2fa-new-email-masked').textContent = data.masked_email
                method.resetValidation()
                this.verifyNewEmailStage()
            }
        } catch (error) {
            method.error()
            method.setMessage(error)
        } finally {
            this.nextBtn?.unload()
        }
    }

    async _submitNewTotpVerify() {
        const code = this.newTotpOtp.get()
        if (code.length !== this.newTotpOtp.length) {
            this.newTotpOtp.setMessage('Enter the 6-digit code from your authenticator app')
            return
        }

        try {
            this.newTotpOtp.resetValidation()
            this.nextBtn?.load()
            const data = await this._doVerifyCode(`${BASE_URL}/core/two-factor/change/totp/complete`, code)
            this._backupCodes = data?.backup_codes ?? []
            this._populateBackupCodes(this._backupCodes, document.getElementById('change2fa-backup-codes-grid'))
            this.backupStage()
        } catch (error) {
            this.newTotpOtp.setMessage(error)
        } finally {
            this.nextBtn?.unload()
        }
    }

    async _submitNewEmailVerify() {
        const code = this.newEmailOtp.get()
        if (code.length !== this.newEmailOtp.length) {
            this.newEmailOtp.setMessage('Enter the 6-digit verification code')
            return
        }

        try {
            this.newEmailOtp.resetValidation()
            this.nextBtn?.load()
            await this._doVerifyCode(`${BASE_URL}/core/two-factor/change/email/complete`, code)
            this.newEmailOtp.stopResendTimer()
            await this.trigger('changed', { method: 'email' })
            this.helper.successAlert({ title: '2FA Method Changed', message: 'Two-factor authentication via Email OTP is now active.', timeout: 4000 })
            this.modal?.hide()
        } catch (error) {
            this.newEmailOtp.setMessage(error)
        } finally {
            this.nextBtn?.unload()
        }
    }

    //#endregion

}
