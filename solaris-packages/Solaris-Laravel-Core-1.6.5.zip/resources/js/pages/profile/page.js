import { Gender, Salutation } from "@core-js/const"
import Filter from "@core-js/solaris/filter/filter"
import PushNotification from "@core-js/solaris/push-notification"
import SolarEditPage from "@core-js/solaris/solar/solar-edit-page"
import ChangePasswordModal from "./change-password"
import EnableTwoFactor from "./enable-two-factor"
import DisableTwoFactor from "./disable-two-factor"
import ChangeTwoFactor from "./change-two-factor"
import ProfileSessionDetail from "./session-detail"

const GOOGLE_SVG_LG = `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>`
const GOOGLE_SVG_SM = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>`

export default class ProfilePage extends SolarEditPage {

	//#region Lifecycle

	init() {
		this.pushNotification = new PushNotification()

		this.isPushNotif = false
		this.pushNotifRefresh = false
		this.nameDisplay = document.getElementById('name-display')

		this.initForm()
		this.initSSO()
		this.initRoles()

		this.registerDetail("profile-sessions", ProfileSessionDetail)
	}

	initForm() {
		this.initAddressLookup()
		this.initChangePassword()
		this.initTwoFactor()

		const name = this.form.get("name")
		name?.on('input', (value) => {
			this.nameDisplay.innerText = value
			this.breadcrumbName.innerText = value
		}, "ProfilePage")

		const salutation = this.form.get("salutation_id")
		const gender = this.form.get("gender_id")
		salutation?.on("change", (value) => {
			if (!value) {
				return
			}

			let genderId = null
			switch (value.id) {
				case Salutation.Mr:
					genderId = Gender.Male
					break

				case Salutation.Mrs:
				case Salutation.Ms:
					genderId = Gender.Female
					break

				default:
					break
			}

			gender.set(genderId)
		}, "ProfilePage")
	}

	initAddressLookup() {
		const country = this.form.get("country_id")
		const province = this.form.get("province_id")
		const city = this.form.get("city_id")
		const district = this.form.get("district_id")
		const sub_district = this.form.get("sub_district_id")

		province.init({
			param: (param) => {
				const filter = new Filter()
				const countryId = country.get()?.id
				if (countryId) {
					filter.and("country_id", countryId)
					param.filter = filter.get()
				}

				return param
			}
		})

		city.init({
			param: (param) => {
				const filter = new Filter()
				const countryId = country.get()?.id
				if (countryId) {
					filter.and("country_id", countryId)
				}

				const provinceId = province.get()?.id
				if (provinceId) {
					filter.and("province_id", provinceId)
				}

				if (filter.get().length > 0) {
					param.filter = filter.get()
				}

				return param
			}
		})

		district.init({
			param: (param) => {
				const filter = new Filter()
				const countryId = country.get()?.id
				if (countryId) {
					filter.and("country_id", countryId)
				}

				const provinceId = province.get()?.id
				if (provinceId) {
					filter.and("province_id", provinceId)
				}

				const cityId = city.get()?.id
				if (cityId) {
					filter.and("city_id", cityId)
				}

				if (filter.get().length > 0) {
					param.filter = filter.get()
				}

				return param
			}
		})

		sub_district.init({
			param: (param) => {
				const filter = new Filter()
				const countryId = country.get()?.id
				if (countryId) {
					filter.and("country_id", countryId)
				}

				const provinceId = province.get()?.id
				if (provinceId) {
					filter.and("province_id", provinceId)
				}

				const cityId = city.get()?.id
				if (cityId) {
					filter.and("city_id", cityId)
				}

				const districtId = district.get()?.id
				if (districtId) {
					filter.and("district_id", districtId)
				}

				if (filter.get().length > 0) {
					param.filter = filter.get()
				}

				return param
			}
		})

		country?.on("change", (val) => {
			if (!val) {
				province.set(null)
			}
		}, "ProfilePage")

		province?.on("change", (val) => {
			if (!val) {
				city.set(null)
				return
			}

			if (val && !country.get()) {
				country.set(val.country)
			}

			if (val && city.get() && city.get().province.id != val.id) {
				city.set(null)
			}
		}, "ProfilePage")

		city?.on("change", (val) => {
			if (!val) {
				district.set(null)
				return
			}

			if (val && !province.get()) {
				province.set(val.province)
			}

			if (val && district.get() && district.get().city.id != val.id) {
				district.set(null)
			}
		}, "ProfilePage")

		district?.on("change", (val) => {
			if (!val) {
				sub_district.set(null)
				return
			}

			if (val && !city.get()) {
				city.set(val.city)
			}

			if (val && sub_district.get() && sub_district.get().district.id != val.id) {
				sub_district.set(null)
			}
		}, "ProfilePage")

		sub_district?.on("change", (val) => {
			const postcode = this.form.get("postcode")
			postcode.set(val ? val.postcode : "")

			if (val && (!district.get() || district.get() && val.district.id != district.get().id)) {
				district.set(val.district)
			}
		}, "ProfilePage")
	}

	//#endregion

	//#region Roles

	initRoles() {
		this.rolesModal = this.get('roles-modal')
		this.aiRolesModal = this.get('ai-roles-modal')

		document.getElementById('roles-display')?.addEventListener('click', (e) => {
			if (e.target.closest('#roles-more-badge')) {
				this.rolesModal?.show()
			}
		})

		document.getElementById('ai-roles-display')?.addEventListener('click', (e) => {
			if (e.target.closest('#ai-roles-more-badge')) {
				this.aiRolesModal?.show()
			}
		})
	}

	/**
	 * Only regular users ever reach this page (integration accounts can't log in), so identity
	 * roles are always group_name=user. Null falls back to "user" too (pre-migration role, not
	 * yet tagged).
	 * @param {Array<Object>} roles
	 * @returns {void}
	 */
	_renderRoles(roles) {
		roles = roles ?? []

		const identityRoles = roles.filter(role => role.group_name === 'user' || role.group_name == null)
		const aiRoles = roles.filter(role => role.group_name === 'ai')

		this._renderRoleGroup(identityRoles, 'roles-display', 'roles-more-badge', 'roles-modal-body',
			(role) => `bg-${role.name == "Admin" ? "success" : "info"}`)

		this._renderRoleGroup(aiRoles, 'ai-roles-display', 'ai-roles-more-badge', 'ai-roles-modal-body', () => 'bg-info')
	}

	/**
	 * @param {Array<Object>} roles
	 * @param {string} displayId
	 * @param {string} moreBadgeId
	 * @param {string} modalBodyId
	 * @param {(role: Object) => string} badgeClass
	 * @returns {void}
	 */
	_renderRoleGroup(roles, displayId, moreBadgeId, modalBodyId, badgeClass) {
		const display = document.getElementById(displayId)
		const modalBody = document.getElementById(modalBodyId)
		const badge = (role) => `<span class="badge ${badgeClass(role)}">${role.name}</span>`

		let html = roles.length === 0
			? `<span class="badge bg-danger">None</span>`
			: roles.slice(0, 2).map(badge).join('')

		if (roles.length > 2) {
			html += `<span class="badge bg-secondary" role="button" id="${moreBadgeId}">${roles.length - 2}+</span>`
		}
		display.innerHTML = html

		modalBody.innerHTML = roles.map(role => `<tr><td>${badge(role)}</td></tr>`).join('')
	}

	//#endregion

	//#region Change Password

	initTwoFactor() {
		this.twoFactor        = new EnableTwoFactor()
		this.disableTwoFactor = new DisableTwoFactor()
		this.changeTwoFactor  = new ChangeTwoFactor()

		const enableBtn  = this.get("btn-enable-2fa")
		const disableBtn = this.get("btn-disable-2fa")
		const changeBtn  = this.get("btn-change-2fa-method")

		enableBtn?.on("click", () => this.twoFactor.modal.show(), "ProfilePage")

		disableBtn?.on("click", () => {
			const method = document.getElementById('2fa-status-section')?.dataset.method
			this.disableTwoFactor.open(method)
		}, "ProfilePage")

		changeBtn?.on("click", () => {
			const method = document.getElementById('2fa-status-section')?.dataset.method
			this.changeTwoFactor.open(method)
		}, "ProfilePage")

		this.twoFactor.on('enabled', ({ method }) => {
			const today = new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
			this.reloadTwoFactor(method, today)
		})

		this.disableTwoFactor.on('disabled', () => {
			this.reloadTwoFactor(null)
		})

		this.changeTwoFactor.on('changed', ({ method }) => {
			const today = new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
			this.reloadTwoFactor(method, today)
		})
	}

	/**
	 * @param {string|null} method
	 * @param {string|null} since
	 * @returns {void}
	 */
	reloadTwoFactor(method, since = null) {
		const isActive    = !!method
		const methodLabel = method === 'totp' ? 'Authenticator App' : 'Email OTP'

		const statusSection = document.getElementById('2fa-status-section')
		if (statusSection) {
			statusSection.dataset.method = method ?? ''
		}

		const badgeActive   = document.getElementById('2fa-badge-active')
		const badgeMethod   = document.getElementById('2fa-badge-method')
		const badgeInactive = document.getElementById('2fa-badge-inactive')
		const sinceEl       = document.getElementById('2fa-since')
		const actionsOff    = document.getElementById('2fa-actions-inactive')
		const actionsOn     = document.getElementById('2fa-actions-active')

		if (isActive) {
			badgeInactive?.classList.add('d-none')
			badgeActive?.classList.remove('d-none')

			if (badgeMethod) {
				badgeMethod.textContent = methodLabel
				badgeMethod.classList.remove('d-none')
			}

			if (sinceEl && since) {
				sinceEl.textContent = `Active since ${since}`
				sinceEl.classList.remove('d-none')
			}

			actionsOff?.classList.add('d-none')
			actionsOn?.classList.remove('d-none')
		} else {
			badgeActive?.classList.add('d-none')
			badgeMethod?.classList.add('d-none')
			badgeInactive?.classList.remove('d-none')
			sinceEl?.classList.add('d-none')
			actionsOff?.classList.remove('d-none')
			actionsOn?.classList.add('d-none')
		}
	}

	initChangePassword() {
		this.changePassword = new ChangePasswordModal()

		const changePassBtn = this.get("change-password")
		const forgotPassBtn = this.get("forgot-password")
		
		changePassBtn?.on("click", async () => this.changePassword.modal.show(), "ProfilePage")
		forgotPassBtn?.on("click", async () => await this.forgotPassword(), "ProfilePage")

		setTimeout(() => forgotPassBtn.enabled(), 10 * 1000)
	}

	/**
	 * @returns {Promise<void>}
	 */
	async forgotPassword() {
		if (!await this.helper.confirm({ title: "Are you sure" })) {
			return
		}

		this.helper.loadingPage(true)
		try {
			const req = await this.axios({
				method: "POST",
				url: `${BASE_URL}/core/profile/forgot-password`,
				data: {
					email: this.form.get("email").get()
				}
			})
			const res = req.data
			if (!res.success) {
				throw res.message
			}

			this.helper.successAlert({ title: res.message, timeout: 3000 })
		} catch (error) {
			this.helper.errorAlert({ title: error, timeout: 5000 })
		} finally {
			this.helper.loadingPage(false)

			this.get("forgot-password").disabled()
			setTimeout(() => this.get("forgot-password").enabled(), 30 * 1000)
		}
	}

	//#endregion

	//#region SSO

	initSSO() {
		const is_push_notification = this.form.get("is_push_notification")
		is_push_notification?.on("change", (value) => this.isPushNotif = value, "ProfilePage")

		const container = document.getElementById('google-sso-container')
		container?.addEventListener('click', (e) => {
			if (e.target.closest('#sso-google-connect')) {
				this.connectGoogle()
			} else if (e.target.closest('#sso-google-disconnect')) {
				this.disconnectGoogle()
			}
		})
	}

	/**
	 * @param {string|null} email
	 * @returns {void}
	 */
	renderGoogleSSO(email) {
		const container = document.getElementById('google-sso-container')
		if (!container) {
			return
		}

		if (email) {
			container.innerHTML = `
				<div class="d-flex align-items-center gap-3">
					<div class="d-flex align-items-center gap-2 flex-grow-1">
						${GOOGLE_SVG_LG}
						<div class="d-flex flex-column">
							<span class="fs-11 text-muted">Connected as</span>
							<span class="fs-13 fw-medium">${email}</span>
						</div>
					</div>
					<span class="badge bg-success-transparent">Connected</span>
					<button type="button" class="btn btn-sm btn-outline-danger" id="sso-google-disconnect">Disconnect</button>
				</div>`
			return
		}

		container.innerHTML = `
			<button type="button" class="btn btn-outline-secondary d-flex align-items-center gap-2" id="sso-google-connect">
				${GOOGLE_SVG_SM}
				Connect with Google
			</button>`
	}

	/**
	 * @returns {void}
	 */
	connectGoogle() {
		const connectUrl = document.getElementById('google-sso-container')?.dataset.connectUrl
		if (!connectUrl) {
			return
		}
		window.location.href = connectUrl
	}

	/**
	 * @returns {Promise<void>}
	 */
	async disconnectGoogle() {
		if (!await this.helper.confirm({ title: "Disconnect Google account?", message: "You will need to reconnect to use Google sign-in." })) {
			return
		}

		this.helper.loadingPage(true)
		try {
			await this.axios({
				method: "DELETE",
				url: `${BASE_URL}/core/profile/sso/google`
			})
			this.renderGoogleSSO(null)
		} catch (error) {
			if (!error?.response) {
				this.helper.errorAlert({ title: "Oops! There was an error", message: error, timeout: null })
			}
		} finally {
			this.helper.loadingPage(false)
		}
	}

	//#endregion

	//#region Form Events

	/**
	 * @param {Object} data
	 * @returns {Promise<void>}
	 */
	async onRefreshed(data) {
		const is_push_notification 	 = this.form.get("is_push_notification")
		const is_mobile_notification = this.form.get("is_mobile_notification")
		const is_email_notification  = this.form.get("is_email_notification")
		const is_app_notification 	 = this.form.get("is_app_notification")

		this.nameDisplay.innerText 	  = data.name
		this.breadcrumbName.innerText = data.name

		this._renderRoles(data.roles)

		this._updateStorage(data)

		is_push_notification?.set(data.user.is_push_notification, true)
		is_mobile_notification?.set(data.user.is_mobile_notification, true)
		is_email_notification?.set(data.user.is_email_notification, true)
		is_app_notification?.set(data.user.is_app_notification, true)

		this.renderGoogleSSO(data.sso?.google ?? null)

		const twoFactorMethod = data.user.two_factor_confirmed_at ? data.user.two_factor_method : null
		const twoFactorSince  = data.user.two_factor_confirmed_at
			? new Date(data.user.two_factor_confirmed_at).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
			: null
		this.reloadTwoFactor(twoFactorMethod, twoFactorSince)

		this.form.get('username').set(data.user.username)
	}

	/**
	 * @param {Object} data
	 * @returns {void}
	 */
	_updateStorage(data) {
		const storageInfo = document.getElementById('storage-info')
		const maxSize = parseInt(storageInfo?.dataset.maxSize ?? 10737418240)
		const maxFormatted = storageInfo?.dataset.maxFormatted ?? ''
		const usedBytes = data.total_uploaded_size_raw ?? 0
		const percentage = maxSize > 0 ? Math.min(100, parseFloat(((usedBytes / maxSize) * 100).toFixed(2))) : 0
		const barColor = percentage >= 90 ? 'danger' : (percentage >= 70 ? 'warning' : 'success')

		const progressBar = document.getElementById('storage-progress-bar')
		const fileSizeDisplay = document.getElementById('file-size-display')
		const fileCountDisplay = document.getElementById('file-count-display')
		const storagePercentage = document.getElementById('storage-percentage')

		if (progressBar) {
			progressBar.style.width = `${percentage}%`
			progressBar.className = `progress-bar bg-${barColor}`
			progressBar.setAttribute('aria-valuenow', percentage)
		}

		if (fileSizeDisplay) {
			fileSizeDisplay.innerText = `${data.total_uploaded_size} / ${maxFormatted}`
		}

		if (fileCountDisplay) {
			fileCountDisplay.innerText = `${data.total_file} files`
		}

		if (storagePercentage) {
			storagePercentage.innerText = `${percentage}% used`
		}
	}

	/**
	 * @returns {Promise<void>}
	 */
	async validated() {
		const is_push_notification = this.form.get("is_push_notification")

		if (this.isPushNotif) {
			this.isPushNotif = false

			if (!await this.pushNotification.subscribe()) {
				console.warn(`Push notification cannot be setup`)

				is_push_notification.set(false)
				return
			}

			this.pushNotifRefresh = true
		} else if (!is_push_notification.get() && IS_PUSH_NOTIFICATION) {
			await this.pushNotification.unsubscribe()
			this.pushNotifRefresh = true
		}
	}

	/**
	 * @param {Object} response
	 * @returns {Promise<void>}
	 */
	async success(response) {
		super.success(response)

		const username = this.form.get('username')
		if (!this.helper.isEmpty(username.get()) && !username.isDisabled()) {
			username.disabled()
		}

		if (this.pushNotifRefresh) {
			window.location.reload()
		}
	}

	//#endregion
}
