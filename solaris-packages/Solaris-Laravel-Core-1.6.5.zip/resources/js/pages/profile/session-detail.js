import SolarListDetail from "@core-js/solaris/solar/solar-list-detail";
import DateHelper from "../../solaris/date-helper";

export default class ProfileSessionDetail extends SolarListDetail {
	init() {
		this.columnRender("channel", this.channelRender.bind(this));
		this.columnRender("user_agent", this.userAgentRender.bind(this));
		this.columnRender("logged_in_at", this.loginAtRender.bind(this));
		this.columnRender("last_active_at", this.lastActiveRender.bind(this));
		this.columnRender("status", this.statusRender.bind(this));
	}

	// #region Rendering
	/**
	 * @param {string} data
	 * @param {Object} rowData
	 * @returns {string}
	 */
	channelRender(data, rowData) {
		if (data === 'mobile') {
			return `<span class="badge bg-primary-subtle text-primary-emphasis"><i class="bi bi-phone-fill me-1"></i>Mobile</span>`;
		}

		return `<span class="badge bg-secondary-subtle text-secondary-emphasis"><i class="bi bi-globe me-1"></i>Web</span>`;
	}

	/**
	 * @param {string|null} data
	 * @param {Object} rowData
	 * @returns {string}
	 */
	userAgentRender(data, rowData) {
		if (!data) {
			return '<span class="text-muted">—</span>';
		}

		if (rowData.channel === 'mobile') {
			const device = rowData.device_name || this._parseMobileDevice(data);
			return device || '<span class="text-muted">—</span>';
		}

		const browser = this._parseBrowser(data);
		const os = this._parseOS(data);

		return `${browser} <span class="text-muted">· ${os}</span>`;
	}

	/**
	 * @param {string|null} data
	 * @param {Object} rowData
	 * @returns {string}
	 */
	loginAtRender(data, rowData) {
		if (!data) {
			return '<span class="text-muted">—</span>';
		}

		const loginDate = DateHelper.formatDatetime(data);
		let extra = '';

		if (rowData.terminated_at) {
			extra = `<div class="text-muted fs-12 mt-1"><i class="ri-forbid-line me-1"></i>Terminated · ${DateHelper.formatDatetime(rowData.terminated_at)}</div>`;
		} else if (rowData.logged_out_at) {
			extra = `<div class="text-muted fs-12 mt-1"><i class="ri-logout-box-line me-1"></i>Logout · ${DateHelper.formatDatetime(rowData.logged_out_at)}</div>`;
		}

		return `<div>${loginDate}${extra}</div>`;
	}

	/**
	 * @param {string|null} data
	 * @returns {string}
	 */
	lastActiveRender(data, rowData) {
		if (!rowData.resolved_last_active) {
			return '<span class="text-muted">—</span>';
		}

		return DateHelper.relativeTime(rowData.resolved_last_active);
	}

	/**
	 * @param {string|null} data
	 * @param {Object} rowData
	 * @returns {string}
	 */
	statusRender(data, rowData) {
		if (rowData.terminated_at) {
			return `<span class="badge bg-danger">Terminated</span>`;
		}

		if (rowData.logged_out_at) {
			return `<span class="badge bg-secondary">Logged Out</span>`;
		}

		return `<span class="badge bg-success">Active</span>`;
	}
	// #endregion

	// #region Parsing
	/**
	 * @param {string} ua
	 * @returns {string}
	 */
	_parseBrowser(ua) {
		let match;

		if ((match = ua.match(/Edg\/(\d+)/))) {
			return `Edge ${match[1]}`;
		}

		if ((match = ua.match(/OPR\/(\d+)/))) {
			return `Opera ${match[1]}`;
		}

		if ((match = ua.match(/Chrome\/(\d+)/))) {
			return `Chrome ${match[1]}`;
		}

		if ((match = ua.match(/Firefox\/(\d+)/))) {
			return `Firefox ${match[1]}`;
		}

		if ((match = ua.match(/Version\/(\d+).*Safari/))) {
			return `Safari ${match[1]}`;
		}

		return 'Browser';
	}

	/**
	 * @param {string} ua
	 * @returns {string}
	 */
	_parseOS(ua) {
		if (/Windows NT 10\.0/.test(ua)) {
			return 'Windows 10/11';
		}

		if (/Windows NT/.test(ua)) {
			return 'Windows';
		}

		if (/Mac OS X/.test(ua)) {
			return 'macOS';
		}

		if (/Android/.test(ua)) {
			return 'Android';
		}

		if (/iPhone|iPad/.test(ua)) {
			return 'iOS';
		}

		if (/Linux/.test(ua)) {
			return 'Linux';
		}

		return 'Unknown OS';
	}

	/**
	 * @param {string} ua
	 * @returns {string|null}
	 */
	_parseMobileDevice(ua) {
		const match = ua.match(/\(([^)]+)\)/);
		return match ? match[1].split(';')[0].trim() : null;
	}
	// #endregion
}
