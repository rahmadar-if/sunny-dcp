import ProfilePage from "./page"

new ProfilePage()