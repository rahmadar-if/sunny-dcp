import SolarModalPage from "@core-js/solaris/solar/solar-modal-page"
import OtpInput from "@core-js/solaris/form/otp-input"

export default class TwoFactorBase extends SolarModalPage {

    constructor(modalId) {
        super(modalId)
    }

    _preInit() {
        super._preInit()
        this._events      = []
        this._step        = null
        this._method      = null
        this._backupCodes = []
    }

    //#region Events

    static supportedEvent() {
        return []
    }

    /**
     * @param {string} type
     * @param {Function} callback
     * @returns {this}
     */
    on(type, callback) {
        if (!this.constructor.supportedEvent().includes(type)) {
            throw new Error(`Event ${type} does not support`)
        }

        if (!this.helper.isFunction(callback)) {
            throw new Error(`Callback must be function`)
        }

        this._events.push({ type, callback })

        return this
    }

    /**
     * @param {string} type
     * @param {...*} data
     * @returns {Promise<void>}
     */
    async trigger(type, ...data) {
        const events = this._events.filter(e => e.type === type)
        for (let i = 0; i < events.length; i++) {
            await events[i].callback(...data)
        }
    }

    //#endregion

    //#region AJAX Primitives

    _extractError(res) {
        return res.errors ? Object.values(res.errors)[0] : res.message
    }

    async _doConfirmPassword(url, password) {
        const req = await this.axios({ method: 'POST', url, data: { password } })
        const res = req.data
        if (!res.success) throw this._extractError(res)
        return res.data
    }

    async _doLoadTotpSetup(url) {
        const req = await this.axios({ method: 'POST', url })
        const res = req.data
        if (!res.success) throw this._extractError(res)
        return res.data
    }

    async _doLoadEmailSetup(url) {
        const req = await this.axios({ method: 'POST', url })
        const res = req.data
        if (!res.success) throw this._extractError(res)
        return res.data
    }

    async _doVerifyCode(url, code) {
        const req = await this.axios({ method: 'POST', url, data: { code } })
        const res = req.data
        if (!res.success) throw this._extractError(res)
        return res.data
    }

    //#endregion

    //#region Backup Codes

    _populateBackupCodes(codes, gridEl) {
        if (!gridEl) return
        gridEl.innerHTML = codes.map(code => `
            <div class="col-6">
                <code class="d-block text-center py-2 px-3 bg-light rounded fw-semibold fs-13 border">${code}</code>
            </div>
        `).join('')
    }

    _downloadBackupCodes() {
        const content = this._backupCodes.join('\n')
        const blob    = new Blob([content], { type: 'text/plain' })
        const url     = URL.createObjectURL(blob)
        const a       = document.createElement('a')
        a.href        = url
        a.download    = 'twofa-backup-codes.txt'
        a.click()
        URL.revokeObjectURL(url)
    }

    async _copyBackupCodes() {
        await navigator.clipboard.writeText(this._backupCodes.join('\n'))
        this.helper.toast({ title: 'Backup codes copied to clipboard', timeout: 2000 })
    }

    //#endregion

    //#region Button UI

    _nextAsContinue() {
        if (!this.nextBtn) return
        this.nextBtn._element.classList.replace('btn-success', 'btn-primary')
        this.nextBtn._element.classList.replace('btn-danger', 'btn-primary')
        this.nextBtn._element.textContent = 'Continue'
    }

    _nextAsDone() {
        if (!this.nextBtn) return
        this.nextBtn._element.classList.replace('btn-primary', 'btn-success')
        this.nextBtn._element.innerHTML = '<i class="ri-check-line me-1"></i>Done'
    }

    _nextAsDanger() {
        if (!this.nextBtn) return
        this.nextBtn._element.classList.replace('btn-primary', 'btn-danger')
        this.nextBtn._element.textContent = 'Disable 2FA'
    }

    //#endregion

    //#region UX Helpers

    /**
     * Bind Enter key on the password field to trigger _handleNext().
     * @param {string} fieldId
     * @returns {void}
     */
    _bindPasswordEnter(fieldId) {
        const field = this.form.get(fieldId)
        if (!field) {
            return
        }

        field.on('keydown', (val, e) => {
            if (e.key !== 'Enter') {
                return
            }

            e.preventDefault()
            this._handleNext()
        })
    }

    /**
     * Auto-trigger _handleNext() when OTP input is fully filled.
     * @param {OtpInput} otp
     * @returns {void}
     */
    _bindOtpAutoSubmit(otp) {
        if (!otp) {
            return
        }

        otp.on('change', () => this._handleNext())
    }

    //#endregion

}
