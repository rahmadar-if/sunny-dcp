import PermissionListPage from "./list"

new PermissionListPage("permission")