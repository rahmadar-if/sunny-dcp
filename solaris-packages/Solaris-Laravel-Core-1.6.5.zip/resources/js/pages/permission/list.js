import SolarListPage from "@core-js/solaris/solar/solar-list-page";
import Filter from "@core-js/solaris/filter/filter";
import PermissionAssign from "../../solaris/assign/permission-assign";

const GROUPS = {
    user: "User",
    ai: "AI",
    integration: "Integration",
}

const DEFAULT_GROUP = "user"
const STORAGE_KEY = "permission_group_filter"

export default class PermissionListPage extends SolarListPage {

    //#region Lifecycle

    init() {
        this._activeGroup = this._readStoredGroup()

        this.columnRender("group_name", this.groupColumnRender.bind(this))

        this.assign = new PermissionAssign("permission-assign-modal")
        this.assign.on("closed", (changed) => changed ? this.refresh() : null)

        this.initGroupFilter()
        this.initModal()
    }

    //#endregion

    //#region Group Filter

    /**
     * @returns {void}
     */
    initGroupFilter() {
        const radios = document.querySelectorAll('input[name="filter-group"]')

        radios.forEach(radio => {
            radio.checked = radio.value === this._activeGroup

            radio.addEventListener("change", async (e) => {
                if (!e.target.checked) {
                    return
                }

                this._activeGroup = e.target.value
                localStorage.setItem(STORAGE_KEY, this._activeGroup)

                this._applyGroupIndicator()
                await this._applyGroupFilter()
            })
        })

        // Applied without refreshing: the table performs its own initial load right after init,
        // and refreshing here would fetch the same page twice.
        this._applyGroupFilter(false)
    }

    /**
     * @param {boolean} [refresh=true]
     * @returns {Promise<void>}
     */
    async _applyGroupFilter(refresh = true) {
        await this.table.filter("group", new Filter().and("group_name", this._activeGroup), refresh)
    }

    /**
     * Falls back to the default when storage holds a group that no longer exists, so a stale
     * value cannot leave the page filtered to nothing.
     * @returns {string}
     */
    _readStoredGroup() {
        const stored = localStorage.getItem(STORAGE_KEY)

        return Object.hasOwn(GROUPS, stored ?? "") ? stored : DEFAULT_GROUP
    }

    //#endregion

    //#region Modal

    /**
     * @returns {void}
     */
    initModal() {
        if (!this.hasModalForm()) {
            return
        }

        // The field is a read-only indicator, so it is kept out of the payload and the real
        // value is injected from the active filter instead.
        this.form.exclude("group_name")

        this.form.on("sending", (config) => {
            config.data.group_name = this._activeGroup
        }, "PermissionListPage")

        this.modal.on("show", () => this._applyGroupIndicator(), "PermissionListPage")

        this._applyGroupIndicator()
    }

    /**
     * @returns {void}
     */
    _applyGroupIndicator() {
        this.form?.get("group_name")?.set(GROUPS[this._activeGroup] ?? "")
    }

    //#endregion

    //#region Column

    groupColumnRender(data) {
        return GROUPS[data] ?? ""
    }

    //#endregion

    onActionCreated(row, cell, rowData) {
        this.actionAfter(row, "edit-action", {
            selector: "assign-action",
            label: "Assign",
            icon: "ri-user-settings-line",
            callback: async () => await this.assign.show(rowData.id)
        })
    }
}
