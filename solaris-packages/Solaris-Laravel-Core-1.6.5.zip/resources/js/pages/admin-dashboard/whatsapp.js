import SolarPage from "@core-js/solaris/solar/solar-page"

export default class AdminDashboardWhatsApp extends SolarPage {

	// #region Lifecycle

	/**
	 * @param {{categories: string[], series: Array<{name: string, data: number[]}>}} messageVolumeData
	 */
	constructor(messageVolumeData) {
		super(false)

		this.messageVolumeData = messageVolumeData

		this.init()
	}

	init() {
		this.initMetric()
		this.initDevices()
		this.initMessageVolume()
		this.initTabWatcher()
	}

	// #endregion

	// #region Public API

	/**
	 * @param {Object} data
	 * @returns {Promise<void>}
	 */
	async refresh(data) {
		this._refreshMetric(this.totalDevice, data.total_device)
		this._refreshMetric(this.totalMessagesIn, data.total_messages_in)
		this._refreshMetric(this.totalMessagesOut, data.total_messages_out)
		this._refreshMetric(this.mediaMessages, data.media_messages)
		this._refreshMetric(this.waFile, data.wa_file)
		this._refreshMetric(this.waStorage, data.wa_storage)

		this.devicesRefresh(data.devices)
		this.messageVolumeRefresh(data.message_volume)
	}

	// #endregion

	// #region Metric

	initMetric() {
		this.totalDevice      = this.get("total-device")
		this.totalMessagesIn  = this.get("total-messages-in")
		this.totalMessagesOut = this.get("total-messages-out")
		this.mediaMessages    = this.get("media-messages")
		this.waFile           = this.get("whatsapp-wa-file")
		this.waStorage        = this.get("whatsapp-wa-storage")

		this.totalDevice?.init()
		this.totalMessagesIn?.init()
		this.totalMessagesOut?.init()
		this.mediaMessages?.init()
		this.waFile?.init()
		this.waStorage?.init()
	}

	/**
	 * @param {import("@core-js/solaris/metric-dashboard").default} metric
	 * @param {{value: string}} data
	 */
	_refreshMetric(metric, data) {
		if (!metric || !data) {
			return
		}

		metric.setValue(data.value)
	}

	// #endregion

	// #region Devices

	initDevices() {
		this.devices = document.querySelector("#whatsapp-devices")

		if (this.devices) {
			this._devicesObserver = new MutationObserver(() => this._adjustDevicesHeight())
			this._devicesObserver.observe(this.devices, { childList: true })
		}

		this._adjustDevicesHeight()
	}

	/**
	 * Bootstrap tab panes are `display:none` while inactive, so height reads 0
	 * until the tab is actually shown. Recalculate once the WhatsApp tab opens.
	 */
	initTabWatcher() {
		this.get("dashboard-tab")?.on("change", (target) => {
			if (target === "dashboard-tab-whatsapp") {
				this._adjustDevicesHeight()
			}
		}, "AdminDashboardWhatsApp")
	}

	/**
	 * @param {Array<Object>} data
	 */
	devicesRefresh(data) {
		if (!this.devices || !data) {
			return
		}

		if (data.length === 0) {
			this.devices.innerHTML = `<div class="text-center text-muted py-4">No WhatsApp device configured.</div>`
			return
		}

		this.devices.innerHTML = data
			.map(device => `<div class="whatsapp-device-item">${this._renderDevice(device)}</div>`)
			.join("")
	}

	/**
	 * Clamp visible area to exactly 2 full cards; overflow scrolls. No-op when 2 or fewer,
	 * or when the tab is hidden (offsetHeight reads 0 for display:none ancestors).
	 */
	_adjustDevicesHeight() {
		if (!this.devices) {
			return
		}

		const cards = this.devices.querySelectorAll(".whatsapp-device-item")

		if (cards.length <= 2) {
			this.devices.style.maxHeight = ""
			this.devices.style.overflowY = ""
			return
		}

		const gap    = parseFloat(getComputedStyle(this.devices).rowGap) || 0
		const height = cards[0].offsetHeight + cards[1].offsetHeight + gap

		if (height === 0) {
			return
		}

		this.devices.style.maxHeight = `${height}px`
		this.devices.style.overflowY = "auto"
	}

	/**
	 * @param {{name: string, phone_number: ?string, is_connected: boolean, daily_used: number, error: ?string, total_conversation: number, quota: ?{used: number, total: number, package: ?string, expires_at: ?string, daily_limit: number}}} device
	 * @returns {string}
	 */
	_renderDevice(device) {
		const quota = device.quota

		const statusBadge = device.error
			? `<span class="badge bg-danger">Error</span>`
			: (device.is_connected
				? `<span class="badge bg-success">Connected</span>`
				: `<span class="badge bg-secondary">Disconnected</span>`)

		let quotaHtml = ""
		if (quota) {
			const packagePercent = quota.total > 0 ? Math.min(100, Math.round((quota.used / quota.total) * 100)) : 0
			const dailyPercent   = quota.daily_limit > 0 ? Math.min(100, Math.round((device.daily_used / quota.daily_limit) * 100)) : 0
			const packageColor   = packagePercent >= 90 ? "bg-danger" : (packagePercent >= 70 ? "bg-warning" : "bg-primary")
			const expiresAt      = quota.expires_at
				? `until ${new Date(quota.expires_at).toLocaleDateString("en-US", { day: "numeric", month: "short", year: "numeric" })}`
				: ""

			quotaHtml = `
				<div class="mb-2">
					<div class="d-flex justify-content-between fs-12 text-muted mb-1">
						<span>
							<span class="badge bg-light text-dark border me-1">${quota.package ?? "-"}</span>
							${expiresAt}
						</span>
						<span>${(quota.used ?? 0).toLocaleString("en-US")} / ${(quota.total ?? 0).toLocaleString("en-US")}</span>
					</div>
					<div class="progress" style="height: 6px;">
						<div class="progress-bar ${packageColor}" role="progressbar" style="width: ${packagePercent}%"></div>
					</div>
				</div>
				<div>
					<div class="d-flex justify-content-between fs-12 text-muted mb-1">
						<span>Daily Limit</span>
						<span>${(device.daily_used ?? 0).toLocaleString("en-US")} / ${(quota.daily_limit ?? 0).toLocaleString("en-US")}</span>
					</div>
					<div class="progress" style="height: 6px;">
						<div class="progress-bar bg-warning" role="progressbar" style="width: ${dailyPercent}%"></div>
					</div>
				</div>`
		}

		return `<div class="card custom-card mb-0">
			<div class="card-body">
				<div class="d-flex align-items-center justify-content-between mb-2">
					<div>
						<div class="fw-medium">${device.name}</div>
						<div class="fs-12 text-muted">${device.phone_number ?? "No active number"}</div>
					</div>
					${statusBadge}
				</div>
				<div class="fs-12 text-muted mb-3">
					<i class="ri-chat-3-line me-1"></i>${device.total_conversation} conversations
				</div>
				${quotaHtml}
			</div>
		</div>`
	}

	// #endregion

	// #region Message Volume

	initMessageVolume() {
		const options = {
			series: this.messageVolumeData.series,
			chart: {
				type: "line",
				height: 300,
			},
			stroke: {
				curve: "smooth",
				width: 2,
			},
			xaxis: {
				categories: this.messageVolumeData.categories,
			},
			colors: ["var(--info-color)", "var(--success-color)"],
			dataLabels: {
				enabled: false,
			},
		}

		this.messageVolumeChart = new ApexCharts(document.querySelector("#message-volume-chart"), options)
		this.messageVolumeChart.render()

		this._refreshMessageVolume = this.get("message-volume-refresh")
		this._refreshMessageVolume?.on("click", async () => {
			this._refreshMessageVolume.disabled()
			await this.messageVolumeRefresh()
			setTimeout(() => this._refreshMessageVolume.enabled(), 2000)
		}, "AdminDashboardWhatsApp")
	}

	/**
	 * @param {{categories: string[], series: Array<{name: string, data: number[]}>}|null} data
	 * @returns {Promise<void>}
	 */
	async messageVolumeRefresh(data = null) {
		if (!data) {
			const req = await this.axios({
				method: "POST",
				url   : `${BASE_URL}/admin/dashboard/message-volume`,
			})

			data = req.data
		}

		this.messageVolumeChart?.updateOptions({
			series: data.series,
			xaxis : { categories: data.categories },
		})
	}

	// #endregion
}
