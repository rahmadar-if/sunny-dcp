import SolarPage from "@core-js/solaris/solar/solar-page"

export default class AdminDashboardStorage extends SolarPage {

	// #region Lifecycle

	constructor() {
		super(false)

		this.init()
	}

	init() {
		this.initMetric()
		this.initStoragePerModule()
		this.initTopStorageByUser()
		this.initNearLimitUsers()
	}

	// #endregion

	// #region Public API

	/**
	 * @param {Object} data
	 * @returns {Promise<void>}
	 */
	async refresh(data) {
		this._refreshMetric(this.totalFile, data.total_file)
		this._refreshMetric(this.totalSize, data.total_size)
		this._refreshMetric(this.waFile, data.wa_file)
		this._refreshMetric(this.waStorage, data.wa_storage)

		this.storagePerModuleRefresh(data.storage_per_module)
		this.topStorageByUserRefresh(data.top_storage_by_user)
		this.nearLimitUsersRefresh(data.near_limit_users)
	}

	// #endregion

	// #region Metric

	initMetric() {
		this.totalFile = this.get("total-file")
		this.totalSize = this.get("total-size")
		this.waFile    = this.get("wa-file")
		this.waStorage = this.get("wa-storage")

		this.totalFile?.init()
		this.totalSize?.init()
		this.waFile?.init()
		this.waStorage?.init()
	}

	/**
	 * @param {import("@core-js/solaris/metric-dashboard").default} metric
	 * @param {{value: string}} data
	 */
	_refreshMetric(metric, data) {
		if (!metric || !data) {
			return
		}

		metric.setValue(data.value)
	}

	// #endregion

	// #region Storage per Module

	initStoragePerModule() {
		this.storagePerModule = document.querySelector("#storage-per-module")

		this._refreshStoragePerModule = this.get("storage-per-module-refresh")
		this._refreshStoragePerModule?.on("click", async () => {
			this._refreshStoragePerModule.disabled()
			await this.storagePerModuleRefresh()
			setTimeout(() => this._refreshStoragePerModule.enabled(), 2000)
		}, "AdminDashboardStorage")
	}

	/**
	 * @param {Array<{name: string, total_file: number, size_human: string, percent: number}>|null} data
	 * @returns {Promise<void>}
	 */
	async storagePerModuleRefresh(data = null) {
		if (!data) {
			const req = await this.axios({
				method: "POST",
				url   : `${BASE_URL}/admin/dashboard/storage-per-module`,
			})

			data = req.data
		}

		if (!this.storagePerModule) {
			return
		}

		if (data.length === 0) {
			this.storagePerModule.innerHTML = `<li class="list-group-item text-center text-muted py-4">No storage usage recorded yet.</li>`
			return
		}

		this.storagePerModule.innerHTML = data
			.map(item => `<li class="list-group-item d-flex align-items-center justify-content-between">
				<span class="fw-medium">${item.name}</span>
				<span class="fs-12 text-muted">${item.total_file} files &middot; ${item.size_human} &middot; ${item.percent}%</span>
			</li>`)
			.join("")
	}

	// #endregion

	// #region Top Storage by User

	initTopStorageByUser() {
		this.topStorageByUser = document.querySelector("#top-storage-by-user")

		this._refreshTopStorageByUser = this.get("top-storage-by-user-refresh")
		this._refreshTopStorageByUser?.on("click", async () => {
			this._refreshTopStorageByUser.disabled()
			await this.topStorageByUserRefresh()
			setTimeout(() => this._refreshTopStorageByUser.enabled(), 2000)
		}, "AdminDashboardStorage")
	}

	/**
	 * @param {Array<{user_name: string, user_email: string, total_file: number, total_size_human: string, limit_human: string, percent: number}>|null} data
	 * @returns {Promise<void>}
	 */
	async topStorageByUserRefresh(data = null) {
		if (!data) {
			const req = await this.axios({
				method: "POST",
				url   : `${BASE_URL}/admin/dashboard/top-storage-by-user`,
			})

			data = req.data
		}

		if (!this.topStorageByUser) {
			return
		}

		if (data.length === 0) {
			this.topStorageByUser.innerHTML = `<li class="list-group-item text-center text-muted py-4">No storage usage recorded yet.</li>`
			return
		}

		this.topStorageByUser.innerHTML = data
			.map(item => this._renderUserStorage(item, "bg-secondary"))
			.join("")
	}

	// #endregion

	// #region Near Limit Users

	initNearLimitUsers() {
		this.nearLimitUsers = document.querySelector("#near-limit-users")

		this._refreshNearLimitUsers = this.get("near-limit-users-refresh")
		this._refreshNearLimitUsers?.on("click", async () => {
			this._refreshNearLimitUsers.disabled()
			await this.nearLimitUsersRefresh()
			setTimeout(() => this._refreshNearLimitUsers.enabled(), 2000)
		}, "AdminDashboardStorage")
	}

	/**
	 * @param {Array<{user_name: string, user_email: string, total_file: number, total_size_human: string, limit_human: string, percent: number}>|null} data
	 * @returns {Promise<void>}
	 */
	async nearLimitUsersRefresh(data = null) {
		if (!data) {
			const req = await this.axios({
				method: "POST",
				url   : `${BASE_URL}/admin/dashboard/near-limit-users`,
			})

			data = req.data
		}

		if (!this.nearLimitUsers) {
			return
		}

		if (data.length === 0) {
			this.nearLimitUsers.innerHTML = `<li class="list-group-item text-center text-muted py-4">No user near the storage limit.</li>`
			return
		}

		this.nearLimitUsers.innerHTML = data
			.map(item => this._renderUserStorage(item, "bg-danger-transparent", "bg-danger"))
			.join("")
	}

	// #endregion

	// #region Shared Rendering

	/**
	 * @param {{user_name: string, user_email: string, total_file: number, total_size_human: string, limit_human: string, percent: number}} item
	 * @param {string} avatarClass
	 * @param {?string} forceBarColor
	 * @returns {string}
	 */
	_renderUserStorage(item, avatarClass, forceBarColor = null) {
		const percent  = Math.min(100, item.percent)
		const barColor = forceBarColor ?? (item.percent >= 90 ? "bg-danger" : (item.percent >= 70 ? "bg-warning" : "bg-success"))

		return `<li class="list-group-item">
			<div class="d-flex align-items-center justify-content-between gap-2">
				<div class="d-flex align-items-center gap-2">
					<span class="avatar avatar-sm avatar-rounded ${avatarClass}">${this.helper.getInitialName(item.user_name)}</span>
					<div>
						<span class="d-block fw-medium">${item.user_name ?? "-"}</span>
						<span class="fs-12 text-muted">${item.user_email ?? "-"}</span>
					</div>
				</div>
				<div class="text-end">
					<div class="fs-12 fw-medium">${item.total_size_human} / ${item.limit_human}</div>
					<div class="fs-11 text-muted">${item.total_file} files &middot; ${item.percent}%</div>
				</div>
			</div>
			<div class="progress mt-2" style="height: 4px;">
				<div class="progress-bar ${barColor}" role="progressbar" style="width: ${percent}%"></div>
			</div>
		</li>`
	}

	// #endregion
}
