import AdminDashboardPage from "./page"

export default new AdminDashboardPage()
