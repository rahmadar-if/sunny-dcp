import SolarPage from "@core-js/solaris/solar/solar-page"
import AdminDashboardUsersSessions from "./users-sessions"
import AdminActiveSessions from "./active-sessions"
import AdminDashboardStorage from "./storage"
import AdminDashboardWhatsApp from "./whatsapp"
import AdminDashboardApproval from "./approval"
import AdminDashboardAgentAi from "./agent-ai"

export default class AdminDashboardPage extends SolarPage {
	init() {
		this._refreshBtn = this.get("refresh")
		this._refreshBtn?.on("click", async () => {
			this._refreshBtn.disabled()
			await this.refresh()
			setTimeout(() => this._refreshBtn.enabled(), 2000)
		}, "AdminDashboardPage")

		this.usersSessions = new AdminDashboardUsersSessions(USER_DISTRIBUTION)
		this.activeSessions = new AdminActiveSessions("admin-active-sessions")
		this.storage = new AdminDashboardStorage()
		this.whatsapp = new AdminDashboardWhatsApp(MESSAGE_VOLUME)
		this.approval = new AdminDashboardApproval(REQUEST_BY_STATUS)
		this.agentAi = new AdminDashboardAgentAi()
	}

	async refresh() {
		try {
			this.helper.loadingPage(true)
			const data = await this._fetchData()

			await Promise.all([
				this.usersSessions?.refresh(data.users_sessions),
				this.activeSessions?.table?.refresh(),
				this.storage?.refresh(data.storage),
				this.whatsapp?.refresh(data.whatsapp),
				this.approval?.refresh(data.approval),
				this.agentAi?.refresh(data.agent_ai),
			])
		} catch (error) {
			console.error({ error })
		} finally {
			this.helper.loadingPage(false)
		}
	}

	async _fetchData() {
		const req = await this.axios({
			method: "POST",
			url   : `${BASE_URL}/admin/dashboard/all`,
		})

		return req.data
	}
}
