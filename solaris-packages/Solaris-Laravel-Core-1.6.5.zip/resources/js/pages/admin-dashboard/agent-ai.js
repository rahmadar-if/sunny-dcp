import SolarPage from "@core-js/solaris/solar/solar-page"

export default class AdminDashboardAgentAi extends SolarPage {

	// #region Lifecycle

	init() {
		this.initMetric()
		this.initTopAgentByCost()
		this.initTopUserByCost()
	}

	// #endregion

	// #region Public API

	/**
	 * @param {Object} data
	 * @returns {Promise<void>}
	 */
	async refresh(data) {
		this._refreshMetric(this.totalToken, data.total_token)
		this._refreshMetric(this.totalRequest, data.total_request)
		this._refreshMetric(this.estCost, data.est_cost)

		this.topAgentByCostRefresh(data.top_agent_by_cost)
		this.topUserByCostRefresh(data.top_user_by_cost)
	}

	// #endregion

	// #region Metric

	initMetric() {
		this.totalToken   = this.get("total-token-ai")
		this.totalRequest = this.get("total-request-ai")
		this.estCost      = this.get("est-cost-ai")

		this.totalToken?.init()
		this.totalRequest?.init()
		this.estCost?.init()
	}

	/**
	 * @param {import("@core-js/solaris/metric-dashboard").default} metric
	 * @param {{value: string}} data
	 */
	_refreshMetric(metric, data) {
		if (!metric || !data) {
			return
		}

		metric.setValue(data.value)
	}

	// #endregion

	// #region Top Agent by Cost

	initTopAgentByCost() {
		this.topAgentByCost = document.querySelector("#top-agent-by-cost")

		this._refreshTopAgentByCost = this.get("top-agent-by-cost-refresh")
		this._refreshTopAgentByCost?.on("click", async () => {
			this._refreshTopAgentByCost.disabled()
			await this.topAgentByCostRefresh()
			setTimeout(() => this._refreshTopAgentByCost.enabled(), 2000)
		}, "AdminDashboardAgentAi")
	}

	/**
	 * @param {Array<{name: string, total_token: number, total_request: number, cost_human: string}>|null} data
	 * @returns {Promise<void>}
	 */
	async topAgentByCostRefresh(data = null) {
		if (!data) {
			const req = await this.axios({
				method: "POST",
				url   : `${BASE_URL}/admin/dashboard/top-agent-by-cost`,
			})

			data = req.data
		}

		this._renderCostList(this.topAgentByCost, data, "No agent usage this month.")
	}

	// #endregion

	// #region Top User by Cost

	initTopUserByCost() {
		this.topUserByCost = document.querySelector("#top-user-by-cost")

		this._refreshTopUserByCost = this.get("top-user-by-cost-refresh")
		this._refreshTopUserByCost?.on("click", async () => {
			this._refreshTopUserByCost.disabled()
			await this.topUserByCostRefresh()
			setTimeout(() => this._refreshTopUserByCost.enabled(), 2000)
		}, "AdminDashboardAgentAi")
	}

	/**
	 * @param {Array<{name: string, total_token: number, total_request: number, cost_human: string}>|null} data
	 * @returns {Promise<void>}
	 */
	async topUserByCostRefresh(data = null) {
		if (!data) {
			const req = await this.axios({
				method: "POST",
				url   : `${BASE_URL}/admin/dashboard/top-user-by-cost`,
			})

			data = req.data
		}

		this._renderCostList(this.topUserByCost, data, "No user usage this month.")
	}

	// #endregion

	// #region Shared Rendering

	/**
	 * @param {?HTMLElement} el
	 * @param {Array<{name: string, total_token: number, total_request: number, cost_human: string}>} data
	 * @param {string} emptyMessage
	 */
	_renderCostList(el, data, emptyMessage) {
		if (!el) {
			return
		}

		if (data.length === 0) {
			el.innerHTML = `<li class="list-group-item text-center text-muted py-4">${emptyMessage}</li>`
			return
		}

		el.innerHTML = data
			.map(item => `<li class="list-group-item d-flex align-items-center justify-content-between gap-2">
				<span class="fw-medium">${item.name}</span>
				<div class="text-end">
					<div class="fs-12 fw-medium">${item.cost_human}</div>
					<div class="fs-11 text-muted">${item.total_token.toLocaleString("en-US")} tokens &middot; ${item.total_request} req</div>
				</div>
			</li>`)
			.join("")
	}

	// #endregion
}
