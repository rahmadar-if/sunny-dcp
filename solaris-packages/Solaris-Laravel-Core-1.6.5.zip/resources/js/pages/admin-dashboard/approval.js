import SolarPage from "@core-js/solaris/solar/solar-page"

export default class AdminDashboardApproval extends SolarPage {

	// #region Lifecycle

	/**
	 * @param {{series: number[], labels: string[], colors: string[]}} chartData
	 */
	constructor(chartData) {
		super(false)

		this.chartData = chartData

		this.init()
	}

	init() {
		this.initMetric()
		this.initRequestByStatus()
		this.initNeedsAction()
		this.initResolvedHistory()
	}

	// #endregion

	// #region Public API

	/**
	 * @param {Object} data
	 * @returns {Promise<void>}
	 */
	async refresh(data) {
		this._refreshMetric(this.totalPending, data.total_pending)
		this._refreshMetric(this.totalInProgress, data.total_in_progress)
		this._refreshMetric(this.expiringSoon, data.expiring_soon)
		this._refreshMetric(this.expiredUnresolved, data.expired_unresolved)
		this._refreshMetric(this.avgResolveTime, data.avg_resolve_time)

		this.requestByStatusRefresh(data.request_by_status)
		this.needsActionRefresh(data.needs_action)
		this.resolvedHistoryRefresh(data.resolved_history)
	}

	// #endregion

	// #region Metric

	initMetric() {
		this.totalPending      = this.get("total-pending-approval")
		this.totalInProgress   = this.get("total-in-progress-approval")
		this.expiringSoon      = this.get("expiring-soon-approval")
		this.expiredUnresolved = this.get("expired-unresolved-approval")
		this.avgResolveTime    = this.get("avg-resolve-time-approval")

		this.totalPending?.init()
		this.totalInProgress?.init()
		this.expiringSoon?.init()
		this.expiredUnresolved?.init()
		this.avgResolveTime?.init()
	}

	/**
	 * @param {import("@core-js/solaris/metric-dashboard").default} metric
	 * @param {{value: string}} data
	 */
	_refreshMetric(metric, data) {
		if (!metric || !data) {
			return
		}

		metric.setValue(data.value)
	}

	// #endregion

	// #region Request by Status

	initRequestByStatus() {
		const options = {
			series: this.chartData.series,
			labels: this.chartData.labels,
			colors: this.chartData.colors,
			chart: {
				type: "donut",
				height: 260,
			},
			legend: {
				show: false,
			},
			dataLabels: {
				enabled: false,
			},
		}

		this.requestByStatusChart = new ApexCharts(document.querySelector("#request-by-status-chart"), options)
		this.requestByStatusChart.render()

		this.requestByStatusDetail = document.querySelector("#request-by-status-detail")
	}

	/**
	 * @param {{chart: {series: number[], labels: string[], colors: string[]}, detail: Array<{name: string, total: number, color: string, percent: number}>}} data
	 */
	requestByStatusRefresh(data) {
		if (!data) {
			return
		}

		this.requestByStatusChart?.updateOptions({
			series: data.chart.series,
			labels: data.chart.labels,
			colors: data.chart.colors,
		})

		if (this.requestByStatusDetail) {
			this.requestByStatusDetail.innerHTML = data.detail
				.map(item => `<li class="list-group-item d-flex align-items-center gap-2">
					<span class="avatar avatar-sm bg-${item.color}-transparent">
						<i class="ri-circle-fill fs-10 text-${item.color}"></i>
					</span>
					<span class="flex-fill">${item.name}</span>
					<span class="fw-medium">${item.total}</span>
					<span class="fs-12 text-muted text-end" style="min-width: 3rem">${item.percent}%</span>
				</li>`)
				.join("")
		}
	}

	// #endregion

	// #region Needs Action

	initNeedsAction() {
		this.needsAction = document.querySelector("#needs-action")

		this._refreshNeedsAction = this.get("needs-action-refresh")
		this._refreshNeedsAction?.on("click", async () => {
			this._refreshNeedsAction.disabled()
			await this.needsActionRefresh()
			setTimeout(() => this._refreshNeedsAction.enabled(), 2000)
		}, "AdminDashboardApproval")
	}

	/**
	 * @param {Array<{name: string, requester_name: ?string, level_label: string, expires_human: ?string}>|null} data
	 * @returns {Promise<void>}
	 */
	async needsActionRefresh(data = null) {
		if (!data) {
			const req = await this.axios({
				method: "POST",
				url   : `${BASE_URL}/admin/dashboard/needs-action`,
			})

			data = req.data
		}

		if (!this.needsAction) {
			return
		}

		if (data.length === 0) {
			this.needsAction.innerHTML = `<li class="list-group-item text-center text-muted py-4">No approval needs action right now.</li>`
			return
		}

		this.needsAction.innerHTML = data
			.map(item => `<li class="list-group-item">
				<div class="d-flex align-items-center justify-content-between gap-2">
					<div>
						<span class="d-block fw-medium">${item.name ?? "-"}</span>
						<span class="fs-12 text-muted">Requested by ${item.requester_name ?? "-"}</span>
					</div>
					<div class="text-end">
						<span class="badge bg-secondary-transparent text-secondary">Level ${item.level_label}</span>
						<div class="fs-11 text-muted mt-1">${item.expires_human ?? "No expiry"}</div>
					</div>
				</div>
			</li>`)
			.join("")
	}

	// #endregion

	// #region Resolved History

	initResolvedHistory() {
		this.resolvedHistory = document.querySelector("#resolved-history")

		this._refreshResolvedHistory = this.get("resolved-history-refresh")
		this._refreshResolvedHistory?.on("click", async () => {
			this._refreshResolvedHistory.disabled()
			await this.resolvedHistoryRefresh()
			setTimeout(() => this._refreshResolvedHistory.enabled(), 2000)
		}, "AdminDashboardApproval")
	}

	/**
	 * @param {Array<{name: string, requester_name: ?string, status_name: string, status_color: string, resolved_at_human: ?string, duration_human: string}>|null} data
	 * @returns {Promise<void>}
	 */
	async resolvedHistoryRefresh(data = null) {
		if (!data) {
			const req = await this.axios({
				method: "POST",
				url   : `${BASE_URL}/admin/dashboard/resolved-history`,
			})

			data = req.data
		}

		if (!this.resolvedHistory) {
			return
		}

		if (data.length === 0) {
			this.resolvedHistory.innerHTML = `<li class="list-group-item text-center text-muted py-4">No resolved approval yet.</li>`
			return
		}

		this.resolvedHistory.innerHTML = data
			.map(item => `<li class="list-group-item">
				<div class="d-flex align-items-center justify-content-between gap-2">
					<div>
						<span class="d-block fw-medium">${item.name ?? "-"}</span>
						<span class="fs-12 text-muted">Requested by ${item.requester_name ?? "-"}</span>
					</div>
					<div class="text-end">
						<span class="badge bg-${item.status_color}-transparent text-${item.status_color}">${item.status_name}</span>
						<div class="fs-11 text-muted mt-1">${item.resolved_at_human ?? "-"} &middot; ${item.duration_human}</div>
					</div>
				</div>
			</li>`)
			.join("")
	}

	// #endregion
}
