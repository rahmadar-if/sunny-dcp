import SolarPage from "@core-js/solaris/solar/solar-page"

export default class AdminDashboardUsersSessions extends SolarPage {

	// #region Lifecycle

	/**
	 * @param {{series: number[], labels: string[], colors: string[]}} chartData
	 */
	constructor(chartData) {
		super(false)

		this.chartData = chartData

		this.init()
	}

	init() {
		this.initMetric()
		this.initDistributionChart()
	}

	// #endregion

	// #region Public API

	/**
	 * @param {Object} data
	 * @returns {Promise<void>}
	 */
	async refresh(data) {
		this._refreshMetric(this.totalUser, data.total_user)
		this._refreshMetric(this.activeUser, data.active_user)
		this._refreshMetric(this.unverifiedUser, data.unverified_user)
		this._refreshMetric(this.nonActiveUser, data.non_active_user)

		this.distributionRefresh(data.user_distribution)
	}

	// #endregion

	// #region Metric

	initMetric() {
		this.totalUser      = this.get("total-user")
		this.activeUser     = this.get("active-user")
		this.unverifiedUser = this.get("unverified-user")
		this.nonActiveUser  = this.get("non-active-user")

		this.totalUser?.init()
		this.activeUser?.init()
		this.unverifiedUser?.init()
		this.nonActiveUser?.init()
	}

	/**
	 * @param {import("@core-js/solaris/metric-dashboard").default} metric
	 * @param {{value: string}} data
	 */
	_refreshMetric(metric, data) {
		if (!metric || !data) {
			return
		}

		metric.setValue(data.value)
	}

	// #endregion

	// #region Distribution Chart

	initDistributionChart() {
		const options = {
			series: this.chartData.series,
			labels: this.chartData.labels,
			colors: this.chartData.colors,
			chart: {
				type: "donut",
				height: 260,
			},
			legend: {
				show: false,
			},
			dataLabels: {
				enabled: false,
			},
		}

		this.distributionChart = new ApexCharts(document.querySelector("#user-distribution-chart"), options)
		this.distributionChart.render()

		this.distributionDetail = document.querySelector("#user-distribution-detail")

		this._refreshDistribution = this.get("user-distribution-refresh")
		this._refreshDistribution?.on("click", async () => {
			this._refreshDistribution.disabled()
			await this.distributionRefresh()
			setTimeout(() => this._refreshDistribution.enabled(), 2000)
		}, "AdminDashboardUsersSessions")
	}

	/**
	 * @param {{chart: {series: number[], labels: string[], colors: string[]}, detail: Array<{name: string, total: number, percent: number, color: string, icon: string}>}|null} data
	 * @returns {Promise<void>}
	 */
	async distributionRefresh(data = null) {
		if (!data) {
			const req = await this.axios({
				method: "POST",
				url   : `${BASE_URL}/admin/dashboard/user-distribution`,
			})

			data = req.data
		}

		this.distributionChart?.updateOptions({
			series: data.chart.series,
			labels: data.chart.labels,
			colors: data.chart.colors,
		})

		if (this.distributionDetail) {
			this.distributionDetail.innerHTML = data.detail
				.map(category => this._renderDistributionDetail(category))
				.join("")
		}
	}

	/**
	 * @param {{name: string, total: number, percent: number, color: string, icon: string}} category
	 * @returns {string}
	 */
	_renderDistributionDetail(category) {
		return `<li class="list-group-item d-flex align-items-center gap-2">
			<span class="avatar avatar-sm bg-${category.color}-transparent">
				<i class="${category.icon} text-${category.color}"></i>
			</span>
			<span class="flex-fill">${category.name}</span>
			<span class="fw-medium">${category.total}</span>
			<span class="fs-12 text-muted text-end" style="min-width: 3rem">${category.percent}%</span>
		</li>`
	}

	// #endregion
}
