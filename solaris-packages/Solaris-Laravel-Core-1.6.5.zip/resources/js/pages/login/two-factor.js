import SolarPage from "@core-js/solaris/solar/solar-page"
import Form from "@core-js/solaris/form/form"
import OtpInput from "@core-js/solaris/form/otp-input"

export default class TwoFactorPage extends SolarPage {
    init() {
        /** @type { Form } */
        const form = this.get("login-2fa")

        /** @type { OtpInput } */
        const otp = this.get("login-otp")

        if (TWO_FACTOR_METHOD === 'email') {
            otp.on('resend', () => {
                this.helper.successAlert({ title: 'Code resent to your email', timeout: 3000 })
            })
            .startResendTimer()
        }

        otp.focus()
        otp.on('change', (code) => {
            if (code.length === otp.length) {
                form
                    .addData("code", otp.get())
                    .submit()
            }
        })

        form
            .hiddenSuccessAlert()
            .hiddenErrorAlert()
            .addData("code", otp.get())
            .on("success", (response) => {
                form.disabled()
                window.location = response.redirect
            }, "TwoFactorPage")
            .on("failed", (response) => {
                otp.setMessage(response.code ?? 'Invalid code')
            }, "TwoFactorPage")
            .on("error", (response) => {
                if (response?.locked) {
                    window.location = LOGIN_ROUTE
                    return
                }

                otp.setMessage(response.message ?? 'Invalid code')
            }, "TwoFactorPage")
    }
}
