import LoginPage from "./page"

new LoginPage()