import SolarPage from "@core-js/solaris/solar/solar-page"
import Button from "@core-js/solaris/button"
import Form from "@core-js/solaris/form/form"

export default class LoginPage extends SolarPage {
    // #region Lifecycle
    init() {
        const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone

        /** @type { Form } */
        this.form = this.get("login")

        /** @type { Button } */
        this.google = this.get("google")

        this.google?.on("click", () => {
            const url       = this.google._element.getAttribute('data-url')
            const params    = new URLSearchParams({ timezone })
            window.location = `${url}?${params.toString()}`
        }, "LoginPage")

        this.form
            .hiddenSuccessAlert()
            .hiddenErrorAlert()
            .addData("timezone", timezone)
            .on("success", (response) => {
                this.helper.clearCacheBySuffix(["_table_cache"])
                this.form.disabled()
                window.location = response.redirect
            }, "LoginPage")
            .on("error", (response) => {
                if (response?.locked && response?.locked_until) {
                    this._applyLockout(response.locked_until)
                    return
                }

                if (this.helper.isObject(response) && response.hasOwnProperty("redirect")) {
                    this.form.disabled()
                    window.location = response.redirect
                }
            }, "LoginPage")

        this._initLockout()
    }
    // #endregion

    // #region Lockout
    /**
     * @returns {void}
     */
    _initLockout() {
        if (!AUTH_LOCKED_UNTIL || new Date(AUTH_LOCKED_UNTIL) <= new Date()) {
            return
        }

        this._applyLockout(AUTH_LOCKED_UNTIL)
    }

    /**
     * @param {string} lockedUntil - ISO 8601 datetime string from server
     * @returns {void}
     */
    _applyLockout(lockedUntil) {
        const until     = new Date(lockedUntil)
        const notice    = document.getElementById('lockout-notice')
        const countdown = document.getElementById('lockout-countdown')

        this.form
            .nonactive()
            .disabled()

        this.google?.disabled()
        notice?.classList.remove('d-none')

        const tick = () => {
            const remaining = Math.max(0, until - Date.now())
            const totalSecs = Math.ceil(remaining / 1000)
            const mins      = Math.floor(totalSecs / 60)
            const secs      = totalSecs % 60

            if (countdown) {
                countdown.textContent = mins > 0
                    ? `${mins}m ${secs}s`
                    : `${totalSecs}s`
            }

            if (remaining > 0) {
                return
            }

            clearInterval(this._lockTimer)
            
            this.form
                .active()
                .enabled()

            this.google?.enabled()
            notice?.classList.add('d-none')
        }

        clearInterval(this._lockTimer)
        this._lockTimer = setInterval(tick, 1000)
        tick()
    }
    // #endregion
}
