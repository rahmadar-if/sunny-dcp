import TwoFactorPage from "./two-factor"

new TwoFactorPage()