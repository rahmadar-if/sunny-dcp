import ForgotPasswordPage from "./page"

new ForgotPasswordPage()