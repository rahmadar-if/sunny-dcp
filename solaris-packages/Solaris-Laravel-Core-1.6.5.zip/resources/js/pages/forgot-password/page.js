import SolarPage from "@core-js/solaris/solar/solar-page"

export default class ForgotPasswordPage extends SolarPage {
    init() {
        const form = this.get("forgot-password")
        const submit = this.get("forgot-password-submit")
        const email = form.get("email")

        const disabled = (timeout = 30 * 1000) => {
            email.reset(true)
            submit.disabled()

            setTimeout(() => email.disabled(), 0)

            setTimeout(() => {
                submit.enabled()
                email.enabled()
            }, timeout)
        }

        form
            .hiddenSuccessAlert()
            .on("success", (response) => {
                disabled()
                this.helper.successAlert({ title: response.message })
            }, "ForgotPasswordPage")
            .on("error", (response) => {
                disabled()
                this.helper.errorAlert({ title: response.message })
            }, "ForgotPasswordPage")
    }
}