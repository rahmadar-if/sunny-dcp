import { PermissionType, RightLevel } from "../../const"
import Button from "../../solaris/button"
import Form from "../../solaris/form/form"
import ModalForm from "../../solaris/modal-form"
import Model from "../../solaris/model"
import SolarPage from "../../solaris/solar/solar-page"

export default class BaseRule extends SolarPage {

    constructor(selector, model, objectPermissionId, code) {
        super(false)

        this.selector = selector
        this.model = model
        this.objectPermissionId = objectPermissionId
        this.code = code

        this.rules = []
        this._dragSrc = null

        this.init()
    }

    init() {
        /** @type {ModalForm} */
        this.modalForm = this.get(`${this.selector}-modal_ModalForm`)

        this.modal = this.modalForm.modal
        this.modal.on("show", () => {
            this.preview.innerHTML = ''

            this.form.addData("code", this.code)
            this.form.addData("object_permission_id", this.objectPermissionId)
        })

        this.form = this.modalForm.form
        this.form
            .on("submitting", () => {
                const rules = this.getRules()
                this.form.addData("rules", rules)
            })
            .on("success", () => this.refresh())

        this.preview = this.modal._element.querySelector(".rule-preview")

        /** @type {Button} */
        this.addRuleBtn = this.get(`${this.selector}-new`)
        this.addRuleBtn.on("click", () => this.new())

        /** @type {Button} */
        this.refreshBtn = this.get(`${this.selector}-refresh`)
        this.refreshBtn.on("click", () => this.refresh())

        this.container = document.querySelector(`#${this.selector}-list`)
        this.emptyState = document.querySelector(`#${this.selector}-empty-state`)

        this.refresh()
    }

    // ─── Actions ─────────────────────────────────────────────────────────────

    new() {
        this.modalForm.new()
    }

    async edit(id) {
        await this.modalForm.edit(id, this.onEdit.bind(this))
    }

    async delete(id) {
        const deleted = await Model.delete(this.model, id, { success: "", loading: false })
        if (!deleted) {
            return
        }

        this.rules = this.rules.filter(r => r.id !== id)

        this._renderCards()
    }

    // ─── Load & Refresh ───────────────────────────────────────────────────────

    async refresh() {
        this.helper.loadingPage(true)
        try {
            this.rules = await this._fetchData()
            this._renderCards()
        } catch (error) {
            console.error({ error })
        } finally {
            this.helper.loadingPage(false)
        }
    }

    async _fetchData() {
        try {
            const res = await this.axios({
                method: "GET",
                url: `${BASE_URL}/admin/access-right/${this.type}-rule/${this.objectPermissionId}`
            })
            const raw = res.data?.data ?? res.data

            return Array.isArray(raw) ? raw : []
        } catch (_) {
            return []
        }
    }

    // ─── Render ──────────────────────────────────────────────────────────────

    _renderCards() {
        if (this.rules.length > 0) {
            this.emptyState.classList.add("d-none")
            const rows = this.rules.map((rule, i) => this._ruleCard(rule, i)).join("")
            this.container.innerHTML = `<div class="rule-list">${rows}</div>`
            this._bindCardEvents()
            this._initDropPlaceholder(this.container.querySelector(".rule-list"))
        } else {
            this.emptyState.classList.remove("d-none")
            this.container.innerHTML = ""
        }
    }

    _ruleCard(rule, index) {
        const granteeType = rule.grantee_type
        const grantee = this._getEntity(rule, 'grantee')

        const operationsHtml = rule.details.map(d => {
            const checked = d.level_id == RightLevel.Grant
            return `<div class="form-check form-switch form-check-inline">
                <input class="form-check-input rule-op-checkbox" type="checkbox" id="op-${rule.id}-${d.operation_id}"
                    data-rule-id="${rule.id}" data-op-id="${d.operation_id}" ${checked ? 'checked' : ''}>
                <label class="form-check-label" for="op-${rule.id}-${d.operation_id}">${d.operation.name}</label>
            </div>`
        }).join("")

        return `<div class="card custom-card rule-card d-flex flex-row align-items-center gap-3 py-2 px-3" data-id="${rule.id}">
            <span class="drag-handle text-muted flex-shrink-0" style="cursor:grab;line-height:1" title="Drag to reorder" draggable="true">
                <i class="ti ti-grip-vertical fs-16"></i>
            </span>
            <span class="badge bg-primary-transparent text-primary flex-shrink-0">#${index + 1}</span>
            <span class="fw-medium flex-grow-1">${granteeType.name} · ${grantee.name}</span>
            <div class="d-flex gap-1 flex-shrink-0">${operationsHtml}</div>
            <div class="dropdown flex-shrink-0">
                <button type="button" class="btn btn-sm btn-light" data-bs-toggle="dropdown" aria-expanded="false"><i class="ri-more-fill"></i></button>
                <ul class="dropdown-menu dropdown-menu-end shadow-sm">
                    <li><a class="dropdown-item rule-edit-btn" href="javascript:void(0);" data-id="${rule.id}"><i class="ri-pencil-line me-1"></i>Edit</a></li>
                    <li><a class="dropdown-item text-danger rule-delete-btn" href="javascript:void(0);" data-id="${rule.id}"><i class="ri-delete-bin-fill me-1"></i>Delete</a></li>
                </ul>
            </div>
        </div>`
    }

    _bindCardEvents() {
        this.container.querySelectorAll(".rule-card").forEach(card => {
            const handle = card.querySelector(".drag-handle")

            handle.addEventListener("dragstart", e => this._onDragStart(e, card))
            handle.addEventListener("dragend", () => this._onDragEnd())

            card.addEventListener("dragover", e => this._onDragOver(e, card))
            card.addEventListener("dragleave", e => this._onDragLeave(e, card))
            card.addEventListener("drop", e => this._onDrop(e, card))

            this._bindOperationCheckboxes(card)
        })

        this.container.querySelectorAll(".rule-edit-btn").forEach(btn => {
            btn.addEventListener("click", e => {
                e.stopPropagation()
                this.edit(btn.dataset.id)
            })
        })

        this.container.querySelectorAll(".rule-delete-btn").forEach(btn => {
            btn.addEventListener("click", e => {
                e.stopPropagation()
                this.delete(btn.dataset.id)
            })
        })
    }

    _bindOperationCheckboxes(card) {
        const ruleId = card.dataset.id
        const rule = this.rules.find(r => `${r.id}` === ruleId)
        if (!rule) return

        let debounceTimer = null

        card.querySelectorAll(".rule-op-checkbox").forEach(checkbox => {
            checkbox.addEventListener("change", () => {
                const opId = checkbox.dataset.opId
                const detail = rule.details.find(d => `${d.operation_id}` === `${opId}`)
                if (detail) {
                    detail.level_id = checkbox.checked ? RightLevel.Grant : RightLevel.Deny
                }

                clearTimeout(debounceTimer)
                debounceTimer = setTimeout(() => {
                    const operations = rule.details.map(d => ({
                        operation_id: d.operation_id,
                        level_id: d.level_id
                    }))
                    this._updateRuleOperation(rule.id, operations)
                }, 800)
            })
        })
    }

    _getEntity(rule, prefix = 'grantee') {
        const type = rule[`${prefix}_type`]
        if (!type) return null

        switch (type.id) {
            case PermissionType.Role: return rule[`role_${prefix}`]
            case PermissionType.Permission: return rule[`permission_${prefix}`]
            case PermissionType.User:
            default: return rule[`user_${prefix}`]
        }
    }

    updateSelector(type, field) {
        if (!type) {
            field.reset()
            field.disabled()
            return
        }

        let config = {}
        field.reset()

        if (type.id == PermissionType.Role) {
            config = { placeholder: "Choose Role", source: "Role", pagination: true }
        } else if (type.id == PermissionType.Permission) {
            config = { placeholder: "Choose Permission", source: "Permission", pagination: true }
        } else if (type.id == PermissionType.User) {
            config = { placeholder: "Choose User", source: "User", pagination: true }
        }

        field._plugin.init(config)
        field.on("change", () => this.updatePreview())
        field.enabled()
    }

    getRules() {
        return this.form.get("operations")._options.map(op => {
            return {
                operation_id: op._element.value,
                level_id: op.get() ? RightLevel.Grant : RightLevel.Deny
            }
        })
    }

    async _updateRuleOperation(ruleId, operations) {
        try {
            await this.axios({
                method: "PUT",
                url: `${BASE_URL}/admin/access-right/${this.type}-rule/operation/${ruleId}`,
                data: {
                    code: this.code,
                    rules: operations
                }
            })
        } catch (e) {
            console.error({ e })
            this.helper.toast({ message: "Update rule failed" })
        }
    }

    // ─── Drag & Drop ─────────────────────────────────────────────────────────

    _initDropPlaceholder(container) {
        const existing = container.querySelector(".rule-drop-placeholder")
        if (existing) existing.remove()

        const placeholder = document.createElement("div")
        placeholder.className = "rule-drop-placeholder border-top border-dashed border-primary text-center text-muted fs-13 py-2 px-3"
        placeholder.textContent = "Drop here to move to end"

        placeholder.addEventListener("dragover", e => {
            e.preventDefault()
            placeholder.classList.add("bg-primary-transparent", "text-primary")
        })
        placeholder.addEventListener("dragleave", () => {
            placeholder.classList.remove("bg-primary-transparent", "text-primary")
        })
        placeholder.addEventListener("drop", e => {
            e.preventDefault()
            placeholder.classList.remove("bg-primary-transparent", "text-primary")

            const srcId = e.dataTransfer.getData("text/plain")
            if (!srcId) return

            const srcCard = this.container.querySelector(`.rule-card[data-id="${srcId}"]`)
            if (!srcCard) return

            if (srcCard.parentNode !== container) {
                return
            }

            placeholder.before(srcCard)

            this._updateBadges(container)

            const newRuleCards = Array.from(container.querySelectorAll(".rule-card"))
            const newIdx = newRuleCards.indexOf(srcCard)

            const newPriority = this._calcNewPriority(newRuleCards, newIdx)

            const rule = this.rules.find(r => `${r.id}` === srcId)
            if (rule) rule.priority = newPriority

            this._updatePriority(srcId, newPriority)
        })

        container.appendChild(placeholder)
    }

    _onDragStart(e, card) {
        this._dragSrc = card
        e.dataTransfer.effectAllowed = "move"
        e.dataTransfer.setData("text/plain", card.dataset.id)

        const rect = card.getBoundingClientRect()
        e.dataTransfer.setDragImage(card, e.clientX - rect.left, e.clientY - rect.top)

        setTimeout(() => card.classList.add("opacity-50"), 0)
    }

    _onDragOver(e, card) {
        e.preventDefault()
        if (!this._dragSrc || card === this._dragSrc) return

        if (card !== this._lastDragTarget) {
            this._clearDropIndicators()
            card.classList.add("drop-target")
            this._lastDragTarget = card
        }
    }

    _onDragLeave(e, card) {
        if (!card.contains(e.relatedTarget)) {
            card.classList.remove("drop-target")
            if (this._lastDragTarget === card) {
                this._lastDragTarget = null
            }
        }
    }

    _onDrop(e, targetCard) {
        e.preventDefault()
        this._clearDropIndicators()

        const srcId = e.dataTransfer.getData("text/plain")
        const tgtId = targetCard.dataset.id
        if (!srcId || srcId === tgtId) return

        const srcIdx = this.rules.findIndex(r => `${r.id}` === srcId)
        const tgtIdx = this.rules.findIndex(r => `${r.id}` === tgtId)
        if (srcIdx < 0 || tgtIdx < 0) return

        const [moved] = this.rules.splice(srcIdx, 1)
        const adjustedTgtIdx = this.rules.findIndex(r => `${r.id}` === tgtId)
        const insertIdx = srcIdx < tgtIdx ? adjustedTgtIdx + 1 : adjustedTgtIdx
        this.rules.splice(insertIdx, 0, moved)

        const srcCard = this.container.querySelector(`.rule-card[data-id="${srcId}"]`)
        if (srcIdx < tgtIdx) {
            targetCard.after(srcCard)
        } else {
            targetCard.before(srcCard)
        }

        this._updateBadges(this.container)

        const newRuleCards = Array.from(this.container.querySelectorAll(".rule-card"))
        const domIdx = newRuleCards.indexOf(srcCard)

        const newPriority = this._calcNewPriority(newRuleCards, domIdx)
        moved.priority = newPriority
        this._updatePriority(srcId, newPriority)
    }

    _onDragEnd() {
        this._dragSrc?.classList.remove("opacity-50")
        this._clearDropIndicators()
        this._dragSrc = null
        this._lastDragTarget = null
    }

    _clearDropIndicators() {
        this.container.querySelectorAll(".drop-target").forEach(el => {
            el.classList.remove("drop-target")
        })
    }

    _updateBadges(container) {
        container.querySelectorAll(".rule-card .badge.bg-primary-transparent").forEach((badge, i) => {
            badge.textContent = `#${i + 1}`
        })
    }

    _calcNewPriority(ruleCards, newIndex) {
        const GAP = 1000
        const prevCard = ruleCards[newIndex - 1]
        const nextCard = ruleCards[newIndex + 1]

        const prevId = prevCard ? prevCard.dataset.id : null
        const nextId = nextCard ? nextCard.dataset.id : null

        const prevRule = prevId ? this.rules.find(r => `${r.id}` === prevId) : null
        const nextRule = nextId ? this.rules.find(r => `${r.id}` === nextId) : null

        if (!prevRule && !nextRule) return GAP
        if (!prevRule) return Math.floor((nextRule.priority ?? GAP) / 2)
        if (!nextRule) return (prevRule.priority ?? 0) + GAP

        return Math.floor(((prevRule.priority ?? 0) + (nextRule.priority ?? 0)) / 2)
    }

    async _updatePriority(ruleId, priority) {
        try {
            await this.axios({
                method: "PUT",
                url: `${BASE_URL}/admin/access-right/${this.type}-rule/priority/${ruleId}`,
                data: {
                    code: this.code,
                    priority
                }
            })
        } catch (e) {
            console.error({ e })
            this.helper.toast({ message: "Reorder priority failed" })
        }
    }

    // ─── Abstract (implement in subclass) ─────────────────────────────────────

    get type() { throw new Error(`${this.constructor.name}: type getter must be implemented`) }

    /**
     * @param {Object} rule
     * @param {string} allowOperation
     * @param {string} deniedOperation
     * @returns {string}
     */
    getPreviewTextFromRule(rule, allowOperation, deniedOperation) { throw new Error(`${this.constructor.name}: getPreviewTextFromRule() must be implemented`) }

    updatePreview() { throw new Error(`${this.constructor.name}: updatePreview() must be implemented`) }

    /**
     * @param {Form} form
     * @param {*} data
     */
    onEdit(form, data) { throw new Error(`${this.constructor.name}: onEdit() must be implemented`) }
}
