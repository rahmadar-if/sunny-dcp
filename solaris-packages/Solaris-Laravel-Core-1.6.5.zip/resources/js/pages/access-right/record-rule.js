import { PermissionType, RightLevel } from "../../const"
import BaseRule from "./base-rule"

export default class RecordRule extends BaseRule {

    constructor(objectPermissionId, code) {
        super("record-rule", "RecordRule", objectPermissionId, code)
    }

    get type() {
        return "record"
    }

    init() {
        super.init()

        const ownerType = this.form.get("owner_type_id")
        const owner = this.form.get("owner_id")
        const granteeType = this.form.get("grantee_type_id")
        const grantee = this.form.get("grantee_id")
        const operations = this.form.get("operations")

        ownerType.on("change", (val) => {
            this.updatePreview()
            this.updateSelector(val, owner)
        })

        granteeType.on("change", (val) => {
            this.updatePreview()
            this.updateSelector(val, grantee)
        })

        operations.on("change", (val) => this.updatePreview())

        this.form.exclude("operations")

        this.modal
            .on("show", () => operations.reset(true))
            .on("hide", () => {
                owner.disabled()
                grantee.disabled()
            })
    }

    _buildPreviewText(ownerType, owner, granteeType, grantee, allowOperation, deniedOperation) {
        if (this.helper.isEmpty(ownerType) || this.helper.isEmpty(owner) || this.helper.isEmpty(granteeType) || this.helper.isEmpty(grantee)) {
            return ''
        }

        let preview = ''
        const granteeText = `${granteeType}: ${grantee}`
        const ownerText = `${ownerType}: ${owner}`
        const allowedText = `<span class="text-success fw-medium">is allowed to</span>`
        const deniedText = `<span class="text-danger fw-medium">is denied from</span>`

        if (this.helper.isEmpty(allowOperation)) {
            preview = `${granteeText} ${deniedText} perform <span class="fw-medium">${deniedOperation}</span> on records owned by <span class="fw-medium">${ownerText}</span>`
        } else if (this.helper.isEmpty(deniedOperation)) {
            preview = `${granteeText} ${allowedText} perform <span class="fw-medium">${allowOperation}</span> on records owned by <span class="fw-medium">${ownerText}</span>`
        } else {
            preview = `${granteeText} ${allowedText} perform <span class="fw-medium">${allowOperation}</span> and ${deniedText} perform <span class="fw-medium">${deniedOperation}</span> on records owned by <span class="fw-medium">${ownerText}</span>`
        }

        return preview
    }

    getPreviewTextFromRule(rule, allowOperation, deniedOperation) {
        const ownerType = rule.owner_type
        const owner = this._getEntity(rule, 'owner')
        const granteeType = rule.grantee_type
        const grantee = this._getEntity(rule, 'grantee')
        return this._buildPreviewText(ownerType?.name, owner?.name, granteeType?.name, grantee?.name, allowOperation, deniedOperation)
    }

    updatePreview() {
        const ownerType = this.form.get("owner_type_id")
        const owner = this.form.get("owner_id")
        const granteeType = this.form.get("grantee_type_id")
        const grantee = this.form.get("grantee_id")

        const operations = this.form.get("operations")
        const operation_options = operations._options
        const allowedOperation = `${operation_options.filter(op => op.get()).map(op => op._label.textContent).join(", ")}`
        const deniedOperation = `${operation_options.filter(op => !op.get()).map(op => op._label.textContent).join(", ")}`

        this.preview.innerHTML = this._buildPreviewText(
            ownerType.get()?.name,
            owner.get()?.name,
            granteeType.get()?.name,
            grantee.get()?.name,
            allowedOperation,
            deniedOperation
        )
    }

    onEdit(form, data) {
        this.updateSelector(data.owner_type, this.form.get("owner_id"))
        this.updateSelector(data.grantee_type, this.form.get("grantee_id"))

        this.form.set("owner_id", this._getEntity(data, 'owner'))
        this.form.set("grantee_id", this._getEntity(data, 'grantee'))

        const operationValue = data.details
            .filter(d => d.level_id == RightLevel.Grant)
            .map(d => d.operation_id)

        this.form.set("operations", operationValue)
    }

    async refresh() {
        this.helper.loadingPage(true)
        try {
            const rawData = await this._fetchData()

            this.groupedData = rawData
            this.rules = rawData.flatMap(g => g.rules)

            this._renderCards()
        } catch (error) {
            console.error({ error })
        } finally {
            this.helper.loadingPage(false)
        }
    }

    async delete(id) {
        await super.delete(id)

        this.groupedData = this.groupedData.map(group => ({
            ...group,
            rules: group.rules.filter(r => r.id !== id)
        })).filter(group => group.rules.length > 0)

        this._renderCards()
    }

    _renderCards() {
        if (this.rules.length > 0) {
            this.emptyState.classList.add("d-none")
            this.container.innerHTML = this.groupedData.map(group => this._groupCard(group)).join("")
            this._bindCardEvents()
            this.container.querySelectorAll(".group-rules").forEach(groupContainer => {
                this._initDropPlaceholder(groupContainer)
            })
        } else {
            this.emptyState.classList.remove("d-none")
            this.container.innerHTML = ""
        }
    }

    _groupCard(group) {
        const ownerType = group.owner_type
        const owner = group.owner
        const count = group.rules.length

        return `
        <div class="rule-group mb-4" data-group="${ownerType.id}_${owner.id}">
            <div class="d-flex align-items-center gap-2 mb-2">
                <i class="ri-database-2-line text-muted fs-16"></i>
                <span class="text-muted fs-13">Records owned by</span>
                <span class="fw-semibold text-primary">${ownerType.name} · ${owner.name}</span>
                <span class="badge bg-secondary-transparent text-secondary ms-auto">${count} rule${count !== 1 ? 's' : ''}</span>
            </div>
            <div class="group-rules rule-list">
                ${group.rules.map((rule, i) => this._ruleCard(rule, i)).join("")}
            </div>
        </div>
        `
    }

    _ruleCard(rule, index) {
        const granteeType = rule.grantee_type
        const grantee = this._getEntity(rule, 'grantee')

        const operationsHtml = rule.details.map(d => {
            const checked = d.level_id == RightLevel.Grant
            return `<div class="form-check form-switch form-check-inline">
                <input class="form-check-input rule-op-checkbox" type="checkbox" id="op-${rule.id}-${d.operation_id}"
                    data-rule-id="${rule.id}" data-op-id="${d.operation_id}" ${checked ? 'checked' : ''}>
                <label class="form-check-label" for="op-${rule.id}-${d.operation_id}">${d.operation.name}</label>
            </div>`
        }).join("")

        return `<div class="card custom-card rule-card d-flex flex-row align-items-center gap-3 py-2 px-3" data-id="${rule.id}">
            <span class="drag-handle text-muted flex-shrink-0" style="cursor:grab;line-height:1" title="Drag to reorder" draggable="true">
                <i class="ti ti-grip-vertical fs-16"></i>
            </span>
            <span class="badge bg-primary-transparent text-primary flex-shrink-0">#${index + 1}</span>
            <span class="fw-medium flex-grow-1">${granteeType.name} · ${grantee.name}</span>
            <div class="d-flex gap-1 flex-shrink-0">${operationsHtml}</div>
            <div class="dropdown flex-shrink-0">
                <button type="button" class="btn btn-sm btn-light" data-bs-toggle="dropdown" aria-expanded="false"><i class="ri-more-fill"></i></button>
                <ul class="dropdown-menu dropdown-menu-end shadow-sm">
                    <li><a class="dropdown-item rule-edit-btn" href="javascript:void(0);" data-id="${rule.id}"><i class="ri-pencil-line me-1"></i>Edit</a></li>
                    <li><a class="dropdown-item text-danger rule-delete-btn" href="javascript:void(0);" data-id="${rule.id}"><i class="ri-delete-bin-fill me-1"></i>Delete</a></li>
                </ul>
            </div>
        </div>`
    }

    _onDragOver(e, card) {
        e.preventDefault()
        if (!this._dragSrc || card === this._dragSrc) return

        if (card.parentNode !== this._dragSrc.parentNode) return

        if (card !== this._lastDragTarget) {
            this._clearDropIndicators()
            card.classList.add("drop-target")
            this._lastDragTarget = card
        }
    }

    _onDrop(e, targetCard) {
        e.preventDefault()
        this._clearDropIndicators()

        const srcId = e.dataTransfer.getData("text/plain")
        const tgtId = targetCard.dataset.id
        if (!srcId || srcId === tgtId) return

        const srcCard = this.container.querySelector(`.rule-card[data-id="${srcId}"]`)

        if (srcCard.parentNode !== targetCard.parentNode) {
            return
        }

        const groupContainer = targetCard.parentNode
        const ruleCards = Array.from(groupContainer.querySelectorAll(".rule-card"))

        const srcIdx = ruleCards.indexOf(srcCard)
        const tgtIdx = ruleCards.indexOf(targetCard)
        if (srcIdx < 0 || tgtIdx < 0) return

        if (srcIdx < tgtIdx) {
            targetCard.after(srcCard)
        } else {
            targetCard.before(srcCard)
        }

        this._updateBadges(groupContainer)

        const newRuleCards = Array.from(groupContainer.querySelectorAll(".rule-card"))
        const newIdx = newRuleCards.indexOf(srcCard)

        const newPriority = this._calcNewPriority(newRuleCards, newIdx)

        const rule = this.rules.find(r => `${r.id}` === srcId)
        if (rule) rule.priority = newPriority

        this._updatePriority(srcId, newPriority)
    }
}
