import SolarEditPage from "@core-js/solaris/solar/solar-edit-page"
import ObjectRule from "./object-rule"
import RecordRule from "./record-rule"

export default class AccessRightPage extends SolarEditPage {

    init() {
        const tableCode = this.form.get("code").get()

        this.objectRule = new ObjectRule(this.id, tableCode)
        this.recordRule = new RecordRule(this.id, tableCode)
    }

    async onRefreshed(data) {
        const tableCode = data.code?.id ?? data.code

        this.breadcrumbName.textContent = tableCode
        this.form.set("code", tableCode)

        await Promise.all([
            this.objectRule.refresh(),
            this.recordRule.refresh()
        ])
    }
}