import SolarListPage from "@core-js/solaris/solar/solar-list-page";

export default class AccessRightListPage extends SolarListPage {
    init() {
        this.columnRender("object_permission", this.activeColumnRender.bind(this))
        this.columnRender("record_permission", this.activeColumnRender.bind(this))
        this.columnRender("rules", this.rulesColumnRender.bind(this))

        this.initModal()
    }

    initModal() {
        const objPermission = this.form.get("object_permission")
        const recPermission = this.form.get("record_permission")

        this.modal
            .on("show", () => {
                if (!this.form.isEdit()) {
                    objPermission.set(true, true)
                    recPermission.set(true, true)
                }
            })
    }

    openEditPage(id) {
        this.helper.loadingPage(true)
        window.location = `${BASE_URL}/admin/access-right/edit/${id}`
    }

    rowDoubleClick(row, data) {
        this.openEditPage(data.id)
    }

    async view(row, data) {
        this.openEditPage(data.id)
    }

    activeColumnRender(data, rowData) {
        return `<span class="badge bg-${data ? 'success' : 'danger'}">${data ? 'Active' : 'Off'}</span>`
    }

    rulesColumnRender(data, rowData) {
        const objRules = `<span class="badge bg-secondary">${rowData.object_rule_total ?? 0} object rules</span>`
        const recordRules = `<span class="badge bg-info">${rowData.record_rule_total ?? 0} record rules</span>`

        return `<div class="d-flex align-items-center gap-1">
            ${objRules}
            ${recordRules}
        </div>`
    }
}