import AccessRightPage from "./page"

new AccessRightPage()