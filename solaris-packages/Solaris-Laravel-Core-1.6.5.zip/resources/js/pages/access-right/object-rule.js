import { PermissionType, RightLevel } from "../../const"
import BaseRule from "./base-rule"

export default class ObjectRule extends BaseRule {

    constructor(objectPermissionId, code) {
        super("object-rule", "ObjectRule", objectPermissionId, code)
    }

    get type() {
        return "object"
    }

    init() {
        super.init()

        const type = this.form.get("grantee_type_id")
        const grantee = this.form.get("grantee_id")
        const operations = this.form.get("operations")

        type.on("change", (val) => {
            this.updatePreview()
            this.updateSelector(val, grantee)
        })

        operations.on("change", (val) => this.updatePreview())

        this.form.exclude("operations")

        this.modal
            .on("show", () => operations.reset(true))
            .on("hide", () => grantee.disabled())
    }

    _buildPreviewText(type, grantee, allowOperation, deniedOperation) {
        if (this.helper.isEmpty(type) || this.helper.isEmpty(grantee)) {
            return ''
        }

        let preview = ''
        const whoText = `${type}: ${grantee}`
        const allowedText = `<span class="text-success fw-medium">is allowed to</span>`
        const deniedText = `<span class="text-danger fw-medium">is denied from</span>`

        if (this.helper.isEmpty(allowOperation)) {
            preview = `${whoText} ${deniedText} perform <span class="fw-medium">${deniedOperation}</span> on this table`
        } else if (this.helper.isEmpty(deniedOperation)) {
            preview = `${whoText} ${allowedText} perform <span class="fw-medium">${allowOperation}</span> on this table`
        } else {
            preview = `${whoText} ${allowedText} perform <span class="fw-medium">${allowOperation}</span> and ${deniedText} perform <span class="fw-medium">${deniedOperation}</span> on this table`
        }

        return preview
    }

    getPreviewTextFromRule(rule, allowOperation, deniedOperation) {
        const granteeType = rule.grantee_type
        const grantee = this._getEntity(rule, 'grantee')
        return this._buildPreviewText(granteeType?.name, grantee?.name, allowOperation, deniedOperation)
    }

    updatePreview() {
        const type = this.form.get("grantee_type_id")
        const grantee = this.form.get("grantee_id")
        const operations = this.form.get("operations")
        const operation_options = operations._options
        const allowedOperation = `${operation_options.filter(op => op.get()).map(op => op._label.textContent).join(", ")}`
        const deniedOperation = `${operation_options.filter(op => !op.get()).map(op => op._label.textContent).join(", ")}`

        this.preview.innerHTML = this._buildPreviewText(type.get()?.name, grantee.get()?.name, allowedOperation, deniedOperation)
    }

    onEdit(form, data) {
        this.updateSelector(data.grantee_type, this.form.get("grantee_id"))
        this.form.set("grantee_id", this._getEntity(data, 'grantee'))

        const operationValue = data.details
            .filter(d => d.level_id == RightLevel.Grant)
            .map(d => d.operation_id)
        this.form.set("operations", operationValue)
    }
}
