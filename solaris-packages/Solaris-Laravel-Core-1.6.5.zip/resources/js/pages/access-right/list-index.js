import AccessRightListPage from "./list"

new AccessRightListPage("access-right")