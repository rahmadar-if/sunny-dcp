import MenuListPage from "./list"

new MenuListPage()
