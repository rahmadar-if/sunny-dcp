import SolarPage from "../../solaris/solar/solar-page"
import MenuTree from "./menu-tree"
import ModalForm from "../../solaris/modal-form"
import Button from "../../solaris/button"
import Model from "../../solaris/model"

export default class MenuListPage extends SolarPage {

    constructor() {
        super(false)

        this.id = "menu-tree"
        this.init()
    }

    init() {
        this._selectedNode = null

        this._initActions()
        this._initModal()

        this.tree = new MenuTree(`#${this.id}`)
        this.tree.setData(MENUS)
        this.tree
            .on("ready", this.ready.bind(this))
            .on("added", this.new.bind(this))
            .on("edit", this.edit.bind(this))
            .on("edited", this.edited.bind(this))
            .on("delete", this.delete.bind(this))
            .on("move", this.move.bind(this))
            .render()
    }

    _initActions() {
        /** @type {Button} */
        this._newMenuBtn = this.get(`${this.id}_add-menu`)
        this._newMenuBtn.on("click", () => this.tree.addRoot())

        /** @type {Button} */
        this._newCategoryBtn = this.get(`${this.id}_add-category`)
        this._newCategoryBtn.on("click", () => this.tree.addCategory())

        /** @type {Button} */
        this._expandBtn = this.get(`${this.id}_expand-all`)
        this._expandBtn.on("click", () => this.tree.expandAll())

        /** @type {Button} */
        this._collapseBtn = this.get(`${this.id}_collapse-all`)
        this._collapseBtn.on("click", () => this.tree.collapseAll())

        /** @type {Button} */
        this._refreshBtn = this.get(`${this.id}_refresh`)
        this._refreshBtn.on("click", () => this.refresh())
    }

    _initModal() {
        /** @type {ModalForm} */
        this._modal = this.get(`${this.id}_modal_ModalForm`)

        this._modal.modal.on("hidden", () => {
            if (this._selectedNode) {
                this._selectedNode._state = "clean"
                this._selectedNode = null
            }
        })

        this._modal.form.on("success", (response) => {
            if (this._selectedNode) {
                const data = response.data
                this.tree.updateNode(this._selectedNode.id, { name: data.name, is_hide: data.is_hide })
                this._selectedNode = null
            }
        })
    }

    async ready() {
        this._newMenuBtn.enabled()
        this._newCategoryBtn.enabled()
        this._expandBtn.enabled()
        this._collapseBtn.enabled()
        this._refreshBtn.enabled()
    }

    async new(node) {
        try {
            const res = await Model.create("Menu", {
                name: node.name,
                position: node.position,
                parent_id: node.parent_id,
                category_id: node.category_id,
                is_category: node.is_category || false
            })

            if (!res.success) {
                this._showError(res.message, res.errors)
                return false
            }

            this.tree.updateNode(node.id, { id: res.data.id })
            return res.success
        } catch (e) {
            this._showError("Failed to create menu")
            return false
        }
    }

    async edit(node) {
        this._selectedNode = node
        await this._modal.edit(node.id, (form, data) => {
            if (data.is_category) {
                form.get("url").hidden()
                form.get("route_name").hidden()
                form.get("icon").hidden()
            } else {
                if (node.parent_id) {
                    form.get("icon").hidden()
                } else {
                    form.get("icon").show()
                }

                form.get("url").show()
                form.get("route_name").show()
            }
        })
    }

    async edited(node) {
        try {
            const res = await Model.update("Menu", node.id, {
                name: node.name
            })

            if (!res.success) {
                this._showError(res.message, res.errors)
                return false
            }

            return true
        } catch (e) {
            this._showError("Failed to update menu")
            return false
        }
    }

    async delete(node, mode) {
        const req = await this.axios({
            method: "DELETE",
            url: `${BASE_URL}/core/form/${node.id}`,
            headers: {
                'X-Model': "Menu"
            },
            data: {
                delete_all: mode == 'all'
            }
        })

        const res = req.data

        if (!res.success) {
            this.helper.errorAlert({ title: "Oops! There was an error", message: res.message, timeout: null })
        }

        return res.success
    }

    async move(node, parentId, position, oldParentId) {
        try {
            const res = await Model.update("Menu", node.id, {
                name: node.name,
                parent_id: node.parent_id,
                category_id: node.category_id,
                position: position
            })

            if (!res.success) {
                this._showError(res.message, res.errors)
                return false
            }

            return true
        } catch (e) {
            this._showError("Failed to move menu")
            return false
        }
    }

    async refresh() {
        this.helper.loadingPage(true)
        try {
            const req = await this.axios.get(`${BASE_URL}/admin/menu/list`)
            const menus = req.data

            this.tree.setData(menus, true)
        } catch (error) {
            console.error({ error })
            this.helper.toast({ message: "Refresh failed", color: "danger" })
        } finally {
            this.helper.loadingPage(false)
        }
    }

    _showError(message, errors = {}) {
        const messages = []

        if (message) {
            messages.push(message)
        }

        for (const key in errors) {
            const fieldErrors = errors[key]
            if (Array.isArray(fieldErrors)) {
                messages.push(...fieldErrors)
            } else {
                messages.push(fieldErrors)
            }
        }

        const fullMessage = messages.join(". ").trim()
        if (fullMessage) {
            this.helper.toast({ message: fullMessage, color: "danger" })
        }
    }
}
