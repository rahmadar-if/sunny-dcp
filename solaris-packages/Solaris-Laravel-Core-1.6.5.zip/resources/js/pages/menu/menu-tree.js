import MenuAssign from "../../solaris/assign/menu-assign"
import Tree from "../../solaris/tree"

/**
 * MenuTree - Extends Tree to support Category-based menu management
 */
export default class MenuTree extends Tree {

    /**
     * Check if node is a category
     * @param {object} node 
     * @returns {boolean}
     */
    isCategory(node) {
        return node?.is_category === true
    }

    /**
     * Add a new category at root level
     */
    async addCategory() {
        const node = this._createNode({
            is_category: true,
            name: "New Category"
        })

        node.element = this._renderNode(node, 0)

        const placeholder = this._root.querySelector(".tree-root-placeholder")
        if (placeholder) {
            this._root.insertBefore(node.element, placeholder)
        } else {
            this._root.appendChild(node.element)
        }

        this._data.push(node)

        await this.trigger("adding", node)
    }

    /**
     * Override setData to restructure flat list into nested category structure
     */
    setData(data, forceRender = false) {
        const categories = {}
        const roots = []

        data.forEach(node => {
            if (node.is_category) {
                if (!node.children) node.children = []
                categories[node.id] = node
                roots.push(node)
            } else if (!node.category_id) {
                roots.push(node)
            }
        })

        const orphans = []
        data.forEach(node => {
            if (!node.is_category && node.category_id) {
                if (!node.parent_id) {
                    const category = categories[node.category_id]
                    if (category) {
                        category.children.push(node)
                    } else {
                        orphans.push(node)
                    }
                }
            }
        })

        roots.push(...orphans)
        roots.sort((a, b) => (a.position || 0) - (b.position || 0))

        Object.values(categories).forEach(cat => {
            if (cat.children) {
                cat.children.sort((a, b) => (a.position || 0) - (b.position || 0))
            }
        })

        return super.setData(roots, forceRender)
    }

    /**
     * Override addChild - if parent is category, set category_id instead of parent_id
     */
    async addChild(parentId) {
        const parent = this.find(parentId)
        if (!parent) {
            return
        }

        if (parent._state === "new") {
            return
        }

        const isParentCategory = this.isCategory(parent)

        const node = this._createNode({
            parent_id: isParentCategory ? null : parentId,
            category_id: isParentCategory ? parentId : parent.category_id
        })

        node.element = this._renderNode(node, 0)

        if (!parent.children) {
            parent.children = []

            const childrenUl = document.createElement("ul")
            childrenUl.className = "tree-children"

            const placeholder = this._createDropPlaceholder()
            childrenUl.appendChild(placeholder)

            parent.element.querySelector(".tree-toggle")?.classList.remove("invisible")
            parent.element.appendChild(childrenUl)
        }

        parent.children.push(node)

        const childrenUl = parent.element.querySelector(".tree-children")
        const placeholder = childrenUl.querySelector(":scope > .tree-drop-placeholder")
        if (placeholder) {
            childrenUl.insertBefore(node.element, placeholder)
        } else {
            childrenUl.appendChild(node.element)
        }

        await this.trigger("adding", node)
    }

    /**
     * Override move to handle category restrictions and logic
     */
    async move(nodeId, newParentId, position, referenceId = null) {
        const node = this.find(nodeId)
        if (!node) return false
        if (node.id === newParentId) return false
        if (newParentId && this._isDescendantOf(newParentId, nodeId)) return false
        if (this.isCategory(node) && newParentId !== null) return false

        const oldParentId = node.parent_id

        this._removeFromParent(node)

        node.parent_id = newParentId

        let targetList, targetData

        if (newParentId) {
            const newParent = this.find(newParentId)

            if (this.isCategory(newParent)) {
                node.parent_id = null
                node.category_id = newParent.id
            } else {
                node.category_id = newParent.category_id
            }

            if (!newParent.children) {
                newParent.children = []
                const childrenUl = document.createElement("ul")
                childrenUl.className = "tree-children"

                const placeholder = this._createDropPlaceholder()
                childrenUl.appendChild(placeholder)

                newParent.element.querySelector(".tree-toggle")?.classList.remove("invisible")
                newParent.element.appendChild(childrenUl)
            }
            targetList = newParent.element.querySelector(".tree-children")
            targetData = newParent.children
        } else {
            targetList = this._root
            targetData = this._data
            node.category_id = null
        }

        if (!newParentId && referenceId) {
            const refNode = this.find(referenceId)
            if (refNode) {
                if (this.isCategory(refNode)) {
                    node.category_id = null
                } else {
                    node.category_id = refNode.category_id
                }
            }
        }

        if (position === "last") {
            const placeholder = targetList.querySelector(":scope > .tree-drop-placeholder")
            if (placeholder) {
                targetList.insertBefore(node.element, placeholder)
            } else {
                targetList.appendChild(node.element)
            }
            targetData.push(node)
        } else if (position === "before" && referenceId) {
            const refNode = this.find(referenceId)
            if (refNode && refNode.element.parentNode) {
                refNode.element.parentNode.insertBefore(node.element, refNode.element)
                const refIndex = targetData.findIndex(n => n.id === referenceId)
                targetData.splice(refIndex, 0, node)
            }
        } else if (position === "after" && referenceId) {
            const refNode = this.find(referenceId)
            if (refNode && refNode.element.parentNode) {
                refNode.element.parentNode.insertBefore(node.element, refNode.element.nextSibling)
                const refIndex = targetData.findIndex(n => n.id === referenceId)
                targetData.splice(refIndex + 1, 0, node)
            }
        }

        node.position = this._calculateNewPosition(targetData, position, referenceId)

        const success = await this._triggerEvent("move", node, node.parent_id, node.position, oldParentId)
        if (!success) {
            console.warn("Move event handler returned false. Manual refresh may be needed.")
        }

        return true
    }

    updateNode(nodeId, data) {
        const node = super.updateNode(nodeId, data)

        const iconHide = node.element.querySelector("i.ri-eye-off-line")
        if (node.is_hide) {
            iconHide.classList.remove("d-none")
        } else {
            iconHide.classList.add("d-none")
        }

        return node
    }

    _preInit() {
        super._preInit()

        this.assign = new MenuAssign("menu-assign-modal")

        this.on("node-created", this._onNodeCreated.bind(this))
    }

    _onNodeCreated(item, node) {
        const deleteItem = item.querySelector(".action-delete")?.closest("li")
        if (!deleteItem) return

        deleteItem.insertAdjacentHTML("beforebegin", `
            <li><a class="dropdown-item action-assign" href="#"><i class="ri-user-settings-line me-2"></i>Assign Access</a></li>
            <li><hr class="dropdown-divider"></li>
        `)

        item.querySelector(".action-assign").addEventListener("click", async (e) => {
            e.preventDefault()
            await this.assign.show(node.id)
        })
    }

    /**
     * Override to preserve is_category and category_id
     */
    _normalizeData(nodes, parentId = null, categoryId = null) {
        return nodes
            .map(node => {
                const isCategory = node.is_category === true
                const nodeCategoryId = isCategory ? null : (node.category_id || categoryId)

                return {
                    id: node.id?.toString() || (this._index++).toString(),
                    name: node.name || this._config.defaultName,
                    position: node.position || 0,
                    parent_id: parentId,
                    category_id: nodeCategoryId,
                    is_category: isCategory,
                    is_hide: node.is_hide,
                    children: node.children && node.children.length > 0
                        ? this._normalizeData(node.children, node.id?.toString(), nodeCategoryId)
                        : null,
                    _state: "clean"
                }
            })
            .sort((a, b) => a.position - b.position)
    }

    /**
     * Override template for category nodes
     * @param {object} node 
     * @param {boolean} hasChildren 
     * @returns {string}
     */
    _nodeTemplate(node, hasChildren) {
        if (this.isCategory(node)) {
            return this._categoryTemplate(node, hasChildren)
        }

        let nodeTemplate = super._nodeTemplate(node, hasChildren)
        nodeTemplate += `<i class="ri-eye-off-line ${node.is_hide ? "" : "d-none"}"></i>`

        return nodeTemplate
    }

    /**
     * Template for category node - matches parent's _nodeTemplate structure
     * @param {object} node 
     * @param {boolean} hasChildren 
     * @returns {string}
     */
    _categoryTemplate(node, hasChildren) {
        const isNew = node._state === "new"
        const { icons, labels } = this._config

        return `
            <span class="tree-drag-handle d-flex align-items-center justify-content-center ${isNew ? 'd-none' : ''}">
                <i class="${icons.drag}"></i>
            </span>
            <span class="tree-toggle d-flex align-items-center justify-content-center ${hasChildren ? '' : 'invisible'}">
                <i class="${icons.collapse}"></i>
            </span>
            <div class="dropdown ${isNew ? 'd-none' : ''}">
                <button type="button" class="btn btn-sm btn-light btn-icon" data-bs-toggle="dropdown">
                    <i class="${icons.dropdown}"></i>
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item action-add-child" href="#"><i class="${icons.addChild} me-2"></i>Add Menu</a></li>
                    <li><a class="dropdown-item action-edit" href="#"><i class="${icons.edit} me-2"></i>${labels.edit}</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item text-danger action-delete" href="#"><i class="${icons.delete} me-2"></i>${labels.delete}</a></li>
                </ul>
            </div>
            <span class="tree-actions d-flex gap-1 ${isNew ? '' : 'd-none'}">
                <button type="button" class="btn btn-sm btn-success btn-icon action-save" title="${labels.save}">
                    <i class="${icons.save}"></i>
                </button>
                <button type="button" class="btn btn-sm btn-light btn-icon action-discard" title="${labels.discard}">
                    <i class="${icons.discard}"></i>
                </button>
            </span>
            <span class="flex-grow-1 text-truncate">
                <input type="text" class="tree-input form-control form-control-sm ${isNew ? '' : 'd-none'}" value="${node.name}" />
                <span class="tree-name ${isNew ? 'd-none' : ''}">${node.name}</span>
            </span>
            <div class="d-flex gap-2">
                <i class="ri-eye-off-line ${node.is_hide ? '' : 'd-none'}"></i>
                <span class="badge bg-secondary">Category</span>
            </div>
        `
    }

    /**
     * Helper to remove node from its parent (supports Category as parent)
     */
    _removeFromParent(node) {
        if (node.parent_id) {
            const parent = this.find(node.parent_id)
            if (parent && parent.children) {
                parent.children = parent.children.filter(n => n.id !== node.id)
                if (parent.children.length === 0) {
                    parent.children = null
                    parent.element.querySelector(".tree-toggle")?.classList.add("invisible")
                    parent.element.querySelector(".tree-children")?.remove()
                }
            }
        } else if (node.category_id && !node.is_category) {
            const category = this.find(node.category_id)
            if (category && category.children) {
                category.children = category.children.filter(n => n.id !== node.id)
                if (category.children.length === 0) {
                    category.children = null
                    category.element.querySelector(".tree-toggle")?.classList.add("invisible")
                    category.element.querySelector(".tree-children")?.remove()
                }
            }
        } else {
            this._data = this._data.filter(n => n.id !== node.id)
        }
    }

    async _deleteAll(nodeId, isSilent = false) {
        const node = this.find(nodeId)
        if (!node) return false
        if (!isSilent && !await this._triggerEvent("delete", node, "all")) return false

        this._removeFromParent(node)
        node.element?.remove()
        return true
    }

    async _deleteNodeOnly(nodeId, isSilent = false) {
        const node = this.find(nodeId)
        if (!node) return false
        if (!isSilent && !await this._triggerEvent("delete", node, "node-only")) return false

        const children = node.children || []

        let parentData, parentElement

        if (node.parent_id) {
            const parent = this.find(node.parent_id)
            parentData = parent.children
            parentElement = parent.element.querySelector(".tree-children")
        } else if (node.category_id && !node.is_category) {
            const category = this.find(node.category_id)
            parentData = category.children
            parentElement = category.element.querySelector(".tree-children")
        } else {
            parentData = this._data
            parentElement = this._root
        }

        const nodeIndex = parentData.findIndex(n => n.id === nodeId)

        children.forEach(child => {
            if (this.isCategory(node)) {
                child.parent_id = null
                child.category_id = null
            } else {
                child.parent_id = node.parent_id
                child.category_id = node.category_id
            }
        })

        parentData.splice(nodeIndex, 1, ...children)

        children.forEach(child => {
            parentElement.insertBefore(child.element, node.element)
        })

        node.element?.remove()
        return true
    }

    _onDnd_Over(e, dragEl, targetEl, zone) {
        if (!this._draggedNode) return
        if (this._draggedNode.id === targetEl.closest('.tree-node')?.dataset.id) return

        const targetNode = this.find(targetEl.closest('.tree-node')?.dataset.id)
        if (!targetNode) return
        if (this._isDescendantOf(targetNode.id, this._draggedNode.id)) return

        this._clearDropIndicators()

        if (this.isCategory(this._draggedNode)) {
            const isTargetRoot = !targetNode.parent_id && (!targetNode.category_id || this.isCategory(targetNode))
            if (!isTargetRoot) return

            if (zone === 'before') targetEl.classList.add('drop-before')
            else targetEl.classList.add('drop-after')
            return
        }

        if (this.isCategory(targetNode)) {
            if (zone === 'before') targetEl.classList.add('drop-before')
            else if (zone === 'after') targetEl.classList.add('drop-after')
            else targetEl.classList.add('drop-inside')
            return
        }

        super._onDnd_Over(e, dragEl, targetEl, zone)
    }

    _onDnd_Drop(e, dragEl, targetEl, zone) {
        const dragNodeId = dragEl.closest('.tree-node')?.dataset.id
        const targetNode = this.find(targetEl.closest('.tree-node')?.dataset.id)
        if (!targetNode || dragNodeId === targetNode.id) return
        if (this._isDescendantOf(targetNode.id, dragNodeId)) return

        this._clearDropIndicators()

        if (this.isCategory(this._draggedNode)) {
            const isTargetRoot = !targetNode.parent_id && (!targetNode.category_id || this.isCategory(targetNode))
            if (!isTargetRoot) return

            if (zone === 'before') {
                this.move(dragNodeId, null, 'before', targetNode.id)
            } else {
                this.move(dragNodeId, null, 'after', targetNode.id)
            }
            return
        }

        if (this.isCategory(targetNode)) {
            if (zone === 'before') {
                this.move(dragNodeId, null, 'before', targetNode.id)
            } else if (zone === 'after') {
                this.move(dragNodeId, null, 'after', targetNode.id)
            } else {
                this.move(dragNodeId, targetNode.id, 'last')
            }
            return
        }

        super._onDnd_Drop(e, dragEl, targetEl, zone)
    }
}
