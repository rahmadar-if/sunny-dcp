import SolarPage from "@core-js/solaris/solar/solar-page"

export default class ResetPasswordPage extends SolarPage {
    init() {
        const form = this.get("reset-password")
        const token = document.querySelector('#token').value
        const email = document.querySelector('#email').value
        const password = form.get("password")
        const confirmPassword = form.get("password_confirmation")

        password?.on("change", (value) => {
            const isPasswordConfEmpty = this.helper.isEmpty(confirmPassword.get())
            const isMatch = !isPasswordConfEmpty && !this.helper.isEmpty(value) && value === confirmPassword.get()

            if (!isPasswordConfEmpty && !isMatch) {
                console.log("test")
                confirmPassword.error()
                confirmPassword.setMessage("Confirm password does not match")
            }
        }, "ResetPasswordPage")

        confirmPassword?.on("change", (value) => {
            if (!this.helper.isEmpty(password.get()) && password.get() !== value) {
                confirmPassword.error()
                confirmPassword.setMessage("Confirm password does not match")
            }
        }, "ResetPasswordPage")

        form
            .hiddenSuccessAlert()
            .addData("token", token)
            .addData("email", email)
            .addValidation("password_confirmation", (value) => {
                const isValid = !this.helper.isEmpty(value) && (password.get() !== value) ? false : true

                return {
                    success: isValid,
                    message: "Confirm password does not match",
                }
            })
            .on("success", (response) => {
                setTimeout(() => form.disabled(), 0)
                this.helper.successAlert({ title: response.message })
                    .then(res => window.location = response.redirect)
            }, "ResetPasswordPage")
            .on("error", (response) => this.helper.errorAlert({ title: response.message }), "ResetPasswordPage")
    }
}