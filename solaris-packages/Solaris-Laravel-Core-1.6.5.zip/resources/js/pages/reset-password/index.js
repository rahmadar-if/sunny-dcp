import ResetPasswordPage from "./page"

new ResetPasswordPage()