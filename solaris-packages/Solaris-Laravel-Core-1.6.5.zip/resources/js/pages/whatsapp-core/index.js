import WhatsAppCorePage from "./page"

export default new WhatsAppCorePage()
