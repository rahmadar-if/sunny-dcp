import SolarPage from "@core-js/solaris/solar/solar-page"
import Chat from "@core-js/solaris/chat"
import Modal from "@core-js/solaris/modal"

export default class WhatsAppCorePage extends SolarPage {

	// #region Lifecycle

	init() {
		/** @type { Chat } */
		this.chat = this.get('wa-chat')

		this.initNewChatModal()
		this.initSetupBtn()
	}

	// #endregion

	// #region New Chat Modal

	/**
	 * @returns {void}
	 */
	initNewChatModal() {
		/** @type { Modal } */
		this.newChatModal = this.get('new-chat-modal')
		this.newChatModal.on("hide", () => this._resetNewChatModal())

		this.get('new-chat-btn')?.on('click', () => this.newChatModal?.show())
		this.get('new-chat-modal_save')?.on('click', () => this._submitNewChat())

		this.newChatName  = this.get('new-chat-modal_contact_name')
		this.newChatPhone = this.get('new-chat-modal_phone_number')
	}

	// #endregion

	// #region New Chat Internals

	/**
	 * @returns {Promise<void>}
	 */
	async _submitNewChat() {
		const phone = this.newChatPhone?.get()?.trim()
		const name  = this.newChatName?.get()?.trim() || null

		if (!phone) {
			this.newChatPhone.error()
			this.newChatPhone.setMessage('Phone Number is required')
			return
		}

		this.helper.loadingPage(true)
		await this.chat.addConversation(phone, name)

		this.newChatModal?.hide()
		this._resetNewChatModal()

		this.helper.loadingPage(false)
	}

	/**
	 * @returns {void}
	 */
	_resetNewChatModal() {
		this.newChatName?.reset(false)
		this.newChatPhone?.reset(false)
	}

	// #endregion

	// #region Setup

	/**
	 * @returns {void}
	 */
	initSetupBtn() {
		this.get('setup-btn')?.on('click', () => this.chat.openSetup())
	}

	// #endregion
}
