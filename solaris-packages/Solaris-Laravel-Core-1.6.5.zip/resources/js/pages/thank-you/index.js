import ThankYouPage from "./page"

new ThankYouPage()