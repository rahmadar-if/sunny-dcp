import SolarPage from "@core-js/solaris/solar/solar-page"

const STORAGE_KEY = "solaris_resend_locked"

export default class ThankYouPage extends SolarPage {
	init() {
		const email       = document.querySelector("#email").value
		this._resendBtn   = this.get("resend_confirmation")
		this._countdownEl = document.querySelector("#resend-countdown")
        
        this._countdownInterval = null

		const stored = sessionStorage.getItem(STORAGE_KEY)
		if (stored) {
			const { locked_at, duration } = JSON.parse(stored)
			const remaining = Math.ceil(duration - (Date.now() - locked_at) / 1000)
			if (remaining > 0) {
				this._startCooldown(remaining)
			} else {
				sessionStorage.removeItem(STORAGE_KEY)
			}
		} else {
			this._startCooldown(10)
		}

		this._resendBtn.on("click", async () => {
			sessionStorage.setItem(STORAGE_KEY, JSON.stringify({ locked_at: Date.now(), duration: 60 }))
			this._resendBtn.disabled()
			this._resendBtn.load()

			try {
				const req = await this.axios({
					method: "POST",
					url: `${BASE_URL}/verify-email`,
					data: { email }
				})
				const res = req.data

				if (!res.success) {
					await this.helper.errorAlert({ title: "Oops! There was an error", message: res.message, timeout: 3000 })
				} else {
					await this.helper.successAlert({ title: "Resend success", message: res.message, timeout: 3000 })
				}

				const redirect = res.redirect ?? null
				if (redirect) {
					this.helper.loadingPage(true)
					window.location = redirect
				} else {
					this._startCooldown(60)
				}
			} catch (error) {
				console.error({ error })
				this._resendBtn.unload()
				this._resendBtn.enabled()
				sessionStorage.removeItem(STORAGE_KEY)
				if (!error?.response) {
					this.helper.errorAlert({ title: "Oops! There was an error", message: error })
				}
			}
		})
	}

	/**
	 * @param {number} seconds
	 * @returns {void}
	 */
	_startCooldown(seconds) {
		clearInterval(this._countdownInterval)

		this._resendBtn.disabled()
		this._resendBtn.load()

		let remaining = Math.ceil(seconds)
		this._updateCountdownText(remaining)

		this._countdownInterval = setInterval(() => {
			remaining--

			if (remaining <= 0) {
				clearInterval(this._countdownInterval)
				this._countdownInterval = null
				sessionStorage.removeItem(STORAGE_KEY)
				this._resendBtn.unload()
				this._resendBtn.enabled()
				if (this._countdownEl) {
					this._countdownEl.textContent = ""
				}
				return
			}

			this._updateCountdownText(remaining)
		}, 1000)
	}

	/**
	 * @param {number} seconds
	 * @returns {void}
	 */
	_updateCountdownText(seconds) {
		this._countdownEl.textContent = `You can resend in ${seconds}s`
	}
}
