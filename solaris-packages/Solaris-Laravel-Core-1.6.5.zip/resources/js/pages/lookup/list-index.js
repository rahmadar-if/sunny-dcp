import LookupListPage from "./list"

new LookupListPage("lookup")