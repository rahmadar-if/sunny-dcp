import SolarListPage from "@core-js/solaris/solar/solar-list-page";
import Model from "../../solaris/model";

export default class LookupDetailListPage extends SolarListPage {
    init() {
        this.table
            .disableCache()
            .on("saving", (row, data, config) => {
                config.headers['X-Model'] = `!${this.table._parseModel.controller}`
                config.headers['X-Lookup'] = this.table._parseModel.methodArgs[0]
            })
            .on("save all", async (saveRows) => {
                const req = await this.axios({
                    method: "POST",
                    url:    `${BASE_URL}/admin/lookup/save-all`,
                    headers: { 'X-Lookup': this.table._parseModel.methodArgs[0] },
                    data:   { rows: saveRows.map(item => item.data) }
                })

                return req.data
            })
    }

    async new() {
        const obj = Object.fromEntries(
            DATAGRID_COLUMNS.map(key => [key, null])
        )

        obj.id = null

        return obj
    }

    async delete(data) {
        if (!await this.helper.confirmDelete({ title: "Are you sure" })) {
            return null
        }

        try {
            const req = await this.axios({
                method: "DELETE",
                url: `${BASE_URL}/core/form/${data.id}`,
                headers: {
                    'X-Model': `!${this.table._parseModel.controller}`,
                    'X-Lookup': this.table._parseModel.methodArgs[0]
                }
            })

            const res = req.data
            if (!res.success) {
                this.helper.errorAlert({ title: "Oops! There was an error", message: res.message, timeout: null })
            }

            return res.success
        } catch (e) {
            console.error({ e })

            const eMessage = e instanceof AxiosError ? e.response?.data?.message : e
            this.helper.errorAlert({ title: "Oops! There was an error", message: eMessage, timeout: null })

            throw e
        }
    }
}