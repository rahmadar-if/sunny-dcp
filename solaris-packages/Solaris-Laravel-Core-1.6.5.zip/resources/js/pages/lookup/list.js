import SolarListPage from "@core-js/solaris/solar/solar-list-page";
import Button from "../../solaris/button";

export default class LookupListPage extends SolarListPage {
    init() {
        /** @type {Button}  */
        this.refreshBtn = this.get("lookup_refresh")
        this.refreshBtn.on("click", this.refresh.bind(this))

        this.table.disableCache()
    }

    async ready(settings, json) {
        this.refreshBtn.enabled()
    }

    async view(row, data) {
        this.openEditPage(data.name)
    }

    openEditPage(name) {
        this.helper.loadingPage(true)
        window.location = `${BASE_URL}/admin/lookup/${name}`
    }

    rowDoubleClick(row, data) {
        this.openEditPage(data.name)
    }

    onActionCreated(row, cell, rowData) {
        this.actionAppend(row, {
            selector: "clear-cache-action",
            label: "Clear cache",
            icon: "ri-brush-3-line",
            callback: async () => await this.clearCache(rowData.name)
        })
    }

    async clearCache(lookup) {
        await this.axios.post(`${BASE_URL}/admin/lookup/clear-cache`, { name: lookup })
        this.helper.successAlert({ title: "Clear cache successfully" })
    }

    async refresh() {
        this.refreshBtn.disabled()
        try {
            await this.axios.post(`${BASE_URL}/admin/lookup/clear-cache`)
            super.refresh()
        } finally {
            this.refreshBtn.enabled()
        }
    }
}