import LookupDetailListPage from "./detail"

new LookupDetailListPage("lookup")