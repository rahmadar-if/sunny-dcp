import SolarListPage from "@core-js/solaris/solar/solar-list-page";
import Filter from "@core-js/solaris/filter/filter";
import { Role } from "@core-js/const"
import RoleAssign from "../../solaris/assign/role-assign";

const VISIBLE_PERMISSION = 2

const GROUPS = {
    user: "User",
    ai: "AI",
    integration: "Integration",
}

const DEFAULT_GROUP = "user"
const STORAGE_KEY = "role_group_filter"

export default class RoleListPage extends SolarListPage {
    init() {
        this._activeGroup = this._readStoredGroup()

        this.columnRender("group_name", this.groupColumnRender.bind(this))
        this.columnRender("permission", this.permissionColumnRender.bind(this))
        this.columnCreated("permission", this.permissionColumnCreated.bind(this))
        this.columnRender("description", this.descriptionColumnRender.bind(this))
        this.columnCreated("description", this.descriptionColumnCreated.bind(this))

        this.permissionModal = this.get("role-permission-modal")
        this.permissionModalBody = document.getElementById("role-permission-modal-body")

        this.assign = new RoleAssign("role-assign-modal")
        this.assign.on("closed", (changed) => changed ? this.refresh() : null)

        this.initGroupFilter()
        this.initModal()
    }

    //#region Group Filter

    /**
     * @returns {void}
     */
    initGroupFilter() {
        const radios = document.querySelectorAll('input[name="filter-group"]')

        radios.forEach(radio => {
            radio.checked = radio.value === this._activeGroup

            radio.addEventListener("change", async (e) => {
                if (!e.target.checked) {
                    return
                }

                this._activeGroup = e.target.value
                localStorage.setItem(STORAGE_KEY, this._activeGroup)

                this._applyGroupIndicator()
                await this._applyGroupFilter()
            })
        })

        // Applied without refreshing: the table performs its own initial load right after init,
        // and refreshing here would fetch the same page twice.
        this._applyGroupFilter(false)
    }

    /**
     * @param {boolean} [refresh=true]
     * @returns {Promise<void>}
     */
    async _applyGroupFilter(refresh = true) {
        await this.table.filter("group", new Filter().and("group_name", this._activeGroup), refresh)
    }

    /**
     * Falls back to the default when storage holds a group that no longer exists, so a stale
     * value cannot leave the page filtered to nothing.
     * @returns {string}
     */
    _readStoredGroup() {
        const stored = localStorage.getItem(STORAGE_KEY)

        return Object.hasOwn(GROUPS, stored ?? "") ? stored : DEFAULT_GROUP
    }

    //#endregion

    //#region Modal

    /**
     * @returns {void}
     */
    initModal() {
        if (!this.hasModalForm()) {
            return
        }

        // The field is a read-only indicator, so it is kept out of the payload and the real
        // value is injected from the active filter instead.
        this.form.exclude("group_name")

        this.form.on("sending", (config) => {
            config.data.group_name = this._activeGroup
        }, "RoleListPage")

        this.modal.on("show", () => this._applyGroupIndicator(), "RoleListPage")

        this._applyGroupIndicator()
    }

    /**
     * @returns {void}
     */
    _applyGroupIndicator() {
        this.form?.get("group_name")?.set(GROUPS[this._activeGroup] ?? "")
    }

    //#endregion

    //#region Column

    groupColumnRender(data) {
        return GROUPS[data] ?? ""
    }

    //#endregion

    permissionColumnRender(data, rowData) {
        const permissions = rowData.permissions ?? []
        const remaining = permissions.length - VISIBLE_PERMISSION

        let badges = permissions.slice(0, VISIBLE_PERMISSION).map(this._permissionBadge).join("")
        if (remaining > 0) {
            badges += `<span class="badge bg-secondary" role="button" data-permission-more>${remaining}+</span>`
        }

        return `<div class="d-flex flex-wrap align-items-center gap-1">${badges}</div>`
    }

    permissionColumnCreated(row, cell, cellData, rowData) {
        cell.querySelector("[data-permission-more]")?.addEventListener("click", () => {
            this._showPermissionModal(rowData.permissions ?? [])
        })
    }

    /**
     * Shows every permission of the role, including the ones already visible as badges, so the
     * modal reads on its own without cross-referencing the row.
     * @param {Array<Object>} permissions
     * @returns {void}
     */
    _showPermissionModal(permissions) {
        this.permissionModalBody.innerHTML = permissions
            .map(permission => `<tr><td>${this._permissionBadge(permission)}</td></tr>`)
            .join("")

        this.permissionModal?.show()
    }

    /**
     * @param {Object} permission
     * @returns {string}
     */
    _permissionBadge(permission) {
        return `<span class="badge bg-success">${permission.name}</span>`
    }

    descriptionColumnRender(data, rowData) {
        return data ?
            `<span class="d-inline-block text-truncate align-middle" title="Click to expand" style="max-width: 30rem;">${data}</span>`
            : ""
    }

    descriptionColumnCreated(row, cell, cellData, rowData) {
        const span = cell.children[0]
        span?.addEventListener("click", () => {
            span.classList.toggle("d-inline-block")
            span.classList.toggle("text-truncate")
        })
    }

    onActionCreated(row, cell, rowData) {
        const roleSystem = [Role.User, Role.Admin]
        const assignConf = {
            selector: "assign-action",
            label: "Assign Access",
            icon: "ri-user-settings-line",
            callback: async () => await this.assign.show(rowData.id)
        }

        // System roles cannot be edited or deleted, so their action cell has no anchor to
        // insert after — append instead.
        if (roleSystem.includes(rowData.id)) {
            cell.querySelector(".edit-action").remove()
            cell.querySelector(".delete-action").remove()

            this.actionAppend(row, assignConf)
            return
        }

        this.actionAfter(row, "edit-action", assignConf)
    }
}