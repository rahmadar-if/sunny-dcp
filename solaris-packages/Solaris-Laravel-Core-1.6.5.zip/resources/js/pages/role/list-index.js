import RoleListPage from "./list"

new RoleListPage("role")