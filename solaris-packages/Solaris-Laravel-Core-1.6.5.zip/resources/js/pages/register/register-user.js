import RegisterUserPage from "./register-user-page"

new RegisterUserPage()