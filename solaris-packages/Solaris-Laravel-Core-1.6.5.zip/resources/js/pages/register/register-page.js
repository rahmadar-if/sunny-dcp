import SolarPage from "@core-js/solaris/solar/solar-page"

export default class RegisterPage extends SolarPage {
    init() {
        const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone
        const form = this.get("register")
        const password = form.get("password")
        const confirmPassword = form.get("password_confirmation")
        const google = this.get("google")

        password?.on("change", (value) => {
            const isPasswordConfEmpty = this.helper.isEmpty(confirmPassword.get())
            const isMatch = !isPasswordConfEmpty && !this.helper.isEmpty(value) && value === confirmPassword.get()

            if (!isPasswordConfEmpty && !isMatch) {
                confirmPassword.error()
                confirmPassword.setMessage("Confirm password does not match")
            }
        }, "RegisterPage")

        confirmPassword?.on("change", (value) => {
            if (!this.helper.isEmpty(password.get()) && password.get() !== value) {
                confirmPassword.error()
                confirmPassword.setMessage("Confirm password does not match")
            }
        }, "RegisterPage")

        google?.on("click", () => {
            const url = google?._element.getAttribute('data-url')
            const params = new URLSearchParams({
                timezone: timezone
            })

            window.location = `${url}?${params.toString()}`
        })

        form.hiddenSuccessAlert()
            .addData("timezone", timezone)
            .addValidation("password_confirmation", (value) => {
                const isValid = !this.helper.isEmpty(value) && (password.get() !== value) ? false : true

                return {
                    success: isValid,
                    message: "Confirm password does not match",
                }
            })
            .on("success", (response) => {
                setTimeout(() => form.disabled(), 100)
                this.helper.successAlert({ title: "Awesome!", message: "Your account has been created", timeout: 3000 })
                    .then(res => window.location = response.redirect)
            }, "RegisterPage")
    }
}