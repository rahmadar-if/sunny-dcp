import RegisterPage from "./register-page"

new RegisterPage()