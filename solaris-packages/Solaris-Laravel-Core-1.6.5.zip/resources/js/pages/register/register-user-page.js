import { Salutation, Gender } from "@core-js/const"
import Filter from "@core-js/solaris/filter/filter"

export default class RegisterUserPage extends SolarPage {
    init() {
        this.timezone = Intl.DateTimeFormat().resolvedOptions().timeZone
        this.form = this.get("register")

        this.initForm()
    }

    initForm() {
        this.initLookup()
        this.handleFormWizard()

        const profilePicture = this.get("profile_picture")
        profilePicture.on("success", (res) => {
            this.form.setToFormData()
            this.form.addFile("profile_picture", res.blob, res.name)
            this.form.addData("image_height", res.height)
            this.form.addData("image_width", res.width)
        })

        const salutation = this.form.get("salutation_id")
        const gender = this.form.get("gender_id")
        const password = this.form.get("password")
        const confirmPassword = this.form.get("password_confirmation")

        salutation.on("change", (value) => {
            if (!value) {
                return
            }

            let genderId = null
            switch (value.id) {
                case Salutation.Mr:
                    genderId = Gender.Male
                    break

                case Salutation.Mrs:
                case Salutation.Ms:
                    genderId = Gender.Female
                    break

                default:
                    break;
            }

            gender.set(genderId, genderId ? false : true)
        })

        password.on("change", (value) => {
            const isPasswordConfEmpty = this.helper.isEmpty(confirmPassword.get())
            const isMatch = !isPasswordConfEmpty && !this.helper.isEmpty(value) && value === confirmPassword.get()

            if (!isPasswordConfEmpty && !isMatch) {
                console.log("test")
                confirmPassword.error()
                confirmPassword.setMessage("Confirm password does not match")
            }
        })

        confirmPassword.on("change", (value) => {
            if (!this.helper.isEmpty(password.get()) && password.get() !== value) {
                confirmPassword.error()
                confirmPassword.setMessage("Confirm password does not match")
            }
        })

        form
            .nonactive()
            .hiddenSuccessAlert()
            .addData("timezone", timezone)
            .addValidation("password_confirmation", (value) => {
                const isValid = !this.helper.isEmpty(value) && (password.get() !== value) ? false : true

                return {
                    success: isValid,
                    message: "Confirm password does not match",
                }
            })
            .on("success", (response) => {
                setTimeout(() => form.disabled(), 100)
                this.helper.successAlert({ title: "Awesome!", message: "Your account has been created", timeout: 3000 })
                    .then(res => window.location = response.redirect)
            })
            .on("fail", (fail) => this.helper.toast({ message: "Some fields are invalid or incomplete. Please check again.", color: "danger" }))
    }

    initLookup() {
        const country = this.form.get("country_id")
        const province = this.form.get("province_id")
        const city = this.form.get("city_id")
        const district = this.form.get("district_id")
        const sub_district = this.form.get("sub_district_id")

        province.init({
            param: (param) => {
                const filter = new Filter()
                const countryId = country.get()?.id
                if (countryId) {
                    filter.and("country_id", countryId)
                    param.filter = filter.get()
                }

                return param
            }
        })

        city.init({
            param: (param) => {
                const filter = new Filter()
                const countryId = country.get()?.id
                if (countryId) {
                    filter.and("country_id", countryId)
                }

                const provinceId = province.get()?.id
                if (provinceId) {
                    filter.and("province_id", provinceId)
                }

                if (filter.get().length > 0) {
                    param.filter = filter.get()
                }

                return param
            }
        })

        district.init({
            param: (param) => {
                const filter = new Filter()
                const countryId = country.get()?.id
                if (countryId) {
                    filter.and("country_id", countryId)
                }

                const provinceId = province.get()?.id
                if (provinceId) {
                    filter.and("province_id", provinceId)
                }

                const cityId = city.get()?.id
                if (cityId) {
                    filter.and("city_id", cityId)
                }

                if (filter.get().length > 0) {
                    param.filter = filter.get()
                }

                return param
            }
        })

        sub_district.init({
            param: (param) => {
                const filter = new Filter()
                const countryId = country.get()?.id
                if (countryId) {
                    filter.and("country_id", countryId)
                }

                const provinceId = province.get()?.id
                if (provinceId) {
                    filter.and("province_id", provinceId)
                }

                const cityId = city.get()?.id
                if (cityId) {
                    filter.and("city_id", cityId)
                }

                const districtId = district.get()?.id
                if (districtId) {
                    filter.and("district_id", districtId)
                }

                if (filter.get().length > 0) {
                    param.filter = filter.get()
                }

                return param
            }
        })

        country.on("change", (val) => {
            if (!val) {
                province.set(null)
            }
        })

        province.on("change", (val) => {
            if (!val) {
                city.set(null)
                return
            }

            if (val && !country.get()) {
                country.set(val.country)
            }

            if (val && city.get() && city.get().province.id != val.id) {
                city.set(null)
            }
        })

        city.on("change", (val) => {
            if (!val) {
                district.set(null)
                return
            }

            if (val && !province.get()) {
                province.set(val.province)
            }

            if (val && district.get() && district.get().city.id != val.id) {
                district.set(null)
            }
        })

        district.on("change", (val) => {
            if (!val) {
                sub_district.set(null)
                return
            }

            if (val && !city.get()) {
                city.set(val.city)
            }

            if (val && sub_district.get() && sub_district.get().district.id != val.id) {
                sub_district.set(null)
            }
        })

        sub_district.on("change", (val) => {
            const postcode = form.get("postcode")
            postcode.set(val ? val.postcode : "")

            if (val && (!district.get() || district.get() && val.district.id != district.get().id)) {
                district.set(val.district)
            }
        })
    }

    handleFormWizard() {
        const next = this.get("next")
        const prev = this.get("prev")
        const confirm = this.get("confirm")

        let i = 0;
        const tabOrder = [
            "register-tabs_personal_info",
            "register-tabs-account_detail",
            "register-tabs-address_info",
            "register-tabs-confirmation"
        ]
        const validation = [
            ["name", "phone_number", "salutation_id", "gender_id"],
            ["email", "password", "password_confirmation"],
            null,
            null
        ]

        const tabButtons = document.querySelectorAll(`#register-tabs_nav li button`)
        const tabContents = document.querySelectorAll(`#register-tabs_content div.tab-pane`)

        const setActiveTab = (id) => {
            tabButtons.forEach(btn => {
                if (btn.id == `${id}_button`) {
                    btn.classList.add("active")
                } else {
                    btn.classList.remove("active")
                }
            })
            tabContents.forEach(content => {
                if (content.id == id) {
                    content.classList.add("show", "active")
                } else {
                    content.classList.remove("show", "active")
                }
            })
        }

        const doValidation = (index) => {
            const keys = validation[index]
            if (!keys || (keys && keys.length == 0)) {
                return true
            }

            let isValid = true
            keys.forEach(key => {
                const field = this.form.get(key)
                if (this.helper.isEmpty(field.get())) {
                    isValid = false

                    field.error()
                    field.setMessage(`${field.getLabel()} is required`)
                }
            })

            if (keys.includes("password_confirmation")) {
                if (!this.helper.isEmpty(this.form("password_confirmation").get()) && (this.form("password").get() !== this.form("password_confirmation").get())) {
                    isValid = false
                }
            }

            return isValid
        }

        next.on("click", () => {
            if (!doValidation(i)) {
                return
            }

            i++;
            setActiveTab(tabOrder[i])

            if (i == tabOrder.length - 1) {
                next.disabled()
                next.hidden()
                confirm.enabled()
                confirm.show()
            }

            prev.enabled()
        })

        prev.on("click", () => {
            i--;
            setActiveTab(tabOrder[i])

            if (i == 0) {
                prev.disabled()
            }

            confirm.hidden()
            confirm.disabled()
            next.enabled()
            next.show()
        })

        confirm.on("click", () => {
            this.form
                .active()
                .submit()
        })
    }
}