import PushNotification from "@core-js/solaris/push-notification"

(function () {
    const pushNotification = new PushNotification()

    document.addEventListener("DOMContentLoaded", async () => {
        if (!USER_ID) {
            return
        }

        const isSubscribed = await pushNotification.isSubscribed()

        if (isSubscribed && IS_PUSH_NOTIFICATION === false) {
            console.warn("Device is subscribe but user not setup push notification")
            await pushNotification.unsubscribe()
        } else if (!isSubscribed && IS_PUSH_NOTIFICATION === true) {
            console.warn("Device is not subscribe but user setup push notification")
            await pushNotification.subscribe()
        } else {
            await pushNotification.checkSubscription()
        }
    })
})()