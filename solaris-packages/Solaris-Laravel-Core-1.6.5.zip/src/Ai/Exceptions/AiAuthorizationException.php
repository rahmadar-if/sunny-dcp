<?php

namespace Solaris\Core\Ai\Exceptions;

class AiAuthorizationException extends \RuntimeException {}
