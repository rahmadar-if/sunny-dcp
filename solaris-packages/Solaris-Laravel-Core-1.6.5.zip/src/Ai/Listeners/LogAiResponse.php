<?php

namespace Solaris\Core\Ai\Listeners;

use Laravel\Ai\Events\AgentPrompted;
use Laravel\Ai\Responses\Data\Step;
use Solaris\Core\Ai\Services\AiLogService;

class LogAiResponse
{
	public function handle(AgentPrompted $event): void
	{
		$response = $event->response;

		AiLogService::write('info', 'AI response received', essential: [
			'invocation_id'   => $event->invocationId,
			'agent'           => $event->prompt->agent::class,
			'conversation_id' => $response->conversationId,
			'steps'           => $response->steps->count(),
			'finish_reasons'  => $response->steps->map(fn (Step $step) => $step->finishReason->value)->implode(', '),
			'usage'           => $response->usage->toArray(),
		], full: [
			'response'    => $response->text,
			'tool_calls'  => $response->toolCalls
				->map(fn ($call) => ['name' => $call->name, 'arguments' => $call->arguments])
				->all(),
			'step_detail' => $response->steps
				->map(fn (Step $step) => [
					'tools'         => array_map(fn ($call) => $call->name, $step->toolCalls),
					'finish_reason' => $step->finishReason->value,
					'usage'         => $step->usage->toArray(),
				])
				->all(),
		]);
	}
}
