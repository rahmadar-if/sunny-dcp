<?php

namespace Solaris\Core\Ai\Listeners;

use Solaris\Core\Ai\Services\BouncerEventPublisher;
use Solaris\Core\Ai\Services\WhatsAppAiService;
use Solaris\Core\Events\WhatsApp\WaMessageMediaReady;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\WaConversation;

class DispatchAiOnMediaReady
{
    public function handle(WaMessageMediaReady $event): void
    {
        if (!in_array($event->type, ['image', 'audio', 'video', 'document'], true)) {
            return;
        }

        $aiDevice = Helper::config('whatsapp_ai.device', 'sunny');
        if ($event->device !== $aiDevice) {
            return;
        }

        if (!Helper::config('whatsapp_ai.enabled', false)) {
            return;
        }

        $conversation = WaConversation::find($event->conversationId);
        if ($conversation === null) {
            return;
        }

        $user = WhatsAppAiService::resolveUser($conversation->phone_number);
        if ($user === null) {
            return;
        }

        BouncerEventPublisher::publishMediaReady(
            Helper::config('whatsapp_ai.bouncer.app_id'),
            $conversation->device_id,
            $conversation->id,
            $event->messageId,
        );
    }
}
