<?php

namespace Solaris\Core\Ai\Listeners;

use Solaris\Core\Ai\Services\WhatsAppAiService;
use Solaris\Core\Ai\Services\BatchModeService;
use Solaris\Core\Ai\Services\BouncerEventPublisher;
use Solaris\Core\Events\WhatsApp\WaMessageProcessing;
use Solaris\Core\Helpers\Helper;

class DispatchAiResponse
{
    public function handle(WaMessageProcessing $event): void
    {
        $aiDevice = Helper::config('whatsapp_ai.device', 'sunny');
        if ($event->deviceKey !== $aiDevice) {
            return;
        }

        if (!Helper::config('whatsapp_ai.enabled', false)) {
            return;
        }

        $user = WhatsAppAiService::resolveUser($event->conversation->phone_number);
        if ($user === null) {
            return;
        }

        $textVisibleDuringHold = BatchModeService::isActive($event->conversation, $user)
            ? (string) ($event->message->body ?: $event->message->caption)
            : null;

        BouncerEventPublisher::publish(
            Helper::config('whatsapp_ai.bouncer.app_id'),
            $event->deviceKey,
            $event->conversation->id,
            $event->message->id,
            $event->message->type,
            $textVisibleDuringHold,
            blocking: $event->message->type === 'audio',
        );
    }
}
