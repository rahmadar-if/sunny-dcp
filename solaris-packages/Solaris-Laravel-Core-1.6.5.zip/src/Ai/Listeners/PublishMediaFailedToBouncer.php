<?php

namespace Solaris\Core\Ai\Listeners;

use Solaris\Core\Ai\Services\BouncerEventPublisher;
use Solaris\Core\Ai\Services\WhatsAppAiService;
use Solaris\Core\Events\WhatsApp\WaMessageMediaFailed;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\WaConversation;

class PublishMediaFailedToBouncer
{
    public function handle(WaMessageMediaFailed $event): void
    {
        if ($event->device !== Helper::config('whatsapp_ai.device', 'sunny')) {
            return;
        }

        if (!Helper::config('whatsapp_ai.enabled', false)) {
            return;
        }

        $conversation = WaConversation::find($event->conversationId);
        if ($conversation === null) {
            return;
        }

        if (WhatsAppAiService::resolveUser($conversation->phone_number) === null) {
            return;
        }

        BouncerEventPublisher::publishMediaFailed(
            Helper::config('whatsapp_ai.bouncer.app_id'),
            $conversation->device_id,
            $conversation->id,
            $event->messageId,
        );
    }
}
