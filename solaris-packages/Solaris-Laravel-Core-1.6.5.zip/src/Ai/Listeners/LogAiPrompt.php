<?php

namespace Solaris\Core\Ai\Listeners;

use Laravel\Ai\Events\PromptingAgent;
use Solaris\Core\Ai\Services\AiLogService;

class LogAiPrompt
{
	public function handle(PromptingAgent $event): void
	{
		$prompt = $event->prompt;

		AiLogService::write('info', 'AI prompt sent', essential: [
			'invocation_id' => $event->invocationId,
			'agent'         => $prompt->agent::class,
			'provider'      => $prompt->provider()->name(),
			'model'         => $prompt->model,
			'attachments'   => $prompt->attachments->count(),
			'timeout'       => $prompt->timeout,
		], full: [
			'prompt' => $prompt->prompt,
		]);
	}
}
