<?php

namespace Solaris\Core\Ai\Services;

use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Laravel\Ai\Contracts\Agent;
use Laravel\Ai\Contracts\CanActAsTool;
use Laravel\Ai\Contracts\Tool;
use ReflectionClass;
use RuntimeException;
use Solaris\Core\Ai\Agents\BaseAiAgent;
use Solaris\Core\Ai\Attributes\AiEssential;
use Solaris\Core\Ai\Attributes\AiIgnore;
use Solaris\Core\Ai\Tools\BaseAiTool;
use Solaris\Core\Const\RoleConst;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\UserCache;
use Solaris\Core\Models\AiAgent;
use Solaris\Core\Models\AiTool;

class AiRegistryService
{
    public function sync(): array
    {
        $agentSources = $this->resolveAgentSources();
        $toolSources  = $this->resolveToolSources($agentSources);

        $result = DB::transaction(function () use ($agentSources, $toolSources) {
            $agents = $this->syncAgents($agentSources);
            $tools  = $this->syncTools($toolSources);

            $this->syncEssentialAttachments($agentSources, $toolSources);
            $this->grantDefaultAcl();

            return ['agents' => $agents, 'tools' => $tools];
        });

        UserCache::flushAi();

        return $result;
    }

    protected function syncEssentialAttachments(array $agentSources, array $toolSources): void
    {
        $toolSlugByClass = array_flip($toolSources);
        $agentIdBySlug   = AiAgent::pluck('id', 'slug');
        $toolIdBySlug    = AiTool::pluck('id', 'slug');

        foreach ($agentSources as $agentSlug => $agentClass) {
            if (!is_callable([$agentClass, 'essentialToolClasses'])) {
                continue;
            }

            $agentId = $agentIdBySlug[$agentSlug] ?? null;

            if ($agentId === null) {
                continue;
            }

            $agentEssential = Helper::getClassAttribute($agentClass, AiEssential::class) !== null;

            $desiredToolIds = collect($agentClass::essentialToolClasses())
                ->map(fn (string $class) => $toolSlugByClass[$class] ?? null)
                ->filter()
                ->map(fn (string $slug) => $toolIdBySlug[$slug] ?? null)
                ->filter()
                ->values();

            $this->wireEssentialTools($agentId, $desiredToolIds, $agentEssential);

            if ($agentEssential && $desiredToolIds->isNotEmpty()) {
                AiTool::whereIn('id', $desiredToolIds)->update(['is_default' => true]);
            }
        }
    }

    protected function wireEssentialTools(string $agentId, Collection $desiredToolIds, bool $agentEssential): void
    {
        $existing = DB::table('ai_agent_tools')
            ->where('agent_id', $agentId)
            ->pluck('is_locked', 'tool_id');

        $rows = $desiredToolIds
            ->reject(fn ($toolId) => $existing->has($toolId))
            ->map(fn ($toolId) => [
                'id'        => (string) Str::uuid7(),
                'agent_id'  => $agentId,
                'tool_id'   => $toolId,
                'is_locked' => $agentEssential,
            ])->all();

        if (!empty($rows)) {
            DB::table('ai_agent_tools')->insert($rows);
        }

        if (!$agentEssential) {
            return;
        }

        $relock = $desiredToolIds->filter(fn ($toolId) => $existing->has($toolId) && !$existing[$toolId]);

        if ($relock->isNotEmpty()) {
            DB::table('ai_agent_tools')
                ->where('agent_id', $agentId)
                ->whereIn('tool_id', $relock->all())
                ->update(['is_locked' => true]);
        }

        $stale = DB::table('ai_agent_tools')
            ->where('agent_id', $agentId)
            ->where('is_locked', true);

        if ($desiredToolIds->isNotEmpty()) {
            $stale->whereNotIn('tool_id', $desiredToolIds->all());
        }

        $stale->delete();
    }

    protected function grantDefaultAcl(): void
    {
        $this->grantUserRole('role_ai_agents', 'agent_id', AiAgent::where('is_default', true)->pluck('id'));
        $this->grantUserRole('role_ai_tools', 'tool_id', AiTool::where('is_default', true)->pluck('id'));
    }

    protected function grantUserRole(string $table, string $column, Collection $ids): void
    {
        $rows = $ids->map(fn ($id) => [
            'id'      => (string) Str::uuid7(),
            'role_id' => RoleConst::User,
            $column   => $id,
        ])->all();

        if (empty($rows)) {
            return;
        }

        DB::table($table)->insertOrIgnore($rows);
    }

    protected function resolveAgentSources(): array
    {
        $sources = [];

        foreach (Helper::config('ai.agents', []) as $slug => $class) {
            $resolved = Helper::resolveAiAgentClass($class);

            if ($resolved === null) {
                continue;
            }

            if (!is_callable([$resolved, 'slug'])) {
                $sources[$slug] = $resolved;
                continue;
            }

            $actual = $resolved::slug();

            if ($actual !== $slug) {
                throw new RuntimeException(
                    "Config [ai.agents.{$slug}] resolves to {$resolved}, but its slug() returns "
                    . "\"{$actual}\" — the config key must match the class's own slug."
                );
            }

            $sources[$slug] = $resolved;
        }
        $filter = fn (ReflectionClass $ref) => !$ref->isAbstract()
            && ($ref->isSubclassOf(BaseAiAgent::class) || $ref->implementsInterface(Agent::class));

        foreach (Helper::discoverClasses(app_path('Ai/Agents'), 'App\\Ai\\Agents', $filter) as $reflection) {
            $class = $reflection->getName();
            $slug  = $this->resolveAgentSlug($class);

            $sources[$slug] ??= $class;
        }

        return $sources;
    }

    protected function resolveAgentSlug(string $class): string
    {
        if (is_callable([$class, 'slug'])) {
            return $class::slug();
        }

        if (method_exists($class, 'name')) {
            try {
                $name = (new ReflectionClass($class))->newInstanceWithoutConstructor()->name();

                if (is_string($name) && $name !== '') {
                    return $name;
                }
            } catch (\Throwable) {
            }
        }

        return Str::snake(class_basename($class));
    }

    protected function resolveToolSources(array $agentSources): array
    {
        $sources = [];

        foreach (Helper::config('ai.tools', []) as $slug => $class) {
            $resolved = Helper::resolveAiToolClass($class);

            if ($resolved === null) {
                continue;
            }

            if (Helper::getClassAttribute($resolved, AiIgnore::class) !== null) {
                continue;
            }

            if (!is_callable([$resolved, 'slug'])) {
                $sources[$slug] = $resolved;
                continue;
            }

            $actual = $resolved::slug();

            if ($actual !== $slug) {
                throw new RuntimeException(
                    "Config [ai.tools.{$slug}] resolves to {$resolved}, but its slug() returns "
                    . "\"{$actual}\" — the config key must match the class's own slug."
                );
            }

            $sources[$slug] = $resolved;
        }

        $filter = fn (ReflectionClass $ref) => !$ref->isAbstract()
            && $ref->getAttributes(AiIgnore::class) === []
            && ($ref->isSubclassOf(BaseAiTool::class) || $ref->implementsInterface(Tool::class));

        foreach (Helper::discoverClasses(app_path('Ai/Tools'), 'App\\Ai\\Tools', $filter) as $reflection) {
            $class = $reflection->getName();
            $slug  = $this->resolveToolSlug($class);

            $sources[$slug] ??= $class;
        }

        foreach ($agentSources as $agentClass) {
            if (!is_a($agentClass, CanActAsTool::class, true)) {
                continue;
            }

            $slug = (new ReflectionClass($agentClass))->newInstanceWithoutConstructor()->name();

            $sources[$slug] ??= $agentClass;
        }

        return $sources;
    }

    protected function resolveToolSlug(string $class): string
    {
        if (is_callable([$class, 'slug'])) {
            return $class::slug();
        }

        if (method_exists($class, 'name')) {
            try {
                $name = (new ReflectionClass($class))->newInstanceWithoutConstructor()->name();

                if (is_string($name) && $name !== '') {
                    return $name;
                }
            } catch (\Throwable) {
            }
        }

        return Str::snake(class_basename($class));
    }

    protected function syncAgents(array $sources): array
    {
        $created = 0;
        $updated = 0;

        foreach ($sources as $slug => $class) {
            $agent = AiAgent::updateOrCreate(['slug' => $slug], [
                'class'      => $class,
                'name'       => Str::headline($slug),
                'is_default' => Helper::getClassAttribute($class, AiEssential::class) !== null,
            ]);

            $agent->wasRecentlyCreated ? $created++ : $updated++;
        }

        $deleted = AiAgent::whereNotIn('slug', array_keys($sources))->count();
        AiAgent::whereNotIn('slug', array_keys($sources))->delete();

        return compact('created', 'updated', 'deleted');
    }

    protected function syncTools(array $sources): array
    {
        $created = 0;
        $updated = 0;

        foreach ($sources as $slug => $class) {
            $tool = AiTool::updateOrCreate(['slug' => $slug], [
                'class'       => $class,
                'name'        => Str::headline($slug),
                'description' => $this->describeTool($class),
                'is_default'  => Helper::getClassAttribute($class, AiEssential::class) !== null,
            ]);

            $tool->wasRecentlyCreated ? $created++ : $updated++;
        }

        $deleted = AiTool::whereNotIn('slug', array_keys($sources))->count();
        AiTool::whereNotIn('slug', array_keys($sources))->delete();

        return compact('created', 'updated', 'deleted');
    }

    protected function describeTool(string $class): ?string
    {
        if (!is_subclass_of($class, BaseAiTool::class) && !is_a($class, CanActAsTool::class, true)) {
            return null;
        }

        try {
            $instance = (new ReflectionClass($class))->newInstanceWithoutConstructor();

            return trim((string) $instance->description()) ?: null;
        } catch (\Throwable) {
            return null;
        }
    }
}
