<?php

namespace Solaris\Core\Ai\Services;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Str;
use ReflectionClass;
use ReflectionNamedType;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Helpers\Helper;

class AttachmentTargetRegistry
{
    public static function all(): Collection
    {
        return Cache::rememberForever('ai:attachment_targets', function () {
            $modelNamespaces = ['App\\Models' => app_path('Models')] + array_reverse(Helper::config('model.namespaces', []));
            $exceptions      = Helper::config('object_permissions.model_exceptions', []);
            $seen            = [];
            $targets         = collect();

            $filter = function (ReflectionClass $ref) {
                if (!$ref->isSubclassOf(Model::class) || $ref->isAbstract() || !$ref->hasMethod('fileAttachments')) {
                    return false;
                }

                $returnType = $ref->getMethod('fileAttachments')->getReturnType();

                return $returnType instanceof ReflectionNamedType && $returnType->getName() === HasMany::class;
            };

            foreach ($modelNamespaces as $namespace => $path) {
                foreach (Helper::discoverClasses($path, $namespace, $filter, $exceptions) as $reflection) {
                    $shortName = $reflection->getShortName();

                    if (isset($seen[$shortName])) {
                        continue;
                    }

                    $seen[$shortName] = true;

                    $table = null;
                    if ($reflection->hasProperty('table')) {
                        $table = $reflection->getDefaultProperties()['table'] ?? null;
                    }

                    $table ??= Str::snake(Str::pluralStudly($shortName));

                    $targets->push(['name' => $shortName, 'class' => $reflection->getName(), 'table' => $table]);
                }
            }

            return $targets->sortBy('name')->values();
        });
    }

    public static function findByTable(string $table): ?array
    {
        return static::all()->firstWhere('table', $table);
    }

    public static function resolveTarget(?string $table, ?string $recordId, string $userId): array
    {
        if (empty($table)) {
            return [
                'table_name' => 'users',
                'record_id'  => $userId,
                'label'      => 'your personal attachments',
            ];
        }

        $target = static::findByTable($table);

        if ($target === null || empty($recordId) || !$target['class']::whereKey($recordId)->exists()) {
            return AiResponse::error(
                AiErrorCode::NotFound,
                "Target \"{$table}\" not found or the record does not exist — call list_attachment_targets to verify the module first.",
            );
        }

        return [
            'table_name' => $target['table'],
            'record_id'  => $recordId,
            'label'      => "{$target['name']} record",
        ];
    }
}
