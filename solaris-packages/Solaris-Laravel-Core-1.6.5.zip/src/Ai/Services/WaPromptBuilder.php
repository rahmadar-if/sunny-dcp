<?php

namespace Solaris\Core\Ai\Services;

use Illuminate\Database\Eloquent\Collection as EloquentCollection;
use Illuminate\Support\Collection;
use Laravel\Ai\Files;
use Solaris\Core\Ai\Agents\AudioExtractionAgent;
use Solaris\Core\Ai\Exceptions\AiAuthorizationException;
use Solaris\Core\Models\Attachment;
use Solaris\Core\Models\WaMessage;
use Throwable;

class WaPromptBuilder
{
    public const ID_LENGTH = 8;

    private const SNIPPET_LENGTH = 80;

    private const MEDIA_TYPES = ['image', 'audio', 'video', 'document'];

    private array $voiceReports = [];

    public static function shortId(string $id): string
    {
        return substr($id, -self::ID_LENGTH);
    }

    public function build(Collection $messages): ?string
    {
        $messages = $messages->filter(fn (WaMessage $message) => $this->isRenderable($message))->values();

        if ($messages->isEmpty()) {
            return null;
        }

        if ($messages instanceof EloquentCollection) {
            $messages->load('quotedMessage');
        }

        $this->voiceReports = $this->resolveVoiceReports($messages);

        if ($messages->count() === 1) {
            return $this->buildSingle($messages->first());
        }

        return $this->buildBatch($messages);
    }

    private function isRenderable(WaMessage $message): bool
    {
        if ($message->type === 'text') {
            return !empty($message->body);
        }

        return in_array($message->type, self::MEDIA_TYPES, true);
    }

    private function buildSingle(WaMessage $message): ?string
    {
        $quoted = $message->quotedMessage;

        if ($message->type === 'text') {
            return $quoted === null
                ? $message->body
                : 'User replied to ' . $this->describeQuoted($quoted) . ":\n" . $message->body;
        }

        if ($message->type === 'audio') {
            $report = $this->readVoice($message);

            return $quoted === null
                ? $report
                : 'User replied to ' . $this->describeQuoted($quoted) . " with a voice message:\n" . $report;
        }

        $media  = $this->mediaNoun($message) . ' [' . static::shortId($message->id) . '] (' . $this->mediaState($message) . ')';
        $header = $quoted === null
            ? 'User sent ' . $media
            : 'User replied to ' . $this->describeQuoted($quoted) . ' with ' . $media;

        return empty($message->caption)
            ? $header . ' with no caption.'
            : $header . " with caption:\n" . $message->caption;
    }

    private function buildBatch(Collection $messages): string
    {
        $total = $messages->count();

        $lines = $messages
            ->map(fn (WaMessage $message, int $index) => $this->batchLine($message, $index + 1, $total))
            ->implode("\n\n");

        return "User sent {$total} messages:\n\n" . $lines;
    }

    private function batchLine(WaMessage $message, int $position, int $total): string
    {
        $quoted = $message->quotedMessage;
        $prefix = "{$position}/{$total} [" . static::shortId($message->id) . '] ';

        if ($quoted !== null) {
            $prefix .= '↳ replying to ' . $this->describeQuoted($quoted) . ' — ';
        }

        if ($message->type === 'text') {
            return $prefix . $message->body;
        }

        if ($message->type === 'audio') {
            $caption = empty($message->caption) ? '(voice)' : "(voice, caption: \"{$message->caption}\")";

            return $prefix . $caption . "\n" . $this->readVoice($message);
        }

        $marker = '(' . $message->type . ', ' . $this->mediaState($message) . ')';

        return empty($message->caption)
            ? $prefix . $marker
            : $prefix . $marker . ' with caption: ' . $message->caption;
    }

    private function describeQuoted(WaMessage $quoted): string
    {
        $owner       = $quoted->direction === 'sent' ? 'your' : 'their own';
        $description = $owner . ' ' . $this->quotedNoun($quoted) . ' [' . static::shortId($quoted->id) . ']';
        $snippet     = $this->snippet($quoted->body ?: $quoted->caption);

        return $snippet === null ? $description : $description . ' ("' . $snippet . '")';
    }

    private function quotedNoun(WaMessage $quoted): string
    {
        return match ($quoted->type) {
            'text'     => 'message',
            'audio'    => 'voice message',
            'image'    => 'image',
            'video'    => 'video',
            'document' => 'document',
            default    => 'message',
        };
    }

    private function snippet(?string $text): ?string
    {
        $text = trim(preg_replace('/\s+/u', ' ', (string) $text));

        if ($text === '') {
            return null;
        }

        if (mb_strlen($text) <= self::SNIPPET_LENGTH) {
            return $text;
        }

        $cut       = mb_substr($text, 0, self::SNIPPET_LENGTH);
        $lastSpace = mb_strrpos($cut, ' ');

        if ($lastSpace !== false && $lastSpace > 0) {
            $cut = mb_substr($cut, 0, $lastSpace);
        }

        return rtrim($cut) . '…';
    }

    private function mediaNoun(WaMessage $message): string
    {
        if ($message->type === 'document') {
            $filename = $message->media_filename ?? 'file';

            return "a document \"{$filename}\"";
        }

        return $message->type === 'image' ? 'an image' : 'a ' . $message->type;
    }

    private function mediaState(WaMessage $message): string
    {
        return $message->attachment_id === null ? 'still downloading' : 'not yet processed';
    }

    private function readVoice(WaMessage $message): string
    {
        return $this->voiceReports[$message->id]
            ?? '(voice message could not be read. Ask the user to repeat it or type it instead.)';
    }

    private function resolveVoiceReports(Collection $messages): array
    {
        $attachments = [];

        foreach ($messages as $message) {
            if ($message->type !== 'audio') {
                continue;
            }

            $attachment = $message->attachment_id === null ? null : Attachment::find($message->attachment_id);

            if ($attachment !== null) {
                $attachments[$message->id] = $attachment;
            }
        }

        if (empty($attachments)) {
            return [];
        }

        return count($attachments) === 1
            ? $this->readOneByOne($attachments)
            : $this->readTogether($attachments);
    }

    private function readTogether(array $attachments): array
    {
        $agent = new AudioExtractionAgent();
        $audio = array_map(
            fn (Attachment $attachment) => Files\Audio::fromStorage($attachment->path, $attachment->disk),
            array_values($attachments),
        );

        $response = $this->promptAudio($agent, $audio, array_keys($attachments));

        if ($response === null) {
            return [];
        }

        $blocks = $agent->decodeBlocks($response, count($audio));

        if ($blocks === null) {
            AiLogService::write('warning', 'Voice batch report did not match the recordings sent', essential: [
                'message_ids' => array_keys($attachments),
                'expected'    => count($audio),
            ]);

            return $this->readOneByOne($attachments);
        }

        return array_combine(array_keys($attachments), $blocks);
    }

    private function readOneByOne(array $attachments): array
    {
        $agent   = new AudioExtractionAgent();
        $reports = [];

        foreach ($attachments as $messageId => $attachment) {
            $audio    = [Files\Audio::fromStorage($attachment->path, $attachment->disk)];
            $response = $this->promptAudio($agent, $audio, [$messageId]);
            $blocks   = $response === null ? null : $agent->decodeBlocks($response, 1);

            if ($blocks !== null) {
                $reports[$messageId] = $blocks[0];
            }
        }

        return $reports;
    }

    private function promptAudio(AudioExtractionAgent $agent, array $audio, array $messageIds): ?string
    {
        try {
            $response = trim((string) $agent->read($audio));
        } catch (AiAuthorizationException) {
            AiLogService::write('warning', 'Voice message skipped — no access to audio extraction', essential: [
                'message_ids' => $messageIds,
            ]);

            return null;
        } catch (Throwable $e) {
            AiLogService::write('error', 'Voice message could not be read', essential: [
                'message_ids' => $messageIds,
                'error'       => $e->getMessage(),
            ]);

            return null;
        }

        return $response === '' ? null : $response;
    }
}
