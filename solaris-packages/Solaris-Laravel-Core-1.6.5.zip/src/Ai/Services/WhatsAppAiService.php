<?php

namespace Solaris\Core\Ai\Services;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Solaris\Core\Ai\Agents\WhatsAppAgent;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Interfaces\Model\SolarisUser;
use Solaris\Core\Models\WaAiConfirmation;
use Solaris\Core\Models\Profile;
use Solaris\Core\Models\WaConversation;
use Throwable;

class WhatsAppAiService
{
    private const MEDIA_TYPES = ['image', 'audio', 'video', 'document'];

    private const RECOVERY_NUDGE = 'The previous turn ended without a reply to the user. Using ONLY the tool '
        . 'results already in this conversation, write that final WhatsApp message now. Relay every outcome '
        . 'honestly, including any failure, missing information, or pending confirmation. Do not call any tool.';

    public function processMessage(WaConversation $conversation, Collection $messages): ?string
    {
        if (!Helper::config('whatsapp_ai.enabled', false)) {
            return null;
        }

        $user = static::resolveUser($conversation->phone_number);
        if ($user === null) {
            return null;
        }

        BatchModeService::touch($conversation, $user);

        ConfirmedMediaService::sweepStale($user->getAuthIdentifier());

        $this->cacheUnconsumedMedia($conversation->id, $messages);

        Auth::setUser($user);
        try {
            $prompt = (new WaPromptBuilder())->build($messages);
            if ($prompt === null) {
                return null;
            }

            $agent            = new WhatsAppAgent($user, $conversation);
            $aiConversationId = $this->resolveConversationId($conversation);

            $response = $aiConversationId
                ? $agent->continue($aiConversationId, as: $user)->prompt($prompt)
                : $agent->forUser($user)->prompt($prompt);

            $text = trim((string) $response);

            if ($text === '') {
                $text = $this->recoverEmptyResponse($user, $conversation, $response->conversationId ?? $aiConversationId);
            }
        } finally {
            Auth::forgetGuards();
        }

        if ($aiConversationId) {
            $conversation->update(['ai_last_active_at' => now()]);
        } else {
            $conversation->update([
                'ai_conversation_id' => $response->conversationId,
                'ai_last_active_at'  => now(),
            ]);
        }

        return $text;
    }

    private function recoverEmptyResponse(Authenticatable&SolarisUser $user, WaConversation $conversation, ?string $threadId): string
    {
        $text = $threadId === null ? '' : $this->promptRecovery($user, $threadId);

        AiLogService::write('warning', 'Empty agent response', essential: [
            'conversation_id'    => $conversation->id,
            'ai_conversation_id' => $threadId,
            'recovered'          => $text !== '',
        ]);

        return $text === '' ? $this->fallbackMessage() : $text;
    }

    private function promptRecovery(Authenticatable&SolarisUser $user, string $threadId): string
    {
        try {
            $response = (new WhatsAppAgent($user))
                ->continue($threadId, as: $user)
                ->prompt(self::RECOVERY_NUDGE);

            return trim((string) $response);
        } catch (Throwable) {
            return '';
        }
    }

    protected function fallbackMessage(): string
    {
        return 'Maaf, ada kendala saat menyiapkan jawabannya. Silakan kirim ulang permintaan Anda.';
    }

    private function cacheUnconsumedMedia(string $conversationId, Collection $messages): void
    {
        $key      = static::pendingMediaKey($conversationId);
        $existing = Cache::get($key, []);

        foreach ($messages as $message) {
            if (in_array($message->type, self::MEDIA_TYPES, true) && $message->attachment_id !== null) {
                $existing[] = $message->id;
            }
        }

        $existing = array_values(array_unique($existing));

        if (!empty($existing)) {
            Cache::put($key, $existing, now()->addMinutes(static::pendingMediaTtl()));
        }
    }

    public static function pendingMediaKey(string $conversationId): string
    {
        return "wa:pending_media:{$conversationId}";
    }

    public static function clearPendingMedia(string $conversationId, ?array $messageIds = null): void
    {
        $key = static::pendingMediaKey($conversationId);

        if ($messageIds === null) {
            Cache::forget($key);

            return;
        }

        $existing = array_values(array_diff(Cache::get($key, []), $messageIds));

        if (empty($existing)) {
            Cache::forget($key);

            return;
        }

        Cache::put($key, $existing, now()->addMinutes(static::pendingMediaTtl()));
    }

    private static function pendingMediaTtl(): int
    {
        return (int) Helper::config('ai.agent_settings.whatsapp.pending_media_ttl_minutes', 15);
    }

    private function resolveConversationId(WaConversation $conversation): ?string
    {
        $id = $conversation->ai_conversation_id;
        if (!$id) {
            if ($conversation->ai_last_active_at !== null) {
                Cache::forget("wa:user_id:{$conversation->phone_number}");
            }
            return null;
        }

        $window     = (int) Helper::config('whatsapp_ai.session_idle_minutes', 240);
        $lastActive = $conversation->ai_last_active_at;

        if ($window > 0 && $lastActive !== null && $lastActive->lt(now()->subMinutes($window))) {
            Cache::forget("wa:user_id:{$conversation->phone_number}");

            $conversation->ai_agent_threads = null;
            WaConversation::where('id', $conversation->id)->update(['ai_agent_threads' => null]);

            return null;
        }

        return $id;
    }

    public static function resolveUser(string $phone): (Authenticatable&SolarisUser)|null
    {
        $phone = preg_replace('/\D/', '', $phone);
        if (empty($phone)) {
            return null;
        }

        $cacheKey = "wa:user_id:{$phone}";
        $cached   = Cache::get($cacheKey);

        if ($cached === false) {
            return null;
        }

        if ($cached !== null) {
            return $cached;
        }

        $profile = Profile::whereIn('phone_number', static::phoneVariants($phone))->first();
        if ($profile === null) {
            Cache::put($cacheKey, false, now()->addMinutes(30));
            return null;
        }

        $user = $profile->user;
        if ($user === null || !$user->hasVerifiedEmail() || !$user->is_active || !$user->whatsapp_enabled) {
            Cache::put($cacheKey, false, now()->addMinutes(30));
            return null;
        }

        Cache::forever($cacheKey, $user);

        return $user;
    }

    public static function clearUserCache(string $rawPhone): void
    {
        $phone = preg_replace('/\D/', '', $rawPhone);
        if (empty($phone)) {
            return;
        }

        foreach (static::phoneVariants($phone) as $variant) {
            Cache::forget("wa:user_id:{$variant}");
        }
    }

    public static function cleanConfirmations(?int $days = null): int
    {
        $days = $days ?? (int) Helper::config('ai.tool_settings.confirmation.retention_days', 30);

        return WaAiConfirmation::where('created_at', '<', now()->subDays($days))->delete();
    }

    private static function phoneVariants(string $phone): array
    {
        $national = $phone;
        if (str_starts_with($national, '62')) {
            $national = substr($national, 2);
        } elseif (str_starts_with($national, '0')) {
            $national = ltrim($national, '0');
        }

        if (empty($national)) {
            return [];
        }

        return array_values(array_unique([
            $national,
            '0' . $national,
            '62' . $national,
            '+62' . $national,
        ]));
    }
}
