<?php

namespace Solaris\Core\Ai\Services;

use Illuminate\Support\Facades\Log;
use Psr\Log\LoggerInterface;
use Solaris\Core\Helpers\Helper;

class AiLogService
{
	public static function write(string $level, string $heading, array $essential, array $full = []): void
	{
		if (!static::isEnabled()) {
			return;
		}

		$fields = static::isFull() ? [...$essential, ...$full] : $essential;

		static::channel()->{$level}(static::format($heading, $fields));
	}

	private static function isEnabled(): bool
	{
		return (bool) Helper::config('ai.logging.enabled', true);
	}

	private static function isFull(): bool
	{
		return Helper::config('ai.logging.verbosity', 'full') === 'full';
	}

	private static function channel(): LoggerInterface
	{
		$days = (int) Helper::config('ai.logging.retention_days', 14);

		return Log::build([
			'driver' => 'daily',
			'path'   => storage_path('logs/ai/ai.log'),
			'days'   => $days,
			'level'  => 'debug',
		]);
	}

	private static function format(string $heading, array $fields): string
	{
		$lines   = [];
		$lines[] = str_repeat('-', 80);
		$lines[] = sprintf('[%s] %s', now()->toIso8601String(), $heading);
		$lines[] = '';

		foreach ($fields as $key => $value) {
			$lines[] = sprintf('%s: %s', $key, static::stringify($value));
		}

		$lines[] = str_repeat('-', 80);

		return implode("\n", $lines);
	}

	private static function stringify(mixed $value): string
	{
		if (is_array($value)) {
			return json_encode($value, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
		}

		return (string) ($value ?? 'null');
	}
}
