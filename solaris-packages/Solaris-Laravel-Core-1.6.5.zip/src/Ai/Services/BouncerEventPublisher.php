<?php

namespace Solaris\Core\Ai\Services;

use Illuminate\Support\Facades\Redis;
use RuntimeException;
use Solaris\Core\Helpers\Helper;

class BouncerEventPublisher
{
    public static function publish(?string $appId, string $deviceKey, string $conversationId, string $messageId, string $type, ?string $text = null, bool $blocking = false): void
    {
        $appId = static::requireAppId($appId);

        $fields = [
            'event_type', 'message',
            'app_id', $appId,
            'device_key', $deviceKey,
            'conversation_id', $conversationId,
            'message_id', $messageId,
            'type', $type,
        ];

        if ($text !== null) {
            $fields[] = 'text';
            $fields[] = $text;
        }

        if ($blocking) {
            $fields[] = 'blocking';
            $fields[] = '1';
        }

        static::xadd($fields);
    }

    public static function publishMediaReady(?string $appId, string $deviceKey, string $conversationId, string $messageId): void
    {
        static::publishMediaSignal('media_ready', $appId, $deviceKey, $conversationId, $messageId);
    }

    public static function publishMediaFailed(?string $appId, string $deviceKey, string $conversationId, string $messageId): void
    {
        static::publishMediaSignal('media_failed', $appId, $deviceKey, $conversationId, $messageId);
    }

    private static function publishMediaSignal(string $eventType, ?string $appId, string $deviceKey, string $conversationId, string $messageId): void
    {
        static::xadd([
            'event_type', $eventType,
            'app_id', static::requireAppId($appId),
            'device_key', $deviceKey,
            'conversation_id', $conversationId,
            'message_id', $messageId,
        ]);
    }

    public static function publishHoldStart(?string $appId, string $deviceKey, string $conversationId, array $keywords, array $cancelKeywords, int $maxWaitSeconds): void
    {
        static::xadd([
            'event_type', 'hold_start',
            'app_id', static::requireAppId($appId),
            'device_key', $deviceKey,
            'conversation_id', $conversationId,
            'keywords', json_encode(array_values($keywords), JSON_UNESCAPED_UNICODE),
            'cancel_keywords', json_encode(array_values($cancelKeywords), JSON_UNESCAPED_UNICODE),
            'max_wait_ms', (string) ($maxWaitSeconds * 1000),
        ]);
    }

    public static function publishHoldEnd(?string $appId, string $deviceKey, string $conversationId): void
    {
        static::xadd([
            'event_type', 'hold_end',
            'app_id', static::requireAppId($appId),
            'device_key', $deviceKey,
            'conversation_id', $conversationId,
        ]);
    }

    public static function publishUnlock(?string $appId, string $deviceKey, string $conversationId): void
    {
        static::xadd([
            'event_type', 'unlock',
            'app_id', static::requireAppId($appId),
            'device_key', $deviceKey,
            'conversation_id', $conversationId,
        ]);
    }

    private static function requireAppId(?string $appId): string
    {
        if (!empty($appId)) {
            return $appId;
        }

        AiLogService::write('error', 'Bouncer app_id is not configured', essential: [
            'config_key' => 'whatsapp_ai.bouncer.app_id',
        ]);

        throw new RuntimeException('whatsapp_ai.bouncer.app_id is not configured.');
    }

    private static function xadd(array $fields): void
    {
        $stream = Helper::config('whatsapp_ai.bouncer.stream', 'wa-ai-bouncer-events');
        $maxLen = Helper::config('whatsapp_ai.bouncer.stream_maxlen', 100000);

        Redis::connection('bouncer')->executeRaw([
            'XADD', $stream, 'MAXLEN', '~', (string) $maxLen, '*',
            ...$fields,
        ]);
    }
}
