<?php

namespace Solaris\Core\Ai\Services;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Support\Facades\Cache;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\WaConversation;
use Solaris\Core\Models\WaMessage;

class BatchModeService
{
	public static function start(WaConversation $conversation, Authenticatable $user, WaMessage $triggerMessage): void
	{
		Cache::put(static::key($conversation, $user), [
			'start_message_id' => $triggerMessage->id,
			'started_at'       => $triggerMessage->wa_timestamp->toDateTimeString(),
		], now()->addMinutes(static::ttl()));
	}

	public static function isActive(WaConversation $conversation, Authenticatable $user): bool
	{
		return Cache::has(static::key($conversation, $user));
	}

	public static function touch(WaConversation $conversation, Authenticatable $user): void
	{
		$payload = Cache::get(static::key($conversation, $user));

		if ($payload === null) {
			return;
		}

		Cache::put(static::key($conversation, $user), $payload, now()->addMinutes(static::ttl()));
	}

	public static function cancel(WaConversation $conversation, Authenticatable $user): void
	{
		Cache::forget(static::key($conversation, $user));
	}

	private static function key(WaConversation $conversation, Authenticatable $user): string
	{
		return "wa:batch_mode:{$conversation->id}:{$user->getAuthIdentifier()}";
	}

	public static function ttl(): int
	{
		return (int) Helper::config('ai.tool_settings.batch_mode.ttl_minutes', 15);
	}
}
