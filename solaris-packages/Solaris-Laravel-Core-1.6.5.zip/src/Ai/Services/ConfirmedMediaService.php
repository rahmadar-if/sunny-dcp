<?php

namespace Solaris\Core\Ai\Services;

use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\Attachment;
use Solaris\Core\Models\WaAiConfirmation;
use Solaris\Core\Models\WaConversation;
use Solaris\Core\Models\WaMessage;
use Solaris\Core\Repositories\AttachmentRepository;
use Solaris\Core\Services\WhatsApp\WhatsAppService;
use Throwable;

class ConfirmedMediaService
{
    public static function handle(string $conversationId, array $messageIds): void
    {
        $conversation = WaConversation::find($conversationId);
        if ($conversation === null) {
            return;
        }

        $user = WhatsAppAiService::resolveUser($conversation->phone_number);
        if ($user === null) {
            return;
        }

        foreach (static::notesWaitingFor($user->getAuthIdentifier(), $messageIds) as $note) {
            static::advance($note, $messageIds);
        }
    }

    public static function sweepStale(string $userId): void
    {
        static::reviveAbandonedClaims($userId);

        $expired = static::notesAwaitingMedia($userId)
            ->filter(fn (WaAiConfirmation $note) => static::isPastDeadline($note));

        foreach ($expired as $note) {
            if (static::claim($note)) {
                static::apply($note);
            }
        }
    }

    public static function apply(WaAiConfirmation $note): void
    {
        try {
            $outcome = static::copyEverything($note);
        } catch (Throwable $e) {
            static::releaseClaim($note);

            throw $e;
        }

        $message = static::messageFor($note, $outcome);

        $note->update([
            'status'  => WaAiConfirmation::StatusConfirmed,
            'message' => $message,
        ]);

        static::notify($note, $message);
    }

    protected static function advance(WaAiConfirmation $note, array $signalled): void
    {
        $failed = static::permanentlyFailedAmong($note, $signalled);

        if (!empty($failed)) {
            static::recordFailures($note, $failed);
        }

        if (!static::everyMemberSettled($note)) {
            return;
        }

        if (static::claim($note)) {
            static::apply($note);
        }
    }

    protected static function notesAwaitingMedia(string $userId): Collection
    {
        return WaAiConfirmation::where('status', WaAiConfirmation::StatusAwaitingMedia)
            ->where('user_id', $userId)
            ->get();
    }

    protected static function notesWaitingFor(string $userId, array $messageIds): Collection
    {
        return static::notesAwaitingMedia($userId)
            ->filter(fn (WaAiConfirmation $note) => !empty(array_intersect(static::waitingIds($note), $messageIds)))
            ->values();
    }

    protected static function permanentlyFailedAmong(WaAiConfirmation $note, array $signalled): array
    {
        $named = array_values(array_intersect(static::waitingIds($note), $signalled));

        if (empty($named)) {
            return [];
        }

        return WaMessage::whereIn('id', $named)
            ->whereNull('attachment_id')
            ->pluck('id')
            ->all();
    }

    protected static function recordFailures(WaAiConfirmation $note, array $failed): void
    {
        DB::transaction(function () use ($note, $failed) {
            $fresh = WaAiConfirmation::whereKey($note->id)->lockForUpdate()->first();

            if ($fresh === null) {
                return;
            }

            $payload           = $fresh->payload ?? [];
            $payload['failed'] = array_values(array_unique([...($payload['failed'] ?? []), ...$failed]));

            $fresh->update(['payload' => $payload]);

            $note->payload = $payload;
        });
    }

    protected static function everyMemberSettled(WaAiConfirmation $note): bool
    {
        $waiting = static::waitingIds($note);

        if (empty($waiting)) {
            return true;
        }

        $settled = [...static::downloadedAmong($waiting), ...static::failedIds($note)];

        return empty(array_diff($waiting, $settled));
    }

    protected static function claim(WaAiConfirmation $note): bool
    {
        $claimed = WaAiConfirmation::whereKey($note->id)
            ->where('status', WaAiConfirmation::StatusAwaitingMedia)
            ->update(['status' => WaAiConfirmation::StatusApplying]);

        if ($claimed === 0) {
            return false;
        }

        $note->status = WaAiConfirmation::StatusApplying;

        return true;
    }

    protected static function releaseClaim(WaAiConfirmation $note): void
    {
        WaAiConfirmation::whereKey($note->id)
            ->where('status', WaAiConfirmation::StatusApplying)
            ->update(['status' => WaAiConfirmation::StatusAwaitingMedia]);
    }

    protected static function reviveAbandonedClaims(string $userId): void
    {
        $stuckMinutes = (int) Helper::config('ai.tool_settings.confirmed_media.stuck_minutes', 5);

        WaAiConfirmation::where('status', WaAiConfirmation::StatusApplying)
            ->where('user_id', $userId)
            ->where('updated_at', '<', now()->subMinutes($stuckMinutes))
            ->update(['status' => WaAiConfirmation::StatusAwaitingMedia]);
    }

    protected static function copyEverything(WaAiConfirmation $note): array
    {
        if (!empty($note->payload['avatar'])) {
            return static::applyAvatar($note);
        }

        $payload = $note->payload ?? [];
        $copied  = 0;
        $skipped = count(static::stillMissing($note));

        foreach ($payload['targets'] ?? [] as $index => $entry) {
            $target        = $entry['target'] ?? [];
            $attachmentIds = static::attachmentIdsFor($note, $entry, $index);

            if (!static::targetStillExists($target)) {
                $skipped += count($attachmentIds);

                continue;
            }

            foreach ($attachmentIds as $attachmentId) {
                $source = Attachment::find($attachmentId);

                if ($source === null) {
                    $skipped++;

                    continue;
                }

                AttachmentRepository::copyToRecord($source, $target['table_name'], $target['record_id']);
                $copied++;
            }
        }

        return ['copied' => $copied, 'skipped' => $skipped];
    }

    protected static function applyAvatar(WaAiConfirmation $note): array
    {
        $avatar       = (array) $note->payload['avatar'];
        $attachmentId = $note->payload['attachment_id'] ?? static::firstDownloadedAmong(static::waitingIds($note));

        if ($attachmentId === null) {
            return ['copied' => 0, 'skipped' => 1];
        }

        $model = $avatar['model']::find($avatar['id']);

        if ($model === null) {
            return ['copied' => 0, 'skipped' => 1];
        }

        AvatarService::setFromAttachment($model, $avatar['column'], $attachmentId);

        return ['copied' => 1, 'skipped' => 0];
    }

    protected static function firstDownloadedAmong(array $messageIds): ?string
    {
        if (empty($messageIds)) {
            return null;
        }

        return WaMessage::whereIn('id', $messageIds)
            ->whereNotNull('attachment_id')
            ->value('attachment_id');
    }

    protected static function attachmentIdsFor(WaAiConfirmation $note, array $entry, int $index): array
    {
        $ids      = array_values(array_filter((array) ($entry['attachment_ids'] ?? [])));
        $assigned = static::waitingIdsForTarget($note, $index);

        if (empty($assigned)) {
            return $ids;
        }

        $resolved = WaMessage::whereIn('id', $assigned)
            ->whereNotNull('attachment_id')
            ->pluck('attachment_id')
            ->all();

        return array_values(array_unique([...$ids, ...$resolved]));
    }

    protected static function stillMissing(WaAiConfirmation $note): array
    {
        $waiting = static::waitingIds($note);

        if (empty($waiting)) {
            return [];
        }

        return array_values(array_diff($waiting, static::downloadedAmong($waiting)));
    }

    protected static function downloadedAmong(array $messageIds): array
    {
        return WaMessage::whereIn('id', $messageIds)
            ->whereNotNull('attachment_id')
            ->pluck('id')
            ->all();
    }

    protected static function targetStillExists(array $target): bool
    {
        $table    = $target['table_name'] ?? null;
        $recordId = $target['record_id'] ?? null;

        if (empty($table) || empty($recordId)) {
            return false;
        }

        return DB::table($table)->where('id', $recordId)->exists();
    }

    protected static function messageFor(WaAiConfirmation $note, array $outcome): string
    {
        $messages = $note->payload['completion_messages'] ?? [];

        if ($outcome['copied'] > 0 && $outcome['skipped'] === 0) {
            return (string) ($messages['success'] ?? '');
        }

        if ($outcome['copied'] > 0) {
            return (string) ($messages['partial'] ?? $messages['failed'] ?? '');
        }

        return (string) ($messages['failed'] ?? '');
    }

    protected static function notify(WaAiConfirmation $note, string $message): void
    {
        if (trim($message) === '') {
            return;
        }

        $conversation = WaConversation::find($note->payload['conversation_id'] ?? '');

        if ($conversation === null) {
            return;
        }

        WhatsAppService::device($conversation->device_id)
            ->sendText($conversation, $message, mode: 'human', typingSpeed: 'fast');
    }

    protected static function isPastDeadline(WaAiConfirmation $note): bool
    {
        $deadline = $note->payload['deadline'] ?? null;

        if (!empty($deadline)) {
            return now()->gt($deadline);
        }

        $waitMinutes = (int) Helper::config('ai.tool_settings.confirmed_media.wait_minutes', 30);

        return $note->updated_at !== null && now()->gt($note->updated_at->addMinutes($waitMinutes));
    }

    protected static function waitingMap(WaAiConfirmation $note): array
    {
        return (array) ($note->payload['waiting'] ?? []);
    }

    protected static function waitingIds(WaAiConfirmation $note): array
    {
        return array_values(array_keys(static::waitingMap($note)));
    }

    protected static function waitingIdsForTarget(WaAiConfirmation $note, int $index): array
    {
        return array_values(array_keys(array_filter(
            static::waitingMap($note),
            fn ($targetIndex) => (int) $targetIndex === $index,
        )));
    }

    protected static function failedIds(WaAiConfirmation $note): array
    {
        return array_values(array_filter((array) ($note->payload['failed'] ?? [])));
    }
}
