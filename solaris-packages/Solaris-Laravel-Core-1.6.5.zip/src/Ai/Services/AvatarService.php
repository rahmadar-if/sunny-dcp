<?php

namespace Solaris\Core\Ai\Services;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Models\Attachment;
use Solaris\Core\Repositories\AttachmentRepository;

class AvatarService
{
    public static function setFromAttachment(Model $model, string $column, string $sourceAttachmentId): void
    {
        $source = Attachment::findOrFail($sourceAttachmentId);
        $folder = (new \ReflectionClass($model))->getShortName();

        $attachment = AttachmentRepository::copyToRecord($source, folder: $folder);

        $oldId             = $model->{$column};
        $model->{$column}  = $attachment->id;
        $model->save();

        if ($oldId) {
            app(AttachmentRepository::class)->delete($oldId);
        }
    }
}
