<?php

namespace Solaris\Core\Ai\Services;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Solaris\Core\Helpers\UserCache;
use Solaris\Core\Interfaces\Model\SolarisRoles;
use Solaris\Core\Interfaces\Model\SolarisUser;
use Solaris\Core\Models\AiAgent;
use Solaris\Core\Models\AiTool;

class AiAccessService
{
    public static function accessibleAgentIds(Authenticatable&SolarisUser&SolarisRoles $user): Collection
    {
        return static::grantedIds($user, 'user_ai_agents', 'role_ai_agents', 'permission_ai_agents', 'agent_id');
    }

    public static function accessibleToolIds(Authenticatable&SolarisUser&SolarisRoles $user): Collection
    {
        return static::grantedIds($user, 'user_ai_tools', 'role_ai_tools', 'permission_ai_tools', 'tool_id');
    }

    public static function toolsFor(string $agentSlug, Authenticatable&SolarisUser&SolarisRoles $user): Collection
    {
        $agent = AiAgent::where('slug', $agentSlug)->first();

        if ($agent === null) {
            return collect();
        }

        if (!UserCache::aiAgents($user)->contains($agent->id)) {
            return collect();
        }

        return $agent->tools()->whereIn('ai_tools.id', UserCache::aiTools($user))->get();
    }

    public static function canAccessTool(Authenticatable&SolarisUser&SolarisRoles $user, string $slug): bool
    {
        $tool = AiTool::where('slug', $slug)->first();

        return $tool !== null && UserCache::aiTools($user)->contains($tool->id);
    }

    public static function canAccessAgent(Authenticatable&SolarisUser&SolarisRoles $user, string $slug): bool
    {
        $agent = AiAgent::where('slug', $slug)->first();

        return $agent !== null && UserCache::aiAgents($user)->contains($agent->id);
    }

    protected static function grantedIds(Authenticatable&SolarisUser&SolarisRoles $user, string $userTable, string $roleTable, string $permissionTable, string $column): Collection
    {
        $roleIds       = UserCache::roles($user)->pluck('id')->all();
        $permissionIds = UserCache::allPermissions($user)->pluck('id')->all();

        $viaUser       = DB::table($userTable)->select($column)->where('user_id', $user->id);
        $viaRole       = DB::table($roleTable)->select($column)->whereIn('role_id', $roleIds);
        $viaPermission = DB::table($permissionTable)->select($column)->whereIn('permission_id', $permissionIds);

        return collect(
            DB::query()
                ->fromSub($viaUser->unionAll($viaRole)->unionAll($viaPermission), 'combined')
                ->select($column)
                ->distinct()
                ->pluck($column)
        );
    }
}
