<?php

namespace Solaris\Core\Ai\Attributes;

use Attribute;

#[Attribute]
class AiEssential {}
