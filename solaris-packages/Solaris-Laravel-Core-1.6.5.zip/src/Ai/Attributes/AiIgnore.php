<?php

namespace Solaris\Core\Ai\Attributes;

use Attribute;

#[Attribute(Attribute::TARGET_CLASS)]
class AiIgnore {}
