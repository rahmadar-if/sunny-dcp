<?php

namespace Solaris\Core\Ai\Data;

use Illuminate\Support\Carbon;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\Number;
use Solaris\Core\Interfaces\Model\SolarisModel;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Models\Profile;

class AiProfileData
{
    public function __construct(
        public readonly ?string $name,
        public readonly ?string $nickname,
        public readonly ?string $salutation,
        public readonly ?string $username,
        public readonly ?string $email,
        public readonly ?string $phoneNumber,
        public readonly ?string $gender,
        public readonly ?string $birthdate,
        public readonly ?string $birthplace,
        public readonly ?string $religion,
        public readonly ?string $address,
        public readonly ?string $country,
        public readonly ?string $province,
        public readonly ?string $city,
        public readonly ?string $district,
        public readonly ?string $subDistrict,
        public readonly ?string $postcode,
        public readonly array $roles,
        public readonly ?string $emailVerifiedAt,
        public readonly bool $mobileAccess,
        public readonly array $twoFactor,
        public readonly array $sso,
        public readonly array $notifications,
        public readonly array $storage,
    ) {}

    public static function fromProfile(Profile $profile): self
    {
        $user     = $profile->user;
        $timezone = $profile->timezone ?: 'UTC';

        return new self(
            name:            $profile->name,
            nickname:        $profile->nickname,
            salutation:      static::display($profile->salutation),
            username:        $user?->username,
            email:           $profile->email,
            phoneNumber:     $profile->phone_number,
            gender:          static::display($profile->gender),
            birthdate:       static::date($profile->birthdate, 'Y-m-d'),
            birthplace:      $profile->birthplace,
            religion:        static::display($profile->religion),
            address:         $profile->address,
            country:         static::display($profile->country),
            province:        static::display($profile->province),
            city:            static::display($profile->city),
            district:        static::display($profile->district),
            subDistrict:     static::display($profile->sub_district),
            postcode:        $profile->postcode,
            roles:           collect($profile->roles)
                ->map(fn ($role) => static::display($role))
                ->filter()
                ->values()
                ->all(),
            emailVerifiedAt: static::date($user?->email_verified_at, timezone: $timezone),
            mobileAccess:    (bool) $user?->is_mobile_access,
            twoFactor:       [
                'enabled' => $user?->two_factor_confirmed_at !== null,
                'method'  => static::twoFactorMethod($user?->two_factor_method),
                'since'   => static::date($user?->two_factor_confirmed_at, 'Y-m-d', $timezone),
            ],
            sso:             collect($profile->sso ?? [])
                ->filter()
                ->keys()
                ->all(),
            notifications:   [
                'push'   => (bool) $user?->is_push_notification,
                'email'  => (bool) $user?->is_email_notification,
                'app'    => (bool) $user?->is_app_notification,
                'mobile' => (bool) $user?->is_mobile_notification,
            ],
            storage:         static::storage($profile),
        );
    }

    public function toArray(): array
    {
        return [
            'identity' => [
                'name'       => $this->name,
                'nickname'   => $this->nickname,
                'salutation' => $this->salutation,
                'username'   => $this->username,
            ],
            'contact' => [
                'email'        => $this->email,
                'phone_number' => $this->phoneNumber,
                'address'      => $this->address,
                'country'      => $this->country,
                'province'     => $this->province,
                'city'         => $this->city,
                'district'     => $this->district,
                'sub_district' => $this->subDistrict,
                'postcode'     => $this->postcode,
            ],
            'personal' => [
                'gender'     => $this->gender,
                'birthdate'  => $this->birthdate,
                'birthplace' => $this->birthplace,
                'religion'   => $this->religion,
            ],
            'account' => [
                'roles'             => $this->roles,
                'email_verified_at' => $this->emailVerifiedAt,
                'mobile_access'     => $this->mobileAccess,
                'two_factor'        => $this->twoFactor,
                'sso'               => $this->sso,
            ],
            'notifications' => $this->notifications,
            'storage'       => $this->storage,
        ];
    }

    private static function storage(Profile $profile): array
    {
        $usedRaw   = (int) $profile->total_uploaded_size_raw;
        $quotaRaw  = (int) Helper::config('attachment.max_size', 0);
        $remaining = max($quotaRaw - $usedRaw, 0);
        $percent   = $quotaRaw > 0 ? min(100.0, round($usedRaw / $quotaRaw * 100, 2)) : 0.0;

        return [
            'total_file'   => (int) $profile->total_file,
            'used'         => $profile->total_uploaded_size,
            'used_percent' => $percent,
            'quota'        => Number::getHumanReadableSize($quotaRaw),
            'remaining'    => Number::getHumanReadableSize($remaining),
        ];
    }

    private static function twoFactorMethod(?string $method): ?string
    {
        if ($method === null) {
            return null;
        }

        return $method === 'totp' ? 'Authenticator App' : 'Email OTP';
    }

    private static function display(BaseModel|SolarisModel|null $model): ?string
    {
        if ($model === null) {
            return null;
        }

        return $model->getDisplayValue() ?? $model->name;
    }

    private static function date(mixed $value, string $format = 'Y-m-d H:i:s', ?string $timezone = null): ?string
    {
        if ($value === null) {
            return null;
        }

        $date = Carbon::parse($value);

        if ($timezone !== null) {
            $date = $date->setTimezone($timezone);
        }

        return $date->format($format);
    }
}
