<?php

namespace Solaris\Core\Ai\Agents;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use Laravel\Ai\Contracts\Agent;
use Laravel\Ai\Contracts\Conversational;
use Laravel\Ai\Contracts\HasTools;
use RuntimeException;
use Solaris\Core\Ai\Concerns\HasProviderFailover;
use Solaris\Core\Ai\Exceptions\AiAuthorizationException;
use Solaris\Core\Ai\Services\AiAccessService;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Ai\Tools\NeedsAgent;
use Solaris\Core\Ai\Tools\NeedsToolState;
use Solaris\Core\Ai\Tools\NeedsUser;
use Solaris\Core\Ai\Tools\ToolTurnState;
use Solaris\Core\Models\AiTool;

abstract class BaseAiAgent implements Agent, Conversational, HasTools
{
    use HasProviderFailover;

    protected Authenticatable $user;
    protected bool $ownsAuthState = false;

    protected bool $recoveryMode = false;

    protected ?Collection $accessibleToolsCache = null;

    protected ToolTurnState $toolTurnState;

    public function __construct(?Authenticatable $user = null)
    {
        $existing = Auth::user();

        if ($existing !== null) {
            $this->user = $existing;
        } elseif ($user !== null) {
            $this->user = $user;
            Auth::setUser($user);
            $this->ownsAuthState = true;
        } else {
            throw new RuntimeException(static::class . ' requires a user — Auth is empty and none was passed.');
        }

        if (!AiAccessService::canAccessAgent($this->user, static::slug())) {
            throw new AiAuthorizationException(static::class . ' is not accessible to the current user.');
        }

        $this->toolTurnState = new ToolTurnState();
    }

    abstract public static function slug(): string;

    abstract protected function buildInstructions(): string;

    public final function instructions(): string
    {
        $instructions = $this->buildInstructions();

        if ($this->isDelegateTarget()) {
            $instructions .= "\n\n" . static::delegateOutputInstructions();
        }

        $hasSearchTool = $this->accessibleTools()->contains(fn (AiTool $tool) => is_a($tool->class, BaseSearchTool::class, true));

        return $hasSearchTool ? $instructions . "\n\n" . BaseSearchTool::filterInstructions() : $instructions;
    }

    // False for the orchestrator (it speaks to the user) and for the extraction agents, whose output
    // must stay in the user's own language because it IS the user's message.
    protected function isDelegateTarget(): bool
    {
        return true;
    }

    protected static function delegateOutputInstructions(): string
    {
        return <<<TXT
        # OUTPUT CONTRACT
        Your reply is read by another agent, never by a human. Always write it in English, whatever
        language the task arrived in — the agent reading you handles the user's language itself.
        Return only what was asked for, compactly: the values, one line each. No preamble, no
        restating the task, no commentary on how you searched or which spelling matched.
        Compactness never outranks completeness: report every failure, every missing field, every
        pending confirmation and every partial result in full. Omitting a problem to stay short is
        the one thing that makes your answer useless.
        A task may arrive with a FINDINGS block holding what other specialists already retrieved this
        turn. Those values are established fact — use them directly instead of looking them up again,
        and never widen your task on their account.
        TXT;
    }

    public static function essentialToolClasses(): array
    {
        return [];
    }

    public function withRecoveryMode(): static
    {
        $this->recoveryMode = true;

        return $this;
    }

    public function tools(): iterable
    {
        if ($this->recoveryMode) {
            return [];
        }

        return $this->accessibleTools()
            ->map(fn (AiTool $tool) => $this->resolveTool($tool->class))
            ->all();
    }

    protected function accessibleTools(): Collection
    {
        return $this->accessibleToolsCache ??= AiAccessService::toolsFor(static::slug(), $this->user);
    }

    protected function resolveTool(string $class): object
    {
        $instance = new $class();

        if ($instance instanceof NeedsUser) {
            $instance->setUser($this->user);
        }

        if ($instance instanceof NeedsAgent) {
            $instance->setAgentSlug(static::slug());
        }

        if ($instance instanceof NeedsToolState) {
            $instance->setToolState($this->toolTurnState);
        }

        return $instance;
    }
}
