<?php

namespace Solaris\Core\Ai\Agents;

use Laravel\Ai\Concerns\RemembersConversations;
use Laravel\Ai\Promptable;
use Laravel\Ai\Responses\AgentResponse;

class ImageExtractionAgent extends BaseAiAgent
{
	use Promptable, RemembersConversations;

	public static function slug(): string
	{
		return 'image_extraction';
	}

	// Its output carries the image's own text back to the orchestrator — forcing English would translate
	// away the very content the user sent.
	protected function isDelegateTarget(): bool
	{
		return false;
	}

	protected function buildInstructions(): string
	{
		return <<<TXT
		You are a data extraction assistant. You receive one or more images plus a task description.
		Read the images carefully and extract exactly what the task asks for.
		Respond with valid JSON only — no markdown, no code fences, no explanation text before or after.
		If a requested field is not visible or not present in the image, omit it or leave it empty; never invent data.
		TXT;
	}

	public function tools(): iterable
	{
		return [];
	}

	public function provider(): array
	{
		return $this->resolveProviderChain('ai.agent_providers.image_extraction.providers');
	}

	public function timeout(): int
	{
		return 120;
	}

	public function read(string $task, array $images): AgentResponse
	{
		return $this->forUser($this->user)->prompt($task, attachments: $images);
	}

	public function decode(string $response): ?array
	{
		$text = trim($response);

		if (str_starts_with($text, '```')) {
			$text = trim(preg_replace('/^```[a-zA-Z]*\s*|\s*```$/', '', $text));
		}

		$decoded = json_decode($text, true);

		return is_array($decoded) ? $decoded : null;
	}
}
