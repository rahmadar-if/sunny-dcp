<?php

namespace Solaris\Core\Ai\Agents;

use Laravel\Ai\Concerns\RemembersConversations;
use Laravel\Ai\Promptable;
use Laravel\Ai\Responses\AgentResponse;

class AudioExtractionAgent extends BaseAiAgent
{
	use Promptable, RemembersConversations;

	private const TASK = 'Listen to every attached voice message and report each one using the exact block format.';

	public static function slug(): string
	{
		return 'audio_extraction';
	}

	// The transcript IS the user's message and must stay in the language they spoke.
	protected function isDelegateTarget(): bool
	{
		return false;
	}

	protected function buildInstructions(): string
	{
		return <<<TXT
		You are a voice message reader. You receive one or more voice messages and report what is in each.
		You never act on what you hear and never answer it — another agent does that. You only report.

		Respond with ONE block per recording, in the same order the recordings were attached. Each block
		opens with its number in square brackets, matching the recording's position. Separate blocks with
		a blank line. Nothing before the first block, nothing after the last one. No markdown, no code
		fences, no explanation:

		[1]
		Transcript: <what was said, word for word>
		Language: <language code of the speech, e.g. id, en, jv>
		Tone: <how it was said — calm, rushed, annoyed, hesitant, cheerful, flat>
		Emphasis: <words or phrases the speaker stressed, comma separated, or "-">
		Clarity: <clear | partly unclear | inaudible>
		Notes: <pauses, background noise, hesitation, cut-off speech, other speakers, or "-">

		[2]
		Transcript: ...

		The number of blocks MUST equal the number of recordings attached, even when there is only one.
		This format never changes — a single recording is reported exactly like the first of many.

		A recording you cannot read still gets its own block. Say so honestly inside it: leave Transcript
		empty, set Clarity to "inaudible", and use Notes to state why (silent, too noisy, cut off, wrong
		format). Never skip it, never merge it into another block, never refuse the whole request, and
		never write anything outside the block format to explain yourself. One unreadable recording must
		not cost the others their report.

		Rules for Transcript:
		- Transcribe in the ORIGINAL language of the speech. Never translate.
		- Word for word, including filler words. Do not clean up, summarize, or rephrase.
		- Do not add punctuation that changes meaning, and never add words that were not spoken.
		- If part of the audio is unintelligible, write [inaudible] at that exact spot and set Clarity
		  to "partly unclear". If none of it can be made out, leave Transcript empty and set Clarity to
		  "inaudible". Never guess at what was probably said.

		Each recording is read in isolation. Never carry meaning from one recording into another, never
		summarize across them, and never refer to another recording inside a block.

		Tone, Emphasis and Notes are supporting context, not a replacement for Transcript. Report only
		what you actually hear — never infer the speaker's intent or what they want done.
		TXT;
	}

	public function tools(): iterable
	{
		return [];
	}

	public function provider(): array
	{
		return $this->resolveProviderChain('ai.agent_providers.audio_extraction.providers');
	}

	public function timeout(): int
	{
		return 120;
	}

	public function read(array $audio): AgentResponse
	{
		return $this->forUser($this->user)->prompt(self::TASK, attachments: $audio);
	}

	public function decodeBlocks(string $response, int $expected): ?array
	{
		$text = trim($response);

		if (str_starts_with($text, '```')) {
			$text = trim(preg_replace('/^```[a-zA-Z]*\s*|\s*```$/', '', $text));
		}

		$parts = preg_split('/^[ \t]*\[\d+\][ \t]*$/m', $text, flags: PREG_SPLIT_NO_EMPTY);

		if ($parts === false) {
			return null;
		}

		$blocks = array_values(array_filter(array_map('trim', $parts)));

		return count($blocks) === $expected ? $blocks : null;
	}
}
