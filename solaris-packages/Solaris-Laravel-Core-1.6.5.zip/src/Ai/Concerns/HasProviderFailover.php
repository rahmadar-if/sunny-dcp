<?php

namespace Solaris\Core\Ai\Concerns;

use Solaris\Core\Helpers\Helper;

trait HasProviderFailover
{
	protected function resolveProviderChain(string $configKey): array
	{
		$chain = [];

		foreach (Helper::config($configKey, []) as $provider => $model) {
			if (empty(config("ai.providers.{$provider}.key"))) {
				continue;
			}

			$chain[$provider] = $model;
		}

		return $chain !== [] ? $chain : [config('ai.default', 'openai') => null];
	}
}
