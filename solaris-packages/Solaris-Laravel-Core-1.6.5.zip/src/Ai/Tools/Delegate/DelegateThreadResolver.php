<?php

namespace Solaris\Core\Ai\Tools\Delegate;

interface DelegateThreadResolver
{
	public function resolve(string $slug): ?string;

	public function remember(string $slug, string $conversationId): void;
}
