<?php

namespace Solaris\Core\Ai\Tools\Delegate;

use Illuminate\Support\Str;

class DelegateTurnState
{
	private const RESULT_MAX_CHARS = 600;

	private array $counts = [];

	private array $errors = [];

	private array $results = [];

	public function __construct(private readonly int $cap)
	{
	}

	public function cap(): int
	{
		return $this->cap;
	}

	public function count(string $specialist): int
	{
		return $this->counts[$specialist] ?? 0;
	}

	public function increment(string $specialist): void
	{
		$this->counts[$specialist] = $this->count($specialist) + 1;
	}

	public function markError(string $specialist, string $signature): void
	{
		$this->errors[$specialist . '|' . $signature] = true;
	}

	public function hasError(string $specialist, string $signature): bool
	{
		return isset($this->errors[$specialist . '|' . $signature]);
	}

	public function recordResult(string $specialist, string $result): void
	{
		$result = trim($result);

		if ($result === '') {
			return;
		}

		$this->results[$specialist] = Str::limit($result, self::RESULT_MAX_CHARS);
	}

	public function results(?string $except = null): array
	{
		if ($except === null) {
			return $this->results;
		}

		return array_diff_key($this->results, [$except => true]);
	}
}
