<?php

namespace Solaris\Core\Ai\Tools\Delegate;

use Solaris\Core\Models\WaConversation;

class WaDelegateThreadResolver implements DelegateThreadResolver
{
	private array $threads;

	public function __construct(private readonly WaConversation $conversation)
	{
		$this->threads = $conversation->ai_agent_threads ?? [];
	}

	public function resolve(string $slug): ?string
	{
		return $this->threads[$slug] ?? null;
	}

	public function remember(string $slug, string $conversationId): void
	{
		$this->threads[$slug] = $conversationId;

		WaConversation::where('id', $this->conversation->id)
			->update(['ai_agent_threads' => json_encode($this->threads, JSON_UNESCAPED_UNICODE)]);
	}
}
