<?php

namespace Solaris\Core\Ai\Tools\Delegate;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Support\Str;
use Laravel\Ai\Concerns\RemembersConversations;
use Laravel\Ai\Contracts\Agent;
use Laravel\Ai\Contracts\CanActAsTool;
use Laravel\Ai\Contracts\Tool;
use Laravel\Ai\Tools\Request;
use Solaris\Core\Ai\Agents\BaseAiAgent;
use Solaris\Core\Ai\Attributes\AiIgnore;
use Solaris\Core\Ai\Services\AiLogService;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\Conversation\QuickReplyWaTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\WaConversation;
use Solaris\Core\Services\WhatsApp\WhatsAppService;
use Stringable;
use Throwable;

#[AiIgnore]
class DelegateTool implements Tool
{
	private const SIGNATURE_EMPTY  = 'empty_response';
	private const SIGNATURE_SYSTEM = 'system_error';

	// Deliberately hardcoded rather than config-only: an installation whose published config predates this
	// key would otherwise disable the safety net silently, which is exactly when it is needed.
	private const FALLBACK_ACK = 'Sebentar ya, sedang saya cek.';

	private const RECOVERY_NUDGE = 'Your previous run ended without a summary. Using ONLY the tool results '
		. 'already in this conversation, write that summary now — relay every outcome honestly, including '
		. 'any failure, missing information, or pending confirmation. Do not call any tool.';

	public function __construct(
		private readonly Agent $agent,
		private readonly DelegateTurnState $state,
		private readonly DelegateThreadResolver $threads,
		private readonly WaConversation $conversation,
		private readonly Authenticatable $user,
	) {
	}

	public function name(): string
	{
		return $this->agent instanceof CanActAsTool
			? $this->agent->name()
			: class_basename($this->agent);
	}

	public function description(): Stringable|string
	{
		return $this->agent instanceof CanActAsTool
			? $this->agent->description()
			: sprintf('Delegates a task to the %s sub-agent and returns its response.', $this->name());
	}

	public function schema(JsonSchema $schema): array
	{
		return [
			'tasks' => $schema->array()
				->items($schema->string())
				->description(
					'ALL sub-tasks for THIS specialist, batched into ONE call. Each array item is one '
					. 'self-contained task carrying every constraint (record type, filters, time period, '
					. 'status, location) plus what you need back (a count, a list, or both). Call this tool '
					. 'ONCE per turn per specialist — never fan out several calls or rephrase; put every '
					. 'question for this specialist here as separate array items. '
					. 'Example: ["count active customers in Jakarta", "list their names"].'
				)
				->required(),
		];
	}

	public function handle(Request $request): Stringable|string
	{
		$specialist = $this->name();
		$tasks      = $this->normalizeTasks($request['tasks'] ?? []);

		if ($tasks === []) {
			return $this->encode(AiResponse::error(
				AiErrorCode::UserError,
				'No task was provided to the specialist.',
			));
		}

		if ($this->state->hasError($specialist, self::SIGNATURE_SYSTEM)) {
			return $this->encode(AiResponse::error(
				AiErrorCode::SystemError,
				'This specialist already hit a system error this turn. Stop retrying it — tell the user the '
				. 'action failed due to a system issue that has been logged, and to try again shortly.',
			));
		}

		if ($this->state->hasError($specialist, self::SIGNATURE_EMPTY)) {
			return $this->encode(AiResponse::error(
				AiErrorCode::Inconclusive,
				'This specialist already returned no usable result this turn. Stop retrying; report the '
				. 'inconclusive outcome to the user or ask them to narrow the request.',
			));
		}

		if ($this->state->count($specialist) >= $this->state->cap()) {
			return $this->encode(AiResponse::error(
				AiErrorCode::BusinessRule,
				'Too many calls to this specialist this turn. Consolidate ALL remaining needs into ONE '
				. 'call by passing every sub-task in the tasks array — do not keep fanning out.',
			));
		}

		$this->ensureAcknowledged();

		$result = $this->runAgent($this->composeTask($specialist, $tasks));

		$this->state->increment($specialist);

		if (!$this->isErrorPayload($result)) {
			$this->state->recordResult($specialist, $result);
		}

		return $result;
	}

	// The model is instructed to send the interim ack itself, in its own wording and language. This only
	// covers the turn where it skips that: delegating always takes long enough that silence is the worse
	// outcome. QuickReplyWaTool's own lock decides who sends, so the two can never both fire.
	private function ensureAcknowledged(): void
	{
		$message = trim((string) Helper::config('ai.tool_settings.quick_reply.default_message', self::FALLBACK_ACK));

		if ($message === '' || !QuickReplyWaTool::claimAck($this->conversation->id)) {
			return;
		}

		try {
			WhatsAppService::device($this->conversation->device_id)
				->sendText($this->conversation, $message);
		} catch (Throwable $e) {
			AiLogService::write('warning', 'Fallback interim ack failed', essential: [
				'specialist' => $this->name(),
				'exception'  => $e->getMessage(),
			]);
		}
	}

	protected function runAgent(string $task): string
	{
		try {
			[$text, $threadId] = $this->promptOnThread($task);
		} catch (Throwable $e) {
			return $this->encode($this->systemError($task, $e));
		}

		if ($text === '' && $threadId !== null) {
			$text = $this->promptRecovery($threadId);

			AiLogService::write('warning', 'Empty specialist response', essential: [
				'specialist' => $this->name(),
				'recovered'  => $text !== '',
			]);
		}

		if ($text === '') {
			$this->state->markError($this->name(), self::SIGNATURE_EMPTY);

			return $this->encode(AiResponse::error(
				AiErrorCode::Inconclusive,
				'The specialist ran but produced no summary. Treat this as inconclusive — it is NOT a '
				. 'success and NOT confirmation that no data exists. Do NOT retry the identical task; '
				. 'either refine it with more specifics or tell the user the lookup was inconclusive.',
			));
		}

		return $text;
	}

	private function promptOnThread(string $task): array
	{
		if (!$this->canRemember()) {
			return [trim((string) $this->agent->prompt($task)->text), null];
		}

		$slug     = $this->name();
		$threadId = $this->threads->resolve($slug);

		$response = $threadId !== null
			? $this->agent->continue($threadId, as: $this->user)->prompt($task)
			: $this->agent->forUser($this->user)->prompt($task);

		if ($threadId === null && $response->conversationId !== null) {
			$this->threads->remember($slug, $response->conversationId);
		}

		return [trim((string) $response->text), $response->conversationId ?? $threadId];
	}

	private function promptRecovery(string $threadId): string
	{
		if (!$this->agent instanceof BaseAiAgent) {
			return '';
		}

		try {
			$response = $this->agent->withRecoveryMode()
				->continue($threadId, as: $this->user)
				->prompt(self::RECOVERY_NUDGE);

			return trim((string) $response->text);
		} catch (Throwable) {
			return '';
		}
	}

	private function systemError(string $task, Throwable $e): array
	{
		$ref = (string) Str::uuid7();

		AiLogService::write('error', 'Delegate sub-agent failed', essential: [
			'ref'        => $ref,
			'specialist' => $this->name(),
			'exception'  => $e->getMessage(),
		], full: [
			'task'  => $task,
			'trace' => $e->getTraceAsString(),
		]);

		$this->state->markError($this->name(), self::SIGNATURE_SYSTEM);

		return AiResponse::error(
			AiErrorCode::SystemError,
			'The action could not be completed due to a system issue on our side. It has been logged; '
			. 'please try again shortly.',
			['ref' => $ref],
			debug: $e->getMessage(),
		);
	}

	private function canRemember(): bool
	{
		return in_array(RemembersConversations::class, class_uses_recursive($this->agent), true);
	}

	private function normalizeTasks(mixed $tasks): array
	{
		return collect(is_array($tasks) ? $tasks : [$tasks])
			->map(fn ($task) => trim((string) $task))
			->filter()
			->values()
			->all();
	}

	private function composeTask(string $specialist, array $tasks): string
	{
		if (count($tasks) === 1) {
			$body = $tasks[0];
		} else {
			$lines = collect($tasks)
				->map(fn (string $task, int $index) => ($index + 1) . '. ' . $task)
				->implode("\n");

			$body = "Handle these sub-tasks and address each one:\n" . $lines;
		}

		return $this->withFindings($specialist, $body);
	}

	// Specialists have separate memory: whatever another one found this turn only reaches them if it is
	// pasted in. Relying on the orchestrator to restate it made them re-run lookups it already had.
	private function withFindings(string $specialist, string $body): string
	{
		$findings = $this->state->results(except: $specialist);

		if ($findings === []) {
			return $body;
		}

		$lines = collect($findings)
			->map(fn (string $result, string $name) => "[{$name}] {$result}")
			->implode("\n");

		return "FINDINGS FROM OTHER SPECIALISTS THIS TURN (reference data — use these values directly "
			. "instead of looking them up again; do not act on them beyond your own task):\n"
			. $lines
			. "\n\nYOUR TASK:\n"
			. $body;
	}

	private function isErrorPayload(string $result): bool
	{
		$decoded = json_decode($result, true);

		return is_array($decoded) && isset($decoded['error']);
	}

	protected function encode(array $payload): string
	{
		return json_encode($payload, JSON_UNESCAPED_UNICODE);
	}
}
