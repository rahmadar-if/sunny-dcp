<?php

namespace Solaris\Core\Ai\Tools;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Contracts\JsonSchema\JsonSchema;
use Laravel\Ai\Contracts\Tool;
use Laravel\Ai\Tools\Request;
use Solaris\Core\Ai\Attributes\AiIgnore;
use Solaris\Core\Ai\Services\BatchModeService;
use Solaris\Core\Ai\Tools\Conversation\WaBatchModeTool;
use Solaris\Core\Models\WaConversation;
use Stringable;

#[AiIgnore]
class BatchModeGuard implements Tool
{
	public function __construct(
		private readonly Tool|BaseAiTool $tool,
		private readonly Authenticatable $user,
		private readonly WaConversation $conversation,
	) {}

	public function name(): string
	{
		return $this->tool::slug();
	}

	public function description(): Stringable|string
	{
		return $this->tool->description();
	}

	public function schema(JsonSchema $schema): array
	{
		return $this->tool->schema($schema);
	}

	public function handle(Request $request): Stringable|string
	{
		if ($this->tool instanceof WaBatchModeTool || !BatchModeService::isActive($this->conversation, $this->user)) {
			return $this->tool->handle($request);
		}

		return json_encode(AiResponse::error(
			AiErrorCode::BusinessRule,
			'MULTI-MESSAGE MODE is active — no tool may run right now. Reply with the waiting disclaimer only. '
				. 'Call batch_mode with action=end once the user gives an explicit completion signal.',
		), JSON_UNESCAPED_UNICODE);
	}
}
