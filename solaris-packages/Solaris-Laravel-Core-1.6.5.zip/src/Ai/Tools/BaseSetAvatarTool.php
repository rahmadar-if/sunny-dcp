<?php

namespace Solaris\Core\Ai\Tools;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Database\Eloquent\Model;
use Laravel\Ai\Tools\Request;
use Solaris\Core\Ai\Services\AvatarService;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Models\Attachment;
use Solaris\Core\Models\WaMessage;

abstract class BaseSetAvatarTool extends BaseConfirmAiTool
{
	use HasDeferredMedia;

	abstract protected function targetModel(): Model;

	abstract protected function targetColumn(): string;

	public function schema(JsonSchema $schema): array
	{
		return array_merge($this->confirmationSchema($schema), [
			'attachment_id' => $schema->string()->description(
				'The id of an already-uploaded attachment to use as the profile picture. Omit only when the '
				. 'photo is still downloading — then pass pending_media_id instead.'
			),
			'pending_media_id' => $schema->string()->description(
				'The pending_media_id wa_media_tool returned when the photo is still downloading. The user '
				. 'confirms now, and the photo is applied on its own once the download finishes.'
			),
			'completion_messages' => $schema->object([
				'success' => $schema->string()->description('The photo was applied.')->required(),
				'failed'  => $schema->string()->description('The photo could not be downloaded.')->required(),
			])->description(
				'Closing lines sent AFTER your turn ends, once the still-downloading photo lands. Write them in '
				. 'the user\'s language, one short line each. Always fill both; if the photo turns out to be '
				. 'ready, they simply go unused.'
			)->required(),
		]);
	}

	public function validateConfirmation(Request $request): array
	{
		$attachmentId = trim((string) ($request['attachment_id'] ?? ''));
		$pendingId    = trim((string) ($request['pending_media_id'] ?? ''));

		if ($attachmentId === '' && $pendingId === '') {
			return AiResponse::error(AiErrorCode::UserError, 'Pass either attachment_id or pending_media_id.');
		}

		if ($attachmentId !== '' && !Attachment::where('id', $attachmentId)->exists()) {
			return AiResponse::error(AiErrorCode::NotFound, 'This attachment does not exist.');
		}

		$model = $this->targetModel();

		return [
			'payload' => [
				'attachment_id'       => $attachmentId === '' ? null : $attachmentId,
				'waiting'             => $pendingId === '' ? [] : [$pendingId => 0],
				'completion_messages' => $this->completionMessages($request),
				'avatar'              => [
					'model'  => $model::class,
					'id'     => $model->getKey(),
					'column' => $this->targetColumn(),
				],
			],
			'summary' => $pendingId === '' ? [] : ['photo' => 'still downloading'],
		];
	}

	private function absorbAvatarMedia(array $payload): array
	{
		$waiting = (array) ($payload['waiting'] ?? []);

		if (empty($waiting)) {
			return $payload;
		}

		$attachmentId = WaMessage::whereIn('id', array_keys($waiting))
			->whereNotNull('attachment_id')
			->value('attachment_id');

		if ($attachmentId === null) {
			return $payload;
		}

		$payload['attachment_id'] = $attachmentId;
		$payload['waiting']       = [];

		return $payload;
	}

	public function executeConfirmed(Request $request, array $payload): array
	{
		$payload = $this->absorbAvatarMedia($payload);

		if (!empty($payload['waiting'])) {
			return $this->parkForMedia(
				$request,
				$payload,
				'Tell the user immediately, in their language, that the photo is still downloading and will be '
					. 'applied on its own once ready. Do not call this tool again for it.',
			);
		}

		if (empty($payload['attachment_id'])) {
			return AiResponse::error(AiErrorCode::NotFound, 'The photo is no longer available. Ask the user to resend it.');
		}

		AvatarService::setFromAttachment($this->targetModel(), $this->targetColumn(), $payload['attachment_id']);

		return AiResponse::success(
			['message' => $this->successMessage()],
			instruction: 'Reply to the user immediately with a brief one-line confirmation in their language.',
		);
	}

	protected function successMessage(): string
	{
		return 'Photo updated.';
	}
}
