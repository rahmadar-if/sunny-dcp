<?php

namespace Solaris\Core\Ai\Tools;

use Carbon\Carbon;
use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Str;
use Laravel\Ai\Tools\Request;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Services\FilterDsl\DslException;
use Solaris\Core\Interfaces\Model\SolarisLookup;
use Solaris\Core\Models\AiTool;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Services\Filter;
use Stringable;

abstract class BaseSearchTool extends BaseAiTool implements AiSearchable
{
	use HasSearchLookup;

	// How small a scope has to be before listing it whole is worth doing, when a search matched nothing and
	// the model is asked to recognise the record instead. Above this the list is not shown at all: an
	// arbitrary window presented as "the available records" made agents conclude — and tell the user —
	// that nothing existed among N records when they had only ever seen a fraction of them.
	private const BROWSE_LIMIT = 25;

	abstract protected function resourceLabel(): string;

	abstract protected function model(): BaseModel;

	abstract protected function fields(): array;

	abstract protected function formatRecord(Model $record): array;

	protected function descriptionExtra(): ?string
	{
		return null;
	}

	protected function auditFields(): array
	{
		return [
			'created_at'    => AiSearchColumn::datetime('created_at', 'Date and time this record was created (created on).'),
			'updated_at'    => AiSearchColumn::datetime('updated_at', 'Date and time this record was last updated (updated on, last modified).'),
			'created_by_id' => AiSearchColumn::reference(
				'created_by_id',
				'The user who created this record — the record\'s owner/creator. If this resource has its '
				. 'own deal/team assignment field (e.g. an opportunity\'s sales team), that is a separate '
				. 'concept from who originally created the record.',
				modelKey: 'user',
			),
			'updated_by_id' => AiSearchColumn::reference('updated_by_id', 'The user who last updated this record.', modelKey: 'user'),
		];
	}

	protected function auditFormat(Model $record): array
	{
		return [
			'created_at' => $record->created_at ? Carbon::parse($record->created_at)->format('d M Y') : null,
        	'updated_at' => $record->updated_at ? Carbon::parse($record->updated_at)->format('d M Y') : null,
			'created_by' => $record->created_by?->name,
			'updated_by' => $record->updated_by?->name,
		];
	}

	private function allFields(): array
	{
		return array_merge($this->auditFields(), $this->fields());
	}

	protected function relations(): array
	{
		return [];
	}

	public static function filterInstructions(): string
	{
		return <<<TXT
		# PROCEDURE — follow in order, every time
		1. Read the instruction. List each thing asked for. Two independent questions = two searches.
		2. Does it name any lookup/reference VALUE (a category, status, type, or the name of another record
		   it points to)? Filters match on ids, never on names. Resolve them ALL in ONE lookup_options call —
		   it takes an array, so batch every value you need in a single round trip.
		3. Pick the tool for the resource being ASKED ABOUT. "Accounts that have X" -> the account search tool, even
		   though X describes an activity.
		4. Build the `filter` string (see FILTER LANGUAGE). Conditions about a related record go in ONE
		   HAS(...) group.
		5. Only a number is wanted? Use the `aggregate` param. A list of records? Normal search.
		6. Call the tool ONCE. On an "error" result, fix what it says and retry — an error is never "no
		   results found". The error message tells you exactly what to fix and the position in your filter.

		# FILTER LANGUAGE
		The `filter` param is ONE plain string, written like a SQL WHERE clause. Not JSON.

		Comparison   col = "v"   col != "v"   col > 5   col >= 5   col < 5   col <= 5
		Text         name CONTAINS "jon"   name STARTS_WITH "jo"   name ENDS_WITH "hn"
		Fuzzy        name SIMILAR "jon"   (add THRESHOLD 0.4 to loosen)     Full text: notes FULLTEXT "erp"
		Set / range  type_id IN ["a","b"]   type_id NOT_IN [...]   age BETWEEN 1 AND 10
		Null / empty col IS_NULL   col IS_NOT_NULL   col IS_EMPTY   col IS_NOT_EMPTY
		Date period  created_at IS_TODAY | IS_THIS_WEEK | IS_LAST_MONTH | IS_THIS_YEAR | ...
		             created_at IS_LAST 7 DAYS      created_at IS_NEXT 3 MONTHS
		Logic        cond AND cond      cond OR cond      ( ... ) to group
		Relation     relation HAS (conditions about that relation, columns written BARE)
		             relation HAS_NO (conditions)   — has NO matching related record
		             relation HAS_NONE              — has no related record at all
		             relation HAS_ANY               — has at least one related record (no condition)
		Aggregate    COUNT(relation) >= 3    SUM(relation.column) > 1000000

		RULES:
		- Every VALUE is quoted ("...") except plain numbers, TRUE/FALSE, and [lists].
		- Lookup/reference columns need the ID (quote it): some_id = "<id from lookup_options>".
		- Use ONE HAS(...) when 2+ conditions must hold on the SAME related record.
		- Keywords may be any case; column names come from # COLUMNS / # RELATIONS in the tool description.

		# SEARCH vs FILTER
		`search` = free-text over [searchable] columns. `filter` = precise conditions. Combine both freely.
		For "named like / similar to / typo", prefer `filter` with SIMILAR (and OR CONTAINS) on the name
		column. Reach for plain `search` only for open-ended keyword hunts. Put 2-3 keyword variations into
		`search_synonyms` in the SAME call — OR-combined, one call replaces several narrow ones.

		# COUNTS
		Need ONLY a number or a breakdown -> the `aggregate` param.
		Need rows, OR a count AND examples together -> ONE normal search. `total_count` is the true total,
		`results` is the capped sample. Never spend a second call on `aggregate` for a total already handed.

		# AGGREGATION & SUPERLATIVES
		"Biggest / most / best / top / paling banyak / terlaris / terbesar" — and their opposites — are
		aggregate questions, never list questions. Follow this exactly:
		1. Find where the NUMBER lives. It is almost never on the entity being asked about: an account's
		   revenue lives on invoices, a product's sales live on order/invoice line items. Pick the tool
		   that owns the number, then group by that tool's reference column pointing at the asked-about
		   entity. "Which account has the most revenue" -> the invoice search tool, NOT the account search tool.
		2. One entity usually owns MANY rows there, so its value is the SUM of them — never the single
		   largest row. Ranking raw rows answers "which invoice is biggest", a different question.
		3. Ask for the ranking itself: `aggregate` with group_by + direction + a small limit. Example:
		   filter: status_id = "<paid status id>" AND completed_at IS_THIS_YEAR
		   aggregate: {function: sum, column: amount, group_by: ["account_id"], direction: desc, limit: 5}
		4. NEVER rank from `results`. That list is a capped, unordered sample — ordering it yourself
		   produces a confident answer built on rows the database never promised were the top ones.
		   Only `aggregate` breakdowns and `total_count` carry authority.
		5. `truncated: true` means groups exist past your limit. Report it as a top-N, never as the
		   complete picture, and never total up those rows as if they were everything.

		# STATE YOUR CRITERIA
		A number is only useful when the reader knows what went into it. So whenever your answer rests on
		a decision YOU made — an `aggregate` value, a ranking, or any filter you chose that was not spelled
		out in the instruction you were given — end with ONE short sentence naming: what was counted, which
		records qualified, which date it was measured on, and how it was combined.
		Write it for the person who asked, in THEIR words — never in column names. This sentence exists to
		be checked by someone who has never seen the schema; a column name they cannot interpret gives them
		nothing to disagree with, which defeats the entire purpose.
		  NO:  "From invoices with status_id = Completed, summed by account_id on completed_at this year."
		  YES: "From paid invoices, totalled per customer by their payment date this year."
		It must describe the filter you ACTUALLY sent, not what you meant to send — read back your own
		call before writing it. A criteria sentence that flatters a wrong filter is worse than none: it
		converts a correctable mistake into a trusted one.
		Skip it entirely when nothing was decided for the user: a literal lookup by name, an instruction
		that already stated every condition, or a single unambiguous record.

		# DATE & TIME
		Relative wording in any language ("hari ini", "minggu ini", "bulan lalu") -> use the matching period
		operator. They resolve to correct boundaries on the server — no date arithmetic, no
		get_current_datetime call needed for them. Call get_current_datetime only when an actual calendar
		date must appear in your reply.

		# HARD RULES
		1. Records, ids, and counts come from tool results only. Nothing matched -> say so plainly.
		2. An "error" result means the call failed — report it as a failed search, never as "not found".
		3. The rows a tool returns ALREADY satisfy every filter you sent. Report ALL of them. Never drop,
		   re-rank, or re-judge a returned row from its name or any field — that overrides the filter you
		   built with a guess. If the set looks wrong, fix the FILTER and search again.
		TXT;
	}

	protected function execute(Request $request): Stringable|string
	{
		return json_encode($this->search($request->all()), JSON_UNESCAPED_UNICODE);
	}

	public function search(array $params): array
	{
		try {
			$allFilters = $this->resolveFilters($params);
		} catch (DslException $e) {
			return AiResponse::error(AiErrorCode::UserError, $e->getMessage());
		}

		$errors = [];

		$this->validateFilterRelations($allFilters, $errors);
		$this->validateFilterIds($allFilters, $errors);

		if (!empty($errors)) {
			return AiResponse::error(
				AiErrorCode::UserError,
				'One or more filter values could not be resolved.',
				['details' => $errors],
			);
		}

		$sortErrors = [];
		$this->validateSort($params, $sortErrors);

		if (!empty($sortErrors)) {
			return AiResponse::error(AiErrorCode::UserError, 'One or more sort columns are invalid.', ['details' => $sortErrors]);
		}

		$allFilters = $this->mergeBaseFilters($allFilters);

		if (isset($params['aggregate'])) {
			return $this->resolveAggregate((array) $params['aggregate'], $allFilters);
		}

		try {
			return $this->runSearch($params, $allFilters);
		} catch (\Throwable $e) {
			return AiResponse::error(AiErrorCode::SystemError, 'The search could not be completed due to a system issue.', debug: $e->getMessage());
		}
	}

	protected function baseFilters(): array
	{
		return [];
	}

	protected function baseFilterLabel(): ?string
	{
		return null;
	}

	private function mergeBaseFilters(array $userFilters): array
	{
		$base = $this->baseFilters();

		if ($base === []) {
			return $userFilters;
		}

		if ($userFilters === []) {
			return $base;
		}

		return array_merge($base, [['logical' => 'AND', 'conditions' => $userFilters]]);
	}

	private function resolveFilters(array $params): array
	{
		if (isset($params['filter']) && is_string($params['filter']) && trim($params['filter']) !== '') {
			return Filter::fromString($params['filter'], array_keys($this->allFields()))->get();
		}

		return isset($params['filters']) ? (array) $params['filters'] : [];
	}

	private function runSearch(array $params, array $allFilters): array
	{
		$search   = isset($params['search']) ? trim((string) $params['search']) : null;
		$synonyms = isset($params['search_synonyms']) ? (array) $params['search_synonyms'] : [];
		$limit    = min((int) ($params['limit'] ?? 10), 20);

		$searchTerms = collect([$search, ...$synonyms])
			->map(fn ($term) => trim((string) $term))
			->filter()
			->unique()
			->values();

		$searchableColumns = $this->searchableColumns();
		$sortOrders        = $this->sortOrders($params);

		$query = $this->model()
			->newQuery()
			->prepared(array_keys($this->allFields()))
			->when(!empty($allFilters), fn ($q) => $q->filter($allFilters))
			->when($searchTerms->isNotEmpty(), fn ($q) => $q->where(
				fn ($outer) => $searchTerms->each(
					fn ($term) => $outer->orWhere(fn ($inner) => $inner->search($term, $searchableColumns))
				)
			))
			->when(!empty($sortOrders), fn ($q) => $q->sort($sortOrders));

		$totalCount = (clone $query)->count();
		$results    = $query->limit($limit)->get();

		if ($results->isEmpty() && $searchTerms->isNotEmpty()) {
			$browseQuery = $this->model()
				->newQuery()
				->prepared(array_keys($this->allFields()))
				->when(!empty($allFilters), fn ($q) => $q->filter($allFilters))
				->when(!empty($sortOrders), fn ($q) => $q->sort($sortOrders));

			$browsedTotal = (clone $browseQuery)->count();

			if ($browsedTotal > 0 && $browsedTotal > self::BROWSE_LIMIT) {
				return [
					'results'      => [],
					'count'        => 0,
					'total_count'  => $browsedTotal,
					'search_note'  => "No match for '{$searchTerms->implode(', ')}'. {$browsedTotal} records exist in "
						. 'scope — too many to review one by one.',
					'_instruction' => 'Nothing matched. Do NOT search this resource again with reworded terms or '
						. 'synonyms: the terms are not the problem, and repeating the search cannot change the '
						. 'outcome. Report that nothing matched, and ask for the exact name/spelling or a narrowing '
						. 'detail (a city, a category, an owner) that can be filtered on.',
				];
			}

			$browsed = $browseQuery->limit(self::BROWSE_LIMIT)->get();

			if ($browsed->isNotEmpty()) {
				return [
					'results'      => $browsed->map(fn ($r) => $this->trimForListing($this->identityOnly($this->formatRecord($r))))->values()->all(),
					'count'        => $browsed->count(),
					'total_count'  => $browsedTotal,
					'search_note'  => "No match for '{$searchTerms->implode(', ')}'. Listing ALL {$browsedTotal} records "
						. 'in scope, identifying fields only, for semantic matching.',
					'_instruction' => 'No match was found even after trying multiple keywords. This is the COMPLETE '
						. "list in scope — review it and identify which record best matches the user's intent by "
						. 'meaning, not exact wording. Only identifying fields are shown: if one is relevant, call '
						. 'this tool again with a filter on its exact id (left: "id") to fetch its full detail. If '
						. 'none is relevant, say so — and do not search again with other words, you have now seen '
						. 'everything there is.',
				];
			}
		}

		$count = $results->count();

		$instruction = $count > 1
			? 'Multiple records found. Present each result to the user using readable fields only '
				. '(name, type, status, date, or any other distinguishing info available) — never expose _id. '
				. 'Ask the user to confirm which one they mean before taking any action. '
				. 'Only proceed with update/delete/read after the user explicitly picks one.'
			: 'Use _id fields internally only for subsequent tools (update/delete/read). '
				. 'Never expose _id to the user — present results using readable fields only.';

		$payload = [
			'results'      => $results
				->map(fn ($r) => array_merge($this->auditFormat($r), $this->formatRecord($r)))
				->map(fn ($record) => $count > 1 ? $this->trimForListing($record) : $record)
				->values()
				->all(),
			'count'        => $count,
			'total_count'  => $totalCount,
			'_instruction' => $instruction,
		];

		$scope = $this->baseFilterLabel();

		if ($count === 0 && $scope !== null) {
			$payload['scope_note']   = $scope;
			$payload['_instruction'] = "Nothing matched WITHIN this tool's built-in scope. {$scope} Say that "
				. 'plainly, naming the scope — a record kept out by it is NOT the same as a record that does '
				. 'not exist, and reporting this as "not found" would state something untrue about their data.';
		}

		return $payload;
	}

	private function resolveAggregate(array $aggregate, array $allFilters): array
	{
		$function = strtolower((string) ($aggregate['function'] ?? ''));

		if (!in_array($function, ['count', 'sum', 'avg', 'min', 'max'], true)) {
			return AiResponse::error(AiErrorCode::UserError, "Unsupported aggregate function '{$function}'. Use count, sum, avg, min, or max.");
		}

		$fields = $this->allFields();
		$column = $aggregate['column'] ?? null;

		if ($column !== null && !isset($fields[$column])) {
			return AiResponse::error(AiErrorCode::UserError, "Column '{$column}' is not aggregatable on this resource.");
		}

		if ($function !== 'count' && $column === null) {
			return AiResponse::error(AiErrorCode::UserError, "Aggregate function '{$function}' requires a column.");
		}

		$groupBy       = array_values(array_unique((array) ($aggregate['group_by'] ?? [])));
		$direction     = strtolower((string) ($aggregate['direction'] ?? 'desc')) === 'asc' ? 'asc' : 'desc';
		$limit         = min(max((int) ($aggregate['limit'] ?? 20), 1), 50);
		$invalidGroups = [];

		foreach ($groupBy as $groupColumn) {
			$def = $fields[$groupColumn] ?? null;

			if ($def === null || !in_array($def->type, [AiColumnType::Lookup, AiColumnType::Reference, AiColumnType::Boolean], true)) {
				$invalidGroups[] = $groupColumn;
			}
		}

		if (!empty($invalidGroups)) {
			return AiResponse::error(
				AiErrorCode::UserError,
				'group_by only supports lookup/reference/boolean columns from this resource\'s own column list — free-text or date columns have unbounded breakdowns.',
				['columns' => $invalidGroups],
			);
		}

		try {
			$query = $this->model()
				->newQuery()
				->when(!empty($allFilters), fn ($q) => $q->filter($allFilters));

			if (empty($groupBy)) {
				$value = $function === 'count' ? $query->count() : $query->{$function}($column);

				return AiResponse::success(['aggregate' => ['function' => $function, 'column' => $column, 'value' => $value]]);
			}

			$expression = $function === 'count' ? 'count(*)' : "{$function}({$column})";

			$rows = $query
				->select($groupBy)
				->selectRaw("{$expression} as aggregate_value")
				->groupBy($groupBy)
				->orderBy('aggregate_value', $direction)
				->limit($limit + 1)
				->get();
		} catch (\Throwable $e) {
			return AiResponse::error(AiErrorCode::SystemError, 'The aggregate could not be computed due to a system issue.', debug: $e->getMessage());
		}

		$truncated = $rows->count() > $limit;

		$breakdown = $rows->take($limit)->map(function ($row) use ($groupBy, $fields) {
			$group = [];

			foreach ($groupBy as $groupColumn) {
				$group += $this->formatGroupKey($fields[$groupColumn], $groupColumn, $row->{$groupColumn});
			}

			$value = $row->aggregate_value;

			return ['group' => $group, 'value' => is_numeric($value) ? $value + 0 : $value];
		})->values()->all();

		$payload = [
			'aggregate' => [
				'function'  => $function,
				'column'    => $column,
				'group_by'  => $groupBy,
				'direction' => $direction,
				'breakdown' => $breakdown,
				'truncated' => $truncated,
			],
		];

		$notes = ['Each group already carries the resolved NAME — do not call another tool to look it up '
			. 'or "confirm" it, that costs a step and tells you nothing new. The matching "_" key holds '
			. 'its id, ready for any follow-up that needs one; never show that id to the user.'];

		if ($truncated) {
			$notes[] = "Only the top {$limit} groups are shown, ordered {$direction} — more groups exist "
				. "beyond this cut. Present it as a top-{$limit}, never as the complete list, and never "
				. 'state a total derived from these rows alone.';
		}

		return AiResponse::success($payload, instruction: implode(' ', $notes));
	}

	private function formatGroupKey(AiSearchColumn $def, string $column, mixed $raw): array
	{
		$isReference = in_array($def->type, [AiColumnType::Lookup, AiColumnType::Reference], true);

		if (!$isReference || !str_ends_with($column, '_id')) {
			return [$column => $this->resolveGroupLabel($def, $raw)];
		}

		return [
			'_' . $column          => $raw,
			substr($column, 0, -3) => $this->resolveGroupLabel($def, $raw),
		];
	}

	private function resolveGroupLabel(AiSearchColumn $columnDef, mixed $value): mixed
	{
		if ($value === null) {
			return null;
		}

		if ($columnDef->type === AiColumnType::Lookup && !empty($columnDef->modelKey)) {
			$class = Helper::model($columnDef->modelKey);

			if ($class !== null && is_a($class, SolarisLookup::class, true)) {
				$option = $class::toLookup()->firstWhere('id', $value);

				return $option?->getDisplayValue() ?? $option?->name ?? $value;
			}
		}

		if ($columnDef->type === AiColumnType::Reference && !empty($columnDef->modelKey)) {
			$class  = Helper::model($columnDef->modelKey);
			$record = $class !== null ? $class::find($value) : null;

			if ($record !== null) {
				$displayColumn = method_exists($record, 'getDisplayValueName') ? $record->getDisplayValueName() : null;

				return $displayColumn ? $record->{$displayColumn} : $value;
			}
		}

		return $value;
	}

	// The browse fallback exists so the model can recognise a record it could not spell. Only the fields it
	// could recognise it by are useful there — sending every column of every row was the single largest
	// payload in a failed search, and none of it was read.
	private function identityOnly(array $record): array
	{
		$keep = collect($this->fields())
			->filter(fn (AiSearchColumn $def) => $def->searchable)
			->keys()
			->push('name')
			->all();

		return collect($record)
			->filter(fn ($value, string $key) => $key === '_id' || in_array($key, $keep, true))
			->all();
	}

	private function trimForListing(array $record): array
	{
		return array_map(
			fn ($value) => is_string($value) && mb_strlen($value) > 200 ? mb_substr($value, 0, 200) . '…' : $value,
			$record
		);
	}

	public final function description(): Stringable|string
	{
		$colLines = [];
		foreach ($this->allFields() as $field => $def) {
			$ops        = implode(', ', array_map([self::class, 'operatorLabel'], $def->operators));
			$searchable = $def->searchable ? ' [searchable]' : '';
			$sortable   = $this->isSortable($def) ? ' [sortable]' : '';
			$keyHint    = $this->resolutionHint($def);

			$colLines[] = "  - {$field} ({$def->type->value}){$searchable}{$sortable}: {$def->description}.{$keyHint} Operators: {$ops}.";
		}

		$description = "Search and retrieve {$this->resourceLabel()}.\n\n";

		$scope = $this->baseFilterLabel();

		if ($scope !== null) {
			$description .= "# SCOPE (ALWAYS APPLIED)\n{$scope} This is enforced on the server and applies to "
				. "every call, including aggregates — you cannot widen or switch it off, and records outside "
				. "it will never appear here no matter what you filter on.\n\n";
		}

		$description .= "# COLUMNS\n" . implode("\n", $colLines)
			. $this->relationsBlock();

		$extra = $this->descriptionExtra();

		if ($extra !== null) {
			$description .= "\n\n" . $extra;
		}

		return $description;
	}

	private static function operatorLabel(string $operator): string
	{
		return match ($operator) {
			Filter::IsLastN => 'IS_LAST <n> DAYS|WEEKS|MONTHS|YEARS',
			Filter::IsNextN => 'IS_NEXT <n> DAYS|WEEKS|MONTHS|YEARS',
			default         => $operator,
		};
	}

	private function resolutionHint(AiSearchColumn $def): string
	{
		if ($def->modelKey === null) {
			return '';
		}

		if ($def->type === AiColumnType::Lookup) {
			return " Resolve via lookup_options with type: \"{$def->modelKey}\".";
		}

		if ($def->type !== AiColumnType::Reference || str_contains($def->description, 'search tool')) {
			return '';
		}

		$resource = str_replace('_', ' ', $def->modelKey);

		return " Resolve this id with the {$resource} search tool available to you first.";
	}

	private function relationsBlock(): string
	{
		$relations = $this->relations();

		if (empty($relations)) {
			return '';
		}

		$lines = [];

		foreach ($relations as $name => $target) {
			$peer = is_string($target) ? static::peerTool($target) : null;

			if ($peer === null) {
				$lines[] = "  - {$name}: {$target}";
				continue;
			}

			$lines[] = "  - {$name} -> {$peer->resourceLabel()}\n"
				. '    filterable: ' . static::compactColumns($peer->allFields());
		}

		return "\n\n# RELATIONS (for relation-group and aggregate-condition filters ONLY)\n"
			. "The ONLY valid values for `relation`, or for `conditions.left` in an aggregate-condition "
			. "filter. Columns listed under a relation are the ones filterable INSIDE that relation-group, "
			. "written bare (no relation prefix):\n"
			. implode("\n", $lines);
	}

	protected static function compactColumns(array $fields): string
	{
		$parts = [];

		foreach ($fields as $field => $def) {
			$key = ($def->modelKey !== null && in_array($def->type, [AiColumnType::Lookup, AiColumnType::Reference], true))
				? ":{$def->modelKey}"
				: '';

			$parts[] = "{$field}({$def->type->value}{$key})";
		}

		return implode(' ', $parts);
	}

	protected static function peerTool(string $slugOrClass): ?self
	{
		$toolClass = AiTool::where('slug', $slugOrClass)->value('class') ?? $slugOrClass;

		if (!is_a($toolClass, self::class, true)) {
			return null;
		}

		$instance = new $toolClass();

		return $instance instanceof self ? $instance : null;
	}

	public final function schema(JsonSchema $schema): array
	{
		return [
			'search'          => $schema->string()->description('Free-text search across [searchable] columns.'),
			'search_synonyms' => $schema->array()->items($schema->string())->description(
				'Extra keyword variations, OR-ed with `search` in this same call.'
			),
			'filter' => $schema->string()->description(
				'Filter expression string (see FILTER LANGUAGE in the agent instructions). Shape: '
				. 'some_column = "value" AND some_relation HAS (related_column = "value"). Column and relation '
				. 'names come from # COLUMNS / # RELATIONS below.'
			),
			'limit'     => $schema->integer()->description('Max rows. Default 10, max 20.'),
			'sort'      => $schema->string()->description(
				'Order the results, written like a SQL ORDER BY clause: "column direction, column2 direction2". '
				. 'direction is asc or desc (default asc). The first column has the highest priority, the rest '
				. 'break ties. Use ONLY columns marked [sortable] in # COLUMNS. Example: "amount desc, created_at asc".'
			),
			'aggregate' => $schema->object([
				'function' => $schema->string()->enum(['count', 'sum', 'avg', 'min', 'max'])->description('Required.'),
				'column'   => $schema->string()->description('Required for sum/avg/min/max, unused for count.'),
				'group_by' => $schema->array()->items($schema->string())->description(
					'Break the aggregate down by these columns. Lookup/reference/boolean columns only.'
				),
				'direction' => $schema->string()->enum(['asc', 'desc'])->description(
					'Orders the group_by breakdown by the computed value. Default desc (highest first) — '
					. 'use asc for "lowest/fewest". Ignored without group_by.'
				),
				'limit' => $schema->integer()->description(
					'Max groups in the breakdown. Default 20, max 50. For a "top N" question ask for N '
					. 'directly (e.g. 5) — the breakdown is already ordered, so a small limit is the answer, '
					. 'not a sample to re-rank. Ignored without group_by.'
				),
			])->description(
				'Returns a computed number INSTEAD of rows. Use whenever only a count/total is needed. '
				. '`filter` still scopes what gets aggregated.'
			),
		];
	}

	private function searchableColumns(): array
	{
		$columns = [];

		foreach ($this->allFields() as $column => $def) {
			if (empty($def->searchable)) {
				continue;
			}

			if (is_string($def->searchable)) {
				$columns[$column] = $def->searchable;
			} else {
				$columns[] = $column;
			}
		}

		return $columns;
	}

	private function parseSortString(mixed $sort): array
	{
		if (!is_string($sort) || trim($sort) === '') {
			return [];
		}

		$orders = [];

		foreach (explode(',', $sort) as $piece) {
			$piece = trim($piece);

			if ($piece === '') {
				continue;
			}

			$bits      = preg_split('/\s+/', $piece);
			$direction = strtolower($bits[1] ?? 'asc') === 'desc' ? 'desc' : 'asc';

			$orders[] = ['column' => $bits[0], 'direction' => $direction];
		}

		return $orders;
	}

	private function sortOrders(array $params): array
	{
		$fields = $this->allFields();
		$orders = [];

		foreach ($this->parseSortString($params['sort'] ?? null) as $order) {
			$def    = $fields[$order['column']] ?? null;
			$target = $def !== null ? $this->sortTarget($def) : null;

			if ($target === null) {
				continue;
			}

			$orders[] = ['column' => $target, 'direction' => $order['direction']];
		}

		return $orders;
	}

	private function validateSort(array $params, array &$errors): void
	{
		$fields   = $this->allFields();
		$sortable = array_keys(array_filter($fields, fn (AiSearchColumn $def) => $this->isSortable($def)));

		foreach ($this->parseSortString($params['sort'] ?? null) as $order) {
			$def = $fields[$order['column']] ?? null;

			if ($def === null) {
				$errors[] = [
					'field'   => $order['column'],
					'message' => "'{$order['column']}' is not a column on this resource.",
					'options' => $sortable,
				];
				continue;
			}

			if (!$this->isSortable($def)) {
				$errors[] = [
					'field'   => $order['column'],
					'message' => "'{$order['column']}' is not sortable on this resource.",
					'options' => $sortable,
				];
			}
		}
	}

	private function isSortable(AiSearchColumn $def): bool
	{
		if (!in_array($def->type, [AiColumnType::Lookup, AiColumnType::Reference], true)) {
			return true;
		}

		if ($def->sortColumn !== null) {
			return true;
		}

		$model = $this->model();

		return $model::isLookupBelongsTo($def->column, $model);
	}

	private function sortTarget(AiSearchColumn $def): ?string
	{
		if (!in_array($def->type, [AiColumnType::Lookup, AiColumnType::Reference], true)) {
			return $def->column;
		}

		if ($def->sortColumn !== null) {
			return $def->sortColumn;
		}

		$model  = $this->model();
		$lookup = $model::getLookup($def->column, $model);

		if ($lookup === null || !($lookup->relation instanceof BelongsTo)) {
			return null;
		}

		$target = $lookup->model->getDisplayValueName() ?? 'name';

		return "{$lookup->name}.{$target}";
	}

	private function validateFilterRelations(array $filters, array &$errors): void
	{
		$model = $this->model();
		$known = array_keys($this->relations());

		foreach ($filters as $filter) {
			if (isset($filter['relation'])) {
				$relation = (string) $filter['relation'];
				$relation = str_ends_with($relation, '_id') ? substr($relation, 0, -3) : $relation;

				if (!method_exists($model, $relation)) {
					$errors[] = [
						'field'   => $filter['relation'],
						'message' => "Relation '{$filter['relation']}' does not exist on this resource.",
						'options' => $known,
					];
				}

				continue;
			}

			if (isset($filter['conditions']) && is_array($filter['conditions']) && array_is_list($filter['conditions'])) {
				$this->validateFilterRelations($filter['conditions'], $errors);
				continue;
			}

			if (isset($filter['aggregate'])) {
				$left = $filter['conditions']['left'] ?? null;

				if (is_string($left)) {
					$relation = str_contains($left, '.') ? explode('.', $left)[0] : $left;

					if (!method_exists($model, $relation)) {
						$errors[] = [
							'field'   => $left,
							'message' => "Relation '{$relation}' does not exist on this resource — required by "
								. 'the aggregate-condition filter (the `aggregate` key inside `filters`).',
							'options' => $known,
						];
					}
				}
			}
		}
	}

	private function validateFilterIds(array $filters, array &$errors): void
	{
		$this->validateFilterColumns($filters, $this->allFields(), null, $errors);
	}

	private function validateFilterColumns(array $filters, array $fields, ?string $relation, array &$errors): void
	{
		foreach ($filters as $filter) {
			if (isset($filter['relation'])) {
				$this->validateRelationGroupColumns($filter, $errors);
				continue;
			}

			if (isset($filter['conditions']) && is_array($filter['conditions']) && array_is_list($filter['conditions'])) {
				$this->validateFilterColumns($filter['conditions'], $fields, $relation, $errors);
				continue;
			}

			if (isset($filter['aggregate'])) {
				continue;
			}

			$left = $filter['conditions']['left'] ?? null;

			if (!is_string($left)) {
				continue;
			}

			if (str_contains($left, '.')) {
				$this->reportPrefixedRelationColumn($left, $relation, $errors);
				continue;
			}

			$col = $fields[$left] ?? null;

			if ($col === null) {
				$this->reportUnknownRelationColumn($left, $relation, $fields, $errors);
				continue;
			}

			if (!in_array($col->type, [AiColumnType::Lookup, AiColumnType::Reference], true)) {
				continue;
			}

			$this->reportNonIdValues($filter, $left, $relation, $errors);
		}
	}

	private function validateRelationGroupColumns(array $filter, array &$errors): void
	{
		$relations = $this->relations();
		$name      = (string) $filter['relation'];
		$stripped  = str_ends_with($name, '_id') ? substr($name, 0, -3) : $name;
		$target    = $relations[$name] ?? $relations[$stripped] ?? null;
		$peer      = is_string($target) ? static::peerTool($target) : null;
		$nested    = $filter['conditions'] ?? [];

		if ($peer === null || !is_array($nested) || !array_is_list($nested)) {
			return;
		}

		$this->validateFilterColumns($nested, $peer->allFields(), $stripped, $errors);
	}

	private function reportUnknownRelationColumn(string $left, ?string $relation, array $fields, array &$errors): void
	{
		if ($relation === null || $left === 'id') {
			return;
		}

		$errors[] = [
			'field'   => "{$relation}.{$left}",
			'message' => "'{$left}' is not a filterable column on the '{$relation}' relation. Use one of the "
				. 'columns listed under that relation in # RELATIONS, written bare (no relation prefix).',
			'options' => array_keys($fields),
		];
	}

	private function reportPrefixedRelationColumn(string $left, ?string $relation, array &$errors): void
	{
		if ($relation === null) {
			return;
		}

		$bare = substr($left, strrpos($left, '.') + 1);

		$errors[] = [
			'field'   => $left,
			'message' => "Inside the '{$relation}' relation-group, write the column bare as '{$bare}' — the "
				. 'conditions are already scoped to that relation.',
		];
	}

	private function reportNonIdValues(array $filter, string $left, ?string $relation, array &$errors): void
	{
		$right  = $filter['conditions']['right'] ?? null;
		$values = is_array($right) && array_is_list($right) ? $right : [$right];
		$field  = $relation === null ? $left : "{$relation}.{$left}";

		foreach ($values as $value) {
			if (!is_string($value) || $value === '' || Str::isUuid($value)) {
				continue;
			}

			$errors[] = [
				'field'   => $field,
				'message' => "'{$value}' is not a valid id for '{$left}' — it looks like a human-readable "
					. 'name. Resolve it to its id first via lookup_options (lookup columns) or the '
					. 'matching search_* tool (reference columns), then pass the id here.',
			];
		}
	}
}
