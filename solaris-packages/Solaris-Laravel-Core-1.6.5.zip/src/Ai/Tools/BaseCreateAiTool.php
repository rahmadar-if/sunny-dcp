<?php

namespace Solaris\Core\Ai\Tools;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Contracts\Validation\Validator as ValidatorContract;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Validator;
use Laravel\Ai\Tools\Request;
use Stringable;

abstract class BaseCreateAiTool extends BaseConfirmAiTool
{
	abstract protected function resourceLabel(): string;

	abstract public static function fields(JsonSchema $schema): array;

	abstract protected function rules(): array;

	abstract protected function create(array $validated, array $raw): array;

	protected function descriptionExtra(): ?string
	{
		return null;
	}

	protected function beforeCreate(array $data, array $raw): array { return $data; }

	protected function afterCreate(Model $record, array $raw): void { }

	protected function validateDetailList(array $items, array $rules, string $parentKey, string $parentId): array
	{
		$validated = [];
		$errors    = [];

		foreach (array_values($items) as $index => $item) {
			$validator = Validator::make(array_merge((array) $item, [$parentKey => $parentId]), $rules);

			if ($validator->fails()) {
				$errors[] = "#{$index}: " . implode(' ', $validator->errors()->all());
				continue;
			}

			$validated[] = $validator->validated();
		}

		return [$validated, $errors];
	}

	protected function beforeValidation(array $data): array
	{
		return $data;
	}

	protected function afterValidation(ValidatorContract $validator): void
	{
	}

	protected function lookupChecks(): array
	{
		return [];
	}

	public final function description(): Stringable|string
	{
		$resourceLabel = $this->resourceLabel();

		$description = "Create a new {$resourceLabel}. "
			. 'Call this tool NOW as soon as the required fields are gathered — do NOT wait for approval '
			. 'before calling it, and do NOT compose a confirmation message yourself without calling it '
			. 'first. Requires confirmation before creating — see the confirmation protocol. '
			. 'Present the summary this tool returns as a WhatsApp-friendly message: one introductory line '
			. "(e.g. \"Confirm creating {$resourceLabel}:\"), then ONE bullet per field IN THAT SUMMARY using "
			. '*bold* for the field name — e.g. "• *<field>:* <value>". Use exactly the fields the summary '
			. 'contains; never invent, add, or rename a field that is not in the returned summary. '
			. 'Pass ONLY field values the user actually provided or a tool returned this turn — never invent, '
			. 'guess, or auto-fill a value (phone, email, industry, type, address, etc.) the user did not give. '
			. 'This applies with FULL force to free-text fields (notes, needs, description, remarks): writing a '
			. 'plausible sentence for one is fabrication, not helpfulness — it is stored as if the user said it. '
			. 'Never derive a value from another field either, such as reading a date out of a record\'s name. '
			. 'Omit optional fields you do not have; if a REQUIRED field is missing, ask the user for it instead '
			. 'of fabricating one.';

		$extra = $this->descriptionExtra();
		if ($extra !== null) {
			$description .= "\n\n" . $extra;
		}

		return $description;
	}

	public final function schema(JsonSchema $schema): array
	{
		return array_merge(
			$this->confirmationSchema($schema),
			static::fields($schema),
		);
	}

	public function validateConfirmation(Request $request): array
	{
		$data 	   = $this->beforeValidation($request->all(array_keys($this->rules())));
		$validator = Validator::make($data, $this->rules());
		$this->afterValidation($validator);

		if ($validator->fails()) {
			return AiResponse::error(AiErrorCode::UserError, 'Validation failed.', ['messages' => $validator->errors()->all()]);
		}

		$validated = $validator->validated();
		$errors    = [];

		foreach ($this->lookupChecks() as $def) {
			$value = $validated[$def->column] ?? null;

			if ($value === null || $value === '') {
				continue;
			}

			$valid = $def->type === AiColumnType::Lookup
				? $this->lookupExists($def->modelKey, $value)
				: $this->referenceExists($def->modelKey, $value);

			if (!$valid) {
				$errors[] = ['field' => $def->column, 'message' => "'{$value}' is not a valid {$def->label}."];
			}
		}

		if (!empty($errors)) {
			return AiResponse::error(AiErrorCode::UserError, 'One or more fields could not be resolved.', ['details' => $errors]);
		}

		return [
			'payload' => ['validated' => $validated, 'raw' => $data],
			'summary' => $validated,
		];
	}

	public function executeConfirmed(Request $request, array $payload): array
	{
		return $this->create($payload['validated'], $payload['raw']);
	}
}
