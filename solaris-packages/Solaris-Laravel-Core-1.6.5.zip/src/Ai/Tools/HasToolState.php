<?php

namespace Solaris\Core\Ai\Tools;

trait HasToolState
{
	protected ?ToolTurnState $toolState = null;

	public function setToolState(ToolTurnState $state): static
	{
		$this->toolState = $state;

		return $this;
	}
}
