<?php

namespace Solaris\Core\Ai\Tools;

use Solaris\Core\Models\WaConversation;

trait HasWaConversation
{
	protected WaConversation $conversation;

	public function setConversation(WaConversation $conversation): static
	{
		$this->conversation = $conversation;

		return $this;
	}
}
