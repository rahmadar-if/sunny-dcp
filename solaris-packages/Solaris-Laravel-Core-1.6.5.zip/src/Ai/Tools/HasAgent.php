<?php

namespace Solaris\Core\Ai\Tools;

trait HasAgent
{
	protected ?string $agentSlug = null;

	public function setAgentSlug(string $slug): static
	{
		$this->agentSlug = $slug;

		return $this;
	}
}
