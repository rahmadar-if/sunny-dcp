<?php

namespace Solaris\Core\Ai\Tools;

use Illuminate\Contracts\Auth\Authenticatable;

trait HasUser
{
	protected Authenticatable $user;

	public function setUser(Authenticatable $user): static
	{
		$this->user = $user;

		return $this;
	}
}
