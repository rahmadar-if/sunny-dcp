<?php

namespace Solaris\Core\Ai\Tools;

// Per-turn memory of which tool failed with which error code. Shared by every tool of one agent run
// so a tool that keeps returning the same error can be stopped at the runtime level: models proved
// willing to retry an identical failure several times, ending with nonsense arguments.
class ToolTurnState
{
	private array $failures = [];

	public function recordFailure(string $slug, string $errorCode): void
	{
		$key = $slug . '|' . $errorCode;

		$this->failures[$key] = ($this->failures[$key] ?? 0) + 1;
	}

	public function failureCount(string $slug, string $errorCode): int
	{
		return $this->failures[$slug . '|' . $errorCode] ?? 0;
	}

	public function isExhausted(string $slug, string $errorCode, int $limit): bool
	{
		return $this->failureCount($slug, $errorCode) >= $limit;
	}
}
