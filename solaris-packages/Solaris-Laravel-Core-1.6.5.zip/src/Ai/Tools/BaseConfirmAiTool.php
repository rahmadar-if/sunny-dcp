<?php

namespace Solaris\Core\Ai\Tools;

abstract class BaseConfirmAiTool extends BaseAiTool implements ConfirmAiTool
{
	use HasConfirmation;
}
