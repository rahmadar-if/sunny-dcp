<?php

namespace Solaris\Core\Ai\Tools;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Contracts\Validation\Validator as ValidatorContract;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Validator;
use Laravel\Ai\Tools\Request;
use Stringable;

abstract class BaseUpdateAiTool extends BaseConfirmAiTool
{
	abstract protected function resourceLabel(): string;

	abstract public static function fields(JsonSchema $schema): array;

	abstract protected function rules(): array;

	abstract protected function findRecordById(string $id): ?Model;

	abstract protected function currentData(Model $record): array;

	abstract protected function update(Model $record, array $validated, array $changes): array;

	protected function resolveRecordId(Request $request): string
	{
		return trim((string) ($request['id'] ?? ''));
	}

	protected function descriptionExtra(): ?string
	{
		return null;
	}

	protected function beforeUpdate(Model $record, array $data, array $raw): array { return $data; }

	protected function afterUpdate(Model $record, array $changes): void { }

	protected function excludedChangeKeys(): array { return []; }

	protected function resolveDetailOperations(
		array $items,
		string $modelClass,
		array $createRules,
		array $updateRules,
		string $parentKey,
		string $parentId,
	): array {
		$creates = [];
		$updates = [];
		$deletes = [];
		$errors  = [];

		foreach (array_values($items) as $index => $item) {
			$item   = (array) $item;
			$id     = $item['id'] ?? null;
			$fields = collect($item)->except(['id', 'delete'])->all();

			if ($id !== null) {
				$existing = $modelClass::where('id', $id)->where($parentKey, $parentId)->first();

				if ($existing === null) {
					$errors[] = "#{$index}: record not found.";
					continue;
				}

				if (!empty($item['delete'])) {
					$deletes[] = $id;
					continue;
				}

				$validator = Validator::make(array_merge($existing->toArray(), $fields, [$parentKey => $parentId]), $updateRules);

				if ($validator->fails()) {
					$errors[] = "#{$index}: " . implode(' ', $validator->errors()->all());
					continue;
				}

				$updates[$id] = $validator->validated();
				continue;
			}

			$validator = Validator::make(array_merge($fields, [$parentKey => $parentId]), $createRules);

			if ($validator->fails()) {
				$errors[] = "#{$index}: " . implode(' ', $validator->errors()->all());
				continue;
			}

			$creates[] = $validator->validated();
		}

		return [['create' => $creates, 'update' => $updates, 'delete' => $deletes], $errors];
	}

	protected function beforeValidation(Model $record, array $changes): array
	{
		return $changes;
	}

	protected function afterValidation(ValidatorContract $validator): void
	{
	}

	protected function lookupChecks(): array
	{
		return [];
	}

	public final function description(): Stringable|string
	{
		$description = "Update an existing {$this->resourceLabel()}. "
			. 'Only pass the fields the user wants to change. '
			. 'Call this tool NOW as soon as the intended changes are known — do NOT wait for approval '
			. 'before calling it, and do NOT compose a confirmation message yourself without calling it '
			. 'first. Requires confirmation before applying changes — see the confirmation protocol. '
			. 'Present the summary this tool returns as a bullet list: one short introductory line stating '
			. 'what will change, then each field as "• *FieldName:* NewValue". '
			. 'Pass ONLY values the user actually provided or a tool returned this turn — never invent, guess, '
			. 'or auto-fill a value the user did not give. This applies with FULL force to free-text fields '
			. '(notes, needs, description, remarks): writing a plausible sentence for one is fabrication, not '
			. 'helpfulness — it is stored as if the user said it. Never derive a value from another field '
			. 'either. If a needed value is missing, ask the user instead of fabricating one.';

		$extra = $this->descriptionExtra();
		if ($extra !== null) {
			$description .= "\n\n" . $extra;
		}

		return $description;
	}

	public final function schema(JsonSchema $schema): array
	{
		return array_merge(
			$this->confirmationSchema($schema),
			static::fields($schema),
		);
	}

	public function validateConfirmation(Request $request): array
	{
		$id = $this->resolveRecordId($request);

		if ($id === '') {
			return AiResponse::error(AiErrorCode::NotFound, "{$this->resourceLabel()} id is required.");
		}

		$record = $this->findRecordById($id);

		if ($record === null) {
			return AiResponse::error(AiErrorCode::NotFound, "{$this->resourceLabel()} not found.");
		}

		$changes = $this->beforeValidation($record, $request->all(array_keys($this->rules())));

		if (empty($changes)) {
			return AiResponse::error(AiErrorCode::UserError, 'No fields were provided to update.');
		}

		$merged    = array_merge($this->currentData($record), $changes);
		$validator = Validator::make($merged, $this->rules());
		$this->afterValidation($validator);

		if ($validator->fails()) {
			return AiResponse::error(AiErrorCode::UserError, 'Validation failed.', ['messages' => $validator->errors()->all()]);
		}

		$errors = [];

		foreach ($this->lookupChecks() as $def) {
			$value = $changes[$def->column] ?? null;

			if ($value === null || $value === '') {
				continue;
			}

			$valid = $def->type === AiColumnType::Lookup
				? $this->lookupExists($def->modelKey, $value)
				: $this->referenceExists($def->modelKey, $value);

			if (!$valid) {
				$errors[] = ['field' => $def->column, 'message' => "'{$value}' is not a valid {$def->label}."];
			}
		}

		if (!empty($errors)) {
			return AiResponse::error(AiErrorCode::UserError, 'One or more fields could not be resolved.', ['details' => $errors]);
		}

		$displayColumn = method_exists($record, 'getDisplayValueName') ? $record->getDisplayValueName() : null;
		$displayValue  = $displayColumn ? $record->{$displayColumn} : $record->getKey();

		return [
			'payload' => ['id' => $id, 'validated' => $validator->validated(), 'changes' => $changes],
			'summary' => array_merge(['record' => $displayValue], $changes),
		];
	}

	public function executeConfirmed(Request $request, array $payload): array
	{
		$record = $this->findRecordById((string) ($payload['id'] ?? ''));

		if ($record === null) {
			return AiResponse::error(AiErrorCode::NotFound, "{$this->resourceLabel()} not found.");
		}

		return $this->update($record, $payload['validated'], $payload['changes']);
	}
}
