<?php

namespace Solaris\Core\Ai\Tools\Lookup;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
use Laravel\Ai\Tools\Request;
use ReflectionClass;
use Solaris\Core\Ai\Attributes\AiEssential;
use Solaris\Core\Ai\Services\AiAccessService;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\AiSearchable;
use Solaris\Core\Ai\Tools\BaseAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Interfaces\Model\SolarisLookup;
use Solaris\Core\Models\AiTool;
use Solaris\Core\Services\Filter;
use Stringable;

#[AiEssential]
class LookupOptionsTool extends BaseAiTool
{
	private static ?array $cacheLookupMap = null;

	public static function slug(): string
	{
		return 'lookup_options';
	}

	public function description(): Stringable|string
	{
		return 'Resolves a human-readable name to the id it is stored as. MANDATORY before calling any '
			. 'create/update tool that has lookup or reference columns, AND before filtering or searching '
			. 'on one — filter conditions match on ids only, a name passed there never matches. '
			. 'Batch every value you need to resolve in ONE call — never call this once per field. '
			. 'Each item in "lookups" is exactly one of: '
			. '(1) {type} alone — small cached lookup (e.g. gender, salutation, industry, account_type, any '
			. 'activity_* lookup). Returns ALL options. This is the DEFAULT for resolving a name you already '
			. 'know, and one call handles many types — do NOT build a filter for these; '
			. '(2) {type, filter} — a large/reference model with no dedicated search tool. `filter` is a '
			. 'filter expression string (same language as the search tools, e.g. name SIMILAR "<query>" OR '
			. 'name CONTAINS "<query>"); '
			. '(3) {tool, params} — delegate to an existing registered search tool by name (e.g. lookup_region) '
			. 'when one already exists for that resource — it only works if that tool was built to support this.';
	}

	public function schema(JsonSchema $schema): array
	{
		return [
			'lookups' => $schema->array()->items(
				$schema->object([
					'type'    => $schema->string()->description('Model key or class name. Alone = cache lookup. With "filter" = reference lookup.'),
					'filter'  => $schema->string()->description('Filter expression string (see FILTER LANGUAGE) — only with "type", for reference/pagination models.'),
					'tool'    => $schema->string()->description('Registered read-only tool name to delegate to (e.g. lookup_region, the account search tool).'),
					'params'  => $schema->object()->description('Raw params forwarded to "tool".'),
					'limit'   => $schema->integer()->description('Max results for reference lookups. Default 10, max 20.'),
				])
			)->description('Batch every lookup/reference needed before calling the target tool, in ONE call.')->required(),
		];
	}

	protected function execute(Request $request): Stringable|string
	{
		$lookups = (array) ($request['lookups'] ?? []);

		if (empty($lookups)) {
			return json_encode(AiResponse::error(AiErrorCode::UserError, 'lookups is required.'), JSON_UNESCAPED_UNICODE);
		}

		$results = [];

		foreach ($lookups as $item) {
			$key = $item['tool'] ?? $item['type'] ?? null;

			if ($key === null) {
				continue;
			}

			$hasFilter = isset($item['filter']) || isset($item['filters']);

			$results[$key] = match (true) {
				isset($item['tool'])            => $this->resolveViaTool($item),
				isset($item['type']) && $hasFilter => $this->resolveViaFilter($item),
				isset($item['type'])            => $this->resolveViaCache($item),
				default                         => AiResponse::error(AiErrorCode::UserError, "Invalid lookup item for '{$key}'."),
			};
		}

		return json_encode(AiResponse::success(['results' => $results]), JSON_UNESCAPED_UNICODE);
	}

	// Registered keys are only part of the picture: a project declares its own lookups under App\Models
	// without ever touching the model registry, and every other lookup consumer in the app (see
	// LookupManagementController::getLookupModels) discovers them by scanning. Resolving from the registry
	// alone made those project lookups unreachable here while being valid everywhere else.
	private static function cacheLookupMap(): array
	{
		if (static::$cacheLookupMap !== null) {
			return static::$cacheLookupMap;
		}

		$registered = collect((array) Helper::config('model.models', []))
			->filter(fn ($class) => is_string($class) && is_a($class, SolarisLookup::class, true));

		$namespaces = ['App\\Models' => app_path('Models')] + array_reverse((array) Helper::config('model.namespaces', []));
		$discovered = collect();

		foreach ($namespaces as $namespace => $path) {
			Helper::discoverClasses($path, $namespace, fn (ReflectionClass $ref) => $ref->implementsInterface(SolarisLookup::class) && !$ref->isAbstract())
				->each(function (ReflectionClass $ref) use ($discovered) {
					$discovered->put(Str::snake($ref->getShortName()), $ref->getName());
				});
		}

		// Registered keys win: that is the name the rest of the system already uses for the model.
		return static::$cacheLookupMap = $discovered->merge($registered)->all();
	}

	private static function cacheLookupTypes(): array
	{
		return collect(static::cacheLookupMap())->keys()->sort()->values()->all();
	}

	private function resolveViaCache(array $item): array
	{
		$type = $item['type'];

		try {
			$class = Helper::model($type) ?? static::cacheLookupMap()[$type] ?? (class_exists($type) ? $type : null);
		} catch (\Throwable) {
			$class = null;
		}

		if (!$class || !is_a($class, SolarisLookup::class, true)) {
			return AiResponse::error(
				AiErrorCode::UserError,
				"Unknown or invalid cache lookup type '{$type}'. Do not guess another name — the tool you are "
				. 'preparing states the exact type for each of its lookup columns. Valid types are: '
				. implode(', ', static::cacheLookupTypes()) . '.',
			);
		}

		$options = $class::toLookup()
			->map(fn ($option) => ['id' => $option->id, 'name' => $option->getDisplayValue() ?? $option->name])
			->filter(fn (array $option) => $option['name'] !== null)
			->values()
			->all();

		return AiResponse::success(['options' => $options]);
	}

	private function resolveViaFilter(array $item): array
	{
		$type  = $item['type'];
		$limit = min((int) ($item['limit'] ?? 10), 20);

		$class = Helper::model($type) ?? (class_exists($type) ? $type : null);

		if ($class === null || !is_a($class, Model::class, true)) {
			return AiResponse::error(AiErrorCode::UserError, "Unknown model for '{$type}'.");
		}

		try {
			$filters = isset($item['filter']) && is_string($item['filter'])
				? Filter::fromString($item['filter'])->get()
				: (array) ($item['filters'] ?? []);

			$options = $class::query()
				->filter($filters)
				->limit($limit)
				->get()
				->map(fn ($record) => [
					'id'   => $record->getKey(),
					'name' => method_exists($record, 'getDisplayValue') ? $record->getDisplayValue() : null,
				])
				->all();
		} catch (\Throwable $e) {
			return AiResponse::error(AiErrorCode::SystemError, 'The filter could not be applied due to a system issue.', debug: $e->getMessage());
		}

		return AiResponse::success(['options' => $options]);
	}

	private function resolveViaTool(array $item): array
	{
		$toolName = $item['tool'];
		$params   = (array) ($item['params'] ?? []);

		foreach (['filters', 'search', 'search_synonyms', 'limit', 'aggregate'] as $forwardable) {
			if (!isset($params[$forwardable]) && isset($item[$forwardable])) {
				$params[$forwardable] = $item[$forwardable];
			}
		}

		$class = AiTool::where('slug', $toolName)->value('class');

		if ($class === null || !is_a($class, AiSearchable::class, true)) {
			return AiResponse::error(AiErrorCode::UserError, "'{$toolName}' is not a valid searchable tool for delegation.");
		}

		if (!AiAccessService::canAccessTool($this->user, $toolName)) {
			return AiResponse::error(AiErrorCode::BusinessRule, "You do not have access to '{$toolName}'.");
		}

		return $class::searchLookup($this->user, $params);
	}
}
