<?php

namespace Solaris\Core\Ai\Tools\Lookup;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Laravel\Ai\Tools\Request;
use Solaris\Core\Ai\Attributes\AiEssential;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\AiSearchable;
use Solaris\Core\Ai\Tools\BaseAiTool;
use Solaris\Core\Ai\Tools\HasSearchLookup;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Services\Filter;
use Stringable;

#[AiEssential]
class LookupRegionTool extends BaseAiTool implements AiSearchable
{
	use HasSearchLookup;

    private const PARENTS = [
        'country'      => null,
        'province'     => 'country_id',
        'city'         => 'province_id',
        'district'     => 'city_id',
        'sub_district' => 'district_id',
    ];

    private const PARENT_RELATION = [
        'province'     => ['relation' => 'country',  'label' => 'country'],
        'city'         => ['relation' => 'province', 'label' => 'province'],
        'district'     => ['relation' => 'city',     'label' => 'city'],
        'sub_district' => ['relation' => 'district', 'label' => 'district'],
    ];

    public static function slug(): string
    {
        return 'lookup_region';
    }

    public function description(): Stringable|string
    {
        return 'Search address region options (country, province, city, district, sub_district) by name. '
            . 'Levels are hierarchical but you may search any level on its own; pass the parent id only when '
            . 'you want to narrow results (e.g. a province id when searching a city). Searching sub_district '
            . 'also returns its postcode. Use the returned id wherever a region id is required. '
            . 'If the response contains ambiguous: true, multiple regions share the same name — show the '
            . 'options with their parent context to the user and ask them to clarify, then call this tool '
            . 'again with the appropriate parent_id to get the exact match. '
            . 'Never show these ids to the user.';
    }

    protected function execute(Request $request): Stringable|string
    {
        return json_encode($this->search($request->all()), JSON_UNESCAPED_UNICODE);
    }

    public function search(array $params): array
    {
        $type = (string) ($params['type'] ?? '');
        if (!array_key_exists($type, self::PARENTS)) {
            return AiResponse::error(AiErrorCode::UserError, 'Invalid region type.');
        }

        $query    = trim((string) ($params['query'] ?? ''));
        $parentId = $params['parent_id'] ?? null;
        $class    = Helper::config("model.models.{$type}");

        $filter = new Filter();
        if ($query !== '') {
            $filter->and('name', Filter::Contains, $query);
        }

        $parentColumn = self::PARENTS[$type];
        if ($parentColumn !== null && !empty($parentId)) {
            $filter->and($parentColumn, $parentId);
        }

        $hasPostcode = $type === 'sub_district';
        $columns     = $hasPostcode ? ['id', 'name', 'postcode'] : ['id', 'name'];

        $rows = $class::filter($filter)
            ->orderBy('name')
            ->limit(15)
            ->get($columns);

        if ($rows->isEmpty()) {
            return AiResponse::success(['results' => []], instruction: 'No matching region found — tell the user and ask them to try a different name.');
        }

        if ($rows->count() > 1 && !empty($query)) {
            $duplicateNames = $rows
                ->groupBy(fn ($r) => mb_strtolower($r->name))
                ->filter(fn ($group) => $group->count() > 1);

            if ($duplicateNames->isNotEmpty()) {
                return AiResponse::success(
                    ['ambiguous' => true, 'options' => $rows->map(fn ($r) => $this->formatWithParent($r, $type, $hasPostcode))->values()->all()],
                    instruction: "Multiple regions match '{$query}'. Show options to the user and ask them to clarify, then call this tool again with the correct parent_id.",
                );
            }
        }

        return AiResponse::success(['results' => $rows->map(fn ($r) => $this->format($r, $hasPostcode))->values()->all()]);
    }

    public function schema(JsonSchema $schema): array
    {
        return [
            'type' => $schema->string()
                ->enum(['country', 'province', 'city', 'district', 'sub_district'])
                ->description('The region level to search.')
                ->required(),
            'query' => $schema->string()
                ->description('Partial or full region name to search for.')
                ->required(),
            'parent_id' => $schema->string()
                ->description('Optional id of the parent region to narrow results and resolve ambiguity (e.g. province id when searching a city).'),
        ];
    }

    private function format($row, bool $hasPostcode): array
    {
        $item = ['id' => $row->id, 'name' => $row->name];
        if ($hasPostcode) {
            $item['postcode'] = $row->postcode;
        }

        return $item;
    }

    private function formatWithParent($row, string $type, bool $hasPostcode): array
    {
        $item = $this->format($row, $hasPostcode);

        $parentInfo = self::PARENT_RELATION[$type] ?? null;
        if ($parentInfo) {
            $relation        = $parentInfo['relation'];
            $label           = $parentInfo['label'];
            $item[$label]    = $row->$relation?->name;
        }

        return $item;
    }
}
