<?php

namespace Solaris\Core\Ai\Tools;

use Illuminate\Contracts\Auth\Authenticatable;

trait HasSearchLookup
{
	abstract public function search(array $params): array;

	public static function searchLookup(Authenticatable $user, array $params): array
	{
		$instance = new static();

		if ($instance instanceof NeedsUser) {
			$instance->setUser($user);
		}

		return $instance->search($params);
	}
}
