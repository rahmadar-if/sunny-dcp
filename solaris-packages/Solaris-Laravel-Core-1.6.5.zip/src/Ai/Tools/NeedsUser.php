<?php

namespace Solaris\Core\Ai\Tools;

use Illuminate\Contracts\Auth\Authenticatable;

interface NeedsUser
{
	public function setUser(Authenticatable $user): static;
}
