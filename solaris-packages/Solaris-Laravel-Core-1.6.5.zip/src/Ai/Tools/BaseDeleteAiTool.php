<?php

namespace Solaris\Core\Ai\Tools;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Database\Eloquent\Model;
use Laravel\Ai\Tools\Request;
use Stringable;

abstract class BaseDeleteAiTool extends BaseConfirmAiTool
{
	abstract protected function resourceLabel(): string;

	abstract protected function findRecordById(string $id): ?Model;

	abstract protected function delete(Model $record): array;

	protected function resolveRecordId(Request $request): string
	{
		return trim((string) ($request['id'] ?? ''));
	}

	protected function descriptionExtra(): ?string
	{
		return null;
	}

	protected function guardDelete(mixed $record): ?string
	{
		return null;
	}

	public final function description(): Stringable|string
	{
		$description = "Delete an existing {$this->resourceLabel()}. "
			. 'Requires the record id — obtain it first via the relevant search tool. This action cannot '
			. 'be undone. '
			. 'Call this tool NOW as soon as the record to delete is known — do NOT wait for approval '
			. 'before calling it, and do NOT compose a confirmation message yourself without calling it '
			. 'first. Requires confirmation before deleting — see the confirmation protocol. '
			. 'Present the record\'s name to the user and ask them to confirm the exact record and action.';

		$extra = $this->descriptionExtra();
		if ($extra !== null) {
			$description .= "\n\n" . $extra;
		}

		return $description;
	}

	public final function schema(JsonSchema $schema): array
	{
		return array_merge([
			'id' => $schema->string()
				->description("The {$this->resourceLabel()} id to delete.")
				->required(),
		], $this->confirmationSchema($schema));
	}

	public function validateConfirmation(Request $request): array
	{
		$id = $this->resolveRecordId($request);

		if ($id === '') {
			return AiResponse::error(AiErrorCode::NotFound, "{$this->resourceLabel()} id is required.");
		}

		$record = $this->findRecordById($id);

		if ($record === null) {
			return AiResponse::error(AiErrorCode::NotFound, "{$this->resourceLabel()} not found.");
		}

		$blocked = $this->guardDelete($record);

		if ($blocked !== null) {
			return AiResponse::error(AiErrorCode::BusinessRule, $blocked);
		}

		$displayColumn = method_exists($record, 'getDisplayValueName') ? $record->getDisplayValueName() : null;
		$displayValue  = $displayColumn ? $record->{$displayColumn} : $record->getKey();

		return [
			'payload' => ['id' => $id],
			'summary' => ['resource' => $this->resourceLabel(), 'name' => $displayValue],
		];
	}

	public function executeConfirmed(Request $request, array $payload): array
	{
		$record = $this->findRecordById((string) ($payload['id'] ?? ''));

		if ($record === null) {
			return AiResponse::error(AiErrorCode::NotFound, "{$this->resourceLabel()} not found.");
		}

		return $this->delete($record);
	}
}
