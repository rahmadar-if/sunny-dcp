<?php

namespace Solaris\Core\Ai\Tools;

interface NeedsAgent
{
	public function setAgentSlug(string $slug): static;
}
