<?php

namespace Solaris\Core\Ai\Tools\Attachment;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Support\Facades\Cache;
use Laravel\Ai\Contracts\Tool;
use Laravel\Ai\Tools\Request;
use Solaris\Core\Ai\Services\WhatsAppAiService;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\HasUser;
use Solaris\Core\Ai\Tools\HasWaConversation;
use Solaris\Core\Ai\Tools\NeedsUser;
use Solaris\Core\Ai\Tools\NeedsWaConversation;
use Solaris\Core\Models\WaMessage;
use Stringable;

class WaMediaTool implements Tool, NeedsUser, NeedsWaConversation
{
	use HasUser, HasWaConversation;

	private const AVATAR_TYPES     = ['image'];
	private const ATTACHMENT_TYPES = ['image', 'audio', 'video', 'document'];
	private const READ_TYPES       = ['image'];

	public static function slug(): string
	{
		return 'wa_media_tool';
	}

	public function description(): Stringable|string
	{
		return 'Resolve which media the user means (an explicit bracketed id, a reply/quote, or the most '
			. 'recent relevant file) into attachment_id(s). '
			. 'Call this FIRST — never guess or fabricate an attachment_id yourself. '
			. 'Files that are still downloading come back as "pending_media_ids". For '
			. '"for":"avatar"/"attachment" those are NOT a dead end: pass them straight to set_avatar or '
			. 'upload_attachment alongside the ready ones, so the user confirms everything at once and the '
			. 'stragglers are attached by themselves once their download lands. '
			. 'For "for":"read" (read-only lookups, e.g. before extract_images) reading cannot be deferred — '
			. 'anything still downloading is only reported so you can proceed with what is ready or ask the '
			. 'user to wait/resend. '
			. 'Omit media to resolve via reply, then fall back to the most recent relevant media (or the pending '
			. 'media pool for "attachment"/"read", which can return multiple).';
	}

	public function schema(JsonSchema $schema): array
	{
		return [
			'for' => $schema->string()->enum(['avatar', 'attachment', 'read'])->description(
				'What the resolved attachment_id(s) will be used for. "read" = a read-only lookup (e.g. feeding '
					. 'extract_images).'
			)->required(),
			'media' => $schema->array()->items($schema->string())->description(
				'The bracketed id(s) the media message(s) were shown with, e.g. "4e07b129". Omit to resolve '
				. 'via reply, then fall back to the most recent relevant media.'
			),
		];
	}

	public function handle(Request $request): Stringable|string
	{
		$for = (string) ($request['for'] ?? '');

		if (!in_array($for, ['avatar', 'attachment', 'read'], true)) {
			return json_encode(AiResponse::error(AiErrorCode::UserError, '"for" must be "avatar", "attachment", or "read".'), JSON_UNESCAPED_UNICODE);
		}

		[$messages, $consumedIds] = $this->resolveMessages($request, $for);

		if (empty($messages)) {
			return json_encode(AiResponse::error(
				AiErrorCode::NotFound,
				'No matching media found in this chat. Ask the user to send or point to the file first.',
			), JSON_UNESCAPED_UNICODE);
		}

		$ready   = [];
		$pending = [];

		foreach ($messages as $message) {
			$message->attachment_id !== null
				? $ready[] = $message->attachment_id
				: $pending[] = $message->id;
		}

		if (!empty($consumedIds)) {
			WhatsAppAiService::clearPendingMedia($this->conversation->id, $consumedIds);
		}

		if ($for === 'read') {
			return json_encode($this->readResult($ready, $pending), JSON_UNESCAPED_UNICODE);
		}

		return json_encode($this->actionableResult($ready, $pending), JSON_UNESCAPED_UNICODE);
	}

	private function readResult(array $ready, array $pending): array
	{
		if (empty($ready)) {
			return AiResponse::success(
				['pending' => true],
				instruction: 'None of the requested file(s) have finished downloading yet. Reading cannot be '
					. 'deferred, so tell the user immediately, in their language, to wait a moment or resend, '
					. 'then try again.',
			);
		}

		return AiResponse::success(
			['attachment_ids' => $ready],
			instruction: empty($pending)
				? 'Proceed now with these attachment_ids.'
				: 'Some of the requested file(s) are still downloading and are NOT included here. Reading cannot '
					. 'be deferred — proceed now with these ready attachment_ids, and tell the user the rest need '
					. 'to be resent or requested again once ready.',
		);
	}

	private function actionableResult(array $ready, array $pending): array
	{
		if (empty($pending)) {
			return AiResponse::success(
				['attachment_ids' => $ready],
				instruction: 'Call set_avatar or upload_attachment NOW with these attachment_ids.',
			);
		}

		return AiResponse::success(
			['attachment_ids' => $ready, 'pending_media_ids' => $pending],
			instruction: 'Call set_avatar or upload_attachment NOW, passing the ready attachment_ids AND the '
				. 'pending_media_ids exactly as returned here. Files that are still downloading are NOT skipped: '
				. 'the user still confirms them now, and they are attached on their own once the download lands. '
				. 'Never invent or reword these ids.',
		);
	}

	private function resolveMessages(Request $request, string $for): array
	{
		$types = match ($for) {
			'avatar' => self::AVATAR_TYPES,
			'read'   => self::READ_TYPES,
			default  => self::ATTACHMENT_TYPES,
		};

		$suffixes = array_filter(array_map('trim', array_map('strval', (array) ($request['media'] ?? []))));

		[$messages, $consumedIds] = !empty($suffixes)
			? $this->resolveByIds($suffixes, $types)
			: $this->resolveByFallback($types, $for);

		if ($for === 'avatar' && count($messages) > 1) {
			$messages = [$messages[0]];
		}

		return [$messages, $consumedIds];
	}

	private function resolveByFallback(array $types, string $for): array
	{
		$reply = $this->resolveByReply($types);

		if ($reply !== null) {
			return [[$reply], []];
		}

		return $for === 'avatar'
			? [$this->resolveLatest($types), []]
			: $this->resolvePendingPool($types);
	}

	private function resolveByIds(array $suffixes, array $types): array
	{
		$messages = collect($suffixes)
			->map(fn (string $suffix) => preg_replace('/[^A-Za-z0-9-]/', '', $suffix))
			->filter()
			->flatMap(fn (string $suffix) => WaMessage::forConversation($this->conversation->id)
				->idSuffix($suffix)
				->whereIn('type', $types)
				->get()
				->all())
			->unique('id')
			->values();

		return [$messages->all(), $messages->pluck('id')->all()];
	}

	private function resolveByReply(array $types): ?WaMessage
	{
		$latest = WaMessage::forConversation($this->conversation->id)
			->received()
			->latest('wa_timestamp')
			->first();

		$quoted = $latest?->quotedMessage;

		return $quoted !== null && in_array($quoted->type, $types, true) ? $quoted : null;
	}

	private function resolveLatest(array $types): array
	{
		$message = WaMessage::forConversation($this->conversation->id)
			->received()
			->whereIn('type', $types)
			->latest('wa_timestamp')
			->first();

		return $message !== null ? [$message] : [];
	}

	private function resolvePendingPool(array $types): array
	{
		$pending = Cache::get(WhatsAppAiService::pendingMediaKey($this->conversation->id), []);

		if (empty($pending)) {
			return [[], []];
		}

		$messages = WaMessage::whereIn('id', $pending)->whereIn('type', $types)->get();

		return [$messages->all(), $messages->pluck('id')->all()];
	}
}
