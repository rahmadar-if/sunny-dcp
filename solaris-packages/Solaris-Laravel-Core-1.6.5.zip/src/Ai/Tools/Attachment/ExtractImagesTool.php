<?php

namespace Solaris\Core\Ai\Tools\Attachment;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Laravel\Ai\Files;
use Laravel\Ai\Tools\Request;
use Solaris\Core\Ai\Agents\ImageExtractionAgent;
use Solaris\Core\Ai\Exceptions\AiAuthorizationException;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseAiTool;
use Solaris\Core\Models\Attachment;
use Stringable;

class ExtractImagesTool extends BaseAiTool
{
	public static function slug(): string
	{
		return 'extract_images';
	}

	public function description(): Stringable|string
	{
		return 'Read one or more images (already resolved to attachment_id via wa_media_tool with '
			. 'for:"read") and extract structured data from each, in whatever JSON shape you need. '
			. 'One entry in "groups" = one independent entity/document — e.g. 3 separate business cards from '
			. '3 different people = 3 groups of one attachment_id each; a single double-sided card = 1 group '
			. 'with 2 attachment_ids; a mixed batch (each image for a different purpose) = groups with '
			. 'different "task" text each. Batch every group needed in ONE call. '
			. 'You decide the grouping yourself from context — if it is genuinely unclear how many separate '
			. 'entities the images represent, do not guess; treat it as an unclear request instead. '
			. 'This tool only reads the images, it creates nothing — present each result to the user as a '
			. 'confirmation before calling the matching create tool.';
	}

	public function schema(JsonSchema $schema): array
	{
		return [
			'groups' => $schema->array()->items(
				$schema->object([
					'attachment_ids' => $schema->array()->items($schema->string())->description(
						'One or more attachment ids (from wa_media_tool) that together form ONE entity/document.'
					)->required(),
					'task' => $schema->string()->description(
						'What to extract from this group and in what shape — describe the exact fields/JSON keys '
							. 'you need (e.g. matching the target create tool\'s fields). Read in isolation from '
							. 'every other group.'
					)->required(),
				])
			)->description('One entry per independent entity/document to extract.')->required(),
		];
	}

	protected function execute(Request $request): Stringable|string
	{
		$groups = (array) ($request['groups'] ?? []);

		if (empty($groups)) {
			return json_encode(AiResponse::error(AiErrorCode::UserError, 'groups is required.'), JSON_UNESCAPED_UNICODE);
		}

		$results = [];

		foreach ($groups as $index => $group) {
			$results[$index] = $this->extractGroup((array) $group);
		}

		return json_encode(AiResponse::success(
			['results' => $results],
			instruction: 'Present each result to the user as a confirmation before calling the matching '
				. 'create tool — one call per group. Never invent a value for a field not found in its images.',
		), JSON_UNESCAPED_UNICODE);
	}

	private function extractGroup(array $group): array
	{
		$attachmentIds = (array) ($group['attachment_ids'] ?? []);
		$task          = trim((string) ($group['task'] ?? ''));

		if (empty($attachmentIds) || $task === '') {
			return AiResponse::error(AiErrorCode::UserError, 'Each group needs attachment_ids and a task.');
		}

		$images = collect($attachmentIds)
			->map(fn ($id) => Attachment::find($id))
			->filter()
			->map(fn (Attachment $attachment) => Files\Image::fromStorage($attachment->path, $attachment->disk))
			->values()
			->all();

		if (empty($images)) {
			return AiResponse::error(AiErrorCode::NotFound, 'None of this group\'s attachment_ids could be resolved.');
		}

		try {
			$agent    = new ImageExtractionAgent();
			$response = $agent->read($task, $images);
		} catch (AiAuthorizationException) {
			return AiResponse::error(AiErrorCode::BusinessRule, 'You do not have access to image extraction.');
		}

		$extracted = $agent->decode((string) $response);

		if ($extracted === null) {
			return AiResponse::error(AiErrorCode::SystemError, 'Could not read this group\'s image(s).', debug: (string) $response);
		}

		return AiResponse::success($extracted);
	}
}
