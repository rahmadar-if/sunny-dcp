<?php

namespace Solaris\Core\Ai\Tools\Attachment;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Laravel\Ai\Tools\Request;
use Solaris\Core\Ai\Services\AttachmentTargetRegistry;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseAiTool;
use Stringable;

class ListAttachmentTargetsTool extends BaseAiTool
{
	public static function slug(): string
	{
		return 'list_attachment_targets';
	}

	public function description(): Stringable|string
	{
		return 'List valid modules files can be uploaded to via upload_attachment — call this when the user '
			. 'names a module you are not certain exists, or before searching for its record if unsure. Pass the '
			. '"table" value it returns as the "model" field on upload_attachment. Never guess a module exists '
			. 'without checking here first.';
	}

	public function schema(JsonSchema $schema): array
	{
		return [
			'search' => $schema->string()->description('Optional: filter by partial name match (e.g. "account").'),
		];
	}

	protected function execute(Request $request): Stringable|string
	{
		$search = trim((string) ($request['search'] ?? ''));

		$targets = AttachmentTargetRegistry::all()
			->when($search !== '', fn ($items) => $items->filter(
				fn ($item) => str_contains(strtolower($item['name']), strtolower($search))
			))
			->map(fn ($item) => ['name' => $item['name'], 'table' => $item['table']])
			->values()
			->all();

		return json_encode(
			AiResponse::success(['targets' => $targets, 'count' => count($targets)]),
			JSON_UNESCAPED_UNICODE,
		);
	}
}
