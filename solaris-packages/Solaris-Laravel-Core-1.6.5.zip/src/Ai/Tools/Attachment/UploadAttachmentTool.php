<?php

namespace Solaris\Core\Ai\Tools\Attachment;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Laravel\Ai\Tools\Request;
use Solaris\Core\Ai\Services\AttachmentTargetRegistry;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseConfirmAiTool;
use Solaris\Core\Ai\Tools\HasDeferredMedia;
use Solaris\Core\Models\Attachment;
use Solaris\Core\Repositories\AttachmentRepository;
use Stringable;

class UploadAttachmentTool extends BaseConfirmAiTool
{
	use HasDeferredMedia;

	public static function slug(): string
	{
		return 'upload_attachment';
	}

	public function description(): Stringable|string
	{
		return 'Upload already-uploaded attachment(s) into the attachment system, linked to a specific record '
			. '(or the user\'s own personal attachments). Resolve the attachment_id(s) first via the channel\'s '
			. 'own media-resolution tool (e.g. wa_media_tool on WhatsApp). '
			. 'Call this tool NOW as soon as the attachment_id(s) and target are known — do NOT wait for '
			. 'approval before calling it, and do NOT compose a confirmation or completion message yourself '
			. 'without calling it first. Requires confirmation before uploading — see the confirmation protocol. '
			. 'If a target module/record is named, call list_attachment_targets first to confirm it exists and get '
			. 'its "table" value — never guess the model. Then find that module\'s own search tool to resolve the '
			. 'record id, and pass model (the table value) + record_id here — never guess the id either. If no '
			. 'target is named, ask whether the user wants their personal attachments or a specific record. '
			. 'Each item must explicitly list its own files and its own target — never omit them expecting the '
			. 'rest to be inferred. Multiple targets in one call are supported: pass one item per target, each '
			. 'with the exact files that belong to it. '
			. 'Files still downloading are passed as pending_media_ids on the item they belong to: they are '
			. 'confirmed together with everything else and attached on their own once ready, so never leave '
			. 'them out and never call this tool again for them.';
	}

	public function schema(JsonSchema $schema): array
	{
		return array_merge($this->confirmationSchema($schema), [
			'items' => $schema->array()->items($schema->object([
				'attachment_ids' => $schema->array()->items($schema->string())->description(
					'The attachment id(s) to upload to this target, from wa_media_tool.'
				),
				'pending_media_ids' => $schema->array()->items($schema->string())->description(
					'The pending_media_ids wa_media_tool returned for this target — files still downloading. '
					. 'Pass them exactly as given: they are confirmed together with the rest and attached on '
					. 'their own once the download finishes.'
				),
				'model' => $schema->string()->description(
					'Target table name, from list_attachment_targets\' "table" value. Omit for the user\'s personal attachments.'
				),
				'record_id' => $schema->string()->description(
					'The target record id. Required when model is given — resolve via that module\'s own search tool first.'
				),
			]))->description('One or more upload targets. Each item needs at least one attachment_id or pending_media_id.')->required(),
			'completion_messages' => $schema->object([
				'success' => $schema->string()->description('Everything was attached.')->required(),
				'partial' => $schema->string()->description('Some files were attached, the rest failed to download.')->required(),
				'failed'  => $schema->string()->description('Nothing could be attached.')->required(),
			])->description(
				'Closing lines sent AFTER your turn ends, once the still-downloading files land. Write them in '
				. 'the user\'s language, one short line each, and NEVER mention counts — the numbers are only '
				. 'known later. Always fill all three; if every file turns out to be ready, they simply go unused.'
			)->required(),
		]);
	}

	public function validateConfirmation(Request $request): array
	{
		$items = array_values((array) ($request['items'] ?? []));

		if (empty($items)) {
			return AiResponse::error(AiErrorCode::UserError, 'At least one upload target is required.');
		}

		$itemIds     = [];
		$itemPending = [];
		$allIds      = [];

		foreach ($items as $index => $item) {
			$item    = (array) $item;
			$ids     = array_values(array_unique(array_map('strval', (array) ($item['attachment_ids'] ?? []))));
			$pending = array_values(array_unique(array_map('strval', (array) ($item['pending_media_ids'] ?? []))));

			if (empty($ids) && empty($pending)) {
				return AiResponse::error(
					AiErrorCode::UserError,
					"Item {$index} must list at least one attachment_id or pending_media_id.",
				);
			}

			$itemIds[$index]     = $ids;
			$itemPending[$index] = $pending;
			$allIds              = array_merge($allIds, $ids);
		}

		$existingIds = Attachment::whereIn('id', array_unique($allIds))->pluck('id')->all();

		$targets = [];
		$waiting = [];
		$summary = [];

		foreach ($items as $index => $item) {
			$ids     = $itemIds[$index];
			$pending = $itemPending[$index];
			$missing = array_diff($ids, $existingIds);

			if (!empty($missing)) {
				return AiResponse::error(AiErrorCode::NotFound, 'Attachment(s) not found: ' . implode(', ', $missing));
			}

			$target = $this->resolveTarget((array) $item);

			if (isset($target['error'])) {
				return $target;
			}

			foreach ($pending as $messageId) {
				$waiting[$messageId] = $index;
			}

			$targets[] = ['attachment_ids' => $ids, 'target' => $target];
			$summary[] = $this->describeItem(count($ids), count($pending), $target['label']);
		}

		return [
			'payload' => [
				'targets'             => $targets,
				'waiting'             => $waiting,
				'completion_messages' => $this->completionMessages($request),
			],
			'summary' => ['upload' => $summary],
		];
	}

	private function describeItem(int $ready, int $pending, string $label): string
	{
		$total = $ready + $pending;
		$line  = "{$total} file(s) → {$label}";

		return $pending === 0 ? $line : $line . " ({$pending} still downloading)";
	}

	private function resolveTarget(array $item): array
	{
		return AttachmentTargetRegistry::resolveTarget($item['model'] ?? null, $item['record_id'] ?? null, $this->user->id);
	}

	public function executeConfirmed(Request $request, array $payload): array
	{
		$payload = $this->absorbReadyMedia($payload);

		if (!empty($payload['waiting'])) {
			return $this->parkForMedia(
				$request,
				$payload,
				'Tell the user immediately, in their language, that the remaining file(s) are still downloading '
					. 'and will be attached on their own once ready. Do not call this tool again for them.',
			);
		}

		$uploaded = 0;

		foreach ($payload['targets'] as $entry) {
			foreach ($entry['attachment_ids'] as $id) {
				$source = Attachment::find($id);
				if ($source === null) {
					continue;
				}

				AttachmentRepository::copyToRecord($source, $entry['target']['table_name'], $entry['target']['record_id']);
				$uploaded++;
			}
		}

		return AiResponse::success(
			['uploaded' => $uploaded],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
