<?php

namespace Solaris\Core\Ai\Tools;

use Laravel\Ai\Tools\Request;
use Solaris\Core\Ai\Services\ConfirmedMediaService;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\WaAiConfirmation;
use Solaris\Core\Models\WaMessage;

trait HasDeferredMedia
{
	protected function completionMessages(Request $request): array
	{
		$messages = (array) ($request['completion_messages'] ?? []);

		return array_filter([
			'success' => trim((string) ($messages['success'] ?? '')),
			'partial' => trim((string) ($messages['partial'] ?? '')),
			'failed'  => trim((string) ($messages['failed'] ?? '')),
		]);
	}

	protected function absorbReadyMedia(array $payload): array
	{
		$waiting = (array) ($payload['waiting'] ?? []);

		if (empty($waiting)) {
			return $payload;
		}

		$resolved = WaMessage::whereIn('id', array_keys($waiting))
			->whereNotNull('attachment_id')
			->pluck('attachment_id', 'id')
			->all();

		foreach ($resolved as $messageId => $attachmentId) {
			$index = (int) $waiting[$messageId];

			$payload['targets'][$index]['attachment_ids'][] = $attachmentId;

			unset($waiting[$messageId]);
		}

		foreach ($payload['targets'] ?? [] as $index => $target) {
			$payload['targets'][$index]['attachment_ids'] = array_values(array_unique(
				(array) ($target['attachment_ids'] ?? []),
			));
		}

		$payload['waiting'] = $waiting;

		return $payload;
	}

	protected function parkForMedia(Request $request, array $payload, string $instruction): array
	{
		$note = WaAiConfirmation::find(trim((string) ($request['confirmation_token'] ?? '')));

		if ($note === null) {
			return AiResponse::error(
				AiErrorCode::SystemError,
				'This confirmation could not be found while parking the pending files.',
			);
		}

		$conversationId = WaMessage::whereIn('id', array_keys($payload['waiting']))->value('conversation_id');

		$payload['conversation_id'] = $conversationId;
		$payload['deadline']        = now()->addMinutes(static::deferredWaitMinutes())->toIso8601String();

		$note->update([
			'status'  => WaAiConfirmation::StatusAwaitingMedia,
			'payload' => $payload,
		]);

		if ($conversationId !== null) {
			ConfirmedMediaService::handle($conversationId, array_keys($payload['waiting']));
		}

		return AiResponse::success(['awaiting_media' => true], instruction: $instruction);
	}

	protected static function deferredWaitMinutes(): int
	{
		return (int) Helper::config('ai.tool_settings.confirmed_media.wait_minutes', 30);
	}
}
