<?php

namespace Solaris\Core\Ai\Tools\Conversation;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Laravel\Ai\Contracts\Tool;
use Laravel\Ai\Tools\Request;
use Solaris\Core\Ai\Services\BatchModeService;
use Solaris\Core\Ai\Services\BouncerEventPublisher;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\HasUser;
use Solaris\Core\Ai\Tools\HasWaConversation;
use Solaris\Core\Ai\Tools\NeedsUser;
use Solaris\Core\Ai\Tools\NeedsWaConversation;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\WaMessage;
use Stringable;

class WaBatchModeTool implements Tool, NeedsUser, NeedsWaConversation
{
	use HasUser, HasWaConversation;

	public static function slug(): string
	{
		return 'batch_mode';
	}

	public function description(): Stringable|string
	{
		return 'Controls MULTI-MESSAGE MODE — see that section of your instructions for when to use each action. '
			. '"start": call the moment the user signals they are about to send several messages that belong '
			. 'together — call it, do not just reply in your own words promising to wait, that promise enforces '
			. 'nothing without this call. The system takes over holding the conversation from that point — you '
			. 'will not be invoked again for it until the user sends the exact release/cancel keyword the "start" '
			. 'result tells you to quote, or a ceiling elapses. '
			. '"end": call this FIRST, before any other tool, the moment you are invoked again for a conversation you '
			. 'previously started a hold on — the messages the user sent while held are already in the prompt above '
			. 'you (all of it, including the release keyword itself), this call only releases the hold flag so the '
			. 'other tools you need next actually work. Treat every message shown to you this turn as ONE combined '
			. 'request and act on all of it. '
			. '"cancel": call if the user changes their mind before the hold ends. Discards the hold with no further '
			. 'action.';
	}

	public function schema(JsonSchema $schema): array
	{
		return [
			'action' => $schema->string()
				->enum(['start', 'end', 'cancel'])
				->description('start | end | cancel — see this tool\'s own description for when each applies.')
				->required(),
		];
	}

	public function handle(Request $request): Stringable|string
	{
		$action = trim((string) ($request['action'] ?? ''));

		return match ($action) {
			'start'  => json_encode($this->start(), JSON_UNESCAPED_UNICODE),
			'end'    => json_encode($this->end(), JSON_UNESCAPED_UNICODE),
			'cancel' => json_encode($this->cancel(), JSON_UNESCAPED_UNICODE),
			default  => json_encode(AiResponse::error(AiErrorCode::UserError, 'action must be one of: start, end, cancel.'), JSON_UNESCAPED_UNICODE),
		};
	}

	private function start(): array
	{
		$trigger = WaMessage::forConversation($this->conversation->id)
			->received()
			->latest('wa_timestamp')
			->first();

		if ($trigger === null) {
			return AiResponse::error(AiErrorCode::NotFound, 'No message found to anchor the hold to.');
		}

		BatchModeService::start($this->conversation, $this->user, $trigger);
		$this->notifyBouncerStart();

		$keywords   = Helper::config('ai.tool_settings.batch_mode.keywords');
		$ttlMinutes = BatchModeService::ttl();

		return AiResponse::success(
			['started' => true],
			instruction: 'Reply immediately with a short disclaimer in the user\'s language telling them you will '
				. 'wait until they say they are done. WhatsApp-format the keyword itself in *bold*, wrapped in '
				. "SINGLE quotes INSIDE the asterisks — e.g. *'word'* — never plain text, never double quotes "
				. '(those get backslash-escaped when this instruction is JSON-encoded and you must NOT copy that '
				. 'backslash into your reply), never quotes without bold, never bold without quotes. Detect the '
				. "user's language: Indonesian → tell them to type *'{$keywords['stop']['id']}'* when done or "
				. "*'{$keywords['cancel']['id']}'* to cancel; any other language (default English) → tell them "
				. "to type *'{$keywords['stop']['en']}'* when done or *'{$keywords['cancel']['en']}'* to "
				. 'cancel. Use ONLY the one variant matching their language — never invent your own wording for '
				. 'the keyword itself, the system matches on it exactly (the bold/quote markers themselves are '
				. 'not part of the match, only for the user\'s display). Every '
				. "message after this is held by the system, unseen by you, for up to {$ttlMinutes} minutes or "
				. 'until that exact keyword arrives.',
		);
	}

	private function end(): array
	{
		BatchModeService::cancel($this->conversation, $this->user);
		$this->notifyBouncerEnd();

		return AiResponse::success(
			['ended' => true],
			instruction: 'The hold is over. Every message the user sent while waiting is already shown to '
				. 'you this turn — treat all of it as ONE combined request. Process every single one, '
				. 'calling whatever other tools each needs (they are usable again now). Do not skip or '
				. 'merge any of them into a partial answer.',
		);
	}

	private function cancel(): array
	{
		BatchModeService::cancel($this->conversation, $this->user);
		$this->notifyBouncerEnd();

		return AiResponse::success(
			['cancelled' => true],
			instruction: 'Reply with a brief one-line acknowledgment in the user\'s language that the hold was cancelled.',
		);
	}

	private function notifyBouncerStart(): void
	{
		$appId = $this->bouncerAppId();
		if ($appId === null) {
			return;
		}

		$keywords = Helper::config('ai.tool_settings.batch_mode.keywords');

		BouncerEventPublisher::publishHoldStart(
			$appId,
			$this->conversation->device_id,
			$this->conversation->id,
			[$keywords['stop']['id'], $keywords['stop']['en']],
			[$keywords['cancel']['id'], $keywords['cancel']['en']],
			BatchModeService::ttl() * 60,
		);
	}

	private function notifyBouncerEnd(): void
	{
		$appId = $this->bouncerAppId();
		if ($appId === null) {
			return;
		}

		BouncerEventPublisher::publishHoldEnd($appId, $this->conversation->device_id, $this->conversation->id);
	}

	private function bouncerAppId(): ?string
	{
		return Helper::config('whatsapp_ai.bouncer.app_id');
	}
}
