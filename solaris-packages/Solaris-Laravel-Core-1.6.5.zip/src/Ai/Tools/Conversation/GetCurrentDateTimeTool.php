<?php

namespace Solaris\Core\Ai\Tools\Conversation;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Support\Carbon;
use Laravel\Ai\Tools\Request;
use Solaris\Core\Ai\Attributes\AiEssential;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseAiTool;
use Stringable;

#[AiEssential]
class GetCurrentDateTimeTool extends BaseAiTool
{
    public static function slug(): string
    {
        return 'get_current_datetime';
    }

    public function description(): Stringable|string
    {
        return 'Get the current date and time, in the user\'s own timezone. This is the ONLY source of truth '
            . 'for "today", "now", "tomorrow", or any relative date/time — never use training-data dates. Call '
            . 'this before any reply that depends on the current date/time or a relative date computed from it.';
    }

    protected function execute(Request $request): Stringable|string
    {
        $timezone = $this->user->profile?->timezone ?: config('app.timezone');
        $now      = Carbon::now($timezone);

        return json_encode(AiResponse::success([
            'now'         => $now->format('l, Y-m-d H:i'),
            'day_of_week' => $now->format('l'),
            'timezone'    => $timezone,
            'utc_offset'  => 'UTC' . $now->format('P'),
        ]), JSON_UNESCAPED_UNICODE);
    }

    public function schema(JsonSchema $schema): array
    {
        return [];
    }
}
