<?php

namespace Solaris\Core\Ai\Tools\Conversation;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Laravel\Ai\Contracts\Tool;
use Laravel\Ai\Tools\Request;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\ConfirmAiTool;
use Solaris\Core\Ai\Tools\HasConfirmation;
use Solaris\Core\Ai\Tools\HasWaConversation;
use Solaris\Core\Ai\Tools\NeedsWaConversation;
use Solaris\Core\Models\WaConversation;
use Stringable;

class ResetWaConversationTool implements Tool, ConfirmAiTool, NeedsWaConversation
{
    use HasConfirmation, HasWaConversation;

    public static function slug(): string
    {
        return 'reset_conversation';
    }

    public function description(): Stringable|string
    {
        return 'Clear the remembered chat history and start a fresh conversation context. '
            . 'COMMANDS: "/reset" is just a shortcut for a clear intent — skip asking why. '
            . 'NATURAL LANGUAGE: applies when the user asks to reset, start over, clear chat, or forget the '
            . 'conversation. '
            . 'Call this tool NOW as soon as the intent to reset is clear — do NOT wait for approval before '
            . 'calling it, and do NOT compose a confirmation or completion message yourself without calling '
            . 'it first. Requires confirmation before resetting — see the confirmation protocol.';
    }

    public function schema(JsonSchema $schema): array
    {
        return $this->confirmationSchema($schema);
    }

    public function handle(Request $request): Stringable|string
    {
        return $this->execute($request);
    }

    public function validateConfirmation(Request $request): array
    {
        return ['payload' => [], 'summary' => []];
    }

    public function executeConfirmed(Request $request, array $payload): array
    {
        WaConversation::where('id', $this->conversation->id)->update([
            'ai_conversation_id' => null,
            'ai_agent_threads'   => null,
            'ai_last_active_at'  => null,
        ]);

        return AiResponse::success(
            ['message' => 'The conversation context has been cleared. The next message starts fresh.'],
            instruction: 'Reply to the user immediately with a brief one-line confirmation in their language.',
        );
    }
}
