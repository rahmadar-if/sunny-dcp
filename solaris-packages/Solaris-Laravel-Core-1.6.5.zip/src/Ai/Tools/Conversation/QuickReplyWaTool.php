<?php

namespace Solaris\Core\Ai\Tools\Conversation;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Support\Facades\Cache;
use Laravel\Ai\Contracts\Tool;
use Laravel\Ai\Tools\Request;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\HasWaConversation;
use Solaris\Core\Ai\Tools\NeedsWaConversation;
use Solaris\Core\Services\WhatsApp\WhatsAppService;
use Stringable;

class QuickReplyWaTool implements Tool, NeedsWaConversation
{
	use HasWaConversation;

	public static function slug(): string
	{
		return 'quick_reply';
	}

	// Shared with DelegateTool's fallback ack: whoever claims it first sends, the other stands down.
	public static function claimAck(string $conversationId): bool
	{
		return Cache::add("wa_quick_reply:{$conversationId}", true, now()->addSeconds(20));
	}

	public function description(): Stringable|string
	{
		return 'Sends a brief interim acknowledgment so the user knows their request was received while slow '
			. 'work runs. Call it in the SAME step as the first tool that hands work to a specialist — the two '
			. 'go out together. The message is one short "please wait" sentence in the user\'s language and '
			. 'tone, generic: no topic, records, numbers, or other details. '
			. 'It is an ack, not the answer — you still owe the real result as your final message this turn. '
			. 'One per turn; a second call is ignored, so send it early rather than deliberating over it.';
	}

	public function handle(Request $request): Stringable|string
	{
		$message = trim((string) ($request['message'] ?? ''));

		if (empty($message)) {
			return json_encode(AiResponse::error(AiErrorCode::UserError, 'No message provided; nothing was sent.'), JSON_UNESCAPED_UNICODE);
		}

		if (!static::claimAck($this->conversation->id)) {
			return json_encode(AiResponse::success(
				['sent' => false, 'skipped' => 'already_acknowledged'],
				instruction: 'You already sent an interim acknowledgment this turn — do NOT send another. '
					. 'Proceed with your other tools and deliver the actual result or confirmation as your final message.',
			), JSON_UNESCAPED_UNICODE);
		}

		WhatsAppService::device($this->conversation->device_id)
			->sendText($this->conversation, $message);

		return json_encode(AiResponse::success(
			['sent' => true],
			instruction: 'Interim acknowledgment only — NOT your reply. You MUST still send the actual '
				. 'result or confirmation as your final message this same turn once your other tools return.',
		), JSON_UNESCAPED_UNICODE);
	}

	public function schema(JsonSchema $schema): array
	{
		return [
			'message' => $schema->string()->description(
				'Very short generic "please wait" text in the user\'s language and tone. One brief sentence max. '
				. 'Do NOT mention the topic, task, records, or any details.'
			),
		];
	}
}
