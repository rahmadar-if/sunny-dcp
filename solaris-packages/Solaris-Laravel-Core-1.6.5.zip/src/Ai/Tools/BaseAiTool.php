<?php

namespace Solaris\Core\Ai\Tools;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Support\Str;
use Laravel\Ai\Contracts\Tool;
use Laravel\Ai\Tools\Request;
use Solaris\Core\Ai\Services\AiAccessService;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Interfaces\Model\SolarisLookup;
use Stringable;

abstract class BaseAiTool implements Tool, NeedsUser, NeedsAgent, NeedsToolState
{
	use HasUser;
	use HasAgent;
	use HasToolState;

	// One failure is information, a second is a fair retry, a third is thrashing.
	private const FAILURE_LIMIT = 2;

	abstract public static function slug(): string;

	abstract public function description(): Stringable|string;

	abstract public function schema(JsonSchema $schema): array;

	abstract protected function execute(Request $request): Stringable|string;

	public final function handle(Request $request): Stringable|string
	{
		if ($this->agentSlug !== null && !AiAccessService::canAccessAgent($this->user, $this->agentSlug)) {
			return $this->accessDenied();
		}

		if (!AiAccessService::canAccessTool($this->user, static::slug())) {
			return $this->accessDenied();
		}

		if ($this->toolState === null) {
			return $this->execute($request);
		}

		$exhausted = $this->exhaustedErrorCode();

		if ($exhausted !== null) {
			return $this->repeatedFailure($exhausted);
		}

		$result = $this->execute($request);

		$this->recordFailure((string) $result);

		return $result;
	}

	private function exhaustedErrorCode(): ?string
	{
		foreach (AiErrorCode::cases() as $code) {
			if ($this->toolState->isExhausted(static::slug(), $code->value, self::FAILURE_LIMIT)) {
				return $code->value;
			}
		}

		return null;
	}

	private function recordFailure(string $result): void
	{
		$decoded = json_decode($result, true);

		if (!is_array($decoded)) {
			return;
		}

		foreach ($this->errorCodesIn($decoded) as $code) {
			$this->toolState->recordFailure(static::slug(), $code);
		}
	}

	// Batch tools report success at the root and hide per-item failures one level down (lookup_options
	// returns {"success":true,"results":{"<key>":{"error":…}}}), which used to slip past the counter
	// entirely — the model could repeat the same invalid item indefinitely.
	private function errorCodesIn(array $decoded): array
	{
		if (isset($decoded['error']) && is_string($decoded['error'])) {
			return [$decoded['error']];
		}

		return collect($decoded['results'] ?? [])
			->filter(fn ($item) => is_array($item) && isset($item['error']) && is_string($item['error']))
			->map(fn (array $item) => $item['error'])
			->unique()
			->values()
			->all();
	}

	private function repeatedFailure(string $errorCode): string
	{
		$guidance = $errorCode === AiErrorCode::SystemError->value
			? 'Tell the user the action failed due to a system issue that has been logged and to try again shortly.'
			: 'Report the failure to the user or ask them for the information needed to change the request.';

		return json_encode(AiResponse::error(
			AiErrorCode::BusinessRule,
			'This tool already failed ' . self::FAILURE_LIMIT . ' times this turn with the same error. Do not '
			. 'call it again and do not reword the arguments — the outcome will not change. ' . $guidance,
		), JSON_UNESCAPED_UNICODE);
	}

	private function accessDenied(): string
	{
		return json_encode(AiResponse::error(
			AiErrorCode::BusinessRule,
			'You do not have access to this tool.'
		), JSON_UNESCAPED_UNICODE);
	}

	protected function referenceExists(string $model, string $value): bool
	{
		if (!Str::isUuid($value)) {
			return false;
		}

		$class = Helper::model($model) ?? (class_exists($model) ? $model : null);

		return $class !== null && $class::whereKey($value)->exists();
	}

	protected function lookupExists(string $model, string $value): bool
	{
		$class = Helper::model($model);

		if (!is_a($class, SolarisLookup::class, true)) {
			return false;
		}

		return $class::toLookup()->contains(fn ($option) => (string) $option->id === $value);
	}

	protected function waToHtml(string $text): string
	{
		$text  = str_replace(["\r\n", "\r"], "\n", $text);
		$lines = explode("\n", $text);

		$blocks      = [];
		$buffer      = [];
		$currentType = null;

		$flush = function () use (&$blocks, &$buffer, &$currentType) {
			if (empty($buffer)) {
				return;
			}
			$blocks[]    = ['type' => $currentType, 'lines' => $buffer];
			$buffer      = [];
			$currentType = null;
		};

		foreach ($lines as $line) {
			if (preg_match('/^[-•]\s+(.+)$/', $line, $m)) {
				$type    = 'ul';
				$content = $m[1];
			} elseif (preg_match('/^\d+\.\s+(.+)$/', $line, $m)) {
				$type    = 'ol';
				$content = $m[1];
			} elseif (preg_match('/^>\s*(.*)$/', $line, $m)) {
				$type    = 'blockquote';
				$content = $m[1];
			} elseif (trim($line) === '') {
				$flush();
				continue;
			} else {
				$type    = 'p';
				$content = $line;
			}

			if ($type !== $currentType) {
				$flush();
				$currentType = $type;
			}

			$buffer[] = $content;
		}

		$flush();

		$html = '';
		foreach ($blocks as $block) {
			$html .= $this->renderWaBlock($block);
		}

		return $html;
	}

	private function renderWaBlock(array $block): string
	{
		$type  = $block['type'];
		$lines = $block['lines'];

		if ($type === 'ul') {
			$items = implode('', array_map(fn ($l) => '<li>' . $this->inlineWaFormat($l) . '</li>', $lines));

			return "<ul>{$items}</ul>";
		}

		if ($type === 'ol') {
			$items = implode('', array_map(fn ($l) => '<li>' . $this->inlineWaFormat($l) . '</li>', $lines));

			return "<ol>{$items}</ol>";
		}

		if ($type === 'blockquote') {
			$inner = implode('', array_map(fn ($l) => '<p>' . $this->inlineWaFormat($l) . '</p>', $lines));

			return "<blockquote>{$inner}</blockquote>";
		}

		return implode('', array_map(fn ($l) => '<p>' . $this->inlineWaFormat($l) . '</p>', $lines));
	}

	private function inlineWaFormat(string $text): string
	{
		$text = preg_replace('/`([^`]+)`/', '<code>$1</code>', $text);
		$text = preg_replace('/\*([^*]+)\*/', '<strong>$1</strong>', $text);
		$text = preg_replace('/_([^_]+)_/', '<em>$1</em>', $text);
		$text = preg_replace('/~([^~]+)~/', '<s>$1</s>', $text);

		return $text;
	}
}
