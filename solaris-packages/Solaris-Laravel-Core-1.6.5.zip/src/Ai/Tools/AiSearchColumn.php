<?php

namespace Solaris\Core\Ai\Tools;

use Solaris\Core\Services\Filter;

final class AiSearchColumn
{
	private const array STRING_DEFAULT_OPERATORS = [
		Filter::Equal, Filter::NotEqual, Filter::Contains, Filter::StartWith, Filter::EndWith,
		Filter::Similar, Filter::IsEmpty, Filter::IsNotEmpty,
	];

	private const array NUMBER_DEFAULT_OPERATORS = [
		Filter::Equal, Filter::NotEqual, Filter::Greater, Filter::GreaterOrEqual, Filter::Less, Filter::LessOrEqual,
		Filter::IsNull, Filter::IsNotNull,
	];

	private const array BOOLEAN_DEFAULT_OPERATORS = [Filter::Equal];

	private const array DATETIME_DEFAULT_OPERATORS = [
		Filter::Equal, Filter::NotEqual, Filter::Greater, Filter::GreaterOrEqual, Filter::Less, Filter::LessOrEqual,
		Filter::Between, Filter::NotBetween, Filter::IsNull, Filter::IsNotNull,
		Filter::IsToday, Filter::IsYesterday, Filter::IsThisWeek, Filter::IsLastWeek, Filter::IsThisMonth, Filter::IsLastMonth, Filter::IsThisYear, Filter::IsLastYear,
		Filter::IsYear, Filter::IsMonth, Filter::IsDay, Filter::IsMonthDay, Filter::IsLastN, Filter::IsNextN,
	];

	private const array LOOKUP_DEFAULT_OPERATORS = [Filter::Equal, Filter::NotEqual, Filter::In, Filter::NotIn, Filter::IsNull, Filter::IsNotNull];

	private const array REFERENCE_DEFAULT_OPERATORS = [Filter::Equal, Filter::NotEqual, Filter::IsNull, Filter::IsNotNull];

	private function __construct(
		public readonly string $column,
		public readonly AiColumnType $type,
		public readonly string $description,
		public readonly array $operators,
		public readonly bool|string $searchable = false,
		public readonly ?string $modelKey = null,
		public readonly ?string $sortColumn = null,
	) {}

	public static function string(string $column, string $description, ?array $operators = null, bool|string $searchable = false): self
	{
		return new self($column, AiColumnType::String, $description, $operators ?? self::STRING_DEFAULT_OPERATORS, $searchable);
	}

	public static function number(string $column, string $description, ?array $operators = null, bool|string $searchable = false): self
	{
		return new self($column, AiColumnType::Number, $description, $operators ?? self::NUMBER_DEFAULT_OPERATORS, $searchable);
	}

	public static function boolean(string $column, string $description, ?array $operators = null): self
	{
		return new self($column, AiColumnType::Boolean, $description, $operators ?? self::BOOLEAN_DEFAULT_OPERATORS);
	}

	public static function date(string $column, string $description, ?array $operators = null): self
	{
		return new self($column, AiColumnType::Date, $description, $operators ?? self::DATETIME_DEFAULT_OPERATORS);
	}

	public static function datetime(string $column, string $description, ?array $operators = null): self
	{
		return new self($column, AiColumnType::DateTime, $description, $operators ?? self::DATETIME_DEFAULT_OPERATORS);
	}

	public static function lookup(string $column, string $description, string $modelKey, ?array $operators = null, ?string $sortColumn = null): self
	{
		return new self($column, AiColumnType::Lookup, $description, $operators ?? self::LOOKUP_DEFAULT_OPERATORS, modelKey: $modelKey, sortColumn: $sortColumn);
	}

	public static function reference(string $column, string $description, string $modelKey, ?array $operators = null, ?string $sortColumn = null): self
	{
		return new self($column, AiColumnType::Reference, $description, $operators ?? self::REFERENCE_DEFAULT_OPERATORS, modelKey: $modelKey, sortColumn: $sortColumn);
	}

}
