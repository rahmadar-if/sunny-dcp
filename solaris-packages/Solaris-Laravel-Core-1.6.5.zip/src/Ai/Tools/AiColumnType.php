<?php

namespace Solaris\Core\Ai\Tools;

enum AiColumnType: string
{
	case String   = 'string';
	case Number   = 'number';
	case Boolean  = 'boolean';
	case Date     = 'date';
	case DateTime = 'datetime';
	case Lookup   = 'lookup';
	case Reference = 'reference';
}
