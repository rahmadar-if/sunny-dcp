<?php

namespace Solaris\Core\Ai\Tools\User;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

class SearchUserTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_user';
	}

	protected function resourceLabel(): string
	{
		return 'users — system/application user accounts';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('user'))();
	}

	protected function fields(): array
	{
		return [
			'name' => AiSearchColumn::string(
				column: 'name',
				description: 'Full name of the user',
				searchable: true,
			),
			'email' => AiSearchColumn::string(
				column: 'email',
				description: 'Email address of the user',
				searchable: true,
			),
			'username' => AiSearchColumn::string(
				column: 'username',
				description: 'Username of the user',
				searchable: true,
			),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'      => $record->id,
			'name'     => $record->name,
			'email'    => $record->email,
			'username' => $record->username,
		];
	}
}
