<?php

namespace Solaris\Core\Ai\Tools;

use Solaris\Core\Models\WaConversation;

interface NeedsWaConversation
{
	public function setConversation(WaConversation $conversation): static;
}
