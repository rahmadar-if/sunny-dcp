<?php

namespace Solaris\Core\Ai\Tools;

interface NeedsToolState
{
	public function setToolState(ToolTurnState $state): static;
}
