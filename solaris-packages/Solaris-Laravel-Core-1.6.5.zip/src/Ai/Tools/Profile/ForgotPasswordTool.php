<?php

namespace Solaris\Core\Ai\Tools\Profile;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Support\Facades\Password;
use Laravel\Ai\Tools\Request;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseConfirmAiTool;
use Stringable;

class ForgotPasswordTool extends BaseConfirmAiTool
{
	public static function slug(): string
	{
		return 'send_password_reset';
	}

	public function description(): Stringable|string
	{
		return 'Generate or send a password reset link when the user wants to change or reset their password. '
			. 'Passwords can NEVER be changed directly through WhatsApp — this tool either sends a reset link '
			. 'directly in this chat, or triggers the email reset flow. '
			. 'Two delivery modes controlled by the "via" parameter: '
			. '"chat" (default) — generate the reset link and include it directly in the WhatsApp reply; '
			. '"email" — send the reset link to the user\'s registered email instead. '
			. 'COMMANDS: "/reset-password" or "/forgot-password" are just a shortcut for via=chat — skip asking '
			. 'which channel. '
			. 'NATURAL LANGUAGE: ask the user whether they want the link sent here in chat or to their '
			. 'registered email, then call this tool with the appropriate "via" value. '
			. 'Call this tool NOW as soon as the delivery channel is known — do NOT wait for approval before '
			. 'calling it, and do NOT compose a confirmation or completion message yourself without calling '
			. 'it first. Requires confirmation before generating/sending — see the confirmation protocol. '
			. 'When delivering via chat, tell the user the link expires soon and to keep it private.';
	}

	public function schema(JsonSchema $schema): array
	{
		return array_merge($this->confirmationSchema($schema), [
			'via' => $schema->string()
				->enum(['chat', 'email'])
				->description('Delivery channel for the reset link. "chat" sends it here in WhatsApp (default); "email" sends it to the registered email.'),
		]);
	}

	public function validateConfirmation(Request $request): array
	{
		if (empty($this->user->email)) {
			return AiResponse::error(AiErrorCode::UserError, 'No email is registered for this account.');
		}

		$via = trim((string) ($request['via'] ?? 'chat'));

		return [
			'payload' => ['via' => $via],
			'summary' => ['via' => $via],
		];
	}

	public function executeConfirmed(Request $request, array $payload): array
	{
		$via = $payload['via'];

		if ($via === 'email') {
			Password::sendResetLink(['email' => $this->user->email]);

			return AiResponse::success(
				['via' => 'email', 'message' => 'Password reset link has been sent to the registered email.'],
				instruction: 'Reply to the user immediately with a brief one-line confirmation in their language.',
			);
		}

		$token    = Password::createToken($this->user);
		$resetUrl = route('password.reset', [
			'token' => $token,
			'email' => $this->user->getEmailForPasswordReset(),
		]);

		return AiResponse::success(
			['via' => 'chat', 'reset_url' => $resetUrl],
			instruction: 'Send this reset link directly in the WhatsApp reply. Warn the user it expires soon and to keep it private.',
		);
	}
}
