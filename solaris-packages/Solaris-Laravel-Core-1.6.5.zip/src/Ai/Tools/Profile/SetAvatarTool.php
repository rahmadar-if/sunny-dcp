<?php

namespace Solaris\Core\Ai\Tools\Profile;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\BaseSetAvatarTool;
use Stringable;

class SetAvatarTool extends BaseSetAvatarTool
{
	public static function slug(): string
	{
		return 'set_avatar';
	}

	public function description(): Stringable|string
	{
		return 'Set an already-uploaded attachment as the user\'s profile picture. '
			. 'Resolve the photo first via the channel\'s own media-resolution tool (e.g. wa_media_tool on '
			. 'WhatsApp), then pass its attachment_id — or, if it is still downloading, its pending_media_id, '
			. 'which is confirmed now and applied on its own once ready. '
			. 'Call this tool NOW as soon as you have either id — do NOT wait for approval before calling it, '
			. 'and do NOT compose a confirmation or completion message yourself without calling it first. '
			. 'Requires confirmation before applying — see the confirmation protocol. '
			. 'Briefly note that a square (1:1) photo gives the best result.';
	}

	protected function targetModel(): Model
	{
		return $this->user;
	}

	protected function targetColumn(): string
	{
		return 'profile_picture_id';
	}

	protected function successMessage(): string
	{
		return 'Profile picture updated.';
	}
}
