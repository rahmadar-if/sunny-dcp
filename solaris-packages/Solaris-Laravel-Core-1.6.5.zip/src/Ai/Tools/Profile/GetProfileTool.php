<?php

namespace Solaris\Core\Ai\Tools\Profile;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Laravel\Ai\Tools\Request;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseAiTool;
use Solaris\Core\Ai\Data\AiProfileData;
use Solaris\Core\Helpers\Helper;
use Stringable;

class GetProfileTool extends BaseAiTool
{
    public static function slug(): string
    {
        return 'get_profile';
    }

    public function description(): Stringable|string
    {
        return 'Retrieve the profile and biodata of the WhatsApp user you are currently assisting. '
            . 'Invoke this tool when the user asks about their own account or personal data, '
            . 'or when they send "/profile" or "/profile full". '
            . 'How to present the result depends on how it was triggered: '
            . 'COMMAND "/profile" — write a short, engaging narrative (1-2 natural sentences) covering '
            . 'only name, gender, and brief location (city or province level). Keep it warm and personal. '
            . 'COMMAND "/profile full" — present the complete biodata as a clean dot-list, '
            . 'one field per line with a newline between each item. Include all available fields. '
            . 'NATURAL LANGUAGE — share only the fields relevant to what the user asked. '
            . 'Sensitive details (email, phone number, full address, birthdate, two-factor and SSO info) '
            . 'are shown only when the user asks for them specifically, or when "/profile full" is used.';
    }

    protected function execute(Request $request): Stringable|string
    {
        $profileId = $this->user->profile?->id;
        if ($profileId === null) {
            return json_encode(AiResponse::error(AiErrorCode::NotFound, 'Profile not found.'), JSON_UNESCAPED_UNICODE);
        }

        $repo    = new (Helper::repository('profile'))(new (Helper::model('profile')));
        $profile = $repo->findComplete($profileId);

        return json_encode(
            AiResponse::success(AiProfileData::fromProfile($profile)->toArray()),
            JSON_UNESCAPED_UNICODE
        );
    }

    public function schema(JsonSchema $schema): array
    {
        return [];
    }
}
