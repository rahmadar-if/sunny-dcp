<?php

namespace Solaris\Core\Ai\Tools\Profile;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Carbon;
use Laravel\Ai\Tools\Request;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseUpdateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Http\Requests\ProfileRequest;
use Solaris\Core\Models\Profile;

class UpdateProfileTool extends BaseUpdateAiTool
{
	public static function slug(): string
	{
		return 'update_profile';
	}

	protected function resourceLabel(): string
	{
		return 'profile';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'name'          => $schema->string()->description('Full name.'),
			'nickname'      => $schema->string()->description('Preferred name or alias used to address the user.'),
			'phone_number'  => $schema->string()->description('Phone number.'),
			'birthdate'     => $schema->string()->description('Date of birth (Y-m-d).'),
			'birthplace'    => $schema->string()->description('Place of birth.'),
			'gender_id'     => $schema->string()->description('Gender id. Resolve via lookup_options with type: "gender".'),
			'salutation_id' => $schema->string()->description('Salutation id. Resolve via lookup_options with type: "salutation".'),
			'religion_id' 	=> $schema->string()->description('Religion id. Resolve via lookup_options with type: "religion".'),
			'chat_style_id' => $schema->string()->description(
				'Chat style id. Resolve via lookup_options with type: "chat_style". Casual, Friendly, or Professional.'
			),
			'address' => $schema->string()->description(
				'The user\'s full address text, verbatim — every part of what they typed '
					. '(street, building, RT/RW, kelurahan/kecamatan/city/province names, etc.), even the '
					. 'parts that are ALSO resolved separately into the region id fields below. Never trim '
					. 'it down to just the street portion.'
			),
			'country_id'      => $schema->string()->description('Country id — resolve via lookup_region.'),
			'province_id'     => $schema->string()->description('Province id — resolve via lookup_region.'),
			'city_id'         => $schema->string()->description('City id — resolve via lookup_region.'),
			'district_id'     => $schema->string()->description('District id — resolve via lookup_region.'),
			'sub_district_id' => $schema->string()->description(
				'Sub-district id — resolve via lookup_region. Postcode is filled automatically.'
			),
			'postcode' => $schema->string()->description('Postal code.'),
			'username' => $schema->string()->description(
				'Username. Can only be set while still empty; minimum 5 characters, not an email.'
			),
			'is_app_notification'    => $schema->boolean()->description('Enable/disable in-app notifications.'),
			'is_email_notification'  => $schema->boolean()->description('Enable/disable email notifications.'),
			'is_mobile_notification' => $schema->boolean()->description('Enable/disable mobile notifications.'),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::lookup(column: 'gender_id', label: 'gender', modelKey: 'gender'),
			AiColumn::lookup(column: 'salutation_id', label: 'salutation', modelKey: 'salutation'),
			AiColumn::lookup(column: 'religion_id', label: 'religion', modelKey: 'religion'),
			AiColumn::lookup(column: 'chat_style_id', label: 'chat style', modelKey: 'chat_style'),
			AiColumn::reference(column: 'country_id', label: 'country', modelKey: 'country'),
			AiColumn::reference(column: 'province_id', label: 'province', modelKey: 'province'),
			AiColumn::reference(column: 'city_id', label: 'city', modelKey: 'city'),
			AiColumn::reference(column: 'district_id', label: 'district', modelKey: 'district'),
			AiColumn::reference(column: 'sub_district_id', label: 'sub district', modelKey: 'sub_district'),
		];
	}

	private function columnLabel(string $column): string
	{
		return match ($column) {
			'phone_number'  => 'phone number',
			'gender_id' 	=> 'gender',
			'salutation_id' => 'salutation',
			'religion_id' 	=> 'religion',
			'chat_style_id' => 'chat style',
			'country_id'  	=> 'country',
			'province_id' 	=> 'province',
			'city_id' 		=> 'city',
			'district_id' 	=> 'district',
			'sub_district_id' 	  	 => 'sub district',
			'is_app_notification' 	 => 'in-app notification',
			'is_email_notification'  => 'email notification',
			'is_mobile_notification' => 'mobile notification',
			default => $column,
		};
	}

	protected function rules(): array
	{
		return ProfileRequest::profileRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/update-profile" with no other text, ask what they would like to update. '
			. 'If the user sends "/update-profile" followed by a description of the changes they want, '
			. 'extract the fields directly and proceed to confirmation — skip clarifying questions unless a field is ambiguous.'
			. "\n\n"
			. 'ADDRESS: Always pass the user\'s full address text verbatim into `address` — never drop or '
			. 'rewrite any part of it, even the parts you also resolve into region fields below. Separately, '
			. 'scan that same text for region names using these Indonesian terms: kelurahan/kel./desa = '
			. 'sub_district; kecamatan/kec. = district; kabupaten/kota/kab./kotamadya = city; provinsi/prov. '
			. '= province. Whenever ANY of these appear — however casually, abbreviated, or mixed in with '
			. 'other address text — you MUST call lookup_region to resolve it; never leave a region '
			. 'mentioned by the user unresolved just because it is already captured inside `address`. Pass '
			. 'ONLY the most specific region id found (sub_district beats district beats city beats '
			. 'province) — parent regions are filled automatically (e.g. passing sub_district_id auto-fills '
			. 'district, city, province, country, and postcode). If a mentioned region name does not match '
			. 'what lookup_region returns, tell the user and confirm the correct one before proceeding — '
			. 'never guess or silently drop it. '
			. 'If a salutation implies gender (Mr = Male, Mrs/Ms = Female) and gender is not given, set gender accordingly. '
			. 'Email cannot be changed. Username can only be set once (while still empty). '
			. 'Password and two-factor cannot be changed over WhatsApp. '
			. 'Push notifications cannot be enabled via WhatsApp. '
			. 'CHAT STYLE: three options — Casual (relaxed tone, always addresses the user by nickname or '
			. '"Kak"), Friendly (default — balanced tone, address term depends on age/salutation as usual), '
			. 'Professional (formal tone, always addresses the user as Pak/Ibu regardless of nickname). If '
			. 'the user asks to change how you talk to them, explain these three and set this field '
			. 'accordingly.';
	}

	protected function resolveRecordId(Request $request): string
	{
		return (string) ($this->user->profile?->id ?? '');
	}

	protected function findRecordById(string $id): ?Profile
	{
		return $this->user->profile;
	}

	protected function currentData(mixed $record): array
	{
		return [
			'name'                   => $record->name,
			'nickname'               => $record->nickname,
			'phone_number'           => $record->phone_number,
			'salutation_id'          => $record->salutation_id,
			'gender_id'              => $record->gender_id,
			'birthdate'              => $record->birthdate
				? Carbon::parse($record->birthdate)->format('Y-m-d')
				: null,
			'birthplace'             => $record->birthplace,
			'religion_id'            => $record->religion_id,
			'chat_style_id'          => $record->chat_style_id,
			'address'                => $record->address,
			'country_id'             => $record->country_id,
			'province_id'            => $record->province_id,
			'city_id'                => $record->city_id,
			'district_id'            => $record->district_id,
			'sub_district_id'        => $record->sub_district_id,
			'postcode'               => $record->postcode,
			'username'               => $this->user->username,
			'is_app_notification'    => (bool) $this->user->is_app_notification,
			'is_email_notification'  => (bool) $this->user->is_email_notification,
			'is_mobile_notification' => (bool) $this->user->is_mobile_notification,
		];
	}

	protected function update(Model $record, array $validated, array $changes): array
	{
		if (isset($changes['username']) && !empty($this->user->username)) {
			return AiResponse::error(AiErrorCode::BusinessRule, 'Username is already set and cannot be changed.');
		}

		$validated = $this->cascadeRegion($validated, $changes);

		$repo = new (Helper::repository('profile'))(new (Helper::model('profile')));
		$repo->update(
			$record->id, 
			$validated, 
			before: fn($_record, $data) => $this->beforeUpdate($_record, $data, $changes),
			after: fn($_record) => $this->afterUpdate($_record, $changes)
		);

		return AiResponse::success(
			['updated' => array_values(array_map(
				fn ($key) => $this->columnLabel($key),
				array_keys($changes),
			))],
			instruction: 'Reply to the user immediately with a brief one-line confirmation in their language.',
		);
	}

	private function cascadeRegion(array $validated, array $changes): array
	{
		if (isset($changes['sub_district_id'])) {
			$row = Helper::model('sub_district')::find($changes['sub_district_id']);
			if ($row) {
				foreach (['district_id', 'city_id', 'province_id', 'country_id', 'postcode'] as $field) {
					if (!isset($changes[$field]) && !empty($row->$field)) {
						$validated[$field] = $row->$field;
					}
				}
			}
			return $validated;
		}

		if (isset($changes['district_id'])) {
			$row = Helper::model('district')::find($changes['district_id']);
			if ($row) {
				foreach (['city_id', 'province_id', 'country_id'] as $field) {
					if (!isset($changes[$field]) && !empty($row->$field)) {
						$validated[$field] = $row->$field;
					}
				}
			}
			return $validated;
		}

		if (isset($changes['city_id'])) {
			$row = Helper::model('city')::find($changes['city_id']);
			if ($row) {
				foreach (['province_id', 'country_id'] as $field) {
					if (!isset($changes[$field]) && !empty($row->$field)) {
						$validated[$field] = $row->$field;
					}
				}
			}
			return $validated;
		}

		if (isset($changes['province_id'])) {
			$row = Helper::model('province')::find($changes['province_id']);
			if ($row && !isset($changes['country_id']) && !empty($row->country_id)) {
				$validated['country_id'] = $row->country_id;
			}
		}

		return $validated;
	}
}
