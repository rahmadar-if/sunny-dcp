<?php

namespace Solaris\Core\Ai\Tools;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Laravel\Ai\Tools\Request;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\WaAiConfirmation;
use Stringable;

trait HasConfirmation
{
	abstract public static function slug(): string;

	protected function execute(Request $request): Stringable|string
	{
		$token = trim((string) ($request['confirmation_token'] ?? ''));

		if ($token === '') {
			return json_encode($this->startConfirmation($request), JSON_UNESCAPED_UNICODE);
		}

		if ((bool) ($request['cancel'] ?? false)) {
			return json_encode($this->cancelConfirmation($token), JSON_UNESCAPED_UNICODE);
		}

		if ((bool) ($request['reset'] ?? false)) {
			$cancelled = $this->cancelConfirmation($token);

			if (isset($cancelled['error'])) {
				return json_encode($cancelled, JSON_UNESCAPED_UNICODE);
			}

			return json_encode($this->startConfirmation($request), JSON_UNESCAPED_UNICODE);
		}

		return json_encode($this->confirmAndExecute($request, $token), JSON_UNESCAPED_UNICODE);
	}

	protected function confirmationSchema(JsonSchema $schema): array
	{
		return [
			'confirmation_token' => $schema->string()->description(
				'Leave empty on the first call. After the user explicitly confirms, call again passing the '
				. 'confirmation_token value returned by the first call — no other fields needed.'
			),
			'reset' => $schema->boolean()->description(
				'Set true together with confirmation_token AND the corrected field values when the user wants to '
				. 'change something before confirming. Invalidates the previous confirmation_token and issues a '
				. 'new one for the corrected data.'
			),
			'cancel' => $schema->boolean()->description(
				'Set true together with confirmation_token when the user declines the pending action. Cancels it '
				. '— no new confirmation is issued.'
			),
		];
	}

	protected function issueConfirmation(array $payload, array $summary = []): array
	{
		$ttl = (int) Helper::config('ai.tool_settings.confirmation.ttl_minutes', 30);

		$record = WaAiConfirmation::create([
			'id'        => (string) Str::uuid7(),
			'user_id'   => Auth::id(),
			'tool_name' => static::slug(),
			'payload'   => $payload,
			'exp_at'    => now()->addMinutes($ttl),
			'status'    => WaAiConfirmation::StatusPending,
		]);

		return AiResponse::pending(
			$record->id,
			'Present this as a confirmation request to the user in their language, WhatsApp-formatted. Wait '
				. 'for their explicit approval — do not call this tool again until they respond. Once approved, '
				. 'call this exact same tool again passing ONLY confirmation_token. If the user wants to change '
				. 'something first, call again with confirmation_token, reset=true, and the corrected fields. If '
				. 'the user declines, call again with confirmation_token and cancel=true.',
			$summary,
		);
	}

	private function startConfirmation(Request $request): array
	{
		$result = $this->validateConfirmation($request);

		if (isset($result['error'])) {
			return $result;
		}

		return $this->issueConfirmation($result['payload'], $result['summary'] ?? []);
	}

	private function confirmAndExecute(Request $request, string $token): array
	{
		$lookup = $this->lookupRequest($token);

		if ($lookup['status'] !== 'found') {
			return $this->confirmationError($lookup['status']);
		}

		$result = $this->executeConfirmed($request, $lookup['payload']);

		if (empty($result['error'])) {
			WaAiConfirmation::whereKey($lookup['model']->id)
				->where('status', WaAiConfirmation::StatusPending)
				->update(['status' => WaAiConfirmation::StatusConfirmed]);

			return $result;
		}

		$lookup['model']->update(['message' => (string) ($result['message'] ?? $result['error'])]);

		return $result;
	}

	private function cancelConfirmation(string $token): array
	{
		$record = WaAiConfirmation::find($token);

		if ($record === null || $record->tool_name !== static::slug() || $record->user_id !== Auth::id()) {
			return AiResponse::cancelled('The pending confirmation was cancelled.');
		}

		if ($record->status !== WaAiConfirmation::StatusPending) {
			return AiResponse::error(
				AiErrorCode::BusinessRule,
				'This action was already approved and is being carried out — it can no longer be cancelled.',
			);
		}

		$record->update(['status' => WaAiConfirmation::StatusCancelled]);

		return AiResponse::cancelled('The pending confirmation was cancelled.');
	}

	private function lookupRequest(string $token): array
	{
		$record = WaAiConfirmation::find($token);

		if ($record === null || $record->status !== WaAiConfirmation::StatusPending) {
			return ['status' => 'not_found'];
		}

		if ($record->tool_name !== static::slug() || $record->user_id !== Auth::id()) {
			return ['status' => 'invalid'];
		}

		if (now()->gt($record->exp_at)) {
			$record->update(['status' => WaAiConfirmation::StatusExpired]);

			return ['status' => 'expired'];
		}

		return ['status' => 'found', 'model' => $record, 'payload' => $record->payload ?? []];
	}

	private function confirmationError(string $status): array
	{
		return match ($status) {
			'invalid' => AiResponse::error(AiErrorCode::UserError, 'This confirmation token does not belong to this action or user.'),
			'expired' => AiResponse::error(AiErrorCode::UserError, 'This confirmation has expired or was already used. Ask the user for the details again.'),
			default   => AiResponse::error(AiErrorCode::UserError, 'This confirmation token does not exist. Validate the request again from the start.'),
		};
	}
}
