<?php

namespace Solaris\Core\Ai\Tools;

final class AiResponse
{
	public static function success(array $data = [], ?string $instruction = null): array
	{
		$response = array_merge(['success' => true], $data);

		if ($instruction !== null) {
			$response['_instruction'] = $instruction;
		}

		return $response;
	}

	public static function error(
		AiErrorCode $code,
		string $message,
		array $extra = [],
		?string $debug = null,
	): array {
		$payload = [
			'error'   => $code->value,
			'message' => $message,
		];

		if ($debug !== null) {
			$payload['debug'] = $debug;
		}

		return array_merge($payload, $extra);
	}

	public static function cancelled(string $message): array
	{
		return ['cancelled' => true, 'message' => $message];
	}

	public static function pending(string $token, string $instruction, array $summary = []): array
	{
		return array_merge($summary, [
			'pending_confirmation' => true,
			'confirmation_token'   => $token,
			'_instruction'         => $instruction,
		]);
	}
}
