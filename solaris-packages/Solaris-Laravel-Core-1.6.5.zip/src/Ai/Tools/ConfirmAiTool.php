<?php

namespace Solaris\Core\Ai\Tools;

use Laravel\Ai\Tools\Request;

interface ConfirmAiTool
{
	public function validateConfirmation(Request $request): array;

	public function executeConfirmed(Request $request, array $payload): array;
}
