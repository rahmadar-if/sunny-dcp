<?php

namespace Solaris\Core\Ai\Tools;

use Illuminate\Contracts\Auth\Authenticatable;

interface AiSearchable
{
	public static function searchLookup(Authenticatable $user, array $params): array;

	public function search(array $params): array;
}
