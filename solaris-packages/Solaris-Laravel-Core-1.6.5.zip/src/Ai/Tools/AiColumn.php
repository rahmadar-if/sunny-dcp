<?php

namespace Solaris\Core\Ai\Tools;

final class AiColumn
{
	private function __construct(
		public readonly string $column,
		public readonly AiColumnType $type,
		public readonly string $param,
		public readonly string $label,
		public readonly string $description = '',
		public readonly bool $required = false,
		public readonly ?array $values = null,
		public readonly ?string $modelKey = null,
		public readonly ?array $filterable = null,
		public readonly ?string $resolver = null,
	) {}

	public static function string(string $column, string $label, string $description = '', bool $required = false, ?array $values = null, ?string $param = null): self
	{
		return new self($column, AiColumnType::String, $param ?? $column, $label, $description, $required, $values);
	}

	public static function number(string $column, string $label, string $description = '', bool $required = false, ?string $param = null): self
	{
		return new self($column, AiColumnType::Number, $param ?? $column, $label, $description, $required);
	}

	public static function boolean(string $column, string $label, string $description = '', ?string $param = null): self
	{
		return new self($column, AiColumnType::Boolean, $param ?? $column, $label, $description);
	}

	public static function date(string $column, string $label, string $description = '', bool $required = false, ?string $param = null): self
	{
		return new self($column, AiColumnType::Date, $param ?? $column, $label, $description, $required);
	}

	public static function datetime(string $column, string $label, string $description = '', bool $required = false, ?string $param = null): self
	{
		return new self($column, AiColumnType::DateTime, $param ?? $column, $label, $description, $required);
	}

	public static function lookup(string $column, string $label, string $modelKey, string $description = '', bool $required = false, ?string $param = null): self
	{
		return new self($column, AiColumnType::Lookup, $param ?? $column, $label, $description, $required, modelKey: $modelKey);
	}

	public static function reference(string $column, string $label, string $modelKey, string $description = '', bool $required = false, ?array $filterable = null, ?string $resolver = null, ?string $param = null): self
	{
		return new self($column, AiColumnType::Reference, $param ?? $column, $label, $description, $required, modelKey: $modelKey, filterable: $filterable, resolver: $resolver);
	}
}
