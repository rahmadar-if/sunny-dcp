<?php

namespace Solaris\Core\Ai\Tools;

enum AiErrorCode: string
{
	case UserError    = 'user_error';
	case NotFound     = 'not_found';
	case BusinessRule = 'business_rule';
	case Inconclusive = 'inconclusive';
	case SystemError  = 'system_error';
}
