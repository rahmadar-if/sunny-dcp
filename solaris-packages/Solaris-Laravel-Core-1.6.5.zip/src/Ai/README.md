# AI Tools — Developer Guide

How to build a WhatsApp AI tool in this package (and consumer packages: masterdata, basecrm,
sales, marketing). Every tool's `description()`/`schema()` is sent to the LLM on **every** request
in the conversation — keep them lean. Full mechanics live once in `WhatsAppAgent::instructions()`;
a tool's own description should only state what makes it different.

## 1. Decide which base class to extend

```
Does calling this tool create/update/delete data, or trigger a real side effect
(send email, send WhatsApp message, clear state, etc.)?
│
├─ NO (pure read/search, nothing changes) ─────────────────► BaseAiTool (direct)
│                                                              or BaseSearchTool (see §5)
│
└─ YES (something happens) ─────────────────────────────────► BaseConfirmAiTool family
     │
     ├─ Creates a brand-new record, fields map 1:1 to a model ──► BaseCreateAiTool
     ├─ Updates an existing record, fields map 1:1 to a model ──► BaseUpdateAiTool
     ├─ Deletes an existing record ────────────────────────────► BaseDeleteAiTool
     └─ Anything else that mutates/sends but isn't a full-model
        CRUD (send reset link, clear conversation, custom
        business action, a handful of ad-hoc params) ──────────► BaseConfirmAiTool (direct)
```

Never skip confirmation for a mutating action "because it's a slash command" — commands are only
a shortcut for gathering input, they never bypass confirmation. See `ForgotPasswordTool` /
`ResetWaConversationTool` / `BaseSetAvatarTool` for real examples of each shape.

## 2. Every tool needs

```php
abstract public static function slug(): string;          // snake_case, e.g. 'update_profile'
abstract public function description(): Stringable|string;
abstract public function schema(JsonSchema $schema): array;
```

**Instantiation is `new $class()` — no arguments, no `make()` factory.** Context is injected
after construction, via interface + trait pairs (each optional, add only what the tool needs):

```php
implements NeedsUser        + use HasUser;          // $this->user   (Authenticatable)
implements NeedsWaConversation + use HasWaConversation;  // $this->conversation (WaConversation)
```

`BaseAiTool` already `implements NeedsUser, use HasUser` for you — every `BaseCreateAiTool` /
`BaseUpdateAiTool` / `BaseDeleteAiTool` / `BaseSearchTool` / `BaseConfirmAiTool` subclass gets
`$this->user` for free. Add `NeedsWaConversation`/`HasWaConversation` yourself only if the tool
needs to know the active WhatsApp device/thread — e.g. to send a file as a side effect
(`sendMedia`) instead of just returning text. See `ResetWaConversationTool` / `WaMediaTool` for
real examples; a tool needing conversation but not `$this->user` can skip `BaseConfirmAiTool`
entirely and compose `implements Tool, ConfirmAiTool, NeedsWaConversation` +
`use HasConfirmation, HasWaConversation` directly (see `ResetWaConversationTool`).

`handle()` is provided for you by `HasConfirmation` if you extend `BaseConfirmAiTool` (see §3), or
implemented directly by `BaseAiTool`/`BaseSearchTool` for read-only tools.

You don't register a tool by hand — `solaris:ai-sync` (`AiRegistryService`) auto-discovers it from
the package `ai.tools` config and the `App\Ai\Tools` convention folder, upserting an `ai_tools` row
keyed by `slug()`. What controls who can call it, and from which agent, is the access model in §10.

## 3. Tools that need confirmation (`BaseConfirmAiTool`)

Implement 2 methods instead of `handle()`:

```php
public function validateConfirmation(Request $request): array;
// Runs only on the FIRST call (no confirmation_token yet). Validate/load/guard everything needed
// — find the target record, check preconditions, validate input. Return an AiResponse::error(...)
// array to short-circuit, or ['payload' => ..., 'summary' => ...] on success.
// $payload is frozen behind the token — it is what executeConfirmed() will actually run on, never
// re-derived from a later request, so the model can never smuggle changed data through the reply.

public function executeConfirmed(Request $request, array $payload): array;
// Runs only once the user has approved (confirmation_token supplied and valid). Perform the
// actual mutation/side effect and return AiResponse::success(...) or AiResponse::error(...).
// If this returns an error, the token stays alive (status remains 'pending') so the model can
// retry the SAME confirmation once the underlying issue is fixed, without re-confirming.
```

The trait (`HasConfirmation`) handles the rest: issuing the token (`WaAiConfirmation` row), the
`reset=true` (invalidate + revalidate fresh data) and `cancel=true` (invalidate, no reissue)
branches, and token validity checks (not_found / invalid / expired). None of this needs to be
re-explained in your tool's `description()` — the model already knows the protocol globally.

Your `schema()` must merge in `$this->confirmationSchema($schema)` (adds `confirmation_token`,
`reset`, `cancel`) unless you extend `BaseCreateAiTool`/`BaseUpdateAiTool`/`BaseDeleteAiTool`,
which already do this for you (their `schema()` is `final`).

### 3a. `BaseCreateAiTool`

```php
abstract protected function resourceLabel(): string;                       // "opportunity", "product", ...
abstract public static function fields(JsonSchema $schema): array;         // LLM-facing schema — $schema->string()->description(...)->required(), etc.
abstract protected function rules(): array;                                // Laravel Validator rules, keyed by field
abstract protected function create(array $validated, array $raw): array;   // do the insert, return AiResponse::success()/error()

protected function descriptionExtra(): ?string { return null; }            // optional tool-specific extra prose
protected function beforeCreate(array $data, array $raw): array { return $data; }   // optional hook, mirrors BaseRepository::creating()
protected function afterCreate(mixed $record, array $raw): void { }                 // optional hook, mirrors BaseRepository::created()
protected function lookupChecks(): array { return []; }                    // AiColumn::lookup()/reference() — see §4
protected function afterValidation(Validator $validator): void { }         // see §4a
```

For a nested "create children in the same confirmation" resource (e.g. `detail_contacts` on
`create_account`), use the inherited `validateDetailList(array $items, array $rules, string
$parentKey, string $parentId): array` helper inside `validateConfirmation()` — never re-declare a
method with this name in the subclass (it shadows the base one with reduced visibility, which is a
PHP fatal error). See `CreateAccountTool` (MasterData) for the full pattern.

### 3b. `BaseUpdateAiTool`

Same shape as Create, plus:

```php
abstract protected function findRecord(Request $request): ?Model;        // null => not found (auto AiResponse::error)
abstract protected function currentData(mixed $record): array;           // full current values, merged with changes for validation — MUST cover every key in rules()/fields(), or an untouched field can be silently overwritten with null on save
abstract protected function update(mixed $record, array $validated, array $changes): array;

protected function beforeUpdate(mixed $record, array $data, array $raw): array { return $data; }  // optional hook
protected function afterUpdate(mixed $record, array $changes): void { }                            // optional hook
```

Same nested-children pattern as Create, via the inherited `resolveDetailOperations(array $items,
string $modelClass, array $createRules, array $updateRules, string $parentKey, string $parentId):
array` helper — handles create/update/delete per row (omit id → create, id + fields → update, id +
`delete:true` → delete). See `UpdateAccountTool` (MasterData) for the full pattern.

### 3c. `BaseDeleteAiTool`

```php
abstract protected function resourceLabel(): string;
abstract protected function findRecord(Request $request): mixed;   // schema already requires 'id'
abstract protected function delete(mixed $record): array;

protected function guardDelete(mixed $record): ?string { return null; }  // non-null string blocks deletion, surfaced as error
```

### 3d. Custom process — extend `BaseConfirmAiTool` directly

For anything that mutates/sends but doesn't map to a model's full field set (send a link, clear a
flag, trigger a service call, upload a file). Declare only the params you actually need in
`schema()` with the `JsonSchema` builder, or none at all if the action has no data (e.g.
`ResetWaConversationTool` — `validateConfirmation()` just returns `['payload' => [], 'summary' =>
[]]`). See `UploadAttachmentTool` / `BaseSetAvatarTool` / `ResetWaConversationTool` for real,
working examples — copy one of those, not the shape below from memory.

## 4. `lookupChecks()` — validating reference/lookup ids with `AiColumn`

`fields()`/`columns` for the LLM are declared with the `JsonSchema` builder (`$schema->string()`,
`$schema->boolean()`, `$schema->array()->items(...)`, etc.) — **never** with `AiColumn`. `AiColumn`
has one job: entries in `lookupChecks()`, checked automatically by `BaseCreateAiTool`/
`BaseUpdateAiTool` after `rules()` passes, so a bad id gets a friendly "not a valid X" error
instead of a raw DB failure.

```php
AiColumn::lookup(column: 'type_id', label: 'account type', modelKey: 'account_type');
// small, cached (SolarisLookup) — e.g. gender, salutation. Checked via the model's own toLookup() cache.

AiColumn::reference(column: 'account_id', label: 'account', modelKey: 'account');
// large/paginated model. Checked via a plain whereKey()->exists() query.
```

Every field with a `modelKey` (lookup or reference) in `fields()` should have a matching entry in
`lookupChecks()` — this is a common gap, always cross-check the two lists when reviewing a tool.

### 4a. `afterValidation()` — constraints `rules()` can't express as static strings

```php
protected function afterValidation(\Illuminate\Contracts\Validation\Validator $validator): void { }
```

Available on `BaseCreateAiTool`/`BaseUpdateAiTool`, called right after `Validator::make()`, before
`fails()` is checked. Mirrors `FormRequest::withValidator()` — mutates the SAME validator instance
(register via `$validator->after(fn ($v) => ...)` to run after the base rules pass), it does not
stand alone. Use this to reuse an existing `FormRequest`'s custom cross-field rule (e.g.
`AccountRequest::validateFrequency()`) that would otherwise only ever fire on the web/API path,
never on the AI path — `Validator::make($data, $this->rules())` (a plain static rules array) never
triggers a `FormRequest`'s own `withValidator()` hook.

## 5. Read-only search tools — `BaseSearchTool`

For a resource that needs rich, multi-column, filterable search (not just "resolve to an id" —
see `lookup_options` for that). Extends `BaseAiTool`, implements `AiSearchable` (see §6).

```php
abstract protected function resourceLabel(): string;
abstract protected function model(): BaseModel;
abstract protected function fields(): array;                // search-specific shape: field => AiSearchColumn (type, description, operators, searchable, ...)
abstract protected function formatRecord(Model $record): array;

protected function relations(): array { return []; }         // relation-group / aggregate-condition filter targets
protected function descriptionExtra(): ?string { return null; }
```

Note: `BaseSearchTool::fields()` is a **different** shape than `BaseCreateAiTool`/`BaseUpdateAiTool`'s
`fields()` — it feeds the `# COLUMNS` block in `description()` (filter documentation), not
`schema()`. `schema()` on a search tool is `final` (`search`/`search_synonyms`/`filter`/`limit`/
`aggregate`), identical across every resource. Use `AiSearchColumn`, never `AiColumn`, here.

A decorator subclass (e.g. a `sales` package adding opportunity-aware columns to `basecrm`'s
`search_contact`) extends the parent's concrete tool directly and calls `parent::resourceLabel()`
/`parent::fields()`/`parent::formatRecord()`/`parent::relations()` — get the method names exactly
right, a typo (e.g. `columns()` instead of `fields()`) silently produces dead code: the override
never runs and the base's own method still wins, since nothing else in the class calls the
misspelled name.

## 6. Making a tool delegatable via `lookup_options` — `AiSearchable`

Any **read-only** tool (a `BaseSearchTool` subclass, or something like `LookupRegionTool`) can be
called generically through `lookup_options` mode 3 (`{tool: "your_tool_name", params: {...}}`) if
it implements `AiSearchable` and uses `HasSearchLookup`:

```php
class YourSearchTool extends BaseSearchTool  // or BaseAiTool implements AiSearchable, use HasSearchLookup
{
    // BaseSearchTool already implements AiSearchable + uses HasSearchLookup for you.
}
```

This works because `HasSearchLookup::searchLookup(Authenticatable $user, array $params)` does
`new static()`, calls `setUser($user)` if the instance `implements NeedsUser`, then calls
`->search($params)` — your `handle()`/`execute()` must be a thin wrapper around a `search(array
$params): array` method (plain array in/out, no `json_encode`) so both the direct tool call and
the batch delegation reuse the exact same logic (`BaseSearchTool::execute()` already does this for
you). **Never** make a mutating tool implement `AiSearchable` — `lookup_options` treats that
interface as its ONLY safety gate for what it's allowed to call.

## 7. Response shape — `AiResponse`

Never build the JSON payload by hand. Use:

```php
AiResponse::success(array $data = [], ?string $instruction = null): array
AiResponse::error(AiErrorCode $code, string $message, array $extra = [], ?string $debug = null): array
AiResponse::cancelled(string $message): array   // used internally by HasConfirmation, rarely called directly
AiResponse::pending(string $token, string $instruction, array $summary = []): array  // ditto
```

`$instruction` (on `success()`) is a behavioral note for the model (e.g. "reply immediately with
a one-line confirmation") — not shown to the user verbatim. `$extra` (on `error()`) carries
structured detail like `details`/`messages` for validation-style failures.

`$code` is one of 5 fixed `AiErrorCode` cases — `UserError`, `NotFound`, `BusinessRule`,
`Inconclusive`, `SystemError` — which tells the orchestrator what to do with the error, not what
specifically went wrong (that's `$message`'s job). `SystemError` is the only case whose `$message`
must stay generic — pass the real exception/detail via `$debug` instead, which is log-only and
never relayed to the user or the model as the reply.

## 8. Writing `description()`

- State what the tool does, its params, and anything genuinely tool-specific (a command shortcut,
  a business rule, output formatting guidance). Keep it short.
- If it requires confirmation: add ONE line — *"Requires confirmation before X — see the
  confirmation protocol."* Do not re-explain confirmation_token/reset/cancel; that's covered once
  in `WhatsAppAgent::instructions()`.
- If it has `lookup`/`reference` columns, `BaseCreateAiTool`/`BaseUpdateAiTool` already append the
  resolution hints (model_key / filterable / resolver) automatically — don't duplicate them.
- Don't say "no confirmation needed" on read-only tools — that's the default, stating it is
  wasted tokens.

## 9. One confirmation = one tool

Never rely on the model to orchestrate multiple independent confirmations into a single user
approval. If a workflow genuinely needs to act on several items at once, build a dedicated batch
tool for it (its own `fields()`/validation covering the whole batch) rather than expecting the
model to chain several single-item tool calls under one confirmation.

## 10. Registry, access control & agents

### Registry (`solaris:ai-sync`)

`AiRegistryService::sync()` mirrors code → DB in one transaction:

- **Agents** → `ai_agents`, **tools** → `ai_tools`, keyed by `slug()`. Sources: package `ai.agents`/
  `ai.tools` config + the `App\Ai\Agents` / `App\Ai\Tools` convention folders (auto-discovered).
  Rows whose class no longer exists are deleted.
- A **sub-agent** (an agent implementing `CanActAsTool`) is also registered as a tool, under its
  `name()` — **not** its `slug()`. E.g. `ProfileAgent` (slug `profile`) → tool `profile_specialist`.
- **Essential** items — a class with `#[AiEssential]`, or a tool listed in an essential agent's
  `essentialToolClasses()` — are flagged `is_default = true`, their agent↔tool pivot is written
  `is_locked = true`, and they are ACL-granted to the base `user` role. All automatic.

### Access control — pure DB, two gates

ACL is read straight from the pivot tables (`{user,role,permission}_ai_{agents,tools}`) via
`AiAccessService` — no conditional logic, no code-declared defaults. `is_default`/`is_locked` are
**UI flags only** (which rows admins may re-ACL / which wiring may be detached); they do NOT take
part in the access decision.

- **Tool ACL** (`accessibleToolIds`) → hard gate on *calling* a tool (`BaseAiTool::handle()`).
- **Agent ACL** (`accessibleAgentIds`) → gates *which agent a user may use*, and via `toolsFor()`
  filters which of that agent's tools surface to the LLM. Also enforced in
  `BaseAiAgent::__construct()`, so an agent constructed programmatically is gated too.

Every real user carries the base `user` role, so essential agents/tools are reachable by everyone by
default; anything else is opt-in via admin grants.

### Wiring an agent's tool set

- **Essential/locked** pairs → written by sync, never detachable.
- **Default wiring** → one-time bootstrap in `AiRegistrySeeder::wire()`.
- **Runtime** → admins attach/detach via the `assignTool` endpoint (`ai-agent/tool/{id}`); a locked
  pair cannot be removed.

### Two sub-agent patterns

1. **`CanActAsTool`** (`ProfileAgent` → `profile_specialist`): the agent *is* a tool. Tool ACL on
   that slug is the gate — no access, the orchestrator never even sees it.
2. **Wrapper tool** (`ExtractImagesTool` runs `new ImageExtractionAgent()`): the inner agent is
   constructed programmatically, so its own constructor gate applies. It throws
   `AiAuthorizationException` on denial — the wrapper tool must `try/catch` it and return
   `AiResponse::error(AiErrorCode::BusinessRule, …)` so the model can tell the user, instead of crashing the run.

### Routing: one owning specialist per request

The orchestrator picks the ONE specialist that owns the outcome. Entities the request merely refers
to — an account on an opportunity, a product on a line item, a source — are that specialist's own
job: it holds the lookups, knows which fields it needs, and its tool schemas already carry the exact
lookup type name (emitted by `BaseSearchTool::resolutionHint()`). Resolving them for it in advance
duplicates work and turns an empty orchestrator-side lookup into a dead end the specialist would
have handled.

Two mechanisms keep that from drifting. `WhatsAppAgent::excludedToolSlugs()` withholds
`lookup_options` from the orchestrator entirely — it owns no tool with lookup or reference columns,
so any type name it passed would be a guess. And `DelegateTurnState` is constructed with
`DELEGATE_CALLS_PER_SPECIALIST` (1), matching the instruction that every sub-task for one specialist
is batched into a single call. When adding an orchestrator-side tool that genuinely needs lookups,
drop the slug from the exclusion list rather than working around it.

### Interim acknowledgment

Delegating is always slow enough that silence reads as a hang. The model is instructed to call
`quick_reply` in the same step as its first specialist call — same step, so it costs no extra
round-trip. `DelegateTool::ensureAcknowledged()` covers the turn where it forgets, sending
`ai.tool_settings.quick_reply.default_message` instead. `QuickReplyWaTool::claimAck()` holds the
20-second lock both paths compete for, so exactly one ack goes out.

### Per-turn guardrails

Two pieces of state exist for the length of one orchestrator turn. Neither is something a tool
author wires up — both are injected automatically — but both change what the model sees.

**`ToolTurnState`** (injected into every `BaseAiTool` via `NeedsToolState`, held by `BaseAiAgent`)
counts failures per `slug|error_code`. After two identical failures `handle()` stops calling
`execute()` at all and returns a `BusinessRule` error telling the model to report the failure
instead of retrying. Models proved willing to retry the same broken search four times, the last
two with nonsense arguments; a prompt rule did not hold them. If a tool returns an `error` payload
for a reason the model *can* fix by changing arguments, make sure the code differs from the one it
returns for unfixable failures — the counter keys on that code.

**`DelegateTurnState`** (shared by every `DelegateTool` of one turn) additionally records each
specialist's successful answer. The next specialist's task is prefixed with a `FINDINGS FROM OTHER
SPECIALISTS THIS TURN` block holding them. Specialists keep separate conversation threads, so
without this a price or phone number one of them just retrieved is invisible to the next, and the
orchestrator was not reliably restating it. `BaseAiAgent::delegateOutputInstructions()` tells
delegate targets to treat that block as established fact.

That same instruction block also locks every delegate target to English and to compact,
data-only replies — the orchestrator owns the user's language. Agents whose output *is* user
content (`AudioExtractionAgent`, `ImageExtractionAgent`) and the orchestrator itself opt out with
`isDelegateTarget(): false`.

## Reference implementations in this package

| Pattern | Tool |
|---|---|
| Plain read-only | `GetProfileTool` |
| Confirm, no payload/validation, tied to `$this->user` | `ForgotPasswordTool` |
| Confirm, custom process (not full-model CRUD) | `BaseSetAvatarTool` |
| Confirm, needs `$this->conversation` not `$this->user`, composed directly (no base class) | `ResetWaConversationTool` |
| Confirm, custom process with a file side effect via `NeedsWaConversation` | `UploadAttachmentTool` (attachments), see also `WaMediaTool` |
| Create/Update, full model fields incl. lookup + reference, nested detail children | `CreateAccountTool` / `UpdateAccountTool` (MasterData) |
| Update, full model fields incl. lookup + reference(resolver) | `UpdateProfileTool` |
| Search tool delegatable via `lookup_options` | `LookupRegionTool` |
| Search tool decorated by a downstream package | `SearchAccountTool` (BaseCRM, extends MasterData's) |
| Generic batch lookup/reference resolver | `LookupOptionsTool` |
| Sub-agent exposed as a tool (`CanActAsTool`) | `ProfileAgent` (`profile_specialist`) |
| Agent run inside a wrapper tool — ACL-gated + graceful deny | `ImageExtractionAgent` via `ExtractImagesTool` |
