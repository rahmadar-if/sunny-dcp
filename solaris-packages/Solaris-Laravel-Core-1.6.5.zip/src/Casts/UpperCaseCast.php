<?php

namespace Solaris\Core\Casts;

use Illuminate\Contracts\Database\Eloquent\CastsAttributes;

class UpperCaseCast implements CastsAttributes
{
    public function get($model, string $key, $value, array $attributes)
    {
        return is_string($value) ? strtoupper($value) : $value;
    }

    public function set($model, string $key, $value, array $attributes)
    {
        return is_string($value) ? strtoupper($value) : $value;
    }
}