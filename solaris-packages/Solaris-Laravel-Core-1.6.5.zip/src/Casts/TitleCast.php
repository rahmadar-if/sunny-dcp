<?php

namespace Solaris\Core\Casts;

use Illuminate\Contracts\Database\Eloquent\CastsAttributes;
use Illuminate\Support\Str;

class TitleCast implements CastsAttributes
{
    public function get($model, string $key, $value, array $attributes)
    {
        return Str::title($value);
    }

    public function set($model, string $key, $value, array $attributes)
    {
        if (!is_string($value)) {
            return $value;
        }

        return Str::title($value);
    }
}