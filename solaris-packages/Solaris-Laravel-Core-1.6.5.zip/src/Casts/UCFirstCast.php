<?php

namespace Solaris\Core\Casts;

use Illuminate\Contracts\Database\Eloquent\CastsAttributes;

class UCFirstCast implements CastsAttributes
{
    public function get($model, string $key, $value, array $attributes)
    {
        return ucfirst(strtolower($value));
    }

    public function set($model, string $key, $value, array $attributes)
    {
        if (!is_string($value)) {
            return $value;
        }

        return ucfirst(strtolower($value));
    }
}