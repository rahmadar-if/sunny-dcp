<?php

namespace Solaris\Core\Const;

class RightLevelConst
{
    public const Grant         = '0199329b-a4d5-7276-a28f-ff9ab24a6a04';
    public const GrantDelegate = '0199329b-a4d5-77cf-9e77-047989a4790e';
    public const Deny          = '0199329b-a4d5-73a7-8205-1a1afd8d9565';
}