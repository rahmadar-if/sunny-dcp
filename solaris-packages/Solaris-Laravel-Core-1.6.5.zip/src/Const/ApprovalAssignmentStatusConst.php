<?php

namespace Solaris\Core\Const;

class ApprovalAssignmentStatusConst
{
	public const Pending   = '019cac97-782c-7b12-86cc-0cdba64270f4';
	public const Approved  = '019cac97-782c-73bc-b5ad-89c3bcbcb914';
	public const Rejected  = '019cac97-782c-78dc-ab5e-58941eede283';
	public const Dismissed = '019cac97-782c-770b-8140-54f1e1893afa';
}