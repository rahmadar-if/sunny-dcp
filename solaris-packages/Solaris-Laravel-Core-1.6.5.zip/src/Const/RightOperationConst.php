<?php

namespace Solaris\Core\Const;

class RightOperationConst
{
    public const Create = '019932a6-2c91-70ce-b9c7-c3e185b53621';
    public const Read   = '019932a6-2c91-74f2-9a5b-2d52c803b2a8';
    public const Update = '019932a6-2c91-7879-b6a6-2c4438bdc6ea';
    public const Delete = '019932a6-2c91-7618-a769-3f25fa0ac0af';
}