<?php

namespace Solaris\Core\Const;

class ApprovalLevelStatusConst
{
	public const Pending    = '019cac96-2dcd-78cc-84a7-a2cc514ea200';
	public const InProgress = '019cac96-2dcd-7d5c-896d-39a84b339122';
	public const Approved   = '019cac96-2dcd-75b3-bce7-ba0111518a26';
	public const Rejected   = '019cac96-2dcd-7205-a922-07921c6205f6';
	public const Skipped    = '019cac96-2dcd-7740-8427-e2c6f9ffe150';
}