<?php

namespace Solaris\Core\Const;

class RoleConst
{
    public const User        = '019c27d4-831f-7e33-8b9f-f328320c4d8b';
    public const Admin       = '019c27d4-831f-74b3-859f-a48dcca44e07';
    public const Integration = '019ffe19-7343-75df-af1e-9cdfaffb9503';
}