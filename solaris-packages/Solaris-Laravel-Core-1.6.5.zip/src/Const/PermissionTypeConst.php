<?php

namespace Solaris\Core\Const;

class PermissionTypeConst
{
    public const User       = '0199329a-aaf7-7d59-bca6-d91b349f489e';
    public const Role       = '0199329a-aaf7-73ed-80a3-ece242100c97';
    public const Permission = '0199329a-aaf7-7b04-9972-e84c648197b5';
}