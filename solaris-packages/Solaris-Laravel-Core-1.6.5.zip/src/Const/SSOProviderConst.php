<?php

namespace Solaris\Core\Const;

class SSOProviderConst
{
    public const Google   = 'google';
    public const EntraID  = 'entraid';
    public const LinkedIn = 'linkedin';
}
