<?php

namespace Solaris\Core\Const;

class ChatStyleConst
{
    public const Casual       = 'b1e2a3c4-1111-4a2b-9c3d-4e5f6a7b8c9d';
    public const Friendly     = 'b1e2a3c4-2222-4a2b-9c3d-4e5f6a7b8c9d';
    public const Professional = 'b1e2a3c4-3333-4a2b-9c3d-4e5f6a7b8c9d';
}
