<?php

namespace Solaris\Core\Const;

class ApprovalRequestStatusConst
{
	public const Pending    = '019cac97-f75e-7da5-9f61-c5e2ed7b525f';
	public const InProgress = '019cac97-f75e-74f2-90f9-031ecc5840ae';
	public const Approved   = '019cac97-f75e-76dc-b36c-a44d9dfa0d23';
	public const Rejected   = '019cac97-f75e-7d85-a569-33b4678f6e31';
	public const Cancelled  = '019cac97-f75e-7a96-be23-8f20aca26ff9';
	public const Expired    = '019cac97-f75e-756e-89a0-72190588bec5';
}