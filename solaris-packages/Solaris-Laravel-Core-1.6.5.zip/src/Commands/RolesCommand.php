<?php

namespace Solaris\Core\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Interfaces\Model\SolarisUser;
use Solaris\Core\Models\Permission;
use Solaris\Core\Models\Role;

use function Laravel\Prompts\error;
use function Laravel\Prompts\info;
use function Laravel\Prompts\select;
use function Laravel\Prompts\table;
use function Laravel\Prompts\text;
use function Laravel\Prompts\warning;

class RolesCommand extends Command
{
    protected $signature = 'solaris:roles
                                {action? : list, create, delete, user, permission }
                                {--name= : Role name for new, and can be name or id for delete. If action "list" then "name" not empty, then show list all user in a specific role }
                                {--user= : User name/email/id}
                                {--permission= : Permission name/id}';

    protected $description = 'Manage roles (list, create, delete)';

    protected $name;
    protected $user;
    protected $permission;
    protected $userModel;

    public function handle()
    {
        $this->name = $this->option('name');
        $this->user = $this->option('user');
        $this->permission = $this->option('permission');
        $this->userModel = Helper::model('user');

        $action = $this->argument('action') ?? 'list';

        try {
            switch ($action) {
                case 'list':
                    $this->showList();
                    break;

                case 'create':
                    $this->create();
                    break;

                case 'delete':
                    $this->delete();
                    break;

                case 'user':
                    $this->userAssign();
                    break;

                case 'permission':
                    $this->permissionAssign();
                    break;

                default:
                    error('Invalid action: ' . $action);
            }
        } catch (\Exception $e) {
            error($e->getMessage());
        }

        return self::SUCCESS;
    }

    protected function showList()
    {
        if(empty($this->name)) {
            $roles = Role::orderBy('name', 'asc')
                ->get(['id', 'name'])
                ->map(fn($item) => ['id' => $item->id, 'name' => $item->name]);
            
            info("List all available roles");
            table(['id', 'name'], $roles);
        } else {
            $role = Role::where(Str::isUuid($this->name) ? "id" : "name", $this->name)->get();
            if($role->isEmpty()) {
                return warning("Role is not found");
            }

            if($role->count() > 1) {
                $selectedRole = select("Select role", $role->pluck('name', 'id')->all());
                $role = Role::where("id", $selectedRole)->get();
            }
            
            $users = $role
                ->first()
                ->getUsers()
                ->map(fn($item) => ['id' => $item->id, 'name' => $item->name, 'email' => $item->email]);

            $permissions = $role
                ->first()
                ->getPermissions()
                ->map(fn($item) => ['id' => $item->id, 'name' => $item->name]);

            info("Users in ".$role->first()->name." role");
            table(['id', 'name', 'email'], $users);

            info("Permission in ".$role->first()->name." role");
            table(['id', 'name'], $permissions);
        }
    }

    protected function create()
    {
        if(Str::isUuid($this->name)) {
            return error('Name must be string');
        }

        if(empty($this->name)) {
            $this->name = text('Enter role name', required: true);
        }

        $exists = Role::where('name', $this->name)->exists();
        if($exists) {
            return warning("Role ".$this->name." is exists, try another one");
        }

        $role = Role::create(['name' => $this->name]);
        info("Role ".$this->name." successfully created with Id: ".$role->id);
    }

    protected function delete()
    {
        $role = $this->getRoleSelected("Select role to delete");

        $role->permissions()->detach();
        
        $userRoles = $role->getUsers();
        
        $role->users()->detach();
        $role->delete();

        foreach ($userRoles as $user) {
            Cache::forget("user:".$user->id.":roles");
        }

        info("Role ".$role->name." successfully deleted");
    }

    protected function userAssign()
    {
        $role = $this->getRoleSelected("Select role to be assigned");
        $user = $this->getUserSelected("Select user to be assigned");

        DB::table('user_roles')->insert([
            'id' => (string) Str::uuid7(),
            'user_id' => $user->id,
            'role_id' => $role->id
        ]);

        info("User ".$user->name." successfully assigned to Role ".$role->name);
    }

    protected function permissionAssign()
    {
        $role = $this->getRoleSelected("Select role to be assigned");
        $permission = $this->getPermissionSelected("Select permission to be assigned");

        DB::table('role_permissions')->insert([
            'id' => (string) Str::uuid7(),
            'role_id' => $role->id,
            'permission_id' => $permission->id,
        ]);

        info("Permission ".$permission->name." successfully assigned to Role ".$role->name);
    }

    protected function getRoleSelected($label): Role
    {
        $selected = null;

        if (empty($this->name)) {
            $roles = Role::get(['id', 'name']);
            if($roles->isEmpty()) {
                throw new \Exception("Roles not found");
            }

            $selected = select($label, $roles->pluck('name', 'id'));
        }

        if(is_null($selected) && !Str::isUuid($this->name)) {
            $roles = Role::where('name', $this->name)->get(['id', 'name']);
            if($roles->isEmpty()) {
                throw new \Exception("Role ".$this->name." is not found");
            }

            $selected = $roles->count() == 1 ? $roles->first()->id : select($label, $roles->pluck('name', 'id'));
        }

        $selected = !is_null($selected) ? $selected : $this->name;

        $role = Role::find($selected);
        if(is_null($role)) {
            throw new \Exception("Role ".$this->name." is not found");
        }

        return $role;
    }

    protected function getUserSelected($label): SolarisUser
    {
        $selected = null;

        if (empty($this->user)) {
            $users = $this->userModel::get(['id', 'name']);
            if($users->isEmpty()) {
                throw new \Exception("User not found");
            }

            $selected = select($label, $users->pluck('name', 'id'));
        }

        if(is_null($selected) && !Str::isUuid($this->user)) {
            $users = $this->userModel::where('name', $this->user)
                ->orWhere('email', $this->user)
                ->get(['id', 'name']);
            if($users->isEmpty()) {
                throw new \Exception("User ".$this->user." is not found");
            }

            $selected = $users->count() == 1 ? $users->first()->id : select($label, $users->pluck('name', 'id'));
        }

        $selected = !is_null($selected) ? $selected : $this->user;

        $user = $this->userModel::find($selected);
        if(is_null($user)) {
            throw new \Exception("User ".$this->user." is not found");
        }

        return $user;
    }

    protected function getPermissionSelected($label): Permission
    {
        $selected = null;

        if (empty($this->permission)) {
            $permissions = Permission::get(['id', 'name']);
            if($permissions->isEmpty()) {
                throw new \Exception("Permissions not found");
            }

            $selected = select($label, $permissions->pluck('name', 'id'));
        }

        if(is_null($selected) && !Str::isUuid($this->permission)) {
            $permissions = Permission::where('name', $this->permission)->get();
            if($permissions) {
                throw new \Exception("Permission ".$this->permission." is not found");
            }

            $selected = $permissions->count() == 1 ? $permissions->first()->id : select($label, $permissions->pluck('name', 'id'));
        }

        $selected = !is_null($selected) ? $selected : $this->permission;

        $permission = Permission::find($selected);
        if(is_null($permission)) {
            throw new \Exception("Permission ".$this->permission." is not found");
        }

        return $permission;
    }
}