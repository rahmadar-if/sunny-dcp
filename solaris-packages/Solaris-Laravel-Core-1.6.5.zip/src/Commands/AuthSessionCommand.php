<?php

namespace Solaris\Core\Commands;

use Illuminate\Console\Command;
use Solaris\Core\Services\AuthService;

use function Laravel\Prompts\error;
use function Laravel\Prompts\info;

class AuthSessionCommand extends Command
{
	protected $signature = 'solaris:auth-session {action}';

	protected $description = 'Auth session management commands';

	public function handle(): int
	{
		return match ($this->argument('action')) {
			'mark-expired'    => $this->markExpired(),
			'cleanup-history' => $this->cleanupHistory(),
			default           => $this->invalidAction(),
		};
	}

	private function markExpired(): int
	{
		$count = AuthService::markExpiredWebSessions();
		info("Marked {$count} expired web sessions.");

		return Command::SUCCESS;
	}

	private function cleanupHistory(): int
	{
		$count = AuthService::cleanupSessionHistory();
		info("Cleaned up {$count} old auth session records.");

		return Command::SUCCESS;
	}

	private function invalidAction(): int
	{
		error("Unknown action: {$this->argument('action')}");

		return Command::FAILURE;
	}
}
