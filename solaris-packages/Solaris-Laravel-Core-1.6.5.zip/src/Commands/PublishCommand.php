<?php

namespace Solaris\Core\Commands;

use Illuminate\Console\Command;

use function Laravel\Prompts\error;
use function Laravel\Prompts\info;
use function Laravel\Prompts\multiselect;
use function Laravel\Prompts\warning;

class PublishCommand extends Command
{
    protected $signature = 'solaris:publish
                            {action : config, ai-skill}
                            {--agent=* : Agent(s) to publish: claude, codex, opencode, antigravity, copilot, cursor}
                            {--force : Overwrite existing files}';

    protected $description = 'Publish Solaris resources to the project';

    protected const AGENTS = [
        'claude'      => 'Claude Code (CLAUDE.md)',
        'codex'       => 'OpenAI Codex (AGENTS.md)',
        'opencode'    => 'OpenCode (AGENTS.md + .opencode/skills/)',
        'antigravity' => 'Antigravity (.agents/skills/)',
        'copilot'     => 'GitHub Copilot (.github/copilot-instructions.md)',
        'cursor'      => 'Cursor (.cursorrules)',
    ];

    public function handle()
    {
        $action = $this->argument('action');

        try {
            match ($action) {
                'config'   => $this->publishConfig(),
                'ai-skill' => $this->publishAiSkill(),
                default    => throw new \Exception("Action '{$action}' is not supported. Available: config, ai-skill"),
            };
        } catch (\Exception $e) {
            error($e->getMessage());
            return self::FAILURE;
        }

        return self::SUCCESS;
    }

    protected function publishConfig(): void
    {
        // TODO: implement config publish
        info('Config publish not yet implemented.');
    }

    protected function publishAiSkill(): void
    {
        $stubsPath = __DIR__ . '/../../stubs/ai';
        $force     = $this->option('force');
        $agents    = $this->resolveAgents();

        if (empty($agents)) {
            warning('No agents selected. Nothing published.');
            return;
        }

        // Always publish skill files — source of truth for all agents
        $this->copySkills($stubsPath . '/skills', base_path('.ai/skills'), $force);

        // Publish per-agent files
        $agentsToPublishAgentsMd = array_intersect(['codex', 'opencode'], $agents);

        if (in_array('claude', $agents)) {
            $this->publishFile($stubsPath . '/CLAUDE.md', base_path('CLAUDE.md'), 'CLAUDE.md', $force);
        }

        if (!empty($agentsToPublishAgentsMd)) {
            $this->publishFile($stubsPath . '/AGENTS.md', base_path('AGENTS.md'), 'AGENTS.md', $force);
        }

        if (in_array('opencode', $agents)) {
            $this->publishFile(
                $stubsPath . '/agents-skill.md',
                base_path('.opencode/skills/solaris/SKILL.md'),
                '.opencode/skills/solaris/SKILL.md',
                $force
            );
        }

        if (in_array('antigravity', $agents)) {
            $this->publishFile(
                $stubsPath . '/agents-skill.md',
                base_path('.agents/skills/solaris/SKILL.md'),
                '.agents/skills/solaris/SKILL.md',
                $force
            );
        }

        if (in_array('copilot', $agents)) {
            $this->publishFile(
                $stubsPath . '/copilot-instructions.md',
                base_path('.github/copilot-instructions.md'),
                '.github/copilot-instructions.md',
                $force
            );
        }

        if (in_array('cursor', $agents)) {
            $this->publishFile(
                $stubsPath . '/cursor-rules',
                base_path('.cursorrules'),
                '.cursorrules',
                $force
            );
        }

        info('AI skill files published. Skill files are in: .ai/skills/');
    }

    protected function resolveAgents(): array
    {
        $option = $this->option('agent');

        if (!empty($option)) {
            $selected = is_array($option)
                ? array_merge(...array_map(fn($v) => explode(',', $v), $option))
                : explode(',', $option);

            $selected = array_map('trim', $selected);
            $invalid  = array_diff($selected, array_keys(static::AGENTS));

            if (!empty($invalid)) {
                throw new \Exception('Unknown agent(s): ' . implode(', ', $invalid) . '. Available: ' . implode(', ', array_keys(static::AGENTS)));
            }

            return $selected;
        }

        return multiselect(
            label  : 'Select AI agent(s) to publish skill files for',
            options: static::AGENTS,
            default: array_keys(static::AGENTS),
            hint   : 'Space to select, Enter to confirm'
        );
    }

    protected function copySkills(string $source, string $destination, bool $force): void
    {
        if (!is_dir($source)) {
            warning("Skill stubs directory not found: {$source}");
            return;
        }

        $this->ensureDirectory($destination);

        $files = glob($source . '/*.md');
        foreach ($files as $file) {
            $filename = basename($file);
            $target   = $destination . '/' . $filename;

            if (file_exists($target) && !$force) {
                warning("Skipped (already exists): .ai/skills/{$filename}");
                continue;
            }

            copy($file, $target);
            info("Published: .ai/skills/{$filename}");
        }
    }

    protected function publishFile(string $source, string $destination, string $label, bool $force): void
    {
        if (!file_exists($source)) {
            warning("Stub not found, skipping: {$label}");
            return;
        }

        if (file_exists($destination) && !$force) {
            warning("Skipped (already exists): {$label}");
            return;
        }

        $this->ensureDirectory(dirname($destination));
        copy($source, $destination);
        info("Published: {$label}");
    }

    protected function ensureDirectory(string $path): void
    {
        if (!is_dir($path)) {
            mkdir($path, 0755, true);
        }
    }
}
