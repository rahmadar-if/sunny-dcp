<?php

namespace Solaris\Core\Commands;

use Illuminate\Console\Command;
use Solaris\Core\Models\CodeGenerator;
use Solaris\Core\Services\CodeGenerator\CodeGeneratorService;

use function Laravel\Prompts\confirm;
use function Laravel\Prompts\error;
use function Laravel\Prompts\info;
use function Laravel\Prompts\select;
use function Laravel\Prompts\table;
use function Laravel\Prompts\text;
use function Laravel\Prompts\warning;

class CodeGeneratorCommand extends Command
{
    protected $signature = 'solaris:code-generator
                                {action?        : list (default), create, reset, trigger, delete}
                                {--code=        : Model class name}
                                {--column=      : Column model}
                                {--mask=        : Mask format}
                                {--last-number= : Last number for update}
                                {--record-id=   : Record ID for trigger}';

    protected $description = 'Manage code generators: create, update last number, or trigger code generation';

    public function handle()
    {
        $action = $this->argument('action') ?: 'list';

        switch ($action) {
            case 'list':
                $this->list();
                break;

            case 'create':
                $this->create();
                break;

            case 'update':
                $this->update();
                break;

            case 'reset':
                $this->resetLastNumber();
                break;

            case 'trigger':
                $this->trigger();
                break;

            case 'delete':
                $this->delete();
                break;

            default:
                error('Invalid action: ' . $action);
        }

        return self::SUCCESS;
    }

    protected function list()
    {
        $code = $this->option('code');

        if ($code) {
            $this->showDetail($code);
            return;
        }

        $this->showTable();
    }

    protected function create()
    {
        try {
            $modelInfo = $this->resolveModel();
            $column    = $this->resolveColumn($modelInfo['class'], $modelInfo['table']);
            
            $mask = $this->option('mask') ?: text(
                'Enter the mask format (e.g., INV-{YYYY}{0:000})',
                required: true
            );

            $active = confirm('Should this generator be active?', true);

            CodeGeneratorService::create($modelInfo['table'], $column, $mask, $active);
            
            info("🎉 Code generator created for {$modelInfo['table']} with mask {$mask} in column {$column} (active: ".($active?'yes':'no').")");
        } catch (\Exception $e) {
            error($e->getMessage());
        }
    }

    protected function update()
    {
        try {
            $modelInfo = $this->resolveRegisteredModel();
            $generator = CodeGenerator::where('code', $modelInfo['table'])->first();

            $column = $this->resolveColumn($modelInfo['class'], $modelInfo['table'], $generator->column);
            
            $mask = $this->option('mask') ?: text(
                'Enter the mask format (e.g., INV-{YYYY}{0:000})',
                default: $generator->mask,
                required: true
            );

            $active = confirm('Should this generator be active?', $generator->active);

            $generator->update([
                'column' => $column,
                'mask'   => $mask,
                'active' => $active,
            ]);
            
            info("✅ Code generator updated for {$modelInfo['table']}");
        } catch (\Exception $e) {
            error($e->getMessage());
        }
    }

    protected function resetLastNumber()
    {
        try {
            $modelInfo = $this->resolveRegisteredModel();
            $generator = CodeGenerator::with('details')->where('code', $modelInfo['table'])->first();

            $maskFormat = $this->option('mask');
            $detail     = null;

            if ($maskFormat) {
                $detail = $generator->details->where('mask_format', $maskFormat)->first();
            } else {
                if ($generator->details->isEmpty()) {
                    throw new \Exception("No mask formats found for '{$modelInfo['table']}'.");
                }

                $maskOptions = $generator->details->pluck('mask_format', 'mask_format')->toArray();
                $maskFormat  = select("Select the mask format to update", $maskOptions);
                $detail      = $generator->details->where('mask_format', $maskFormat)->first();
            }

            if (!$detail) {
                throw new \Exception("Mask format '{$maskFormat}' not found for '{$modelInfo['table']}'.");
            }

            $lastNumber = $this->option('last-number') ?: text(
                "Enter the new last number for {$maskFormat}",
                default: (string) $detail->last_number,
                required: true,
                validate: fn($input) => is_numeric($input) ? true : 'Please enter a valid number'
            );

            $updated = CodeGeneratorService::updateLastNumber($modelInfo['table'], $maskFormat, (int) $lastNumber);
            
            if (!$updated) {
                throw new \Exception("Failed to update last number for '{$modelInfo['table']}' with mask '{$maskFormat}'.");
            }

            info("✅ Last number for {$modelInfo['table']} and mask {$maskFormat} updated to {$lastNumber}");
        } catch (\Exception $e) {
            error($e->getMessage());
        }
    }

    protected function trigger()
    {
        try {
            $modelInfo = $this->resolveRegisteredModel();
            
            if (!class_exists($modelInfo['class'])) {
                throw new \Exception("Model for '{$modelInfo['table']}' does not exist.");
            }

            $recordId = $this->option('record-id') ?: text(
                'Enter the record ID to trigger code generation',
                required: true
            );

            $record = $modelInfo['class']::find($recordId);
            if (!$record) {
                throw new \Exception("Record with ID '{$recordId}' not found in table '{$modelInfo['table']}'.");
            }

            $generatedCode = CodeGeneratorService::generateCode($modelInfo['table'], $record);
            if (!$generatedCode) {
                throw new \Exception("⚠️ No active generator found for '{$modelInfo['table']}'.");
            }

            $record->{$generatedCode['column']} = $generatedCode["result"];
            $record->save();

            info("✅ Code generated: ".$generatedCode["result"]);
        } catch (\Exception $e) {
            error($e->getMessage());
        }
    }

    protected function delete()
    {
        try {
            $modelInfo = $this->resolveRegisteredModel();
            if (!class_exists($modelInfo['class'])) {
                throw new \Exception("Model for '{$modelInfo['table']}' does not exist.");
            }

            $generator = CodeGenerator::firstWhere("code", $modelInfo['table']);
            if (!$generator) {
                throw new \Exception("❌ Generator not found.");
            }

            $confirmed = confirm("Delete generator '{$generator->code}' (column: {$generator->column})? This will remove all related details and history.", false);
            if (!$confirmed) {
                return;
            }

            $generator->delete();
            info("✅ Code generator '{$generator->code}' deleted.");
        } catch (\Exception $e) {
            error($e->getMessage());
        }
    }

    protected function showTable()
    {
        $generators = CodeGenerator::get(['code', 'column', 'mask', 'active'])
            ->map(fn($g) => [
                'code'   => $g->code,
                'column' => $g->column,
                'mask'   => $g->mask,
                'active' => $g->active ? '✔️' : '❌',
            ]);

        if ($generators->isEmpty()) {
            warning('No code generators found.');
            return;
        }

        table(['Code/Table', 'Column', 'Mask', 'Active'], $generators);
    }

    protected function showDetail(string $code)
    {
        $generator = CodeGenerator::with('details')->where('code', $code)->first();

        if (!$generator) {
            error("Code generator not found for: {$code}");
            return;
        }

        info("Code Generator Detail: {$code}");
        
        table(
            ['Field', 'Value'],
            [
                ['ID', $generator->id],
                ['Code/Table', $generator->code],
                ['Column', $generator->column],
                ['Default Mask', $generator->mask],
                ['Status', $generator->active ? 'Active (✔️)' : 'Inactive (❌)'],
                ['Created At', $generator->created_at],
            ]
        );

        $this->newLine();
        info("Mask details:");
        
        $details = $generator->details->map(fn($d) => [
            'mask_format' => $d->mask_format,
            'last_number' => $d->last_number,
        ]);

        if ($details->isEmpty()) {
            warning('No mask details found.');
            return;
        }

        table(['Mask Format', 'Last Number'], $details);
    }

    protected function resolveModel(): array
    {
        $code = $this->option('code');

        if (!$code) {
            $models = CodeGeneratorService::getUnregisterModel();

            if ($models->isEmpty()) {
                throw new \Exception("No unregistered models available.");
            }

            $options = $models->mapWithKeys(fn($m) => [
                $m['class'] => $m['table']
            ])->toArray();

            $selectedClass = select("Select the object (unregistered only)", $options);
            return $models->where('class', $selectedClass)->first();
        }

        $modelInfo = CodeGeneratorService::getAvailableModel()->where('table', $code)->first();
        
        if (!$modelInfo) {
            throw new \Exception("Table/Code '{$code}' is invalid or does not use CodeGeneratable trait.");
        }

        return $modelInfo;
    }

    protected function resolveRegisteredModel(): array
    {
        $code = $this->option('code');

        if (!$code) {
            $models = CodeGeneratorService::getRegisterModel();

            if ($models->isEmpty()) {
                throw new \Exception("No registered generators available to update.");
            }

            $options = $models->mapWithKeys(fn($m) => [
                $m['class'] => $m['table']
            ])->toArray();

            $selectedClass = select("Select the object to update", $options);
            return $models->where('class', $selectedClass)->first();
        }

        $modelInfo = CodeGeneratorService::getAvailableModel()->where('table', $code)->first();
            
        if (!$modelInfo) {
            throw new \Exception("Table/Code '{$code}' is invalid or does not use CodeGeneratable trait.");
        }

        if (!CodeGenerator::where('code', $code)->exists()) {
            throw new \Exception("Table/Code '{$code}' is not registered yet.");
        }

        return $modelInfo;
    }

    protected function resolveColumn(?string $className, string $table, ?string $default = null): string
    {
        $column = $this->option('column');
        if ($column) {
            return $column;
        }

        $columns = CodeGeneratorService::getValidColumns($className);
        if ($columns->isEmpty()) {
            if ($className && method_exists($className, 'getColumns')) {
                throw new \Exception("No string columns found in table '{$table}'.");
            }
            
            return text('Enter the column name (e.g., name)', default: $default ?: '', required: true);
        }

        return select(
            'Select the column name', 
            $columns->pluck('name', 'name')->toArray(), 
            default: $default, 
            required: true
        );
    }
}