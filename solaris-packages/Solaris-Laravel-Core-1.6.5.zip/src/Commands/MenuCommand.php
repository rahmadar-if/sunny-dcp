<?php

namespace Solaris\Core\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Str;
use Illuminate\Support\Collection;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\Menu;
use Solaris\Core\Services\MenuService;

use function Laravel\Prompts\confirm;
use function Laravel\Prompts\error;
use function Laravel\Prompts\info;
use function Laravel\Prompts\multiselect;
use function Laravel\Prompts\note;
use function Laravel\Prompts\select;
use function Laravel\Prompts\table;
use function Laravel\Prompts\text;
use function Laravel\Prompts\warning;

class MenuCommand extends Command
{
	protected $signature = 'solaris:menu
                                {action?        : list|create|update|delete|access|remove-access}
                                {type?          : menu type (category|menu|sub-menu)}
                                {--category=    : category name. show list menu by category name or id}
                                {--name=        : menu name}
                                {--url=         : menu url}
                                {--route=       : menu route name}
                                {--icon=        : menu icon}
                                {--position=    : menu position}';

	protected $description = 'Manage menu (list, update, delete and create category, menu, sub-menu)';

	public function handle()
	{
		$action = $this->argument('action') ?? 'list';

		try {
			switch ($action) {
				case 'list':
					$this->showList();
					break;

				case 'create':
					$this->create();
					break;

				case 'delete':
					$this->delete();
					break;

				case 'update':
					$this->update();
					break;

				case 'access':
					$this->access();
					break;

				case 'remove-access':
					$this->removeAccess();
					break;

				default:
					error('Invalid action: ' . $action);
			}
		} catch (\Exception $e) {
			error($e->getMessage());
		}

		return self::SUCCESS;
	}

	protected function showList()
	{
		$categoryFilter = $this->option("category");
		$allMenu = MenuService::all();

		$categories = Menu::where("is_category", true)
			->when(Str::isUuid($categoryFilter), fn ($query) => $query->where("id", $categoryFilter))
			->when(! empty($categoryFilter) && ! Str::isUuid($categoryFilter), fn ($query) => $query->where("name", Helper::likeOperator(), "%" . $categoryFilter . "%"))
			->orderBy("position", "asc")
			->get();

		foreach ($categories as $cat) {
			$categoryRootMenus = $allMenu->where("category_id", $cat->id)->whereNull("parent_id")->values();

			note($cat->name);
			table(
				headers: ["id", "name", "url", "route name", "icon", "parent"],
				rows: $this->renderTreeMenu($categoryRootMenus, $allMenu, "")
			);
		}

		$menuNotInCategory = $allMenu->whereNull("category_id")->whereNull("parent_id")->where("is_category", false)->values();
		if ($menuNotInCategory->isNotEmpty()) {
			note("Menus that have no categories");
			table(
				headers: ["id", "name", "url", "route name", "icon", "parent"],
				rows: $this->renderTreeMenu($menuNotInCategory, $allMenu, "")
			);
		}
	}

	protected function renderTreeMenu(Collection $menus, Collection $allMenu, string $prefix = "")
	{
		$rows = [];
		foreach ($menus as $menu) {
			$rows[] = [
				$menu->id,
				$prefix . $menu->name,
				$menu->url,
				$menu->route_name,
				$menu->icon,
				$menu->parent?->name ?? "-"
			];

			$subMenus = $allMenu->where("parent_id", $menu->id)->values();
			$rows = array_merge($rows, $this->renderTreeMenu($subMenus, $allMenu, $prefix . "  "));
		}

		return $rows;
	}

	protected function create()
	{
		$menu = null;
		$type = $this->getTypeSelected('What do you want to create?');

		if ($type == 'category') {
			$menu = $this->createCategory();
		}

		if ($type == 'menu') {
			$menu = $this->createMenu();
		}

		if ($type == 'sub-menu') {
			$menu = $this->createSubMenu();
		}

		if (is_null($menu)) {
			throw new \Exception("Menu is null");
		}

		Menu::create([
			'name'        => $menu['name'],
			'position'    => $menu['position'],
			'is_category' => $menu['is_category'],
			'url'         => $menu['url'],
			'route_name'  => $menu['route_name'],
			'icon'        => $menu['icon'],
			'parent_id'   => $menu['parent_id'],
			'category_id' => $menu['category_id'],
		]);

		info("Create {$type} {$menu['name']} is successfully");
	}

	protected function createCategory()
	{
		$name = $this->option("name");
		if (empty($name)) {
			$name = text(label: 'What\'s the name?', required: true);
		}

		$position = $this->option("position");
		if (empty($position)) {
			$position = text('Set the position (number)', default: '0');
		}

		return [
			'name'        => $name,
			'position'    => (int) $position,
			'is_category' => true,
			'url'         => null,
			'route_name'  => null,
			'icon'        => null,
			'parent_id'   => null,
			'category_id' => null,
		];
	}

	protected function createMenu()
	{
		$categoryId = null;
		$hasCategory = confirm('Do you want to put this menu under a category?', true);
		if ($hasCategory) {
			$categories = Menu::where('is_category', true)->orderBy("position", "asc")->pluck('name', 'id')->toArray();
			if (! empty($categories)) {
				$categoryId = select(
					label: 'Pick a category',
					options: $categories
				);
			} else {
				warning('⚠ No categories found, skipping category selection.');
			}
		}

		$name = $this->option("name");
		if (empty($name)) {
			$name = text(label: 'What\'s the name?', required: true);
		}

		$position = $this->option("position");
		if (empty($position)) {
			$position = text('Set the position (number)', default: '0');
		}

		$url = $this->option("url");
		if (empty($url)) {
			$url = text('Enter URL (optional)');
		}

		$route = $this->option("route");
		if (empty($route)) {
			$route = text('Enter route name (optional)');
		}

		$icon = $this->option("icon");
		if (empty($icon)) {
			$icon = text('Pick an icon for this top-level menu (optional)');
		}

		return [
			'name'        => $name,
			'position'    => (int) $position,
			'is_category' => false,
			'url'         => $url,
			'route_name'  => $route,
			'icon'        => $icon,
			'parent_id'   => null,
			'category_id' => $categoryId,
		];
	}

	protected function createSubMenu()
	{
		$menus = Menu::where('is_category', false)->orderBy('position', 'asc')->orderBy('name', 'asc')->get();
		$menuOptions = $menus->pluck('name', 'id')->toArray();

		if (empty($menuOptions)) {
			throw new \Exception('No parent menus found. Create a menu first.');
		}

		$parentId = select(
			label: 'Choose a parent menu',
			options: $menuOptions
		);

		$name = $this->option("name");
		if (empty($name)) {
			$name = text(label: 'What\'s the name?', required: true);
		}

		$position = $this->option("position");
		if (empty($position)) {
			$position = text('Set the position (number)', default: '0');
		}

		$url = $this->option("url");
		if (empty($url)) {
			$url = text('Enter URL (optional)');
		}

		$route = $this->option("route");
		if (empty($route)) {
			$route = text('Enter route name (optional)');
		}

		return [
			'name'        => $name,
			'position'    => (int) $position,
			'is_category' => false,
			'url'         => $url,
			'route_name'  => $route,
			'icon'        => null,
			'parent_id'   => $parentId,
			'category_id' => null,
		];
	}

	protected function delete()
	{
		$type = $this->getTypeSelected('What do you want to delete?');

		if ($type == 'category') {
			return $this->deleteCategory();
		}

		return $this->deleteMenu();
	}

	protected function deleteCategory()
	{
		$categories = Menu::where('is_category', true)->orderBy("position", "asc")->pluck('name', 'id')->all();
		if (empty($categories)) {
			throw new \Exception('No categories found');
		}

		$categoryId = select(
			label: 'Select category to delete',
			options: $categories
		);

		$category = Menu::find($categoryId);

		MenuService::deleteCategory($category, confirm("Delete all menus in this category", false));
		MenuService::clearCache();

		info("Category menu {$category->name} successfully deleted");
	}

	protected function deleteMenu()
	{
		$menus = Menu::with('parent')->where('is_category', false)->orderBy("position", "asc")
			->get()
			->map(function ($menu) {
				if (! is_null($menu->parent_id)) {
					$menu->name = $menu->name . " (sub menu from " . $menu->parent->name . ")";
				}

				return $menu;
			})
			->pluck('name', 'id')
			->all();

		$menuId = select(
			label: 'Select menu to delete',
			options: $menus
		);

		$menu = Menu::find($menuId);

		MenuService::deleteMenu($menu, confirm("Delete all sub menus in this menu", false));
		MenuService::clearCache();

		info("Menu {$menu->name} successfully deleted");
	}

	protected function update()
	{
		$menus = Menu::with('parent')->orderBy("position", "asc")
			->get()
			->map(function ($menu) {
				if ($menu->is_category) {
					$menu->name = $menu->name . " (Category)";
				} else if (! is_null($menu->parent_id)) {
					$menu->name = $menu->name . " (Sub menu from " . $menu->parent->name . ")";
				}

				return $menu;
			})
			->pluck('name', 'id')
			->all();

		$menuId = select(
			label: 'Select menu to update',
			options: $menus
		);

		$menu = Menu::find($menuId);
		$updateValues = [
			'name'     => text('Name', default: $menu->name),
			'position' => text('Position', default: $menu->position)
		];

		if (! $menu->is_category) {
			$updateValues['url']        = text('Url', default: $menu->url);
			$updateValues['route_name'] = text('Route name', default: $menu->route_name);
			$updateValues['icon']       = text('Icon', default: $menu->icon);

			if (! is_null($menu->parent_id)) {
				if (confirm("Delete parent relation?", false)) {
					$updateValues['parent_id'] = null;
				} else if (confirm("Change parent relation?", false)) {
					$updateValues['parent_id'] = select(
						label: 'Choose a parent menu',
						options: Menu::where('is_category', false)
							->where('id', '!=', $menuId)
							->orderBy('position', 'asc')
							->orderBy('name', 'asc')
							->pluck('name', 'id')
							->all()
					);
				}
			} else if (confirm("Update parent?", false)) {
				$updateValues['parent_id'] = select(
					label: 'Choose a parent menu',
					options: Menu::where('is_category', false)
						->where('id', '!=', $menuId)
						->orderBy('position', 'asc')
						->orderBy('name', 'asc')
						->pluck('name', 'id')
						->all()
				);
			}

			if (is_null($menu->parent_id) && is_null($menu->category_id) && confirm("Put this menu under a category", false)) {
				$updateValues['category_id'] = select(
					label: 'Pick a category',
					default: $menu->category_id,
					options: Menu::where('is_category', true)
						->orderBy("position", "asc")
						->pluck('name', 'id')
						->all()
				);
			} else if (! is_null($menu->category_id) && confirm("Delete category relation", false)) {
				$updateValues['category_id'] = null;
			}
		}

		$menu->update($updateValues);

		info("Update {$menu['name']} is successfully");
	}

	protected function access()
	{
		$menus = Menu::with('parent')->orderBy("position", "asc")
			->get()
			->map(function ($menu) {
				if ($menu->is_category) {
					$menu->name = $menu->name . " (Category)";
				} else if (! is_null($menu->parent_id)) {
					$menu->name = $menu->name . " (Sub menu from " . $menu->parent->name . ")";
				}

				return $menu;
			})
			->pluck('name', 'id')
			->all();

		$menuIds = multiselect(
			label: 'Select the menus that can be accessed',
			options: $menus
		);

		$type = strtolower(select(
			label: "Give access to",
			options: ['User', 'Role', 'Permission'],
			default: 0
		));

		if ($type == 'user') {
			$users = Helper::model('user')::get(['id', 'name']);
			$selected = multiselect("Select user to be assigned", $users->pluck('name', 'id'));

			foreach ($menuIds as $menuId) {
				Menu::find($menuId)->assignUser($selected);
			}
		} else if ($type == 'role') {
			$roles = \Solaris\Core\Models\Role::get(['id', 'name']);
			$selected = multiselect("Select role to be assigned", $roles->pluck('name', 'id'));

			foreach ($menuIds as $menuId) {
				Menu::find($menuId)->assignRole($selected);
			}
		} else if ($type == 'permission') {
			$permissions = \Solaris\Core\Models\Permission::get(['id', 'name']);
			$selected = multiselect("Select permission to be assigned", $permissions->pluck('name', 'id'));

			foreach ($menuIds as $menuId) {
				Menu::find($menuId)->assignPermission($selected);
			}
		}

		MenuService::clearCache();

		info("Setup access menu successfully");
	}

	protected function removeAccess()
	{
		$menus = Menu::with('parent')->orderBy("position", "asc")
			->get()
			->map(function ($menu) {
				if ($menu->is_category) {
					$menu->name = $menu->name . " (Category)";
				} else if (! is_null($menu->parent_id)) {
					$menu->name = $menu->name . " (Sub menu from " . $menu->parent->name . ")";
				}

				return $menu;
			})
			->pluck('name', 'id')
			->all();

		$menuIds = multiselect(
			label: 'Select the menus to remove access from',
			options: $menus
		);

		$type = strtolower(select(
			label: "Remove access from",
			options: ['User', 'Role', 'Permission'],
			default: 0
		));

		if ($type == 'user') {
			$users = Helper::model('user')::get(['id', 'name']);
			$selected = multiselect("Select user to remove access", $users->pluck('name', 'id'));

			foreach ($menuIds as $menuId) {
				Menu::find($menuId)->removeUser($selected);
			}
		} else if ($type == 'role') {
			$roles = \Solaris\Core\Models\Role::get(['id', 'name']);
			$selected = multiselect("Select role to remove access", $roles->pluck('name', 'id'));

			foreach ($menuIds as $menuId) {
				Menu::find($menuId)->removeRole($selected);
			}
		} else if ($type == 'permission') {
			$permissions = \Solaris\Core\Models\Permission::get(['id', 'name']);
			$selected = multiselect("Select permission to remove access", $permissions->pluck('name', 'id'));

			foreach ($menuIds as $menuId) {
				Menu::find($menuId)->removePermission($selected);
			}
		}

		MenuService::clearCache();

		info("Remove access menu successfully");
	}

	protected function getTypeSelected(string $label): string
	{
		$type = $this->argument('type');
		$validType = ['Category', 'Menu', 'Sub-Menu'];

		if (empty($type)) {
			$type = select(
				label: $label,
				options: $validType,
				default: 0
			);
		} else {
			if (! in_array($type, array_map(fn ($item) => strtolower($item), $validType))) {
				throw new \Exception('Invalid type: ' . $type);
			}
		}

		return strtolower($type);
	}
}