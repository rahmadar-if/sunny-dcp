<?php

namespace Solaris\Core\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Str;
use Solaris\Core\Services\Generators\ApprovalGenerator;
use Solaris\Core\Services\Generators\ControllerGenerator;
use Solaris\Core\Services\Generators\MigrationGenerator;
use Solaris\Core\Services\Generators\ModelGenerator;
use Solaris\Core\Services\Generators\RequestGenerator;
use Solaris\Core\Services\Generators\RepositoryGenerator;
use Solaris\Core\Services\Generators\ViewGenerator;
use Solaris\Core\Services\Generators\JsGenerator;
use Solaris\Core\Services\Generators\ModuleGenerator;

use function Laravel\Prompts\text;
use function Laravel\Prompts\select;
use function Laravel\Prompts\confirm;
use function Laravel\Prompts\error;
use function Laravel\Prompts\info;
use function Laravel\Prompts\table;
use function Laravel\Prompts\warning;

class MakeCommand extends Command
{
    protected $signature = 'solaris:make
                            {action : model, controller, repository, request, migration, view, module, approve}
                            {name? : Class name or module name}
                            {--default}
                            {--repo= : Specify repository setup (none, default, custom)}
                            {--request : Use FormRequest (Shortcut)}
                            {--no-request : Do not use FormRequest (Shortcut)}
                            {--type= : Specify type}
                            {--table= : Custom table name}
                            {--no-migration : Skip migration generation (module)}
                            {--force : Overwrite existing files}
                            {--model= : Model name for repository binding (controller)}
                            {--parent= : Parent model name (model: detail, stage-history)}
                            {--parent-column= : Parent foreign key column (model: detail, stage-history)}
                            {--stage-model= : Stage model name (model: stage-history)}
                            {--stage-column= : Stage foreign key column (model: stage-history)}';

    protected $description = 'Generate Solaris scaffold components';

    protected array $generatedFiles = [];

    protected array $failures = [];

    public function handle()
    {
        $action = $this->argument('action');
        $name = $this->argument('name');

        try {
            switch ($action) {
                case 'controller':
                    $this->makeController($name);
                    break;

                case 'model':
                    $this->makeModel($name);
                    break;

                case 'request':
                    $this->makeRequest($name);
                    break;

                case 'repository':
                    $this->makeRepository($name);
                    break;

                case 'migration':
                    $this->makeMigration($name);
                    break;

                case 'view':
                    $this->makeView($name);
                    break;

                case 'module':
                    $this->makeModule($name);
                    break;

                case 'approve':
                    $this->makeApproval($name);
                    break;

                default:
                    error("Action '{$action}' not supported yet.");

                    return self::FAILURE;
            }

            $this->printSummary();

        } catch (\Throwable $e) {
            $this->failures[] = [Str::studly($action), $e->getMessage()];

            $this->printSummary();

            error($e->getMessage());

            return self::FAILURE;
        }

        return self::SUCCESS;
    }

    protected function validatedOption(string $option, array $allowed): ?string
    {
        $value = $this->option($option);

        if (empty($value)) {
            return null;
        }

        if (!in_array($value, $allowed, true)) {
            throw new \InvalidArgumentException("Invalid --{$option} value '{$value}'. Allowed: " . implode(', ', $allowed) . '.');
        }

        return $value;
    }

    protected function promptFor(string $option, string $label, string $placeholder, ?string $default = null): string
    {
        if ($this->option('default') || !$this->input->isInteractive()) {
            if ($default !== null) {
                return $default;
            }

            throw new \InvalidArgumentException("Option --{$option} is required in non-interactive mode.");
        }

        return text(
            label      : $label,
            placeholder: $placeholder,
            default    : $default ?? '',
            required   : true
        );
    }

    protected function makeController(?string $name)
    {
        if (empty($name)) {
            $name = text(
                label      : 'What is the controller name?',
                placeholder: 'e.g., Product',
                required   : true
            );
        }

        $isDefault = $this->option('default');
        $type      = $this->validatedOption('type', ['full', 'detail', 'blank']) ?: ($isDefault ? 'full' : null);

        if (!$type) {
            $type = select(
                label: 'Select controller type',
                options: [
                    'full'   => 'Solaris Pattern (CRUD)', 
                    'detail' => 'Detail Pattern (Relational)',
                    'blank'  => 'Blank Controller'
                ],
                default: 'full'
            );
        }

        if ($type === 'blank') {
            $this->generateController($name, ['blank' => true, 'type' => 'blank']);
            return;
        }

        $options = [
            'blank' => false, 
            'type'  => $type
        ];

        $repoChoice = $this->validatedOption('repo', ['none', 'default', 'custom']);

        if (!$repoChoice) {
            $repoChoice = $isDefault ? 'default' : select(
                label  : 'Repository setup',
                options: [
                    'none'    => 'No Repository (Empty CRUD methods)',
                    'default' => 'Default (BaseRepository)',
                    'custom'  => 'Custom Repository (Specific Class)',
                ],
                default: 'default'
            );
        }

        if ($repoChoice === 'none') {
            $options['no_repo'] = true;
        } elseif ($repoChoice === 'default') {
            $options['repo_type'] = 'base';

            $modelName = match (true) {
                (bool) $this->option('model')        => Str::studly($this->option('model')),
                $isDefault                           => Str::studly($name),
                !$this->input->isInteractive()       => Str::studly($name),
                default => Str::studly(text(
                    label      : 'What model should this repository use?',
                    default    : Str::studly($name),
                    placeholder: 'e.g., Product',
                    hint       : 'The repository will be bound to this model.'
                )),
            };

            $options['repo_model']  = $modelName;
            $options['repo_params'] = "\\App\\Models\\{$modelName}::class";
        } else {
            // Repository name follows the model it serves
            $repoName = Str::studly($this->option('model') ?: $name) . "Repository";
            $options['repo_class'] = "App\\Repositories\\{$repoName}";
            $options['repo_type']  = 'custom';
        }

        $useRequest = $isDefault || $this->option('request') ? true
            : ($this->option('no-request') ? false
            : confirm(label: 'Use FormRequest for validation?', default: true));

        $options['use_request'] = $useRequest;
        
        $this->generateController($name, $options);
    }

    protected function generateController(string $name, array $options)
    {
        $generator = new ControllerGenerator($name, array_merge($options, [
            'force' => $this->option('force'),
        ]));

        $path = $generator->generate();
        $this->generatedFiles[] = ['Controller', $path];
    }

    protected function makeModel(?string $name, array $options = [])
    {
        if (empty($name)) {
            $name = text(
                label: 'What is the model name?',
                placeholder: 'e.g., Product',
                required: true
            );
        }

        $isDefault = $this->option('default');
        $type      = $this->validatedOption('type', ['base', 'none', 'lookup', 'detail', 'lookup-stage', 'stage-history']);

        if (!$type) {
            $type = $isDefault ? 'base' : select(
                label: 'Select model type',
                options: [
                    'base'          => 'Solaris BaseModel (Default)',
                    'none'          => 'Laravel Model (Standard)',
                    'lookup'        => 'Lookup Model',
                    'detail'        => 'Detail Model',
                    'lookup-stage'  => 'Lookup Stage Model',
                    'stage-history' => 'Stage History Model',
                ],
                default: 'base'
            );
        }

        $options['type'] = $type;

        if (in_array($type, ['detail', 'stage-history'], true)) {
            $options['parent_model']  ??= $this->option('parent')
                ? Str::studly($this->option('parent'))
                : $this->promptFor('parent', 'Parent model name?', 'e.g., Account');

            $options['parent_column'] ??= $this->option('parent-column')
                ?: $this->promptFor('parent-column', 'Parent column (foreign key)?', 'e.g., account_id', Str::snake($options['parent_model']) . '_id');
        }

        if ($type === 'stage-history') {
            $options['stage_model']   ??= $this->option('stage-model')
                ? Str::studly($this->option('stage-model'))
                : $this->promptFor('stage-model', 'Stage model name?', 'e.g., AccountStage');

            $options['stage_column']  ??= $this->option('stage-column')
                ?: $this->promptFor('stage-column', 'Stage column (foreign key)?', 'e.g., account_stage_id', Str::snake($options['stage_model']) . '_id');
        }

        $generator = new ModelGenerator($name, array_merge($options, [
            'force'  => $this->option('force'),
            'table'  => $this->option('table'),
        ]));

        $path = $generator->generate();
        $this->generatedFiles[] = ['Model', $path];

        if ($type === 'stage-history') {
            $this->updateParentModelForStageHistory($name, $options);
        }

        return $path;
    }

    protected function makeRequest(?string $name, array $options = [])
    {
        if (empty($name)) {
            $name = text(
                label: 'What is the request name?',
                placeholder: 'e.g., Product',
                required: true
            );
        }

        $generator = new RequestGenerator($name, array_merge($options, [
            'force' => $this->option('force')
        ]));

        $path = $generator->generate();
        $this->generatedFiles[] = ['Request', $path];
    }

    protected function makeRepository(?string $name, array $options = [])
    {
        if (empty($name)) {
            $name = text(
                label: 'What is the name for the repository?',
                placeholder: 'e.g., Product',
                required: true
            );
        }

        $generator = new RepositoryGenerator($name, array_merge($options, [
            'force' => $this->option('force')
        ]));

        $path = $generator->generate();
        $this->generatedFiles[] = ['Repository', $path];
    }

    protected function makeMigration(?string $name)
    {
        if (empty($name)) {
            $name = text(
                label: 'What is the name for the migration?',
                placeholder: 'e.g., Product',
                required: true
            );
        }

        $isDefault = $this->option('default');
        $type      = $this->validatedOption('type', ['base', 'none']);

        if (!$type && !$isDefault) {
            $type = select(
                label: 'Select migration type',
                options: [
                    'base' => 'Solaris Pattern (Default)',
                    'none' => 'Laravel Standard (Blank)',
                ],
                default: 'base'
            );
        }

        $type = $type ?: ($isDefault ? 'base' : null);

        $generator = new MigrationGenerator($name, [
            'force' => $this->option('force'),
            'table' => $this->option('table'),
            'type'  => $type,
        ]);

        $path = $generator->generate();
        $this->generatedFiles[] = ['Migration', $path];
    }
    
    protected function makeView(?string $name)
    {
        if (empty($name)) {
            $name = text(
                label: 'What is the module name for the view?',
                placeholder: 'e.g., account_profile',
                required: true
            );
        }

        $type = $this->validatedOption('type', ['list', 'page', 'base', 'blank', 'modal']);
        if (!$type) {
            $type = select(
                label: 'Select view type',
                options: [
                    'list'  => 'List Page',
                    'page'  => 'Edit Page',
                    'modal' => 'Modal Page',
                    'base'  => 'Standard Page',
                    'blank' => 'Blank Page'
                ],
                default: 'list'
            );
        }

        $options = [
            'force' => $this->option('force'),
            'type'  => $type,
        ];

        $viewGenerator = new ViewGenerator($name, $options);
        $viewPath = $viewGenerator->generate();
        $this->generatedFiles[] = ['View', $viewPath];

        $jsGenerator = new JsGenerator($name, $options);
        $jsPath = $jsGenerator->generate();
        $this->generatedFiles[] = ['JS', $jsPath];
    }

    protected function printSummary()
    {
        if (empty($this->generatedFiles) && empty($this->failures)) {
            return;
        }

        $rows = array_map(function ($item) {
            $type = $item[0];
            $path = $item[1];
            // Format clickable path for terminal (supported by many modern terminals)
            $clickable = "<href=file:///{$path}>{$path}</>";
            return ['OK', $type, $clickable];
        }, $this->generatedFiles);

        foreach ($this->failures as $failure) {
            $rows[] = ['FAILED', $failure[0], $failure[1]];
        }

        table(['Status', 'Type', 'Path / Reason'], $rows);
    }

    protected function updateParentModelForStageHistory(string $historyModelName, array $options)
    {
        $parentModel = $options['parent_model'];
        $stageColumn = $options['stage_column'];
        $path = app_path("Models/{$parentModel}.php");

        if (!file_exists($path)) {
            error("Parent model {$parentModel} not found at {$path}. Skipping trait injection.");
            return;
        }

        $content = file_get_contents($path);
        $quoted  = preg_quote($parentModel, '/');

        // 1. Add Trait Import if missing
        if (!str_contains($content, 'Solaris\Core\Traits\Model\HasStageHistory')) {
            $replaced = preg_replace('/namespace App\\\Models;/', "namespace App\\Models;\n\nuse Solaris\\Core\\Traits\\Model\\HasStageHistory;", $content, 1, $count);

            if (!$count) {
                warning("Could not add HasStageHistory import to {$parentModel}: namespace declaration not found. Add it manually.");
            }

            $content = $replaced ?? $content;
        }

        // 2. Add Trait Use if missing
        if (!str_contains($content, 'use HasStageHistory;')) {
            $replaced = preg_replace('/class\s+' . $quoted . '\s+extends\s+[\\\\\w]+\s*\{/', "$0\n    use HasStageHistory;", $content, 1, $count);

            if (!$count) {
                warning("Could not add 'use HasStageHistory;' to {$parentModel}: class declaration not matched. Add it manually.");
            }

            $content = $replaced ?? $content;
        }

        // 3. Add Abstract Methods if missing
        if (!str_contains($content, 'function stageHistoryModel()')) {
            $methods  = "\n    protected static function stageHistoryModel(): string\n    {\n        return \\App\\Models\\{$historyModelName}::class;\n    }\n\n    protected static function stageColumn(): string\n    {\n        return '{$stageColumn}';\n    }\n";
            // Insert before the last closing brace of the class
            $replaced = preg_replace('/\}\s*$/', $methods . "}", rtrim($content), 1, $count);

            if (!$count) {
                warning("Could not add stage methods to {$parentModel}: closing brace not found. Add them manually.");
            }

            $content = $replaced ?? $content;
        }

        file_put_contents($path, $content);
        info("Modified parent model {$parentModel} with HasStageHistory trait and abstract methods.");
    }

    protected function makeApproval(?string $name): void
    {
        if (empty($name)) {
            $name = text(
                label      : 'What is the approval class name?',
                placeholder: 'e.g., PromoteEmployee',
                required   : true
            );
        }

        $generator = new ApprovalGenerator($name, [
            'force' => $this->option('force'),
        ]);

        $path = $generator->generate();
        $this->generatedFiles[] = ['Approval', $path];
    }

    protected function makeModule(?string $name)
    {
        if (empty($name)) {
            $name = text(
                label      : 'What is the module name?',
                placeholder: 'e.g., Project',
                required   : true
            );
        }

        $migration = match (true) {
            $this->option('no-migration') => false,
            (bool) $this->option('default') => true,
            default => confirm("Generate migration?", true),
        };

        $table = $this->option('table');
        if (empty($table) && !($this->option('default'))) {
            $table = text(
                label  : 'Table name?',
                default: Str::plural(Str::snake($name))
            );
        }
        $table = $table ?: Str::plural(Str::snake($name));

        $repoChoice = $this->validatedOption('repo', ['default', 'custom']);
        if (empty($repoChoice)) {
            $repoChoice = $this->option('default') ? 'default' : select(
                label: 'Repository setup',
                options: [
                    'default' => 'Default (BaseRepository)',
                    'custom'  => 'Custom Repository (Specific Class)',
                ],
                default: 'default'
            );
        }

        $generator = new ModuleGenerator($name, [
            'force'     => $this->option('force'),
            'migration' => $migration,
            'table'     => $table,
            'repo'      => $repoChoice,
        ]);

        try {
            $files = $generator->generate();
        } catch (\Throwable $e) {
            // Keep partial results visible in the summary before bubbling up
            $this->collectModuleFiles($generator->getGenerated());

            throw $e;
        }

        $this->collectModuleFiles($files);
    }

    protected function collectModuleFiles(array $files): void
    {
        foreach ($files as $type => $path) {
            $this->generatedFiles[] = [$type, $path];
        }
    }
}
