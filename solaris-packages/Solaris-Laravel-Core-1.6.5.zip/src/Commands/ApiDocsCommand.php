<?php

namespace Solaris\Core\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;
use Solaris\Core\Services\Api\Docs\OpenApiGenerator;

use function Laravel\Prompts\info;
use function Laravel\Prompts\warning;

class ApiDocsCommand extends Command
{
    public const PATH = 'api-docs/openapi-v1.json';

    protected $signature = 'solaris:api-docs
                                {action? : build}
                                {--quiet-drift : Skip the drift report}';

    protected $description = 'Build the OpenAPI document served at /docs/api';

    public function handle(): int
    {
        $generator = new OpenApiGenerator();
        $spec      = $generator->generate();

        if (empty($spec['paths'])) {
            warning('No api.v1.* routes found — nothing to document.');

            return self::SUCCESS;
        }

        Storage::disk('local')->put(
            self::PATH,
            json_encode($spec, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
        );

        info(sprintf('Documented %d paths → %s', count($spec['paths']), self::PATH));

        $this->reportDrift($generator->warnings());

        return self::SUCCESS;
    }

    /**
     * Drift is reported, never fatal — a missing description should not block a deploy, but it
     * should not stay invisible either.
     *
     * @param string[] $warnings
     */
    protected function reportDrift(array $warnings): void
    {
        if (empty($warnings) || $this->option('quiet-drift')) {
            return;
        }

        warning(count($warnings) . ' documentation gap(s):');

        foreach ($warnings as $line) {
            $this->line("  {$line}");
        }
    }
}
