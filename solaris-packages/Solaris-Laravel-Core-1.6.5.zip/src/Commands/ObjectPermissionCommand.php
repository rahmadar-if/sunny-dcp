<?php

namespace Solaris\Core\Commands;

use Exception;
use Illuminate\Console\Command;
use Solaris\Core\Const\PermissionTypeConst;
use Solaris\Core\Const\RightLevelConst;
use Solaris\Core\Const\RightOperationConst;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Models\ObjectPermission;
use Solaris\Core\Models\ObjectRule;
use Solaris\Core\Models\Permission;
use Solaris\Core\Models\PermissionType;
use Solaris\Core\Models\RecordRule;
use Solaris\Core\Models\RightOperation;
use Solaris\Core\Models\Role;
use Solaris\Core\Services\AccessRight\ObjectRuleService;
use Solaris\Core\Services\AccessRight\RecordRuleService;
use Solaris\Core\Traits\Model\HasObjectPermission;

use function Laravel\Prompts\confirm;
use function Laravel\Prompts\error;
use function Laravel\Prompts\info;
use function Laravel\Prompts\multiselect;
use function Laravel\Prompts\select;
use function Laravel\Prompts\table;
use function Laravel\Prompts\text;
use function Laravel\Prompts\warning;

class ObjectPermissionCommand extends Command
{
    protected $signature = 'solaris:object-permission
                                {action?         : list, create, update, delete}
                                {type?           : permission type (object|record)}
                                {--code=         : object permission code}
                                {--owner_type=   : Owner type (User|Role|Permission). This option is used to add object/record rule}
                                {--owner=        : Owner id/name. This option is used to add object/record rule}
                                {--grantee_type= : Grantee type (User|Role|Permission). This option is used to add object/record rule}
                                {--grantee=      : Grantee id/name. This option is used to add object/record rule}
                                {--priority=     : Priority number, the smaller the number the higher the priority. This option is used to add object/record rule}
                                {--create=       : Operation Create (true|false). This option is used to add object/record rule}
                                {--read=         : Operation Read (true|false). This option is used to add object/record rule}
                                {--update=       : Operation Update (true|false). This option is used to add object/record rule}
                                {--delete=       : Operation Delete (true|false). This option is used to add object/record rule};
                                {--skip=         : Skip looping for add another rules. This option is used to add object/record rule}';

    protected $description = 'Register object and setup object permission & record permission rules';

    protected $rightOperations;
    protected $permissionTypes;

    public function handle()
    {
        $action = $this->argument('action') ?? 'list';
        $type   = $this->argument('type');

        try {
            switch ($action) {
                case 'list':
                    $this->showList();
                    break;

                case 'create':
                    if(empty($type)) {
                        $this->create();
                    } else {
                        if(!in_array($type, ["object", "record"])) {
                            throw new Exception('Invalid type: ' . $type);
                        }

                        $this->createRule($type);
                    }

                    break;

                case 'update':
                    if(empty($type)) {
                        $this->update();
                    } else {
                        if(!in_array($type, ["object", "record"])) {
                            throw new Exception('Invalid type: ' . $type);
                        }

                        $this->updateRule($type);
                    }

                    break;

                case 'delete':
                    if(empty($type)) {
                        $type = select("Choose type", ["object", "record"]);
                    }

                    if(!in_array($type, ["object", "record"])) {
                        throw new Exception('Invalid type: ' . $type);
                    }

                    $this->delete($type);
                    break;

                default:
                    error('Invalid action: ' . $action);
                    break;
            }
        } catch (\Exception $e) {
            error($e->getMessage());
        }

        return self::SUCCESS;
    }

    protected function showList()
    {
        $code = $this->option('code');
        if(empty($code)) {
            $objectPermissions = ObjectPermission::orderBy('code', 'asc')
                ->orderBy('created_at', 'desc')
                ->get(['id', 'name', 'code', 'object_permission', 'record_permission'])
                ->map(fn($item) => [
                    'id'                => $item->id, 
                    'name'              => $item->name, 
                    'code'              => $item->code, 
                    'object_permission' => $item->object_permission ? '✅' : '❌',
                    'record_permission' => $item->record_permission ? '✅' : '❌',
                ]);
            
            info("List all available object permissions");
            table(['id', 'name', 'code', 'object_permission', 'record_permission'], $objectPermissions);
        } else {
            $objectRules = ObjectRuleService::listing($code);
            $recordRules = RecordRuleService::listing($code);

            info("Object rules:");
            table(
                ['id', 'priority', 'type', 'grantee', 'create', 'read', 'update', 'delete'], 
                $objectRules->map(function($rule) {
                    $create = $rule->details->where('operation_id', RightOperationConst::Create)->first();
                    $read   = $rule->details->where('operation_id', RightOperationConst::Read)->first();
                    $update = $rule->details->where('operation_id', RightOperationConst::Update)->first();
                    $delete = $rule->details->where('operation_id', RightOperationConst::Delete)->first();
                    
                    return [
                        'id'       => $rule->id,
                        'priority' => $rule->priority,
                        'type'     => $rule->grantee_type->name,
                        'grantee'  => $rule->grantee->name,
                        'create'   => $create?->level_id == RightLevelConst::Grant  ? '✅' : '❌',
                        'read'     => $read?->level_id == RightLevelConst::Grant    ? '✅' : '❌',
                        'update'   => $update?->level_id == RightLevelConst::Grant  ? '✅' : '❌',
                        'delete'   => $delete?->level_id == RightLevelConst::Grant  ? '✅' : '❌'
                    ];
                })
            );

            info("Record rules:");
            table(
                ['id', 'priority', 'owner type', 'owner', 'grantee type', 'grantee', 'read', 'update', 'delete'], 
                $recordRules->map(function($rule) {
                    $read   = $rule->details->where('operation_id', RightOperationConst::Read)->first();
                    $update = $rule->details->where('operation_id', RightOperationConst::Update)->first();
                    $delete = $rule->details->where('operation_id', RightOperationConst::Delete)->first();
                    
                    return [
                        'id'           => $rule->id,
                        'priority'     => $rule->priority,
                        'owner type'   => $rule->owner_type->name,
                        'owner'        => $rule->owner->name,
                        'grantee type' => $rule->grantee_type->name,
                        'grantee'      => $rule->grantee->name,
                        'read'         => $read?->level_id == RightLevelConst::Grant    ? '✅' : '❌',
                        'update'       => $update?->level_id == RightLevelConst::Grant  ? '✅' : '❌',
                        'delete'       => $delete?->level_id == RightLevelConst::Grant  ? '✅' : '❌'
                    ];
                })
            );
        }
    }

    protected function create()
    {
        $model            = $this->getAvailableModel();
        $objectPermActive = confirm("Object permission is active");
        $recordPermActive = confirm("Record permission is active");

        if(!$objectPermActive && !$recordPermActive) {
            return warning("Object permission or Record permission must be set to active");
        }

        $objectPermission = ObjectPermission::create([
            'name'              => $model["name"],
            'code'              => $model["code"],
            'object_permission' => $objectPermActive,
            'record_permission' => $recordPermActive
        ]);

        info("Object permission for table ".$objectPermission->code." successfully created with Id: ".$objectPermission->id);

        if($objectPermActive || $recordPermActive) {
            $this->rightOperations = RightOperation::orderBy('position', 'asc')->get(['id', 'name']);
            $this->permissionTypes = PermissionType::orderBy('position', 'asc')->get(['id', 'name']);
        }

        if($objectPermActive) {
            while (confirm("Want to add rules for object?")) {
                try {
                    $this->addObjectRule($objectPermission->code);
                } catch (\Exception $e) {
                    error("Failed to add rules: " . $e->getMessage());
                    return self::FAILURE;
                }
            }
        }

        if($recordPermActive && confirm("Want to add rules for record?")) {

        }
    }

    protected function createRule($type)
    {
        $model = $this->getAvailablePermission();

        $this->rightOperations = RightOperation::orderBy('position', 'asc')->get(['id', 'name']);
        $this->permissionTypes = PermissionType::orderBy('position', 'asc')->get(['id', 'name']);

        $skip   = $this->option("skip");
        $isSkip = $skip && strtolower($skip) === "true" ? true : false;

        if ($type === 'object') {
            do {
                try {
                    $this->addObjectRule($model["code"]);
                } catch (\Throwable $e) {
                    error("Failed: " . $e->getMessage());
                    return self::FAILURE;
                }
            } while ($isSkip ? false : $this->confirm("Want to add another object rule?"));
        } else {
            $this->rightOperations = $this->rightOperations->where('id', '!=', RightOperationConst::Create)->values();
            do {
                try {
                    $this->addRecordRule($model["code"]);
                } catch (\Throwable $e) {
                    error("Failed: " . $e->getMessage());
                    return self::FAILURE;
                }
            } while ($isSkip ? false : $this->confirm("Want to add another record rule?"));
        }
    }

    protected function update()
    {
        $model            = $this->getAvailablePermission();
        $objectPermission = ObjectPermission::where('code', $model['code'])->first();

        $objectPermission->object_permission = confirm("Object permission is active? Previous value ". ($objectPermission->object_permission ? "Yes" : "No"));
        $objectPermission->record_permission = confirm("Record permission is active? Previous value ". ($objectPermission->record_permission ? "Yes" : "No"));
        $objectPermission->save();

        ObjectRuleService::clearCache($model['code']);
        RecordRuleService::clearCache($model['code']);

        info("Object permission for table ".$objectPermission->code." successfully updated");
    }

    protected function updateRule($type)
    {
        $model = $this->getAvailablePermission();

        $this->rightOperations = RightOperation::orderBy('position', 'asc')->get(['id', 'name']);
        $this->permissionTypes = PermissionType::orderBy('position', 'asc')->get(['id', 'name']);

        if ($type === 'object') {
            $rules = ObjectRule::whereHas('object_permission', fn($query) => $query->where('code', $model["code"]))
                ->prepared('grantee_type[id,name], grantee_id, priority')
                ->with([
                    'userGrantee', 
                    'roleGrantee', 
                    'permissionGrantee',
                    'details' => fn($query) => $query->prepared('object_rule.id, operation[id, name], level[id, name]')
                ])
                ->orderBy('priority', 'asc')
                ->get();

            $ruleId = select("Select rule", $rules->pluck("grantee.name", "id"));

            $this->updateObjectRule($model["code"], $rules->where("id", $ruleId)->first());
        } else {
            
        }
    }

    protected function delete($type)
    {
        $model      = $this->getAvailablePermission();
        $deleteAll  = confirm("Delete all rules?", default: false);
        if($deleteAll) {
            if($type == "object") {
                ObjectRuleService::deleteAll($model["code"]);
            } else {
                RecordRuleService::deleteAll($model["code"]);
            }

            return info("All rules successfully deleted");
        }

        if($type == "object") {
            $rules = ObjectRule::whereHas('object_permission', fn($query) => $query->where('code', $model["code"]))
                ->with([
                    'grantee_type',
                    'userGrantee', 
                    'roleGrantee', 
                    'permissionGrantee'
                ])
                ->orderBy('priority', 'asc')
                ->get()
                ->map(function($item) {
                    $item->key = $item->grantee->name." (".$item->grantee_type->name.")";
                    return $item;
                });

            $ruleId = select("Select rule", $rules->pluck("key", "id"));

            ObjectRuleService::delete($model["code"], $ruleId);
        } else {
            $rules = RecordRule::whereHas('object_permission', fn($query) => $query->where('code', $model["code"]))
                ->with([
                    'owner_type',
                    'userOwner', 
                    'roleOwner', 
                    'permissionOwner',
                    'grantee_type',
                    'userGrantee', 
                    'roleGrantee', 
                    'permissionGrantee'
                ])
                ->orderBy('priority', 'asc')
                ->get()
                ->map(function($item) {
                    $item->key = "Owner: ".$item->owner->name." (".$item->owner_type->name.") - Grantee: ".$item->grantee->name." (".$item->grantee_type->name.")";
                    return $item;
                });

            $ruleId = select("Select rule", $rules->pluck("key", "id"));

            RecordRuleService::delete($model["code"], $ruleId);
        }

        info("Rule successfully deleted");
    }

    protected function addObjectRule($code)
    {
        $_granteeType = $this->option('grantee_type');
        if(!empty($_granteeType)) {
            $type = $this->permissionTypes->where('name', $_granteeType)->first()->id;
        } else {
            $type = select("Select grantee type", $this->permissionTypes->pluck('name', 'id'));
        }

        $grantees   = null;
        if($type == PermissionTypeConst::User) {
            $grantees = Helper::model('user')::pluck('email', 'id')->all();
        } else if($type == PermissionTypeConst::Role) {
            $grantees = Role::pluck('name', 'id')->all();
        } else {
            $grantees = Permission::pluck('name', 'id')->all();
        }

        $_grantee = $this->option('grantee');
        if(!empty($_grantee)) {
            $grantee = array_search($_grantee, $grantees);
            if(!$grantee) {
                $grantee = select("Select grantee", $grantees);
            }
        } else {
            $grantee = select("Select grantee", $grantees);
        }

        if(ObjectRuleService::exists($code, $type, $grantee)) {
            throw new Exception("Rule is exists, cannot add duplicate rule");
        }

        $_priority  = $this->option("priority");
        $priority   = !is_null($_priority) ? $_priority : text("Priority (Enter a number, the smaller the number the higher the priority)", default: '0');

        info("Add rules:");

        $rules = [];
        foreach ($this->rightOperations as $operation) {
            $level      = confirm($operation->name, yes: "Grant", no: "Deny");
            $rules[]    = [
                'operation' => $operation->id,
                'level'     => $level ? RightLevelConst::Grant : RightLevelConst::Deny
            ];
        }

        ObjectRuleService::add($code, $type, $grantee, (int)$priority, $rules);

        info("New rule successfully created");
    }

    protected function updateObjectRule($code, $rule)
    {
        $type     = select("Select grantee type (previous: ".$rule->grantee_type->name.")", $this->permissionTypes->pluck('name', 'id'));
        $grantees = null;
        if($type == PermissionTypeConst::User) {
            $grantees = Helper::model('user')::pluck('email', 'id')->all();
        } else if($type == PermissionTypeConst::Role) {
            $grantees = Role::pluck('name', 'id')->all();
        } else {
            $grantees = Permission::pluck('name', 'id')->all();
        }

        $grantee = select("Select grantee (previous: ".$rule->grantee->name.")", $grantees);

        if(ObjectRuleService::exists($code, $type, $grantee, $rule->id)) {
            throw new Exception("Rule is exists, cannot add duplicate rule");
        }

        $priority = text("Priority (previous: ".$rule->priority.")", default: $rule->priority);

        info("Update rules:");

        $rules = [];
        foreach ($this->rightOperations as $operation) {
            $previous  = $rule->details->where('operation_id', $operation->id)->first();
            $prevLevel = $previous->level_id == RightLevelConst::Grant ? "Grant" : "Deny";

            $level   = confirm($operation->name." (previous: ".$prevLevel.")", yes: "Grant", no: "Deny");
            $rules[] = [
                'operation' => $operation->id,
                'level'     => $level ? RightLevelConst::Grant : RightLevelConst::Deny
            ];
        }

        ObjectRuleService::update($code, $rule->id, $type, $grantee, (int)$priority, $rules);

        info("Update rule successfully");
    }

    protected function addRecordRule($code)
    {
        $_ownerType = $this->option('owner_type');
        if(!empty($_ownerType)) {
            $ownerType = $this->permissionTypes->where('name', $_ownerType)->first()->id;
        } else {
            $ownerType = select("Select owner type", $this->permissionTypes->pluck('name', 'id'));
        }
        
        $owners = null;
        if($ownerType == PermissionTypeConst::User) {
            $owners = Helper::model('user')::pluck('name', 'id')->all();
        } else if($ownerType == PermissionTypeConst::Role) {
            $owners = Role::pluck('name', 'id')->all();
        } else {
            $owners = Permission::pluck('name', 'id')->all();
        }
        
        $_owner = $this->option('owner');
        if(!empty($_owner)) {
            $owner = array_search($_owner, $owners);
            if(!$owner) {
                $owner = select("Select owner", $owners);
            }
        } else {
            $owner = select("Select owner", $owners);
        }

        $_granteeType = $this->option('grantee_type');
        if(!empty($_granteeType)) {
            $granteeType = $this->permissionTypes->where('name', $_granteeType)->first()->id;
        } else {
            $granteeType = select("Select grantee type", $this->permissionTypes->pluck('name', 'id'));
        }

        $grantees    = null;
        if($granteeType == PermissionTypeConst::User) {
            $grantees = Helper::model('user')::pluck('name', 'id')->all();
        } else if($granteeType == PermissionTypeConst::Role) {
            $grantees = Role::pluck('name', 'id')->all();
        } else {
            $grantees = Permission::pluck('name', 'id')->all();
        }

        $_grantee = $this->option('grantee');
        if(!empty($_grantee)) {
            $grantee = array_search($_grantee, $grantees);
            if(!$grantee) {
                $grantee = select("Select grantee", $grantees);
            }
        } else {
            $grantee = select("Select grantee", $grantees);
        }

        if(RecordRuleService::exists($code, ["type_id" => $ownerType, "id" => $owner], ["type_id" => $granteeType, "id" => $grantee])) {
            throw new Exception("Rule is exists, cannot add duplicate rule");
        }
        
        $_priority  = $this->option("priority");
        $priority   = !is_null($_priority) ? $_priority : text("Priority (Enter a number, the smaller the number the higher the priority)", default: '0');

        info("Add rules:");

        $rules = [];
        foreach ($this->rightOperations as $operation) {
            $option     = $this->option(strtolower($operation->name));
            $level      = $option ? (strtolower($option) === "true" ? true : false) : confirm($operation->name, yes: "Grant", no: "Deny");
            $rules[]    = [
                'operation' => $operation->id,
                'level'     => $level ? RightLevelConst::Grant : RightLevelConst::Deny
            ];
        }

        RecordRuleService::add($code, ["type_id" => $ownerType, "id" => $owner], ["type_id" => $granteeType, "id" => $grantee], (int)$priority, $rules);

        info("New rule successfully created");
    }

    protected function getAvailableModel(): array
    {
        $models = Helper::discoverModels()
            ->filter(function($class) {
                if ($class['reflection']->isSubclassOf(BaseModel::class)) {
                    return true;
                }

                return in_array(
                    HasObjectPermission::class, 
                    array_unique(Helper::getClassTraits($class['reflection']))
                );
            });

        $availableObjectPerm = ObjectPermission::pluck('code')->all();
        
        if($models->isEmpty()) {
            throw new \Exception("Object permission not available");
        }

        if(!empty($availableObjectPerm)) {
            $models = $models->filter(fn ($model) => !in_array($model['table'], $availableObjectPerm));
        }

        if($models->isEmpty()) {
            throw new \Exception("Object permission not available");
        }

        $model = select("Select the object", $models->pluck('table', 'class'));

        return [
            "name" => $model,
            "code" => $models->where('class', $model)->first()['table']
        ];
    }

    protected function getAvailablePermission()
    {
        $objectPermissions = ObjectPermission::get();

        if($objectPermissions->isEmpty()) {
            throw new \Exception("Object permission not available");
        }

        $code = $this->option("code");
        if(!empty($code)) {
            $_model = $objectPermissions->where('code', $code)->first();
            if(!is_null($_model)) {
                $model = $_model->name;
            } else {
                $model = select("Select the object", $objectPermissions->pluck('code', 'name'));
            }
        } else {
            $model = select("Select the object", $objectPermissions->pluck('code', 'name'));
        }

        return [
            "name" => $model,
            "code" => $objectPermissions->where('name', $model)->first()->code
        ];
    }
}