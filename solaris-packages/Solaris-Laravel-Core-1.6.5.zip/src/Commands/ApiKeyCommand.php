<?php

namespace Solaris\Core\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Str;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\ApiKey;
use Solaris\Core\Services\ApiKeyService;

use function Laravel\Prompts\error;
use function Laravel\Prompts\info;
use function Laravel\Prompts\table;
use function Laravel\Prompts\text;
use function Laravel\Prompts\warning;

class ApiKeyCommand extends Command
{
    protected $signature = 'solaris:api-key
                                {action? : list, create, revoke}
                                {--user= : Integration user name/email/id}
                                {--name= : Label for the key, or key id when revoking}
                                {--tier= : Rate limit tier (low, standard, high)}
                                {--ip= : Comma separated IP whitelist}';

    protected $description = 'Manage API keys for integration users (list, create, revoke)';

    public function handle(): int
    {
        $action = $this->argument('action') ?? 'list';

        try {
            return match ($action) {
                'list'   => $this->list(),
                'create' => $this->create(),
                'revoke' => $this->revoke(),
                default  => $this->invalid($action),
            };
        } catch (\Exception $e) {
            error($e->getMessage());

            return self::FAILURE;
        }
    }

    protected function list(): int
    {
        $keys = ApiKey::with('user')->orderByDesc('created_at')->get();

        if ($keys->isEmpty()) {
            warning('No API keys found');

            return self::SUCCESS;
        }

        table(
            ['ID', 'User', 'Name', 'Tier', 'Last used', 'Revoked at'],
            $keys->map(fn (ApiKey $key) => [
                $key->id,
                $key->user?->email ?? '-',
                $key->name,
                $key->rate_limit ?? 'default',
                $key->last_used_at ?? 'never',
                $key->revoked_at ?? '-',
            ])->all()
        );

        return self::SUCCESS;
    }

    protected function create(): int
    {
        $user = $this->resolveUser();

        if (is_null($user)) {
            error('Integration user not found');

            return self::FAILURE;
        }

        $name = $this->option('name') ?: text('Key name', required: true);
        $ips  = $this->option('ip')
            ? array_map('trim', explode(',', $this->option('ip')))
            : null;

        $raw = ApiKeyService::generate($user, $name, $ips, $this->option('tier'));

        info("API key created for {$user->email}");

        // Printed once and never recoverable — only the hash is stored.
        warning('Copy this key now. It cannot be shown again:');
        $this->line('');
        $this->line("  {$raw}");
        $this->line('');

        return self::SUCCESS;
    }

    protected function revoke(): int
    {
        $id = $this->option('name') ?: text('Key id', required: true);

        if (!ApiKeyService::revoke($id)) {
            error('Key not found or already revoked');

            return self::FAILURE;
        }

        info('Key revoked');

        return self::SUCCESS;
    }

    protected function resolveUser(): mixed
    {
        $needle = $this->option('user') ?: text('Integration user (id, email or name)', required: true);

        return (Helper::model('user'))::where('is_integration', true)
            ->where(function ($query) use ($needle) {
                // Comparing a non-uuid against a uuid column is a type error on PostgreSQL.
                $query->when(Str::isUuid($needle), fn ($q) => $q->orWhere('id', $needle))
                    ->orWhere('email', $needle)
                    ->orWhere('name', $needle);
            })
            ->first();
    }

    protected function invalid(string $action): int
    {
        error("Unknown action: {$action}");

        return self::FAILURE;
    }
}
