<?php

namespace Solaris\Core\Commands;

use Illuminate\Console\Command;
use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Support\Str;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Interfaces\Model\SolarisUser;
use Solaris\Core\Models\Permission;
use Solaris\Core\Models\Role;

use function Laravel\Prompts\note;
use function Laravel\Prompts\select;
use function Laravel\Prompts\text;

class NotificationCommand extends Command
{
    protected $signature = 'solaris:notification
                                {--username=    : Send to specific user}
                                {--role=        : Send to specific role}
                                {--permission=  : Send to specific permission}
                                {--title=       : Notification title}
                                {--message=     : Notification message}
                                {--url=         : Notification url link}
                                {--channel=     : Notification channel. inapp|email|webpush|all}';

    protected $description = 'Send notification to specific user, role, or permission';

    public function handle()
    {
        $channel = $this->option("channel");
        if(empty($channel)) {
            $channel = select("Choose notification channel", [
                "inapp"     => "In App Notification",
                "email"     => "Email",
                "webpush"   => "Web push",
                "all"       => "All channel"
            ]);
        }

        $receiverType   = null;
        $receiver       = null;

        if(empty($this->option("username")) && empty($this->option("role")) && empty($this->option("permission"))) {
            $receiverType = select("Choose receiver type", [
                "user"          => "User",
                "role"          => "User who have specific role",
                "permission"    => "User who have specific permission"
            ]);
        }

        if(is_null($receiverType)) {
            if(!empty($this->option("username"))) {
                $receiverType = "user";
            } else if(!empty($this->option("role"))) {
                $receiverType = "role";
            } else if(!empty($this->option("permission"))) {
                $receiverType = "permission";
            }
        }

        $receiver = match ($receiverType) {
            "user"          => $this->getUserSelected(),
            "role"          => $this->getRoleSelected(),
            "permission"    => $this->getPermissionSelected()
        };

        $title = $this->option('title');
        if(empty($title)) {
            $title = text(
                label: "Title",
                required: true
            );
        }

        $message = $this->option('message');
        if(empty($message)) {
            $message = text(
                label: "Message",
                required: true
            );
        }

        $url = $this->option('url');
        if(empty($url)) {
            $url = text("Url");
        }

        if($receiverType != 'user') {
            $whereHas = $receiverType == 'role' ? 'roles' : 'permissions';
            Helper::model('user')::select('id', 'name', 'email', 'is_app_notification', 'is_email_notification', 'is_push_notification')
                ->whereHas($whereHas, fn($query) => $query->where($whereHas.'.id', $receiver->id))
                ->chunk(100, function($users) use($title, $message, $url, $channel) {
                    foreach ($users as $user) {
                        note("Sending to {$user->name} ({$user->email})");

                        $this->sendNotif($user, $channel, $title, $message, $url);
                    }
                });
        } else {
            note("Sending to {$receiver->name} ({$receiver->email})");
            $this->sendNotif($receiver, $channel, $title, $message, $url);
        }

        info("Send notification is finish ✔️");

        return Command::SUCCESS;
    }

    protected function getUserSelected()
    {
        $selected   = null;
        $username   = $this->option("username");

        if (empty($username)) {
            $users = Helper::model('user')::get(['id', 'name']);
            if($users->isEmpty()) {
                throw new \Exception("User not found");
            }

            $selected = select("Choose user", $users->pluck('name', 'id'));
        }

        if(is_null($selected) && !Str::isUuid($username)) {
            $users = Helper::model('user')::where('name', $username)
                ->orWhere('email', $username)
                ->orWhere('username', $username)
                ->get(['id', 'name']);
            if($users->isEmpty()) {
                throw new \Exception("User ".$username." is not found");
            }

            $selected = $users->count() == 1 ? $users->first()->id : select("Choose user", $users->pluck('name', 'id'));
        }

        $selected = !is_null($selected) ? $selected : $username;

        $user = Helper::model('user')::find($selected);
        if(is_null($user)) {
            throw new \Exception("User ".$username." is not found");
        }

        return $user;
    }

    protected function getRoleSelected()
    {
        $selected   = null;
        $_role       = $this->option("role");

        if (empty($role)) {
            $roles = Role::get(['id', 'name']);
            if($roles->isEmpty()) {
                throw new \Exception("Roles not found");
            }

            $selected = select("Choose role", $roles->pluck('name', 'id'));
        }

        if(is_null($selected) && !Str::isUuid($_role)) {
            $roles = Role::where('name', $_role)->get(['id', 'name']);
            if($roles->isEmpty()) {
                throw new \Exception("Role ".$_role." is not found");
            }

            $selected = $roles->count() == 1 ? $roles->first()->id : select("Choose role", $roles->pluck('name', 'id'));
        }

        $selected = !is_null($selected) ? $selected : $_role;

        $role = Role::find($selected);
        if(is_null($role)) {
            throw new \Exception("Role ".$_role." is not found");
        }

        return $role;
    }

    protected function getPermissionSelected()
    {
        $selected       = null;
        $_permission    = $this->option("permission");

        if (empty($_permission)) {
            $permissions = Permission::get(['id', 'name']);
            if($permissions->isEmpty()) {
                throw new \Exception("Permission not found");
            }

            $selected = select("Choose permission", $permissions->pluck('name', 'id'));
        }

        if(is_null($selected) && !Str::isUuid($_permission)) {
            $permissions = Permission::where('name', $_permission)->get(['id', 'name']);
            if($permissions->isEmpty()) {
                throw new \Exception("Permission ".$_permission." is not found");
            }

            $selected = $permissions->count() == 1 ? $permissions->first()->id : select("Choose permission", $permissions->pluck('name', 'id'));
        }

        $selected = !is_null($selected) ? $selected : $_permission;

        $permission = Role::find($selected);
        if(is_null($permission)) {
            throw new \Exception("Permission ".$_permission." is not found");
        }

        return $permission;
    }

    protected function sendNotif(Authenticatable&SolarisUser $user, string $channel, string $title, string $message, string $url)
    {
        match ($channel) {
            'inapp'     => $user->sendInAppNotification($title, $message, $url),
            'email'     => $user->sendEmailNotification($title, $title, $message, $url),
            'webpush'   => $user->sendPushNotification($title, $message, $url),
            default     => $user->sendPreferredNotification($title, $message, $url, force: true),
        };
    }
}