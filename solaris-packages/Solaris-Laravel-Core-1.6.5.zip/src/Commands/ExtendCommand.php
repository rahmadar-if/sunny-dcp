<?php

namespace Solaris\Core\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Str;
use Solaris\ConfigEditor\ConfigEditor;
use Solaris\Core\Helpers\Helper;

use function Laravel\Prompts\error;
use function Laravel\Prompts\info;
use function Laravel\Prompts\select;
use function Laravel\Prompts\warning;

class ExtendCommand extends Command
{
	protected $signature = 'solaris:extend
                            {type : controller, model, repository, request, view, module}
                            {name? : Module name to extend}
                            {--force : Overwrite existing files}';

	protected $description = 'Extend Solaris core components into the project';

	protected const CONFIG_KEYS = [
		'controller' => 'controller.controllers',
		'model'      => 'model.models',
		'repository' => 'repositories',
		'request'    => 'form_requests',
		'view'       => 'resource.views',
	];

	protected array $generatedFiles = [];

	protected array $failures = [];

	public function handle()
	{
		$type = $this->argument('type');

		try {
			$name = $this->getChoice($type);

			switch ($type) {
				case 'controller':
					$this->extendController($name);
					break;
				case 'model':
					$this->extendModel($name);
					break;
				case 'request':
					$this->extendRequest($name);
					break;
				case 'repository':
					$this->extendRepository($name);
					break;
				case 'view':
					$this->extendView($name);
					break;
				case 'module':
					$this->extendModule($name);
					break;
				default:
					error("Type '{$type}' is not supported.");
					return static::FAILURE;
			}

			$this->printSummary();
		} catch (\Throwable $e) {
			$this->failures[] = [Str::studly($type), $e->getMessage()];

			$this->printSummary();

			error($e->getMessage());
			return static::FAILURE;
		}

		if (empty($this->generatedFiles) && !empty($this->failures)) {
			return static::FAILURE;
		}

		return static::SUCCESS;
	}

	protected function getChoice(string $type): string
	{
		$name    = (string)$this->argument('name');
		$choices = $this->getChoices($type);

		if (empty($choices)) {
			throw new \Exception("No available components found for type '{$type}' in configuration.");
		}

		if (empty($name)) {
			return select(
				label: "Select {$type} to extend",
				options: $choices,
				scroll: 15
			);
		}

		foreach ([$name, Str::snake($name), Str::kebab($name), Str::studly($name)] as $candidate) {
			if (isset($choices[$candidate])) {
				return $candidate;
			}
		}

		info("Available choices: " . implode(', ', array_keys($choices)));
		throw new \Exception("Component '{$name}' of type '{$type}' not found in configuration.");
	}

	protected function getChoices(string $type): array
	{
		if ($type === 'module') {
			$allKeys = [];

			foreach (static::CONFIG_KEYS as $configKey) {
				$allKeys = array_merge($allKeys, array_keys(Helper::config($configKey, [])));
			}

			$keys = array_unique($allKeys);
			sort($keys);

			return array_combine($keys, $keys);
		}

		$configKey = static::CONFIG_KEYS[$type] ?? null;
		if (!$configKey) {
			return [];
		}

		$keys = array_keys(Helper::config($configKey, []));
		sort($keys);

		return array_combine($keys, $keys);
	}

	protected function extendController(string $name)
	{
		$studlyName = Str::studly($name);
		$snakeName  = Str::snake($name);
		$targetPath = app_path("Http/Controllers/{$studlyName}Controller.php");

		if (file_exists($targetPath) && !$this->option('force')) {
			throw new \Exception("Controller {$studlyName}Controller already exists.");
		}

		$vendorClass = Helper::controller($snakeName);
		if (!$vendorClass) {
			throw new \Exception("Vendor controller for '{$snakeName}' not found in configuration.");
		}

		$stub    = file_get_contents(__DIR__ . '/../Services/Generators/stubs/controllers/extend.stub');
		$content = str_replace(
			['{{class}}', '{{extend_controller}}'],
			[$studlyName, $vendorClass],
			$stub
		);

		$this->ensureDirectory(dirname($targetPath));
		file_put_contents($targetPath, $content);

		$this->updateConfig("controller.controllers.{$snakeName}", "App\\Http\\Controllers\\{$studlyName}Controller");
		$this->generatedFiles[] = ['Controller', $targetPath];
	}

	protected function extendModel(string $name)
	{
		$studlyName = Str::studly($name);
		$snakeName  = Str::snake($name);
		$targetPath = app_path("Models/{$studlyName}.php");

		if (file_exists($targetPath) && !$this->option('force')) {
			throw new \Exception("Model {$studlyName} already exists.");
		}

		$vendorClass = Helper::model($snakeName);
		if (!$vendorClass) {
			throw new \Exception("Vendor model for '{$snakeName}' not found in configuration.");
		}

		$stub    = file_get_contents(__DIR__ . '/../Services/Generators/stubs/models/extend.stub');
		$content = str_replace(
			['{{class}}', '{{extend_model}}'],
			[$studlyName, $vendorClass],
			$stub
		);

		$this->ensureDirectory(dirname($targetPath));
		file_put_contents($targetPath, $content);

		$this->updateConfig("model.models.{$snakeName}", "App\\Models\\{$studlyName}");
		$this->generatedFiles[] = ['Model', $targetPath];
	}

	protected function extendRequest(string $name)
	{
		$studlyName = Str::studly($name);
		$snakeName  = Str::snake($name);
		$targetPath = app_path("Http/Requests/{$studlyName}Request.php");

		if (file_exists($targetPath) && !$this->option('force')) {
			throw new \Exception("FormRequest {$studlyName}Request already exists.");
		}

		$vendorClass = Helper::formRequest($snakeName);
		if (!$vendorClass) {
			throw new \Exception("Vendor FormRequest for '{$snakeName}' not found in configuration.");
		}

		$stub    = file_get_contents(__DIR__ . '/../Services/Generators/stubs/requests/extend.stub');
		$content = str_replace(
			['{{class}}', '{{extend_form_request}}'],
			[$studlyName, $vendorClass],
			$stub
		);

		$this->ensureDirectory(dirname($targetPath));
		file_put_contents($targetPath, $content);

		$this->updateConfig("form_requests.{$snakeName}", "App\\Http\\Requests\\{$studlyName}Request");
		$this->generatedFiles[] = ['Request', $targetPath];
	}

	protected function extendRepository(string $name)
	{
		$snakeName = Str::snake($name);

		// Repository name always follows the model name it serves
		$modelClass = Helper::model($snakeName);
		$repoName   = $modelClass ? class_basename($modelClass) : Str::studly($name);
		$targetPath = app_path("Repositories/{$repoName}Repository.php");

		if (file_exists($targetPath) && !$this->option('force')) {
			throw new \Exception("Repository {$repoName}Repository already exists.");
		}

		$vendorClass = Helper::repository($snakeName);
		if (!$vendorClass) {
			throw new \Exception("Vendor repository for '{$snakeName}' not found in configuration.");
		}

		if (Str::endsWith($vendorClass, 'BaseRepository')) {
			$stub    = file_get_contents(__DIR__ . '/../Services/Generators/stubs/repositories/repository.stub');
			$content = str_replace(['{{class}}', '{{comment}}'], [$repoName, ''], $stub);
		} else {
			$stub    = file_get_contents(__DIR__ . '/../Services/Generators/stubs/repositories/extend.stub');
			$content = str_replace(
				['{{class}}', '{{extend_repository}}'],
				[$repoName, $vendorClass],
				$stub
			);
		}

		$this->ensureDirectory(dirname($targetPath));
		file_put_contents($targetPath, $content);

		$this->updateConfig("repositories.{$snakeName}", "App\\Repositories\\{$repoName}Repository");
		$this->generatedFiles[] = ['Repository', $targetPath];
	}

	protected function extendView(string $name)
	{
		$snakeName  = Str::snake($name);
		$registered = Helper::view($snakeName);

		if (empty($registered)) {
			$this->extendViewByConvention($name);
			return;
		}

		$entries   = $this->flattenViews($registered);
		$resources = Helper::config('resource.path', []);
		$copiedDir = [];

		foreach ($entries as $configKey => $viewName) {
			[$package, $view] = $this->splitViewName($viewName);

			if (!$package) {
				warning("View '{$viewName}' has no package prefix — already extended, skipped.");
				continue;
			}

			if (!isset($resources[$package])) {
				warning("Package '{$package}' is not registered in resource.path — '{$viewName}' skipped.");
				continue;
			}

			$relPath = str_replace('.', '/', $view);
			$relDir  = dirname($relPath);

			$copiedDir[$relDir] ??= $this->copyViewDirectory($relDir);

			$bladeKey = basename($relPath) . '.blade.php';
			if (!isset($copiedDir[$relDir][$bladeKey])) {
				warning("Blade '{$bladeKey}' not found in vendor directory '{$relDir}' — config not updated.");
				continue;
			}

			$targetKey = $configKey === ''
				? "resource.views.{$snakeName}"
				: "resource.views.{$snakeName}.{$configKey}";

			$this->updateConfig($targetKey, $view);
		}

		foreach ($copiedDir as $relDir => $copied) {
			$this->extendJs($name, $relDir, $copied);
		}
	}

	protected function extendViewByConvention(string $name)
	{
		$kebabName = Str::kebab($name);
		$snakeName = Str::snake($name);
		$relDir    = "pages/{$kebabName}";

		$copied = $this->copyViewDirectory($relDir);

		foreach (['list', 'page'] as $type) {
			if (!isset($copied["{$type}.blade.php"])) {
				continue;
			}

			$this->updateConfig("resource.views.{$snakeName}.{$type}", "pages.{$kebabName}.{$type}");
		}

		$this->extendJs($name, $relDir, $copied);
	}

	protected function copyViewDirectory(string $relDir): array
	{
		$viewPaths = $this->collectViewPaths($relDir);

		if (empty($viewPaths)) {
			throw new \Exception("No vendor view paths found for '{$relDir}'.");
		}

		$mergedFiles = $this->mergeVendorFiles($viewPaths);
		$destBase    = resource_path("views/{$relDir}");

		$copied = $this->copyAndRefactorViews($mergedFiles, $destBase);

		foreach ($copied as $relativePath => $info) {
			if ($info['skipped'] ?? false) {
				continue;
			}

			$this->generatedFiles[] = ["View ({$relativePath})", $info['to']];
		}

		return $copied;
	}

	protected function flattenViews(string|array $registered, string $prefix = ''): array
	{
		if (is_string($registered)) {
			return [$prefix => $registered];
		}

		$flat = [];

		foreach ($registered as $key => $value) {
			$configKey = $prefix === '' ? (string)$key : "{$prefix}.{$key}";
			$flat      = array_merge($flat, $this->flattenViews($value, $configKey));
		}

		return $flat;
	}

	protected function splitViewName(string $viewName): array
	{
		if (!str_contains($viewName, '::')) {
			return [null, $viewName];
		}

		return explode('::', $viewName, 2);
	}

	protected function extendJs(string $name, string $relDir, array $copiedViews)
	{
		$studlyName = Str::studly($name);
		$fallback   = basename($relDir);

		foreach (['list', 'page'] as $type) {
			$bladeFile = "{$type}.blade.php";
			if (!isset($copiedViews[$bladeFile])) {
				continue;
			}

			$sourceBlade = $copiedViews[$bladeFile]['from'];
			$content     = file_get_contents($sourceBlade);

			preg_match('/\bpackage="([^"]+)"/', $content, $m);
			$package = $m[1] ?? null;

			if (!$package) {
				warning("No package attribute in {$bladeFile} ({$relDir}) — JS for '{$type}' not generated.");
				continue;
			}

			preg_match('/\bpath="([^"]+)-index"/', $content, $m);
			$path = $m[1] ?? $fallback;

			$destJsPath = resource_path("js/pages/{$path}.js");

			if (file_exists($destJsPath) && !$this->option('force')) {
				warning("Skipped (exists): {$destJsPath}");
				continue;
			}

			if ($type === 'list') {
				preg_match('/\bid="([^"]+)"/', $content, $m);
				$id = $m[1] ?? $fallback;

				$stub = file_get_contents(__DIR__ . '/../Services/Generators/stubs/js/extend_list.stub');
				$jsContent = str_replace(
					['{{class}}', '{{alias}}', '{{path}}', '{{id}}'],
					[$studlyName, $package, $path, $id],
					$stub
				);
			} else {
				$stub = file_get_contents(__DIR__ . '/../Services/Generators/stubs/js/extend_page.stub');
				$jsContent = str_replace(
					['{{class}}', '{{alias}}', '{{path}}'],
					[$studlyName, $package, $path],
					$stub
				);
			}

			$this->ensureDirectory(dirname($destJsPath));
			file_put_contents($destJsPath, $jsContent);
			$this->generatedFiles[] = ["JS ({$type})", $destJsPath];
		}
	}

	protected function collectViewPaths(string $relDir): array
	{
		$resources = Helper::config('resource.path', []);
		$viewPaths = [];

		foreach ($resources as $key => $relPath) {
			$absPath = base_path("{$relPath}/views/{$relDir}");
			if (is_dir($absPath)) {
				$viewPaths[$key] = $absPath;
			}
		}

		return $viewPaths;
	}

	protected function mergeVendorFiles(array $viewPaths): array
	{
		$fileMap = [];
		foreach ($viewPaths as $basePath) {
			$iterator = new \RecursiveIteratorIterator(
				new \RecursiveDirectoryIterator($basePath, \RecursiveDirectoryIterator::SKIP_DOTS)
			);

			foreach ($iterator as $file) {
				if ($file->isFile()) {
					$absPath = $file->getPathname();
					$relPath = str_replace(rtrim($basePath, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR, '', $absPath);
					$relPath = str_replace(DIRECTORY_SEPARATOR, '/', $relPath);
					$fileMap[$relPath] = $absPath;
				}
			}
		}
		return $fileMap;
	}

	protected function copyAndRefactorViews(array $fileMap, string $destBase): array
	{
		$copied = [];
		foreach ($fileMap as $relPath => $sourcePath) {
			$destPath = "{$destBase}/{$relPath}";

			if (file_exists($destPath) && !$this->option('force')) {
				warning("Skipped (exists): {$destPath}");
				$copied[$relPath] = ['from' => $sourcePath, 'to' => $destPath, 'skipped' => true];
				continue;
			}

			$this->ensureDirectory(dirname($destPath));

			if (str_ends_with($sourcePath, '.blade.php')) {
				$content = file_get_contents($sourcePath);

				if (basename($relPath) === 'list.blade.php' || basename($relPath) === 'page.blade.php') {
					$content = preg_replace('/\s+package="[^"]*"/', '', $content);
					$content = preg_replace('/path="([^"]*)-index"/', 'path="$1"', $content);
				}

				file_put_contents($destPath, $content);
			} else {
				copy($sourcePath, $destPath);
			}

			$copied[$relPath] = ['from' => $sourcePath, 'to' => $destPath];
		}
		return $copied;
	}

	protected function extendModule(string $name)
	{
		$steps = [
			'Model'      => fn() => $this->extendModel($name),
			'Controller' => fn() => $this->extendController($name),
			'Request'    => fn() => $this->extendRequest($name),
			'Repository' => fn() => $this->extendRepository($name),
			'View'       => fn() => $this->extendView($name),
		];

		foreach ($steps as $step => $callback) {
			try {
				$callback();
			} catch (\Throwable $e) {
				$this->failures[] = [$step, $e->getMessage()];
				warning("{$step}: {$e->getMessage()}");
			}
		}
	}

	protected function updateConfig(string $key, string $value)
	{
		$configPath = config_path('sunny.php');

		if (!file_exists($configPath)) {
			file_put_contents($configPath, "<?php\n\nreturn [];\n");
		}

		$editor = new ConfigEditor($configPath);
		$editor->set($key, $value);
		$editor->save();
	}

	protected function ensureDirectory(string $path)
	{
		if (is_dir($path)) {
			return;
		}

		if (!mkdir($path, 0755, true) && !is_dir($path)) {
			throw new \Exception("Failed to create directory: {$path}");
		}
	}

	protected function printSummary()
	{
		if (empty($this->generatedFiles) && empty($this->failures)) {
			return;
		}

		$rows = [];

		foreach ($this->generatedFiles as $file) {
			$rows[] = ['OK', $file[0], $file[1]];
		}

		foreach ($this->failures as $failure) {
			$rows[] = ['FAILED', $failure[0], $failure[1]];
		}

		$this->table(['Status', 'Type', 'Path / Reason'], $rows);

		if (!empty($this->generatedFiles)) {
			info("\nConfiguration updated in config/sunny.php");
		}
	}
}
