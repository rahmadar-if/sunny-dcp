<?php

namespace Solaris\Core\Commands;

use Illuminate\Console\Command;
use Solaris\Core\Services\Excel\ExcelService;

use function Laravel\Prompts\error;
use function Laravel\Prompts\table;

class CleanExcelLogsCommand extends Command
{
	protected $signature = 'solaris:clean-excel-logs {action=all : Which logs to clean: export|import|all}';

	protected $description = 'Clean up export and import log records along with their associated files';

	public function handle(): int
	{
		$action = $this->argument('action');

		if (! in_array($action, ['export', 'import', 'all'])) {
			error('Invalid action. Use: export, import, or all');
			return Command::FAILURE;
		}

		if ($action === 'export' || $action === 'all') {
			info('Cleaning export logs...');
			$result = ExcelService::deleteExportLog();
			table(
				['Metric', 'Count'],
				[
					['Deleted Export Files', $result['deletedFiles']],
					['Skipped Export Files', $result['skippedFiles']],
					['Deleted Log Records', $result['deletedLogs']],
				]
			);
		}

		if ($action === 'import' || $action === 'all') {
			info('Cleaning import logs...');
			$result = ExcelService::deleteImportLog();
			table(
				['Metric', 'Count'],
				[
					['Deleted Error CSV Files', $result['deletedFiles']],
					['Skipped Error CSV Files', $result['skippedFiles']],
					['Deleted Log Records', $result['deletedLogs']],
				]
			);
		}

		info('Done.');
		return Command::SUCCESS;
	}
}
