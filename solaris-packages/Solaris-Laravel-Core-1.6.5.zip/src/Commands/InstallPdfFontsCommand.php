<?php

namespace Solaris\Core\Commands;

use Dompdf\Dompdf;
use Dompdf\Options;
use Illuminate\Console\Command;

use function Laravel\Prompts\info;
use function Laravel\Prompts\warning;

class InstallPdfFontsCommand extends Command
{
	protected $signature = 'solaris:install-pdf-fonts';

	protected $description = 'Register custom fonts for PDF generation';

	public function handle(): int
	{
		$fontDir = storage_path('fonts');

		if (!is_dir($fontDir)) {
			mkdir($fontDir, 0755, true);
		}

		$packageFontsDir = realpath(__DIR__ . '/../../resources/fonts');

		$options = new Options();
		$options->setChroot([base_path(), $fontDir, $packageFontsDir]);
		$options->setFontDir($fontDir);

		$dompdf      = new Dompdf($options);
		$fontMetrics = $dompdf->getFontMetrics();
		$fonts       = $this->fontDefinitions();
		$registered  = 0;
		$failed      = 0;

		foreach ($fonts as [$family, $weight, $style, $path]) {
			if (!file_exists($path)) {
				warning("  File not found: $path");
				$failed++;
				continue;
			}

			$success = $fontMetrics->registerFont(
				['family' => $family, 'weight' => $weight, 'style' => $style],
				'file://' . $path
			);

			if ($success) {
				$this->line("  <info>✓</info> $family ($weight/$style)");
				$registered++;
			} else {
				warning("  ✗ Failed: $family ($weight/$style)");
				$failed++;
			}
		}

		$fontMetrics->saveFontFamilies();

		info("Done. Registered: $registered, Failed: $failed");

		return $failed > 0 ? Command::FAILURE : Command::SUCCESS;
	}

	private function fontDefinitions(): array
	{
		$base = realpath(__DIR__ . '/../../resources/fonts');

		return [
			['Poppins',          'normal', 'normal', "$base/poppins/Poppins-Regular.ttf"],
			['Poppins',          'bold',   'normal', "$base/poppins/Poppins-Bold.ttf"],
			['Poppins',          'normal', 'italic', "$base/poppins/Poppins-Italic.ttf"],
			['Poppins',          'bold',   'italic', "$base/poppins/Poppins-BoldItalic.ttf"],
			['PT Serif',         'normal', 'normal', "$base/pt-serif/PTSerif-Regular.ttf"],
			['PT Serif',         'bold',   'normal', "$base/pt-serif/PTSerif-Bold.ttf"],
			['PT Serif',         'normal', 'italic', "$base/pt-serif/PTSerif-Italic.ttf"],
			['PT Serif',         'bold',   'italic', "$base/pt-serif/PTSerif-BoldItalic.ttf"],
			['Times New Roman',  'normal', 'normal', "$base/times-new-roman/LiberationSerif-Regular.ttf"],
			['Times New Roman',  'bold',   'normal', "$base/times-new-roman/LiberationSerif-Bold.ttf"],
			['Times New Roman',  'normal', 'italic', "$base/times-new-roman/LiberationSerif-Italic.ttf"],
			['Times New Roman',  'bold',   'italic', "$base/times-new-roman/LiberationSerif-BoldItalic.ttf"],
			['Arial',            'normal', 'normal', "$base/arial/LiberationSans-Regular.ttf"],
			['Arial',            'bold',   'normal', "$base/arial/LiberationSans-Bold.ttf"],
			['Arial',            'normal', 'italic', "$base/arial/LiberationSans-Italic.ttf"],
			['Arial',            'bold',   'italic', "$base/arial/LiberationSans-BoldItalic.ttf"],
			['Calibri',          'normal', 'normal', "$base/calibri/Carlito-Regular.ttf"],
			['Calibri',          'bold',   'normal', "$base/calibri/Carlito-Bold.ttf"],
			['Calibri',          'normal', 'italic', "$base/calibri/Carlito-Italic.ttf"],
			['Calibri',          'bold',   'italic', "$base/calibri/Carlito-BoldItalic.ttf"],
			['Courier New',      'normal', 'normal', "$base/courier-new/LiberationMono-Regular.ttf"],
			['Courier New',      'bold',   'normal', "$base/courier-new/LiberationMono-Bold.ttf"],
			['Courier New',      'normal', 'italic', "$base/courier-new/LiberationMono-Italic.ttf"],
			['Courier New',      'bold',   'italic', "$base/courier-new/LiberationMono-BoldItalic.ttf"],
			['Georgia',          'normal', 'normal', "$base/georgia/Tinos-Regular.ttf"],
			['Georgia',          'bold',   'normal', "$base/georgia/Tinos-Bold.ttf"],
			['Georgia',          'normal', 'italic', "$base/georgia/Tinos-Italic.ttf"],
			['Georgia',          'bold',   'italic', "$base/georgia/Tinos-BoldItalic.ttf"],
		];
	}
}
