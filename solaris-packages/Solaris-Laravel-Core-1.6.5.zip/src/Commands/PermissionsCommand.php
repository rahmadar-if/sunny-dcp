<?php

namespace Solaris\Core\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Interfaces\Model\SolarisUser;
use Solaris\Core\Models\Permission;
use Solaris\Core\Models\Role;

use function Laravel\Prompts\confirm;
use function Laravel\Prompts\error;
use function Laravel\Prompts\info;
use function Laravel\Prompts\select;
use function Laravel\Prompts\table;
use function Laravel\Prompts\text;
use function Laravel\Prompts\warning;

class PermissionsCommand extends Command
{
    protected $signature = 'solaris:permissions
                                {action? : list, create, delete, user, role }
                                {--name= : Permission name for new, and can be name or id for delete. If action "list" then "name" not empty, then show list all user and role in a specific permission }
                                {--user= : User name/email/id}
                                {--role= : Role name/id}';

    protected $description = 'Manage permissions (list, create, delete)';

    protected string $permName;
    protected string $user;
    protected string $role;
    protected string $userModel;

    public function handle()
    {
        $this->permName = $this->option('name');
        $this->user = $this->option('user');
        $this->role = $this->option('role');

        $this->userModel = Helper::model('user');

        $action = $this->argument('action') ?? 'list';

        try {
            switch ($action) {
                case 'list':
                    $this->showList();
                    break;

                case 'create':
                    $this->create();
                    break;

                case 'delete':
                    $this->delete();
                    break;

                case 'user':
                    $this->userAssign();
                    break;

                case 'role':
                    $this->roleAssign();
                    break;

                default:
                    error('Invalid action: ' . $action);
            }
        } catch (\Exception $e) {
            error($e->getMessage());
        }

        return self::SUCCESS;
    }

    protected function showList()
    {
        if(empty($this->permName)) {
            $permissions = Permission::orderBy('name', 'asc')
                ->get(['id', 'name'])
                ->map(fn($item) => ['id' => $item->id, 'name' => $item->name]);
            
            info("List all available permissions");
            table(['id', 'name'], $permissions);
        } else {
            $permissions = Permission::where(Str::isUuid($this->permName) ? "id" : "name", $this->permName)->get();
            if($permissions->isEmpty()) {
                return warning("Permission is not found");
            }

            if($permissions->count() > 1) {
                $selectedPermission = select("Select permission", $permissions->pluck('name', 'id')->all());
                $permissions = Permission::where("id", $selectedPermission)->get();
            }
            
            $permission = $permissions->first();
            $users = $permission
                ->getUsers()
                ->map(fn($item) => ['id' => $item->id, 'name' => $item->name, 'email' => $item->email]);

            $roles = $permission
                ->getRoles()
                ->map(fn($item) => ['id' => $item->id, 'name' => $item->name]);

            info("Users in ".$permission->name." permission");
            table(['id', 'name', 'email'], $users);

            info("Roles in ".$permission->name." permission");
            table(['id', 'name'], $roles);
        }
    }

    protected function create()
    {
        if(Str::isUuid($this->permName)) {
            return error('Name must be string');
        }

        if(empty($this->permName)) {
            $this->permName = text('Enter permission name', required: true);
        }

        $exists = Permission::where('name', $this->permName)->exists();
        if($exists) {
            return warning("Permission ".$this->permName." is exists, try another one");
        }

        $permission = Permission::create(['name' => $this->permName]);
        info("Permission ".$this->permName." successfully created with Id: ".$permission->id);
    }

    protected function delete()
    {
        $permission = $this->getPermissionSelected("Select permission to delete");

        $permission->roles()->detach();
        $permission->users()->detach();
        $permission->delete();

        info("Permission ".$permission->name." successfully deleted");
    }

    protected function userAssign()
    {
        $permission = $this->getPermissionSelected("Select permission to be assigned");
        $user = $this->getUserSelected("Select user to be assigned");

        DB::table('user_permissions')->insert([
            'id' => (string) Str::uuid7(),
            'user_id' => $user->id,
            'permission_id' => $permission->id
        ]);

        info("User ".$user->name." successfully assigned to Permission ".$permission->name);
    }

    protected function roleAssign()
    {
        $permission = $this->getPermissionSelected("Select permission to be assigned");
        $role = $this->getRoleSelected("Select role to be assigned");

        DB::table('role_permissions')->insert([
            'id' => (string) Str::uuid7(),
            'role_id' => $role->id,
            'permission_id' => $permission->id,
        ]);

        info("Role ".$role->name." successfully assigned to Permission ".$permission->name);
    }

    protected function getPermissionSelected(string $label): Permission
    {
        $selected = null;

        if (empty($this->permName)) {
            $permissions = Permission::get(['id', 'name']);
            if($permissions->isEmpty()) {
                throw new \Exception("Permissions not found");
            }

            $selected = select($label, $permissions->pluck('name', 'id'));
        }

        if(is_null($selected) && !Str::isUuid($this->permName)) {
            $permissions = Permission::where('name', $this->permName)->get();
            if($permissions->isEmpty()) {
                throw new \Exception("Permission ".$this->permName." is not found");
            }

            $selected = $permissions->count() == 1 ? $permissions->first()->id : select($label, $permissions->pluck('name', 'id'));
        }

        $selected = !is_null($selected) ? $selected : $this->permName;

        $permission = Permission::find($selected);
        if(is_null($permission)) {
            throw new \Exception("Permission ".$this->permName." is not found");
        }

        return $permission;
    }

    protected function getRoleSelected(string $label): Role
    {
        $selected = null;

        if (empty($this->role)) {
            $roles = Role::get(['id', 'name']);
            if($roles->isEmpty()) {
                throw new \Exception("Roles not found");
            }

            $selected = select($label, $roles->pluck('name', 'id'));
        }

        if(is_null($selected) && !Str::isUuid($this->role)) {
            $roles = Role::where('name', $this->role)->get(['id', 'name']);
            if($roles->isEmpty()) {
                throw new \Exception("Role ".$this->role." is not found");
            }

            $selected = $roles->count() == 1 ? $roles->first()->id : select($label, $roles->pluck('name', 'id'));
        }

        $selected = !is_null($selected) ? $selected : $this->role;

        $role = Role::find($selected);
        if(is_null($role)) {
            throw new \Exception("Role ".$this->role." is not found");
        }

        return $role;
    }

    protected function getUserSelected(string $label): SolarisUser
    {
        $selected = null;

        if (empty($this->user)) {
            $users = $this->userModel::get(['id', 'name']);
            if($users->isEmpty()) {
                throw new \Exception("User not found");
            }

            $selected = select($label, $users->pluck('name', 'id'));
        }

        if(is_null($selected) && !Str::isUuid($this->user)) {
            $users = $this->userModel::where('name', Helper::likeOperator(), "%".$this->user."%")
                ->orWhere('email', $this->user)
                ->get(['id', 'name']);
            if($users->isEmpty()) {
                throw new \Exception("User ".$this->user." is not found");
            }

            $selected = $users->count() == 1 ? $users->first()->id : select($label, $users->pluck('name', 'id'));
        }

        $selected = !is_null($selected) ? $selected : $this->user;

        $user = $this->userModel::find($selected);
        if(is_null($user)) {
            throw new \Exception("User ".$this->user." is not found");
        }

        return $user;
    }
}