<?php

namespace Solaris\Core\Commands;

use BaconQrCode\Renderer\PlainTextRenderer;
use BaconQrCode\Writer;
use Illuminate\Console\Command;
use Solaris\Core\Ai\Services\WhatsAppAiService;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Services\WhatsApp\Webhook\WebhookPayload;
use Solaris\Core\Services\WhatsApp\WhatsAppClient;
use Solaris\Core\Services\WhatsApp\WhatsAppService;

use function Laravel\Prompts\confirm;
use function Laravel\Prompts\error;
use function Laravel\Prompts\info;
use function Laravel\Prompts\select;
use function Laravel\Prompts\table;
use function Laravel\Prompts\warning;

class WhatsAppCommand extends Command
{
	protected $signature = 'solaris:whatsapp
	                            {device? : Config key under whatsapp.devices.* (e.g. sunny), or "clean-ai-confirmations" to purge old AI confirmation rows}
	                            {action? : status, connect, logout, qr, redis-subscribe}';

	protected $description = 'Manage WhatsApp device (status, connect, logout, qr, redis-subscribe, clean-ai-confirmations)';

	public function handle(): int
	{
		if ($this->argument('device') === 'clean-ai-confirmations') {
			return $this->cleanAiConfirmations();
		}

		$deviceKey = $this->argument('device') ?? $this->resolveDevice();

		if ($deviceKey === null) {
			return self::FAILURE;
		}

		$action = $this->argument('action');

		if (empty($action)) {
			$action = select('Select action', ['status', 'connect', 'logout', 'qr', 'redis-subscribe']);
		}

		$client = WhatsAppClient::device($deviceKey);

		try {
			match ($action) {
				'status'          => $this->status($client),
				'connect'         => $this->connect($client),
				'logout'          => $this->logout($client),
				'qr'              => $this->qr($client),
				'redis-subscribe' => $this->redisSubscribe($deviceKey),
				default           => error("Unknown action: {$action}"),
			};
		} catch (\Exception $e) {
			error($e->getMessage());

			return self::FAILURE;
		}

		return self::SUCCESS;
	}

	protected function cleanAiConfirmations(): int
	{
		$deleted = WhatsAppAiService::cleanConfirmations();

		info("Deleted {$deleted} wa_ai_confirmations row(s).");

		return self::SUCCESS;
	}

	protected function status(WhatsAppClient $client): void
	{
		$info = $client->getMe();

		table(['Field', 'Value'], [
			['ID',              $info->id],
			['Name',            $info->name],
			['Phone',           $info->phoneNumber ?? '-'],
			['Connected',       $info->isConnected ? '✅ Yes' : '❌ No'],
			['Daily Used',      $info->dailyUsed],
			['Quota Remaining', $info->quotaRemaining() ?? '-'],
		]);
	}

	protected function connect(WhatsAppClient $client): void
	{
		info('Initiating connection...');
		$client->connect();

		$this->output->writeln('');
		info('Waiting for QR code. Scan with WhatsApp to connect.');
		$this->output->writeln('');

		$this->openQrStream($client);
	}

	protected function logout(WhatsAppClient $client): void
	{
		if (!confirm('Logout from WhatsApp? Session will be cleared.')) {
			warning('Cancelled');

			return;
		}

		$client->logout();

		info('Logged out successfully ✔️');
	}

	protected function qr(WhatsAppClient $client): void
	{
		info('Waiting for QR code. Scan with WhatsApp to connect.');
		$this->output->writeln('');

		$this->openQrStream($client);
	}

	protected function redisSubscribe(string $deviceKey): void
	{
		$prefix = "whatsapp.devices.{$deviceKey}";

		if (Helper::config("{$prefix}.webhook_type") !== 'redis') {
			throw new \RuntimeException("Device [{$deviceKey}] webhook_type is not redis.");
		}

		$channel = Helper::config("{$prefix}.redis.channel");

		if (empty($channel)) {
			throw new \RuntimeException("Device [{$deviceKey}] redis.channel is not configured.");
		}

		$host     = Helper::config("{$prefix}.redis.host", '127.0.0.1');
		$port     = (int) Helper::config("{$prefix}.redis.port", 6379);
		$username = Helper::config("{$prefix}.redis.username");
		$password = Helper::config("{$prefix}.redis.password");

		$redis = new \Redis();
		$redis->connect($host, $port, 0, null, 0, -1);
		$redis->auth([$username, $password]);

		info("Device  : {$deviceKey}");
		info("Channel : {$channel}");
		info('Listening for events...');

		$service = WhatsAppService::device($deviceKey);

		$redis->subscribe([$channel], function (\Redis $redis, string $chan, string $message) use ($deviceKey, $service) {
			try {
				$data = json_decode($message, true);

				if (!is_array($data) || !isset($data['event'])) {
					warning('Skipped: invalid message received.');
					return;
				}

				$payload = WebhookPayload::fromArray($data);
				$this->line("[{$payload->timestamp->toIso8601String()}] [{$deviceKey}] {$payload->event} → processing");

				$service->handleWebhook($payload);
			} catch (\Throwable $e) {
				warning("[{$deviceKey}] Handler error: {$e->getMessage()}");
				report($e);
			}
		});
	}

	private function openQrStream(WhatsAppClient $client): void
	{
		$writer  = new Writer(new PlainTextRenderer(0));
		$qrCount = 0;

		$client->streamQr(
			onQr: function (string $qrData) use ($writer, &$qrCount): void {
				$qrCount++;

				if ($qrCount > 1) {
					$this->output->writeln('');
					info('QR updated. Scan the new code:');
					$this->output->writeln('');
				}

				$this->output->write($writer->writeString($qrData));
			},
			onStatus: function (string $status): bool {
				if ($status === 'CONNECTED') {
					$this->output->writeln('');
					info('Connected successfully ✔️');

					return true;
				}

				warning("Status: {$status}");

				return false;
			},
		);
	}

	private function resolveDevice(): ?string
	{
		$devices = collect(Helper::config('whatsapp.devices') ?? [])
			->filter(fn($v) => is_array($v) && isset($v['device_id']))
			->keys()
			->all();

		if (empty($devices)) {
			error('No WhatsApp devices found in config.');

			return null;
		}

		if (count($devices) === 1) {
			return $devices[0];
		}

		return select('Select device', $devices);
	}
}
