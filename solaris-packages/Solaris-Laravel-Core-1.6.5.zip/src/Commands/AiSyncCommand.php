<?php

namespace Solaris\Core\Commands;

use Illuminate\Console\Command;
use Solaris\Core\Ai\Services\AiRegistryService;

use function Laravel\Prompts\info;
use function Laravel\Prompts\table;

class AiSyncCommand extends Command
{
    protected $signature = 'solaris:ai-sync';

    protected $description = 'Sync every registered AI Agent/Tool (package config + project convention folders) into the DB catalog';

    public function handle(AiRegistryService $registry)
    {
        $result = $registry->sync();

        info('AI registry synced.');

        table(
            ['', 'created', 'updated', 'deleted'],
            [
                ['Agents', $result['agents']['created'], $result['agents']['updated'], $result['agents']['deleted']],
                ['Tools', $result['tools']['created'], $result['tools']['updated'], $result['tools']['deleted']],
            ]
        );

        return self::SUCCESS;
    }
}
