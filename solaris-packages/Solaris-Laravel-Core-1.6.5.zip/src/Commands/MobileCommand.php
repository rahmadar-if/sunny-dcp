<?php

namespace Solaris\Core\Commands;

use Illuminate\Console\Command;
use Solaris\Core\Services\AuthService;

use function Laravel\Prompts\error;
use function Laravel\Prompts\info;

class MobileCommand extends Command
{
    protected $signature = 'solaris:mobile {action}';

    protected $description = 'Mobile management commands';

    public function handle(): int
    {
        return match ($this->argument('action')) {
            'cleanup-tokens' => $this->cleanupTokens(),
            default          => $this->invalidAction(),
        };
    }

    private function cleanupTokens(): int
    {
        $deleted = AuthService::cleanupMobileTokens();
        info("Cleaned up {$deleted} expired mobile tokens.");

        return Command::SUCCESS;
    }

    private function invalidAction(): int
    {
        error("Unknown action: {$this->argument('action')}");

        return Command::FAILURE;
    }
}
