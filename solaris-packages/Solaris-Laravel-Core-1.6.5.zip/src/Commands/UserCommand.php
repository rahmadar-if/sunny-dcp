<?php

namespace Solaris\Core\Commands;

use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Str;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Interfaces\Model\SolarisUser;
use Solaris\Core\Models\AuthSession;
use Solaris\Core\Models\Permission;
use Solaris\Core\Models\Role;
use Solaris\Core\Repositories\UserRepository;

use function Laravel\Prompts\confirm;
use function Laravel\Prompts\error;
use function Laravel\Prompts\info;
use function Laravel\Prompts\multiselect;
use function Laravel\Prompts\password;
use function Laravel\Prompts\select;
use function Laravel\Prompts\table;
use function Laravel\Prompts\text;
use function Laravel\Prompts\warning;

class UserCommand extends Command
{
    protected $signature = 'solaris:user
                                {action?        : list, info, create, delete, delete-role, delete-permission, change-password, reset-password, role, permission, verify-email}
                                {--name=        : user full name for create. id|name|email for search user}
                                {--email=       : user email}
                                {--username=    : username to login}
                                {--password=    : user password}
                                {--role=*       : user role, can be multiple}
                                {--permission=* : user permission, can be multiple}';

    protected $description = 'Manage user (list, create, delete, change password, reset password, assign role & permission)';

    protected string $userModel;
    protected UserRepository $userRepo;

    public function handle()
    {
        $this->userModel = Helper::model('user');
        $this->userRepo  = new UserRepository(new $this->userModel);
        
        $action = $this->argument('action') ?? 'list';

        try {
            switch ($action) {
                case 'list':
                    $this->showList();
                    break;

                case 'info':
                    $this->showInfo();
                    break;

                case 'create':
                    $this->create();
                    break;

                case 'delete':
                    $this->delete();
                    break;
                
                case 'role':
                    $this->roleAssign();
                    break;

                case 'permission':
                    $this->permissionAssign();
                    break;

                case 'delete-role':
                    $this->deleteRole();
                    break;

                case 'delete-permission':
                    $this->deletePermission();
                    break;

                case 'change-password':
                    $this->changePassword();
                    break;

                case 'reset-password':
                    $this->resetPassword();
                    break;

                case 'verify-email':
                    $this->verifyEmail();
                    break;

                default:
                    error('Invalid action: ' . $action);
            }
        } catch (\Exception $e) {
            error($e->getMessage());
        }

        return self::SUCCESS;
    }

    protected function showList()
    {
        $latestSession = AuthSession::select([
            'auth_sessions.user_id',
            'auth_sessions.channel',
            'auth_sessions.ip_address',
            'auth_sessions.logged_in_at',
            DB::raw('COALESCE(auth_sessions.last_active_at, mt.last_used_at) as last_active_at'),
        ])
        ->leftJoin('mobile_tokens as mt', function ($join) {
            $join->on('mt.user_id', '=', 'auth_sessions.user_id')
                 ->on('mt.device_id', '=', 'auth_sessions.device_id')
                 ->whereNull('mt.terminated_at');
        })
        ->whereRaw('auth_sessions.logged_in_at = (select max(s.logged_in_at) from auth_sessions s where s.user_id = auth_sessions.user_id)');

        $users = $this->userModel::select([
            'users.id',
            'users.name',
            'users.email',
            'users.username',
            'users.is_active',
            'users.created_at',
            'ls.channel',
            'ls.logged_in_at as last_login_at',
            'ls.last_active_at',
            'ls.ip_address',
        ])
        ->leftJoinSub($latestSession, 'ls', 'ls.user_id', '=', 'users.id')
        ->orderBy('users.name', 'asc')
        ->get()
        ->map(fn($item) => [
            'id'          => $item->id,
            'name'        => $item->name,
            'email'       => $item->email,
            'username'    => $item->username,
            'active'      => $item->is_active ? "✅" : "❌",
            'channel'     => $item->channel ?? '-',
            'created at'  => $item->created_at,
            'last login'  => $item->last_login_at,
            'last active' => $item->last_active_at,
            'ip address'  => $item->ip_address,
        ]);

        info("List all available users");
        table([
            'id',
            'name',
            'email',
            'username',
            'active',
            'channel',
            'created at',
            'last login',
            'last active',
            'ip address',
        ], $users);
    }

    protected function showInfo()
    {
        $name = $this->option('name');
        if(empty($name)) {
            $name = text("User Id or Email or Username or Full name", required: true);
        }

        $users = $this->userModel::prepared(
            "name",
            "email",
            "username",
            "is_active",
            "created_at",
            "profile[birthdate,birthplace,phone_number,gender,salutation,timezone]",
            "profile[country,province,city,district,sub_district,postcode,address]"
        )
        ->when(Str::isUuid($name), fn($query) => $query->where("id", $name))
        ->when(!Str::isUuid($name), 
            fn($query) => $query
                ->where("email", $name)
                ->orWhere("username", $name)
                ->orWhere("name", Helper::likeOperator(), "%".$name."%")
        )
        ->orderBy('name', 'asc')
        ->get();

        if($users->isEmpty()) {
            return warning("User is not found");
        }

        if($users->count() > 1) {
            $selectedUser = select(
                "Select user", 
                $users
                    ->map(function($item) {
                        $item->displayName = "$item->name ($item->email / $item->username)";
                        return $item;
                    })
                    ->pluck('displayName', 'id')
            );

            $users = $users->where("id", $selectedUser);
        }

        $user  = $users->first();
        $roles = $user
            ->getRoles()
            ->map(fn($item) => ['id' => $item->id, 'name' => $item->name]);

        $permissions = $user
            ->getPermissions()
            ->map(fn($item) => ['id' => $item->id, 'name' => $item->name]);
        
        $infos = [
            ['Id'          , $user->id],
            ['Email'       , $user->email],
            ['Username'    , $user->username],
            ['Birthdate'   , $user->profile->birthdate],
            ['Birthplace'  , $user->profile->birthplace],
            ['Phone Number', $user->profile->phone_number],
            ['Gender'      , $user->profile->gender?->name],
            ['Salutation'  , $user->profile->salutation?->name],
            ['Timezone'    , $user->profile->timezone],
            ['Active'      , $user->is_active],
            ['Created At'  , $user->created_at],
        ];
        table(["Field", "Value"], $infos);

        info("Roles in User ".$user->name);
        table(['id', 'name'], $roles);

        info("Permissions in User ".$user->name);
        table(['id', 'name'], $permissions);

        $sessions = AuthSession::select([
            'auth_sessions.channel',
            'auth_sessions.ip_address',
            'auth_sessions.device_name',
            'auth_sessions.user_agent',
            'auth_sessions.logged_in_at',
            'auth_sessions.logged_out_at',
            'auth_sessions.terminated_at',
        ])
        ->where('auth_sessions.user_id', $user->id)
        ->withMobileLastActive()
        ->orderByDesc('auth_sessions.logged_in_at')
        ->limit(5)
        ->get();

        $sessionRows = $sessions->map(fn($s) => [
            'channel'     => $s->channel,
            'ip'          => $s->ip_address,
            'client'      => $this->resolveUserAgent($s->channel, $s->device_name, $s->user_agent),
            'logged in'   => $s->logged_in_at,
            'last active' => $s->resolved_last_active ?? '-',
            'status'      => $s->terminated_at ? 'terminated' : ($s->logged_out_at ? 'logged out' : 'active'),
        ]);

        info("Last 5 Auth Sessions — ".$user->name);
        table(['channel', 'ip', 'client', 'logged in', 'last active', 'status'], $sessionRows);
    }

    protected function create()
    {
        $name = $this->option("name");
        if(empty($name)) {
            $name = text("User full name", required: true);
        }

        $email = $this->option("email");
        if(empty($email)) {
            $email = text("Email for login", required: true);
        }

        $username = $this->option("username");
        if(empty($username)) {
            $username = text("Username for login", required: false);
        }

        $password = $this->option("password");
        if(empty($password)) {
            $password = password("Password", required: true);
        }

        $user = $this->userRepo->create([
            'name'              => $name,
            'email'             => $email,
            'username'          => !empty($username) ? $username : null,
            'password'          => $password,
            'email_verified_at' => Carbon::now(),
            'is_active'         => true
        ]);

        $roles = $this->option('role');
        if(empty($roles) && confirm("Want to add a role?")) {
            $roles = Role::where("name", "!=", "User")->get(['id', 'name']);
            if($roles->isEmpty()) {
                warning("Roles is empty, continue process");
            } else {
                $roles = multiselect("Select role, can be multiple", $roles->pluck('name'));
            }
        }

        if(!empty($roles)) {
            $user->assignRole($roles);
        }
        
        $permissions = $this->option('permission');
        if(empty($permissions) && confirm("Want to add a permission?")) {
            $permissions = Permission::get(['id', 'name']);
            if($permissions->isEmpty()) {
                warning("Permissions is empty, continue process");
            } else {
                $permissions = multiselect("Select permission, can be multiple", $permissions->pluck('name'));
            }
        }
        
        if(!empty($permissions)) {
            $user->assignPermission($permissions);
        }

        info("Create user {$email} is successfully ✔️");
    }

    protected function delete()
    {
        $user = $this->getUserSelected("Select user to delete");

        (new UserRepository(new $this->userModel))->delete($user->id);

        info("User ".$user->name." successfully deleted");
    }

    protected function deleteRole()
    {
        $user  = $this->getUserSelected("Select user");
        $roles = $this->getUserRoleSelected($user, "Select role to deleted");
        
        $user->removeRole($roles);

        info("Role ".implode(",", $roles)." successfully deleted");
    }

    protected function deletePermission()
    {
        $user           = $this->getUserSelected("Select user");
        $permissions    = $this->getUserPermissionSelected($user, "Select permission to deleted");
        
        $user->removePermission($permissions);

        info("Permission ".implode(",", $permissions)." successfully deleted");
    }

    protected function roleAssign()
    {
        $user  = $this->getUserSelected("Select user to be assigned");
        $roles = $this->getRoleSelected("Select role to be assigned");

        $user->assignRole($roles);

        info("Role ".implode(", ", $roles)." successfully assigned to User ".$user->name);
    }

    protected function permissionAssign()
    {
        $user        = $this->getUserSelected("Select user to be assigned");
        $permissions = $this->getPermissionSelected("Select permission to be assigned");

        $user->assignPermission($permissions);

        info("Permission ".implode(", ", $permissions)." successfully assigned to User ".$user->name);
    }
    
    protected function changePassword()
    {
        $user     = $this->getUserSelected("Select user to change password");
        $password = $this->option("password");
        if(empty($password)) {
            $password = password("Password", required: true);
        }

        $user->update(['password' => Hash::make($password)]);

        info("Change password for User ".$user->name." successfully");
    }

    protected function resetPassword()
    {
        $user = $this->getUserSelected("Select user to reset password");
        Password::sendResetLink(['email' => $user->email]);

        info("Send link reset password for User ".$user->name." successfully");
    }

    protected function verifyEmail()
    {
        $name = $this->option('name');

        $users = $this->userModel::whereNull('email_verified_at')
            ->where('is_active', false)
            ->when(!empty($name), fn($q) => $q
                ->where('name', Helper::likeOperator(), "%{$name}%")
                ->orWhere('email', $name)
                ->orWhere('username', $name)
            )
            ->orderBy('name', 'asc')
            ->get(['id', 'name', 'email', 'username']);

        if ($users->isEmpty()) {
            return warning("No unverified inactive users found");
        }

        $selected = null;

        if (!empty($name) && $users->count() === 1) {
            $selected = $users->first()->id;
        } else {
            $selected = select(
                "Select user to force verify email",
                $users->map(function ($item) {
                    $item->displayName = "{$item->name} ({$item->email} / {$item->username})";
                    return $item;
                })->pluck('displayName', 'id')
            );
        }

        $user = $this->userModel::find($selected);

        if (!confirm("Force verify email for {$user->name} ({$user->email})?")) {
            return warning("Cancelled");
        }

        $user->markEmailAsVerified();

        info("Email for User {$user->name} successfully verified ✔️");
    }

    protected function getUserSelected(string $label): Model
    {
        $selected = null;
        $name     = $this->option("name");
        
        $users = $this->userModel::when(!empty($name), function($query) use($name) {
            $query->where('name', Helper::likeOperator(), "%".$name."%")
                ->orWhere('email', $name)
                ->orWhere('username', $name);
        })
        ->orderBy('name', 'asc')
        ->get(['id', 'name', 'email', 'username']);

        if($users->isEmpty()) {
            throw new \Exception("User is not found or empty");
        }

        if(!empty($name) && $users->count() == 1 ) {
            $selected = $users->first()->id;
        } else {
            $selected = select(
                $label, 
                $users->map(function($item) {
                    $item->displayName = "$item->name ($item->email / $item->username)";
                    return $item;
                })
                ->pluck('displayName', 'id')
            );
        }

        $user = $this->userModel::find($selected);
        if(is_null($user)) {
            throw new \Exception("User is not found");
        }

        return $user;
    }

    protected function getRoleSelected(string $label): array
    {
        $selected = null;
        $role     = $this->option("role");
        
        $roles = Role::when(
            !empty($role), 
            fn($query) => $query->whereIn('name', $role)
        )
        ->orderBy('name', 'asc')
        ->get(['id', 'name']);

        if($roles->isEmpty()) {
            throw new \Exception("Roles is not found or empty");
        }
        
        if(!empty($role)) {
            $selected = $roles->pluck('name')->all();
        } else {
            $selected = multiselect(
                $label, 
                $roles->pluck('name'),
                required: true
            );
        }
        
        return $selected;
    }

    protected function getPermissionSelected(string $label): array
    {
        $selected   = null;
        $permission = $this->option("permission");
        
        $permissions = Permission::when(
            !empty($permission), 
            fn($query) => $query->whereIn('name', $permission)
        )
        ->orderBy('name', 'asc')
        ->get(['id', 'name']);

        if($permissions->isEmpty()) {
            throw new \Exception("Permission is not found or empty");
        }
        
        if(!empty($permission)) {
            $selected = $permissions->pluck('name')->all();
        } else {
            $selected = multiselect(
                $label, 
                $permissions->pluck('name'),
                required: true
            );
        }
        
        return $selected;
    }

    protected function getUserRoleSelected(Model $user, string $label): array
    {
        $selected = null;
        $role     = $this->option("role");
        
        $roles = $user->roles()
            ->when(
                !empty($role), 
                fn($query) => $query->whereIn('name', $role)
            )
            ->orderBy('name', 'asc')
            ->get(['roles.id', 'roles.name']);

        if($roles->isEmpty()) {
            throw new \Exception("Roles not found");
        }

        if(!empty($role)) {
            $selected = $roles->pluck('name')->all();
        } else {
            $selected = multiselect(
                $label, 
                $roles->pluck('name'),
                required: true
            );
        }

        return $selected;
    }

    protected function getUserPermissionSelected(Model $user, string $label): array
    {
        $selected   = null;
        $permission = $this->option("permission");

        $permissions = $user->permissions()
            ->when(
                !empty($permission),
                fn($query) => $query->whereIn('name', $permission)
            )
            ->orderBy('name', 'asc')
            ->get(['permissions.id', 'permissions.name']);

        if($permissions->isEmpty()) {
            throw new \Exception("Permissions not found");
        }

        if(!empty($permission)) {
            $selected = $permissions->pluck('name')->all();
        } else {
            $selected = multiselect(
                $label,
                $permissions->pluck('name'),
                required: true
            );
        }

        return $selected;
    }

    private function resolveUserAgent(string $channel, ?string $deviceName, ?string $userAgent): string
    {
        if (!$userAgent) {
            return '-';
        }

        if ($channel === 'mobile') {
            if ($deviceName) {
                return $deviceName;
            }

            if (preg_match('/\(([^)]+)\)/', $userAgent, $m)) {
                return trim(explode(';', $m[1])[0]);
            }

            return '-';
        }

        return $this->parseBrowser($userAgent).' · '.$this->parseOS($userAgent);
    }

    private function parseBrowser(string $ua): string
    {
        if (preg_match('/Edg\/(\d+)/', $ua, $m)) {
            return "Edge {$m[1]}";
        }

        if (preg_match('/OPR\/(\d+)/', $ua, $m)) {
            return "Opera {$m[1]}";
        }

        if (preg_match('/Chrome\/(\d+)/', $ua, $m)) {
            return "Chrome {$m[1]}";
        }

        if (preg_match('/Firefox\/(\d+)/', $ua, $m)) {
            return "Firefox {$m[1]}";
        }

        if (preg_match('/Version\/(\d+).*Safari/', $ua, $m)) {
            return "Safari {$m[1]}";
        }

        return 'Browser';
    }

    private function parseOS(string $ua): string
    {
        if (str_contains($ua, 'Windows NT 10.0')) {
            return 'Windows 10/11';
        }

        if (str_contains($ua, 'Windows NT')) {
            return 'Windows';
        }

        if (str_contains($ua, 'Mac OS X')) {
            return 'macOS';
        }

        if (str_contains($ua, 'Android')) {
            return 'Android';
        }

        if (preg_match('/iPhone|iPad/', $ua)) {
            return 'iOS';
        }

        if (str_contains($ua, 'Linux')) {
            return 'Linux';
        }

        return 'Unknown OS';
    }
}