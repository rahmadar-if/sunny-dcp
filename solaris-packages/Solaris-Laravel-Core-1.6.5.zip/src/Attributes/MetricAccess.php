<?php

namespace Solaris\Core\Attributes;

use Attribute;

#[Attribute()]
class MetricAccess
{
	public function __construct(
		public array $scopes = [],
		public bool $extend  = false,
	) {}

	public function merge(self $parent): static
	{
		return new static(
			scopes: array_merge($parent->scopes, $this->scopes),
		);
	}
}