<?php

namespace Solaris\Core\Attributes;

use Attribute;

#[Attribute()]
class LookupAccess
{
	public function __construct(
		public array $scopes           = [],
		public array $columnExceptions = [],
		public bool $extend            = false,
	) {}

	public function merge(self $parent): static
	{
		return new static(
			scopes:           array_merge($parent->scopes,           $this->scopes),
			columnExceptions: array_merge($parent->columnExceptions, $this->columnExceptions),
		);
	}
}