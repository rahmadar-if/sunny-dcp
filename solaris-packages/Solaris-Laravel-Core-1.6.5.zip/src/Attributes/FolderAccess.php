<?php

namespace Solaris\Core\Attributes;

use Attribute;

#[Attribute()]
class FolderAccess
{
	public function __construct(
		public array $include          = [],
		public array $exclude          = [],
		public array $excludeRelations = [],
		public bool $extend            = false,
	) {}

	public function merge(self $parent): static
	{
		return new static(
			include:          array_merge($parent->include, $this->include),
			exclude:          array_merge($parent->exclude, $this->exclude),
			excludeRelations: array_merge($parent->excludeRelations, $this->excludeRelations),
		);
	}
}
