<?php

namespace Solaris\Core\Attributes;

use Attribute;

#[Attribute()]
class ExportAccess
{
	public function __construct(
		public array $include = [],
		public array $exclude = [],
		public array $default = [],
		public bool $extend   = false,
	) {}

	public function merge(self $parent): static
	{
		return new static(
			include: array_merge($parent->include, $this->include),
			exclude: array_merge($parent->exclude, $this->exclude),
			default: array_merge($parent->default, $this->default),
		);
	}
}
