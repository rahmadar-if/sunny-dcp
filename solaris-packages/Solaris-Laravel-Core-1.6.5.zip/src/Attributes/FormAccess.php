<?php

namespace Solaris\Core\Attributes;

use Attribute;

#[Attribute()]
class FormAccess
{
    public function __construct(public bool $mobileAccess = false) {}
}