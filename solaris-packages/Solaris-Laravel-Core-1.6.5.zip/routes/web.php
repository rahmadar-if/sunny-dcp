<?php

use Illuminate\Support\Facades\Route;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Http\Controllers\AiAgentController;
use Solaris\Core\Http\Controllers\AiToolController;
use Solaris\Core\Http\Controllers\ApprovalController;
use Solaris\Core\Http\Controllers\ApiDocsController;
use Solaris\Core\Http\Controllers\ApiKeyController;
use Solaris\Core\Http\Controllers\AssignmentController;
use Solaris\Core\Http\Controllers\WhatsApp\AiBouncerController;
use Solaris\Core\Http\Controllers\WhatsApp\WhatsAppCoreController;
use Solaris\Core\Http\Controllers\Auth\TwoFactorController;
use Solaris\Core\Http\Controllers\AttachmentController;
use Solaris\Core\Http\Controllers\CodeGeneratorController;
use Solaris\Core\Http\Controllers\DataTableController;
use Solaris\Core\Http\Controllers\ExcelController;
use Solaris\Core\Http\Controllers\FolderController;
use Solaris\Core\Http\Controllers\FormController;
use Solaris\Core\Http\Controllers\HtmlToPdfController;
use Solaris\Core\Http\Controllers\KanbanController;
use Solaris\Core\Http\Controllers\LookupController;
use Solaris\Core\Http\Controllers\LookupManagementController;
use Solaris\Core\Http\Controllers\MenuController;
use Solaris\Core\Http\Controllers\MetricDashboardController;
use Solaris\Core\Http\Controllers\NotificationController;
use Solaris\Core\Http\Controllers\ObjectPermissionController;
use Solaris\Core\Http\Controllers\ObjectRuleController;
use Solaris\Core\Http\Controllers\PermissionController;
use Solaris\Core\Http\Controllers\RecordRuleController;
use Solaris\Core\Http\Controllers\RoleController;
use Solaris\Core\Http\Controllers\WhatsApp\WhatsAppController;
use Solaris\Core\Http\Controllers\WhatsApp\WhatsAppWebhookController;
use Solaris\Core\Repositories\AttachmentRepository;

Route::middleware(['auth', 'verified'])->group(function () {
    Route::get('/', [Helper::controller('home'), 'index'])
        ->name('home');

    Route::prefix('core')->group(function () {
        Route::get('/images/{id}', fn ($id) => AttachmentRepository::previewImage($id))
            ->whereUuid('id')
            ->name('core.images');

        Route::get('/images/thumbnail/{id}', fn ($id) => AttachmentRepository::getThumbnail($id))
            ->whereUuid('id')
            ->name('core.images.thumbnail');

        Route::post('/datatable', DataTableController::class)
            ->middleware(['throttle:datatable'])
            ->name('core.datatable');

        Route::match(['post', 'put'], '/kanban/{id?}', KanbanController::class)->whereUuid('id')
            ->middleware(['throttle:kanban'])
            ->name('core.kanban');

        Route::get('/folder/all-columns', [FolderController::class, 'allColumns'])
            ->name('core.folder.all-columns');

        Route::post('/lookup', LookupController::class)
            ->middleware(['throttle:lookup'])
            ->name('core.lookup');

        Route::post('/dashboard/metric', MetricDashboardController::class)
            ->name('core.dashboard.metric');

        Route::match(['get', 'post', 'put', 'delete'], '/form/{id?}', FormController::class)
            ->whereUuid('id')
            ->middleware(['throttle:form'])
            ->name('core.form');

        Route::prefix('profile')->group(function () {
            $profileController = Helper::controller('profile');

            Route::get('/', [$profileController, 'show'])
                ->name('core.profile');

            Route::post('/banner', [$profileController, 'updateBanner'])
                ->name('core.profile.update.banner');

            Route::post('/avatar', [$profileController, 'updateAvatar'])
                ->name('core.profile.update.avatar');

            Route::put('/change-password', [$profileController, 'changePassword'])
                ->name('core.profile.change-password');

            Route::post('/forgot-password', [Helper::controller('password'), 'sendResetLink'])
                ->name('core.profile.forgot-password');

            Route::delete('/sso/{provider}', [Helper::controller('sso'), 'disconnect'])
                ->name('core.profile.sso.disconnect');
        });

        Route::prefix('two-factor')->group(function () {
            Route::post('/confirm-password', [TwoFactorController::class, 'confirmPassword'])
                ->name('core.two-factor.confirm-password');

            Route::prefix('setup')->group(function () {
                Route::post('/totp', [TwoFactorController::class, 'setupTotp'])
                    ->name('core.two-factor.setup.totp');

                Route::post('/totp/verify', [TwoFactorController::class, 'setupTotpVerify'])
                    ->name('core.two-factor.setup.totp.verify');

                Route::post('/email', [TwoFactorController::class, 'setupEmail'])
                    ->name('core.two-factor.setup.email');

                Route::post('/email/verify', [TwoFactorController::class, 'setupEmailVerify'])
                    ->name('core.two-factor.setup.email.verify');
            });

            Route::prefix('disable')->group(function () {
                Route::post('/send-otp', [TwoFactorController::class, 'disableSendOtp'])
                    ->name('core.two-factor.disable.send-otp');

                Route::post('/', [TwoFactorController::class, 'disable'])
                    ->name('core.two-factor.disable');
            });

            Route::prefix('change')->group(function () {
                Route::post('/verify-current', [TwoFactorController::class, 'changeVerifyCurrent'])
                    ->name('core.two-factor.change.verify-current');

                Route::post('/totp/complete', [TwoFactorController::class, 'changeTotpComplete'])
                    ->name('core.two-factor.change.totp.complete');

                Route::post('/email/complete', [TwoFactorController::class, 'changeEmailComplete'])
                    ->name('core.two-factor.change.email.complete');
            });
        });

        Route::prefix('attachment')->group(function () {
            Route::post('/', [AttachmentController::class, 'store'])
                ->name('core.attachment.store');

            Route::get('/quota', [AttachmentController::class, 'quota'])
                ->name('core.attachment.quota');

            Route::get('/download/{id}', [AttachmentController::class, 'download'])
                ->whereUuid('id')
                ->name('core.attachment.download');

            Route::get('/preview-text/{id}', [AttachmentController::class, 'previewText'])
                ->whereUuid('id')
                ->name('core.attachment.preview-text');

            Route::get('/preview-image/{id}', [AttachmentController::class, 'previewImage'])
                ->whereUuid('id')
                ->name('core.attachment.preview-image');

            Route::get('/preview-media/{id}', [AttachmentController::class, 'previewMedia'])
                ->whereUuid('id')
                ->name('core.attachment.preview-media');

            Route::delete('/{id}', [AttachmentController::class, 'destroy'])
                ->whereUuid('id')
                ->name('core.attachment.delete');
        });

        Route::post('/html-to-pdf', HtmlToPdfController::class)
            ->name('core.html-to-pdf');

        Route::prefix('notification')->group(function () {
            Route::get('/undismiss', [NotificationController::class, 'undismiss'])
                ->name('core.notification.undismiss');

            Route::get('/key', [NotificationController::class, 'key'])
                ->name('core.notification.key');

            Route::post('/subscribe', [NotificationController::class, 'subscribe'])
                ->name('core.notification.subscribe');

            Route::post('/check-subscribe', [NotificationController::class, 'checkSubscribe'])
                ->name('core.notification.check-subscribe');

            Route::post('/unsubscribe', [NotificationController::class, 'unsubscribe'])
                ->name('core.notification.unsubscribe');

            Route::put('/mark-as-read/{id}', [NotificationController::class, 'markAsRead'])
                ->whereUuid('id')
                ->name('core.notification.mark-as-read');

            Route::put('/dismiss/{id}', [NotificationController::class, 'dismiss'])
                ->whereUuid('id')
                ->name('core.notification.dismiss');
        });

        Route::prefix('approval')->group(function () {
            Route::get('/pending', [ApprovalController::class, 'pendingForMe'])
                ->name('core.approval.pending');

            Route::get('/subject', [ApprovalController::class, 'pendingForSubject'])
                ->name('core.approval.subject');

            Route::get('/my-requests', [ApprovalController::class, 'myRequests'])
                ->name('core.approval.my-requests');

            Route::post('/approve/{id}', [ApprovalController::class, 'approve'])
                ->whereUuid('id')
                ->name('core.approval.approve');

            Route::post('/reject/{id}', [ApprovalController::class, 'reject'])
                ->whereUuid('id')
                ->name('core.approval.reject');

            Route::delete('/cancel/{id}', [ApprovalController::class, 'cancel'])
                ->whereUuid('id')
                ->name('core.approval.cancel');
        });

        Route::prefix('whatsapp')->group(function () {
            Route::get('/conversations', [WhatsAppController::class, 'conversations'])
                ->name('core.whatsapp.conversations');

            Route::get('/conversations/{id}', [WhatsAppController::class, 'show'])
                ->whereUuid('id')
                ->name('core.whatsapp.conversation');

            Route::get('/messages/{id}', [WhatsAppController::class, 'messages'])
                ->whereUuid('id')
                ->name('core.whatsapp.messages');

            Route::post('/send', [WhatsAppController::class, 'sendMessage'])
                ->name('core.whatsapp.send');

            Route::post('/add-conversation', [WhatsAppController::class, 'addConversation'])
                ->name('core.whatsapp.add-conversation');

            Route::post('/read/{id}', [WhatsAppController::class, 'markAsRead'])
                ->whereUuid('id')
                ->name('core.whatsapp.read');

            Route::delete('/messages/{id}', [WhatsAppController::class, 'deleteMessage'])
                ->whereUuid('id')
                ->name('core.whatsapp.messages.delete');

            Route::delete('/conversations/{id}', [WhatsAppController::class, 'deleteConversation'])
                ->whereUuid('id')
                ->name('core.whatsapp.conversations.delete');

            Route::post('/messages/{id}/download', [WhatsAppController::class, 'downloadMedia'])
                ->whereUuid('id')
                ->name('core.whatsapp.download');

            Route::get('/messages/{id}/media-status', [WhatsAppController::class, 'checkMediaStatus'])
                ->whereUuid('id')
                ->name('core.whatsapp.media-status');

            Route::prefix('setup')->group(function () {
                Route::get('/device-info', [WhatsAppController::class, 'setupDeviceInfo'])
                    ->name('core.whatsapp.setup.device-info');

                Route::post('/connect', [WhatsAppController::class, 'setupConnect'])
                    ->name('core.whatsapp.setup.connect');

                Route::post('/logout', [WhatsAppController::class, 'setupLogout'])
                    ->name('core.whatsapp.setup.logout');

                Route::get('/qr-stream', [WhatsAppController::class, 'setupQrStream'])
                    ->name('core.whatsapp.setup.qr-stream');
            });
        });

        Route::prefix('excel/export')->group(function () {
            Route::post('/', [ExcelController::class, 'export'])
                ->name('core.excel.export');

            Route::post('/columns', [ExcelController::class, 'exportColumns'])
                ->name('core.excel.export.columns');

            Route::get('/log/{id}', [ExcelController::class, 'exportLog'])
                ->name('core.excel.export.log');

            Route::get('/download/{id}', [ExcelController::class, 'downloadExport'])
                ->whereUuid('id')
                ->name('core.excel.export.download');

            Route::get('/logs', [ExcelController::class, 'exportLogList'])
                ->name('core.excel.export.log-list');
        });

        Route::prefix('excel/import')->group(function () {
            Route::post('/validation', [ExcelController::class, 'importValidation'])
                ->name('core.excel.import.validation');

            Route::get('/log/{id}', [ExcelController::class, 'importLog'])
                ->name('core.excel.import.log');

            Route::get('/log/{id}/download', [ExcelController::class, 'downloadImportErrorLog'])
                ->whereUuid('id')
                ->name('core.excel.import.log-download');

            Route::get('/logs', [ExcelController::class, 'importLogList'])
                ->name('core.excel.import.log-list');

            Route::post('/upload', [ExcelController::class, 'importUpload'])
                ->name('core.excel.import.upload');

            Route::post('/columns', [ExcelController::class, 'importColumns'])
                ->name('core.excel.import.columns');

            Route::post('/confirm', [ExcelController::class, 'importConfirm'])
                ->name('core.excel.import.confirm');

            Route::delete('/upload/{id}', [ExcelController::class, 'importDeleteUpload'])
                ->whereUuid('id')
                ->name('core.excel.import.upload-delete');

            Route::get('/template', [ExcelController::class, 'downloadImportTemplate'])
                ->name('core.excel.import.template');
        });
    });

    Route::prefix('admin')->middleware(['menu.access'])->group(function () {
        Route::prefix('assignment')->group(function () {
            Route::get('/{owner}/{target}/{id}', [AssignmentController::class, 'index'])
                ->whereUuid('id')
                ->name('admin.assignment');

            Route::post('/{owner}/{target}/{id}', [AssignmentController::class, 'store'])
                ->whereUuid('id')
                ->name('admin.assignment.store');
        });

        Route::prefix('dashboard')->group(function () {
            $adminDashboardController = Helper::controller('admin_dashboard');

            Route::get('/', [$adminDashboardController, 'index'])
                ->name('admin.dashboard');

            Route::post('/all', [$adminDashboardController, 'all'])
                ->name('admin.dashboard.all');

            Route::post('/user-distribution', [$adminDashboardController, 'userDistribution'])
                ->name('admin.dashboard.user-distribution');

            Route::post('/storage-per-module', [$adminDashboardController, 'storagePerModule'])
                ->name('admin.dashboard.storage-per-module');

            Route::post('/top-storage-by-user', [$adminDashboardController, 'topStorageByUser'])
                ->name('admin.dashboard.top-storage-by-user');

            Route::post('/near-limit-users', [$adminDashboardController, 'nearLimitUsers'])
                ->name('admin.dashboard.near-limit-users');

            Route::post('/message-volume', [$adminDashboardController, 'messageVolume'])
                ->name('admin.dashboard.message-volume');

            Route::post('/request-by-status', [$adminDashboardController, 'requestByStatus'])
                ->name('admin.dashboard.request-by-status');

            Route::post('/needs-action', [$adminDashboardController, 'needsAction'])
                ->name('admin.dashboard.needs-action');

            Route::post('/resolved-history', [$adminDashboardController, 'resolvedHistory'])
                ->name('admin.dashboard.resolved-history');

            Route::post('/top-agent-by-cost', [$adminDashboardController, 'topAgentByCost'])
                ->name('admin.dashboard.top-agent-by-cost');

            Route::post('/top-user-by-cost', [$adminDashboardController, 'topUserByCost'])
                ->name('admin.dashboard.top-user-by-cost');
        });

        Route::prefix('user')->group(function () {
            $userController = Helper::controller('user');

            Route::get('/', [$userController, 'index'])
                ->name('admin.user');

            Route::get('/{id}', [$userController, 'show'])
                ->whereUuid('id')
                ->name('admin.user.read');

            Route::post('/avatar/{id}', [$userController, 'updateAvatar'])
                ->whereUuid('id')
                ->name('admin.user.update.avatar');

            Route::post('/verify-email/{id}', [$userController, 'resendVerifyEmail'])
                ->whereUuid('id')
                ->middleware('throttle:6,1')
                ->name('admin.user.verify-email');

            Route::post('/reset-password/{id}', [$userController, 'resetPassword'])
                ->whereUuid('id')
                ->name('admin.user.reset-password');

            Route::post('/active/{id}', [$userController, 'active'])
                ->whereUuid('id')
                ->name('admin.user.active');

            Route::post('/mobile-access/{id}', [$userController, 'mobileAccess'])
                ->whereUuid('id')
                ->name('admin.user.mobile-access');

            Route::post('/whatsapp-ai/{id}', [$userController, 'whatsAppAi'])
                ->whereUuid('id')
                ->name('admin.user.whatsapp-ai');

            Route::post('/session-terminate/{id}', [$userController, 'terminateSession'])
                ->whereUuid('id')
                ->name('admin.user.session.terminate');

            Route::prefix('{id}/api-key')->whereUuid('id')->group(function () {
                Route::post('/', [ApiKeyController::class, 'store'])
                    ->name('admin.user.api-key.store');

                Route::post('/{keyId}/revoke', [ApiKeyController::class, 'revoke'])
                    ->whereUuid('keyId')
                    ->name('admin.user.api-key.revoke');
            });

            Route::get('/{id}/audit-log/{logId}', [ApiKeyController::class, 'auditLogDetail'])
                ->whereUuid(['id', 'logId'])
                ->name('admin.user.audit-log.show');
        });

        Route::prefix('role')->group(function () {
            Route::get('/', [RoleController::class, 'index'])
                ->name('admin.role');

            Route::get('/{id}', [RoleController::class, 'show'])
                ->whereUuid('id')
                ->name('admin.role.read');

        });

        Route::prefix('permission')->group(function () {
            Route::get('/', [PermissionController::class, 'index'])
                ->name('admin.permission');

            Route::get('/{id}', [PermissionController::class, 'show'])
                ->whereUuid('id')
                ->name('admin.permission.read');

        });

        Route::prefix('access-right')->group(function() {
            Route::get('/', [ObjectPermissionController::class, 'index'])
                ->name('admin.access-right');

            Route::get('/{id}', [ObjectPermissionController::class, 'show'])
                ->whereUuid('id')
                ->name('admin.access-right.read');

            Route::get('/edit/{id}', [ObjectPermissionController::class, 'edit'])
                ->whereUuid('id')
                ->name('admin.access-right.edit');

            Route::prefix('object-rule')->group(function() {
                Route::get('/{id}', [ObjectRuleController::class, 'list'])
                    ->whereUuid('id')
                    ->name('admin.access-right.object-rule');

                Route::put('/operation/{id}', [ObjectRuleController::class, 'update'])
                    ->whereUuid('id')
                    ->name('admin.access-right.object-rule.update-operation');

                Route::put('/priority/{id}', [ObjectRuleController::class, 'update'])
                    ->whereUuid('id')
                    ->name('admin.access-right.object-rule.update-priority');
            });

            Route::prefix('record-rule')->group(function() {
                Route::get('/{id}', [RecordRuleController::class, 'list'])
                    ->whereUuid('id')
                    ->name('admin.access-right.record-rule');

                Route::put('/operation/{id}', [RecordRuleController::class, 'update'])
                    ->whereUuid('id')
                    ->name('admin.access-right.record-rule.update-operation');

                Route::put('/priority/{id}', [RecordRuleController::class, 'update'])
                    ->whereUuid('id')
                    ->name('admin.access-right.record-rule.update-priority');
            });
        });

        Route::prefix('lookup')->group(function () {
            Route::get('/', [LookupManagementController::class, 'index'])
                ->name('admin.lookup');

            Route::get('/{name}', [LookupManagementController::class, 'show'])
                ->whereAlpha('name')
                ->name('admin.lookup.show');

            Route::post('/save-all', [LookupManagementController::class, 'saveAll'])
                ->name('admin.lookup.save-all');

            Route::post('/clear-cache', [LookupManagementController::class, 'clearCache'])
                ->name('admin.lookup.clear-cache');
        });

        Route::prefix('menu')->group(function () {
            Route::get('/', [MenuController::class, 'index'])
                ->name('admin.menu');

            Route::get('/list', [MenuController::class, 'list'])
                ->name('admin.menu.list');

            Route::get('/{id}', [MenuController::class, 'show'])
                ->whereUuid('id')
                ->name('admin.menu.show');

        });

        Route::prefix('ai-agent')->group(function () {
            Route::get('/list', [AiAgentController::class, 'list'])
                ->name('admin.ai-agent.list');

            Route::post('/sync', [AiAgentController::class, 'sync'])
                ->name('admin.ai-agent.sync');

            Route::get('/{id}', [AiAgentController::class, 'show'])
                ->whereUuid('id')
                ->name('admin.ai-agent.show');

            Route::get('/role/{id}', [AiAgentController::class, 'getAssignRoles'])
                ->whereUuid('id')
                ->name('admin.ai-agent.role');

            Route::post('/role/{id}', [AiAgentController::class, 'assignRole'])
                ->whereUuid('id')
                ->name('admin.ai-agent.assign-role');

            Route::get('/permission/{id}', [AiAgentController::class, 'getAssignPermissions'])
                ->whereUuid('id')
                ->name('admin.ai-agent.permission');

            Route::post('/permission/{id}', [AiAgentController::class, 'assignPermission'])
                ->whereUuid('id')
                ->name('admin.ai-agent.assign-permission');

            Route::get('/user/{id}', [AiAgentController::class, 'getAssignUsers'])
                ->whereUuid('id')
                ->name('admin.ai-agent.user');

            Route::post('/user/{id}', [AiAgentController::class, 'assignUser'])
                ->whereUuid('id')
                ->name('admin.ai-agent.assign-user');

            Route::get('/tool/{id}', [AiAgentController::class, 'getAssignTools'])
                ->whereUuid('id')
                ->name('admin.ai-agent.tool');

            Route::post('/tool/{id}', [AiAgentController::class, 'assignTool'])
                ->whereUuid('id')
                ->name('admin.ai-agent.assign-tool');
        });

        Route::prefix('ai-tool')->group(function () {
            Route::get('/list', [AiToolController::class, 'list'])
                ->name('admin.ai-tool.list');

            Route::get('/{id}', [AiToolController::class, 'show'])
                ->whereUuid('id')
                ->name('admin.ai-tool.show');

            Route::get('/role/{id}', [AiToolController::class, 'getAssignRoles'])
                ->whereUuid('id')
                ->name('admin.ai-tool.role');

            Route::post('/role/{id}', [AiToolController::class, 'assignRole'])
                ->whereUuid('id')
                ->name('admin.ai-tool.assign-role');

            Route::get('/permission/{id}', [AiToolController::class, 'getAssignPermissions'])
                ->whereUuid('id')
                ->name('admin.ai-tool.permission');

            Route::post('/permission/{id}', [AiToolController::class, 'assignPermission'])
                ->whereUuid('id')
                ->name('admin.ai-tool.assign-permission');

            Route::get('/user/{id}', [AiToolController::class, 'getAssignUsers'])
                ->whereUuid('id')
                ->name('admin.ai-tool.user');

            Route::post('/user/{id}', [AiToolController::class, 'assignUser'])
                ->whereUuid('id')
                ->name('admin.ai-tool.assign-user');
        });

        Route::prefix('code-generator')->group(function() {
            Route::get('/', [CodeGeneratorController::class, 'index'])
                ->name('admin.code-generator');

            Route::post('/mask-columns', [CodeGeneratorController::class, 'getMaskColumns'])
                ->name('admin.code-generator.mask-columns');

            Route::get('/record-model', [CodeGeneratorController::class, 'getRecordModel'])
                ->name('admin.code-generator.record-model');

            Route::post('/trigger', [CodeGeneratorController::class, 'triggerRecord'])
                ->name('admin.code-generator.trigger');
        });

        Route::get('/whatsapp', [WhatsAppCoreController::class, 'index'])
            ->name('admin.whatsapp');
    });
});

Route::post('/webhooks/whatsapp', WhatsAppWebhookController::class)
    ->name('webhooks.whatsapp');

Route::post('/webhooks/whatsapp-ai-bouncer', AiBouncerController::class)
    ->name('webhooks.whatsapp-ai-bouncer');

// Public on purpose — partner developers need the reference before they have an account.
// The API itself stays protected by X-Api-Key; this only describes it.
if (Helper::config('api.docs.enabled', true)) {
    Route::prefix(Helper::config('api.docs.route', 'docs/api'))->group(function () {
        Route::get('/', [ApiDocsController::class, 'index'])
            ->name('api.docs');

        Route::get('/v1/openapi.json', [ApiDocsController::class, 'spec'])
            ->name('api.docs.spec');
    });
}
