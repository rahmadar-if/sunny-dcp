<?php

use Illuminate\Support\Facades\Route;
use Solaris\Core\Http\Controllers\AttachmentController;
use Solaris\Core\Http\Controllers\Mobile\AuthController;
use Solaris\Core\Http\Controllers\Mobile\FcmTokenController;
use Solaris\Core\Http\Controllers\Mobile\ImageController;
use Solaris\Core\Http\Controllers\Mobile\LookupController;
use Solaris\Core\Http\Controllers\Mobile\NotificationController;
use Solaris\Core\Http\Controllers\Mobile\ProfileController;

Route::prefix('mobile')->group(function () {
    Route::post('/forgot-password', [AuthController::class, 'forgotPassword'])
        ->name('mobile.forgot-password');

    Route::prefix('login')->group(function () {
        Route::post('/', [AuthController::class, 'login'])
            ->name('mobile.login');
    
        Route::post('/verify-2fa', [AuthController::class, 'verifyTwoFactor'])
            ->name('mobile.login.verify-2fa');
    
        Route::post('/resend-2fa', [AuthController::class, 'resendTwoFactor'])
            ->name('mobile.login.resend-2fa');
    });


    Route::post('/refresh', [AuthController::class, 'refresh'])
        ->name('mobile.refresh');

    Route::middleware('auth.mobile')->group(function () {
        Route::post('/logout', [AuthController::class, 'logout'])
            ->name('mobile.logout');

        Route::post('/logout-all', [AuthController::class, 'logoutAll'])
            ->name('mobile.logout-all');

        Route::put('/fcm-token', FcmTokenController::class)
            ->name('mobile.fcm-token');

        Route::prefix('profile')->group(function () {
            Route::get('/', [ProfileController::class, 'show'])
                ->name('mobile.profile');
            
            Route::put('/', [ProfileController::class, 'update'])
                ->name('mobile.profile.update');

            Route::put('/notification', [ProfileController::class, 'updateNotification'])
                ->name('mobile.profile.update.notification');

            Route::post('/avatar', [ProfileController::class, 'updateAvatar'])
                ->name('mobile.profile.update.avatar');
            
            Route::post('/change-password', [ProfileController::class, 'changePassword'])
                ->name('mobile.change-password');
        });

        Route::get('/images/{id}', [ImageController::class, 'show'])
            ->whereUuid('id')
            ->name('mobile.images');

        Route::get('/images/thumbnail/{id}', [ImageController::class, 'thumbnail'])
            ->whereUuid('id')
            ->name('mobile.images.thumbnail');

        Route::prefix('lookups')->group(function () {
            Route::get('/', [LookupController::class, 'index'])
                ->name('mobile.lookups');

            Route::post('/list', [LookupController::class, 'list'])
                ->name('mobile.lookups.list');
    
            Route::get('/version', [LookupController::class, 'version'])
                ->name('mobile.lookups.version');
        });


        // Route::match(['get', 'post', 'put', 'delete'], '/form/{id?}', FormController::class)
        //     ->whereUuid('id')
        //     ->middleware(['throttle:form'])
        //     ->name('core.form');

        Route::prefix('notification')->group(function () {
            Route::get('/undismiss', [NotificationController::class, 'undismiss'])
                ->name('mobile.notification.undismiss');

            Route::put('/mark-as-read/{id}', [NotificationController::class, 'markAsRead'])
                ->whereUuid('id')
                ->name('mobile.notification.mark-as-read');

            Route::put('/dismiss/{id}', [NotificationController::class, 'dismiss'])
                ->whereUuid('id')
                ->name('mobile.notification.dismiss');
        });

        Route::prefix('attachment')->group(function () {
            Route::post('/', [AttachmentController::class, 'store'])
                ->name('mobile.attachment.store');

            Route::post('/list', [AttachmentController::class, 'mobileList'])
                ->name('mobile.attachment');

            Route::get('/download/{id}', [AttachmentController::class, 'download'])
                ->whereUuid('id')
                ->name('mobile.attachment.download');

            Route::get('/preview-text/{id}', [AttachmentController::class, 'previewText'])
                ->whereUuid('id')
                ->name('mobile.attachment.preview-text');

            Route::get('/preview-image/{id}', [AttachmentController::class, 'previewImage'])
                ->whereUuid('id')
                ->name('mobile.attachment.preview-image');

            Route::delete('/{id}', [AttachmentController::class, 'destroy'])
                ->whereUuid('id')
                ->name('mobile.attachment.delete');
        });
    });
});