<?php

use Illuminate\Support\Facades\Broadcast;

Broadcast::channel('in-app-notification.{id}', function ($user, string $id) {
    return $user->id === $id;
});

Broadcast::channel('batch-delete.{id}', function ($user, string $id) {
    return $user->id === $id;
});

Broadcast::channel('export-download.{id}', function ($user, string $id) {
    return $user->id === $id;
});

Broadcast::channel('import-complete.{id}', function ($user, string $id) {
    return $user->id === $id;
});

Broadcast::channel('approval-request.{id}', function ($user, string $id) {
    return $user->id === $id;
});

Broadcast::channel('approval-status.{id}', function ($user, string $id) {
    return $user->id === $id;
});