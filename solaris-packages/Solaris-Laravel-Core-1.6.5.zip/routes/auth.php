<?php

use Illuminate\Support\Facades\Route;
use Solaris\Core\Helpers\Helper;

Route::middleware('guest')->group(function () {
    Route::prefix('login')->group(function () {
        $authController = Helper::controller('login');

        Route::get('/', [$authController, 'index'])
            ->name('login');

        Route::post('/', [$authController, 'store'])
            ->name('login.store');

        Route::middleware('2fa.pending')->group(function () use ($authController) {
            Route::get('/2fa', [$authController, 'twoFactor'])
                ->name('login.2fa');

            Route::post('/2fa', [$authController, 'twoFactorVerify'])
                ->name('login.2fa.store');

            Route::post('/2fa/resend', [$authController, 'twoFactorResend'])
                ->name('login.2fa.resend');
        });
    });

    if(Helper::config('auth.register')) {
        Route::prefix('register')->group(function() {
            $registerController = Helper::controller('register');

            Route::get('/', [$registerController, 'index'])
                ->name('register');
            
            Route::post('/', [$registerController, 'store'])
                ->name('register.store');
        });
    }

    Route::get('/thank-you/{email}', [Helper::controller('home'), 'thankYou'])
        ->name('thank-you');

    Route::get('verify-email/{id}/{hash}', Helper::controller('verify_email'))
        ->whereUuid('id')
        ->middleware(['signed', 'throttle:6,1'])
        ->name('verification.verify');
        
    Route::post('verify-email', Helper::controller('resend_email'))
        ->middleware('throttle:6,1')
        ->name('verification.send');

    $passwordController = Helper::controller('password');
    Route::get('/forgot-password', [$passwordController, 'forgotPassword'])
        ->name('forgot-password');
    
    Route::post('/forgot-password', [$passwordController, 'sendResetLink'])
        ->name('forgot-password.request');
    
    Route::get('/reset-password/{token}', [$passwordController, 'requestResetPassword'])
        ->name('password.reset');
    
    Route::post('/reset-password', [$passwordController, 'resetPassword'])
        ->name('password.update');

});

if(Helper::config('auth.sso.login') || Helper::config('auth.sso.register')) {
    $ssoController = Helper::controller('sso');
    Route::get('/sso/redirect/{provider}/{mode}', [$ssoController, 'ssoRedirect'])
        ->name('sso.redirect');

    Route::get('/sso/callback/{provider}', [$ssoController, 'callback'])
        ->name('sso.callback');
}

Route::middleware(['auth'])->group(function() {
    $registerController = Helper::controller('register');

    Route::post('/logout', [Helper::controller('login'), 'destroy'])
        ->name('logout');
    
    Route::get('/register/verified/{id}', [$registerController, 'verified'])->whereUuid('id')
        ->name('register.verified');
    
    Route::put('/register/verified/{id}', [$registerController, 'update'])->whereUuid('id')
        ->name('register.update');

    // Route::get('/email/verify', function () {
    //     return "Not verified";
    // })->name('verification.notice');
});