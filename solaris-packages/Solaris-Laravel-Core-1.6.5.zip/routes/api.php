<?php

use Illuminate\Support\Facades\Route;

/*
 * 3rd-party API.
 *
 * Each package declares its own entities in its routes/api.php using the same stack:
 *
 *   Route::prefix('v1')
 *       ->middleware(['api.log', 'auth.api_key', 'throttle:api_key'])
 *       ->group(...);
 *
 * Order matters — api.log wraps auth so rejected calls are still audited, and throttling only
 * means something once the key is known.
 *
 * Core has no 3rd-party entity of its own yet.
 */
