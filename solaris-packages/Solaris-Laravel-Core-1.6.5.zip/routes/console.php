<?php

use Illuminate\Support\Facades\Schedule;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Jobs\CleanApiIdempotencyKeysJob;
use Solaris\Core\Jobs\CleanApiRequestLogsJob;
use Solaris\Core\Jobs\CleanExcelLogsJob;
use Solaris\Core\Jobs\CleanNotificationsJob;
use Solaris\Core\Jobs\ProcessExpiredApprovalsJob;

$timezone = Helper::config('scheduler_timezone', 'UTC');

Schedule::job(new ProcessExpiredApprovalsJob)->everyMinute()->timezone($timezone);
Schedule::command('solaris:auth-session mark-expired')->everyFifteenMinutes()->timezone($timezone);
Schedule::command('solaris:mobile cleanup-tokens')->daily()->timezone($timezone);
Schedule::command('solaris:auth-session cleanup-history')->dailyAt('01:00')->timezone($timezone);
Schedule::command('solaris:whatsapp clean-ai-confirmations')->dailyAt('01:30')->timezone($timezone);
Schedule::job(new CleanExcelLogsJob('all'))->dailyAt('02:00')->timezone($timezone);
Schedule::job(new CleanApiRequestLogsJob)->dailyAt('02:30')->timezone($timezone);
Schedule::job(new CleanApiIdempotencyKeysJob)->hourly()->timezone($timezone);
Schedule::job(new CleanNotificationsJob)->dailyAt('03:00')->timezone($timezone);
