<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
	public function up(): void
	{
		Schema::table('wa_conversations', function (Blueprint $table) {
			$table->dropColumn('is_group');
			$table->string('jid', 100)->nullable()->after('phone_number');
			$table->string('device_id', 50)->after('jid');
		});

		Schema::table('wa_messages', function (Blueprint $table) {
			MigrationHelper::dropIndexIfNeeds($table, ['thumbnail_attachment_id']);
			$table->dropForeign(['thumbnail_attachment_id']);
			$table->dropColumn(['thumbnail_attachment_id', 'media_mimetype', 'media_size']);

			$table->text('thumbnail_image')->nullable()->after('media_filename');
		});
	}

	public function down(): void
	{
		Schema::table('wa_conversations', function (Blueprint $table) {
			$table->dropColumn(['jid', 'device_id']);
			$table->boolean('is_group')->default(false)->after('contact_name');
		});

		Schema::table('wa_messages', function (Blueprint $table) {
			$table->dropColumn('thumbnail_image');
			$table->string('media_mimetype', 100)->nullable()->after('media_filename');
			$table->unsignedBigInteger('media_size')->nullable()->after('media_mimetype');
			$table->foreignUuid('thumbnail_attachment_id')->nullable()->constrained('attachments')->nullOnDelete()->after('media_size');

			MigrationHelper::createIndexIfNeeds($table, ['thumbnail_attachment_id']);
		});
	}
};
