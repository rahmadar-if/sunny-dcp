<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('menus', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('name');
            $table->decimal('position', 15, 6)->default(0);
            $table->string('url')->nullable();
            $table->string('route_name')->nullable();
            $table->string('icon')->nullable();
            $table->boolean('is_category')->nullable()->default(false);
            $table->boolean('is_hide')->nullable()->default(false);
            $table->foreignUuid('parent_id')->nullable()->constrained('menus')->nullOnDelete();
            $table->foreignUuid('category_id')->nullable()->constrained('menus')->nullOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['parent_id']);
            MigrationHelper::createIndexIfNeeds($table, ['category_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('menus');
    }
};
