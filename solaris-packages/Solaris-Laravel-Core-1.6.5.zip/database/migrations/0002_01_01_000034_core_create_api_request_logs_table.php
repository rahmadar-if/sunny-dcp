<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
	public function up(): void
	{
		Schema::create('api_request_logs', function (Blueprint $table) {
			MigrationHelper::baseTable($table);

			$table->foreignUuid('api_key_id')->nullable()->constrained('api_keys')->nullOnDelete();
			$table->foreignUuid('user_id')->nullable()->constrained('users')->nullOnDelete();

			$table->string('method', 10);
			$table->string('path');
			$table->string('route_name')->nullable();
			$table->json('query')->nullable();
			$table->json('request_headers')->nullable();
			$table->json('request_body')->nullable();
			$table->json('response_body')->nullable();

			$table->unsignedSmallInteger('status');
			$table->unsignedInteger('duration_ms')->nullable();
			$table->string('ip_address', 45)->nullable();
			$table->text('user_agent')->nullable();

			MigrationHelper::createIndexIfNeeds($table, ['api_key_id']);
			MigrationHelper::createIndexIfNeeds($table, ['user_id']);

			// Not foreign keys, so MySQL will not index them on its own — these must be
			// created on every driver or the audit filters degrade to full table scans.
			$table->index(['created_at']);
			$table->index(['user_id', 'created_at']);
			$table->index(['status', 'created_at']);
		});
	}

	public function down(): void
	{
		Schema::dropIfExists('api_request_logs');
	}
};
