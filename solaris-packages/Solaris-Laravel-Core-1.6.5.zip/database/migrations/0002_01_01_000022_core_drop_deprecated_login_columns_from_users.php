<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
	public function up(): void
	{
		Schema::table('users', function (Blueprint $table) {
			$table->dropColumn(['last_login_at', 'ip_address', 'user_agent']);
		});
	}

	public function down(): void
	{
		Schema::table('users', function (Blueprint $table) {
			$table->timestamp('last_login_at')->nullable();
			$table->string('ip_address', 45)->nullable();
			$table->text('user_agent')->nullable();
		});
	}
};
