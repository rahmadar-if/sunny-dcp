<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('genders', function (Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('religions', function (Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('countries', function (Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('provincies', function (Blueprint $table) {
            MigrationHelper::baseLookupCode($table);

            $table->foreignUuid('country_id')->nullable()->constrained('countries')->cascadeOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['country_id']);
        });

        Schema::create('cities', function (Blueprint $table) {
            MigrationHelper::baseLookup($table);

            $table->foreignUuid('province_id')->nullable()->constrained('provincies')->cascadeOnDelete();
            $table->foreignUuid('country_id')->nullable()->constrained('countries')->cascadeOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['province_id']);
            MigrationHelper::createIndexIfNeeds($table, ['country_id']);
        });

        Schema::create('districts', function (Blueprint $table) {
            MigrationHelper::baseLookup($table);

            $table->foreignUuid('city_id')->nullable()->constrained('cities')->cascadeOnDelete();
            $table->foreignUuid('province_id')->nullable()->constrained('provincies')->cascadeOnDelete();
            $table->foreignUuid('country_id')->nullable()->constrained('countries')->cascadeOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['city_id']);
            MigrationHelper::createIndexIfNeeds($table, ['province_id']);
            MigrationHelper::createIndexIfNeeds($table, ['country_id']);
        });

        Schema::create('sub_districts', function (Blueprint $table) {
            MigrationHelper::baseLookup($table);

            $table->string('postcode', 10)->nullable();
            $table->foreignUuid('district_id')->nullable()->constrained('districts')->cascadeOnDelete();
            $table->foreignUuid('city_id')->nullable()->constrained('cities')->cascadeOnDelete();
            $table->foreignUuid('province_id')->nullable()->constrained('provincies')->cascadeOnDelete();
            $table->foreignUuid('country_id')->nullable()->constrained('countries')->cascadeOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['district_id']);
            MigrationHelper::createIndexIfNeeds($table, ['city_id']);
            MigrationHelper::createIndexIfNeeds($table, ['province_id']);
            MigrationHelper::createIndexIfNeeds($table, ['country_id']);
        });

        Schema::create('currencies', function (Blueprint $table) {
            MigrationHelper::baseLookupCode($table);

            $table->string('symbol', 5)->nullable();
        });

        Schema::create('salutations', function (Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('salutations');
        Schema::dropIfExists('currencies');
        Schema::dropIfExists('sub_districts');
        Schema::dropIfExists('districts');
        Schema::dropIfExists('cities');
        Schema::dropIfExists('provincies');
        Schema::dropIfExists('countries');
        Schema::dropIfExists('religions');
        Schema::dropIfExists('genders');
    }
};