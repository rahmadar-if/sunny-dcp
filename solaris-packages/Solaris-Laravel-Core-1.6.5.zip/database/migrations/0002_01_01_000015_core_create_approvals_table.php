<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
	public function up(): void
	{
		Schema::create('approval_request_statuses', function (Blueprint $table) {
			MigrationHelper::baseLookup($table);
		});

		Schema::create('approval_level_statuses', function (Blueprint $table) {
			MigrationHelper::baseLookup($table);
		});

		Schema::create('approval_assignment_statuses', function (Blueprint $table) {
			MigrationHelper::baseLookup($table);
		});

		Schema::create('approval_requests', function (Blueprint $table) {
			MigrationHelper::baseTable($table);

			$table->string('name')->nullable();
			$table->string('description')->nullable();
			$table->foreignUuid('requester_id')->constrained('users')->cascadeOnDelete();
			$table->foreignUuid('status_id')->constrained('approval_request_statuses')->restrictOnDelete();
			$table->string('action_class');
			$table->text('action_payload')->nullable();
			$table->string('subject_type')->nullable();
			$table->uuid('subject_id')->nullable();
			$table->string('subject_label')->nullable();
			$table->string('subject_url')->nullable();
			$table->timestamp('expires_at')->nullable()->index();
			$table->unsignedSmallInteger('expires_in')->nullable();
			$table->string('expires_mode', 20)->nullable();
			$table->text('notes')->nullable();
			$table->timestamp('resolved_at')->nullable();
			$table->json('then_chain')->nullable();
			$table->uuid('parent_request_id')->nullable();
			$table->foreign('parent_request_id')->references('id')->on('approval_requests')->nullOnDelete();

			MigrationHelper::createIndexIfNeeds($table, ['requester_id', 'status_id']);
			MigrationHelper::createIndexIfNeeds($table, ['subject_type', 'subject_id']);
		});

		Schema::create('approval_levels', function (Blueprint $table) {
			MigrationHelper::baseTable($table);

			$table->foreignUuid('request_id')->constrained('approval_requests')->cascadeOnDelete();
			$table->foreignUuid('status_id')->constrained('approval_level_statuses')->restrictOnDelete();
			$table->foreignUuid('approver_type_id')->constrained('permission_type')->restrictOnDelete();
			$table->uuid('approver_id');
			$table->decimal('position', 10, 2)->default(0);
			$table->enum('mode', ['first_wins', 'consensus'])->default('first_wins');
			$table->timestamp('resolved_at')->nullable();

			MigrationHelper::createIndexIfNeeds($table, ['request_id', 'position']);
		});

		Schema::create('approval_assignments', function (Blueprint $table) {
			MigrationHelper::baseTable($table);

			$table->foreignUuid('level_id')->constrained('approval_levels')->cascadeOnDelete();
			$table->foreignUuid('approver_id')->constrained('users')->cascadeOnDelete();
			$table->foreignUuid('status_id')->constrained('approval_assignment_statuses')->restrictOnDelete();
			$table->text('notes')->nullable();
			$table->timestamp('acted_at')->nullable();

			MigrationHelper::createIndexIfNeeds($table, ['level_id', 'approver_id']);
			MigrationHelper::createIndexIfNeeds($table, ['approver_id', 'status_id']);
		});
	}

	public function down(): void
	{
		Schema::dropIfExists('approval_assignments');
		Schema::dropIfExists('approval_levels');
		Schema::dropIfExists('approval_requests');
		Schema::dropIfExists('approval_assignment_statuses');
		Schema::dropIfExists('approval_level_statuses');
		Schema::dropIfExists('approval_request_statuses');
	}
};
