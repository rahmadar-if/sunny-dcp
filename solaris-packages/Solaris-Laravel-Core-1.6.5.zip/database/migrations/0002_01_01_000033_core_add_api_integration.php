<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
	public function up(): void
	{
		Schema::table('users', function (Blueprint $table) {
			$table->boolean('is_integration')->default(false)->after('is_mobile_access');
		});

		// group_name, not group — "group" is a reserved keyword on MySQL, PostgreSQL and SQL Server
		Schema::table('permissions', function (Blueprint $table) {
			$table->string('group_name')->nullable()->index()->after('name');
		});

		Schema::table('api_keys', function (Blueprint $table) {
			$table->json('ip_whitelist')->nullable()->after('key');
			$table->string('rate_limit')->nullable()->after('ip_whitelist');
		});
	}

	public function down(): void
	{
		Schema::table('users', function (Blueprint $table) {
			$table->dropColumn('is_integration');
		});

		Schema::table('permissions', function (Blueprint $table) {
			$table->dropColumn('group_name');
		});

		Schema::table('api_keys', function (Blueprint $table) {
			$table->dropColumn('ip_whitelist');
			$table->dropColumn('rate_limit');
		});
	}
};
