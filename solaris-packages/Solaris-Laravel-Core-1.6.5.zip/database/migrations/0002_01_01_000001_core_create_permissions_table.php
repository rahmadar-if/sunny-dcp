<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('roles', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('name')->nullable();
            $table->text('description')->nullable();
        });

        Schema::create('permissions', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('name')->nullable();
            $table->text('description')->nullable();
        });

        Schema::create('user_roles', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->foreignUuid('user_id')->nullable()->constrained('users')->cascadeOnDelete();
            $table->foreignUuid('role_id')->nullable()->constrained('roles')->cascadeOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['user_id']);
            MigrationHelper::createIndexIfNeeds($table, ['role_id']);
        });

        Schema::create('role_permissions', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->foreignUuid('role_id')->nullable()->constrained('roles')->cascadeOnDelete();
            $table->foreignUuid('permission_id')->nullable()->constrained('permissions')->cascadeOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['role_id']);
            MigrationHelper::createIndexIfNeeds($table, ['permission_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('role_permissions');
        Schema::dropIfExists('user_roles');
        Schema::dropIfExists('permissions');
        Schema::dropIfExists('roles');
    }
};