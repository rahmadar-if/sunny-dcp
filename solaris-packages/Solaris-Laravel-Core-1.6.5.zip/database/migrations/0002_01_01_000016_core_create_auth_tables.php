<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->boolean('is_mobile_access')->default(false);
        });

        Schema::create('mobile_tokens', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->foreignUuid('user_id')->constrained('users')->cascadeOnDelete();
            $table->string('device_id')->nullable();
            $table->string('device_name')->nullable();
            $table->string('ip_address', 45)->nullable();
            $table->text('user_agent')->nullable();
            $table->string('access_token', 64)->unique();
            $table->string('fcm_token')->nullable();
            $table->string('refresh_token', 64)->unique();
            $table->timestamp('access_expires_at');
            $table->timestamp('refresh_expires_at');
            $table->timestamp('last_used_at')->nullable();
            $table->timestamp('terminated_at')->nullable();

            MigrationHelper::createIndexIfNeeds($table, ['user_id']);
            $table->unique(['user_id', 'device_id']);
        });

        Schema::create('api_keys', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->foreignUuid('user_id')->constrained('users')->cascadeOnDelete();
            $table->string('name');
            $table->string('key', 64)->unique();
            $table->json('scopes')->nullable();
            $table->timestamp('last_used_at')->nullable();
            $table->timestamp('expires_at')->nullable();
            $table->timestamp('revoked_at')->nullable();

            MigrationHelper::createIndexIfNeeds($table, ['user_id']);
        });

        Schema::create('auth_sessions', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->foreignUuid('user_id')->constrained('users')->cascadeOnDelete();
            $table->string('channel', 20); // web | mobile
            $table->string('session_id')->nullable();
            $table->string('ip_address', 45)->nullable();
            $table->text('user_agent')->nullable();
            $table->string('device_name')->nullable();
            $table->string('device_id')->nullable();
            $table->timestamp('logged_in_at');
            $table->timestamp('last_active_at')->nullable();
            $table->timestamp('logged_out_at')->nullable();
            $table->foreignUuid('terminated_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('terminated_at')->nullable();

            MigrationHelper::createIndexIfNeeds($table, ['user_id']);
            MigrationHelper::createIndexIfNeeds($table, ['session_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('auth_sessions');
        Schema::dropIfExists('api_keys');
        Schema::dropIfExists('mobile_tokens');

        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('is_mobile_access');
        });
    }
};
