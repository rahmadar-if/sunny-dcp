<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('export_logs', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('file_name')->nullable();
            $table->string('model')->nullable();
            $table->integer('total_rows')->default(0);
            $table->text('error_message')->nullable();
            $table->dateTime('finished_at')->nullable();
        });

        Schema::create('import_logs', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('file_name')->nullable();
            $table->string('model')->nullable();
            $table->integer('total_rows')->default(0);
            $table->integer('success_count')->default(0);
            $table->integer('error_count')->default(0);
            $table->string('error_file_path')->nullable();
            $table->text('error_message')->nullable();
            $table->dateTime('finished_at')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('import_logs');
        Schema::dropIfExists('export_logs');
    }
};