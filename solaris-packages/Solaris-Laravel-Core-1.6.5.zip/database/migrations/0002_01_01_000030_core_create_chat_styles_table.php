<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('chat_styles', function (Blueprint $table) {
            MigrationHelper::baseLookupDescription($table);
        });

        Schema::table('user_profiles', function (Blueprint $table) {
            $table->foreignUuid('chat_style_id')->nullable()->after('nickname')->constrained('chat_styles')->nullOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['chat_style_id']);
        });
    }

    public function down(): void
    {
        Schema::table('user_profiles', function (Blueprint $table) {
            $table->dropForeign(['chat_style_id']);
            $table->dropColumn('chat_style_id');
        });

        Schema::dropIfExists('chat_styles');
    }
};
