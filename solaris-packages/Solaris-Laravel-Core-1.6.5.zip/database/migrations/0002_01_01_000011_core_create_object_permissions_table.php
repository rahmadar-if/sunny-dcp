<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('user_permissions', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->foreignUuid('user_id')->nullable()->constrained('users');
            $table->foreignUuid('permission_id')->nullable()->constrained('permissions');

            MigrationHelper::createIndexIfNeeds($table, ['user_id']);
            MigrationHelper::createIndexIfNeeds($table, ['permission_id']);
        });

        Schema::create('permission_type', function (Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('object_permissions', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('code')->nullable();
            $table->boolean('object_permission')->nullable()->default(false);
            $table->boolean('record_permission')->nullable()->default(false);

            $table->unique('code');
        });

        Schema::create('object_rules', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->uuid('grantee_id')->nullable();
            $table->unsignedInteger('priority')->default(0);

            $table->foreignUuid('grantee_type_id')->nullable()->constrained('permission_type')->nullOnDelete();
            $table->foreignUuid('object_permission_id')->nullable()->constrained('object_permissions')->cascadeOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['grantee_type_id']);
            MigrationHelper::createIndexIfNeeds($table, ['object_permission_id']);
        });

        Schema::create('object_rule_details', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->foreignUuid('operation_id')->nullable()->constrained('right_operations')->nullOnDelete();
            $table->foreignUuid('level_id')->nullable()->constrained('right_levels')->nullOnDelete();
            $table->foreignUuid('object_rule_id')->nullable()->constrained('object_rules')->cascadeOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['operation_id']);
            MigrationHelper::createIndexIfNeeds($table, ['level_id']);
            MigrationHelper::createIndexIfNeeds($table, ['object_rule_id']);
        });

        Schema::create('record_rules', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->uuid('owner_id')->nullable();
            $table->uuid('grantee_id')->nullable();
            $table->unsignedInteger('priority')->default(0);

            $table->foreignUuid('owner_type_id')->nullable()->constrained('permission_type')->nullOnDelete();
            $table->foreignUuid('grantee_type_id')->nullable()->constrained('permission_type')->nullOnDelete();
            $table->foreignUuid('object_permission_id')->nullable()->constrained('object_permissions')->cascadeOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['owner_type_id']);
            MigrationHelper::createIndexIfNeeds($table, ['grantee_type_id']);
            MigrationHelper::createIndexIfNeeds($table, ['object_permission_id']);
        });

        Schema::create('record_rule_details', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->foreignUuid('operation_id')->nullable()->constrained('right_operations')->nullOnDelete();
            $table->foreignUuid('level_id')->nullable()->constrained('right_levels')->nullOnDelete();
            $table->foreignUuid('record_rule_id')->nullable()->constrained('record_rules')->cascadeOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['operation_id']);
            MigrationHelper::createIndexIfNeeds($table, ['level_id']);
            MigrationHelper::createIndexIfNeeds($table, ['record_rule_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('record_rule_details');
        Schema::dropIfExists('record_rules');
        Schema::dropIfExists('object_rule_details');
        Schema::dropIfExists('object_rules');
        Schema::dropIfExists('object_permissions');
        Schema::dropIfExists('user_permissions');
        Schema::dropIfExists('permission_type');
    }
};
