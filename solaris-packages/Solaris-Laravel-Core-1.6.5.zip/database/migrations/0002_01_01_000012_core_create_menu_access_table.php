<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('user_menus', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->foreignUuid('user_id')->nullable()->constrained('users')->cascadeOnDelete();
            $table->foreignUuid('menu_id')->nullable()->constrained('menus')->cascadeOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['user_id']);
            MigrationHelper::createIndexIfNeeds($table, ['menu_id']);
        });

        Schema::create('role_menus', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->foreignUuid('role_id')->nullable()->constrained('roles')->cascadeOnDelete();
            $table->foreignUuid('menu_id')->nullable()->constrained('menus')->cascadeOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['role_id']);
            MigrationHelper::createIndexIfNeeds($table, ['menu_id']);
        });

        Schema::create('permission_menus', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->foreignUuid('permission_id')->nullable()->constrained('permissions')->cascadeOnDelete();
            $table->foreignUuid('menu_id')->nullable()->constrained('menus')->cascadeOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['permission_id']);
            MigrationHelper::createIndexIfNeeds($table, ['menu_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('permission_menus');
        Schema::dropIfExists('role_menus');
        Schema::dropIfExists('user_menus');
    }
};