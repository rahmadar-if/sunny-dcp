<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('code_generators', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('code')->nullable();
            $table->string('column')->nullable();
            $table->string('mask')->nullable();
            $table->boolean('active')->nullable()->default(true);

            $table->unique('code');
        });

        Schema::create('code_generator_details', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('mask_format')->nullable();
            $table->unsignedInteger('last_number')->default(0);
            $table->foreignUuid('code_generator_id')->nullable()->constrained('code_generators')->cascadeOnDelete();

            $table->unique(['code_generator_id', 'mask_format']);

            MigrationHelper::createIndexIfNeeds($table, ['code_generator_id']);
        });

        Schema::create('code_generator_owners', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('generated_code')->nullable();
            $table->uuid('record_id')->nullable();

            $table->foreignUuid('generator_detail_id')->nullable()->constrained('code_generator_details')->cascadeOnDelete();
            $table->foreignUuid('user_id')->nullable()->constrained('users');

            MigrationHelper::createIndexIfNeeds($table, ['generator_detail_id']);
            MigrationHelper::createIndexIfNeeds($table, ['user_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('code_generator_owners');
        Schema::dropIfExists('code_generator_details');
        Schema::dropIfExists('code_generators');
    }
};