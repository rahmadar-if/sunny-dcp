<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('folders', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('name')->nullable();
            $table->string('description')->nullable();
            $table->string('table_name')->nullable();
            $table->json('filters')->nullable();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('folders');
    }
};