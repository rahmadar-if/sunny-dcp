<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
	public function up(): void
	{
		Schema::create('wa_ai_confirmations', function (Blueprint $table) {
			MigrationHelper::baseTable($table);

			$table->foreignUuid('user_id')->constrained('users')->cascadeOnDelete();
			$table->string('tool_name');
			$table->json('payload')->nullable();
			$table->timestamp('exp_at');
			$table->string('status')->default('pending');
			$table->text('message')->nullable();

			MigrationHelper::createIndexIfNeeds($table, ['user_id']);
			MigrationHelper::createIndexIfNeeds($table, ['status']);
			MigrationHelper::createIndexIfNeeds($table, ['created_at']);
		});
	}

	public function down(): void
	{
		Schema::dropIfExists('wa_ai_confirmations');
	}
};
