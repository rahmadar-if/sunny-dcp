<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
	public function up(): void
	{
		Schema::create('wa_conversations', function (Blueprint $table) {
			MigrationHelper::baseTable($table);

			$table->string('phone_number', 20)->unique();
			$table->string('contact_name')->nullable();
			$table->boolean('is_group')->default(false);
			$table->foreignUuid('profile_picture_id')->nullable()->constrained('attachments')->nullOnDelete();
			$table->timestamp('profile_picture_fetched_at')->nullable();
			$table->unsignedInteger('unread_count')->default(0);
			$table->timestamp('last_message_at')->nullable();

			MigrationHelper::createIndexIfNeeds($table, ['last_message_at']);
			MigrationHelper::createIndexIfNeeds($table, ['profile_picture_id']);
		});

		Schema::create('wa_messages', function (Blueprint $table) {
			MigrationHelper::baseTable($table);

			$table->foreignUuid('conversation_id')->constrained('wa_conversations')->cascadeOnDelete();
			$table->string('wa_message_id', 100)->unique();
			$table->enum('direction', ['received', 'sent']);
			$table->enum('type', ['text', 'image', 'video', 'audio', 'document', 'sticker'])->default('text');
			$table->text('body')->nullable();
			$table->text('caption')->nullable();
			$table->string('quoted_wa_message_id', 100)->nullable();
			$table->string('media_url', 500)->nullable();
			$table->foreignUuid('thumbnail_attachment_id')->nullable()->constrained('attachments')->nullOnDelete();
			$table->foreignUuid('attachment_id')->nullable()->constrained('attachments')->nullOnDelete();
			$table->string('media_filename')->nullable();
			$table->string('media_mimetype', 100)->nullable();
			$table->unsignedBigInteger('media_size')->nullable();
			$table->enum('status', ['sent', 'delivered', 'read', 'played'])->nullable();
			$table->timestamp('read_at')->nullable();
			$table->foreignUuid('read_by_id')->nullable()->constrained(MigrationHelper::$userTable)->nullOnDelete();
			$table->timestamp('wa_timestamp');

			MigrationHelper::createIndexIfNeeds($table, ['conversation_id', 'wa_timestamp']);
			MigrationHelper::createIndexIfNeeds($table, ['direction']);
			MigrationHelper::createIndexIfNeeds($table, ['status']);
			MigrationHelper::createIndexIfNeeds($table, ['read_by_id']);
			MigrationHelper::createIndexIfNeeds($table, ['thumbnail_attachment_id']);
			MigrationHelper::createIndexIfNeeds($table, ['attachment_id']);
		});
	}

	public function down(): void
	{
		Schema::dropIfExists('wa_messages');
		Schema::dropIfExists('wa_conversations');
	}
};
