<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('sessions', function (Blueprint $table) {
            if (Schema::hasColumn('sessions', 'user_id')) {
                $table->dropColumn('user_id');
            }
        });

        Schema::table('users', function (Blueprint $table) {
            if (Schema::hasColumn('users', 'id')) {
                // If it's mysql/mariadb, we must drop the auto_increment first before dropping primary key
                if (in_array(config('database.default'), ['mysql', 'mariadb'])) {
                    $table->unsignedBigInteger('id')->change();
                }
                $table->dropPrimary(['id']);
                $table->dropColumn('id');
            }

            if (Schema::hasColumn('users', 'created_at')) {
                $table->dropColumn('created_at');
            }

            if (Schema::hasColumn('users', 'updated_at')) {
                $table->dropColumn('updated_at');
            }

            MigrationHelper::baseTable($table);

            $table->boolean('is_2fa')->default(false);
            $table->boolean('is_push_notification')->default(false);
            $table->boolean('is_email_notification')->default(false);
            $table->boolean('is_app_notification')->default(false);
            $table->boolean('is_active')->default(false);
        });

        Schema::table('sessions', function (Blueprint $table) {
            $table->foreignUuid('user_id')->nullable()->constrained('users')->cascadeOnDelete();
            
            MigrationHelper::createIndexIfNeeds($table, ['user_id']);
        });

        Schema::create('user_sso', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('email')->nullable();
            $table->string('provider_id')->nullable();
            $table->string('provider_name')->nullable();
            $table->text('provider_token')->nullable();
            $table->text('provider_refresh_token')->nullable();

            $table->foreignUuid('user_id')->nullable()->constrained('users')->cascadeOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['user_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('user_sso');

        Schema::table('sessions', function (Blueprint $table) {
            if (Schema::hasColumn('sessions', 'user_id')) {
                MigrationHelper::dropIndexIfNeeds($table, ['user_id']);
                $table->dropForeign(['user_id']);
                $table->dropColumn('user_id');
            }

            $table->foreignId('user_id')->nullable()->index();
        });

        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('created_at');
            $table->dropColumn('updated_at');

            $table->dropForeign(['created_by_id']);
            $table->dropForeign(['updated_by_id']);

            MigrationHelper::dropIndexIfNeeds($table, ['created_by_id']);
            MigrationHelper::dropIndexIfNeeds($table, ['updated_by_id']);
            
            $table->dropColumn('created_by_id');
            $table->dropColumn('updated_by_id');

            $table->dropColumn('is_2fa');
            $table->dropColumn('is_push_notification');
            $table->dropColumn('is_email_notification');
            $table->dropColumn('is_app_notification');
            $table->dropColumn('is_active');

            $table->dropPrimary(['id']);
            $table->dropColumn('id');

            $table->id();
            $table->timestamps();
        });
    }
};