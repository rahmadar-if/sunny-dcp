<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('right_operations', function (Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('right_levels', function (Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('right_operations');
        Schema::dropIfExists('right_levels');
    }
};