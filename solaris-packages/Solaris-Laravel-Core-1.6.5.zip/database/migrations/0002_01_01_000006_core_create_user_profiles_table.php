<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('user_profiles', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->foreignUuid('user_id')->constrained('users')->cascadeOnDelete();
            $table->string('name')->nullable();
            $table->string('email')->nullable();
            $table->foreignUuid('salutation_id')->nullable()->constrained('salutations')->nullOnDelete();
            $table->foreignUuid('gender_id')->nullable()->constrained('genders')->nullOnDelete();
            $table->foreignUuid('religion_id')->nullable()->constrained('religions')->nullOnDelete();
            $table->date('birthdate')->nullable();
            $table->string('birthplace')->nullable();
            $table->string('phone_number', 50)->nullable();
            $table->text('address')->nullable();
            $table->string('postcode', 10)->nullable();
            $table->string('timezone')->nullable();
            $table->foreignUuid('sub_district_id')->nullable()->constrained('sub_districts')->nullOnDelete();
            $table->foreignUuid('district_id')->nullable()->constrained('districts')->nullOnDelete();
            $table->foreignUuid('city_id')->nullable()->constrained('cities')->nullOnDelete();
            $table->foreignUuid('province_id')->nullable()->constrained('provincies')->nullOnDelete();
            $table->foreignUuid('country_id')->nullable()->constrained('countries')->nullOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['user_id']);
            MigrationHelper::createIndexIfNeeds($table, ['salutation_id']);
            MigrationHelper::createIndexIfNeeds($table, ['gender_id']);
            MigrationHelper::createIndexIfNeeds($table, ['religion_id']);
            MigrationHelper::createIndexIfNeeds($table, ['sub_district_id']);
            MigrationHelper::createIndexIfNeeds($table, ['district_id']);
            MigrationHelper::createIndexIfNeeds($table, ['city_id']);
            MigrationHelper::createIndexIfNeeds($table, ['province_id']);
            MigrationHelper::createIndexIfNeeds($table, ['country_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('user_profiles');
    }
};