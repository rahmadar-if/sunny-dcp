<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ai_agents', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('slug')->unique();
            $table->string('class');
            $table->string('name');
            $table->text('description')->nullable();
            $table->boolean('is_default')->default(false);
        });

        Schema::create('ai_tools', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('slug')->unique();
            $table->string('class');
            $table->string('name');
            $table->text('description')->nullable();
            $table->boolean('is_default')->default(false);
        });

        Schema::create('ai_agent_tools', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->foreignUuid('agent_id')->constrained('ai_agents')->cascadeOnDelete();
            $table->foreignUuid('tool_id')->constrained('ai_tools')->cascadeOnDelete();
            $table->boolean('is_locked')->default(false);

            $table->unique(['agent_id', 'tool_id']);

            MigrationHelper::createIndexIfNeeds($table, ['agent_id']);
            MigrationHelper::createIndexIfNeeds($table, ['tool_id']);
        });

        Schema::create('user_ai_agents', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->foreignUuid('user_id')->nullable()->constrained('users')->cascadeOnDelete();
            $table->foreignUuid('agent_id')->nullable()->constrained('ai_agents')->cascadeOnDelete();

            $table->unique(['user_id', 'agent_id']);

            MigrationHelper::createIndexIfNeeds($table, ['user_id']);
            MigrationHelper::createIndexIfNeeds($table, ['agent_id']);
        });

        Schema::create('role_ai_agents', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->foreignUuid('role_id')->nullable()->constrained('roles')->cascadeOnDelete();
            $table->foreignUuid('agent_id')->nullable()->constrained('ai_agents')->cascadeOnDelete();

            $table->unique(['role_id', 'agent_id']);

            MigrationHelper::createIndexIfNeeds($table, ['role_id']);
            MigrationHelper::createIndexIfNeeds($table, ['agent_id']);
        });

        Schema::create('permission_ai_agents', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->foreignUuid('permission_id')->nullable()->constrained('permissions')->cascadeOnDelete();
            $table->foreignUuid('agent_id')->nullable()->constrained('ai_agents')->cascadeOnDelete();

            $table->unique(['permission_id', 'agent_id']);

            MigrationHelper::createIndexIfNeeds($table, ['permission_id']);
            MigrationHelper::createIndexIfNeeds($table, ['agent_id']);
        });

        Schema::create('user_ai_tools', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->foreignUuid('user_id')->nullable()->constrained('users')->cascadeOnDelete();
            $table->foreignUuid('tool_id')->nullable()->constrained('ai_tools')->cascadeOnDelete();

            $table->unique(['user_id', 'tool_id']);

            MigrationHelper::createIndexIfNeeds($table, ['user_id']);
            MigrationHelper::createIndexIfNeeds($table, ['tool_id']);
        });

        Schema::create('role_ai_tools', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->foreignUuid('role_id')->nullable()->constrained('roles')->cascadeOnDelete();
            $table->foreignUuid('tool_id')->nullable()->constrained('ai_tools')->cascadeOnDelete();

            $table->unique(['role_id', 'tool_id']);

            MigrationHelper::createIndexIfNeeds($table, ['role_id']);
            MigrationHelper::createIndexIfNeeds($table, ['tool_id']);
        });

        Schema::create('permission_ai_tools', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->foreignUuid('permission_id')->nullable()->constrained('permissions')->cascadeOnDelete();
            $table->foreignUuid('tool_id')->nullable()->constrained('ai_tools')->cascadeOnDelete();

            $table->unique(['permission_id', 'tool_id']);

            MigrationHelper::createIndexIfNeeds($table, ['permission_id']);
            MigrationHelper::createIndexIfNeeds($table, ['tool_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('permission_ai_tools');
        Schema::dropIfExists('role_ai_tools');
        Schema::dropIfExists('user_ai_tools');
        Schema::dropIfExists('permission_ai_agents');
        Schema::dropIfExists('role_ai_agents');
        Schema::dropIfExists('user_ai_agents');
        Schema::dropIfExists('ai_agent_tools');
        Schema::dropIfExists('ai_tools');
        Schema::dropIfExists('ai_agents');
    }
};
