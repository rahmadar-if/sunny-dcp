<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
	public function up(): void
	{
		Schema::create('api_idempotency_keys', function (Blueprint $table) {
			MigrationHelper::baseTable($table);

			$table->foreignUuid('api_key_id')->nullable()->constrained('api_keys')->cascadeOnDelete();
			$table->string('key');
			$table->string('endpoint');

			// Distinguishes a genuine retry from a key reused for a different payload.
			$table->string('request_hash', 64);

			$table->unsignedSmallInteger('status');
			$table->json('response')->nullable();

			$table->unique(['api_key_id', 'key']);
			$table->index(['created_at']);
		});
	}

	public function down(): void
	{
		Schema::dropIfExists('api_idempotency_keys');
	}
};
