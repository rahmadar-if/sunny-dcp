<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
	public function up(): void
	{
		Schema::table('users', function (Blueprint $table) {
			$table->boolean('whatsapp_enabled')->default(false)->after('is_active');
		});

		Schema::table('wa_conversations', function (Blueprint $table) {
			$table->string('ai_conversation_id', 100)->nullable()->after('device_id');
			$table->timestamp('ai_last_active_at')->nullable()->after('ai_conversation_id');
		});
	}

	public function down(): void
	{
		Schema::table('users', function (Blueprint $table) {
			$table->dropColumn('whatsapp_enabled');
		});

		Schema::table('wa_conversations', function (Blueprint $table) {
			$table->dropColumn('ai_conversation_id');
			$table->dropColumn('ai_last_active_at');
		});
	}
};
