<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('user_profiles', function (Blueprint $table) {
            $table->foreignUuid('banner_id')->nullable()->constrained('attachments')->nullOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['banner_id']);
        });
    }

    public function down(): void
    {
        Schema::table('user_profiles', function (Blueprint $table) {
            $table->dropForeign(['banner_id']);

            if (config('database.default') == 'pgsql') {
                $table->dropIndex(['banner_id']);
            }

            $table->dropColumn('banner_id');
        });
    }
};
