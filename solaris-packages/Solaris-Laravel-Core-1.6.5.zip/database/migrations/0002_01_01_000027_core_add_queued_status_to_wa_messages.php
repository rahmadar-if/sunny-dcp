<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
	public function up(): void
	{
		$this->setStatusEnum(['queued', 'sent', 'delivered', 'read', 'played']);
	}

	public function down(): void
	{
		$this->setStatusEnum(['sent', 'delivered', 'read', 'played']);
	}

	// Native ->change() can't alter an enum-backed column on Postgres/SQL Server — both
	// grammars embed the CHECK constraint inline in the column type, which isn't valid
	// syntax inside ALTER COLUMN TYPE (only valid at column-creation time). Each driver
	// needs its own DDL to redefine the allowed values.
	private function setStatusEnum(array $allowed): void
	{
		$driver = Schema::getConnection()->getDriverName();

		if ($driver === 'mysql') {
			Schema::table('wa_messages', function (Blueprint $table) use ($allowed) {
				$table->enum('status', $allowed)->nullable()->change();
			});

			return;
		}

		if ($driver === 'pgsql') {
			$values = implode(',', array_map(fn ($v) => "'{$v}'", $allowed));

			DB::statement('ALTER TABLE wa_messages DROP CONSTRAINT IF EXISTS wa_messages_status_check');
			DB::statement("ALTER TABLE wa_messages ADD CONSTRAINT wa_messages_status_check CHECK (status IN ({$values}))");

			return;
		}

		if ($driver === 'sqlsrv') {
			$constraint = DB::selectOne(<<<'SQL'
				SELECT cc.name
				FROM sys.check_constraints cc
				JOIN sys.columns col ON col.object_id = cc.parent_object_id AND col.column_id = cc.parent_column_id
				WHERE cc.parent_object_id = OBJECT_ID('wa_messages') AND col.name = 'status'
			SQL);

			if ($constraint !== null) {
				DB::statement("ALTER TABLE wa_messages DROP CONSTRAINT [{$constraint->name}]");
			}

			$values = implode(',', array_map(fn ($v) => "'{$v}'", $allowed));
			DB::statement("ALTER TABLE wa_messages ADD CONSTRAINT wa_messages_status_check CHECK (status IN ({$values}))");
		}
	}
};
