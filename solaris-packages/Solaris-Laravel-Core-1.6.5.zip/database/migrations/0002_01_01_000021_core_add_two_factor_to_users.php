<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
	public function up(): void
	{
		Schema::table('users', function (Blueprint $table) {
			$table->dropColumn('is_2fa');

			$table->string('two_factor_method')->nullable();
			$table->text('two_factor_secret')->nullable();
			$table->text('two_factor_recovery_codes')->nullable();
			$table->timestamp('two_factor_confirmed_at')->nullable();
			$table->string('two_factor_otp')->nullable();
			$table->timestamp('two_factor_otp_expires_at')->nullable();
		});
	}

	public function down(): void
	{
		Schema::table('users', function (Blueprint $table) {
			$table->dropColumn([
				'two_factor_method',
				'two_factor_secret',
				'two_factor_recovery_codes',
				'two_factor_confirmed_at',
				'two_factor_otp',
				'two_factor_otp_expires_at',
			]);

			$table->boolean('is_2fa')->default(false);
		});
	}
};
