<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Const\WaMessageStatusConst;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
	public function up(): void
	{
		Schema::create('wa_message_statuses', function (Blueprint $table) {
			MigrationHelper::baseLookup($table);
		});

		DB::table('wa_message_statuses')->insertOrIgnore([
			['id' => WaMessageStatusConst::Queued,    'name' => 'Queued',    'position' => 1],
			['id' => WaMessageStatusConst::Sent,      'name' => 'Sent',      'position' => 2],
			['id' => WaMessageStatusConst::Delivered, 'name' => 'Delivered', 'position' => 3],
			['id' => WaMessageStatusConst::Read,      'name' => 'Read',      'position' => 4],
			['id' => WaMessageStatusConst::Played,    'name' => 'Played',    'position' => 5],
			['id' => WaMessageStatusConst::Failed,    'name' => 'Failed',    'position' => 6],
		]);

		Schema::table('wa_messages', function (Blueprint $table) {
			$table->foreignUuid('status_id')->nullable()->after('status')->constrained('wa_message_statuses')->nullOnDelete();
			$table->text('failure_reason')->nullable()->after('status_id');

			MigrationHelper::createIndexIfNeeds($table, ['status_id']);
		});

		foreach (WaMessageStatusConst::CODE_MAP as $code => $id) {
			DB::table('wa_messages')->where('status', $code)->update(['status_id' => $id]);
		}

		Schema::table('wa_messages', function (Blueprint $table) {
			$table->dropColumn('status');
		});
	}

	public function down(): void
	{
		Schema::table('wa_messages', function (Blueprint $table) {
			$table->enum('status', ['queued', 'sent', 'delivered', 'read', 'played'])->nullable()->after('type');
		});

		foreach (WaMessageStatusConst::CODE_MAP as $code => $id) {
			if ($code === 'failed') {
				continue;
			}

			DB::table('wa_messages')->where('status_id', $id)->update(['status' => $code]);
		}

		Schema::table('wa_messages', function (Blueprint $table) {
			$table->dropForeign(['status_id']);
			$table->dropColumn(['status_id', 'failure_reason']);
		});

		Schema::dropIfExists('wa_message_statuses');
	}
};
