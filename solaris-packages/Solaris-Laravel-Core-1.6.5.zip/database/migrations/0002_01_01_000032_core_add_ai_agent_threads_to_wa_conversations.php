<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
	public function up(): void
	{
		Schema::table('wa_conversations', function (Blueprint $table) {
			// {sub-agent-slug: agent_conversation_id} — each delegated specialist's own thread for this
			// chat. Orchestrator thread stays in the scalar ai_conversation_id; this holds the satellites.
			$table->json('ai_agent_threads')->nullable()->after('ai_last_active_at');
		});
	}

	public function down(): void
	{
		Schema::table('wa_conversations', function (Blueprint $table) {
			$table->dropColumn('ai_agent_threads');
		});
	}
};
