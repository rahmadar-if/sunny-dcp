<?php

namespace Solaris\Core\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Solaris\Core\Const\ChatStyleConst;
use Solaris\Core\Const\CurrencyConst;
use Solaris\Core\Const\GenderConst;
use Solaris\Core\Const\ReligionConst;
use Solaris\Core\Const\SalutationConst;
use Solaris\Core\Const\WaMessageStatusConst;
use Solaris\Core\Models\Country;

class LookupSeeder extends Seeder
{
    public function run(): void
    {
        $this->salutation();
        $this->gender();
        $this->religion();
        $this->chatStyles();
        $this->currency();
        $this->addressLookup();
        $this->waMessageStatus();
    }

    protected function salutation(): void
    {
        $data = [
            ['id' => SalutationConst::Mr,  'name' => 'Mr',  'position' => 1],
            ['id' => SalutationConst::Ms,  'name' => 'Ms',  'position' => 2],
            ['id' => SalutationConst::Dr,  'name' => 'Dr',  'position' => 3],
            ['id' => SalutationConst::Mrs, 'name' => 'Mrs', 'position' => 4],
        ];
        DB::table('salutations')->insertOrIgnore($data);
    }

    protected function gender(): void
    {
        $data = [
            ['id' => GenderConst::Male,   'name' => 'Male',   'position' => 1],
            ['id' => GenderConst::Female, 'name' => 'Female', 'position' => 2],
        ];
        DB::table('genders')->insertOrIgnore($data);
    }

    protected function religion(): void
    {
        $data = [
            ['id' => ReligionConst::Islam,     'name' => 'Islam',     'position' => 1],
            ['id' => ReligionConst::Protestan, 'name' => 'Protestan', 'position' => 2],
            ['id' => ReligionConst::Katolik,   'name' => 'Katolik',   'position' => 3],
            ['id' => ReligionConst::Hindu,     'name' => 'Hindu',     'position' => 4],
            ['id' => ReligionConst::Buddha,    'name' => 'Buddha',    'position' => 5],
            ['id' => ReligionConst::Khonghucu, 'name' => 'Khonghucu', 'position' => 6],
        ];
        DB::table('religions')->insertOrIgnore($data);
    }

    protected function chatStyles(): void
    {
        $data = [
            [
                'id'          => ChatStyleConst::Casual,
                'name'        => 'Casual',
                'position'    => 1,
                'description' => 'Casual and warm, like chatting with a close friend your own age — '
                    . 'tongkrongan style, everyday relaxed wording and contractions where natural; light '
                    . 'informality is fine. Refer to yourself as "aku" or "gw", never "saya" — "saya" reads '
                    . 'too formal for this style (reserve it for Friendly/Professional). Prefer simple, warm '
                    . 'phrasing over formal vocabulary. Stay respectful — casual is not careless or rude.',
            ],
            [
                'id'          => ChatStyleConst::Friendly,
                'name'        => 'Friendly',
                'position'    => 2,
                'description' => 'Friendly, professional, concise — approachable but still polished. '
                    . 'Balanced tone: warm without being overly casual, professional without being '
                    . 'stiff. This is the default style.',
            ],
            [
                'id'          => ChatStyleConst::Professional,
                'name'        => 'Professional',
                'position'    => 3,
                'description' => 'Formal and professional throughout. Avoid slang, casual '
                    . 'abbreviations, or overly relaxed phrasing. Use polished, respectful sentence '
                    . 'structure and precise vocabulary. Maintain a businesslike, courteous register '
                    . 'in every reply.',
            ],
        ];
        DB::table('chat_styles')->insertOrIgnore($data);
    }

    protected function currency(): void
    {
        $data = [
            ['id' => CurrencyConst::Rupiah,           'name' => 'Rupiah',           'code' => 'IDR', 'symbol' => 'Rp',  'position' => 1],
            ['id' => CurrencyConst::USDollar,         'name' => 'US Dollar',        'code' => 'USD', 'symbol' => '$',   'position' => 2],
            ['id' => CurrencyConst::Euro,             'name' => 'EURO',             'code' => 'EUR', 'symbol' => '€',   'position' => 3],
            ['id' => CurrencyConst::PoundSterling,    'name' => 'Pound Sterling',   'code' => 'GBP', 'symbol' => '£',   'position' => 4],
            ['id' => CurrencyConst::Yen,              'name' => 'Yen',              'code' => 'JPY', 'symbol' => '¥',   'position' => 4],
            ['id' => CurrencyConst::YuanRenminbi,     'name' => 'Yuan Renminbi',    'code' => 'CNY', 'symbol' => 'CN¥', 'position' => 5],
            ['id' => CurrencyConst::Won,              'name' => 'Won',              'code' => 'KRW', 'symbol' => '₩',   'position' => 7],
            ['id' => CurrencyConst::SingaporeDollar,  'name' => 'Singapore Dollar', 'code' => 'SGD', 'symbol' => 'S$',  'position' => 8],
            ['id' => CurrencyConst::MalaysianRinggit, 'name' => 'Malaysian Ringgit','code' => 'MYR', 'symbol' => 'RM',  'position' => 9],
            ['id' => CurrencyConst::Baht,             'name' => 'Baht',             'code' => 'THB', 'symbol' => '฿',   'position' => 10],
            ['id' => CurrencyConst::Dong,             'name' => 'Dong',             'code' => 'VND', 'symbol' => '₫',   'position' => 11],
            ['id' => CurrencyConst::PhilippinePeso,   'name' => 'Philippine Peso',  'code' => 'PHP', 'symbol' => '₱',   'position' => 12],
            ['id' => CurrencyConst::Kyat,             'name' => 'Kyat',             'code' => 'MMK', 'symbol' => 'K',   'position' => 13],
            ['id' => CurrencyConst::Riel,             'name' => 'Riel',             'code' => 'KHR', 'symbol' => '៛',   'position' => 14],
            ['id' => CurrencyConst::Kip,              'name' => 'Kip',              'code' => 'LAK', 'symbol' => '₭',   'position' => 15],
            ['id' => CurrencyConst::IndianRupee,      'name' => 'Indian Rupee',     'code' => 'INR', 'symbol' => '₹',   'position' => 16],
        ];
        DB::table('currencies')->insertOrIgnore($data);
    }

    protected function waMessageStatus(): void
    {
        $data = [
            ['id' => WaMessageStatusConst::Queued,    'name' => 'Queued',    'position' => 1],
            ['id' => WaMessageStatusConst::Sent,      'name' => 'Sent',      'position' => 2],
            ['id' => WaMessageStatusConst::Delivered, 'name' => 'Delivered', 'position' => 3],
            ['id' => WaMessageStatusConst::Read,      'name' => 'Read',      'position' => 4],
            ['id' => WaMessageStatusConst::Played,    'name' => 'Played',    'position' => 5],
            ['id' => WaMessageStatusConst::Failed,    'name' => 'Failed',    'position' => 6],
        ];
        DB::table('wa_message_statuses')->insertOrIgnore($data);
    }

    protected function addressLookup(): void
    {
        DB::transaction(function () {
            $country   = Country::create(['name' => 'Indonesia', 'position' => 1]);
            $countryId = $country->id;

            $provinceMap = $this->province($countryId);
            $this->postalCode($countryId, $provinceMap);
        });
    }

    private function province(string $countryId): array
    {
        $url = __DIR__.'/provinces_id_as_key_indonesia.json';
        $res = json_decode(file_get_contents($url), true);

        $i    = 1;
        $data = [];
        $map  = [];

        foreach ($res as $code => $name) {
            $id              = (string) Str::uuid7();
            $map[(string) $code] = $id;

            $data[] = [
                'id'         => $id,
                'name'       => Str::title($name),
                'country_id' => $countryId,
                'code'       => (string) $code,
                'position'   => $i++,
            ];
        }

        DB::table('provincies')->insertOrIgnore($data);

        return $map;
    }

    private function postalCode(string $countryId, array $provinceMap): void
    {
        $url = __DIR__.'/postal_province_code_as_key.json';
        $res = json_decode(file_get_contents($url), true);

        foreach ($res as $provCode => $value) {
            $provId = $provinceMap[(string) $provCode];
            $data   = collect($value);

            $cities  = $data->map(fn ($item) => $item['city'])->unique()->values()->all();
            $cityMap = $this->city($countryId, $provId, $cities);

            foreach ($cities as $city) {
                $cityId    = $cityMap[$city];
                $districts = $data->where('city', $city)
                    ->map(fn ($item) => $item['sub_district'])
                    ->unique()
                    ->values()
                    ->all();

                $districtMap = $this->district($countryId, $provId, $cityId, $districts);

                foreach ($districts as $district) {
                    $districtId   = $districtMap[$district];
                    $subDistricts = $data->where('city', $city)
                        ->where('sub_district', $district)
                        ->values()
                        ->all();

                    $this->subDistrict($countryId, $provId, $cityId, $districtId, $subDistricts);
                }
            }
        }
    }

    private function city(string $countryId, string $provId, array $cities): array
    {
        $i    = 1;
        $data = [];
        $map  = [];

        foreach ($cities as $value) {
            $id        = (string) Str::uuid7();
            $map[$value] = $id;

            $data[] = [
                'id'          => $id,
                'name'        => Str::title($value),
                'province_id' => $provId,
                'country_id'  => $countryId,
                'position'    => $i++,
            ];

            if (count($data) === 200) {
                DB::table('cities')->insertOrIgnore($data);
                $data = [];
            }
        }

        if ($data) {
            DB::table('cities')->insertOrIgnore($data);
        }

        return $map;
    }

    private function district(string $countryId, string $provId, string $cityId, array $districts): array
    {
        $i    = 1;
        $data = [];
        $map  = [];

        foreach ($districts as $value) {
            $id        = (string) Str::uuid7();
            $map[$value] = $id;

            $data[] = [
                'id'          => $id,
                'name'        => Str::title($value),
                'city_id'     => $cityId,
                'province_id' => $provId,
                'country_id'  => $countryId,
                'position'    => $i++,
            ];

            if (count($data) === 200) {
                DB::table('districts')->insertOrIgnore($data);
                $data = [];
            }
        }

        if ($data) {
            DB::table('districts')->insertOrIgnore($data);
        }

        return $map;
    }

    private function subDistrict(string $countryId, string $provId, string $cityId, string $districtId, array $subDistricts): void
    {
        $i    = 1;
        $data = [];

        foreach ($subDistricts as $value) {
            $data[] = [
                'id'          => (string) Str::uuid7(),
                'name'        => Str::title($value['urban']),
                'district_id' => $districtId,
                'city_id'     => $cityId,
                'province_id' => $provId,
                'country_id'  => $countryId,
                'postcode'    => $value['postal_code'],
                'position'    => $i++,
            ];

            if (count($data) === 500) {
                DB::table('sub_districts')->insertOrIgnore($data);
                $data = [];
            }
        }

        if ($data) {
            DB::table('sub_districts')->insertOrIgnore($data);
        }
    }
}
