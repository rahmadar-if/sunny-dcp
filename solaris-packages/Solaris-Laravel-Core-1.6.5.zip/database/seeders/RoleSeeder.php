<?php

namespace Solaris\Core\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Solaris\Core\Const\RoleConst;

class RoleSeeder extends Seeder
{
    public function run(): void
    {
        $this->roles();
    }

    protected function roles(): void
    {
        $data = [
            [
                'id'         => RoleConst::User,
                'name'       => 'User',
                'group_name' => 'user',
            ],
            [
                'id'         => RoleConst::Admin,
                'name'       => 'Admin',
                'group_name' => 'user',
            ]
        ];

        foreach ($data as $role) {
            DB::table('roles')->updateOrInsert(['id' => $role['id']], $role);
        }
    }
}