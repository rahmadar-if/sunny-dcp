<?php

namespace Solaris\Core\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Solaris\Core\Const\PermissionTypeConst;
use Solaris\Core\Const\RightLevelConst;
use Solaris\Core\Const\RightOperationConst;

class ObjectPermissionSeeder extends Seeder
{
    public function run(): void
    {
        $this->right_operations();
        $this->right_levels();
        $this->permission_type();
    }

    protected function right_operations(): void
    {
        $data = [
            [
                'id'       => RightOperationConst::Create,
                'name'     => 'Create',
                'position' => 1,
            ],
            [
                'id'       => RightOperationConst::Read,
                'name'     => 'Read',
                'position' => 2,
            ],
            [
                'id'       => RightOperationConst::Update,
                'name'     => 'Update',
                'position' => 3,
            ],
            [
                'id'       => RightOperationConst::Delete,
                'name'     => 'Delete',
                'position' => 4,
            ],
        ];
        DB::table('right_operations')->insertOrIgnore($data);
    }

    protected function right_levels(): void
    {
        $data = [
            [
                'id'       => RightLevelConst::Grant,
                'name'     => 'Grant',
                'position' => 1,
            ],
            [
                'id'       => RightLevelConst::GrantDelegate,
                'name'     => 'Grant & Delegate',
                'position' => 2,
            ],
            [
                'id'       => RightLevelConst::Deny,
                'name'     => 'Deny',
                'position' => 3,
            ],
        ];
        DB::table('right_levels')->insertOrIgnore($data);
    }

    protected function permission_type(): void
    {
        $data = [
            [
                'id'       => PermissionTypeConst::User,
                'name'     => 'User',
                'position' => 1,
            ],
            [
                'id'       => PermissionTypeConst::Role,
                'name'     => 'Role',
                'position' => 2,
            ],
            [
                'id'       => PermissionTypeConst::Permission,
                'name'     => 'Permission',
                'position' => 3,
            ],
        ];
        DB::table('permission_type')->insertOrIgnore($data);
    }
}