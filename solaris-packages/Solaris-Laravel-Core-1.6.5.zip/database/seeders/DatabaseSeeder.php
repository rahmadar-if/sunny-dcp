<?php

namespace Solaris\Core\Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            RoleSeeder::class,
            IntegrationSeeder::class,
            LookupSeeder::class,
            ObjectPermissionSeeder::class,
            MenuSeeder::class,
            ApprovalSeeder::class,
            WhatsAppMenuSeeder::class,
            AdminDashboardMenuSeeder::class,
            AiRegistrySeeder::class
        ]);
    }
}