<?php

namespace Solaris\Core\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Solaris\Core\Models\Menu;

class WhatsAppMenuSeeder extends Seeder
{
    public function run(): void
    {
        $adminId = Menu::where('name', 'Admin')
            ->where(fn($m) => $m->where('url', '')->where('route_name', ''))
            ->whereHas('category', fn($m) => $m->where('name', 'Admin'))
            ->first()?->id;

        $whatsAppId = "019ef2ab-d36c-7b42-9c1a-f0853c25b5b5";
        $data = [
            [
                "id"          => $whatsAppId,
                'name'        => 'WhatsApp',
                'position'    => 5,
                'url'         => '/admin/whatsapp',
                'route_name'  => 'admin.whatsapp',
                'icon'        => null,
                'is_category' => false,
                'parent_id'   => $adminId,
                'category_id' => null,
            ]
        ];

        DB::table('menus')->insertOrIgnore($data);

        $menu = Menu::find($whatsAppId);
        $menu->assignRole('Admin');
    }
}
