<?php

namespace Solaris\Core\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Artisan;
use Solaris\Core\Models\AiAgent;
use Solaris\Core\Models\AiTool;
use Solaris\Core\Models\Permission;

class AiRegistrySeeder extends Seeder
{
    protected array $wiring = [
        'whatsapp' => [
            'upload_attachment', 'list_attachment_targets', 'extract_images',
            'get_current_datetime', 'lookup_options', 'lookup_region',
            'profile_specialist',
        ],
        'profile' => [
            'lookup_options', 'lookup_region',
        ],
    ];

    protected array $permissions = [
        'AI Tool Extract Images' => [
            'id'          => '019fa686-679a-7245-92f2-95c419050c05',
            'description' => 'Read images and extract structured data via AI (image extraction).',
            'tools'       => ['extract_images'],
            'agents'      => ['image_extraction'],
        ],
        'AI Read Voice Messages' => [
            'id'          => '019fe9cb-47d4-7354-8c43-1df3cd491428',
            'description' => 'Transcribe incoming WhatsApp voice messages via AI (audio extraction).',
            'tools'       => [],
            'agents'      => ['audio_extraction'],
        ],
        'AI Tool Attachment' => [
            'id'          => '019fa686-679a-720f-ac5c-36f94faf9b97',
            'description' => 'Send attachments and list attachment targets via AI.',
            'tools'       => ['upload_attachment', 'list_attachment_targets'],
            'agents'      => [],
        ],
    ];

    public function run(): void
    {
        Artisan::call('solaris:ai-sync');
        $this->wiring();
        $this->permissions();
    }

    protected function wiring(): void
    {
        foreach ($this->wiring as $agentSlug => $toolSlugs) {
            $agent = AiAgent::where('slug', $agentSlug)->first();

            if ($agent === null) {
                continue;
            }

            $agent->attachTools(AiTool::whereIn('slug', $toolSlugs)->pluck('id')->all());
        }
    }

    protected function permissions(): void
    {
        foreach ($this->permissions as $name => $permission) {
            Permission::firstOrCreate(['id' => $permission['id']], [
                'name'        => $name,
                'description' => $permission['description'],
            ]);

            AiTool::whereIn('slug', $permission['tools'])->get()
                ->each(fn (AiTool $tool) => $tool->assignPermission([$permission['id']]));

            AiAgent::whereIn('slug', $permission['agents'])->get()
                ->each(fn (AiAgent $agent) => $agent->assignPermission([$permission['id']]));
        }
    }
}
