<?php

namespace Solaris\Core\Database\Seeders;

use Carbon\Carbon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Solaris\Core\Const\RoleConst;
use Solaris\Core\Helpers\Helper;

class IntegrationSeeder extends Seeder
{
    protected const EMAIL = 'integration@solaris.local';

    public function run(): void
    {
        $this->role();
        $this->user();
    }

    protected function role(): void
    {
        DB::table('roles')->updateOrInsert(
            ['id' => RoleConst::Integration],
            ['name' => 'Integration', 'group_name' => 'integration']
        );
    }

    protected function user(): void
    {
        $userModel = Helper::model('user');

        // Keyed on email, not a fixed id — integration users get a random uuid7 like anyone else
        if ($userModel::where('email', self::EMAIL)->exists()) {
            return;
        }

        $repo = new (Helper::repository('user'))(new $userModel);

        // password is omitted on purpose: UserRepository::creating() fills it with a random
        // one. It is never used — is_integration is what keeps this account out of web/mobile.
        $user = $repo->create([
            'name'              => 'Integration',
            'email'             => self::EMAIL,
            'username'          => null,
            'email_verified_at' => Carbon::now(),
            'is_active'         => true,
            'is_integration'    => true,
            'is_mobile_access'  => false,
        ]);

        $user->assignRole(RoleConst::Integration);
    }
}
