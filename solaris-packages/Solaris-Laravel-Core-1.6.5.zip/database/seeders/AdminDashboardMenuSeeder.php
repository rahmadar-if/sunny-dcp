<?php

namespace Solaris\Core\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Solaris\Core\Models\Menu;

class AdminDashboardMenuSeeder extends Seeder
{
    public function run(): void
    {
        $adminId = Menu::where('name', 'Admin')
            ->where(fn($m) => $m->where('url', '')->where('route_name', ''))
            ->whereHas('category', fn($m) => $m->where('name', 'Admin'))
            ->first()?->id;

        $dashboardId = "019c1d8e-f7c6-7bde-9c4a-2f6a8e1d3b57";
        $data = [
            [
                "id"          => $dashboardId,
                'name'        => 'Dashboard',
                'position'    => 0,
                'url'         => '/admin/dashboard',
                'route_name'  => 'admin.dashboard',
                'icon'        => null,
                'is_category' => false,
                'parent_id'   => $adminId,
                'category_id' => null,
            ]
        ];

        DB::table('menus')->insertOrIgnore($data);

        $menu = Menu::find($dashboardId);
        $menu->assignRole('Admin');
    }
}
