<?php

namespace Solaris\Core\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Solaris\Core\Models\Menu;

class MenuSeeder extends Seeder
{
    public function run(): void
    {
        $this->admin();
    }

    protected function admin(): void
    {
        $categoryId = '019c1d8e-f7c6-79aa-a775-593b2f6c0129';
        $adminId = '019c1d8e-f7c6-7a6d-b226-4807b905c66d';
        $userId = '019c1d8e-f7c6-77ce-9621-eb20b56b37a6';

        $data = [
            [
                'id' => $categoryId,
                'name' => 'Admin',
                'position' => 0,
                'url' => null,
                'route_name' => null,
                'icon' => null,
                'is_category' => true,
                'parent_id' => null,
                'category_id' => null,
            ],
            [
                'id' => $adminId,
                'name' => 'Admin',
                'position' => 1,
                'url' => '',
                'route_name' => '',
                'icon' => 'bx bx-cog',
                'is_category' => false,
                'parent_id' => null,
                'category_id' => $categoryId,
            ],
            [
                'id' => $userId,
                'name' => 'Users',
                'position' => 1,
                'url' => '',
                'route_name' => '',
                'icon' => null,
                'is_category' => false,
                'parent_id' => $adminId,
                'category_id' => null,
            ],
            [
                'id' => '019c1d8e-f7c6-76bf-8957-c29e2d060092',
                'name' => 'User',
                'position' => 1,
                'url' => '/admin/user',
                'route_name' => 'admin.user',
                'icon' => null,
                'is_category' => false,
                'parent_id' => $userId,
                'category_id' => null,
            ],
            [
                'id' => '019c1d8e-f7c6-7760-a31f-c9420b0f9e34',
                'name' => 'Role',
                'position' => 2,
                'url' => '/admin/role',
                'route_name' => 'admin.role',
                'icon' => null,
                'is_category' => false,
                'parent_id' => $userId,
                'category_id' => null,
            ],
            [
                'id' => '019c1d8e-f7c6-7dc4-9354-070e25739040',
                'name' => 'Permission',
                'position' => 3,
                'url' => '/admin/permission',
                'route_name' => 'admin.permission',
                'icon' => null,
                'is_category' => false,
                'parent_id' => $userId,
                'category_id' => null,
            ],
            [
                'id' => '019ac821-1851-7468-be80-817d19a8d66a',
                'name' => 'Access Right',
                'position' => 2,
                'url' => '/admin/access-right',
                'route_name' => 'admin.access-right',
                'icon' => null,
                'is_category' => false,
                'parent_id' => $adminId,
                'category_id' => null,
            ],
            [
                'id' => '019c1d8e-f7c6-7a64-8a1f-417cfcf8f0fe',
                'name' => 'Lookup',
                'position' => 3,
                'url' => '/admin/lookup',
                'route_name' => 'admin.lookup',
                'icon' => null,
                'is_category' => false,
                'parent_id' => $adminId,
                'category_id' => null,
            ],
            [
                'id' => '019c1d8e-f7c6-727a-ae5d-59f66130eb3c',
                'name' => 'Menu',
                'position' => 4,
                'url' => '/admin/menu',
                'route_name' => 'admin.menu',
                'icon' => null,
                'is_category' => false,
                'parent_id' => $adminId,
                'category_id' => null,
            ],
            [
                'id' => '019c1d8e-f7c6-7aaa-888b-b46b2a30c4e9',
                'name' => 'Code Generator',
                'position' => 4,
                'url' => '/admin/code-generator',
                'route_name' => 'admin.code-generator',
                'icon' => null,
                'is_category' => false,
                'parent_id' => $adminId,
                'category_id' => null,
            ],
        ];

        DB::table('menus')->insertOrIgnore($data);

        $menuAccess = Menu::whereIn('id',
            array_map(
                fn ($item) => $item['id'],
                array_filter($data, fn ($item) => ! $item['is_category'] && ! empty($item['url']))
            )
        )
            ->get();

        foreach ($menuAccess as $menu) {
            $menu->assignRole('Admin');
        }
    }
}
