<?php

namespace Solaris\Core\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Solaris\Core\Const\ApprovalAssignmentStatusConst;
use Solaris\Core\Const\ApprovalLevelStatusConst;
use Solaris\Core\Const\ApprovalRequestStatusConst;

class ApprovalSeeder extends Seeder
{
	public function run(): void
	{
		$this->requestStatuses();
		$this->levelStatuses();
		$this->assignmentStatuses();
	}

	protected function requestStatuses(): void
	{
		$data = [
			[
				'id'       => ApprovalRequestStatusConst::Pending,
				'name'     => 'Pending',
				'position' => 1,
			],
			[
				'id'       => ApprovalRequestStatusConst::InProgress,
				'name'     => 'In Progress',
				'position' => 2,
			],
			[
				'id'       => ApprovalRequestStatusConst::Approved,
				'name'     => 'Approved',
				'position' => 3,
			],
			[
				'id'       => ApprovalRequestStatusConst::Rejected,
				'name'     => 'Rejected',
				'position' => 4,
			],
			[
				'id'       => ApprovalRequestStatusConst::Cancelled,
				'name'     => 'Cancelled',
				'position' => 5,
			],
			[
				'id'       => ApprovalRequestStatusConst::Expired,
				'name'     => 'Expired',
				'position' => 6,
			],
		];
		DB::table('approval_request_statuses')->insertOrIgnore($data);
	}

	protected function levelStatuses(): void
	{
		$data = [
			[
				'id'       => ApprovalLevelStatusConst::Pending,
				'name'     => 'Pending',
				'position' => 1,
			],
			[
				'id'       => ApprovalLevelStatusConst::InProgress,
				'name'     => 'In Progress',
				'position' => 2,
			],
			[
				'id'       => ApprovalLevelStatusConst::Approved,
				'name'     => 'Approved',
				'position' => 3,
			],
			[
				'id'       => ApprovalLevelStatusConst::Rejected,
				'name'     => 'Rejected',
				'position' => 4,
			],
			[
				'id'       => ApprovalLevelStatusConst::Skipped,
				'name'     => 'Skipped',
				'position' => 5,
			],
		];
		DB::table('approval_level_statuses')->insertOrIgnore($data);
	}

	protected function assignmentStatuses(): void
	{
		$data = [
			[
				'id'       => ApprovalAssignmentStatusConst::Pending,
				'name'     => 'Pending',
				'position' => 1,
			],
			[
				'id'       => ApprovalAssignmentStatusConst::Approved,
				'name'     => 'Approved',
				'position' => 2,
			],
			[
				'id'       => ApprovalAssignmentStatusConst::Rejected,
				'name'     => 'Rejected',
				'position' => 3,
			],
			[
				'id'       => ApprovalAssignmentStatusConst::Dismissed,
				'name'     => 'Dismissed',
				'position' => 4,
			],
		];
		DB::table('approval_assignment_statuses')->insertOrIgnore($data);
	}
}