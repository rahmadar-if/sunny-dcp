<?php

// config for Solaris/Market
return [

    /*
    |--------------------------------------------------------------------------
    | Resources
    |--------------------------------------------------------------------------
    */
    'resource' => [
        'path' => [
            'marketing' => 'vendor/solaris/solaris-laravel-marketing/resources',
        ],
        'views' => [
            'contact' => [
                'page' => 'marketing::pages.contact.page',
            ],
            'activity' => [
                'page' => 'marketing::pages.activity.page',
            ],
            'event' => [
                'list' => 'marketing::pages.event.list',
                'page' => 'marketing::pages.event.page',
            ],
            'email_blast' => [
                'list'    => 'marketing::pages.email-blast.list',
                'page'    => 'marketing::pages.email-blast.page',
                'editor'  => 'marketing::pages.email-blast.editor',
                'preview' => 'marketing::pages.email-blast.editor-preview',
            ],
            'email_template' => [
                'list' => 'marketing::pages.email-template.list',
                'page' => 'marketing::pages.email-template.page',
            ],
            'wa_blast' => [
                'list' => 'marketing::pages.wa-blast.list',
                'page' => 'marketing::pages.wa-blast.page',
            ],
            'wa_template' => [
                'list' => 'marketing::pages.wa-template.list',
                'page' => 'marketing::pages.wa-template.page',
            ],
            'wa_template_detail' => [
                'page' => 'marketing::pages.wa-template.detail.page',
            ],
            'marketing_dashboard' => 'core::errors.coming-soon',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Models
    |--------------------------------------------------------------------------
    */
    'model' => [
        'namespaces' => [
            'Solaris\\Marketing\\Models' => base_path('vendor/solaris/solaris-laravel-marketing/src/Models'),
        ],
        'models' => [
            'activity' => 'Solaris\\Marketing\\Models\\Activity',
            'contact'  => 'Solaris\\Marketing\\Models\\Contact',

            'event'               => 'Solaris\\Marketing\\Models\\Event',
            'event_status'        => 'Solaris\\Marketing\\Models\\EventStatus',
            'event_stage'         => 'Solaris\\Marketing\\Models\\EventStage',
            'event_type'          => 'Solaris\\Marketing\\Models\\EventType',
            'event_audience'      => 'Solaris\\Marketing\\Models\\EventAudience',
            'event_stage_history' => 'Solaris\\Marketing\\Models\\EventStageHistory',

            'campaign_blast_status'    => 'Solaris\\Marketing\\Models\\CampaignBlastStatus',
            'campaign_blast_quota'     => 'Solaris\\Marketing\\Models\\CampaignBlastQuota',
            'campaign_blast_quota_log' => 'Solaris\\Marketing\\Models\\CampaignBlastQuotaLog',

            'email_blast'                 => 'Solaris\\Marketing\\Models\\EmailBlast',
            'email_blast_audience'        => 'Solaris\\Marketing\\Models\\EmailBlastAudience',
            'email_blast_status_history'  => 'Solaris\\Marketing\\Models\\EmailBlastStatusHistory',
            'email_blast_audience_status' => 'Solaris\\Marketing\\Models\\EmailBlastAudienceStatus',

            'email_template' => 'Solaris\\Marketing\\Models\\EmailTemplate',

            'wa_blast'                 => 'Solaris\\Marketing\\Models\\WaBlast',
            'wa_blast_audience'        => 'Solaris\\Marketing\\Models\\WaBlastAudience',
            'wa_blast_status_history'  => 'Solaris\\Marketing\\Models\\WaBlastStatusHistory',
            'wa_blast_audience_status' => 'Solaris\\Marketing\\Models\\WaBlastAudienceStatus',

            'wa_template'             => 'Solaris\\Marketing\\Models\\WaTemplate',
            'wa_template_category'    => 'Solaris\\Marketing\\Models\\WaTemplateCategory',
            'wa_template_language'    => 'Solaris\\Marketing\\Models\\WaTemplateLanguage',
            'wa_template_sub_type'    => 'Solaris\\Marketing\\Models\\WaTemplateSubType',
            'wa_template_status'      => 'Solaris\\Marketing\\Models\\WaTemplateStatus',
            'wa_template_header_type' => 'Solaris\\Marketing\\Models\\WaTemplateHeaderType',
            'wa_template_detail'      => 'Solaris\\Marketing\\Models\\WaTemplateDetail',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Repositories
    |--------------------------------------------------------------------------
    */
    'repositories' => [
        'event'          => 'Solaris\\Marketing\\Repositories\\EventRepository',
        'event_audience' => 'Solaris\\Core\\Repositories\\BaseRepository',

        'email_blast'          => 'Solaris\\Marketing\\Repositories\\EmailBlastRepository',
        'email_blast_audience' => 'Solaris\\Marketing\\Repositories\\EmailBlastAudienceRepository',

        'email_template' => 'Solaris\\Core\\Repositories\\BaseRepository',

        'wa_blast'          => 'Solaris\\Marketing\\Repositories\\WaBlastRepository',
        'wa_blast_audience' => 'Solaris\\Marketing\\Repositories\\WaBlastAudienceRepository',

        'wa_template'        => 'Solaris\\Marketing\\Repositories\\WaTemplateRepository',
        'wa_template_detail' => 'Solaris\\Marketing\\Repositories\\WaTemplateDetailRepository',
    ],

    /*
    |--------------------------------------------------------------------------
    | HTTP Layer
    |--------------------------------------------------------------------------
    */
    'controller' => [
        'namespaces' => [
            'Solaris\\Marketing\\Http\\Controllers',
        ],
        'controllers' => [
            'activity'       => 'Solaris\\Marketing\\Http\\Controllers\\ActivityController',
            'event'          => 'Solaris\\Marketing\\Http\\Controllers\\EventController',
            'event_audience' => 'Solaris\\Marketing\\Http\\Controllers\\EventAudienceController',

            'email_blast'          => 'Solaris\\Marketing\\Http\\Controllers\\EmailBlastController',
            'email_blast_audience' => 'Solaris\\Marketing\\Http\\Controllers\\EmailBlastAudienceController',

            'email_template' => 'Solaris\\Marketing\\Http\\Controllers\\EmailTemplateController',

            'wa_blast'          => 'Solaris\\Marketing\\Http\\Controllers\\WaBlastController',
            'wa_blast_audience' => 'Solaris\\Marketing\\Http\\Controllers\\WaBlastAudienceController',

            'wa_template'        => 'Solaris\\Marketing\\Http\\Controllers\\WaTemplateController',
            'wa_template_detail' => 'Solaris\\Marketing\\Http\\Controllers\\WaTemplateDetailController',

            'marketing_dashboard' => 'Solaris\\Marketing\\Http\\Controllers\\MarketingDashboardController',

            'stripo_plugin' => 'Solaris\\Marketing\\Http\\Controllers\\StripoPluginController',
        ],
    ],

    'form_requests' => [
        'activity'            => 'Solaris\\Marketing\\Http\\Requests\\ActivityRequest',
        'event'               => 'Solaris\\Marketing\\Http\\Requests\\EventRequest',
        'email_blast'         => 'Solaris\\Marketing\\Http\\Requests\\EmailBlastRequest',
        'email_template'      => 'Solaris\\Marketing\\Http\\Requests\\EmailTemplateRequest',
        'wa_blast'            => 'Solaris\\Marketing\\Http\\Requests\\WaBlastRequest',
        'wa_template'         => 'Solaris\\Marketing\\Http\\Requests\\WaTemplateRequest',
        'wa_template_detail'  => 'Solaris\\Marketing\\Http\\Requests\\WaTemplateDetailRequest',
    ],

    /*
    |--------------------------------------------------------------------------
    | Email Blast
    |--------------------------------------------------------------------------
    */
    'email_blast' => [
        'default'       => env('EMAIL_BLAST_PROVIDER', 'mailgun'),
        'daily_limit'   => env('EMAIL_BLAST_DAILY_LIMIT', 3),
        'safety_buffer' => env('EMAIL_BLAST_SAFETY_BUFFER', 3),

        // Cooldown between test emails, counted per place the test button lives.
        'test_cooldown_seconds' => env('EMAIL_BLAST_TEST_COOLDOWN', 30),
        'webhook_buffer' => [
            'debounce'      => env('EMAIL_BLAST_WEBHOOK_DEBOUNCE', 5),
            'max_batch'     => env('EMAIL_BLAST_WEBHOOK_MAX_BATCH', 1000),
            'recover_after' => env('EMAIL_BLAST_WEBHOOK_RECOVER_AFTER', 300),
        ],
        'providers' => [
            'mailgun' => [
                'driver'               => \Solaris\Marketing\Services\Email\Mailgun\MailgunProvider::class,
                'domain'               => env('MAILGUN_DOMAIN'),
                'secret'               => env('MAILGUN_SECRET'),
                'endpoint'             => env('MAILGUN_ENDPOINT', 'https://api.mailgun.net/v3'),
                'chunk_size'           => env('EMAIL_BLAST_CHUNK', 100),
                'rate_limit'           => env('EMAIL_BLAST_RATE_LIMIT', 10),
                'webhook_key'          => env('MAILGUN_WEBHOOK_KEY'),
                'webhook_success_code' => env('MAILGUN_WEBHOOK_SUCCESS_CODE', 200),
                'webhook_fail_code'    => env('MAILGUN_WEBHOOK_FAIL_CODE', 406),
            ],
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | WhatsApp Blast
    |--------------------------------------------------------------------------
    */
    'wa_blast' => [
        'default'       => env('WA_BLAST_PROVIDER', 'qiscus'),
        'daily_limit'   => env('WA_BLAST_DAILY_LIMIT', 3),
        'safety_buffer' => env('WA_BLAST_SAFETY_BUFFER', 3),
        'webhook_buffer' => [
            'debounce'      => env('WA_BLAST_WEBHOOK_DEBOUNCE', 5),
            'max_batch'     => env('WA_BLAST_WEBHOOK_MAX_BATCH', 1000),
            'recover_after' => env('WA_BLAST_WEBHOOK_RECOVER_AFTER', 300),
        ],
        'providers' => [
            'qiscus' => [
                'driver'               => \Solaris\Marketing\Services\WhatsApp\Qiscus\QiscusProvider::class,
                'app_id'               => env('QISCUS_APP_ID'),
                'secret'               => env('QISCUS_SECRET'),
                'channel_id'           => env('QISCUS_CHANNEL_ID'),
                'endpoint'             => env('QISCUS_ENDPOINT', 'https://omnichannel.qiscus.com'),
                'chunk_size'           => env('WA_CHUNK', 100),
                'rate_limit'           => env('WA_RATE_LIMIT', 10),
                'webhook_key'          => env('QISCUS_SECRET'),
                'webhook_success_code' => env('QISCUS_WEBHOOK_SUCCESS_CODE', 200),
                'webhook_fail_code'    => env('QISCUS_WEBHOOK_FAIL_CODE', 406),
            ],
        ],
    ],

    'wa_template' => [
        'limits' => [
            'header_max_chars'         => 60,
            'footer_max_chars'         => 60,
            'body_max_chars'           => 1024,
            'body_max_params'          => 15,
            'button_total_max'         => 10,
            'button_url_max'           => 2,
            'button_phone_max'         => 1,
            'button_copy_code_max'     => 1,
            'button_label_max_chars'   => 25,
            'button_url_max_chars'     => 2000,
            'button_phone_max_chars'   => 20,
            'button_code_max_chars'    => 15,
            'carousel_button_max'      => 2,
            'carousel_min_cards'       => 2,
            'carousel_max_cards'       => 10,
            'carousel_body_max_chars'  => 160,
            'carousel_body_max_params' => 10,
            'carousel_label_max_chars' => 25,
            'carousel_url_max_chars'   => 2000,
            'auth_expiry_min'          => 1,
            'auth_expiry_max'          => 90,
        ],
        'media_constraints' => [
            'image'    => ['exts' => ['.jpg', '.jpeg', '.png'], 'max_mb' => 5],
            'video'    => ['exts' => ['.mp4', '.3gp'],          'max_mb' => 16],
            'document' => ['exts' => ['.pdf'],                  'max_mb' => 100],
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | HTTP Log
    |--------------------------------------------------------------------------
    */
    'http_log' => [
        // Merged into the core list by ConfigEditor, not replacing it.
        'sensitive_headers' => ['qiscus-secret-key', 'qiscus-app-id'],
    ],

    /*
    |--------------------------------------------------------------------------
    | Stripo Plugin
    |--------------------------------------------------------------------------
    */
    'stripo_plugin' => [
        'email_id'   => env('STRIPO_EMAIL_ID'),
        'plugin_id'  => env('STRIPO_PLUGIN_ID'),
        'secret_key' => env('STRIPO_SECRET_KEY'),
        'image_storage' => [
            'login'    => env('STRIPO_STORAGE_LOGIN', 'stripo'),
            'password' => env('STRIPO_STORAGE_PASSWORD'),
            'disk'     => env('STRIPO_STORAGE_DISK', 'public'),
            'path'     => env('STRIPO_STORAGE_PATH', 'stripo'),
        ],
    ],
];
