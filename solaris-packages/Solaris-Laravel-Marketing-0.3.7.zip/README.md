# 📣 Solaris Marketing

A Laravel package that extends **Solaris BaseCRM** with a full-featured marketing suite — covering multi-channel campaign blasting, audience segmentation, and event management.

Built on the same Solaris foundation, so everything plays nicely with the rest of the ecosystem: Contacts, Leads, Activities, and the Solar UI component system are all wired in out of the box.

---

## 🛠 Features Breakdown

### 📋 CRM Extensions
- **Contact Module** — extends BaseCRM Contact with marketing-specific attributes and behaviors.
- **Activity Module** — extends BaseCRM Activity for tracking marketing touchpoints.
- **Lead Module** — extends BaseCRM Lead for campaign-driven lead flows.

### 🗓 Event Management
- **Event Module** — create and manage marketing events with full lifecycle tracking.
- **Audience Segmentation** — define and manage event audiences; segmentation component is reusable across modules.

### 📧 Email Blast
- **Campaign Management** — create email blast campaigns with status tracking and quota controls.
- **Stripo Email Editor** — rich visual email editor integration for building branded templates.
- **Email Templates** — manage reusable email templates with full Stripo-powered preview.
- **Audience Management** — assign and manage blast audiences per campaign.
- **Mailgun Provider** — send campaigns via Mailgun with full webhook support (delivery, bounce, open, click tracking).
- **Queue-Based Processing** — email sending handled asynchronously via Laravel jobs for reliable large-list delivery.
- **Campaign Blast Quota** — track and enforce send quotas per campaign.

### 💬 WhatsApp Blast
- **WA Campaign Management** — create and manage WhatsApp blast campaigns end-to-end.
- **WhatsApp Templates** — full template management with variable parameter support and carousel attachment.
- **WhatsApp Preview** — real-time phone preview component for visual template verification before sending.
- **WA Audience Management** — per-campaign audience detail with reply and delivery tracking.
- **Qiscus Provider** — WhatsApp sending via Qiscus integration with full webhook support.
- **Campaign Status Tracking** — track campaign progress, reply rates, and delivery status in real time.
- **Chunk Processing** — large audience lists processed in queue-friendly chunks for safe, scalable delivery.

---

## 📦 Requirements

- PHP **8.2+**
- Laravel **11 or 12**
- [`solaris/solaris-laravel-basecrm`](https://github.com/dev-sunny-solaris/Solaris-Laravel-BaseCRM) `^v0.6.5`

> This package is part of the Solaris ecosystem and is intended to be installed alongside **Solaris Core** and **Solaris BaseCRM**.

---

## 📚 Documentation

The official documentation is **currently in development**.  
Once finished, there will be a separate website and dedicated documentation files detailing campaign setup, provider configuration, and customization guides.
