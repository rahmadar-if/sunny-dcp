# Changelog

All notable changes to `Solaris-Laravel-Marketing` will be documented in this file.

---

## [v0.3.6] - 21 Aug 2026

Patch release — single-send email blast, test-email throttling, and blast progress fixes.

- **Email Blast: Single Send** — send one email to a single audience from the campaign page; new controller action, page JS handler, and email-template section wiring.
- **Email Blast: Test Email Throttle** — added `TestEmailThrottle` service and `test-email-cooldown` JS to rate-limit test sends per scope; merge tags are now compiled before the test send. Updated `StripoPluginController`, `StripoPlugin`, `stripo-editor` (JS + Blade), and `solaris.php` config.
- **Blast Progress Fix** — Email/WA blast services and providers now commit progress per pool instead of at the end, so partial runs are not lost. Touched `EmailBlastJob`, `WaBlastJob`, `EmailBlastService`, `EmailProvider`, `MailgunProvider`, `HasBlastSupport`, `WaBlastService`, `WhatsAppProvider`, `CampaignBlastQuotaService`, and the blast audience models.
- **Quota Usage History** — track `updated_at` in the usage modal and relabel unattached usage entries; cleaned up `CampaignBlastQuotaLog`.
- **HTTP Log** — tag the Qiscus channel and mask its request headers in `QiscusProvider`.

---

## [v0.3.5] - 19 Aug 2026

Minor release — blast quota ledger, usage history, and drift/stuck-booking fixes.

- **Campaign Blast Quota: Ledger** — added `campaign_blast_quota_logs` table, `CampaignBlastQuotaLog` model, and action/context consts to track quota movements.
- **Campaign Blast Quota: Usage History** — new usage history modal (`usage-modal`/`usage-detail`) with list, controller endpoint, and `CampaignBlastQuotaUsageService`.
- **Campaign Blast Quota: Drift Fix** — reworked `CampaignBlastQuotaService`, `CampaignBlastQuota` model, and Email/WA blast jobs & services to stop quota drift and clear stuck blast bookings.
- **Audience** — enabled multi-status filter and fixed config/fields on Email Blast and WA Blast audience lists; audience-detail JS fixes.
- **Notes component** — added support for new prop, wired into contact, email-blast, event, and wa-blast pages.
- **WA Template / Stripo Editor** — fixed JS alias usage and circular dependencies.
- Moved component docs (`audience-segmentation-modal`, `stripo-editor`, `whatsapp-preview`) into `components/docs/`.
- Updated `solaris.php` config.
- Bumped dependency: `solaris-laravel-basecrm` → `^v0.8.4`.

---

## [v0.3.4] - 29 Jun 2026

Patch release — contact layout refactor and activity page cleanup.

- **Contact** — refactored contact page into dedicated sections: `info`, `marketing`, and `notes-files`.
- **Activity** — refactored activity page layout and JS.
- **MenuSeeder** — cleaned up menu entries.
- Bumped dependency: `solaris-laravel-basecrm` → `^v0.6.7`.

---

## [v0.3.3] - 26 Jun 2026

Patch release — contact history detail, blast module UI overhaul, and event module updates.

- **Contact: History Detail** — new history sections in contact page: Email Blast, WA Blast, and Event history with dedicated list views and JS handlers.
- **Email Blast** — revamped campaign status section, audience list UI, page JS logic, and audience-detail JS. Updated `EmailBlast` model and `EmailBlastAudienceRepository`.
- **WA Blast** — revamped campaign status section, audience list UI, page JS logic, and audience-detail JS. Updated `WaBlast` model.
- **Event** — updated event list, page, audience list, and stage-history views. Updated `Event` model. Fixed `EventSeeder`.
- **Campaign Blast Quota** — updated `CampaignBlastQuotaRepository` and quota list JS.
- Updated `solaris.php` config.
- Added new constants to `const.js`; cleaned up `jsconfig.json`.
- Bumped dependency: `solaris-laravel-basecrm` → `^v0.6.6`.

---

## [v0.3.2] - 24 Jun 2026

Patch release — broad update across controllers, models, and repositories for all marketing blast modules.

- Updated controllers: `EmailBlastController`, `EmailBlastAudienceController`, `EmailTemplateController`, `WaBlastController`, `WaBlastAudienceController`, `WaTemplateController`, `WaTemplateDetailController`, `EventController`, `EventAudienceController`.
- Updated models: `CampaignBlastQuota`, `EmailBlast`, `EmailTemplate`, `WaBlast`, `WaTemplate`, `WaTemplateLanguage`, `Event`.
- Updated repositories: `EmailBlastRepository`, `EmailBlastAudienceRepository`, `WaBlastRepository`, `WaBlastAudienceRepository`, `WaTemplateRepository`, `WaTemplateDetailRepository`, `CampaignBlastQuotaRepository`, `EventRepository`.

---

## [v0.3.1] - 24 Jun 2026

Patch release — bug fixes for search audience and chunk blast processing.

- Fixed extend search audience behavior.
- Fixed bug in Email Blast and WA Blast chunk processing.
- Removed unused `CampaignAudienceStatus` class.

---

## [v0.3.0] - 24 Apr 2026

Major update — WA Blast campaign status feature and service enhancements.

- **WA Blast: Campaign Status** — added campaign status tracking for WhatsApp blast campaigns.
- **WA Blast service** — enhanced blast service with improved processing logic.
- **WA Blast layout** — updated campaign blast list layout.
- Null checker additions for safer data handling.
- New prop support in the Notes component.
- Return type hints added across relevant classes.
- JS null checker for extend-compatible support.
- Activity fix.
- Renamed WhatsApp blast audience repository for clarity.

---

## [v0.2.5] - 21 Apr 2026

Patch release — webhook handling and replied column additions.

- Updated WhatsApp webhook handling.
- Updated email webhook handling.
- New migration: alter WA blast `replied` columns.
- Updated audience-detail JS.
- Updated campaign console commands.
- Updated campaign seeder.

---

## [v0.2.4] - 20 Apr 2026

Patch release — WA template UI changes and blast fixes.

- WA Template list changed from card to default list layout.
- Fixed WhatsApp preview scale in WA Template.
- Enhanced WA template variable params handling.
- Bug fixes in WA template controller.

---

## [v0.2.3] - 19 Apr 2026

Patch release — WA blast finishing, Qiscus enhancement, and multi-module fixes.

- **WA Blast** — fixed and finalized WA blast end-to-end process.
- **Qiscus Provider** — enhanced Qiscus provider integration.
- **Email Blast** — enhanced email provider DX; fixed duplicate const JS file.
- Fixed WA template carousel attachment table name.
- Fixed lookup breaking change in Blade components.
- Handle disabled field state based on campaign status (Email & WA Blast).
- Added `EventTypeConst` for event type constants.
- New migration: update activities table.
- Updated WA template service and constants.
- Updated WA blast detail view.
- Fixed `SolarisUser` type hint in email provider.
- Blade component docs for Solar UI VS Code extension.
- Fixed typo: Qisqus → Qiscus.

---

## [v0.2.2] - 17 Apr 2026

Major release — full WhatsApp Blast feature implementation.

- **WhatsApp Blast** — full WA blast implementation: `WaBlastRepository`, `WaTemplateRepository`, audience management.
- **WA Template** — template management with full CRUD, JS, and Blade components.
- **WhatsApp Preview component** — interactive preview of WA templates.
- Migrations and seeders for WA blast and templates.
- Email template Stripo integration updates.
- `jsconfig.json` added for JS path resolution.
- Routes update for WA blast and template modules.
- Contact model updates.

---

## [v0.2.1] - 6 Apr 2026

Minor release — WhatsApp blast initial scaffolding and email blast enhancements.

- **WhatsApp Blast feature** — initial WA blast scaffolding and service.
- **WhatsApp Preview component** — new Blade component for phone-style template preview.
- **Email Blast webhook** — enhanced webhook processing and service.
- Email blast and email template updates.
- Updated `EmailBlastRepository`.

---

## [v0.2.0] - 1 Apr 2026

Minor release — email blast process improvements and module updates.

- **Email Blast** — enhanced blast process and service logic.
- **Campaign Blast Quota** — updated quota module.
- Updated email editor and editor-preview Blade components.
- New attributes added to campaign models.
- Service provider and config updates.
- Updated routes and select compatibility.

---

## [v0.1.1] - 23 Feb 2026

Patch release — Stripo update and breaking change fixes.

- Updated Stripo integration.
- Fixed breaking change compatibility issues.
- Internal composer and dependency updates.

---

## [v0.1.0] - 11 Feb 2026

Patch release — namespace standardization.

- Updated namespaces to align with Solaris package standards.

---

## [v0.0.4] - 29 Jan 2026

- **Email Template + Stripo** — integrated Stripo visual email editor.
- Email blast now supports Stripo-based email editor.
- Updated routes, console commands, and config.

---

## [v0.0.3] - 27 Jan 2026

- **Email Blast** — full email blast feature: service, job, facade, audience management, blast list UI.
- **Mailgun Provider** — email sending via Mailgun with provider config.
- Email blast migration updates.
- Routes and service provider updates.
- `CampaignBlastQuota` model update.
- `Event` model update.

---

## [v0.0.2] - 20 Jan 2026

- **Email Blast Module** — initial email blast: migration, seeder, const.
- **Event Module** — audience management updates, segmentation component separated into reusable Blade component.
- Fixed double render bug in add audience modal.

---

## [v0.0.1] - 12 Jan 2026

- Initial release.
- **Contact Module** — extends BaseCRM Contact.
- **Activity Module** — extends BaseCRM Activity.
- **Lead Module** — extends BaseCRM Lead.
- **Event Module** — event management with audience management.
- Base setup: config, routes, service provider, migrations, seeders.
