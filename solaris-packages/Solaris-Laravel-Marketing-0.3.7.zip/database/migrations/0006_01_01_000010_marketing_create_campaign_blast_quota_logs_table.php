<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('campaign_blast_quota_logs', function(Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('action');
            $table->string('context');
            $table->integer('book_delta')->default(0);
            $table->integer('used_delta')->default(0);
            $table->integer('quota_book_after')->default(0);
            $table->integer('quota_used_after')->default(0);
            $table->string('source_type')->nullable();
            $table->uuid('source_id')->nullable();

            $table->foreignUuid('quota_id')->constrained('campaign_blast_quotas')->cascadeOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['quota_id', 'created_at']);
            MigrationHelper::createIndexIfNeeds($table, ['quota_id', 'source_type', 'source_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('campaign_blast_quota_logs');
    }
};
