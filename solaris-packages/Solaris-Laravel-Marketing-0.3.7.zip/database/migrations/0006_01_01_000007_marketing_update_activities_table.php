<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('activities', function (Blueprint $table) {
            $table->foreignUuid('event_id')->nullable()->constrained('events');
            $table->foreignUuid('email_blast_id')->nullable()->constrained('email_blasts');
            $table->foreignUuid('wa_blast_id')->nullable()->constrained('wa_blasts');

            MigrationHelper::createIndexIfNeeds($table, ['event_id']);
            MigrationHelper::createIndexIfNeeds($table, ['email_blast_id']);
            MigrationHelper::createIndexIfNeeds($table, ['wa_blast_id']);
        });
    }

    public function down(): void
    {
        Schema::table('activities', function (Blueprint $table) {
            $table->dropForeign(['event_id']);
            $table->dropForeign(['email_blast_id']);
            $table->dropForeign(['wa_blast_id']);

            MigrationHelper::dropIndexIfNeeds($table, ['event_id']);
            MigrationHelper::dropIndexIfNeeds($table, ['email_blast_id']);
            MigrationHelper::dropIndexIfNeeds($table, ['wa_blast_id']);

            $table->dropColumn('event_id');
            $table->dropColumn('email_blast_id');
            $table->dropColumn('wa_blast_id');
        });
    }
};