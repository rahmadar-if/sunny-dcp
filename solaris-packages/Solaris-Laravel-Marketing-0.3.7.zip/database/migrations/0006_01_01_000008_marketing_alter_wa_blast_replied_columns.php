<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
	public function up(): void
    {
        Schema::table('wa_blast_audiences', function (Blueprint $table) {
            $table->dropColumn('replied');
        });

        Schema::table('wa_blast_audiences', function (Blueprint $table) {
            $table->json('replied')->nullable();
        });

        Schema::table('wa_blast_webhook_temp', function (Blueprint $table) {
            $table->dropColumn('replied');
        });

        Schema::table('wa_blast_webhook_temp', function (Blueprint $table) {
            $table->json('replied')->nullable();
        });

        Schema::table('wa_blast_webhooks', function (Blueprint $table) {
            $table->string('button_payload')->nullable()->after('event_type');
        });
    }

    public function down(): void
    {
        Schema::table('wa_blast_webhooks', function (Blueprint $table) {
            $table->dropColumn('button_payload');
        });

        Schema::table('wa_blast_webhook_temp', function (Blueprint $table) {
            $table->dropColumn('replied');
        });

        Schema::table('wa_blast_webhook_temp', function (Blueprint $table) {
            $table->boolean('replied')->default(false);
        });

        Schema::table('wa_blast_audiences', function (Blueprint $table) {
            $table->dropColumn('replied');
        });

        Schema::table('wa_blast_audiences', function (Blueprint $table) {
            $table->boolean('replied')->default(false);
        });
    }
};
