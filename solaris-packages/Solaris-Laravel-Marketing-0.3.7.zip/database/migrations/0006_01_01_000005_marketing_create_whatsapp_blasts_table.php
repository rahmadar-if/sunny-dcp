<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
	public function up(): void
	{
		Schema::create('wa_blasts', function (Blueprint $table) {
			MigrationHelper::baseTable($table);

			$table->string('title')->nullable();
			$table->dateTime('sent_at')->nullable();
			$table->dateTime('schedule_at')->nullable();
			$table->dateTime('queue_at')->nullable();
			$table->dateTime('completed_at')->nullable();
			$table->integer('total_audience')->default(0);
			$table->integer('total_pending')->default(0);
			$table->integer('total_progress')->default(0);
			$table->integer('total_success')->default(0);
			$table->integer('total_fail')->default(0);
			$table->integer('total_read')->default(0);
			$table->integer('total_replied')->default(0);
			$table->text('notes')->nullable();
			$table->text('error_message')->nullable();
			$table->json('quotas')->nullable();
			$table->json('template_params')->nullable();

			$table->foreignUuid('status_id')->nullable()->constrained('campaign_blast_statuses')->nullOnDelete();
			$table->foreignUuid('priority_id')->nullable()->constrained('activity_priorities')->nullOnDelete();

			MigrationHelper::createIndexIfNeeds($table, ['status_id']);
			MigrationHelper::createIndexIfNeeds($table, ['priority_id']);
		});
		
		Schema::create('wa_blast_audience_statuses', function (Blueprint $table) {
			MigrationHelper::baseLookup($table);
		});

		Schema::create('wa_blast_audiences', function (Blueprint $table) {
			MigrationHelper::baseTable($table);

			$table->boolean('replied')->default(false);
			$table->string('message_id')->unique()->nullable();
			$table->text('message')->nullable();

			$table->foreignUuid('wa_blast_id')->nullable()->constrained('wa_blasts')->cascadeOnDelete();
			$table->foreignUuid('contact_id')->nullable()->constrained('contacts')->cascadeOnDelete();
			$table->foreignUuid('status_id')->nullable()->constrained('wa_blast_audience_statuses')->nullOnDelete();

			MigrationHelper::createIndexIfNeeds($table, ['wa_blast_id']);
			MigrationHelper::createIndexIfNeeds($table, ['contact_id']);
			MigrationHelper::createIndexIfNeeds($table, ['status_id']);
		});

		Schema::create('wa_blast_status_histories', function (Blueprint $table) {
			MigrationHelper::baseTable($table);

			$table->smallInteger('position');
			$table->timestamp('start')->nullable();
			$table->timestamp('end')->nullable();

			$table->foreignUuid('wa_blast_id')->nullable()->constrained('wa_blasts')->cascadeOnDelete();
			$table->foreignUuid('status_id')->nullable()->constrained('campaign_blast_statuses')->cascadeOnDelete();

			MigrationHelper::createIndexIfNeeds($table, ['wa_blast_id']);
			MigrationHelper::createIndexIfNeeds($table, ['status_id']);
		});

		Schema::create('wa_blast_audience_temp', function (Blueprint $table) {
			$table->uuid('id');
			$table->primary('id');

			$table->foreignUuid('wa_blast_id')->nullable()->constrained('wa_blasts');
			$table->foreignUuid('status_id')->nullable()->constrained('wa_blast_audience_statuses');
			$table->string('message_id')->nullable();
			$table->text('message')->nullable();

			MigrationHelper::createIndexIfNeeds($table, ['wa_blast_id']);
			MigrationHelper::createIndexIfNeeds($table, ['status_id']);
		});

		Schema::create('wa_blast_webhooks', function (Blueprint $table) {
			MigrationHelper::baseTable($table);

			$table->json("raw")->nullable();
			$table->string("message_id")->nullable();
			$table->string("message")->nullable();
			$table->string("event_type")->nullable();

			$table->index(['message_id']);
		});

		Schema::create('wa_blast_webhook_temp', function (Blueprint $table) {
			$table->uuid('id');
			$table->primary('id');

			$table->boolean('read')->default(false);
			$table->boolean('replied')->default(false);
			$table->string('message_id')->nullable();
			$table->text('message')->nullable();

			$table->foreignUuid('audience_id')->nullable()->constrained('wa_blast_audiences')->cascadeOnDelete();
			$table->foreignUuid('status_id')->nullable()->constrained('wa_blast_audience_statuses')->nullOnDelete();

			MigrationHelper::createIndexIfNeeds($table, ['audience_id']);
			MigrationHelper::createIndexIfNeeds($table, ['status_id']);

			$table->index(['message_id']);
		});
	}

	public function down(): void
	{
		Schema::dropIfExists('wa_blast_webhook_temp');
		Schema::dropIfExists('wa_blast_webhooks');
		Schema::dropIfExists('wa_blast_audience_temp');
		Schema::dropIfExists('wa_blast_status_histories');
		Schema::dropIfExists('wa_blast_audiences');
		Schema::dropIfExists('wa_blast_audience_statuses');
		Schema::dropIfExists('wa_blasts');
	}
};
