<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
	public function up(): void
	{
		Schema::create('wa_template_categories', function (Blueprint $table) {
			MigrationHelper::baseLookup($table);
		});

		Schema::create('wa_template_sub_types', function (Blueprint $table) {
			MigrationHelper::baseLookup($table);
		});

		Schema::create('wa_template_languages', function (Blueprint $table) {
			MigrationHelper::baseLookupCode($table);
		});

		Schema::create('wa_template_statuses', function (Blueprint $table) {
			MigrationHelper::baseLookupStage($table);
		});

		Schema::create('wa_template_header_types', function (Blueprint $table) {
			MigrationHelper::baseLookup($table);
		});

		Schema::create('wa_templates', function (Blueprint $table) {
			MigrationHelper::baseTable($table);

			$table->string('name')->nullable();
			$table->string('template_id')->nullable();
			$table->string('template_name')->nullable();
			$table->text('custom')->nullable();

			$table->foreignUuid('category_id')->nullable()->constrained('wa_template_categories')->nullOnDelete();

			MigrationHelper::createIndexIfNeeds($table, ['category_id']);
		});

		Schema::create('wa_template_details', function (Blueprint $table) {
			MigrationHelper::baseTable($table);

			$table->foreignUuid('wa_template_id')->nullable()->constrained('wa_templates')->cascadeOnDelete();
			$table->foreignUuid('language_id')->nullable()->constrained('wa_template_languages')->nullOnDelete();
			$table->foreignUuid('sub_type_id')->nullable()->constrained('wa_template_sub_types')->nullOnDelete();
			$table->foreignUuid('status_id')->nullable()->constrained('wa_template_statuses')->nullOnDelete();
			$table->foreignUuid('header_type_id')->nullable()->constrained('wa_template_header_types')->nullOnDelete();

			MigrationHelper::createIndexIfNeeds($table, ['wa_template_id']);
			MigrationHelper::createIndexIfNeeds($table, ['language_id']);
			MigrationHelper::createIndexIfNeeds($table, ['sub_type_id']);
			MigrationHelper::createIndexIfNeeds($table, ['status_id']);
			MigrationHelper::createIndexIfNeeds($table, ['header_type_id']);

			$table->text('header_content')->nullable();
			$table->json('header_examples')->nullable();
			$table->text('body')->nullable();
			$table->json('body_examples')->nullable();
			$table->string('footer')->nullable();
			$table->json('buttons')->nullable();
			$table->json('cards')->nullable();
			$table->boolean('disclaimer')->default(false);
			$table->unsignedSmallInteger('expiry_minutes')->nullable();
			$table->string('reject_reason')->nullable();
		});

		Schema::table('wa_blasts', function(Blueprint $table) {
			$table->foreignUuid('wa_template_detail_id')->nullable()->constrained('wa_template_details')->nullOnDelete();
			MigrationHelper::createIndexIfNeeds($table, ['wa_template_detail_id']);
		});
	}

	public function down(): void
	{
		Schema::table('wa_blasts', function(Blueprint $table) {
			MigrationHelper::dropIndexIfNeeds($table, ["wa_template_detail_id"]);
			$table->dropForeign(['wa_template_detail_id']);
            $table->dropColumn('wa_template_detail_id');
        });

		Schema::dropIfExists('wa_template_details');
		Schema::dropIfExists('wa_templates');
		Schema::dropIfExists('wa_template_header_types');
		Schema::dropIfExists('wa_template_statuses');
		Schema::dropIfExists('wa_template_languages');
		Schema::dropIfExists('wa_template_sub_types');
		Schema::dropIfExists('wa_template_categories');
	}
};
