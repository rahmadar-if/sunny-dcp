<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('email_templates', function(Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('name')->nullable();
            $table->text('html')->nullable();
            $table->text('css')->nullable();
            $table->smallInteger('width')->nullable();
            $table->smallInteger('height')->nullable();
            $table->text('html_compiled')->nullable();
            $table->text('amp_html')->nullable();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('email_templates');
    }
};