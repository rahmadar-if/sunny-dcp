<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('campaign_blast_quotas', function(Blueprint $table) {
            $table->boolean('auto_renew')->default(false)->after('expired_at');
            $table->integer('auto_renew_days')->nullable()->after('auto_renew');
        });
    }

    public function down(): void
    {
        Schema::table('campaign_blast_quotas', function(Blueprint $table) {
            $table->dropColumn(['auto_renew', 'auto_renew_days']);
        });
    }
};
