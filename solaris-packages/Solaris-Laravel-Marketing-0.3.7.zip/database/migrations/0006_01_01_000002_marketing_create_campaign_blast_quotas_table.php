<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('campaign_blast_types', function(Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('campaign_blast_quotas', function(Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('provider')->nullable();
            $table->string('period')->nullable();
            $table->integer('total_quota')->default(0);
            $table->integer('quota_book')->default(0);
            $table->integer('quota_used')->default(0);
            $table->timestamp('effective_at')->nullable();
            $table->timestamp('expired_at')->nullable();

            $table->foreignUuid('type_id')->nullable()->constrained('campaign_blast_types')->nullOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['type_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('campaign_blast_quotas');
        Schema::dropIfExists('campaign_blast_types');
    }
};