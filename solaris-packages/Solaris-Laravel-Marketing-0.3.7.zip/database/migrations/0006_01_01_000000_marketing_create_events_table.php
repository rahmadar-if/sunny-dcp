<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('event_types', function (Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('event_statuses', function (Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('event_stages', function (Blueprint $table) {
            MigrationHelper::baseLookupStage($table);
        });

        Schema::create('events', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('name')->nullable();
            $table->date('start_date')->nullable();
            $table->date('end_date')->nullable();
            $table->string('goal')->nullable();
            $table->decimal('budget_cost', 19, 2)->default(0);
            $table->decimal('actual_cost', 19, 2)->default(0);
            $table->text('notes')->nullable();

            $table->foreignUuid('status_id')->nullable()->constrained('event_statuses')->nullOnDelete();
            $table->foreignUuid('type_id')->nullable()->constrained('event_types')->nullOnDelete();
            $table->foreignUuid('stage_id')->nullable()->constrained('event_stages')->nullOnDelete();
            
            MigrationHelper::createIndexIfNeeds($table, ['status_id']);
            MigrationHelper::createIndexIfNeeds($table, ['type_id']);
            MigrationHelper::createIndexIfNeeds($table, ['stage_id']);
        });

        Schema::create('event_audiences', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->foreignUuid('contact_id')->nullable()->constrained('contacts')->cascadeOnDelete();
            $table->foreignUuid('event_id')->nullable()->constrained('events')->cascadeOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['contact_id']);
            MigrationHelper::createIndexIfNeeds($table, ['event_id']);
        });

        Schema::create('event_stage_histories', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->smallInteger('position');
            $table->timestamp('start')->nullable();
            $table->timestamp('end')->nullable();

            $table->foreignUuid('event_id')->nullable()->constrained('events')->cascadeOnDelete();
            $table->foreignUuid('stage_id')->nullable()->constrained('event_stages')->cascadeOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['event_id']);
            MigrationHelper::createIndexIfNeeds($table, ['stage_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('event_stage_histories');
        Schema::dropIfExists('event_audiences');
        Schema::dropIfExists('events');
        Schema::dropIfExists('event_stages');
        Schema::dropIfExists('event_statuses');
        Schema::dropIfExists('event_types');
    }
};