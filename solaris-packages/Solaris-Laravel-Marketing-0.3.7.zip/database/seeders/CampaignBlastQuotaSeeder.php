<?php

namespace Solaris\Marketing\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Solaris\Core\Models\Menu;

class CampaignBlastQuotaSeeder extends Seeder
{
    public function run(): void
    {
        $data = [
            [
                'id'          => '019d46e2-1492-710b-82a0-22ccc0fad096',
                'name'        => 'Marketing',
                'position'    => 2,
                'url'         => null,
                'route_name'  => null,
                'icon'        => 'bx bx-cog',
                'is_category' => false,
                'is_hide'     => false,
                'parent_id'   => null,
                'category_id' => '019c1d8e-f7c6-79aa-a775-593b2f6c0129',
            ],
            [
                'id'          => '019d46e3-ba17-7296-89e6-b1769986fe8b',
                'name'        => 'Blast Quota',
                'position'    => 1,
                'url'         => '/admin/marketing/campaign-blast-quota',
                'route_name'  => 'admin.marketing.campaign-blast-quota',
                'icon'        => null,
                'is_category' => false,
                'is_hide'     => false,
                'parent_id'   => '019d46e2-1492-710b-82a0-22ccc0fad096',
                'category_id' => null,
            ]
        ];

        DB::table('menus')->insertOrIgnore($data);

        $menuAccess = Menu::whereIn('id', 
            array_map(
                fn($item) => $item['id'], 
                array_filter($data, fn($item) => !$item['is_category'] && !empty($item['url']))
            )
        )
        ->get();

        foreach($menuAccess as $menu) {
            $menu->assignRole('Admin');
        }
    }
}
