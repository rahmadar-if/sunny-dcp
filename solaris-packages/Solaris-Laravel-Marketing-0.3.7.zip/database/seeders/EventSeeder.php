<?php

namespace Solaris\Marketing\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Solaris\Marketing\Const\EventStageConst;
use Solaris\Marketing\Const\EventStatusConst;
use Solaris\Marketing\Const\EventTypeConst;

class EventSeeder extends Seeder
{
    public function run(): void
    {
        $this->event_types();
        $this->event_statuses();
        $this->event_stages();
    }

    protected function event_types(): void
    {
        $data = [
            [
                'id'       => EventTypeConst::Seminar,
                'name'     => 'Seminar',
                'position' => 1,
            ],
            [
                'id'       => EventTypeConst::Exhibition,
                'name'     => 'Exhibition',
                'position' => 2,
            ],
            [
                'id'        => EventTypeConst::Promotion,
                'name'      => 'Promotion',
                'position'  => 3,
            ],
            [
                'id'        => EventTypeConst::Tutorial,
                'name'      => 'Tutorial',
                'position'  => 4,
            ],
            [
                'id'        => EventTypeConst::Webinar,
                'name'      => 'Webinar',
                'position'  => 5,
            ],
        ];
        DB::table('event_types')->insertOrIgnore($data);
    }

    protected function event_statuses(): void
    {
        $data = [
            [
                'id'       => EventStatusConst::Planned,
                'name'     => 'Planned',
                'position' => 1,
            ],
            [
                'id'       => EventStatusConst::InProgress,
                'name'     => 'In Progress',
                'position' => 2,
            ],
            [
                'id'        => EventStatusConst::Completed,
                'name'      => 'Completed',
                'position'  => 3,
            ],
            [
                'id'        => EventStatusConst::Canceled,
                'name'      => 'Canceled',
                'position'  => 4,
            ]
        ];
        DB::table('event_statuses')->insertOrIgnore($data);
    }

    protected function event_stages(): void
    {
        $data = [
            [
                'id'             => EventStageConst::Draft,
                'name'           => 'Draft',
                'position'       => 1,
                'color'          => "primary",
                "group_id"       => null,
                'is_final_stage' => false
            ],
            [
                'id'             => EventStageConst::Confirmation,
                'name'           => 'Confirmation',
                'position'       => 2,
                'color'          => "secondary",
                "group_id"       => null,
                'is_final_stage' => false
            ],
            [
                'id'             => EventStageConst::Closed,
                'name'           => 'Closed',
                'position'       => 3,
                'color'          => "success",
                "group_id"       => null,
                'is_final_stage' => true
            ],
            [
                'id'             => EventStageConst::Cancel,
                'name'           => 'Cancel',
                'position'       => 4,
                'color'          => "danger",
                "group_id"       => EventStageConst::Closed,
                'is_final_stage' => true
            ],
        ];
        DB::table('event_stages')->insertOrIgnore($data);
    }
}