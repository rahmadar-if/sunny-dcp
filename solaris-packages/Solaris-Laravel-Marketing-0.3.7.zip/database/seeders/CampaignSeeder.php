<?php

namespace Solaris\Marketing\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Solaris\Marketing\Const\CampaignBlastStatusConst;
use Solaris\Marketing\Const\CampaignBlastTypeConst;
use Solaris\Marketing\Const\EmailBlastAudienceStatusConst;
use Solaris\Marketing\Const\WaBlastAudienceStatusConst;

class CampaignSeeder extends Seeder
{
    public function run(): void
    {
        $this->campaign_blast_statuses();
        $this->campaign_blast_types();
        $this->email_blast_audience_statuses();
        $this->wa_blast_audience_statuses();
    }

    protected function campaign_blast_statuses(): void
    {
        $data = [
            [
                'id'             => CampaignBlastStatusConst::Draft,
                'name'           => 'Draft',
                'position'       => 1,
                'color'          => "primary",
                "group_id"       => null,
                'is_final_stage' => false
            ],
            [
                'id'             => CampaignBlastStatusConst::Scheduled,
                'name'           => 'Scheduled',
                'position'       => 2,
                'color'          => "secondary",
                "group_id"       => null,
                'is_final_stage' => false
            ],
            [
                'id'             => CampaignBlastStatusConst::Queued,
                'name'           => 'Queued',
                'position'       => 3,
                'color'          => "secondary",
                "group_id"       => null,
                'is_final_stage' => false
            ],
            [
                'id'             => CampaignBlastStatusConst::Sending,
                'name'           => 'Sending',
                'position'       => 3,
                'color'          => "info",
                "group_id"       => null,
                'is_final_stage' => false
            ],
            [
                'id'             => CampaignBlastStatusConst::Completed,
                'name'           => 'Completed',
                'position'       => 4,
                'color'          => "success",
                "group_id"       => null,
                'is_final_stage' => true
            ],
            [
                'id'             => CampaignBlastStatusConst::Canceled,
                'name'           => 'Canceled',
                'position'       => 5,
                'color'          => "danger",
                "group_id"       => CampaignBlastStatusConst::Completed,
                'is_final_stage' => true
            ],
            [
                'id'             => CampaignBlastStatusConst::Failed,
                'name'           => 'Failed',
                'position'       => 6,
                'color'          => "danger",
                "group_id"       => CampaignBlastStatusConst::Completed,
                'is_final_stage' => true
            ],
        ];
        DB::table('campaign_blast_statuses')->insertOrIgnore($data);
    }

    protected function campaign_blast_types(): void
    {
        $data = [
            [
                'id'       => CampaignBlastTypeConst::Email,
                'name'     => 'Email',
                'position' => 1,
            ],
            [
                'id'       => CampaignBlastTypeConst::WhatsApp,
                'name'     => 'WhatsApp',
                'position' => 2,
            ]
        ];
        DB::table('campaign_blast_types')->insertOrIgnore($data);
    }

    protected function email_blast_audience_statuses(): void
    {
        $data = [
            [
                'id'       => EmailBlastAudienceStatusConst::Pending,
                'name'     => 'Pending',
                'position' => 1,
            ],
            [
                'id'       => EmailBlastAudienceStatusConst::Progress,
                'name'     => 'Progress',
                'position' => 2,
            ],
            [
                'id'       => EmailBlastAudienceStatusConst::Delivered,
                'name'     => 'Delivered',
                'position' => 3,
            ],
            [
                'id'        => EmailBlastAudienceStatusConst::SoftBounce,
                'name'      => 'Soft Bounce',
                'position'  => 4,
            ],
            [
                'id'        => EmailBlastAudienceStatusConst::HardBounce,
                'name'      => 'Hard Bounce',
                'position'  => 5,
            ],
            [
                'id'        => EmailBlastAudienceStatusConst::Failed,
                'name'      => 'Failed',
                'position'  => 6,
            ]
        ];
        DB::table('email_blast_audience_statuses')->insertOrIgnore($data);
    }

    protected function wa_blast_audience_statuses(): void
    {
        $data = [
            [
                'id'       => WaBlastAudienceStatusConst::Pending,
                'name'     => 'Pending',
                'position' => 1,
            ],
            [
                'id'       => WaBlastAudienceStatusConst::Progress,
                'name'     => 'Progress',
                'position' => 2,
            ],
            [
                'id'       => WaBlastAudienceStatusConst::Sent,
                'name'     => 'Sent',
                'position' => 3,
            ],
            [
                'id'       => WaBlastAudienceStatusConst::Delivered,
                'name'     => 'Delivered',
                'position' => 4,
            ],
            [
                'id'       => WaBlastAudienceStatusConst::Read,
                'name'     => 'Read',
                'position' => 5,
            ],
            [
                'id'       => WaBlastAudienceStatusConst::Failed,
                'name'     => 'Failed',
                'position' => 6,
            ]
        ];
        DB::table('wa_blast_audience_statuses')->insertOrIgnore($data);
    }
}