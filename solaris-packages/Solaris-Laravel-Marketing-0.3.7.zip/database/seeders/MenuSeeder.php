<?php

namespace Solaris\Marketing\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Solaris\Core\Models\Menu;

class MenuSeeder extends Seeder
{
    public function run(): void
    {
        $this->dashboard();
        $this->marketing();
    }

    protected function dashboard(): void
    {
        $dashboardId = Menu::select('id')
            ->where('name', 'Dashboard')
            ->whereHas('category', fn($query) => $query->where('name', 'Main'))
            ->first()
            ->id;

        $data = [
            [
                'id'          => "7261f70b-a71e-4df2-84e0-382afe4a1416",
                'name'        => 'Marketing',
                'position'    => 1,
                'url'         => "marketing/dashboard",
                'route_name'  => "marketing.dashboard",
                'icon'        => null,
                'is_category' => false,
                'parent_id'   => $dashboardId,
                'category_id' => null,
            ]
        ];

        DB::table('menus')->insertOrIgnore($data);

        $menu = Menu::find("7261f70b-a71e-4df2-84e0-382afe4a1416");
        $menu?->assignRole('User');
    }

    protected function marketing(): void
    {
        $crmModuleCategoryId = "019ac81e-bf04-7034-883e-4af75966562d";
        $marketingId         = "019b4a19-aa0e-71a8-af6c-d636bffb92d4";
        $campaignId          = "019b4a19-aa0e-70a7-9ef8-ab3eed2c0fce";

        $data = [
            [
                'id'          => $marketingId,
                'name'        => 'Marketing',
                'position'    => 1,
                'url'         => null,
                'route_name'  => null,
                'icon'        => 'bx bxs-megaphone',
                'is_category' => false,
                'parent_id'   => null,
                'category_id' => $crmModuleCategoryId,
            ],
            [
                'id'          => "019c4aa5-0282-7bf6-88ea-eb3c6813741b",
                'name'        => 'Lead',
                'position'    => 1,
                'url'         => '/marketing/lead',
                'route_name'  => 'marketing.lead',
                'icon'        => null,
                'is_category' => false,
                'parent_id'   => $marketingId,
                'category_id' => null,
            ],
            [
                'id'          => $campaignId,
                'name'        => 'Campaign',
                'position'    => 2,
                'url'         => null,
                'route_name'  => null,
                'icon'        => null,
                'is_category' => false,
                'parent_id'   => $marketingId,
                'category_id' => null,
            ],
            [
                'id'          => "019b4a19-aa0e-7362-85f1-e8fc18cb5489",
                'name'        => 'Email Blast',
                'position'    => 1,
                'url'         => '/marketing/email-blast',
                'route_name'  => 'marketing.email-blast',
                'icon'        => null,
                'is_category' => false,
                'parent_id'   => $campaignId,
                'category_id' => null,
            ],
            [
                'id'          => "019b4a19-aa0e-7835-af26-ac1a674a430f",
                'name'        => 'Whatsapp Blast',
                'position'    => 2,
                'url'         => '/marketing/wa-blast',
                'route_name'  => 'marketing.wa-blast',
                'icon'        => null,
                'is_category' => false,
                'parent_id'   => $campaignId,
                'category_id' => null,
            ],
            [
                'id'          => "019b4a19-aa0e-7dac-8e34-12fe222c7fe1",
                'name'        => 'Event',
                'position'    => 3,
                'url'         => '/marketing/event',
                'route_name'  => 'marketing.event',
                'icon'        => null,
                'is_category' => false,
                'parent_id'   => $marketingId,
                'category_id' => null,
            ],
            [
                'id'          => "019c4aa2-700c-7fd5-abad-224d28e6c50c",
                'name'        => 'Email Template',
                'position'    => 4,
                'url'         => '/marketing/email-template',
                'route_name'  => 'marketing.email-template',
                'icon'        => null,
                'is_category' => false,
                'parent_id'   => $marketingId,
                'category_id' => null,
            ],
            [
                'id'          => "019d7658-a4cb-7210-8245-59bf24d0264a",
                'name'        => 'WhatsApp Template',
                'position'    => 5,
                'url'         => '/marketing/wa-template',
                'route_name'  => 'marketing.wa-template',
                'icon'        => null,
                'is_category' => false,
                'parent_id'   => $marketingId,
                'category_id' => null,
            ],
        ];

        DB::table('menus')->insertOrIgnore($data);

        $menuAccess = Menu::whereIn('id', 
            array_map(
                fn($item) => $item['id'], 
                array_filter($data, fn($item) => !$item['is_category'] && !empty($item['url']))
            )
        )
        ->get();

        foreach($menuAccess as $menu) {
            $menu->assignRole('User');
        }
    }
}
