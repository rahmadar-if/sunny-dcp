<?php

namespace Solaris\Marketing\Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            MenuSeeder::class,
            EventSeeder::class,
            CampaignSeeder::class,
            CampaignBlastQuotaSeeder::class,
            WhatsAppTemplateSeeder::class,
        ]);
    }
}