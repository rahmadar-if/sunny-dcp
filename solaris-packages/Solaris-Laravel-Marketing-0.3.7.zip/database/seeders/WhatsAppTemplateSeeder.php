<?php

namespace Solaris\Marketing\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Solaris\Marketing\Const\WaTemplateCategoryConst;
use Solaris\Marketing\Const\WaTemplateHeaderTypeConst;
use Solaris\Marketing\Const\WaTemplateLanguageConst;
use Solaris\Marketing\Const\WaTemplateStatusConst;
use Solaris\Marketing\Const\WaTemplateSubTypeConst;

class WhatsAppTemplateSeeder extends Seeder
{
	public function run(): void
	{
		$this->wa_template_categories();
		$this->wa_template_sub_types();
		$this->wa_template_languages();
		$this->wa_template_statuses();
		$this->wa_template_header_types();
	}

	protected function wa_template_categories(): void
	{
		$data = [
			[
				'id'       => WaTemplateCategoryConst::Marketing,      
				'name'     => 'Marketing',      
				'position' => 1
			],
			[
				'id'       => WaTemplateCategoryConst::Utility,        
				'name'     => 'Utility',         
				'position' => 2
			],
			[
				'id'       => WaTemplateCategoryConst::Authentication, 
				'name'     => 'Authentication',  
				'position' => 3
			],
		];
		DB::table('wa_template_categories')->insertOrIgnore($data);
	}

	protected function wa_template_sub_types(): void
	{
		$data = [
			[
				'id'       => WaTemplateSubTypeConst::Regular,  
				'name'     => 'Regular',  
				'position' => 1
			],
			[
				'id'       => WaTemplateSubTypeConst::Carousel, 
				'name'     => 'Carousel', 
				'position' => 2
			],
		];
		DB::table('wa_template_sub_types')->insertOrIgnore($data);
	}

	protected function wa_template_languages(): void
	{
		$data = [
			['id' => WaTemplateLanguageConst::Afrikaans,  'name' => 'Afrikaans',       'position' => 1,  'code' => 'af'],
			['id' => WaTemplateLanguageConst::Albanian,  'name' => 'Albanian',         'position' => 2,  'code' => 'sq'],
			['id' => WaTemplateLanguageConst::Arabic,  'name' => 'Arabic', 		       'position' => 3,  'code' => 'ar'],
			['id' => WaTemplateLanguageConst::Azerbaijani,  'name' => 'Azerbaijani',   'position' => 4,  'code' => 'az'],
			['id' => WaTemplateLanguageConst::Bengali,  'name' => 'Bengali',           'position' => 5,  'code' => 'bn'],
			['id' => WaTemplateLanguageConst::Bulgarian,  'name' => 'Bulgarian',       'position' => 6,  'code' => 'bg'],
			['id' => WaTemplateLanguageConst::Catalan,  'name' => 'Catalan',           'position' => 7,  'code' => 'ca'],
			['id' => WaTemplateLanguageConst::Chinese_CHN,  'name' => 'Chinese (CHN)', 'position' => 8,  'code' => 'zh_CN'],
			['id' => WaTemplateLanguageConst::Chinese_HKG,  'name' => 'Chinese (HKG)', 'position' => 9,  'code' => 'zh_HK'],
			['id' => WaTemplateLanguageConst::Chinese_TAI,  'name' => 'Chinese (TAI)', 'position' => 10, 'code' => 'zh_TW'],
			['id' => WaTemplateLanguageConst::Croatian,  'name' => 'Croatian',         'position' => 11, 'code' => 'hr'],
			['id' => WaTemplateLanguageConst::Czech,  'name' => 'Czech',               'position' => 12, 'code' => 'cs'],
			['id' => WaTemplateLanguageConst::Danish,  'name' => 'Danish',             'position' => 13, 'code' => 'da'],
			['id' => WaTemplateLanguageConst::Dutch,  'name' => 'Dutch',               'position' => 14, 'code' => 'nl'],
			['id' => WaTemplateLanguageConst::English, 'name' => 'English',            'position' => 15, 'code' => 'en'],
			['id' => WaTemplateLanguageConst::English_UK, 'name' => 'English (UK)',    'position' => 16, 'code' => 'en_GB'],
			['id' => WaTemplateLanguageConst::English_US, 'name' => 'English (US)',    'position' => 17, 'code' => 'en_US'],
			['id' => WaTemplateLanguageConst::Estonian, 'name' => 'Estonian',          'position' => 18, 'code' => 'et'],
			['id' => WaTemplateLanguageConst::Filipino, 'name' => 'Filipino',          'position' => 19, 'code' => 'fil'],
			['id' => WaTemplateLanguageConst::Finnish, 'name' => 'Finnish',            'position' => 20, 'code' => 'fi'],
			['id' => WaTemplateLanguageConst::French, 'name' => 'French',              'position' => 21, 'code' => 'fr'],
			['id' => WaTemplateLanguageConst::German, 'name' => 'German',              'position' => 22, 'code' => 'de'],
			['id' => WaTemplateLanguageConst::Greek, 'name' => 'Greek',                'position' => 23, 'code' => 'el'],
			['id' => WaTemplateLanguageConst::Gujarati, 'name' => 'Gujarati',          'position' => 24, 'code' => 'gu'],
			['id' => WaTemplateLanguageConst::Hausa, 'name' => 'Hausa',                'position' => 25, 'code' => 'ha'],
			['id' => WaTemplateLanguageConst::Hebrew, 'name' => 'Hebrew',              'position' => 26, 'code' => 'he'],
			['id' => WaTemplateLanguageConst::Hindi, 'name' => 'Hindi',                'position' => 27, 'code' => 'hi'],
			['id' => WaTemplateLanguageConst::Hungarian, 'name' => 'Hungarian',        'position' => 28, 'code' => 'hu'],
			['id' => WaTemplateLanguageConst::Indonesian, 'name' => 'Indonesian',      'position' => 29, 'code' => 'id'],
			['id' => WaTemplateLanguageConst::Irish, 'name' => 'Irish',                'position' => 30, 'code' => 'ga'],
			['id' => WaTemplateLanguageConst::Italian, 'name' => 'Italian',            'position' => 31, 'code' => 'it'],
			['id' => WaTemplateLanguageConst::Japanese, 'name' => 'Japanese',          'position' => 32, 'code' => 'ja'],
			['id' => WaTemplateLanguageConst::Kannada, 'name' => 'Kannada',            'position' => 33, 'code' => 'kn'],
			['id' => WaTemplateLanguageConst::Kazakh, 'name' => 'Kazakh',              'position' => 34, 'code' => 'kk'],
			['id' => WaTemplateLanguageConst::Korean, 'name' => 'Korean',              'position' => 35, 'code' => 'ko'],
			['id' => WaTemplateLanguageConst::Lao, 'name' => 'Lao',                    'position' => 36, 'code' => 'lo'],
			['id' => WaTemplateLanguageConst::Latvian, 'name' => 'Latvian',            'position' => 37, 'code' => 'lv'],
			['id' => WaTemplateLanguageConst::Lithuanian, 'name' => 'Lithuanian',      'position' => 38, 'code' => 'lt'],
			['id' => WaTemplateLanguageConst::Macedonian, 'name' => 'Macedonian',      'position' => 39, 'code' => 'mk'],
			['id' => WaTemplateLanguageConst::Malay, 'name' => 'Malay',                'position' => 40, 'code' => 'ms'],
			['id' => WaTemplateLanguageConst::Malayalam, 'name' => 'Malayalam',        'position' => 41, 'code' => 'ml'],
			['id' => WaTemplateLanguageConst::Marathi, 'name' => 'Marathi',            'position' => 42, 'code' => 'mr'],
			['id' => WaTemplateLanguageConst::Norwegian, 'name' => 'Norwegian',        'position' => 43, 'code' => 'nb'],
			['id' => WaTemplateLanguageConst::Persian, 'name' => 'Persian',            'position' => 44, 'code' => 'fa'],
			['id' => WaTemplateLanguageConst::Polish, 'name' => 'Polish',              'position' => 45, 'code' => 'pl'],
			['id' => WaTemplateLanguageConst::Portuguese_BR, 'name' => 'Portuguese (BR)',   'position' => 46, 'code' => 'pt_BR'],
			['id' => WaTemplateLanguageConst::Portuguese_POR, 'name' => 'Portuguese (POR)', 'position' => 47, 'code' => 'pt_PT'],
			['id' => WaTemplateLanguageConst::Punjabi, 'name' => 'Punjabi',               	'position' => 48, 'code' => 'pa'],
			['id' => WaTemplateLanguageConst::Romanian, 'name' => 'Romanian',             	'position' => 49, 'code' => 'ro'],
			['id' => WaTemplateLanguageConst::Russian, 'name' => 'Russian',                 'position' => 50, 'code' => 'ru'],
			['id' => WaTemplateLanguageConst::Serbian, 'name' => 'Serbian',                 'position' => 51, 'code' => 'sr'],
			['id' => WaTemplateLanguageConst::Slovak, 'name' => 'Slovak',               	'position' => 52, 'code' => 'sk'],
			['id' => WaTemplateLanguageConst::Slovenian, 'name' => 'Slovenian',             'position' => 53, 'code' => 'sl'],
			['id' => WaTemplateLanguageConst::Spanish, 'name' => 'Spanish',              	'position' => 54, 'code' => 'es'],
			['id' => WaTemplateLanguageConst::Spanish_ARG, 'name' => 'Spanish (ARG)',       'position' => 55, 'code' => 'es_AR'],
			['id' => WaTemplateLanguageConst::Spanish_SPA, 'name' => 'Spanish (SPA)',       'position' => 56, 'code' => 'es_ES'],
			['id' => WaTemplateLanguageConst::Spanish_MEX, 'name' => 'Spanish (MEX)',       'position' => 57, 'code' => 'es_MX'],
			['id' => WaTemplateLanguageConst::Swahili, 'name' => 'Swahili',                 'position' => 58, 'code' => 'sw'],
			['id' => WaTemplateLanguageConst::Swedish, 'name' => 'Swedish',                 'position' => 59, 'code' => 'sv'],
			['id' => WaTemplateLanguageConst::Tamil, 'name' => 'Tamil',                 	'position' => 60, 'code' => 'ta'],
			['id' => WaTemplateLanguageConst::Telugu, 'name' => 'Telugu',               	'position' => 61, 'code' => 'te'],
			['id' => WaTemplateLanguageConst::Thai, 'name' => 'Thai',                 	 	'position' => 62, 'code' => 'th'],
			['id' => WaTemplateLanguageConst::Turkish, 'name' => 'Turkish',              	'position' => 63, 'code' => 'tr'],
			['id' => WaTemplateLanguageConst::Ukrainian, 'name' => 'Ukrainian',             'position' => 64, 'code' => 'uk'],
			['id' => WaTemplateLanguageConst::Urdu, 'name' => 'Urdu',                  		'position' => 65, 'code' => 'ur'],
			['id' => WaTemplateLanguageConst::Uzbek, 'name' => 'Uzbek',                		'position' => 66, 'code' => 'uz'],
			['id' => WaTemplateLanguageConst::Vietnamese, 'name' => 'Vietnamese',           'position' => 67, 'code' => 'vi'],
			['id' => WaTemplateLanguageConst::Zulu, 'name' => 'Zulu',                 		'position' => 68, 'code' => 'zu'],
		];

		DB::table('wa_template_languages')->insertOrIgnore($data);
	}

	protected function wa_template_statuses(): void
	{
		$data = [
			[
				'id'             => WaTemplateStatusConst::Draft,
				'name'           => 'Draft',
				'position'       => 1,
				'color'          => 'primary',
				'group_id'       => null,
				'is_final_stage' => false,
			],
			[
				'id'             => WaTemplateStatusConst::Pending,
				'name'           => 'Pending',
				'position'       => 2,
				'color'          => 'warning',
				'group_id'       => null,
				'is_final_stage' => false,
			],
			[
				'id'             => WaTemplateStatusConst::Approved,
				'name'           => 'Approved',
				'position'       => 3,
				'color'          => 'success',
				'group_id'       => null,
				'is_final_stage' => true,
			],
			[
				'id'             => WaTemplateStatusConst::Rejected,
				'name'           => 'Rejected',
				'position'       => 4,
				'color'          => 'danger',
				'group_id'       => WaTemplateStatusConst::Approved,
				'is_final_stage' => true,
			],
			[
				'id'             => WaTemplateStatusConst::Paused,
				'name'           => 'Paused',
				'position'       => 5,
				'color'          => 'warning',
				'group_id'       => WaTemplateStatusConst::Approved,
				'is_final_stage' => false,
			],
			[
				'id'             => WaTemplateStatusConst::Disabled,
				'name'           => 'Disabled',
				'position'       => 6,
				'color'          => 'secondary',
				'group_id'       => WaTemplateStatusConst::Approved,
				'is_final_stage' => true,
			],
		];
		DB::table('wa_template_statuses')->insertOrIgnore($data);
	}

	protected function wa_template_header_types(): void
	{
		$data = [
			[
				'id'       => WaTemplateHeaderTypeConst::Text,     
				'name'     => 'Text',     
				'position' => 1
			],
			[
				'id'       => WaTemplateHeaderTypeConst::Image,    
				'name'     => 'Image',    
				'position' => 2
			],
			[
				'id'       => WaTemplateHeaderTypeConst::Video,    
				'name'     => 'Video',    
				'position' => 3
			],
			[
				'id'       => WaTemplateHeaderTypeConst::Document, 
				'name'     => 'Document', 
				'position' => 4
			],
		];
		DB::table('wa_template_header_types')->insertOrIgnore($data);
	}
}
