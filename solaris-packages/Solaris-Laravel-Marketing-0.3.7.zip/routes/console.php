<?php

use Illuminate\Support\Facades\Schedule;
use Solaris\Marketing\Jobs\CampaignBlastQuotaAutoRenewJob;
use Solaris\Marketing\Jobs\EmailBlastSchedulerJob;
use Solaris\Marketing\Jobs\WaBlastSchedulerJob;
use Solaris\Marketing\Services\Email\EmailBlastService;
use Solaris\Marketing\Services\WhatsApp\WaBlastService;

Schedule::call(fn() => EmailBlastSchedulerJob::dispatch(now()->format('Y-m-d H:i')))
    ->everyMinute();

Schedule::call(fn() => EmailBlastService::processWebhook())
    ->everyThirtySeconds();

Schedule::call(fn() => WaBlastSchedulerJob::dispatch(now()->format('Y-m-d H:i')))
    ->everyMinute();

Schedule::call(fn() => WaBlastService::processWebhook())
    ->everyThirtySeconds();

Schedule::job(new CampaignBlastQuotaAutoRenewJob)->hourly()->onOneServer();