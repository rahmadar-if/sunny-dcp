<?php

use Illuminate\Support\Facades\Route;
use Solaris\Marketing\Http\Controllers\CampaignBlastQuotaController;
use Solaris\Marketing\Http\Controllers\EmailBlastWebhookController;
use Solaris\Core\Helpers\Helper;
use Solaris\Marketing\Http\Controllers\StripoPluginController;
use Solaris\Marketing\Http\Controllers\WaBlastWebhookController;
use Solaris\Marketing\Http\Controllers\WaTemplateDetailController;

Route::post('/marketing/email-blast/webhook', EmailBlastWebhookController::class)
    ->name('marketing.email-blast.webhook');

Route::post('/marketing/wa-blast/webhook', WaBlastWebhookController::class)
    ->name('marketing.wa-blast.webhook');

Route::get('/marketing/wa-template/media/{id}', [WaTemplateDetailController::class, 'previewMedia'])
    ->whereUuid('id')
    ->name('marketing.wa-template.media');

Route::prefix('marketing/stripo/image-storage')->group(function () {
    Route::get('/', [StripoPluginController::class, 'listFiles'])
        ->name('marketing.stripo.image-storage.list');

    Route::post('/', [StripoPluginController::class, 'uploadFile'])
        ->name('marketing.stripo.image-storage.upload');

    Route::post('/delete', [StripoPluginController::class, 'deleteFile'])
        ->name('marketing.stripo.image-storage.delete');

    Route::get('/info', [StripoPluginController::class, 'fileInfo'])
        ->name('marketing.stripo.image-storage.info');
});

Route::middleware(['auth', 'menu.access'])->group(function () {

    Route::prefix('marketing')->group(function () {
        Route::prefix('lead')->group(function () {
            $leadController = Helper::controller('lead');
    
            Route::get('/', [$leadController, 'index'])
                ->name('marketing.lead');
            
            Route::get('/{id}', [$leadController, 'show'])
                ->whereUuid('id')
                ->name('marketing.lead.read');
            
            Route::get('/edit/{id}', [$leadController, 'edit'])
                ->whereUuid('id')
                ->name('marketing.lead.edit');
        });

        Route::prefix('email-blast')->group(function () {
            $emailBlastController = Helper::controller('email_blast');

            Route::get('/', [$emailBlastController, 'index'])
                ->name('marketing.email-blast');

            Route::get('/{id}', [$emailBlastController, 'show'])
                ->whereUuid('id')
                ->name('marketing.email-blast.read');

            Route::get('/edit/{id}', [$emailBlastController, 'edit'])
                ->whereUuid('id')
                ->name('marketing.email-blast.edit');

            Route::get('/editor/{id}', [$emailBlastController, 'editor'])
                ->whereUuid('id')
                ->name('marketing.email-blast.editor');

            Route::get('/editor/preview/{id}', [$emailBlastController, 'editorPreview'])
                ->whereUuid('id')
                ->name('marketing.email-blast.editor.preview');

            Route::put('/editor/{id}', [$emailBlastController, 'update'])
                ->whereUuid('id')
                ->name('marketing.email-blast.editor.update');

            Route::post('/add-audience', [$emailBlastController, 'addAudience'])
                ->name('marketing.email-blast.add-audience');

            Route::post('/send-now', [$emailBlastController, 'sendNow'])
                ->name('marketing.email-blast.send-now');

            Route::post('/schedule', [$emailBlastController, 'schedule'])
                ->name('marketing.email-blast.schedule');

            Route::get('/available-schedule', [$emailBlastController, 'getAvailableSchedule'])
                ->name('marketing.email-blast.available-schedule');

            Route::post('/cancel-schedule', [$emailBlastController, 'cancelSchedule'])
                ->name('marketing.email-blast.cancel-schedule');

            Route::post('/test-email', [$emailBlastController, 'testEmail'])
                ->name('marketing.email-blast.test-email');
        });

        Route::prefix('wa-blast')->group(function () {
            $waBlastController = Helper::controller('wa_blast');

            Route::get('/', [$waBlastController, 'index'])
                ->name('marketing.wa-blast');

            Route::get('/template-param-columns', [$waBlastController, 'templateParamColumns'])
                ->name('marketing.wa-blast.template-param-columns');

            Route::get('/{id}', [$waBlastController, 'show'])
                ->whereUuid('id')
                ->name('marketing.wa-blast.read');

            Route::get('/edit/{id}', [$waBlastController, 'edit'])
                ->whereUuid('id')
                ->name('marketing.wa-blast.edit');

            Route::post('/add-audience', [$waBlastController, 'addAudience'])
                ->name('marketing.wa-blast.add-audience');

            Route::post('/send-now', [$waBlastController, 'sendNow'])
                ->name('marketing.wa-blast.send-now');

            Route::post('/send-test', [$waBlastController, 'sendTest'])
                ->name('marketing.wa-blast.send-test');

            Route::post('/schedule', [$waBlastController, 'schedule'])
                ->name('marketing.wa-blast.schedule');

            Route::get('/available-schedule', [$waBlastController, 'getAvailableSchedule'])
                ->name('marketing.wa-blast.available-schedule');

            Route::post('/cancel-schedule', [$waBlastController, 'cancelSchedule'])
                ->name('marketing.wa-blast.cancel-schedule');
        });

        Route::prefix('wa-template')->group(function () {
            $waTemplateController       = Helper::controller('wa_template');
            $waTemplateDetailController = Helper::controller('wa_template_detail');

            Route::get('/', [$waTemplateController, 'index'])
                ->name('marketing.wa-template');

            Route::get('/{id}', [$waTemplateController, 'show'])
                ->whereUuid('id')
                ->name('marketing.wa-template.read');

            Route::get('/edit/{id}', [$waTemplateController, 'edit'])
                ->whereUuid('id')
                ->name('marketing.wa-template.edit');

            Route::get('/detail/edit/{id}', [$waTemplateDetailController, 'edit'])
                ->whereUuid('id')
                ->name('marketing.wa-template.detail.edit');

            Route::post('/submit', [$waTemplateController, 'submitToMeta'])
                ->name('marketing.wa-template.submit');

            Route::post('/sync', [$waTemplateController, 'syncTemplate'])
                ->name('marketing.wa-template.sync');

            Route::post('/sync-all', [$waTemplateController, 'syncAllTemplates'])
                ->name('marketing.wa-template.sync-all');

            // Route::get('/submit/{id}', [$waTemplateController, 'submitToMeta'])
            //     ->name('marketing.wa-template.submit');

            Route::post('/update-media', [$waTemplateDetailController, 'updateMedia'])
                ->name('marketing.wa-template.update-media');
        });

        Route::prefix('event')->group(function () {
            $eventController = Helper::controller('event');

            Route::get('/', [$eventController, 'index'])
                ->name('marketing.event');

            Route::get('/{id}', [$eventController, 'show'])
                ->whereUuid('id')
                ->name('marketing.event.read');

            Route::get('/edit/{id}', [$eventController, 'edit'])
                ->whereUuid('id')
                ->name('marketing.event.edit');

            Route::post('/add-audience', [$eventController, 'addAudience'])
                ->name('marketing.event.add-audience');
        });

        Route::prefix('dashboard')->group(function () {
            $controller = Helper::controller('marketing_dashboard');

            Route::get('/', [$controller, 'index'])->name('marketing.dashboard');
            Route::post('/all', [$controller, 'all'])->name('marketing.dashboard.all');
        });

        Route::prefix('email-template')->group(function() {
            $controller = Helper::controller('email_template');

            Route::get('/', [$controller, 'index'])->name('marketing.email-template');
            Route::get('/editor', [$controller, 'new'])->name('marketing.email-template.new');
            Route::get('/editor/{id}', [$controller, 'edit'])->name('marketing.email-template.edit');
            Route::get('/picker', [$controller, 'listForPicker'])->name('marketing.email-template.picker');
        });

        Route::prefix('stripo')->group(function() {
            Route::get('/default-template', [StripoPluginController::class, 'getDefaultTemplate'])
                ->name('marketing.stripo.default-template');
            
            Route::post('/token', [StripoPluginController::class, 'getToken'])
                ->name('marketing.stripo.get-token');
            
            Route::post('/test-email', [StripoPluginController::class, 'testEmailTemplate'])
                ->name('marketing.stripo.test-email');
        });
    });

    Route::prefix('admin/marketing')->group(function() {
        Route::prefix('campaign-blast-quota')->group(function () {
            Route::get('/', [CampaignBlastQuotaController::class, 'index'])
                ->name('admin.marketing.campaign-blast-quota');

            Route::post('/', [CampaignBlastQuotaController::class, 'store'])
                ->name('admin.marketing.campaign-blast-quota.store');

            Route::get('/{id}', [CampaignBlastQuotaController::class, 'show'])
                ->whereUuid('id')
                ->name('admin.marketing.campaign-blast-quota.read');

            Route::get('/{id}/usage/groups', [CampaignBlastQuotaController::class, 'usageGroups'])
                ->whereUuid('id')
                ->name('admin.marketing.campaign-blast-quota.usage-groups');

            Route::post('/{id}/disable-auto-renew', [CampaignBlastQuotaController::class, 'disableAutoRenew'])
                ->whereUuid('id')
                ->name('admin.marketing.campaign-blast-quota.disable-auto-renew');

            Route::delete('/{id}', [CampaignBlastQuotaController::class, 'destroy'])
                ->whereUuid('id')
                ->name('admin.marketing.campaign-blast-quota.destroy');
        });
    });

});