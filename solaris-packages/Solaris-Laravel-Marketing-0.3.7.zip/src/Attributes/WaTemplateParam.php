<?php

namespace Solaris\Marketing\Attributes;

use Attribute;

#[Attribute(Attribute::TARGET_CLASS)]
class WaTemplateParam
{
	public function __construct(
		public readonly array $include = [],
		public readonly array $exclude = [],
		public readonly bool  $extend  = false,
	) {}

	public function merge(self $parent): static
	{
		return new static(
			include: array_unique(array_merge($parent->include, $this->include)),
			exclude: array_unique(array_merge($parent->exclude, $this->exclude)),
			extend: false,
		);
	}
}
