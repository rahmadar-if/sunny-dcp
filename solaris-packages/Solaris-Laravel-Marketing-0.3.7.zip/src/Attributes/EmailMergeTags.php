<?php

namespace Solaris\Marketing\Attributes;

use Attribute;

#[Attribute(Attribute::TARGET_CLASS)]
class EmailMergeTags
{
	public function __construct(
		public readonly array $exclude = [],
		public readonly bool $extend   = false,
	) {}

	public function merge(self $parent): static
	{
		return new static(
			exclude: array_unique(array_merge($parent->exclude, $this->exclude)),
			extend: false,
		);
	}
}
