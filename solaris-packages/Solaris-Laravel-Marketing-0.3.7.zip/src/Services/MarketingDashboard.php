<?php

namespace Solaris\Marketing\Services;

class MarketingDashboard
{
    public static function all(array $period): array
    {
        return [];
    }
}