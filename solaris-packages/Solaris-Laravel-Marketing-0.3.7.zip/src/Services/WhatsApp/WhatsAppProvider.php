<?php

namespace Solaris\Marketing\Services\WhatsApp;

use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Client\Pool;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Solaris\Core\Interfaces\Model\SolarisUser;
use Solaris\Marketing\Const\WaBlastAudienceStatusConst;
use Solaris\Marketing\Models\WaBlast;
use Solaris\Marketing\Models\WaTemplateDetail;
use Solaris\Marketing\Services\WhatsApp\Interfaces\HasBlastSupport;

abstract class WhatsAppProvider implements HasBlastSupport
{
	protected array $config 		   = [];
	protected ?SolarisUser $authUser   = null;
	protected ?WaBlast $blastCampaign  = null;
	protected array $blastQuotas 	   = [];
	protected string $webhookPayload   = '';
	protected array $webhookHeader    = [];

	public static string $blastPhoneColumn = 'primary_mobile_phone';

	public static string $eventSent      = 'sent';
	public static string $eventDelivered = 'delivered';
	public static string $eventRead      = 'read';
	public static string $eventReplied   = 'replied';
	public static string $eventFailed    = 'failed';

	abstract protected function getConfig(): array;

	public static function forBlast(WaBlast|string $campaign, SolarisUser $user): static
	{
		$instance         = new static();
		$instance->config = $instance->getConfig();

		if (!$instance->config) {
			throw new \Exception("WhatsApp blast provider is not found");
		}

		$instance->blastCampaign = WaBlastService::resolveCampaign($campaign);
		if (is_null($instance->blastCampaign)) {
			throw new \Exception("WhatsApp blast campaign not found");
		}

		$instance->authUser    = $user;
		$instance->blastQuotas = json_decode($instance->blastCampaign->quotas, true);

		return $instance;
	}

	public static function forTemplate(SolarisUser $user): static
	{
		$instance         = new static();
		$instance->config = $instance->getConfig();

		if (!$instance->config) {
			throw new \Exception("WhatsApp template provider is not found");
		}

		$instance->authUser = $user;

		return $instance;
	}

	public static function forWebhook(string $webhookPayload, array $webhookHeader = []): static
	{
		$instance                 = new static();
		$instance->config         = $instance->getConfig();
		$instance->webhookPayload = $webhookPayload;
		$instance->webhookHeader  = $webhookHeader;

		return $instance;
	}

	final public static function send(
		string $phone,
		Model $contact,
		WaTemplateDetail $waTemplateDetail,
		array $rawParams
	): array {
		$instance         = new static();
		$instance->config = $instance->getConfig();

		$templateParams = $instance->resolveTemplateParams($rawParams, $contact);
		$response       = $instance->buildSendRequest(Http::getFacadeRoot(), $phone, $waTemplateDetail, $templateParams);

		return [
			'success' => $instance->isSuccessSendResponse($response),
			'message' => $instance->getSendResponseMessage($response),
		];
	}

	protected function getChunkSize(): int
	{
		return $this->config['chunk_size'] ?? 100;
	}

	protected function getRateLimit(): int
	{
		return $this->config['rate_limit'] ?? 10;
	}

	final public function blast(): void
	{
		$waTemplateDetail = $this->blastCampaign->wa_template_detail;
		$rawParams        = json_decode($this->blastCampaign->template_params ?? '{}', true) ?? [];
		$maxPool          = $this->getRateLimit();

		$dataSourceColumns = [];
		foreach ($rawParams as $sectionParams) {
			foreach ($sectionParams as $paramData) {
				if (($paramData['source'] ?? '') === 'data_source' && !empty($paramData['value'])) {
					$dataSourceColumns[] = $paramData['value'];
				}
			}
		}
		$contactColumns  = array_unique(array_merge([static::$blastPhoneColumn], $dataSourceColumns));
		$contactPrepared = 'contact[' . implode(', ', $contactColumns) . ']';

		$success = false;
		$message = null;

		WaBlastService::updateToSending($this->blastCampaign, $this->authUser);

		try {
			$this->blastCampaign->audiences()
				->where("wa_blast_id", $this->blastCampaign->id)
				->whereHas('contact', fn($q) => $q->whereNull(static::$blastPhoneColumn)->orWhere(static::$blastPhoneColumn, ''))
				->update([
					'status_id' => WaBlastAudienceStatusConst::Failed,
					'message' 	=> 'Mobile phone number is empty'
				]);

			do {
				$audiences = $this->blastCampaign->audiences()->prepared($contactPrepared, "status_id")
					->where("wa_blast_id", $this->blastCampaign->id)
					->blastable(static::$blastPhoneColumn)
					->sort("contact." . static::$blastPhoneColumn . ":asc")
					->limit($this->getChunkSize())
					->get();

				if($audiences->isEmpty()) {
					break;
				}

				$this->sendBatchRequest($audiences, $waTemplateDetail, $rawParams, $maxPool);

				WaBlastService::updateCampaignTotals($this->blastCampaign->id);
			} while (true);

			$success = true;
		} catch (\Throwable $e) {
			$message = $e->getMessage();

			Log::error("WhatsApp Blast Process fail", [
				'message'   => $message,
				'exception' => $e
			]);
		}

		WaBlastService::updateToCompleted($this->blastCampaign, $this->authUser, $this->blastQuotas, $success, $message);
	}

	private function sendBatchRequest(Collection $audiences, WaTemplateDetail $waTemplateDetail, array $rawParams, int $maxPool): void
	{
		$pools = [];

		foreach ($audiences as $audience) {
			if (empty($audience->contact?->{static::$blastPhoneColumn})) {
				continue;
			}

			$pools[] = [
				'id'             => $audience->id,
				'phone'          => $audience->contact->{static::$blastPhoneColumn},
				'templateParams' => $this->resolveTemplateParams($rawParams, $audience->contact),
			];

			if (count($pools) == $maxPool) {
				$this->commitPool($this->sendRequest($pools, $waTemplateDetail));
				$pools = [];
			}
		}

		if (!empty($pools)) {
			$this->commitPool($this->sendRequest($pools, $waTemplateDetail));
		}
	}

	private function commitPool(array $responses): void
	{
		if (empty($responses)) {
			return;
		}

		$this->blastQuotas = WaBlastService::updateAudiences(
			$this->blastCampaign->id,
			$this->blastQuotas,
			$responses,
			$this->authUser?->id
		);
	}

	private function sendRequest(array $requestPools, WaTemplateDetail $waTemplateDetail): array
	{
		$results = [];
		$start   = microtime(true);

		$responses = Http::pool(fn (Pool $pool) => array_map(fn (array $request) => $this->buildSendRequest(
			$pool->as($request['id']),
			$request['phone'],
			$waTemplateDetail,
			$request['templateParams']
		), $requestPools));

		foreach ($responses as $key => $response) {
			$results[] = $this->resolveBlastResponse($key, $response)->toArray();
		}

		$elapsed = microtime(true) - $start;
		if ($elapsed < 1) {
			usleep((int)((1 - $elapsed) * 1000000));
		}

		return $results;
	}

	private function resolveBlastResponse(string $audienceId, Response|\Throwable $response): BlastAudienceResponse
	{
		if ($response instanceof \Throwable) {
			return new BlastAudienceResponse(
				audienceId: $audienceId,
				waBlastId : $this->blastCampaign->id,
				statusId  : WaBlastAudienceStatusConst::Failed,
				message   : $response->getMessage(),
			);
		}

		return $this->mappingBlastResponse($audienceId, $this->blastCampaign->id, $response);
	}

	protected function resolveTemplateParams(array $rawParams, Model $contact): array
	{
		$resolved = [];

		foreach ($rawParams as $sectionKey => $sectionParams) {
			ksort($sectionParams, SORT_NUMERIC);
			$resolved[$sectionKey] = [];

			foreach ($sectionParams as $paramIndex => $paramData) {
				$source     = $paramData['source'] ?? 'hardcode';
				$fieldOrVal = $paramData['value'] ?? '';

				if ($source === 'data_source' && !empty($fieldOrVal)) {
					$contactValue = $this->resolveContactValue($contact, $fieldOrVal);
					$resolved[$sectionKey][$paramIndex] = $contactValue !== ''
						? $contactValue
						: (string) ($paramData['default_value'] ?? '');
				} else {
					$resolved[$sectionKey][$paramIndex] = (string) $fieldOrVal;
				}
			}
		}

		return $resolved;
	}

	private function resolveContactValue(Model $contact, string $field): string
	{
		$parts = explode('.', $field);
		$value = $contact;

		foreach ($parts as $part) {
			if (!($value instanceof Model)) {
				return '';
			}

			$value = $value->{$part};

			if (is_null($value)) {
				return '';
			}
		}

		if ($value instanceof Model) {
			return (string) ($value->getDisplayValue() ?? '');
		}

		return (string) $value;
	}

}
