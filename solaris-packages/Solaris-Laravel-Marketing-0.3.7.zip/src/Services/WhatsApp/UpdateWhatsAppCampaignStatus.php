<?php

namespace Solaris\Marketing\Services\WhatsApp;

use Illuminate\Support\Facades\DB;
use Solaris\Marketing\Const\WaBlastAudienceStatusConst;

class UpdateWhatsAppCampaignStatus
{
	public static function updateStatus(array $waBlastIds): void
	{
		$driver = DB::connection()->getDriverName();

		switch ($driver) {
			case 'mysql':
			case 'mariadb':
				static::updateStatusMySQL($waBlastIds);
				break;

			case 'pgsql':
				static::updateStatusPostgreSQL($waBlastIds);
				break;

			case 'sqlsrv':
				static::updateStatusSQLServer($waBlastIds);
				break;

			default:
				throw new \Exception("Unsupported database driver: {$driver}");
		}
	}

	public static function updateAudienceProgress(string $waBlastId): void
	{
		$driver = DB::connection()->getDriverName();

		switch ($driver) {
			case 'mysql':
			case 'mariadb':
				static::updateAudienceProgressMySQL($waBlastId);
				break;

			case 'pgsql':
				static::updateAudienceProgressPostgreSQL($waBlastId);
				break;

			case 'sqlsrv':
				static::updateAudienceProgressSQLServer($waBlastId);
				break;

			default:
				throw new \Exception("Unsupported database driver: {$driver}");
		}
	}

	private static function updateStatusMySQL(array $waBlastIds): void
	{
		$placeholders = implode(',', array_fill(0, count($waBlastIds), '?'));
		$query        = "UPDATE wa_blasts wb
			INNER JOIN (
				SELECT
					wa_blast_id,
					SUM(CASE WHEN status_id IN (?, ?, ?) THEN 1 ELSE 0 END) as total_success,
					SUM(CASE WHEN status_id = ? THEN 1 ELSE 0 END) as total_fail,
					SUM(CASE WHEN status_id = ? THEN 1 ELSE 0 END) as total_read,
					SUM(CASE WHEN replied IS NOT NULL THEN 1 ELSE 0 END) as total_replied,
					SUM(CASE WHEN status_id = ? THEN 1 ELSE 0 END) as total_pending,
					SUM(CASE WHEN status_id = ? THEN 1 ELSE 0 END) as total_progress
				FROM wa_blast_audiences
				WHERE wa_blast_id IN ({$placeholders})
				GROUP BY wa_blast_id
			) temp ON wb.id = temp.wa_blast_id
			SET
				wb.total_success  = temp.total_success,
				wb.total_fail     = temp.total_fail,
				wb.total_read     = temp.total_read,
				wb.total_replied  = temp.total_replied,
				wb.total_pending  = temp.total_pending,
				wb.total_progress = temp.total_progress";

		DB::statement($query, array_merge([
			WaBlastAudienceStatusConst::Sent,
			WaBlastAudienceStatusConst::Delivered,
			WaBlastAudienceStatusConst::Read,
			WaBlastAudienceStatusConst::Failed,
			WaBlastAudienceStatusConst::Read,
			WaBlastAudienceStatusConst::Pending,
			WaBlastAudienceStatusConst::Progress
		], $waBlastIds));
	}

	private static function updateStatusPostgreSQL(array $waBlastIds): void
	{
		$placeholders = implode(',', array_fill(0, count($waBlastIds), '?'));
		$query        = "UPDATE wa_blasts
			SET
				total_success  = temp.total_success,
				total_fail     = temp.total_fail,
				total_read     = temp.total_read,
				total_replied  = temp.total_replied,
				total_pending  = temp.total_pending,
				total_progress = temp.total_progress
			FROM (
				SELECT
					wa_blast_id,
					SUM(CASE WHEN status_id IN (?, ?, ?) THEN 1 ELSE 0 END) as total_success,
					SUM(CASE WHEN status_id = ? THEN 1 ELSE 0 END) as total_fail,
					SUM(CASE WHEN status_id = ? THEN 1 ELSE 0 END) as total_read,
					SUM(CASE WHEN replied IS NOT NULL THEN 1 ELSE 0 END) as total_replied,
					SUM(CASE WHEN status_id = ? THEN 1 ELSE 0 END) as total_pending,
					SUM(CASE WHEN status_id = ? THEN 1 ELSE 0 END) as total_progress
				FROM wa_blast_audiences
				WHERE wa_blast_id IN ({$placeholders})
				GROUP BY wa_blast_id
			) temp
			WHERE wa_blasts.id = temp.wa_blast_id";

		DB::statement($query, array_merge([
			WaBlastAudienceStatusConst::Sent,
			WaBlastAudienceStatusConst::Delivered,
			WaBlastAudienceStatusConst::Read,
			WaBlastAudienceStatusConst::Failed,
			WaBlastAudienceStatusConst::Read,
			WaBlastAudienceStatusConst::Pending,
			WaBlastAudienceStatusConst::Progress
		], $waBlastIds));
	}

	private static function updateStatusSQLServer(array $waBlastIds): void
	{
		$placeholders = implode(',', array_fill(0, count($waBlastIds), '?'));
		$query        = "UPDATE wb
			SET
				wb.total_success  = temp.total_success,
				wb.total_fail     = temp.total_fail,
				wb.total_read     = temp.total_read,
				wb.total_replied  = temp.total_replied,
				wb.total_pending  = temp.total_pending,
				wb.total_progress = temp.total_progress
			FROM wa_blasts wb
			INNER JOIN (
				SELECT
					wa_blast_id,
					SUM(CASE WHEN status_id IN (?, ?, ?) THEN 1 ELSE 0 END) as total_success,
					SUM(CASE WHEN status_id = ? THEN 1 ELSE 0 END) as total_fail,
					SUM(CASE WHEN status_id = ? THEN 1 ELSE 0 END) as total_read,
					SUM(CASE WHEN replied IS NOT NULL THEN 1 ELSE 0 END) as total_replied,
					SUM(CASE WHEN status_id = ? THEN 1 ELSE 0 END) as total_pending,
					SUM(CASE WHEN status_id = ? THEN 1 ELSE 0 END) as total_progress
				FROM wa_blast_audiences
				WHERE wa_blast_id IN ({$placeholders})
				GROUP BY wa_blast_id
			) temp ON wb.id = temp.wa_blast_id";

		DB::statement($query, array_merge([
			WaBlastAudienceStatusConst::Sent,
			WaBlastAudienceStatusConst::Delivered,
			WaBlastAudienceStatusConst::Read,
			WaBlastAudienceStatusConst::Failed,
			WaBlastAudienceStatusConst::Read,
			WaBlastAudienceStatusConst::Pending,
			WaBlastAudienceStatusConst::Progress
		], $waBlastIds));
	}

	private static function updateAudienceProgressMySQL(string $waBlastId): void
	{
		DB::statement("
			UPDATE wa_blast_audiences audience
			INNER JOIN wa_blast_audience_temp temp
				ON audience.id = temp.id
			SET
				status_id  = temp.status_id,
				message_id = temp.message_id,
				message    = temp.message
			WHERE temp.wa_blast_id = ?
		", [$waBlastId]);
	}

	private static function updateAudienceProgressPostgreSQL(string $waBlastId): void
	{
		DB::statement("
			UPDATE wa_blast_audiences audience
			SET
				status_id  = temp.status_id,
				message_id = temp.message_id,
				message    = temp.message
			FROM wa_blast_audience_temp temp
			WHERE audience.id = temp.id
			AND temp.wa_blast_id = ?
		", [$waBlastId]);
	}

	private static function updateAudienceProgressSQLServer(string $waBlastId): void
	{
		DB::statement("
			UPDATE wa_blast_audiences
			SET
				status_id  = temp.status_id,
				message_id = temp.message_id,
				message    = temp.message
			FROM wa_blast_audiences audience
			INNER JOIN wa_blast_audience_temp temp
				ON audience.id = temp.id
			WHERE temp.wa_blast_id = ?
		", [$waBlastId]);
	}
}
