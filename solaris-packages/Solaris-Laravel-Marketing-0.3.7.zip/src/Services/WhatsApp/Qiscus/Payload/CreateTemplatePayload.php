<?php

namespace Solaris\Marketing\Services\WhatsApp\Qiscus\Payload;

use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Str;
use Solaris\Marketing\Const\WaTemplateCategoryConst;
use Solaris\Marketing\Const\WaTemplateHeaderTypeConst;
use Solaris\Marketing\Const\WaTemplateSubTypeConst;
use Solaris\Marketing\Models\WaTemplate;
use Solaris\Marketing\Models\WaTemplateDetail;

class CreateTemplatePayload
{
	public static function build(WaTemplate $waTemplate, Collection $waTemplateDetails, string $channelId): array
	{
		return [
			"have_template" => false,
			"name"          => preg_replace('/[^a-z0-9_]/', '', Str::snake($waTemplate->name)),
			"category"      => strtoupper($waTemplate->category->name),
			"channel_id"    => (int)$channelId,
			"namespace"     => null,
			"hsm_details"   => $waTemplateDetails->map(fn($item) => array_merge(
				self::resolveType($item),
				["language" => $item->language->code]
			))->toArray()
		];
	}

	private static function resolveType(WaTemplateDetail $waTemplateDetail): array
	{
		$isRegular = in_array($waTemplateDetail->wa_template->category_id, [WaTemplateCategoryConst::Utility, WaTemplateCategoryConst::Marketing])
			&& $waTemplateDetail->sub_type_id == WaTemplateSubTypeConst::Regular;

		$isCarousel = $waTemplateDetail->wa_template->category_id == WaTemplateCategoryConst::Marketing
			&& $waTemplateDetail->sub_type_id == WaTemplateSubTypeConst::Carousel;

		$isAuth = $waTemplateDetail->wa_template->category_id == WaTemplateCategoryConst::Authentication;

		return match (true) {
			$isRegular  => self::regular($waTemplateDetail),
			$isCarousel => self::carousel($waTemplateDetail),
			$isAuth     => self::authentication($waTemplateDetail),
			default     => throw new \Exception("Category is not supported")
		};
	}

	private static function regular(WaTemplateDetail $waTemplateDetail): array
	{
		$payload = [
			"header_type" => $waTemplateDetail->header_type ? strtolower($waTemplateDetail->header_type->name) : null,
			"content"     => $waTemplateDetail->body,
			"footer"      => !empty($waTemplateDetail->footer) ? $waTemplateDetail->footer : null
		];

		$headerKey = $waTemplateDetail->header_type_id == WaTemplateHeaderTypeConst::Text ? "header_content" : "header_default_value";
		$payload[$headerKey] = $waTemplateDetail->header_content;

		if ($waTemplateDetail->header_examples) {
			$payload["header_sample"] = array_values(json_decode($waTemplateDetail->header_examples, true));
		}

		if ($waTemplateDetail->body_examples) {
			$payload["body_sample"] = array_values(json_decode($waTemplateDetail->body_examples, true));
		}

		if ($waTemplateDetail->buttons) {
			$payload["buttons"] = array_map(fn($item) => self::resolveButton($item), json_decode($waTemplateDetail->buttons, true));
		}

		return $payload;
	}

	private static function carousel(WaTemplateDetail $waTemplateDetail): array
	{
		$payload = [
			"content" => $waTemplateDetail->body,
		];

		if ($waTemplateDetail->body_examples) {
			$payload["body_sample"] = array_values(json_decode($waTemplateDetail->body_examples, true));
		}

		if ($waTemplateDetail->cards) {
			$headerType = strtolower($waTemplateDetail->header_type->name);
			$payload["cards"] = array_map(function($item) use($headerType) {
				return [
					"header" => [
						"format"  => $headerType,
						"example" => $item["header_content"]
					],
					"body" => [
						"content"  => $item["body"],
						"examples" => array_values($item["body_examples"])
					],
					"buttons" => json_encode(array_map(fn($item) => self::resolveButton($item), $item["buttons"]))
				];
			}, json_decode($waTemplateDetail->cards, true));
		}

		return $payload;
	}

	private static function authentication(WaTemplateDetail $waTemplateDetail): array
	{
		return [
			"content" => [
				"add_security_recommendation" => $waTemplateDetail->disclaimer,
			],
			"footer" => [
				"code_expiration_minutes" => (string)$waTemplateDetail->expirty_minutes
			],
			"button_type" => "OTP",
			"buttons"     => [
				"type"     => "OTP",
				"otp_type" => "COPY_CODE",
				"text"     => "",
			]
		];
	}

	private static function resolveButton(array $button): array
	{
		return match ($button["type"]) {
			"quick_reply"  => self::quickReplyButton($button),
			"url"          => self::urlButton($button),
			"phone_number" => self::phoneNumberButton($button),
			"copy_code"    => self::copyButton($button)
		};
	}

	private static function quickReplyButton(array $button): array
	{
		return [
			"type" => strtoupper($button["type"]),
			"text" => $button["label"],
		];
	}

	private static function phoneNumberButton(array $button): array
	{
		return [
			"type"         => strtoupper($button["type"]),
			"text"         => $button["label"],
			"phone_number" => $button["value"],
		];
	}

	private static function urlButton(array $button): array
	{
		return [
			"type"    => strtoupper($button["type"]),
			"text"    => $button["label"],
			"url"     => $button["value"],
			"example" => !empty($button["url_example"]) ? [str_replace("{{1}}", $button["url_example"], $button["value"])] : []
		];
	}

	private static function copyButton(array $button): array
	{
		return [
			"type"    => strtoupper($button["type"]),
			"text"    => $button["label"],
			"example" => [$button["value"]]
		];
	}
}
