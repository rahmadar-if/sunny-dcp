<?php

namespace Solaris\Marketing\Services\WhatsApp\Qiscus\Payload;

use Solaris\Marketing\Const\WaTemplateSubTypeConst;
use Solaris\Marketing\Models\WaTemplateDetail;

class SendMessagePayload
{
	public static function build(
		string $blastTitle,
		string $phone,
		WaTemplateDetail $waTemplateDetail,
		array $templateParams
	): array {
		$custom     = json_decode($waTemplateDetail->wa_template->custom ?? '{}', true);
		$isCarousel = $waTemplateDetail->sub_type_id === WaTemplateSubTypeConst::Carousel;

		$payload = [
			"channel_id"    => $custom['channel_id'],
			"name"          => $blastTitle,
			"template_name" => $waTemplateDetail->wa_template->template_name,
			"namespace"     => $custom['namespace'],
			"language"      => $waTemplateDetail->language->code,
			"variables"     => array_values($templateParams['body'] ?? []),
			"phone_number"  => self::normalizePhone($phone),
			"started_at"    => null,
			"is_mmlite"     => true,
		];

		if ($isCarousel) {
			$payload["button_params"] = null;
			$payload["card_payload"]  = self::buildCardPayload($waTemplateDetail, $templateParams);
			$payload["card_button"]   = self::buildCardButton($waTemplateDetail, $templateParams);
		} else {
			$payload["button_params"] = self::buildButtonParams($waTemplateDetail, $templateParams);
		}

		return $payload;
	}

	private static function normalizePhone(string $phone): string
	{
		$phone = preg_replace('/[^\d+]/', '', $phone);
		$phone = ltrim($phone, '+');

		if (str_starts_with($phone, '08')) {
			$phone = '62' . substr($phone, 1);
		}

		return $phone;
	}

	private static function buildButtonParams(WaTemplateDetail $detail, array $params): ?array
	{
		$buttons = json_decode($detail->buttons ?? '[]', true) ?? [];
		if (empty($buttons)) {
			return null;
		}

		$result = [];
		foreach ($buttons as $index => $btn) {
			$sectionKey = "button_{$index}";
			$values     = array_values($params[$sectionKey] ?? []);

			if (empty($values)) {
				continue;
			}

			$result[] = [
				'type'   => $btn['type'],
				'values' => $btn['type'] === 'url' ? rawurlencode($values[0]) : $values[0],
				'index'  => $index,
			];
		}

		return $result ?: null;
	}

	private static function buildCardPayload(WaTemplateDetail $detail, array $params): ?array
	{
		$cards = json_decode($detail->cards ?? '[]', true) ?? [];
		if (empty($cards)) {
			return null;
		}

		return array_map(function ($card, $cardIndex) use ($params) {
			$sectionKey = "card_{$cardIndex}_body";
			return array_values($params[$sectionKey] ?? []);
		}, $cards, array_keys($cards));
	}

	private static function buildCardButton(WaTemplateDetail $detail, array $params): ?array
	{
		$cards = json_decode($detail->cards ?? '[]', true) ?? [];
		if (empty($cards)) {
			return null;
		}

		return array_map(function ($card, $cardIndex) use ($params) {
			$buttons = $card['buttons'] ?? [];
			$result  = [];

			foreach ($buttons as $btnIndex => $btn) {
				if ($btn['type'] !== 'url') {
					continue;
				}

				$sectionKey = "card_{$cardIndex}_button_{$btnIndex}";
				$values     = array_values($params[$sectionKey] ?? []);

				if (empty($values)) {
					continue;
				}

				$result[] = [
					'index'  => $btnIndex,
					'type'   => 'url',
					'values' => $values[0],
				];
			}

			return $result;
		}, $cards, array_keys($cards));
	}
}
