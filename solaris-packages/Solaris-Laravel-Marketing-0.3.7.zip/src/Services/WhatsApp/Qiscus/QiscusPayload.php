<?php

namespace Solaris\Marketing\Services\WhatsApp\Qiscus;

use Illuminate\Database\Eloquent\Collection;
use Solaris\Marketing\Models\WaTemplate;
use Solaris\Marketing\Models\WaTemplateDetail;
use Solaris\Marketing\Services\WhatsApp\Qiscus\Payload\CreateTemplatePayload;
use Solaris\Marketing\Services\WhatsApp\Qiscus\Payload\SendMessagePayload;

class QiscusPayload
{
	public static function createTemplate(WaTemplate $waTemplate, Collection $waTemplateDetails, string $channelId): array
	{
		return CreateTemplatePayload::build($waTemplate, $waTemplateDetails, $channelId);
	}

	public static function sendMessage(
		string $blastTitle,
		string $phone,
		WaTemplateDetail $waTemplateDetail,
		array $templateParams
	): array {
		return SendMessagePayload::build($blastTitle, $phone, $waTemplateDetail, $templateParams);
	}
}
