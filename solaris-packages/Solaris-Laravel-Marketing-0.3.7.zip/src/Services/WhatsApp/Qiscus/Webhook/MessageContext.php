<?php

namespace Solaris\Marketing\Services\WhatsApp\Qiscus\Webhook;

final readonly class MessageContext
{
	public function __construct(
		public string $from,
		public string $id,
	) {}

	public static function from(array $data): self
	{
		return new self(
			from: $data['from'] ?? '',
			id  : $data['id'] ?? '',
		);
	}
}
