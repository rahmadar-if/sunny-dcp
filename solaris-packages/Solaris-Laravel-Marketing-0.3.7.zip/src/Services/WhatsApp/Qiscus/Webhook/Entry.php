<?php

namespace Solaris\Marketing\Services\WhatsApp\Qiscus\Webhook;

final readonly class Entry
{
	public function __construct(
		public string $id,
		public array $changes,
	) {}

	public static function from(array $data): self
	{
		return new self(
			id     : $data['id'] ?? '',
			changes: array_map(fn(array $c) => Change::from($c), $data['changes'] ?? []),
		);
	}
}
