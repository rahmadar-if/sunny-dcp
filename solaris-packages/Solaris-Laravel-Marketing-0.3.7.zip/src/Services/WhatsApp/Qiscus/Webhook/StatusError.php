<?php

namespace Solaris\Marketing\Services\WhatsApp\Qiscus\Webhook;

final readonly class StatusError
{
	public function __construct(
		public int $code,
		public string $message,
		public string $title,
		public ?string $details,
	) {}

	public static function from(array $data): self
	{
		return new self(
			code   : (int) ($data['code'] ?? 0),
			message: $data['message'] ?? '',
			title  : $data['title'] ?? '',
			details: $data['error_data']['details'] ?? null,
		);
	}
}
