<?php

namespace Solaris\Marketing\Services\WhatsApp\Qiscus\Webhook;

final readonly class UserAction
{
	public function __construct(
		public string $actionType,
		public string $timestamp,
		public ?LinkClickData $linkClickData,
	) {}

	public static function from(array $data): self
	{
		return new self(
			actionType   : $data['action_type'] ?? '',
			timestamp    : (string) ($data['timestamp'] ?? ''),
			linkClickData: isset($data['marketing_messages_link_click_data'])
				? LinkClickData::from($data['marketing_messages_link_click_data'])
				: null,
		);
	}
}
