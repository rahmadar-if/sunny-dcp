<?php

namespace Solaris\Marketing\Services\WhatsApp\Qiscus\Webhook;

final readonly class LinkClickData
{
	public function __construct(
		public string $clickComponent,
		public string $clickId,
		public string $trackingToken,
	) {}

	public static function from(array $data): self
	{
		return new self(
			clickComponent: $data['click_component'] ?? '',
			clickId       : $data['click_id'] ?? '',
			trackingToken : $data['tracking_token'] ?? '',
		);
	}
}
