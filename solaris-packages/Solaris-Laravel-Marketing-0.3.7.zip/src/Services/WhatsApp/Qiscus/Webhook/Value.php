<?php

namespace Solaris\Marketing\Services\WhatsApp\Qiscus\Webhook;

final readonly class Value
{
	private const VALID_STATUSES = ['sent', 'delivered', 'read', 'failed'];

	public function __construct(
		public string $messagingProduct,
		public Metadata $metadata,
		public array $contacts,
		public array $statuses,
		public array $messages,
		public array $userActions,
	) {}

	public static function from(array $data): self
	{
		return new self(
			messagingProduct: $data['messaging_product'] ?? '',
			metadata        : Metadata::from($data['metadata'] ?? []),
			contacts        : array_map(fn(array $c) => Contact::from($c), $data['contacts'] ?? []),
			statuses        : array_map(fn(array $s) => StatusEntry::from($s), $data['statuses'] ?? []),
			messages        : array_map(fn(array $m) => MessageEntry::from($m), $data['messages'] ?? []),
			userActions     : array_map(fn(array $a) => UserAction::from($a), $data['user_actions'] ?? []),
		);
	}

	public function getMessageId(): string
	{
		if (!empty($this->statuses)) {
			return $this->statuses[0]->id;
		}

		if (!empty($this->messages)) {
			return $this->messages[0]->context?->id ?? '';
		}

		return '';
	}

	public function getEventType(): string
	{
		if (!empty($this->statuses)) {
			$status = $this->statuses[0]->status;
			return in_array($status, self::VALID_STATUSES, true) ? $status : '';
		}

		if (!empty($this->messages) && $this->messages[0]->type === 'button') {
			return 'replied';
		}

		if (!empty($this->userActions)) {
			return 'clicked';
		}

		return '';
	}

	public function isSuccess(): bool
	{
		if (!empty($this->statuses)) {
			return $this->statuses[0]->status !== 'failed';
		}

		return true;
	}

	public function getErrorMessage(): ?string
	{
		if (empty($this->statuses) || $this->statuses[0]->status !== 'failed') {
			return null;
		}

		return $this->statuses[0]->errors[0]->message ?? null;
	}

	public function getButtonPayload(): ?string
	{
		if (empty($this->messages) || $this->messages[0]->type !== 'button') {
			return null;
		}

		return $this->messages[0]->button?->payload;
	}
}
