<?php

namespace Solaris\Marketing\Services\WhatsApp\Qiscus\Webhook;

final readonly class MessageButton
{
	public function __construct(
		public string $payload,
		public string $text,
	) {}

	public static function from(array $data): self
	{
		return new self(
			payload: $data['payload'] ?? '',
			text   : $data['text'] ?? '',
		);
	}
}
