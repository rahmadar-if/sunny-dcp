<?php

namespace Solaris\Marketing\Services\WhatsApp\Qiscus\Webhook;

final readonly class StatusEntry
{
	public function __construct(
		public string $id,
		public string $status,
		public string $timestamp,
		public string $recipientId,
		public array $errors,
	) {}

	public static function from(array $data): self
	{
		return new self(
			id         : $data['id'] ?? '',
			status     : $data['status'] ?? '',
			timestamp  : (string) ($data['timestamp'] ?? ''),
			recipientId: $data['recipient_id'] ?? '',
			errors     : array_map(
				fn(array $e) => StatusError::from($e),
				$data['errors'] ?? []
			),
		);
	}
}
