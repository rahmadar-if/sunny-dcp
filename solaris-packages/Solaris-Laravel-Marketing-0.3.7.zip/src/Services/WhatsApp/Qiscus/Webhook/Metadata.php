<?php

namespace Solaris\Marketing\Services\WhatsApp\Qiscus\Webhook;

final readonly class Metadata
{
	public function __construct(
		public string $displayPhoneNumber,
		public string $phoneNumberId,
	) {}

	public static function from(array $data): self
	{
		return new self(
			displayPhoneNumber: $data['display_phone_number'] ?? '',
			phoneNumberId     : $data['phone_number_id'] ?? '',
		);
	}
}
