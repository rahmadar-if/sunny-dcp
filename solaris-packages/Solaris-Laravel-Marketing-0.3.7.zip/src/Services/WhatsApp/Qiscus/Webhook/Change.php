<?php

namespace Solaris\Marketing\Services\WhatsApp\Qiscus\Webhook;

final readonly class Change
{
	public function __construct(
		public string $field,
		public Value $value,
	) {}

	public static function from(array $data): self
	{
		return new self(
			field: $data['field'] ?? '',
			value: Value::from($data['value'] ?? []),
		);
	}
}
