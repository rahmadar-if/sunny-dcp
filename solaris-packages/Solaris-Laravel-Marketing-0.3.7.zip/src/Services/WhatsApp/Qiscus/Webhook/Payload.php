<?php

namespace Solaris\Marketing\Services\WhatsApp\Qiscus\Webhook;

final readonly class Payload
{
	public function __construct(
		public string $object,
		public string $mcEvent,
		public array $entry,
	) {}

	public static function from(string $json): self
	{
		$data = json_decode($json, true) ?? [];

		return new self(
			object : $data['object'] ?? '',
			mcEvent: $data['mc_event'] ?? '',
			entry  : array_map(fn(array $e) => Entry::from($e), $data['entry'] ?? []),
		);
	}

	public function getValue(): Value
	{
		return $this->entry[0]->changes[0]->value;
	}
}
