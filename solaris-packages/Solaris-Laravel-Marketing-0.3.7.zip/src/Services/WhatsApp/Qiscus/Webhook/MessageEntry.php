<?php

namespace Solaris\Marketing\Services\WhatsApp\Qiscus\Webhook;

final readonly class MessageEntry
{
	public function __construct(
		public string $id,
		public string $from,
		public string $timestamp,
		public string $type,
		public ?MessageButton $button,
		public ?MessageContext $context,
	) {}

	public static function from(array $data): self
	{
		return new self(
			id       : $data['id'] ?? '',
			from     : $data['from'] ?? '',
			timestamp: (string) ($data['timestamp'] ?? ''),
			type     : $data['type'] ?? '',
			button   : isset($data['button']) ? MessageButton::from($data['button']) : null,
			context  : isset($data['context']) ? MessageContext::from($data['context']) : null,
		);
	}
}
