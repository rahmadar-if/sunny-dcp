<?php

namespace Solaris\Marketing\Services\WhatsApp\Qiscus\Webhook;

final readonly class Contact
{
	public function __construct(
		public string $userId,
		public string $waId,
		public ?string $profileName,
	) {}

	public static function from(array $data): self
	{
		return new self(
			userId     : $data['user_id'] ?? '',
			waId       : $data['wa_id'] ?? '',
			profileName: $data['profile']['name'] ?? null,
		);
	}
}
