<?php

namespace Solaris\Marketing\Services\WhatsApp\Qiscus;

use GuzzleHttp\Promise\PromiseInterface;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Client\Factory;
use Illuminate\Http\Client\PendingRequest;
use Illuminate\Http\Client\Pool;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Facades\Http;
use Solaris\Core\Helpers\Helper;
use Solaris\Marketing\Const\WaBlastAudienceStatusConst;
use Solaris\Marketing\Models\WaTemplate;
use Solaris\Marketing\Models\WaTemplateDetail;
use Solaris\Marketing\Services\WhatsApp\BlastAudienceResponse;
use Solaris\Marketing\Services\WhatsApp\Interfaces\HasTemplateSupport;
use Solaris\Marketing\Services\WhatsApp\Interfaces\HasWebhookSupport;
use Solaris\Marketing\Services\WhatsApp\Qiscus\Webhook\Payload;
use Solaris\Marketing\Services\WhatsApp\WaTemplateResponse;
use Solaris\Marketing\Services\WhatsApp\WhatsAppProvider;

class QiscusProvider extends WhatsAppProvider implements HasTemplateSupport, HasWebhookSupport
{
    private ?Payload $parsedPayload = null;

    protected function getConfig(): array
    {
        return Helper::config("wa_blast.providers.qiscus");
    }

    public function buildSendRequest(
        PendingRequest|Factory $request,
        string $phone,
        WaTemplateDetail $waTemplateDetail,
        array $templateParams
    ): PromiseInterface|Response
    {
        $endpoint = $this->config["endpoint"] . "/api/v3/admin/broadcast/client";
        $payload  = QiscusPayload::sendMessage($this->blastCampaign?->title ?? '', $phone, $waTemplateDetail, $templateParams);

        return $request->withHeaders([
            "Qiscus-Secret-Key"     => $this->config["secret"],
            "Qiscus-App-id"         => $this->config["app_id"],
            "X-Solaris-Log-Channel" => "qiscus",
        ])->post($endpoint, $payload);
    }

    public function isSuccessSendResponse(Response $response): bool
    {
        if (!$response->successful()) {
            return false;
        }

        $log = ($response->json('data.broadcast_logs') ?? [])[0] ?? [];

        return !empty($log['message_id']) && ($log['status'] ?? '') === 'sent';
    }

    public function getSendResponseMessage(Response $response): ?string
    {
        if ($this->isSuccessSendResponse($response)) {
            return null;
        }

        if ($response->successful()) {
            $log   = ($response->json('data.broadcast_logs') ?? [])[0] ?? [];
            $msgId = $log['message_id'] ?? null;

            return !$msgId
                ? ($log['notes'] ?? $response->json('errors.message') ?? '')
                : ($response->json('errors.message') ?? '');
        }

        return $response->json('errors.message') ?? $response->body();
    }

    public function mappingBlastResponse(
        string $audienceId,
        string $waBlastId,
        Response $response
    ): BlastAudienceResponse
    {
        $success   = $this->isSuccessSendResponse($response);
        $messageId = null;

        if ($success) {
            $log       = ($response->json('data.broadcast_logs') ?? [])[0] ?? [];
            $messageId = $log['message_id'] ?? null;
        }

        return new BlastAudienceResponse(
            audienceId: $audienceId,
            waBlastId : $waBlastId,
            statusId  : $success ? WaBlastAudienceStatusConst::Progress : WaBlastAudienceStatusConst::Failed,
            messageId : $messageId,
            message   : $this->getSendResponseMessage($response),
        );
    }

    public function isValidWebhook(string $key): bool
    {
        $signature    = $this->webhookHeader['qiscus-signature-key'][0] ?? '';
        $cleanPayload = json_encode(json_decode($this->webhookPayload, true));
        $expected     = base64_encode(hash_hmac('sha256', $cleanPayload, $key, true));

        return hash_equals($expected, $signature);
    }

    public function getWebhookMessageId(): string
    {
        return $this->getWebhookPayload()->getValue()->getMessageId();
    }

    public function getWebhookEventType(): string
    {
        return $this->getWebhookPayload()->getValue()->getEventType();
    }

    public function getWebhookMessage(): ?string
    {
        return $this->getWebhookPayload()->getValue()->getErrorMessage();
    }

    public function getWebhookButtonPayload(): ?string
    {
        return $this->getWebhookPayload()->getValue()->getButtonPayload();
    }

    private function getWebhookPayload(): Payload
    {
        if ($this->parsedPayload === null) {
            $this->parsedPayload = Payload::from($this->webhookPayload);
        }

        return $this->parsedPayload;
    }

    public function getTemplates(): array
    {
        $endpoint  = $this->config["endpoint"] . "/api/v3/admin/hsm";
        $headers   = [
            "Qiscus-Secret-Key"     => $this->config["secret"],
            "Qiscus-App-id"         => $this->config["app_id"],
            "X-Solaris-Log-Channel" => "qiscus",
        ];
        $languages = Helper::model('wa_template_language')::toSelect();
        $limit     = 25;

        $firstResponse = Http::withHeaders($headers)->get($endpoint, ['page' => 1, 'limit' => $limit]);
        if (!$firstResponse->successful()) {
            return [];
        }

        $body      = $firstResponse->json();
        $totalPage = $body['meta']['total_page'] ?? 1;
        $result    = QiscusHelper::mapHsmTemplates($body['data']['hsm_templates'] ?? [], $languages);

        if ($totalPage <= 1) {
            return $result;
        }

        $batches = array_chunk(range(2, $totalPage), 5);

        foreach ($batches as $batch) {
            $responses = Http::pool(fn (Pool $pool) => array_map(
                fn ($page) => $pool->as($page)->withHeaders($headers)->get($endpoint, ['page' => $page, 'limit' => $limit]),
                $batch
            ));

            foreach ($responses as $response) {
                if (!$response->successful()) {
                    continue;
                }
                $result = array_merge($result, QiscusHelper::mapHsmTemplates(
                    $response->json('data.hsm_templates') ?? [],
                    $languages
                ));
            }
        }

        return $result;
    }

    public function getTemplate(WaTemplate $waTemplate): Response
    {
        $endpoint = $this->config["endpoint"] . "/api/v3/admin/hsm";

        return Http::withHeaders([
            "Qiscus-Secret-Key" => $this->config["secret"],
            "Qiscus-App-id"     => $this->config["app_id"],
        ])->get($endpoint, [
            "name"  => $waTemplate->template_name,
            "page"  => 1,
            "limit" => 1
        ]);
    }

    public function mappingGetTemplateResponse(Response $response): WaTemplateResponse
    {
        if (!$response->successful()) {
            return WaTemplateResponse::error($response->json('errors.message') ?? 'Unknown error');
        }

        $body        = $response->json();
        $hasTemplate = $body["meta"]["total"] > 0;

        if (!$hasTemplate) {
            return WaTemplateResponse::error("Template not found");
        }

        $hsmTemplate = $body['data']['hsm_templates'][0];
        $languages   = Helper::model('wa_template_language')::toSelect();

        $detailsData = array_map(fn($detail) => [
            'language_id'   => $languages->firstWhere('code', $detail['language'])->id,
            'status_id'     => QiscusHelper::getTemplateStatus($detail['approval_status']),
            'reject_reason' => $detail['rejection_reason']
        ], $hsmTemplate['hsm_details']);

        return WaTemplateResponse::success([], $detailsData, "Sync completed");
    }

    public function createTemplate(WaTemplate $waTemplate, Collection $waTemplateDetails): Response
    {
        $endpoint = $this->config["endpoint"] . "/api/v3/admin/hsm/create";
        $payload  = QiscusPayload::createTemplate($waTemplate, $waTemplateDetails, $this->config["channel_id"]);

        return Http::withHeaders([
            "Qiscus-Secret-Key" => $this->config["secret"],
            "Qiscus-App-id"     => $this->config["app_id"],
        ])->post($endpoint, $payload);
    }

    public function mappingTemplateResponse(Response $response): WaTemplateResponse
    {
        if (!$response->successful()) {
            return WaTemplateResponse::error($response->json('errors.message') ?? 'Unknown error');
        }

        $body        = $response->json();
        $hsmTemplate = $body['data']['hsm_template'];

        $templateData = [
            'template_id'   => $hsmTemplate['id'],
            'template_name' => $hsmTemplate['name'],
            'custom'        => json_encode([
                'channel_id' => $hsmTemplate['channel_id'],
                'namespace'  => $hsmTemplate['namespace']
            ])
        ];

        $languages   = Helper::model('wa_template_language')::toSelect();
        $detailsData = array_map(fn($detail) => [
            'language_id'   => $languages->firstWhere('code', $detail['language'])->id,
            'status_id'     => QiscusHelper::getTemplateStatus($detail['approval_status']),
            'reject_reason' => $detail['rejection_reason']
        ], $hsmTemplate['hsm_details']);

        return WaTemplateResponse::success($templateData, $detailsData);
    }
}
