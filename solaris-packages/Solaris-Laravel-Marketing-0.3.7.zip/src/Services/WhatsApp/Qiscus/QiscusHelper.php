<?php

namespace Solaris\Marketing\Services\WhatsApp\Qiscus;

use Illuminate\Database\Eloquent\Collection;
use Solaris\Marketing\Const\WaTemplateCategoryConst;
use Solaris\Marketing\Const\WaTemplateHeaderTypeConst;
use Solaris\Marketing\Const\WaTemplateStatusConst;
use Solaris\Marketing\Const\WaTemplateSubTypeConst;
use Solaris\Marketing\Services\WhatsApp\WaTemplateSyncItem;

class QiscusHelper
{
	public static function mapHsmTemplates(array $hsmTemplates, Collection $languages): array
	{
		return array_map(fn($hsm) => static::mapHsmTemplate($hsm, $languages), $hsmTemplates);
	}

	public static function getTemplateStatus(int $approvalStatus): string
	{
		return match ($approvalStatus) {
			-1 => WaTemplateStatusConst::Rejected,
			0  => WaTemplateStatusConst::Pending,
			1  => WaTemplateStatusConst::Approved
		};
	}

	private static function mapHsmTemplate(array $hsm, Collection $languages): WaTemplateSyncItem
	{
		$details = array_map(fn($detail) => static::mapHsmDetail($detail, $languages), $hsm['hsm_details']);

		return WaTemplateSyncItem::create(
			templateName: $hsm['name'],
			templateId:   (string) $hsm['id'],
			custom:       json_encode([
				'channel_id' => $hsm['channel_id'],
				'namespace'  => $hsm['namespace'],
			]),
			categoryId:   static::mapCategoryId($hsm['category']),
			details:      $details,
		);
	}

	private static function mapHsmDetail(array $detail, Collection $languages): array
	{
		$isCarousel  = $detail['is_carousel'] ?? false;
		$cards       = $detail['cards'] ?? [];
		$headerType  = $detail['header_type'] ?? null;
		$argCount    = $detail['number_of_arguments'] ?? 0;

		return [
			'language_id'    => $languages->firstWhere('code', $detail['language'])->id,
			'sub_type_id'    => $isCarousel ? WaTemplateSubTypeConst::Carousel : WaTemplateSubTypeConst::Regular,
			'status_id'      => static::getTemplateStatus($detail['approval_status']),
			'header_type_id' => static::mapHeaderTypeId($headerType),
			'header_content' => static::extractHeaderContent(
				$headerType,
				$detail['header_content'] ?? null,
				$detail['header_default_value'] ?? null
			),
			'header_examples' => strtolower((string) $headerType) === 'text'
				? static::makeParamExamples(1)
				: null,
			'body'           => $detail['content'] ?? null,
			'body_examples'  => static::makeParamExamples($argCount),
			'footer'         => $detail['footer'] ?? null,
			'buttons'        => $isCarousel
				? static::mapCarouselSchemaJson($cards)
				: static::mapButtonsJson($detail['buttons'] ?? null),
			'cards'          => $isCarousel && !empty($cards)
				? static::mapCardsJson($cards)
				: null,
			'reject_reason'  => ($detail['rejection_reason'] ?? null) !== 'NONE'
				? ($detail['rejection_reason'] ?? null)
				: null,
		];
	}

	private static function mapCategoryId(string $category): ?string
	{
		return match(strtolower($category)) {
			'marketing'      => WaTemplateCategoryConst::Marketing,
			'utility'        => WaTemplateCategoryConst::Utility,
			'authentication' => WaTemplateCategoryConst::Authentication,
			default          => null,
		};
	}

	private static function mapHeaderTypeId(?string $headerType): ?string
	{
		if (!$headerType) {
			return null;
		}

		return match(strtolower($headerType)) {
			'text'     => WaTemplateHeaderTypeConst::Text,
			'image'    => WaTemplateHeaderTypeConst::Image,
			'video'    => WaTemplateHeaderTypeConst::Video,
			'document' => WaTemplateHeaderTypeConst::Document,
			default    => null,
		};
	}

	private static function extractHeaderContent(?string $headerType, ?string $headerContent, ?string $headerDefaultValue): ?string
	{
		if (!$headerType) {
			return null;
		}

		if (strtolower($headerType) === 'text') {
			return $headerContent;
		}

		if (!$headerDefaultValue) {
			return null;
		}

		// Qiscus wraps media URL as JSON: {"image":{"link":"..."},"type":"image"}
		$decoded = json_decode($headerDefaultValue, true);
		if (is_array($decoded)) {
			$type = strtolower($headerType);
			return $decoded[$type]['link'] ?? $decoded['link'] ?? $headerDefaultValue;
		}

		return $headerDefaultValue;
	}

	private static function mapButtonsJson(?array $buttons): ?string
	{
		if (empty($buttons)) {
			return null;
		}

		return json_encode(array_map(fn($btn) => [
			'type'        => strtolower($btn['type']),
			'label'       => $btn['text'] ?? '',
			'value'       => match(strtolower($btn['type'])) {
				'url'          => $btn['url'] ?? '',
				'phone_number' => $btn['phone_number'] ?? '',
				'copy_code'    => $btn['example'][0] ?? '',
				default        => ''
			},
			'url_example' => strtolower($btn['type']) === 'url' && !empty($btn['example'])
				? $btn['example'][0] : ''
		], $buttons));
	}

	private static function makeParamExamples(int $count): ?string
	{
		if ($count <= 0) {
			return null;
		}

		return json_encode(array_combine(range(1, $count), array_fill(0, $count, '')));
	}

	private static function makeParamExamplesRaw(int $count): array
	{
		if ($count <= 0) {
			return [];
		}

		return array_combine(range(1, $count), array_fill(0, $count, ''));
	}

	private static function mapCarouselSchemaJson(array $qisqusCards): ?string
	{
		$firstCardButtons = $qisqusCards[0]['buttons'] ?? [];
		if (empty($firstCardButtons)) {
			return null;
		}

		return json_encode(
			array_map(fn($btn) => ['type' => strtolower($btn['type'])], $firstCardButtons)
		);
	}

	private static function mapCardsJson(array $qisqusCards): string
	{
		return json_encode(array_map(function ($card, $i) {
			$bodySamples = [];
			if (!empty($card['body_sample'])) {
				$parsed = json_decode($card['body_sample'], true);
				if (is_array($parsed)) {
					$bodySamples = array_combine(range(1, count($parsed)), $parsed);
				}
			}

			return [
				'id'              => 'c' . ($i + 1),
				'header_content'  => $card['header_default_value'] ?? '',
				'header_examples' => $card['header_default_value'] ?? '',
				'body'            => $card['content'] ?? '',
				'body_examples'   => !empty($bodySamples)
					? $bodySamples
					: static::makeParamExamplesRaw($card['number_of_arguments'] ?? 0),
				'buttons'         => array_map(fn($btn) => [
					'type'        => strtolower($btn['type']),
					'label'       => $btn['text'] ?? '',
					'value'       => match(strtolower($btn['type'])) {
						'url'          => $btn['url'] ?? '',
						'phone_number' => $btn['phone_number'] ?? '',
						'copy_code'    => !empty($btn['example']) ? $btn['example'][0] : '',
						default        => ''
					},
					'url_example' => strtolower($btn['type']) === 'url' && !empty($btn['example'])
						? $btn['example'][0] : ''
				], $card['buttons'] ?? []),
			];
		}, $qisqusCards, array_keys($qisqusCards)));
	}
}
