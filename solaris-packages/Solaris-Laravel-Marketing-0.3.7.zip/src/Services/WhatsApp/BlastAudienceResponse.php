<?php

namespace Solaris\Marketing\Services\WhatsApp;

class BlastAudienceResponse
{
	public function __construct(
		public readonly string  $audienceId,
		public readonly string  $waBlastId,
		public readonly string  $statusId,
		public readonly ?string $messageId = null,
		public readonly ?string $message   = null,
	) {}

	public function toArray(): array
	{
		return [
			'id'          => $this->audienceId,
			'wa_blast_id' => $this->waBlastId,
			'status_id'   => $this->statusId,
			'message_id'  => $this->messageId,
			'message'     => $this->message,
		];
	}
}
