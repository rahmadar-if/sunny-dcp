<?php

namespace Solaris\Marketing\Services\WhatsApp;

use Illuminate\Support\Facades\DB;
use Solaris\Marketing\Const\WaBlastAudienceStatusConst;

class WhatsAppWebhookProcessor
{
	private const CHUNK_SIZE = 1000;

	public function __construct(private string $driverClass)
	{}

	public function process(): void
	{
		$webhooks = DB::table("wa_blast_webhooks", "webhook")
			->select(
				"audiences.id as audience_id",
				"audiences.wa_blast_id as wa_blast_id",
				"audiences.status_id as audience_status_id",
				"audiences.replied as replied",
				"audiences.message as audience_message",
				"webhook.id as webhook_id",
				"webhook.message_id as message_id",
				"webhook.event_type as event_type",
				"webhook.message as message",
				"webhook.button_payload as button_payload",
			)
			->join("wa_blast_audiences as audiences", "audiences.message_id", "=", "webhook.message_id")
			->where("audiences.status_id", "!=", WaBlastAudienceStatusConst::Pending)
			->orderBy("webhook.created_at")
			->limit(self::CHUNK_SIZE)
			->get();

		if ($webhooks->isEmpty()) {
			return;
		}

		$webhookGroups = $webhooks->groupBy("message_id");
		$waBlastIds    = [];
		$data          = [];

		foreach ($webhookGroups as $messageId => $items) {
			$audienceStatus  = $items->first()->audience_status_id;
			$audienceReplied = $items->first()->replied;
			$audienceMessage = $items->first()->audience_message;

			$messages = trim(implode("\n", $items->pluck("message")->filter()->all()));
			if (!empty($messages)) {
				$audienceMessage = $messages;
			}

			$sentCount      = $items->where('event_type', $this->driverClass::$eventSent)->count();
			$deliveredCount = $items->where('event_type', $this->driverClass::$eventDelivered)->count();
			$readCount      = $items->where('event_type', $this->driverClass::$eventRead)->count();
			$repliedCount   = $items->where('event_type', $this->driverClass::$eventReplied)->count();
			$failedCount    = $items->where('event_type', $this->driverClass::$eventFailed)->count();

			$existingReplied = $audienceReplied ? (json_decode($audienceReplied, true) ?? []) : [];
			$newPayloads     = $items
				->where('event_type', $this->driverClass::$eventReplied)
				->pluck('button_payload')
				->filter()
				->values()
				->all();
			$mergedReplied   = !empty($newPayloads)
				? json_encode(array_values(array_unique(array_merge($existingReplied, $newPayloads))))
				: $audienceReplied;

			$isRead = ($readCount > 0 || $repliedCount > 0)
				|| $audienceStatus == WaBlastAudienceStatusConst::Read;

			$isDelivered = ($deliveredCount > 0 && in_array($audienceStatus, [
					WaBlastAudienceStatusConst::Progress,
					WaBlastAudienceStatusConst::Sent,
				]))
				|| $audienceStatus == WaBlastAudienceStatusConst::Delivered
				|| $isRead;

			$isSent = ($sentCount > 0 && $audienceStatus == WaBlastAudienceStatusConst::Progress)
				|| $audienceStatus == WaBlastAudienceStatusConst::Sent
				|| $isDelivered;

			$isFailed = $failedCount > 0 && $audienceStatus == WaBlastAudienceStatusConst::Progress;

			$statusId = $audienceStatus;
			if ($isRead) {
				$statusId = WaBlastAudienceStatusConst::Read;
			} elseif ($isDelivered) {
				$statusId = WaBlastAudienceStatusConst::Delivered;
			} elseif ($isSent) {
				$statusId = WaBlastAudienceStatusConst::Sent;
			} elseif ($isFailed) {
				$statusId = WaBlastAudienceStatusConst::Failed;
			}

			$waBlastIds[] = $items->first()->wa_blast_id;

			$data[] = [
				"id"          => $items->first()->webhook_id,
				"audience_id" => $items->first()->audience_id,
				"message_id"  => $messageId,
				"message"     => $audienceMessage,
				"status_id"   => $statusId,
				"replied"     => $mergedReplied,
			];
		}

		$webhookIdDeletes = $webhooks->pluck("webhook_id")->all();
		$webhookIds       = array_column($data, "id");
		$waBlastIds       = array_unique($waBlastIds);

		DB::transaction(function () use ($webhookIdDeletes, $webhookIds, $waBlastIds, $data) {
			DB::table("wa_blast_webhook_temp")->insert($data);

			$this->bulkUpdateAudiences();

			DB::table("wa_blast_webhook_temp")
				->whereIn('id', $webhookIds)
				->delete();

			UpdateWhatsAppCampaignStatus::updateStatus($waBlastIds);

			DB::table("wa_blast_webhooks")
				->whereIn('id', $webhookIdDeletes)
				->delete();
		});
	}

	private function bulkUpdateAudiences(): void
	{
		$driver = DB::connection()->getDriverName();

		match ($driver) {
			'mysql', 'mariadb' => $this->bulkUpdateMySQL(),
			'pgsql'            => $this->bulkUpdatePostgreSQL(),
			'sqlsrv'           => $this->bulkUpdateSQLServer(),
			default            => throw new \Exception("Unsupported database driver: {$driver}")
		};
	}

	private function bulkUpdateMySQL(): void
	{
		DB::statement("UPDATE wa_blast_audiences audience
			INNER JOIN wa_blast_webhook_temp temp
				ON audience.id = temp.audience_id
				AND audience.message_id = temp.message_id
			SET
				audience.status_id = temp.status_id,
				audience.replied   = temp.replied,
				audience.message   = temp.message");
	}

	private function bulkUpdatePostgreSQL(): void
	{
		DB::statement("UPDATE wa_blast_audiences audience
			SET
				status_id = temp.status_id,
				replied   = temp.replied,
				message   = temp.message
			FROM wa_blast_webhook_temp temp
			WHERE audience.id = temp.audience_id
			AND audience.message_id = temp.message_id");
	}

	private function bulkUpdateSQLServer(): void
	{
		DB::statement("UPDATE audience
			SET
				status_id = temp.status_id,
				replied   = temp.replied,
				message   = temp.message
			FROM wa_blast_audiences audience
			INNER JOIN wa_blast_webhook_temp temp
				ON audience.id = temp.audience_id
				AND audience.message_id = temp.message_id");
	}
}
