<?php

namespace Solaris\Marketing\Services\WhatsApp;

use InvalidArgumentException;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Solaris\Core\Helpers\Helper;
use Solaris\Marketing\Attributes\WaTemplateParam;
use Solaris\Marketing\Const\WaTemplateCategoryConst;
use Solaris\Marketing\Const\WaTemplateHeaderTypeConst;
use Solaris\Marketing\Const\WaTemplateSubTypeConst;
use Solaris\Marketing\Models\WaTemplate;
use Solaris\Marketing\Models\WaTemplateDetail;
use Solaris\Marketing\Services\WhatsApp\Interfaces\HasTemplateSupport;

class WaTemplateService
{
	public static function getTemplates(): array // returns WaTemplateSyncItem[]
	{
		return static::resolveDriver()->getTemplates();
	}

	public static function syncAllTemplates(): array
	{
		$items         = static::getTemplates();
		$templateModel = Helper::model('wa_template');
		$synced        = 0;

		DB::transaction(function () use ($items, $templateModel, &$synced) {
			foreach ($items as $item) {
				$existing = $templateModel::where('template_name', $item->getTemplateName())->first();

				if ($existing) {
					$existing->update([
						'template_id' => $item->getTemplateId(),
						'custom'      => $item->getTemplateData()['custom'],
					]);

					foreach ($item->getDetails() as $detail) {
						$existing->details()
							->where('language_id', $detail['language_id'])
							->update([
								'status_id'     => $detail['status_id'],
								'reject_reason' => $detail['reject_reason'],
							]);
					}
				} else {
					$template = $templateModel::create($item->getTemplateData());

					foreach ($item->getDetails() as $detail) {
						$template->details()->create($detail);
					}
				}

				$synced++;
			}
		});

		return ['success' => true, 'message' => "Synced {$synced} templates"];
	}

	public static function syncTemplate(WaTemplate|string $waTemplate): array
	{
		$driver   	= static::resolveDriver();
		$waTemplate = static::resolveTemplate($waTemplate);

		$response = $driver->mappingGetTemplateResponse(
			$driver->getTemplate($waTemplate)
		);

		if($response->isSuccess()) {
			$response->apply($waTemplate);
		}

		return $response->toArray();
	}

	public static function createTemplate(WaTemplate|string $waTemplate): array
	{
		$driver   = static::resolveDriver();
		$template = static::resolveTemplate($waTemplate);
		
		WaTemplateService::validateForSubmit($template);

		$response = $driver->mappingTemplateResponse(
			$driver->createTemplate($template, $template->details)
		);

		if ($response->isSuccess()) {
			$response->apply($template);
		}

		return $response->toArray();
	}

	public static function validateForSubmit(WaTemplate|string $waTemplate): void
	{
		$template = static::resolveTemplate($waTemplate);

		$errors = [];
		foreach ($template->details as $detail) {
			$detailErrors = static::validateDetail($template, $detail);
			if (!empty($detailErrors)) {
				$lang     = $detail->language->name;
				$errors[] = "[{$lang}]: " . implode('; ', $detailErrors);
			}
		}

		if (!empty($errors)) {
			throw new InvalidArgumentException(implode("\n", $errors));
		}
	}

	public static function resolveTemplate(WaTemplate|string $waTemplate): WaTemplate
	{
		return is_string($waTemplate) && Str::isUuid($waTemplate)
			? Helper::model("wa_template")::find($waTemplate)
			: $waTemplate;
	}

	public static function resolveParams(string $modelClass): array
	{
		$attribute = Helper::getClassAttribute($modelClass, WaTemplateParam::class);
		$columns   = $modelClass::getColumns();
		$include   = $attribute?->include ?? [];
		$exclude   = $attribute?->exclude ?? [];

		$result   = [];
		$usedKeys = [];

		foreach ($columns as $col) {
			$name = $col['name'];
			$isFk = $col['type'] === 'lookup';
			$key  = $isFk ? substr($name, 0, -3) : $name;

			if (isset($usedKeys[$key])) {
				continue;
			}

			if (!empty($include) && !in_array($key, $include) && !in_array($name, $include)) {
				continue;
			}

			if (in_array($name, $exclude) || in_array($key, $exclude)) {
				continue;
			}

			$usedKeys[$key] = true;

			$result[] = [
				'id'   => $key,
				'name' => $col['displayName'],
			];
		}

		return $result;
	}

	private static function resolveDriver(): HasTemplateSupport
	{
		$driverClass = WaBlastService::getDriver();
		$driver      = $driverClass::forTemplate(Auth::user());

		if (!$driver instanceof HasTemplateSupport) {
			throw new InvalidArgumentException("Provider [{$driverClass}] does not implement HasTemplateSupport");
		}

		return $driver;
	}

	private static function validateDetail(WaTemplate $template, WaTemplateDetail $detail): array
	{
		$errors  = [];
		$limits  = Helper::config('wa_template.limits');
		$isAuth  = $template->category_id === WaTemplateCategoryConst::Authentication;
		$isCard  = $template->category_id === WaTemplateCategoryConst::Marketing
				&& $detail->sub_type_id   === WaTemplateSubTypeConst::Carousel;

		if ($isAuth) {
			$exp = $detail->expiry_minutes;
			if ($exp !== null && ($exp < $limits['auth_expiry_min'] || $exp > $limits['auth_expiry_max'])) {
				$errors[] = "Expiry minutes must be between {$limits['auth_expiry_min']} and {$limits['auth_expiry_max']}";
			}
			return $errors;
		}

		if ($isCard) {
			if (empty($detail->body)) {
				$errors[] = "Body is required";
			} elseif (mb_strlen($detail->body) > $limits['carousel_body_max_chars']) {
				$errors[] = "Body exceeds {$limits['carousel_body_max_chars']} characters";
			}

			$cards = is_string($detail->cards) ? json_decode($detail->cards, true) : $detail->cards;
			if (!is_array($cards) || count($cards) < $limits['carousel_min_cards']) {
				$errors[] = "Carousel requires at least {$limits['carousel_min_cards']} cards";
			}

			if (!empty($detail->buttons)) {
				$buttons = is_string($detail->buttons) ? json_decode($detail->buttons, true) : $detail->buttons;
				if (is_array($buttons) && count($buttons) > $limits['carousel_button_max']) {
					$errors[] = "Carousel allows at most {$limits['carousel_button_max']} button types";
				}
			}

			return $errors;
		}

		// Regular / Utility
		if (empty($detail->body)) {
			$errors[] = "Body is required";
		} elseif (mb_strlen($detail->body) > $limits['body_max_chars']) {
			$errors[] = "Body exceeds {$limits['body_max_chars']} characters";
		}

		$mediaHeaderTypes = [
			WaTemplateHeaderTypeConst::Image,
			WaTemplateHeaderTypeConst::Video,
			WaTemplateHeaderTypeConst::Document,
		];
		if (in_array($detail->header_type_id, $mediaHeaderTypes) && empty($detail->header_content)) {
			$errors[] = "Header media URL is required";
		}

		if ($detail->header_type_id === WaTemplateHeaderTypeConst::Text
			&& !empty($detail->header_content)
			&& mb_strlen($detail->header_content) > $limits['header_max_chars']) {
			$errors[] = "Header text exceeds {$limits['header_max_chars']} characters";
		}

		if (!empty($detail->footer) && mb_strlen($detail->footer) > $limits['footer_max_chars']) {
			$errors[] = "Footer exceeds {$limits['footer_max_chars']} characters";
		}

		if (!empty($detail->buttons)) {
			$buttons    = is_string($detail->buttons) ? json_decode($detail->buttons, true) : $detail->buttons;
			$valueTypes = ['url', 'phone_number', 'copy_code'];
			foreach ($buttons as $btn) {
				if (empty($btn['label'])) {
					$errors[] = "All button labels are required";
					break;
				}
				if (in_array($btn['type'], $valueTypes) && empty($btn['value'])) {
					$errors[] = "Button value is required for type '{$btn['type']}'";
					break;
				}
			}
		}

		return $errors;
	}
}
