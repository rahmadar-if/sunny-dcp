<?php

namespace Solaris\Marketing\Services\WhatsApp;

class WaTemplateSyncItem
{
	private string  $templateName;
	private string  $templateId;
	private ?string $custom;
	private ?string $categoryId;
	private array   $details;

	private function __construct(
		string  $templateName,
		string  $templateId,
		?string $custom,
		?string $categoryId,
		array   $details,
	) {
		$this->templateName = $templateName;
		$this->templateId   = $templateId;
		$this->custom       = $custom;
		$this->categoryId   = $categoryId;
		$this->details      = $details;
	}

	public static function create(
		string  $templateName,
		string  $templateId,
		?string $custom,
		?string $categoryId,
		array   $details,
	): static {
		return new static($templateName, $templateId, $custom, $categoryId, $details);
	}

	public function getTemplateName(): string { return $this->templateName; }
	public function getTemplateId(): string   { return $this->templateId; }
	public function getDetails(): array       { return $this->details; }

	public function getTemplateData(): array
	{
		return [
			'name'          => $this->templateName,
			'template_name' => $this->templateName,
			'template_id'   => $this->templateId,
			'custom'        => $this->custom,
			'category_id'   => $this->categoryId,
		];
	}
}
