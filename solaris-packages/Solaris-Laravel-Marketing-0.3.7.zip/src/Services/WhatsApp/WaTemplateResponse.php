<?php

namespace Solaris\Marketing\Services\WhatsApp;

use Illuminate\Support\Facades\DB;
use Solaris\Marketing\Models\WaTemplate;

class WaTemplateResponse
{
	private bool    $success;
	private ?string $errorMessage;
	private array   $templateData;
	private array   $detailsData;
    private ?string $successMessage;

	private function __construct(
		bool    $success,
		?string $errorMessage = null,
		array   $templateData = [],
		array   $detailsData  = [],
        ?string $successMessage = null,
	) {
		$this->success        = $success;
		$this->errorMessage   = $errorMessage;
		$this->templateData   = $templateData;
		$this->detailsData    = $detailsData;
        $this->successMessage = $successMessage;
	}

	public static function success(array $templateData, array $detailsData, ?string $successMessage = null): static
	{
		return new static(true, null, $templateData, $detailsData, $successMessage);
	}

	public static function error(string $message): static
	{
		return new static(false, $message);
	}

	public function isSuccess(): bool
	{
		return $this->success;
	}

	public function getError(): ?string
	{
		return $this->errorMessage;
	}

	public function apply(WaTemplate $template): void
	{
		DB::transaction(function () use ($template) {
			if (!empty($this->templateData)) {
				$template->update($this->templateData);
			}

			foreach ($this->detailsData as $fields) {
				$template->details()
					->where('language_id', $fields['language_id'])
					->update($fields);
			}
		});
	}

	public function toArray(): array
	{
		return [
			'success' => $this->success,
			'message' => $this->success ? ($this->successMessage ?? "Template submitted successfully") : $this->errorMessage,
		];
	}
}
