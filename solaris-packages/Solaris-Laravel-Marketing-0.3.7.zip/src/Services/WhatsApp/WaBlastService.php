<?php

namespace Solaris\Marketing\Services\WhatsApp;

use Carbon\Carbon;
use InvalidArgumentException;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Interfaces\Model\SolarisUser;
use Solaris\Marketing\Const\CampaignBlastQuotaContextConst;
use Solaris\Marketing\Const\CampaignBlastStatusConst;
use Solaris\Marketing\Const\WaBlastAudienceStatusConst;
use Solaris\Marketing\Jobs\WaBlastJob;
use Solaris\Marketing\Jobs\WaBlastWebhookJob;
use Solaris\Marketing\Jobs\WaBlastWebhookProcessJob;
use Solaris\Marketing\Models\WaBlast;
use Solaris\Marketing\Services\CampaignBlastQuotaService;
use Solaris\Marketing\Services\WhatsApp\Interfaces\HasWebhookSupport;

class WaBlastService
{
	public static function send(WaBlast|string $waBlast, ?SolarisUser $user = null, ?string $provider = null): void
	{
		$provider = $provider ?? Helper::config('wa_blast.default');
		$driver   = static::getDriver($provider);
		$campaign = static::resolveCampaign($waBlast);
		$actor    = $user ?? Auth::user();

		static::validateCanBlast($campaign);
		static::releaseLeftoverQuotas($campaign);

		$quotas = CampaignBlastQuotaService::bookWaBlastQuota($provider, $campaign->id, $driver::$blastPhoneColumn, userId: $actor?->id);

		$campaign->status_id     = CampaignBlastStatusConst::Queued;
		$campaign->queue_at      = Carbon::now();
		$campaign->error_message = null;
		$campaign->quotas        = json_encode($quotas);
		$campaign->save();

		WaBlastJob::dispatch($driver, $campaign, $actor);
	}

	public static function sendTest(WaBlast|string $waBlast, string $phone, Model $contact, ?string $provider = null): array
	{
		$provider = $provider ?? Helper::config('wa_blast.default');
		$driver   = static::getDriver($provider);
		$campaign = static::resolveCampaign($waBlast);

		if (empty($campaign->wa_template_detail)) {
			throw new \Exception("Template is empty");
		}

		$quotas   = CampaignBlastQuotaService::bookOneWaBlastQuota($provider, Auth::id());
		$settled  = false;
		$rawParams = json_decode($campaign->template_params ?? '{}', true) ?? [];

		try {
			$result = $driver::send($phone, $contact, $campaign->wa_template_detail, $rawParams);

			$settled = true;

			if ($result['success']) {
				CampaignBlastQuotaService::consumeOne($quotas, Auth::id());
			} else {
				CampaignBlastQuotaService::cancel($quotas, CampaignBlastQuotaContextConst::Test);
				throw new \Exception($result['message'] ?? "Failed to send test WhatsApp");
			}

			return $result;
		} finally {
			if (!$settled) {
				try {
					CampaignBlastQuotaService::cancel($quotas, CampaignBlastQuotaContextConst::Test);
				} catch (\Throwable) {}
			}
		}
	}

	public static function schedule(WaBlast|string $waBlast, string $scheduleAt, ?string $provider = null, ?SolarisUser $user = null): void
	{
		$provider = $provider ?? Helper::config('wa_blast.default');
		$driver   = static::getDriver($provider);
		$campaign = static::resolveCampaign($waBlast);
		$actor    = $user ?? Auth::user();

		$scheduleAtCarbon = Carbon::parse($scheduleAt);
		if ($scheduleAtCarbon->lt(Carbon::now())) {
			throw new \Exception("The scheduled time cannot be set to an earlier time");
		}

		static::validateCanBlast($campaign, $scheduleAtCarbon);
		static::releaseLeftoverQuotas($campaign);

		$quotas = CampaignBlastQuotaService::bookWaBlastQuota($provider, $campaign->id, $driver::$blastPhoneColumn, $scheduleAt, $actor?->id);

		$campaign->status_id     = CampaignBlastStatusConst::Scheduled;
		$campaign->schedule_at   = $scheduleAt;
		$campaign->error_message = null;
		$campaign->quotas        = json_encode($quotas);
		$campaign->save();
	}

	public static function cancel(WaBlast|string $waBlast): void
	{
		$campaign = static::resolveCampaign($waBlast);

		if ($campaign->status_id != CampaignBlastStatusConst::Scheduled) {
			throw new \Exception("You can only cancel in scheduled status");
		}

		$scheduleAt = $campaign->schedule_at->startOfMinute();
		if ($scheduleAt->lte(now()->startOfMinute())) {
			throw new \Exception("Cancellation is only allowed before the scheduled time is reached");
		}

		CampaignBlastQuotaService::cancel(
			quotas    : json_decode($campaign->quotas ?? '[]', true) ?? [],
			context   : CampaignBlastQuotaContextConst::Cancel,
			sourceType: Helper::model("wa_blast"),
			sourceId  : $campaign->id
		);

		$campaign->status_id     = CampaignBlastStatusConst::Draft;
		$campaign->schedule_at   = null;
		$campaign->error_message = null;
		$campaign->quotas        = null;
		$campaign->save();
	}

	public static function checkQuota(?string $provider = null): int
	{
		$provider = $provider ?? Helper::config('wa_blast.default');
		return CampaignBlastQuotaService::getWaBlastQuota($provider);
	}

	public static function queueWebhook(string|array $payload, array $headers = [], ?string $provider = null): Response
	{
		$config = [];
		$code   = 406;

		try {
			$config  = static::resolveWebhookConfig($provider);
			$code    = $config['successCode'];
			$payload = is_array($payload) ? json_encode($payload) : $payload;

			$driver = ($config['driver'])::forWebhook($payload, $headers);

			if (!$driver->isValidWebhook($config['key'])) {
				throw new \Exception("Webhook Signing Key is invalid");
			}

			$messageId = $driver->getWebhookMessageId();
			$eventType = $driver->getWebhookEventType();

			if (empty($messageId)) {
				throw new \Exception("MessageId is null or empty");
			}

			if (empty($eventType)) {
				throw new \Exception("EventType is null or empty");
			}

			WaBlastWebhookJob::dispatch($payload, $messageId, $eventType, $driver->getWebhookMessage(), $driver->getWebhookButtonPayload());
		} catch (\Exception $e) {
			Log::info("WhatsApp Webhook Queue fail", [
				'message' => $e->getMessage()
			]);

			$code = $config['failCode'] ?? 406;
		}

		return response('', $code);
	}

	public static function processWebhook(?string $provider = null): void
	{
		try {
			$config = static::resolveWebhookConfig($provider);
			WaBlastWebhookProcessJob::dispatch($config['driver']);
		} catch (\Exception $e) {
			Log::error("WhatsApp Webhook Process fail", [
				'message'   => $e->getMessage(),
				'exception' => $e
			]);
		}
	}

	public static function getDriver(?string $provider = null): string
	{
		$config = Helper::config('wa_blast.providers.' . ($provider ?? Helper::config('wa_blast.default')));
		if (!$config || empty($config['driver'])) {
			throw new InvalidArgumentException(
				"WhatsApp blast provider [{$provider}] is not configured properly"
			);
		}

		$driverClass = $config['driver'];
		if (!is_subclass_of($driverClass, WhatsAppProvider::class)) {
			throw new InvalidArgumentException(
				"Driver [{$driverClass}] must extend WhatsAppProvider"
			);
		}

		return $driverClass;
	}

	public static function updateToSending(WaBlast $campaign, SolarisUser $user): void
	{
		$campaign->sent_at   = Carbon::now();
		$campaign->status_id = CampaignBlastStatusConst::Sending;
		$campaign->save();

		$user->sendInAppNotification(
			title  : $campaign->title,
			message: "WhatsApp blast process to sending",
			url    : route("marketing.wa-blast", ["id" => $campaign->id])
		);
	}

	public static function updateToCompleted(WaBlast $campaign, SolarisUser $user, array $blastQuotas, bool $isSuccess, ?string $message = null): void
	{
		$remainingQuotas = array_filter($blastQuotas ?? [], fn ($amount) => $amount > 0);
		$cancelSucceeded = true;

		if (!empty($remainingQuotas)) {
			try {
				CampaignBlastQuotaService::cancel(
					quotas    : $remainingQuotas,
					context   : CampaignBlastQuotaContextConst::Completed,
					sourceType: Helper::model("wa_blast"),
					sourceId  : $campaign->id,
					userId    : $user?->id
				);
			} catch (\Exception $e) {
				$cancelSucceeded = false;

				Log::error("WaBlast quota cancel failed", [
					'campaign_id' => $campaign->id,
					'quotas'      => $remainingQuotas,
					'message'     => $e->getMessage(),
				]);
			}
		}

		$campaign->completed_at  = Carbon::now();
		$campaign->status_id     = $isSuccess ? CampaignBlastStatusConst::Completed : CampaignBlastStatusConst::Failed;
		$campaign->error_message = $message;
		$campaign->quotas        = $cancelSucceeded ? null : json_encode($remainingQuotas);
		$campaign->save();

		$user->sendInAppNotification(
			title  : $campaign->title,
			message: $isSuccess ? "WhatsApp blast process is complete" : $message,
			url    : route("marketing.wa-blast", ["id" => $campaign->id])
		);
	}

	private static function releaseLeftoverQuotas(WaBlast $campaign): void
	{
		$leftover = array_filter(json_decode($campaign->quotas ?? '[]', true) ?? [], fn ($amount) => $amount > 0);

		if (empty($leftover)) {
			return;
		}

		try {
			CampaignBlastQuotaService::cancel(
				quotas    : $leftover,
				context   : CampaignBlastQuotaContextConst::Leftover,
				sourceType: Helper::model("wa_blast"),
				sourceId  : $campaign->id
			);
		} catch (\Exception $e) {
			Log::warning("WaBlast leftover quota cancel failed", [
				'campaign_id' => $campaign->id,
				'quotas'      => $leftover,
				'message'     => $e->getMessage(),
			]);
		}
	}

	public static function updateAudiences(string $campaignId, array $blastQuotas, array $responses, ?string $userId = null): array
	{
		$successCount = collect($responses)
			->filter(fn($item) => $item["status_id"] == WaBlastAudienceStatusConst::Progress)
			->count();

		return DB::transaction(function () use ($campaignId, $blastQuotas, $responses, $successCount, $userId) {
			DB::table("wa_blast_audience_temp")->insert($responses);

			UpdateWhatsAppCampaignStatus::updateAudienceProgress($campaignId);

			DB::table("wa_blast_audience_temp")
				->where('wa_blast_id', $campaignId)
				->delete();

			$remainingQuotas = CampaignBlastQuotaService::consume(
				blastQuotas   : $blastQuotas,
				totalProcessed: count($responses),
				successCount  : $successCount,
				sourceType    : Helper::model("wa_blast"),
				sourceId      : $campaignId,
				userId        : $userId
			);

			DB::table("wa_blasts")
				->where('id', $campaignId)
				->update(['quotas' => json_encode($remainingQuotas)]);

			return $remainingQuotas;
		});
	}

	// Aggregate over every audience of the campaign, so it runs per chunk rather than per pool.
	public static function updateCampaignTotals(string $campaignId): void
	{
		UpdateWhatsAppCampaignStatus::updateStatus([$campaignId]);
	}

	public static function resolveCampaign(WaBlast|string $waBlast): WaBlast
	{
		return is_string($waBlast) && Str::isUuid($waBlast)
			? Helper::model("wa_blast")::find($waBlast)
			: $waBlast;
	}

	private static function resolveWebhookConfig(?string $provider): array
	{
		$provider    = $provider ?? Helper::config('wa_blast.default');
		$driverClass = static::getDriver($provider);
		$config      = Helper::config('wa_blast.providers.' . $provider);

		if (!is_a($driverClass, HasWebhookSupport::class, true)) {
			throw new InvalidArgumentException(
				"Driver [{$driverClass}] must implement HasWebhookSupport"
			);
		}

		return [
			'key'         => $config['webhook_key'],
			'successCode' => $config['webhook_success_code'] ?? 200,
			'failCode'    => $config['webhook_fail_code'] ?? 406,
			'driver'      => $driverClass
		];
	}

	private static function validateCanBlast(WaBlast $campaign, ?Carbon $scheduleAt = null): void
	{
		$validStatus = in_array($campaign->status_id, [CampaignBlastStatusConst::Draft, CampaignBlastStatusConst::Failed]);
		if (!$validStatus) {
			throw new \Exception("WhatsApp blasts can only be done when the status is draft/failed");
		}

		if (empty($campaign->wa_template_detail)) {
			throw new \Exception("Template is empty");
		}

		if ($campaign->audiences()->count() == 0) {
			throw new \Exception("Audience is empty");
		}

		$targetDate = $scheduleAt ? $scheduleAt->startOfDay() : today();
		$dailyLimit = Helper::config("wa_blast.daily_limit");

		if ((static::getInProgress($targetDate) + 1) > $dailyLimit) {
			throw new \Exception("The daily limit has been reached. Please wait for another WhatsApp blast to be sent.");
		}
	}

	private static function getInProgress(Carbon $date): int
	{
		return Helper::model("wa_blast")::where(function ($query) use ($date) {
			$query->whereIn("status_id", [
				CampaignBlastStatusConst::Queued,
				CampaignBlastStatusConst::Sending
			])
			->whereDate("queue_at", $date);
		})
		->orWhere(function ($query) use ($date) {
			$query->where("status_id", CampaignBlastStatusConst::Scheduled)
				->whereDate("schedule_at", $date);
		})
		->count();
	}
}
