<?php

namespace Solaris\Marketing\Services\WhatsApp\Interfaces;

use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Client\Response;
use Solaris\Marketing\Models\WaTemplate;
use Solaris\Marketing\Services\WhatsApp\WaTemplateResponse;

interface HasTemplateSupport
{
	public function getTemplates(): array; // returns WaTemplateSyncItem[]

	public function getTemplate(WaTemplate $waTemplate): Response;

	public function mappingGetTemplateResponse(Response $response): WaTemplateResponse;

	public function createTemplate(WaTemplate $waTemplate, Collection $waTemplateDetails): Response;

	public function mappingTemplateResponse(Response $response): WaTemplateResponse;
}
