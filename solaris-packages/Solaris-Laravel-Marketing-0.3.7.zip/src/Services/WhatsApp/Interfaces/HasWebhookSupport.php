<?php

namespace Solaris\Marketing\Services\WhatsApp\Interfaces;

interface HasWebhookSupport
{
	public function isValidWebhook(string $key): bool;

	public function getWebhookMessageId(): string;

	public function getWebhookEventType(): string;

	public function getWebhookMessage(): ?string;

	public function getWebhookButtonPayload(): ?string;
}
