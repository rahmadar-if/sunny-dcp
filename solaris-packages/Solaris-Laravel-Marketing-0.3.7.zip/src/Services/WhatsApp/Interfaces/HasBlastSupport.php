<?php

namespace Solaris\Marketing\Services\WhatsApp\Interfaces;

use GuzzleHttp\Promise\PromiseInterface;
use Illuminate\Http\Client\Factory;
use Illuminate\Http\Client\PendingRequest;
use Illuminate\Http\Client\Response;
use Solaris\Marketing\Models\WaTemplateDetail;
use Solaris\Marketing\Services\WhatsApp\BlastAudienceResponse;

interface HasBlastSupport
{
	public function buildSendRequest(
		PendingRequest|Factory $request,
		string $phone,
		WaTemplateDetail $waTemplateDetail,
		array $templateParams
	): PromiseInterface|Response;

	public function mappingBlastResponse(
		string $audienceId,
		string $waBlastId,
		Response $response
	): BlastAudienceResponse;

	public function isSuccessSendResponse(Response $response): bool;

	public function getSendResponseMessage(Response $response): ?string;
}
