<?php

namespace Solaris\Marketing\Services;

use Carbon\Carbon;
use Closure;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Solaris\Marketing\Const\CampaignBlastQuotaContextConst;
use Solaris\Marketing\Const\CampaignBlastTypeConst;
use Solaris\Core\Helpers\Helper;
use Solaris\Marketing\Models\CampaignBlastQuota;

class CampaignBlastQuotaService
{
	public static function bookEmailBlastQuota(string $provider, string $emailBlastId, Carbon|string|null $scheduleAt = null, ?string $userId = null): array
	{
		$model = Helper::model("email_blast_audience");

		return static::bookQuota(
			typeId         : CampaignBlastTypeConst::Email,
			provider       : $provider,
			audienceCounter: fn() => $model::where("email_blast_id", $emailBlastId)->blastable()->count(),
			context        : $scheduleAt ? CampaignBlastQuotaContextConst::Schedule : CampaignBlastQuotaContextConst::Send,
			sourceType     : Helper::model("email_blast"),
			sourceId       : $emailBlastId,
			userId         : $userId,
			scheduleAt     : is_string($scheduleAt) ? Carbon::parse($scheduleAt) : $scheduleAt
		);
	}

	public static function bookWaBlastQuota(string $provider, string $waBlastId, string $phoneColumn, Carbon|string|null $scheduleAt = null, ?string $userId = null): array
	{
		$model = Helper::model("wa_blast_audience");

		return static::bookQuota(
			typeId         : CampaignBlastTypeConst::WhatsApp,
			provider       : $provider,
			audienceCounter: fn() => $model::where("wa_blast_id", $waBlastId)->blastable($phoneColumn)->count(),
			context        : $scheduleAt ? CampaignBlastQuotaContextConst::Schedule : CampaignBlastQuotaContextConst::Send,
			sourceType     : Helper::model("wa_blast"),
			sourceId       : $waBlastId,
			userId         : $userId,
			scheduleAt     : is_string($scheduleAt) ? Carbon::parse($scheduleAt) : $scheduleAt
		);
	}

	public static function bookOneWaBlastQuota(string $provider, ?string $userId = null): array
	{
		return static::bookOneQuota(CampaignBlastTypeConst::WhatsApp, $provider, $userId);
	}

	public static function bookOneEmailBlastQuota(string $provider, ?string $userId = null): array
	{
		return static::bookOneQuota(CampaignBlastTypeConst::Email, $provider, $userId);
	}

	public static function consume(
		array $blastQuotas,
		int $totalProcessed,
		int $successCount,
		?string $sourceType = null,
		?string $sourceId = null,
		?string $userId = null): array
	{
		$requested = array_filter($blastQuotas, fn($amount) => (int) $amount > 0);

		if (empty($requested) || $totalProcessed <= 0) {
			return $blastQuotas;
		}

		$quotas = CampaignBlastQuota::whereIn("id", array_keys($requested))
			->orderBy("expired_at", "ASC")
			->lockForUpdate()
			->get()
			->keyBy("id");

		$remainingBook = $totalProcessed;
		$remainingUsed = $successCount;

		foreach ($quotas as $quotaId => $quota) {
			if ($remainingBook <= 0) {
				break;
			}

			$bookedAmount = (int) ($blastQuotas[$quotaId] ?? 0);

			if ($bookedAmount <= 0) {
				continue;
			}

			$bookReduction = min($remainingBook, $bookedAmount);
			$usedAddition  = min($remainingUsed, $bookReduction);

			$quota->consume(
				bookQty   : $bookReduction,
				usedQty   : $usedAddition,
				context   : CampaignBlastQuotaContextConst::Blast,
				sourceType: $sourceType,
				sourceId  : $sourceId,
				userId    : $userId
			);

			$blastQuotas[$quotaId] -= $bookReduction;
			$remainingBook         -= $bookReduction;
			$remainingUsed         -= $usedAddition;
		}

		static::logMissingQuotas($requested, $quotas->keys()->all(), "consume");

		return $blastQuotas;
	}

	public static function consumeOne(array $quotas, ?string $userId = null): void
	{
		DB::transaction(function() use ($quotas, $userId) {
			$quotaId = array_key_first($quotas);

			if (is_null($quotaId)) {
				throw new \Exception("No quota reference to consume");
			}

			$quota = CampaignBlastQuota::where("id", $quotaId)
				->lockForUpdate()
				->first();

			if (!$quota) {
				throw new \Exception("Quota [{$quotaId}] not found");
			}

			$quota->consume(
				bookQty: 1,
				usedQty: 1,
				context: CampaignBlastQuotaContextConst::Test,
				userId : $userId
			);
		});
	}

	public static function getEmailBlastQuota(string $provider): int
	{
		return static::getQuota(CampaignBlastTypeConst::Email, $provider);
	}

	public static function getWaBlastQuota(string $provider): int
	{
		return static::getQuota(CampaignBlastTypeConst::WhatsApp, $provider);
	}

	public static function cancel(
		array $quotas,
		?string $context = null,
		?string $sourceType = null,
		?string $sourceId = null,
		?string $userId = null): void
	{
		$requested = array_filter($quotas, fn($amount) => (int) $amount > 0);

		if (empty($requested)) {
			return;
		}

		DB::transaction(function() use ($requested, $context, $sourceType, $sourceId, $userId) {
			$data = CampaignBlastQuota::whereIn("id", array_keys($requested))
				->orderBy("expired_at", "ASC")
				->lockForUpdate()
				->get()
				->keyBy("id");

			foreach ($requested as $quotaId => $bookQty) {
				$quota = $data->get($quotaId);

				if (!$quota) {
					continue;
				}

				$quota->cancelBook(
					bookQty   : (int) $bookQty,
					context   : $context,
					sourceType: $sourceType,
					sourceId  : $sourceId,
					userId    : $userId
				);
			}

			static::logMissingQuotas($requested, $data->keys()->all(), "cancel");
		});
	}

	public static function getAvailableScheduleDates(string $provider, string $typeId): array
	{
		$quotas = CampaignBlastQuota::where('provider', $provider)
			->where('type_id', $typeId)
			->where('expired_at', '>=', today())
			->get(['effective_at', 'expired_at']);

		if ($quotas->isEmpty()) {
			return [];
		}

		$from = $quotas->min('effective_at');
		$now  = Carbon::now();
		$tz   = Auth::user()?->profile->timezone ?? 'UTC';

		return [
			'from' => ($now->gt($from) ? $now : $from)->setTimezone($tz)->format('Y-m-d H:i:s'),
			'to'   => $quotas->max('expired_at')->setTimezone($tz)->format('Y-m-d H:i:s'),
		];
	}

	public static function autoRenew(): int
	{
		$ids = CampaignBlastQuota::where("auto_renew", true)
			->where("expired_at", "<=", Carbon::now()->addDay())
			->orderBy("expired_at", "ASC")
			->pluck("id");

		$count = 0;

		foreach ($ids as $id) {
			if (static::renewQuota($id)) {
				$count++;
			}
		}

		return $count;
	}

	private static function renewQuota(string $id): bool
	{
		return DB::transaction(function() use ($id) {
			$quota = CampaignBlastQuota::where("id", $id)
				->lockForUpdate()
				->first();

			if (!$quota || !$quota->auto_renew) {
				return false;
			}

			[$effectiveAt, $expiredAt] = static::nextRenewalWindow($quota);

			$new = $quota->replicate();

			$quota->auto_renew = false;
			$quota->save();

			if (is_null($expiredAt)) {
				Log::error("Campaign blast quota auto renew skipped: unresolved period", [
					'quota_id'        => $quota->id,
					'period'          => $quota->period,
					'auto_renew_days' => $quota->auto_renew_days,
				]);

				return false;
			}

			$new->effective_at = $effectiveAt;
			$new->expired_at   = $expiredAt;
			$new->quota_book   = 0;
			$new->quota_used   = 0;
			$new->auto_renew   = true;
			$new->save();

			return true;
		});
	}

	private static function nextRenewalWindow(CampaignBlastQuota $quota): array
	{
		$now         = Carbon::now();
		$effectiveAt = $quota->expired_at->copy();
		$expiredAt   = static::addPeriod($effectiveAt, $quota->period, $quota->auto_renew_days);

		if (is_null($expiredAt)) {
			return [null, null];
		}

		while ($expiredAt->lte($now)) {
			$effectiveAt = $expiredAt->copy();
			$expiredAt   = static::addPeriod($effectiveAt, $quota->period, $quota->auto_renew_days);
		}

		return [$effectiveAt, $expiredAt];
	}

	private static function addPeriod(Carbon $from, ?string $period, ?int $autoRenewDays): ?Carbon
	{
		return match ($period) {
			'daily'   => $from->copy()->addDay(),
			'weekly'  => $from->copy()->addWeek(),
			'monthly' => $from->copy()->addMonth(),
			'yearly'  => $from->copy()->addYear(),
			'custom'  => $autoRenewDays > 0 ? $from->copy()->addDays($autoRenewDays) : null,
			default   => null,
		};
	}

	private static function logMissingQuotas(array $requested, array $found, string $operation): void
	{
		$missing = array_diff(array_keys($requested), $found);

		if (empty($missing)) {
			return;
		}

		Log::error("Campaign blast quota {$operation} skipped missing rows", [
			'quota_ids' => array_values($missing),
			'requested' => array_intersect_key($requested, array_flip($missing)),
		]);
	}

	private static function getQuota(string $typeId, string $provider): int
	{
		$now  = Carbon::now();
		$data = CampaignBlastQuota::select(["total_quota", "quota_book", "quota_used"])
			->where("provider", $provider)
			->where("type_id", $typeId)
			->where("effective_at", "<=", $now)
			->where("expired_at", ">=", $now)
			->get();

		if ($data->isEmpty()) {
			return 0;
		}

		$totalQuota = $data->sum("total_quota");
		$totalBook  = $data->sum("quota_book");
		$totalUsed  = $data->sum("quota_used");

		return $totalQuota - $totalBook - $totalUsed;
	}

	private static function bookOneQuota(string $typeId, string $provider, ?string $userId = null): array
	{
		return DB::transaction(function() use ($typeId, $provider, $userId) {
			$now              = Carbon::now();
			$configKey        = $typeId === CampaignBlastTypeConst::WhatsApp ? "wa_blast.safety_buffer" : "email_blast.safety_buffer";
			$safetyBufferTime = $now->copy()->addHours((int) Helper::config($configKey));

			$quota = CampaignBlastQuota::where("provider", $provider)
				->where("type_id", $typeId)
				->where("effective_at", "<=", $now)
				->where("expired_at", ">=", $safetyBufferTime)
				->orderBy("expired_at", "ASC")
				->lockForUpdate()
				->first();

			if (!$quota) {
				throw new \Exception("No active quota found");
			}

			if ($quota->quota() <= 0) {
				throw new \Exception("No available quota");
			}

			$quota->book(
				request: 1,
				context: CampaignBlastQuotaContextConst::Test,
				userId : $userId
			);

			return [$quota->id => 1];
		});
	}

	private static function bookQuota(
		string $typeId,
		string $provider,
		Closure $audienceCounter,
		string $context,
		?string $sourceType = null,
		?string $sourceId = null,
		?string $userId = null,
		?Carbon $scheduleAt = null): array
	{
		return DB::transaction(function() use ($typeId, $provider, $audienceCounter, $context, $sourceType, $sourceId, $userId, $scheduleAt) {
			$totalAudience = (int) $audienceCounter();

			if ($totalAudience <= 0) {
				throw new \Exception("No audience eligible to be sent");
			}

			$targetDate = $scheduleAt ?? Carbon::now();

			$configKey        = $typeId === CampaignBlastTypeConst::WhatsApp ? "wa_blast.safety_buffer" : "email_blast.safety_buffer";
			$safetyBuffer     = (int) Helper::config($configKey);
			$safetyBufferTime = $targetDate->copy()->addHours($safetyBuffer);

			$dataWithoutBuffer = CampaignBlastQuota::select(["id", "total_quota", "quota_book", "quota_used", "expired_at"])
				->selectRaw("(total_quota - quota_book - quota_used) AS quota_available")
				->where("provider", $provider)
				->where("type_id", $typeId)
				->where("effective_at", "<=", $targetDate)
				->where("expired_at", ">=", $targetDate)
				->orderBy("expired_at", "ASC")
				->orderBy("quota_available", "ASC")
				->orderBy("created_at", "ASC")
				->lockForUpdate()
				->get();

			if ($dataWithoutBuffer->isEmpty()) {
				throw new \Exception("No active quota found");
			}

			$data = $dataWithoutBuffer->filter(fn($quota) => $quota->expired_at->gte($safetyBufferTime));
			if ($data->isEmpty()) {
				throw new \Exception("Quota booking blocked: All available quotas expire within safety buffer ({$safetyBuffer} hours)");
			}

			$totalAvail = $data->sum("quota_available");
			if ($totalAudience > $totalAvail) {
				throw new \Exception("Insufficient quota: need {$totalAudience}, available {$totalAvail}");
			}

			$requestBook = $totalAudience;
			$quotas      = [];

			foreach ($data as $quota) {
				$quotaAvail = $quota->quota();
				$rest       = $requestBook - (int) $quotaAvail;

				$totalBook = $rest > 0 ? $quotaAvail : $requestBook;

				$quota->book(
					request   : $totalBook,
					context   : $context,
					sourceType: $sourceType,
					sourceId  : $sourceId,
					userId    : $userId
				);

				$quotas[$quota->id] = $totalBook;

				if ($rest <= 0) {
					break;
				}

				$requestBook = $rest;
			}

			return $quotas;
		});
	}
}
