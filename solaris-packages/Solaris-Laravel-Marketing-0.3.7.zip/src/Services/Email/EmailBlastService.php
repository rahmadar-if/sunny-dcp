<?php

namespace Solaris\Marketing\Services\Email;

use Carbon\Carbon;
use InvalidArgumentException;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Response;
use Illuminate\Mail\Mailables\Address;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Interfaces\Model\SolarisUser;
use Solaris\Marketing\Const\CampaignBlastQuotaContextConst;
use Solaris\Marketing\Const\CampaignBlastStatusConst;
use Solaris\Marketing\Const\EmailBlastAudienceStatusConst;
use Solaris\Marketing\Jobs\EmailBlastJob;
use Solaris\Marketing\Jobs\EmailBlastWebhookJob;
use Solaris\Marketing\Jobs\EmailBlastWebhookProcessJob;
use Solaris\Marketing\Models\EmailBlast;
use Solaris\Marketing\Services\CampaignBlastQuotaService;
use Solaris\Marketing\Services\Email\Interfaces\HasWebhookSupport;

class EmailBlastService
{
	public static function send(EmailBlast|string $emailBlast, ?SolarisUser $user = null, ?string $provider = null): void
	{
		$provider = $provider ?? Helper::config('email_blast.default');
		$driver   = static::getDriver($provider);
		$campaign = static::resolveCampaign($emailBlast);
		$actor    = $user ?? Auth::user();

		static::validateCanBlast($campaign);
		static::releaseLeftoverQuotas($campaign);

		$quotas = CampaignBlastQuotaService::bookEmailBlastQuota($provider, $campaign->id, userId: $actor?->id);

		$campaign->status_id     = CampaignBlastStatusConst::Queued;
		$campaign->queue_at      = Carbon::now();
		$campaign->error_message = null;
		$campaign->quotas        = json_encode($quotas);
		$campaign->save();

		EmailBlastJob::dispatch($driver, $campaign, $actor);
	}

	public static function schedule(EmailBlast|string $emailBlast, string $scheduleAt, ?string $provider = null, ?SolarisUser $user = null): void
	{
		$provider = $provider ?? Helper::config('email_blast.default');
		$campaign = static::resolveCampaign($emailBlast);
		$actor    = $user ?? Auth::user();

		$scheduleAtCarbon = Carbon::parse($scheduleAt);
		if ($scheduleAtCarbon->lt(Carbon::now())) {
			throw new \Exception("The scheduled time cannot be set to an earlier time");
		}

		static::validateCanBlast($campaign, $scheduleAtCarbon);
		static::releaseLeftoverQuotas($campaign);

		$quotas = CampaignBlastQuotaService::bookEmailBlastQuota($provider, $campaign->id, $scheduleAt, $actor?->id);

		$campaign->status_id     = CampaignBlastStatusConst::Scheduled;
		$campaign->schedule_at   = $scheduleAt;
		$campaign->error_message = null;
		$campaign->quotas        = json_encode($quotas);
		$campaign->save();
	}

	public static function cancel(EmailBlast|string $emailBlast): void
	{
		$campaign = static::resolveCampaign($emailBlast);

		if ($campaign->status_id != CampaignBlastStatusConst::Scheduled) {
			throw new \Exception("You can only cancel in scheduled status");
		}

		$scheduleAt = $campaign->schedule_at->startOfMinute();
		if ($scheduleAt->lte(now()->startOfMinute())) {
			throw new \Exception("Cancellation is only allowed before the scheduled time is reached");
		}

		CampaignBlastQuotaService::cancel(
			quotas    : json_decode($campaign->quotas ?? '[]', true) ?? [],
			context   : CampaignBlastQuotaContextConst::Cancel,
			sourceType: Helper::model("email_blast"),
			sourceId  : $campaign->id
		);

		$campaign->status_id     = CampaignBlastStatusConst::Draft;
		$campaign->schedule_at   = null;
		$campaign->error_message = null;
		$campaign->quotas        = null;
		$campaign->save();
	}

	public static function checkQuota(?string $provider = null): int
	{
		$provider = $provider ?? Helper::config('email_blast.default');
		return CampaignBlastQuotaService::getEmailBlastQuota($provider);
	}

	public static function queueWebhook(string|array $payload, array $headers = [], ?string $provider = null): Response
	{
		$config = [];
		$code   = 406;

		try {
			$config  = static::resolveWebhookConfig($provider);
			$code    = $config['successCode'];
			$payload = is_array($payload) ? json_encode($payload) : $payload;

			$driver = ($config['driver'])::forWebhook($payload, $headers);

			if (!$driver->isValidWebhook($config['key'])) {
				throw new \Exception("Webhook Signing Key is invalid");
			}

			$messageId = $driver->getWebhookMessageId();
			$eventType = $driver->getWebhookEventType();
			$message   = $driver->getWebhookMessage();

			if (empty($messageId)) {
				throw new \Exception("MessageId is null or empty");
			}

			if (empty($eventType)) {
				throw new \Exception("EventType is null or empty");
			}

			EmailBlastWebhookJob::dispatch($payload, $messageId, $eventType, $message);
		} catch (\Exception $e) {
			Log::error("Email Webhook Queue fail", [
				'message'   => $e->getMessage(),
				'exception' => $e
			]);

			$code = $config['failCode'] ?? 406;
		}

		return response('', $code);
	}

	public static function processWebhook(?string $provider = null): void
	{
		try {
			$config = static::resolveWebhookConfig($provider);
			EmailBlastWebhookProcessJob::dispatch($config['driver']);
		} catch (\Exception $e) {
			Log::error("Email Webhook Process fail", [
				'message'   => $e->getMessage(),
				'exception' => $e
			]);
		}
	}

	public static function getDriver(?string $provider = null): string
	{
		$config = Helper::config('email_blast.providers.' . ($provider ?? Helper::config('email_blast.default')));
		if (!$config || empty($config['driver'])) {
			throw new InvalidArgumentException(
				"Email blast provider [{$provider}] is not configured properly"
			);
		}

		$driverClass = $config['driver'];
		if (!is_subclass_of($driverClass, EmailProvider::class)) {
			throw new InvalidArgumentException(
				"Driver [{$driverClass}] must extend EmailProvider"
			);
		}

		return $driverClass;
	}

	public static function sendOne(
		string $email,
		string $subject,
		string $html,
		?Model $contact = null,
		?Address $sender = null,
		?string $provider = null
	): array {
		$provider = $provider ?? Helper::config('email_blast.default');
		$driver   = static::getDriver($provider);

		if ($contact) {
			$html = EmailMergeTagService::compile($contact, $html);
		}

		$quotas  = CampaignBlastQuotaService::bookOneEmailBlastQuota($provider, Auth::id());
		$settled = false;

		try {
			$result = $driver::send($email, $subject, $html, $sender, $contact?->name);

			$settled = true;

			if ($result['success']) {
				CampaignBlastQuotaService::consumeOne($quotas, Auth::id());
			} else {
				CampaignBlastQuotaService::cancel($quotas, CampaignBlastQuotaContextConst::Send);
				throw new \Exception($result['message'] ?? "Failed to send email");
			}

			return $result;
		} finally {
			if (!$settled) {
				try {
					CampaignBlastQuotaService::cancel($quotas, CampaignBlastQuotaContextConst::Send);
				} catch (\Throwable) {}
			}
		}
	}

	public static function sendOneView(
		string $email,
		string $subject,
		string $view,
		array $data = [],
		?Model $contact = null,
		?Address $sender = null,
		?string $provider = null
	): array {
		return static::sendOne($email, $subject, view($view, $data)->render(), $contact, $sender, $provider);
	}

	public static function updateCampaignTotals(string $campaignId): void
	{
		UpdateCampaignStatus::updateStatus([$campaignId]);
	}

	public static function resolveCampaign(EmailBlast|string $emailBlast): EmailBlast
	{
		return is_string($emailBlast) && Str::isUuid($emailBlast)
			? Helper::model("email_blast")::find($emailBlast)
			: $emailBlast;
	}

	private static function resolveWebhookConfig(?string $provider): array
	{
		$provider    = $provider ?? Helper::config('email_blast.default');
		$driverClass = static::getDriver($provider);
		$config      = Helper::config('email_blast.providers.' . $provider);

		if (!is_a($driverClass, HasWebhookSupport::class, true)) {
			throw new InvalidArgumentException(
				"Driver [{$driverClass}] must implement HasWebhookSupport"
			);
		}

		return [
			'key'         => $config['webhook_key'],
			'successCode' => $config['webhook_success_code'] ?? 200,
			'failCode'    => $config['webhook_fail_code'] ?? 406,
			'driver'      => $driverClass
		];
	}

	public static function updateToSending(EmailBlast $campaign, SolarisUser $user): void
	{
		$campaign->sent_at   = Carbon::now();
		$campaign->status_id = CampaignBlastStatusConst::Sending;
		$campaign->save();

		$user->sendInAppNotification(
			title  : $campaign->title,
			message: "Email blast process to sending",
			url    : route("marketing.email-blast", ["id" => $campaign->id])
		);
	}

	public static function updateToCompleted(EmailBlast $campaign, SolarisUser $user, array $blastQuotas, bool $isSuccess, ?string $message = null): void
	{
		$remainingQuotas = array_filter($blastQuotas ?? [], fn ($amount) => $amount > 0);
		$cancelSucceeded = true;

		if (!empty($remainingQuotas)) {
			try {
				CampaignBlastQuotaService::cancel(
					quotas    : $remainingQuotas,
					context   : CampaignBlastQuotaContextConst::Completed,
					sourceType: Helper::model("email_blast"),
					sourceId  : $campaign->id,
					userId    : $user?->id
				);
			} catch (\Exception $e) {
				$cancelSucceeded = false;

				Log::error("EmailBlast quota cancel failed", [
					'campaign_id' => $campaign->id,
					'quotas'      => $remainingQuotas,
					'message'     => $e->getMessage(),
				]);
			}
		}

		$campaign->completed_at  = Carbon::now();
		$campaign->status_id     = $isSuccess ? CampaignBlastStatusConst::Completed : CampaignBlastStatusConst::Failed;
		$campaign->error_message = $message;
		$campaign->quotas        = $cancelSucceeded ? null : json_encode($remainingQuotas);
		$campaign->save();

		$user->sendInAppNotification(
			title  : $campaign->title,
			message: $isSuccess ? "Email blast process is complete" : $message,
			url    : route("marketing.email-blast", ["id" => $campaign->id])
		);
	}

	public static function updateAudiences(string $campaignId, array $blastQuotas, array $responses, ?string $userId = null): array
	{
		$successCount = collect($responses)
			->filter(fn($item) => $item["status_id"] == EmailBlastAudienceStatusConst::Progress)
			->count();

		return DB::transaction(function () use($campaignId, $blastQuotas, $responses, $successCount, $userId) {
			DB::table("email_blast_audience_temp")->insert($responses);

			UpdateCampaignStatus::updateAudienceProgress($campaignId);

			DB::table("email_blast_audience_temp")
				->where('email_blast_id', $campaignId)
				->delete();

			$remainingQuotas = CampaignBlastQuotaService::consume(
				blastQuotas   : $blastQuotas,
				totalProcessed: count($responses),
				successCount  : $successCount,
				sourceType    : Helper::model("email_blast"),
				sourceId      : $campaignId,
				userId        : $userId
			);

			DB::table("email_blasts")
				->where('id', $campaignId)
				->update(['quotas' => json_encode($remainingQuotas)]);

			return $remainingQuotas;
		});
	}

	private static function releaseLeftoverQuotas(EmailBlast $campaign): void
	{
		$leftover = array_filter(json_decode($campaign->quotas ?? '[]', true) ?? [], fn ($amount) => $amount > 0);

		if (empty($leftover)) {
			return;
		}

		try {
			CampaignBlastQuotaService::cancel(
				quotas    : $leftover,
				context   : CampaignBlastQuotaContextConst::Leftover,
				sourceType: Helper::model("email_blast"),
				sourceId  : $campaign->id
			);
		} catch (\Exception $e) {
			Log::warning("EmailBlast leftover quota cancel failed", [
				'campaign_id' => $campaign->id,
				'quotas'      => $leftover,
				'message'     => $e->getMessage(),
			]);
		}
	}

	private static function validateCanBlast(EmailBlast $campaign, ?Carbon $scheduleAt = null): void
	{
		$validStatus = in_array($campaign->status_id, [CampaignBlastStatusConst::Draft, CampaignBlastStatusConst::Failed]);
		if (!$validStatus) {
			throw new \Exception("Email blasts can only be done when the status is draft/failed");
		}

		if (empty($campaign->subject)) {
			throw new \Exception("Subject is empty");
		}

		if (empty($campaign->sender_name) || empty($campaign->sender_email)) {
			throw new \Exception("Sender name and email is empty");
		}

		if (empty($campaign->body)) {
			throw new \Exception("Email template is empty");
		}

		if ($campaign->audiences()->count() == 0) {
			throw new \Exception("Audience is empty");
		}

		$targetDate = $scheduleAt ? $scheduleAt->startOfDay() : today();
		$dailyLimit = Helper::config("email_blast.daily_limit");

		if ((static::getInProgress($targetDate) + 1) > $dailyLimit) {
			throw new \Exception("The daily limit has been reached. Please wait for another email blast to be sent.");
		}
	}

	/** */

	private static function getInProgress(Carbon $date): int
	{
		return Helper::model("email_blast")::where(function($query) use($date) {
			$query->whereIn("status_id", [
				CampaignBlastStatusConst::Queued,
				CampaignBlastStatusConst::Sending
			])
			->whereDate("queue_at", $date);
		})
		->orWhere(function($query) use($date) {
			$query->where("status_id", CampaignBlastStatusConst::Scheduled)
				->whereDate("schedule_at", $date);
		})
		->count();
	}
}
