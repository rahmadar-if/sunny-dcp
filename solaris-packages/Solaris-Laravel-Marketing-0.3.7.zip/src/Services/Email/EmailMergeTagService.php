<?php

namespace Solaris\Marketing\Services\Email;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Helpers\Helper;
use Solaris\Marketing\Attributes\EmailMergeTags;

class EmailMergeTagService
{
	private const DEFAULTS = [
		'name',
		'recipients_name',
		'primary_phone',
		'primary_mobile_phone',
		'full_job',
		'salutation',
		'also_known_as'
	];

	public static function resolve(string $modelClass): array
	{
		$attribute = Helper::getClassAttribute($modelClass, EmailMergeTags::class);
		$columns   = $modelClass::getColumns();
		$exclude   = $attribute?->exclude ?? [];

		$defaults = [];
		$rest     = [];
		$usedKeys = [];

		foreach ($columns as $col) {
			$name = $col['name'];
			$isFk = $col['type'] === 'lookup';
			$key  = $isFk ? substr($name, 0, -3) : $name;

			if(in_array($name, $exclude) || in_array($key, $exclude)) {
				continue;
			}

			if(isset($usedKeys[$key])) {
				continue;
			}

			$usedKeys[$key] = true;

			$entry = [
				'label' => $col['displayName'],
				'value' => '{{'.$key.'}}',
			];

			if(in_array($key, self::DEFAULTS)) {
				$defaults[$key] = $entry;
			} else {
				$rest[] = $entry;
			}
		}

		$orderedEntries = [];
		foreach (self::DEFAULTS as $defaultKey) {
			if(isset($defaults[$defaultKey])) {
				$orderedEntries[] = $defaults[$defaultKey];
			}
		}

		return [
			[
				'category' => 'Default',
				'entries'  => $orderedEntries,
			],
			[
				'category' => 'Contact',
				'entries'  => $rest,
			],
		];
	}

	public static function compile(Model $contact, string $html): string
	{
		preg_match_all('/\{\{([\w.]+)\}\}/', $html, $matches);

		$keys = array_unique($matches[1] ?? []);
		if(empty($keys)) {
			return $html;
		}

		$search  = [];
		$replace = [];

		foreach ($keys as $key) {
			$search[]  = '{{'.$key.'}}';
			$replace[] = self::resolveValue($contact, $key);
		}

		return str_replace($search, $replace, $html);
	}

	public static function extractKeys(string $html): array
	{
		preg_match_all('/\{\{([\w.]+)\}\}/', $html, $matches);

		return array_values(array_unique($matches[1] ?? []));
	}

	private static function resolveValue(Model $model, string $key): string
	{
		$parts = explode('.', $key);
		$value = $model;

		foreach ($parts as $part) {
			if (!($value instanceof Model)) {
				return '';
			}

			$value = $value->{$part};

			if (is_null($value)) {
				return '';
			}
		}

		if ($value instanceof Model) {
			return (string) ($value->getDisplayValue() ?? '');
		}

		return (string) $value;
	}
}
