<?php

namespace Solaris\Marketing\Services\Email;

use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Client\Pool;
use Illuminate\Http\Client\Response;
use Illuminate\Mail\Mailables\Address;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Solaris\Core\Interfaces\Model\SolarisUser;
use Solaris\Marketing\Const\EmailBlastAudienceStatusConst;
use Solaris\Marketing\Models\EmailBlast;
use Solaris\Marketing\Services\Email\Interfaces\HasBlastSupport;

abstract class EmailProvider implements HasBlastSupport
{
	protected array $config 			 = [];
	protected ?SolarisUser $authUser	 = null;
	protected ?EmailBlast $blastCampaign = null;
	protected array $blastQuotas 		 = [];
	protected string $webhookPayload 	 = '';
	protected array $webhookHeader 	 	 = [];

	public static string $eventOpen         = 'open';
	public static string $eventClick        = 'click';
	public static string $eventDelivered    = 'delivered';
	public static string $eventUnsubscribed = 'unsubscribed';
	public static string $eventSoftBounce   = 'soft_bounce';
	public static string $eventHardBounce   = 'hard_bounce';

	abstract protected function getConfig(): array;

	public static function forBlast(EmailBlast|string $campaign, SolarisUser $user): static
	{
		$instance         = new static();
		$instance->config = $instance->getConfig();

		if (!$instance->config) {
			throw new \Exception("Email blast provider is not found");
		}

		$instance->blastCampaign = EmailBlastService::resolveCampaign($campaign);
		if (is_null($instance->blastCampaign)) {
			throw new \Exception("Email blast campaign not found");
		}

		$instance->authUser    = $user;
		$instance->blastQuotas = json_decode($instance->blastCampaign->quotas, true);

		return $instance;
	}

	public static function forWebhook(string $webhookPayload, array $webhookHeader = []): static
	{
		$instance                 = new static();
		$instance->config         = $instance->getConfig();
		$instance->webhookPayload = $webhookPayload;
		$instance->webhookHeader  = $webhookHeader;

		return $instance;
	}

	// Sends already-compiled HTML: merge tags and contact resolution stay the caller's job.
	final public static function send(
		string $email,
		string $subject,
		string $html,
		?Address $sender = null,
		?string $recipientName = null
	): array {
		$instance         = new static();
		$instance->config = $instance->getConfig();

		if (!$instance->config) {
			throw new \Exception("Email provider is not found");
		}

		$sender    = $sender ?? new Address(config('mail.from.address'), config('mail.from.name'));
		$recipient = new Address($email, $recipientName ?? $email);
		$response  = $instance->buildBlastRequest(Http::getFacadeRoot(), $subject, $sender, $recipient, $html);

		return [
			'success' => $instance->isSuccessSendResponse($response),
			'message' => $instance->getSendResponseMessage($response),
		];
	}

	protected function getChunkSize(): int
	{
		return $this->config['chunk_size'] ?? 100;
	}

	protected function getRateLimit(): int
	{
		return $this->config['rate_limit'] ?? 10;
	}

	final public function blast(): void
	{
		$subject       = $this->blastCampaign->subject;
		$sender        = new Address($this->blastCampaign->sender_email, $this->blastCampaign->sender_name);
		$emailTemplate = $this->blastCampaign->body;
		$maxPool       = $this->getRateLimit();

		$templateKeys    = EmailMergeTagService::extractKeys($emailTemplate);
		$contactColumns  = array_unique(array_merge(['name', 'email'], $templateKeys));
		$contactPrepared = 'contact[' . implode(', ', $contactColumns) . ']';

		$success = false;
		$message = null;

		EmailBlastService::updateToSending($this->blastCampaign, $this->authUser);

		try {
			$this->blastCampaign->audiences()
				->where("email_blast_id", $this->blastCampaign->id)
				->where("status_id", EmailBlastAudienceStatusConst::Pending)
				->whereHas('contact', fn($q) => $q->whereNull('email')->orWhere('email', ''))
				->update([
					'status_id' => EmailBlastAudienceStatusConst::Failed,
					'message' 	=> 'Email is empty'
				]);

			do {
				$audiences = $this->blastCampaign->audiences()->prepared($contactPrepared, "status_id")
					->where("email_blast_id", $this->blastCampaign->id)
					->blastable()
					->sort("contact.email:asc")
					->limit($this->getChunkSize())
					->get();

				if($audiences->isEmpty()) {
					break;
				}

				$this->sendBatchRequest($audiences, $subject, $sender, $emailTemplate, $maxPool);

				EmailBlastService::updateCampaignTotals($this->blastCampaign->id);
			} while (true);

			$success = true;
		} catch (\Throwable $e) {
			$message = $e->getMessage();

			Log::error("Email Blast Process fail", [
				'message'   => $message,
				'exception' => $e
			]);
		}

		EmailBlastService::updateToCompleted($this->blastCampaign, $this->authUser, $this->blastQuotas, $success, $message);
	}

	final protected function compileEmailTemplate(string $emailTemplate, ?Model $contact = null): string
	{
		if (!$contact) {
			return $emailTemplate;
		}

		return EmailMergeTagService::compile($contact, $emailTemplate);
	}

	private function sendBatchRequest(Collection $audiences, string $subject, Address $sender, string $emailTemplate, int $maxPool): void
	{
		$pools = [];

		foreach ($audiences as $audience) {
			if (empty($audience->contact?->email) || empty($audience->contact?->name)) {
				continue;
			}

			$pools[] = [
				'id'        => $audience->id,
				'subject'   => $subject,
				'sender'    => $sender,
				'recipient' => new Address($audience->contact->email, $audience->contact->name),
				'message'   => EmailMergeTagService::compile($audience->contact, $emailTemplate)
			];

			if (count($pools) == $maxPool) {
				$this->commitPool($this->sendRequest($pools));
				$pools = [];
			}
		}

		if (!empty($pools)) {
			$this->commitPool($this->sendRequest($pools));
		}
	}

	private function commitPool(array $responses): void
	{
		if (empty($responses)) {
			return;
		}

		$this->blastQuotas = EmailBlastService::updateAudiences(
			$this->blastCampaign->id,
			$this->blastQuotas,
			$responses,
			$this->authUser?->id
		);
	}

	private function resolveBlastResponse(string $audienceId, Response|\Throwable $response): BlastAudienceResponse
	{
		if ($response instanceof \Throwable) {
			return new BlastAudienceResponse(
				audienceId  : $audienceId,
				emailBlastId: $this->blastCampaign->id,
				statusId    : EmailBlastAudienceStatusConst::Failed,
				message     : $response->getMessage(),
			);
		}

		return $this->mappingBlastResponse($audienceId, $this->blastCampaign->id, $response);
	}

	private function sendRequest(array $requestPools): array
	{
		$results = [];
		$start   = microtime(true);

		$responses = Http::pool(fn (Pool $pool) => array_map(fn(array $request) => $this->buildBlastRequest(
			$pool->as($request['id']),
			$request['subject'],
			$request['sender'],
			$request['recipient'],
			$request['message']
		), $requestPools));

		foreach ($responses as $key => $response) {
			$results[] = $this->resolveBlastResponse($key, $response)->toArray();
		}

		$elapsed = microtime(true) - $start;
		if ($elapsed < 1) {
			usleep((int)((1 - $elapsed) * 1000000));
		}

		return $results;
	}
}
