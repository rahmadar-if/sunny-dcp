<?php

namespace Solaris\Marketing\Services\Email\Interfaces;

use GuzzleHttp\Promise\PromiseInterface;
use Illuminate\Http\Client\Factory;
use Illuminate\Http\Client\PendingRequest;
use Illuminate\Http\Client\Response;
use Illuminate\Mail\Mailables\Address;
use Solaris\Marketing\Services\Email\BlastAudienceResponse;

interface HasBlastSupport
{
	public function buildBlastRequest(
		PendingRequest|Factory $request,
		string $subject,
		Address $sender,
		Address $recipient,
		string $message
	): PromiseInterface|Response;

	public function mappingBlastResponse(
		string $audienceId,
		string $emailBlastId,
		Response $response
	): BlastAudienceResponse;

	public function isSuccessSendResponse(Response $response): bool;

	public function getSendResponseMessage(Response $response): ?string;
}
