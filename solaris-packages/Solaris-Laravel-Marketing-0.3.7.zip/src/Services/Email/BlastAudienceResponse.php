<?php

namespace Solaris\Marketing\Services\Email;

class BlastAudienceResponse
{
	public function __construct(
		public readonly string  $audienceId,
		public readonly string  $emailBlastId,
		public readonly string  $statusId,
		public readonly ?string $messageId = null,
		public readonly ?string $message   = null,
	) {}

	public function toArray(): array
	{
		return [
			'id'             => $this->audienceId,
			'email_blast_id' => $this->emailBlastId,
			'status_id'      => $this->statusId,
			'message_id'     => $this->messageId,
			'message'        => $this->message,
		];
	}
}
