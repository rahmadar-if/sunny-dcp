<?php

namespace Solaris\Marketing\Services\Email;

use Illuminate\Support\Facades\DB;
use Solaris\Marketing\Const\EmailBlastAudienceStatusConst;

class EmailWebhookProcessor
{
	private const CHUNK_SIZE = 1000;

	public function __construct(private string $driverClass)
	{}

	public function process(): void
	{
		$webhooks = DB::table("email_blast_webhooks", "webhook")
			->select(
				"audiences.id as audience_id",
				"audiences.email_blast_id as email_blast_id",
				"audiences.status_id as audience_status_id",
				"audiences.open as open",
				"audiences.click as click",
				"audiences.unsubscribe as unsubscribe",
				"audiences.message as audience_message",
				"webhook.id as webhook_id",
				"webhook.message_id as message_id",
				"webhook.event_type as event_type",
				"webhook.message as message",
			)
			->join("email_blast_audiences as audiences", "audiences.message_id", "=", "webhook.message_id")
			->where("audiences.status_id", "!=", EmailBlastAudienceStatusConst::Pending)
			->orderBy("webhook.created_at")
			->limit(self::CHUNK_SIZE)
			->get();

		if ($webhooks->isEmpty()) {
			return;
		}

		$webhookGroups = $webhooks->groupBy("message_id");
		$emailBlastIds = [];
		$data          = [];

		foreach ($webhookGroups as $messageId => $items) {
			$audienceStatus  = $items->first()->audience_status_id;
			$audienceOpen    = $items->first()->open;
			$audienceClick   = $items->first()->click;
			$audienceUnsub   = $items->first()->unsubscribe;
			$audienceMessage = $items->first()->audience_message;

			$messages = trim(implode("\n", $items->pluck("message")->filter()->all()));
			if (!empty($messages)) {
				$audienceMessage = $messages;
			}

			$openCount        = $items->where('event_type', $this->driverClass::$eventOpen)->count() + $audienceOpen;
			$clickCount       = $items->where('event_type', $this->driverClass::$eventClick)->count() + $audienceClick;
			$deliveredCount   = $items->where('event_type', $this->driverClass::$eventDelivered)->count();
			$unsubscribeCount = $items->where('event_type', $this->driverClass::$eventUnsubscribed)->count();
			$softBounceCount  = $items->where('event_type', $this->driverClass::$eventSoftBounce)->count();
			$hardBounceCount  = $items->where('event_type', $this->driverClass::$eventHardBounce)->count();

			$isDelivered = ($deliveredCount > 0 && $audienceStatus == EmailBlastAudienceStatusConst::Progress)
				|| $audienceStatus == EmailBlastAudienceStatusConst::Delivered
				|| $openCount > 0
				|| $clickCount > 0
				|| $unsubscribeCount > 0;

			$isSoftBounce = ($softBounceCount > 0 && $audienceStatus == EmailBlastAudienceStatusConst::Progress)
				|| $audienceStatus == EmailBlastAudienceStatusConst::SoftBounce;

			$isHardBounce = ($hardBounceCount > 0 && $audienceStatus == EmailBlastAudienceStatusConst::Progress)
				|| $audienceStatus == EmailBlastAudienceStatusConst::HardBounce;

			$isUnsubscribe = $unsubscribeCount > 0 || $audienceUnsub;

			$statusId = $audienceStatus;
			if ($isDelivered) {
				$statusId = EmailBlastAudienceStatusConst::Delivered;
			} elseif ($isSoftBounce) {
				$statusId = EmailBlastAudienceStatusConst::SoftBounce;
			} elseif ($isHardBounce) {
				$statusId = EmailBlastAudienceStatusConst::HardBounce;
			}

			$emailBlastIds[] = $items->first()->email_blast_id;

			$data[] = [
				"id"          => $items->first()->webhook_id,
				"audience_id" => $items->first()->audience_id,
				"message_id"  => $messageId,
				"message"     => $audienceMessage,
				"status_id"   => $statusId,
				"open"        => $openCount,
				"click"       => $clickCount,
				"unsubscribe" => $isUnsubscribe,
			];
		}

		$webhookIdDeletes = $webhooks->pluck("webhook_id")->all();
		$webhookIds       = array_column($data, "id");
		$emailBlastIds    = array_unique($emailBlastIds);

		DB::transaction(function () use ($webhookIdDeletes, $webhookIds, $emailBlastIds, $data) {
			DB::table("email_blast_webhook_temp")->insert($data);

			$this->bulkUpdateAudiences();

			DB::table("email_blast_webhook_temp")
				->whereIn('id', $webhookIds)
				->delete();

			UpdateCampaignStatus::updateStatus($emailBlastIds);

			DB::table("email_blast_webhooks")
				->whereIn('id', $webhookIdDeletes)
				->delete();
		});
	}

	private function bulkUpdateAudiences(): void
	{
		$driver = DB::connection()->getDriverName();

		match ($driver) {
			'mysql', 'mariadb' => $this->bulkUpdateMySQL(),
			'pgsql'            => $this->bulkUpdatePostgreSQL(),
			'sqlsrv'           => $this->bulkUpdateSQLServer(),
			default            => throw new \Exception("Unsupported database driver: {$driver}")
		};
	}

	private function bulkUpdateMySQL(): void
	{
		DB::statement("UPDATE email_blast_audiences audience
			INNER JOIN email_blast_webhook_temp temp
				ON audience.id = temp.audience_id
				AND audience.message_id = temp.message_id
			SET
				audience.status_id   = temp.status_id,
				audience.open        = temp.open,
				audience.click       = temp.click,
				audience.unsubscribe = temp.unsubscribe,
				audience.message     = temp.message");
	}

	private function bulkUpdatePostgreSQL(): void
	{
		DB::statement("UPDATE email_blast_audiences audience
			SET
				status_id   = temp.status_id,
				open        = temp.open,
				click       = temp.click,
				unsubscribe = temp.unsubscribe,
				message     = temp.message
			FROM email_blast_webhook_temp temp
			WHERE audience.id = temp.audience_id
			AND audience.message_id = temp.message_id");
	}

	private function bulkUpdateSQLServer(): void
	{
		DB::statement("UPDATE audience
			SET
				status_id   = temp.status_id,
				open        = temp.open,
				click       = temp.click,
				unsubscribe = temp.unsubscribe,
				message     = temp.message
			FROM email_blast_audiences audience
			INNER JOIN email_blast_webhook_temp temp
				ON audience.id = temp.audience_id
				AND audience.message_id = temp.message_id");
	}
}
