<?php

namespace Solaris\Marketing\Services\Email;

use Illuminate\Support\Facades\DB;
use Solaris\Marketing\Const\EmailBlastAudienceStatusConst;

class UpdateCampaignStatus
{
    public static function updateStatus(array $emailBlastIds): void
    {
        $driver = DB::connection()->getDriverName();
        
        switch ($driver) {
            case 'mysql':
            case 'mariadb':
                static::updateStatusMySQL($emailBlastIds);
                break;
                
            case 'pgsql':
                static::updateStatusPostgreSQL($emailBlastIds);
                break;
                
            case 'sqlsrv':
                static::updateStatusSQLServer($emailBlastIds);
                break;
                
            default:
                throw new \Exception("Unsupported database driver: {$driver}");
        }
    }

    public static function updateAudienceProgress(string $emailBlastId): void
    {
        $driver = DB::connection()->getDriverName();
        
        switch ($driver) {
            case 'mysql':
            case 'mariadb':
                static::updateAudienceProgressMySQL($emailBlastId);
                break;
                
            case 'pgsql':
                static::updateAudienceProgressPostgreSQL($emailBlastId);
                break;
                
            case 'sqlsrv':
                static::updateAudienceProgressSQLServer($emailBlastId);
                break;
                
            default:
                throw new \Exception("Unsupported database driver: {$driver}");
        }
    }

    private static function updateStatusMySQL(array $emailBlastIds): void
    {
        $placeholders = implode(',', array_fill(0, count($emailBlastIds), '?'));
        $query = "UPDATE email_blasts eb
            INNER JOIN (
                SELECT 
                    email_blast_id,
                    SUM(CASE WHEN status_id = ? THEN 1 ELSE 0 END) as total_success,
                    SUM(CASE WHEN status_id IN (?, ?, ?) THEN 1 ELSE 0 END) as total_fail,
                    SUM(open) as total_open,
                    SUM(click) as total_click,
                    SUM(CASE WHEN unsubscribe = ? THEN 1 ELSE 0 END) as total_unsubscribe,
                    SUM(CASE WHEN spam = ? THEN 1 ELSE 0 END) as total_spam,
                    SUM(CASE WHEN status_id = ? THEN 1 ELSE 0 END) as total_pending,
                    SUM(CASE WHEN status_id = ? THEN 1 ELSE 0 END) as total_progress,
                    SUM(CASE WHEN open > 0 THEN 1 ELSE 0 END) as total_unique_open,
                    SUM(CASE WHEN click > 0 THEN 1 ELSE 0 END) as total_unique_click
                FROM email_blast_audiences
                WHERE email_blast_id IN ({$placeholders})
                GROUP BY email_blast_id
            ) temp ON eb.id = temp.email_blast_id
            SET 
                eb.total_success = temp.total_success,
                eb.total_fail = temp.total_fail,
                eb.total_open = temp.total_open,
                eb.total_click = temp.total_click,
                eb.total_unsubscribe = temp.total_unsubscribe,
                eb.total_spam = temp.total_spam,
                eb.total_pending = temp.total_pending,
                eb.total_progress = temp.total_progress,
                eb.total_unique_open = temp.total_unique_open,
                eb.total_unique_click = temp.total_unique_click";

        DB::statement($query, array_merge([
            EmailBlastAudienceStatusConst::Delivered,
            EmailBlastAudienceStatusConst::SoftBounce,
            EmailBlastAudienceStatusConst::HardBounce,
            EmailBlastAudienceStatusConst::Failed,
            true,
            true,
            EmailBlastAudienceStatusConst::Pending,
            EmailBlastAudienceStatusConst::Progress
        ], $emailBlastIds));
    }

    private static function updateStatusPostgreSQL(array $emailBlastIds): void
    {
        $placeholders = implode(',', array_fill(0, count($emailBlastIds), '?'));
        $query = "UPDATE email_blasts
            SET 
                total_success = temp.total_success,
                total_fail = temp.total_fail,
                total_open = temp.total_open,
                total_click = temp.total_click,
                total_unsubscribe = temp.total_unsubscribe,
                total_spam = temp.total_spam,
                total_pending = temp.total_pending,
                total_progress = temp.total_progress,
                total_unique_open = temp.total_unique_open,
                total_unique_click = temp.total_unique_click
            FROM (
                SELECT 
                    email_blast_id,
                    SUM(CASE WHEN status_id = ? THEN 1 ELSE 0 END) as total_success,
                    SUM(CASE WHEN status_id IN (?, ?, ?) THEN 1 ELSE 0 END) as total_fail,
                    SUM(open) as total_open,
                    SUM(click) as total_click,
                    SUM(CASE WHEN unsubscribe = ? THEN 1 ELSE 0 END) as total_unsubscribe,
                    SUM(CASE WHEN spam = ? THEN 1 ELSE 0 END) as total_spam,
                    SUM(CASE WHEN status_id = ? THEN 1 ELSE 0 END) as total_pending,
                    SUM(CASE WHEN status_id = ? THEN 1 ELSE 0 END) as total_progress,
                    SUM(CASE WHEN open > 0 THEN 1 ELSE 0 END) as total_unique_open,
                    SUM(CASE WHEN click > 0 THEN 1 ELSE 0 END) as total_unique_click
                FROM email_blast_audiences
                WHERE email_blast_id IN ({$placeholders})
                GROUP BY email_blast_id
            ) temp
            WHERE email_blasts.id = temp.email_blast_id";

        DB::statement($query, array_merge([
            EmailBlastAudienceStatusConst::Delivered,
            EmailBlastAudienceStatusConst::SoftBounce,
            EmailBlastAudienceStatusConst::HardBounce,
            EmailBlastAudienceStatusConst::Failed,
            true,
            true,
            EmailBlastAudienceStatusConst::Pending,
            EmailBlastAudienceStatusConst::Progress
        ], $emailBlastIds));
    }

    private static function updateStatusSQLServer(array $emailBlastIds): void
    {
        $placeholders = implode(',', array_fill(0, count($emailBlastIds), '?'));
        $query = "UPDATE eb
            SET 
                eb.total_success = temp.total_success,
                eb.total_fail = temp.total_fail,
                eb.total_open = temp.total_open,
                eb.total_click = temp.total_click,
                eb.total_unsubscribe = temp.total_unsubscribe,
                eb.total_spam = temp.total_spam,
                eb.total_pending = temp.total_pending,
                eb.total_progress = temp.total_progress,
                eb.total_unique_open = temp.total_unique_open,
                eb.total_unique_click = temp.total_unique_click
            FROM email_blasts eb
            INNER JOIN (
                SELECT 
                    email_blast_id,
                    SUM(CASE WHEN status_id = ? THEN 1 ELSE 0 END) as total_success,
                    SUM(CASE WHEN status_id IN (?, ?, ?) THEN 1 ELSE 0 END) as total_fail,
                    SUM(open) as total_open,
                    SUM(click) as total_click,
                    SUM(CASE WHEN unsubscribe = ? THEN 1 ELSE 0 END) as total_unsubscribe,
                    SUM(CASE WHEN spam = ? THEN 1 ELSE 0 END) as total_spam,
                    SUM(CASE WHEN status_id = ? THEN 1 ELSE 0 END) as total_pending,
                    SUM(CASE WHEN status_id = ? THEN 1 ELSE 0 END) as total_progress,
                    SUM(CASE WHEN open > 0 THEN 1 ELSE 0 END) as total_unique_open,
                    SUM(CASE WHEN click > 0 THEN 1 ELSE 0 END) as total_unique_click
                FROM email_blast_audiences
                WHERE email_blast_id IN ({$placeholders})
                GROUP BY email_blast_id
            ) temp ON eb.id = temp.email_blast_id";

        DB::statement($query, array_merge([
            EmailBlastAudienceStatusConst::Delivered,
            EmailBlastAudienceStatusConst::SoftBounce,
            EmailBlastAudienceStatusConst::HardBounce,
            EmailBlastAudienceStatusConst::Failed,
            true,
            true,
            EmailBlastAudienceStatusConst::Pending,
            EmailBlastAudienceStatusConst::Progress
        ], $emailBlastIds));
    }

    private static function updateAudienceProgressMySQL($emailBlastId): void
    {
        DB::statement("
            UPDATE email_blast_audiences audience
            INNER JOIN email_blast_audience_temp temp 
                ON audience.id = temp.id 
            SET 
                status_id = temp.status_id,
                message_id = temp.message_id,
                message = temp.message
            WHERE temp.email_blast_id = ?
        ", [$emailBlastId]);
    }

    private static function updateAudienceProgressPostgreSQL($emailBlastId): void
    {
        DB::statement("
            UPDATE email_blast_audiences audience
            SET 
                status_id = temp.status_id,
                message_id = temp.message_id,
                message = temp.message
            FROM email_blast_audience_temp temp
            WHERE audience.id = temp.id 
            AND temp.email_blast_id = ?
        ", [$emailBlastId]);
    }

    private static function updateAudienceProgressSQLServer($emailBlastId): void
    {
        DB::statement("
            UPDATE email_blast_audiences
            SET 
                status_id = temp.status_id,
                message_id = temp.message_id,
                message = temp.message
            FROM email_blast_audiences audience
            INNER JOIN email_blast_audience_temp temp 
                ON audience.id = temp.id
            WHERE temp.email_blast_id = ?
        ", [$emailBlastId]);
    }
}