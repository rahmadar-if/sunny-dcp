<?php

namespace Solaris\Marketing\Services\Email\Mailgun;

use GuzzleHttp\Promise\PromiseInterface;
use Illuminate\Http\Client\Factory;
use Illuminate\Http\Client\PendingRequest;
use Illuminate\Http\Client\Response;
use Illuminate\Mail\Mailables\Address;
use Solaris\Core\Helpers\Helper;
use Solaris\Marketing\Const\EmailBlastAudienceStatusConst;
use Solaris\Marketing\Services\Email\BlastAudienceResponse;
use Solaris\Marketing\Services\Email\EmailProvider;
use Solaris\Marketing\Services\Email\Interfaces\HasWebhookSupport;
use Solaris\Marketing\Services\Email\Mailgun\Webhook\EventTypeConst;
use Solaris\Marketing\Services\Email\Mailgun\Webhook\Payload;

class MailgunProvider extends EmailProvider implements HasWebhookSupport
{
	public static string $eventOpen  = EventTypeConst::OPENED;
	public static string $eventClick = EventTypeConst::CLICKED;

	private ?Payload $parsedPayload = null;

	protected function getConfig(): array
	{
		return Helper::config("email_blast.providers.mailgun");
	}

	public function buildBlastRequest(PendingRequest|Factory $request, string $subject, Address $sender, Address $recipient, string $message): PromiseInterface|Response
	{
		$endpoint = $this->config["endpoint"] . "/" . $this->config["domain"] . "/messages";
		return $request->withBasicAuth('api', $this->config["secret"])
			->withHeaders(["X-Solaris-Log-Channel" => "mailgun"])
			->acceptJson()
			->asMultipart()
			->post($endpoint, [
				"subject" => $subject,
				"from"    => $sender->name . " <" . $sender->address . ">",
				"to"      => $recipient->name . " <" . $recipient->address . ">",
				"html"    => $message
			]);
	}

	public function isSuccessSendResponse(Response $response): bool
	{
		return $response->successful();
	}

	public function getSendResponseMessage(Response $response): ?string
	{
		return $response->json("message") ?? $response->body();
	}

	public function mappingBlastResponse(string $audienceId, string $emailBlastId, Response $response): BlastAudienceResponse
	{
		$success   = $this->isSuccessSendResponse($response);
		$messageId = null;

		if ($success) {
			$messageId = $response->json('id');
			if (str_starts_with($messageId, '<') && str_ends_with($messageId, '>')) {
				$messageId = substr($messageId, 1, -1);
			}
		}

		return new BlastAudienceResponse(
			audienceId	: $audienceId,
			emailBlastId: $emailBlastId,
			statusId	: $success ? EmailBlastAudienceStatusConst::Progress : EmailBlastAudienceStatusConst::Failed,
			messageId	: $messageId,
			message		: $this->getSendResponseMessage($response),
		);
	}

	public function isValidWebhook(string $key): bool
	{
		return $this->getPayload()->signature->isValid($key);
	}

	public function getWebhookMessageId(): string
	{
		return $this->getPayload()->eventData->getMessageId();
	}

	public function getWebhookEventType(): string
	{
		return $this->getPayload()->eventData->getEventType();
	}

	public function getWebhookMessage(): ?string
	{
		return $this->getPayload()->eventData->getErrorMessage();
	}

	private function getPayload(): Payload
	{
		if ($this->parsedPayload === null) {
			$this->parsedPayload = Payload::from(json_decode($this->webhookPayload, true));
		}

		return $this->parsedPayload;
	}
}
