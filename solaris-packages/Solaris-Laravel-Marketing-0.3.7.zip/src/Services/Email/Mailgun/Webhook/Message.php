<?php

namespace Solaris\Marketing\Services\Email\Mailgun\Webhook;

final readonly class Message
{
    public function __construct(
        public MessageHeaders $headers,
        public ?array $attachments = null,
        public ?int $size = null,
    ) {}

    public static function from(array $data): self
    {
        return new self(
            headers    : MessageHeaders::from($data['headers']),
            attachments: $data['attachments'] ?? [],
            size       : $data['size'] ?? null,
        );
    }
}
