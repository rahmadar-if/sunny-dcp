<?php

namespace Solaris\Marketing\Services\Email\Mailgun\Webhook;

final readonly class EventData
{
    public function __construct(
        public string $id,
        public float $timestamp,
        public string $logLevel,
        public string $event,
        public string $recipient,
        public string $recipientDomain,
        public Message $message,
        public ?DeliveryStatus $deliveryStatus,
        public ?ClientInfo $clientInfo,
        public ?Geolocation $geolocation,
        public ?Envelope $envelope,
        public ?Flags $flags,
        public ?Storage $storage,
        public array $tags,
        public array $userVariables,
        public array $campaigns,
        public ?string $reason = null,
        public ?string $severity = null,
        public ?string $ip = null,
        public ?string $method = null,
        public ?string $apiKeyId = null,
    ) {}

    public function getMessageId(): string
    {
        return $this->message->headers?->messageId ?? '';
    }

    public function getEventType(): string
    {
        $isSoftBounce = $this->event === EventTypeConst::FAILED && $this->logLevel === 'warn';
        $isHardBounce = $this->event === EventTypeConst::FAILED && $this->logLevel === 'error';

        if ($isSoftBounce) {
            return 'soft_bounce';
        }

        if ($isHardBounce && $this->reason === 'suppress-unsubscribe') {
            return EventTypeConst::UNSUBSCRIBED;
        }

        if ($isHardBounce) {
            return 'hard_bounce';
        }

        return $this->event;
    }

    public function getErrorMessage(): ?string
    {
        if ($this->event !== EventTypeConst::FAILED) {
            return null;
        }

        $message     = $this->deliveryStatus?->message ?? '';
        $description = $this->deliveryStatus?->description ?? '';

        return trim(implode('. ', array_filter([$message, $description]))) ?: null;
    }

    public static function from(array $data): self
    {
        return new self(
            id             : $data['id'],
            timestamp      : $data['timestamp'],
            logLevel       : $data['log-level'],
            event          : $data['event'],
            recipient      : $data['recipient'],
            recipientDomain: $data['recipient-domain'],
            message        : Message::from($data['message']),
            deliveryStatus : isset($data['delivery-status'])
                ? DeliveryStatus::from($data['delivery-status'])
                : null,
            clientInfo: isset($data['client-info'])
                ? ClientInfo::from($data['client-info'])
                : null,
            geolocation: isset($data['geolocation'])
                ? Geolocation::from($data['geolocation'])
                : null,
            envelope: isset($data['envelope'])
                ? Envelope::from($data['envelope'])
                : null,
            flags: isset($data['flags'])
                ? Flags::from($data['flags'])
                : null,
            storage: isset($data['storage'])
                ? Storage::from($data['storage'])
                : null,
            tags         : $data['tags'] ?? [],
            userVariables: $data['user-variables'] ?? [],
            campaigns    : $data['campaigns'] ?? [],
            reason       : $data['reason'] ?? null,
            severity     : $data['severity'] ?? null,
            ip           : $data['ip'] ?? null,
            method       : $data['method'] ?? null,
            apiKeyId     : $data['api-key-id'] ?? null,
        );
    }
}
