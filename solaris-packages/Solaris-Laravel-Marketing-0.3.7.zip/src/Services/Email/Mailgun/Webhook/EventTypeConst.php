<?php

namespace Solaris\Marketing\Services\Email\Mailgun\Webhook;

class EventTypeConst
{
	const ACCEPTED     = 'accepted';
	const DELIVERED    = 'delivered';
	const FAILED       = 'failed';
	const OPENED       = 'opened';
	const CLICKED      = 'clicked';
	const UNSUBSCRIBED = 'unsubscribed';
	const COMPLAINED   = 'complained';
}
