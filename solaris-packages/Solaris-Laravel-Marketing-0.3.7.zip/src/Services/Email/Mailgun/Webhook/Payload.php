<?php

namespace Solaris\Marketing\Services\Email\Mailgun\Webhook;

final readonly class Payload
{
    public function __construct(
        public Signature $signature,
        public EventData $eventData,
    ) {}

    public static function from(array $data): self
    {
        return new self(
            signature: Signature::from($data['signature']),
            eventData: EventData::from($data['event-data']),
        );
    }
}
