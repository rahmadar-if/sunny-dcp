<?php

namespace Solaris\Marketing\Services\Email\Mailgun\Webhook;

final readonly class MessageHeaders
{
    public function __construct(
        public string $messageId,
        public ?string $from = null,
        public ?string $to = null,
        public ?string $subject = null,
    ) {}

    public static function from(array $data): self
    {
        return new self(
            messageId: $data['message-id'],
            from     : $data['from'] ?? null,
            to       : $data['to'] ?? null,
            subject  : $data['subject'] ?? null,
        );
    }
}
