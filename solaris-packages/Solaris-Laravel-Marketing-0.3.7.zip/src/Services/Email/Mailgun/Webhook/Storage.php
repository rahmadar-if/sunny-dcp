<?php

namespace Solaris\Marketing\Services\Email\Mailgun\Webhook;

final readonly class Storage
{
    public function __construct(
        public ?string $key = null,
        public ?string $url = null,
    ) {}

    public static function from(array $data): self
    {
        return new self(
            key: $data['key'] ?? null,
            url: $data['url'] ?? null,
        );
    }
}
