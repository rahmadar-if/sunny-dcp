<?php

namespace Solaris\Marketing\Services\Email\Mailgun\Webhook;

final readonly class ClientInfo
{
    public function __construct(
        public string $clientOs,
        public string $deviceType,
        public string $clientName,
        public string $clientType,
        public string $userAgent,
    ) {}

    public static function from(array $data): self
    {
        return new self(
            clientOs  : $data['client-os'],
            deviceType: $data['device-type'],
            clientName: $data['client-name'],
            clientType: $data['client-type'],
            userAgent : $data['user-agent'],
        );
    }
}
