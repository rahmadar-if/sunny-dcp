<?php

namespace Solaris\Marketing\Services\Email\Mailgun\Webhook;

final readonly class Signature
{
    public function __construct(
        public string $token,
        public int $timestamp,
        public string $signature,
    ) {}

    public static function from(array $data): self
    {
        return new self(
            token    : $data['token'],
            timestamp: (int) $data['timestamp'],
            signature: $data['signature'],
        );
    }

    public function isValid(string $signingKey): bool
    {
        $payload = $this->timestamp . $this->token;
        return hash_hmac('sha256', $payload, $signingKey) === $this->signature;
    }
}
