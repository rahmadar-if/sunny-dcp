<?php

namespace Solaris\Marketing\Services\Email\Mailgun\Webhook;

final readonly class Geolocation
{
    public function __construct(
        public string $country,
        public string $region,
        public string $city,
    ) {}

    public static function from(array $data): self
    {
        return new self(
            country: $data['country'],
            region : $data['region'],
            city   : $data['city'],
        );
    }
}
