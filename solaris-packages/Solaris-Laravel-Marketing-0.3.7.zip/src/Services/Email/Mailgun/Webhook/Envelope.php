<?php

namespace Solaris\Marketing\Services\Email\Mailgun\Webhook;

final readonly class Envelope
{
    public function __construct(
        public string $sender,
        public string $transport,
        public string $targets,
        public ?string $sendingIp = null,
    ) {}

    public static function from(array $data): self
    {
        return new self(
            sender   : $data['sender'],
            transport: $data['transport'],
            targets  : $data['targets'],
            sendingIp: $data['sending-ip'] ?? null,
        );
    }
}
