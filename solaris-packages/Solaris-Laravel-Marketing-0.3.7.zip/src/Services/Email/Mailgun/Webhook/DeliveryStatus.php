<?php

namespace Solaris\Marketing\Services\Email\Mailgun\Webhook;

final readonly class DeliveryStatus
{
    public function __construct(
        public int $attemptNo,
        public int $code,
        public ?string $message = null,
        public ?string $description = null,
        public ?bool $tls = null,
        public ?bool $certificateVerified = null,
        public ?string $mxHost = null,
        public float $sessionSeconds,
        public ?string $enhancedCode = null,
        public ?int $retrySeconds = null,
        public ?bool $utf8 = null,
    ) {}

    public static function from(array $data): self
    {
        return new self(
            attemptNo          : $data['attempt-no'],
            code               : $data['code'],
            message            : $data['message'] ?? null,
            description        : $data['description'] ?? null,
            tls                : $data['tls'] ?? null,
            certificateVerified: $data['certificate-verified'] ?? null,
            mxHost             : $data['mx-host'] ?? null,
            sessionSeconds     : $data['session-seconds'],
            enhancedCode       : $data['enhanced-code'] ?? null,
            retrySeconds       : $data['retry-seconds'] ?? null,
            utf8               : $data['utf8'] ?? null,
        );
    }
}
