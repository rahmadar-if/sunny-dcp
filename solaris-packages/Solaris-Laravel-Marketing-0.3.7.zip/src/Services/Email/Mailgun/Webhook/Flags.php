<?php

namespace Solaris\Marketing\Services\Email\Mailgun\Webhook;

final readonly class Flags
{
    public function __construct(
        public bool $isAuthenticated,
        public bool $isTestMode,
        public ?bool $isRouted = null,
        public ?bool $isSystemTest = null,
    ) {}

    public static function from(array $data): self
    {
        return new self(
            isAuthenticated: $data['is-authenticated'],
            isTestMode     : $data['is-test-mode'],
            isRouted       : $data['is-routed'] ?? null,
            isSystemTest   : $data['is-system-test'] ?? null,
        );
    }
}
