<?php

namespace Solaris\Marketing\Services;

use Illuminate\Support\Facades\Session;
use Solaris\Core\Helpers\Helper;

// Stores the moment sending becomes allowed again rather than a countdown, so a reloaded or
// long-idle tab still honours the same lock. Each scope is locked on its own, never shared.
class TestEmailThrottle
{
	public const ScopeBlast    = 'email_blast';
	public const ScopeTemplate = 'email_template';
	public const ScopeEditor   = 'email_editor';

	public static function scopes(): array
	{
		return [self::ScopeBlast, self::ScopeTemplate, self::ScopeEditor];
	}

	public static function retryAt(string $scope): ?int
	{
		$retryAt = Session::get(self::key($scope));

		if (!is_int($retryAt) || $retryAt <= now()->timestamp) {
			return null;
		}

		return $retryAt;
	}

	public static function secondsLeft(string $scope): int
	{
		$retryAt = self::retryAt($scope);

		return $retryAt === null ? 0 : $retryAt - now()->timestamp;
	}

	public static function mark(string $scope): void
	{
		$cooldown = (int) Helper::config('email_blast.test_cooldown_seconds', 30);

		Session::put(self::key($scope), now()->timestamp + $cooldown);
	}

	public static function message(int $seconds): string
	{
		return "Please wait {$seconds} second" . ($seconds === 1 ? '' : 's') . " before sending another test email.";
	}

	private static function key(string $scope): string
	{
		return "marketing.test_email_retry_at.{$scope}";
	}
}
