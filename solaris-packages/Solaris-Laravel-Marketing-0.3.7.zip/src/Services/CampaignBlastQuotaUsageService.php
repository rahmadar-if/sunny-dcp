<?php

namespace Solaris\Marketing\Services;

use Illuminate\Support\Facades\DB;
use Solaris\Core\Helpers\Helper;
use Solaris\Marketing\Const\CampaignBlastQuotaActionConst;
use Solaris\Marketing\Const\CampaignBlastTypeConst;
use Solaris\Marketing\Models\CampaignBlastQuota;
use Solaris\Marketing\Models\CampaignBlastQuotaLog;

class CampaignBlastQuotaUsageService
{
	public static function groups(string $quotaId, ?string $search, int $start, int $length): array
	{
		$quota     = CampaignBlastQuota::select(["id", "type_id"])->findOrFail($quotaId);
		$sourceIds = $search ? static::searchSourceIds($quota->type_id, $search) : null;

		if (!is_null($sourceIds) && empty($sourceIds)) {
			return ["items" => [], "total" => 0];
		}

		$rows = static::groupQuery($quotaId, $sourceIds)
			->orderByRaw("MAX(created_at) DESC")
			->offset($start)
			->limit($length)
			->get();

		return [
			"items" => static::attachTitles($rows),
			"total" => static::groupCount($quotaId, $sourceIds),
		];
	}

	private static function groupQuery(string $quotaId, ?array $sourceIds)
	{
		$query = CampaignBlastQuotaLog::where("quota_id", $quotaId)
			->selectRaw("source_type, source_id")
			->selectRaw("COALESCE(SUM(CASE WHEN book_delta > 0 THEN book_delta ELSE 0 END), 0) AS booked")
			->selectRaw("COALESCE(SUM(CASE WHEN action = ? THEN -book_delta ELSE 0 END), 0) AS consumed", [CampaignBlastQuotaActionConst::Consume])
			->selectRaw("COALESCE(SUM(CASE WHEN action = ? THEN -book_delta ELSE 0 END), 0) AS released", [CampaignBlastQuotaActionConst::Release])
			->selectRaw("COALESCE(SUM(used_delta), 0) AS sent")
			->selectRaw("MIN(created_at) AS first_at")
			->selectRaw("MAX(created_at) AS last_at")
			->selectRaw("COUNT(*) AS entries")
			->groupBy("source_type", "source_id");

		if (!is_null($sourceIds)) {
			$query->whereIn("source_id", $sourceIds);
		}

		return $query;
	}

	private static function groupCount(string $quotaId, ?array $sourceIds): int
	{
		$inner = DB::table("campaign_blast_quota_logs")
			->where("quota_id", $quotaId)
			->groupBy("source_type", "source_id")
			->selectRaw("1");

		if (!is_null($sourceIds)) {
			$inner->whereIn("source_id", $sourceIds);
		}

		return DB::table(DB::raw("({$inner->toSql()}) as grouped"))
			->mergeBindings($inner)
			->count();
	}

	private static function attachTitles($rows): array
	{
		$titles = [];

		foreach ($rows->whereNotNull("source_type")->groupBy("source_type") as $sourceType => $group) {
			if (!class_exists($sourceType)) {
				continue;
			}

			$titles[$sourceType] = $sourceType::whereIn("id", $group->pluck("source_id")->all())
				->pluck("title", "id")
				->all();
		}

		return $rows->map(function($row) use ($titles) {
			$booked   = (int) $row->booked;
			$consumed = (int) $row->consumed;
			$released = (int) $row->released;

			return [
				"source_type" => $row->source_type,
				"source_id"   => $row->source_id,
				"title"       => $titles[$row->source_type][$row->source_id] ?? null,
				"booked"      => $booked,
				"consumed"    => $consumed,
				"released"    => $released,
				"sent"        => (int) $row->sent,
				"outstanding" => $booked - $consumed - $released,
				"entries"     => (int) $row->entries,
				"first_at"    => $row->first_at,
				"last_at"     => $row->last_at,
			];
		})->all();
	}

	private static function searchSourceIds(?string $typeId, string $search): array
	{
		$model = static::campaignModel($typeId);

		if (!$model) {
			return [];
		}

		return $model::where("title", Helper::likeOperator(), "%{$search}%")->pluck("id")->all();
	}

	private static function campaignModel(?string $typeId): ?string
	{
		return match ($typeId) {
			CampaignBlastTypeConst::Email    => Helper::model("email_blast"),
			CampaignBlastTypeConst::WhatsApp => Helper::model("wa_blast"),
			default                          => null,
		};
	}
}
