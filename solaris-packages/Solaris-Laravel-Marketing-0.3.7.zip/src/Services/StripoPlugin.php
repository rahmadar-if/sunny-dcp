<?php

namespace Solaris\Marketing\Services;

use Illuminate\Http\Client\Pool;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Helpers\Helper;
use Solaris\Marketing\Jobs\SendTestEmailJob;
use Solaris\Marketing\Services\Email\EmailMergeTagService;

class StripoPlugin
{
    public static function getEmailId(): string
    {
        return Helper::config("stripo_plugin.email_id");
    }

    public static function getToken(): string
    {
        $pluginId  = Helper::config("stripo_plugin.plugin_id");
        $secretKey = Helper::config("stripo_plugin.secret_key");

        if(empty($pluginId) || empty($secretKey)) {
            throw new \Exception("Plugin ID or Secret Key is null or empty");
        }

        $response = Http::acceptJson()->post("https://plugins.stripo.email/api/v1/auth", [
            "pluginId"  => $pluginId,
            "secretKey" => $secretKey,
            "userId"    => "1",
            "role"      => "api",
        ]);

        if($response->forbidden()) {
            throw new \Exception($response->json()['message']);
        } else if(!$response->ok()) {
            throw new \Exception("Something wrong happen, please check Plugin ID or Secret Key");
        }

        return $response->json()['token'];
    }

    public static function getDefaultTemplate(): array
    {
        $responses = Http::pool(fn (Pool $pool) => [
            $pool->as("html")->get('https://raw.githubusercontent.com/ardas/stripo-plugin/master/Public-Templates/Basic-Templates/Trigger%20newsletter%20mockup/Trigger%20newsletter%20mockup.html'),
            $pool->as("css")->get('https://raw.githubusercontent.com/ardas/stripo-plugin/master/Public-Templates/Basic-Templates/Trigger%20newsletter%20mockup/Trigger%20newsletter%20mockup.css'),
        ]);

        return [
            "html" => $responses['html']->body(),
            "css"  => $responses['css']->body(),
        ];
    }

    // Without a contact the template goes out untouched, so merge tags stay visible as-is.
    public static function sendTestEmail(string $email, string $subject, string $html, ?Model $contact = null): void
    {
        if ($contact) {
            $html = EmailMergeTagService::compile($contact, $html);
        }

        SendTestEmailJob::dispatch($email, $subject, $html);
    }

    public static function listFiles(string $keys): array
    {
        $disk = Helper::config("stripo_plugin.image_storage.disk");
        $path = Helper::config("stripo_plugin.image_storage.path");
        $result = [];

        foreach (explode(",", $keys) as $key) {
            $key = trim($key);
            $folderPath = "$path/$key";
            $files = Storage::disk($disk)->files($folderPath);
            $documents = [];

            foreach ($files as $filePath) {
                $documents[] = self::buildDocumentMeta($disk, $filePath);
            }

            $result[] = [
                "key"       => $key,
                "documents" => $documents,
            ];
        }

        return $result;
    }

    public static function uploadFile(string $key, UploadedFile $file): array
    {
        $disk = Helper::config("stripo_plugin.image_storage.disk");
        $path = Helper::config("stripo_plugin.image_storage.path");
        $folderPath = "$path/$key";

        Storage::disk($disk)->putFileAs($folderPath, $file, $file->getClientOriginalName());

        return self::buildDocumentMeta($disk, "$folderPath/{$file->getClientOriginalName()}");
    }

    public static function deleteFile(string $url): array
    {
        $disk = Helper::config("stripo_plugin.image_storage.disk");
        $storagePath = self::resolvePathFromUrl($disk, $url);

        Storage::disk($disk)->delete($storagePath);

        return ["message" => "File deleted"];
    }

    public static function getFileInfo(string $url): array
    {
        $disk = Helper::config("stripo_plugin.image_storage.disk");
        $storagePath = self::resolvePathFromUrl($disk, $url);

        return [
            "originalName" => basename($storagePath),
            "size"         => Storage::disk($disk)->size($storagePath),
        ];
    }

    private static function buildDocumentMeta(string $disk, string $filePath): array
    {
        $absolutePath = Storage::disk($disk)->path($filePath);
        $url = Storage::disk($disk)->url($filePath);
        $size = Storage::disk($disk)->size($filePath);
        $uploadTime = (int) (Storage::disk($disk)->lastModified($filePath) * 1000);
        $width = 0;
        $height = 0;

        if (@is_array($imageSize = getimagesize($absolutePath))) {
            $width = $imageSize[0];
            $height = $imageSize[1];
        }

        return [
            "url"          => $url,
            "originalName" => basename($filePath),
            "uploadTime"   => $uploadTime,
            "size"         => $size,
            "height"       => $height,
            "width"        => $width,
            "thumbnailUrl" => $url,
        ];
    }

    private static function resolvePathFromUrl(string $disk, string $url): string
    {
        $baseUrl = Storage::disk($disk)->url('');
        return ltrim(str_replace($baseUrl, '', $url), '/');
    }
}