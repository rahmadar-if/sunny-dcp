<?php

namespace Solaris\Marketing\Commands;

use Illuminate\Console\Command;

class SolarisMarketingCommand extends Command
{
    public $signature = 'skeleton';

    public $description = 'My command';

    public function handle(): int
    {
        $this->comment('All done');

        return self::SUCCESS;
    }
}
