<?php

namespace Solaris\Marketing\Const;

class CampaignBlastQuotaActionConst
{
	public const Book    = "book";
	public const Consume = "consume";
	public const Release = "release";
}
