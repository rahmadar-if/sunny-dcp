<?php

namespace Solaris\Marketing\Const;

class CampaignBlastStatusConst
{
    public const Draft     = "17cd3914-0116-4aae-9e49-2d0d6aee84b1";
    public const Scheduled = "fe6e96a5-fc08-4ae1-b63b-305c9a042e2a";
    public const Queued    = "019bbc6c-3183-79be-b7fd-c34235cbdc3f";
    public const Sending   = "246eb45c-8fd0-4492-b1b0-c1f1d1277174";
    public const Completed = "3d25c459-ee8b-4317-b47a-ab9745303634";
    public const Canceled  = "c0cf4e3b-949c-4582-8c0c-25f4b3671650";
    public const Failed    = "11a8c68a-1217-4698-96ce-48ed5418ee53";
}