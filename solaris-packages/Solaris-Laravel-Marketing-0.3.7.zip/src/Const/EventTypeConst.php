<?php

namespace Solaris\Marketing\Const;

class EventTypeConst
{
    public const Seminar    = "698a5f68-551a-4ce3-9947-9b501ca2444c";
    public const Exhibition = "9269653c-f0a9-4009-9cc3-88805795c3f0";
    public const Promotion  = "a6b4e1fd-6d6a-4fb4-8659-9723e02e2d0d";
    public const Tutorial   = "e726a651-e869-46c4-bee1-b869e51233ad";
    public const Webinar    = "9af948f7-31fd-4a1b-a816-47865cc0d636";
}