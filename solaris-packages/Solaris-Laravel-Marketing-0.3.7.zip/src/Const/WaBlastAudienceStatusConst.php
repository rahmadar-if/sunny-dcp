<?php

namespace Solaris\Marketing\Const;

class WaBlastAudienceStatusConst
{
	public const Pending   = "019d65ff-c0da-7031-86b4-cecb26544691";
	public const Progress  = "019d65ff-c0da-7af3-b9bb-9d4b5adb3084";
	public const Sent 	   = "019d65ff-c0da-77bb-9e39-995fec256ff7";
	public const Delivered = "019d65ff-c0da-7e0a-b8c1-2a3456789abc";
	public const Read      = "019d65ff-c0da-7f27-a7ce-b24b4f4996a7";
	public const Failed    = "019d65ff-c0da-79e8-95b9-9089c1f1b216";
}