<?php

namespace Solaris\Marketing\Const;

class WaTemplateCategoryConst
{
	public const Marketing      = "019d65fd-cbba-79b3-9bc8-71e7e1436fdf";
	public const Utility        = "019d65fd-cbba-7acb-9afa-bde5a2614d86";
	public const Authentication = "019d65fd-cbba-731f-bbfa-1e05a27965ba";
}