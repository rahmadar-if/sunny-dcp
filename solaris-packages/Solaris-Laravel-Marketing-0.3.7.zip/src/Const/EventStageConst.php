<?php

namespace Solaris\Marketing\Const;

class EventStageConst
{
    public const Draft        = "b4cffdee-8124-4e98-a095-cb77d97d4038";
    public const Confirmation = "85c6930c-be78-48c0-87c4-5409bf3f0629";
    public const Closed       = "12dcf16e-e2eb-4c8e-a293-3914a12f9952";
    public const Cancel       = "24f34191-c9f9-4d3d-a967-56833dc2e683";
}