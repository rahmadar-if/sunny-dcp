<?php

namespace Solaris\Marketing\Const;

class EventStatusConst
{
    public const InProgress = "954960c6-d6ae-453c-8d72-41a2f79e3df3";
    public const Planned    = "e8868cb0-3450-44e7-92ab-fed5dab90051";
    public const Completed  = "f31b54e5-b32b-4b6d-84e9-02beef44f3e6";
    public const Canceled   = "48c42636-dfb9-4f55-8345-f4fa902b1d21";
}