<?php

namespace Solaris\Marketing\Const;

class WaTemplateSubTypeConst
{
	public const Regular  = "019d65fd-cbba-76d3-a3ac-5304fc4ee3bc";
	public const Carousel = "019d65fd-cbba-707d-aefa-e42c3412e9c3";
}