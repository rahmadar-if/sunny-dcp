<?php

namespace Solaris\Marketing\Const;

class WaTemplateHeaderTypeConst
{
	public const Text     = "019d65fd-cbba-7e73-a442-060631603e6b";
	public const Image    = "019d65fd-cbba-7098-a80f-3b6f28092ec2";
	public const Video    = "019d65fd-cbba-7924-92ca-8c1a79026711";
	public const Document = "019d65fd-cbba-7305-b961-d6ec3bff88cb";
}