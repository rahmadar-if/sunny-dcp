<?php

namespace Solaris\Marketing\Const;

class CampaignBlastTypeConst
{
    public const Email    = "019bb575-ce3b-7fe4-a6da-06d34f857327";
    public const WhatsApp = "019bb575-ce3b-73d2-a9eb-13c35f9b3fd3";
}