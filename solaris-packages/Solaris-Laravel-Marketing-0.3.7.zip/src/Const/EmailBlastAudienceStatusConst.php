<?php

namespace Solaris\Marketing\Const;

class EmailBlastAudienceStatusConst
{
    public const Pending    = "019bd922-451e-76bd-a7c8-9fa412877886";
    public const Progress   = "019bd920-0288-7989-ac1c-295318f6d137";
    public const Delivered  = "019bd920-0288-7c95-b6e0-3c80ede61536";
    public const SoftBounce = "019bd920-0288-7974-b629-1bb667de3774";
    public const HardBounce = "019bd920-0288-7edb-9114-ca3a2fc17ea1";
    public const Failed     = "019bd98a-3e0b-7da2-9ab4-813de42b9ef7";
}