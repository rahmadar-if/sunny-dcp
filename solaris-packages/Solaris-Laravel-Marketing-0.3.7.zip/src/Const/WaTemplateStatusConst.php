<?php

namespace Solaris\Marketing\Const;

class WaTemplateStatusConst
{
	public const Draft    = "019d65fd-cbba-797a-9420-03b27dd53fe0";
	public const Pending  = "019d65fd-cbba-753d-9e18-3611dd5c4720";
	public const Approved = "019d65fd-cbba-7d58-b087-1fb1b3c8eb40";
	public const Rejected = "019d65fd-cbba-7a2c-85b3-f74686d11cf2";
	public const Paused   = "019d65fd-cbba-7ddf-b759-3bb189124cad";
	public const Disabled = "019d65fd-cbba-7f7e-a050-f2120071a94a";
}