<?php

namespace Solaris\Marketing\Const;

class CampaignBlastQuotaContextConst
{
	public const Send      = "send";
	public const Schedule  = "schedule";
	public const Blast     = "blast";
	public const Test      = "test";
	public const Cancel    = "cancel";
	public const Completed = "completed";
	public const JobFailed = "job_failed";
	public const Leftover  = "leftover";
}
