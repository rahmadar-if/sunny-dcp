<?php

namespace Solaris\Marketing\Http\Requests;

use Solaris\Core\Http\Requests\BaseFormRequest;

class CampaignBlastQuotaRequest extends BaseFormRequest
{
	public function rules(): array
	{
		return match ($this->method()) {
			'POST' => $this->createRules(),
		};
	}

	protected function createRules(): array
	{
		return [
			'type_id'         => 'required|uuid',
			'provider'        => 'required|string',
			'total_quota'     => 'required|integer|min:1',
			'effective_at'    => 'required|date',
			'period'          => 'required|string|in:daily,weekly,monthly,yearly,custom',
			'auto_renew_days' => 'required_if:period,custom|nullable|integer|min:1',
			'auto_renew'      => 'required|boolean',
		];
	}
}
