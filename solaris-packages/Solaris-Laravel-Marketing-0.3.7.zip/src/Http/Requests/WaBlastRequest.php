<?php

namespace Solaris\Marketing\Http\Requests;

use Solaris\Core\Http\Requests\BaseFormRequest;

class WaBlastRequest extends BaseFormRequest
{
	public function rules(): array
	{
		$rules = match ($this->method()) {
			'POST' => $this->createRules(),
			'PUT'  => $this->updateRules()
		};

		return $rules;
	}

	protected function createRules(): array
	{
		return [
			'title'       => 'required|string',
			'priority_id' => 'required|uuid',
		];
	}

	protected function updateRules(): array
	{
		return array_merge($this->createRules(), [
			'wa_template_detail_id' => 'required|uuid',
			'template_params' 		=> 'nullable|string',
			'notes'        			=> 'nullable|string'
		]);
	}
}
