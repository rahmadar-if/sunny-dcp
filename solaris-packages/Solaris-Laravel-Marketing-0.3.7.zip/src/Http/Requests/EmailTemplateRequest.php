<?php

namespace Solaris\Marketing\Http\Requests;

use Solaris\Core\Http\Requests\BaseFormRequest;

class EmailTemplateRequest extends BaseFormRequest
{
    public function rules(): array
    {
        return [
            'name'          => 'required|string',
            'html'          => 'required|string',
            'css'           => 'required|string',
            'width'         => 'required|integer',
            'height'        => 'required|integer',
            'html_compiled' => 'required|string',
            'amp_html'      => 'nullable|string'
        ];
    }
}