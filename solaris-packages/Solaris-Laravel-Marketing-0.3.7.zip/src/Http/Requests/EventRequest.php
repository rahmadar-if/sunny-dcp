<?php

namespace Solaris\Marketing\Http\Requests;

use Solaris\Core\Http\Requests\BaseFormRequest;

class EventRequest extends BaseFormRequest
{
    public function rules(): array
    {
        $rules = match ($this->method()) {
            'POST' => $this->createRules(),
            'PUT'  => $this->updateRules()
        };

        return $rules;
    }

    protected function createRules(): array
    {
        return [
            'name'       => 'required|string',
            'type_id'    => 'required|uuid',
            'start_date' => 'required|date_format:Y-m-d',
            'end_date'   => 'required|date_format:Y-m-d',
        ];
    }

    protected function updateRules(): array
    {
        return array_merge($this->createRules(), [
            'status_id'   => 'required|uuid',
            'stage_id'    => 'required|uuid',
            'goal'        => 'nullable|string',
            'budget_cost' => 'nullable|decimal:0,2',
            'actual_cost' => 'nullable|decimal:0,2',
            'notes'       => 'nullable|string',
        ]);
    }
}