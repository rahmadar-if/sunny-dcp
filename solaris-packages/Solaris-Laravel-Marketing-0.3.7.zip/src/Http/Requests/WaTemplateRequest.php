<?php

namespace Solaris\Marketing\Http\Requests;

use Illuminate\Support\Arr;
use Solaris\Core\Http\Requests\BaseFormRequest;

class WaTemplateRequest extends BaseFormRequest
{
	public function rules(): array
	{
		$rules = match ($this->method()) {
            'POST' => $this->createRules(),
            'PUT'  => $this->updateRules()
        };

        return $rules;
	}

	protected function createRules(): array
	{
		return [
			'name'        => 'required|string',
			'category_id' => 'required|uuid',
			'languages'   => 'required|array',
		];
	}

	protected function updateRules(): array
	{
		
		return Arr::except($this->createRules(), ['languages']);
	}
}
