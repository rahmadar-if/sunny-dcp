<?php

namespace Solaris\Marketing\Http\Requests;

use Solaris\Core\Http\Requests\BaseFormRequest;

class WaTemplateDetailRequest extends BaseFormRequest
{
	public function rules(): array
	{
		$rules = match ($this->method()) {
            'POST' => array_merge($this->createRules(), [
				'wa_template_id' => 'required|uuid',
			]),
            'PUT'  => $this->updateRules()
        };

        return $rules;
	}

	protected function createRules(): array
	{
		return [
			'sub_type_id' => 'required|uuid',
			'language_id' => 'required|uuid',
		];
	}

	protected function updateRules(): array
	{
		$limits = config('solaris.wa_template.limits');

		return array_merge($this->createRules(), [
			'header_type_id' => 'nullable|uuid',
			'header_content' => 'nullable|string',
			'header_examples'=> 'nullable|string',
			'body'           => ['nullable', 'string', 'max:' . $limits['body_max_chars']],
			'body_examples'  => 'nullable|string',
			'footer'         => ['nullable', 'string', 'max:' . $limits['footer_max_chars']],
			'buttons'        => 'nullable|string',
			'cards'          => 'nullable|string',
			'disclaimer'     => 'nullable|boolean',
			'expiry_minutes' => ['nullable', 'integer', 'min:' . $limits['auth_expiry_min'], 'max:' . $limits['auth_expiry_max']],
		]);
	}
}
