<?php

namespace Solaris\Marketing\Http\Requests;

use Solaris\Core\Http\Requests\BaseFormRequest;

class EmailBlastRequest extends BaseFormRequest
{
    public function rules(): array
    {
        if($this->routeIs('marketing.email-blast.editor.update')) {
            return [
                'html' => 'required|string',
                'css'  => 'required|string',
                'body' => 'required|string',
            ];
        }

        $rules = match ($this->method()) {
            'POST' => $this->createRules(),
            'PUT'  => $this->updateRules()
        };

        return $rules;
    }

    protected function createRules(): array
    {
        return [
            'title'       => 'required|string',
            'priority_id' => 'required|uuid',
        ];
    }

    protected function updateRules(): array
    {
        return array_merge($this->createRules(), [
            'subject'      => 'nullable|string',
            'sender_name'  => 'nullable|string',
            'sender_email' => 'nullable|string',
            'notes'        => 'nullable|string'
        ]);
    }
}