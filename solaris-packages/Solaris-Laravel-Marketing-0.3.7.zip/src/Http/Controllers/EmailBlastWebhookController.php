<?php

namespace Solaris\Marketing\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Solaris\Marketing\Services\Email\EmailBlastService;

class EmailBlastWebhookController
{
	public function __invoke(Request $request): Response
	{
		return EmailBlastService::queueWebhook($request->getContent(), $request->headers->all());
	}
}
