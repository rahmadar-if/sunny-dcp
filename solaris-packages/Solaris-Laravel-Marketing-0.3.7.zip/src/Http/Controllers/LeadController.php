<?php

namespace Solaris\Marketing\Http\Controllers;

use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Solaris\BaseCRM\Http\Controllers\LeadController as BaseLeadController;
use Solaris\Core\Helpers\Helper;

class LeadController extends BaseLeadController
{
    public function index(): View
    {
        $breadcrumbs = [
            ['label' => 'Marketing'],
            ['label' => 'Lead']
        ];

        return view(Helper::view("lead.list"), [
            'breadcrumbs' => $breadcrumbs
        ]);
    }

    public function show(Request $request, string $id): RedirectResponse|JsonResponse
    {
        if(!$request->expectsJson()) {
            return redirect(route('marketing.lead.edit', ['id' => $id]));
        }

        return parent::show($request, $id);
    }

    public function edit(string $id): View
    {
        $data = $this->repo->findComplete($id, $this->extendColumns());
        $breadcrumbs = [
            ['label' => 'Marketing'],
            ['label' => 'Lead'],
            ['label' => $data->name]
        ];

        return view(Helper::view("lead.page"), [
            'data'        => $data,
            'breadcrumbs' => $breadcrumbs
        ]);
    }
}