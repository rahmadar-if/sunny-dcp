<?php

namespace Solaris\Marketing\Http\Controllers;

use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Marketing\Http\Requests\CampaignBlastQuotaRequest;
use Solaris\Marketing\Repositories\CampaignBlastQuotaRepository;
use Solaris\Marketing\Services\CampaignBlastQuotaUsageService;

#[FormAccess()]
class CampaignBlastQuotaController
{
	public function __construct(protected CampaignBlastQuotaRepository $repo)
	{
	}

	public static function middleware(): array
	{
		return ['role:admin'];
	}

	public function index(): View
	{
		$breadcrumbs = [
			['label' => 'Admin'],
			['label' => 'Marketing'],
			['label' => 'Campaign Blast Quota']
		];

		return view("marketing::pages.campaign-blast-quota.list", [
			'breadcrumbs'     => $breadcrumbs,
			'email_providers' => $this->getEmailProviders(),
			'wa_providers'    => $this->getWAProviders()
		]);
	}

	public function store(CampaignBlastQuotaRequest $request): JsonResponse
	{
		return SolarResponse::success($this->repo->create($request->cleanData()));
	}

	public function usageGroups(string $id, Request $request): JsonResponse
	{
		return SolarResponse::success(CampaignBlastQuotaUsageService::groups(
			quotaId: $id,
			search : $request->input("search"),
			start  : (int) $request->input("start", 0),
			length : (int) $request->input("length", 10)
		));
	}

	public function disableAutoRenew(string $id): JsonResponse
	{
		try {
			$this->repo->disableAutoRenew($id);
			return SolarResponse::success(message: 'Auto renew disabled.');
		} catch (\Exception $e) {
			return response()->json(['message' => $e->getMessage()], 422);
		}
	}

	public function destroy(string $id): JsonResponse
	{
		return SolarResponse::deleted($this->repo->delete($id));
	}

	private function getEmailProviders(): array
	{
		return array_map(
			fn($item) => ['id' => $item, 'name' => Str::title($item)],
			array_keys(Helper::config("email_blast.providers", []))
		);
	}

	private function getWAProviders(): array
	{
		return array_map(
			fn($item) => ['id' => $item, 'name' => Str::title($item)],
			array_keys(Helper::config("wa_blast.providers", []))
		);
	}
}
