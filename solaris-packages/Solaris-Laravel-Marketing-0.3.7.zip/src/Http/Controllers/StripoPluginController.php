<?php

namespace Solaris\Marketing\Http\Controllers;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Marketing\Services\StripoPlugin;
use Solaris\Marketing\Services\TestEmailThrottle;

class StripoPluginController
{
    public function getToken(): JsonResponse
    {
        $token = "";
        try {
            $token = StripoPlugin::getToken();
        } catch (\Exception $e) {
            return SolarResponse::error($e->getMessage());
        }

        return SolarResponse::success($token);
    }

    public function getDefaultTemplate(): JsonResponse
    {
        return SolarResponse::success(StripoPlugin::getDefaultTemplate());
    }

    public function testEmailTemplate(Request $request): JsonResponse
    {
        $request->validate([
            'email'      => 'required|email',
            'subject'    => 'nullable|string|max:255',
            'html'       => 'required|string',
            'contact_id' => 'nullable|uuid',
            'scope'      => 'nullable|in:' . TestEmailThrottle::ScopeTemplate . ',' . TestEmailThrottle::ScopeEditor,
        ]);

        $scope       = $request->scope ?? TestEmailThrottle::ScopeTemplate;
        $secondsLeft = TestEmailThrottle::secondsLeft($scope);

        if ($secondsLeft > 0) {
            return response()->json([
                'success' => false,
                'message' => TestEmailThrottle::message($secondsLeft),
                'data'    => ['retry_at' => TestEmailThrottle::retryAt($scope)],
            ], 400);
        }

        $contact = $request->contact_id
            ? Helper::model('contact')::find($request->contact_id)
            : null;

        StripoPlugin::sendTestEmail($request->email, $request->subject ?? 'Test Email', $request->html, $contact);

        TestEmailThrottle::mark($scope);

        return SolarResponse::success(['retry_at' => TestEmailThrottle::retryAt($scope)]);
    }

    public function listFiles(Request $request): JsonResponse
    {
        if(!$this->validateBasicAuth($request)) {
            return response()->json(['message' => 'Unauthorized'], 401);
        }

        $keys = $request->query('keys', '');

        if(empty($keys)) {
            return response()->json([]);
        }

        return response()->json(StripoPlugin::listFiles($keys));
    }

    public function uploadFile(Request $request): JsonResponse
    {
        if(!$this->validateBasicAuth($request)) {
            return response()->json(['message' => 'Unauthorized'], 401);
        }

        $request->validate([
            'key'  => 'required|string',
            'file' => 'required|file',
        ]);

        return response()->json(StripoPlugin::uploadFile($request->key, $request->file('file')));
    }

    public function deleteFile(Request $request): JsonResponse
    {
        if(!$this->validateBasicAuth($request)) {
            return response()->json(['message' => 'Unauthorized'], 401);
        }

        $request->validate([
            'url' => 'required|string',
        ]);

        return response()->json(StripoPlugin::deleteFile($request->url));
    }

    public function fileInfo(Request $request): JsonResponse
    {
        if(!$this->validateBasicAuth($request)) {
            return response()->json(['message' => 'Unauthorized'], 401);
        }

        $src = $request->query('src', '');

        if(empty($src)) {
            return response()->json(['message' => 'Missing src parameter'], 422);
        }

        return response()->json(StripoPlugin::getFileInfo($src));
    }

    private function validateBasicAuth(Request $request): bool
    {
        $authHeader = $request->header('Authorization', '');

        if(!str_starts_with($authHeader, 'Basic ')) {
            return false;
        }

        $decoded = base64_decode(substr($authHeader, 6));
        [$login, $password] = array_pad(explode(':', $decoded, 2), 2, '');

        return $login === Helper::config('stripo_plugin.image_storage.login')
            && $password === Helper::config('stripo_plugin.image_storage.password');
    }
}
