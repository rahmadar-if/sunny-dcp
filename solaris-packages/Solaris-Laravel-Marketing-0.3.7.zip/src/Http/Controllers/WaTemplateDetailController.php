<?php

namespace Solaris\Marketing\Http\Controllers;

use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Core\Services\ModelBinding\ModelBindingResult;
use Solaris\Marketing\Repositories\WaTemplateDetailRepository;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

#[FormAccess()]
class WaTemplateDetailController
{
	/** @var WaTemplateDetailRepository */
	protected $repo;

	public function __construct()
	{
		$this->repo = new (Helper::repository('wa_template_detail'))(new (Helper::model('wa_template_detail')));
	}

	public function store(): JsonResponse
	{
		$request = app(Helper::formRequest("wa_template_detail"));
		$data    = $this->repo->create($request->cleanData());

		return SolarResponse::success($data);
	}

	public function show(Request $request, string $id): RedirectResponse|JsonResponse
	{
		if (!$request->expectsJson()) {
			return redirect(route('marketing.wa-template.detail.edit', ['id' => $id]));
		}

		return response()->json($this->repo->findComplete($id, $this->extendColumns()));
	}

	public function edit(string $id): View
	{
		$data             = $this->repo->findComplete($id, $this->extendColumns());
		$waTemplateConfig = Helper::config('wa_template');
		$breadcrumbs      = [
			['label' => 'Marketing'],
			['label' => 'WhatsApp Template'],
			['label' => $data->wa_template->name, 'url' => route('marketing.wa-template.edit', ['id' => $data->wa_template_id])],
			['label' => $data->language->name],
		];

		return view(Helper::view("wa_template_detail.page"), [
			'data'             => $data,
			'breadcrumbs'      => $breadcrumbs,
			'waTemplateConfig' => $waTemplateConfig,
		]);
	}

	public function update(string $id): JsonResponse
	{
		$request = app(Helper::formRequest("wa_template_detail"));
		$data    = $this->repo->update($id, $request->cleanData());

		return SolarResponse::success($data);
	}

	public function updateMedia(Request $request): JsonResponse
	{
		$request->validate([
			'id'                               => 'required|uuid',
			'header_attachment_id'             => 'nullable|uuid',
			'card_attachments'                 => 'nullable|array',
			'card_attachments.*.card_id'       => 'required_with:card_attachments|string',
			'card_attachments.*.attachment_id' => 'required_with:card_attachments|uuid',
		]);

		return SolarResponse::success($this->repo->updateMedia($request->all()));
	}

	public function previewMedia(string $id): BinaryFileResponse
	{
		return $this->repo->previewMedia($id);
	}

	public function destroy(string $id): JsonResponse
	{
		return SolarResponse::deleted($this->repo->delete($id));
	}

	public function batchDelete(Request $request, ModelBindingResult $modelParsing): JsonResponse
	{
		return SolarResponse::success($this->repo->requestBatchDelete($request, $modelParsing));
	}

	public function extendColumns(): array
	{
		return [
			"wa_template.category",
			"language_id",
			"sub_type_id",
			"status_id",
			"header_type_id",
			"header_content",
			"header_examples",
			"body",
			"body_examples",
			"footer",
			"buttons",
			"cards",
			"disclaimer",
			"expiry_minutes",
			"reject_reason",
		];
	}
}
