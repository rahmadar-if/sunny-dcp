<?php

namespace Solaris\Marketing\Http\Controllers;

use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Solaris\Marketing\Services\MarketingDashboard;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Services\Dashboard\DashboardService;

class MarketingDashboardController
{
    public function index(): View
    {
        $breadcrumbs = [
            ['label' => 'Dashboard'],
            ['label' => 'Marketing']
        ];

        $period = DashboardService::getDefaultPeriod();

        return view(Helper::view("marketing_dashboard"), [
            'breadcrumbs' => $breadcrumbs,
            'data'        => MarketingDashboard::all($period)
        ]);
    }

    public function all(Request $request): JsonResponse
    {
        $period = $request->input('period');
        return response()->json(MarketingDashboard::all($period));
    }
}