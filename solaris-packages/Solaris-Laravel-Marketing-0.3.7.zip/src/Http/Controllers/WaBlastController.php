<?php

namespace Solaris\Marketing\Http\Controllers;

use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Solaris\Marketing\Const\CampaignBlastTypeConst;
use Solaris\Marketing\Services\CampaignBlastQuotaService;
use Solaris\Marketing\Services\WhatsApp\WaTemplateService;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Core\Services\ModelBinding\ModelBindingResult;
use Solaris\Marketing\Repositories\WaBlastRepository;
use Solaris\Marketing\Services\WhatsApp\WaBlastService;

#[FormAccess()]
class WaBlastController
{
	/** @var WaBlastRepository */
	protected $repo;

	public function __construct()
	{
		$this->repo = new (Helper::repository('wa_blast'))(new (Helper::model('wa_blast')));
	}

	public function index(): View
	{
		$breadcrumbs = [
			['label' => 'Marketing'],
			['label' => 'Campaign'],
			['label' => 'WhatsApp Blast']
		];

		return view(Helper::view("wa_blast.list"), [
			'breadcrumbs' => $breadcrumbs
		]);
	}

	public function store(): JsonResponse
	{
		$request = app(Helper::formRequest("wa_blast"));
		$data    = $this->repo->create($request->cleanData());

		return SolarResponse::success($data);
	}

	public function show(Request $request, string $id): RedirectResponse|JsonResponse
	{
		if (!$request->expectsJson()) {
			return redirect(route('marketing.wa-blast.edit', ['id' => $id]));
		}

		return response()->json($this->repo->findComplete($id, $this->extendColumns()));
	}

	public function edit(string $id): View
	{
		$data        = $this->repo->findComplete($id, $this->extendColumns());
		$breadcrumbs = [
			['label' => 'Marketing'],
			['label' => 'Campaign'],
			['label' => 'WhatsApp Blast'],
			['label' => $data->title]
		];

		return view(Helper::view("wa_blast.page"), [
			'data'        => $data,
			'breadcrumbs' => $breadcrumbs
		]);
	}

	public function update(string $id): JsonResponse
	{
		$request = app(Helper::formRequest("wa_blast"));
		$data    = $this->repo->update($id, $request->cleanData());

		return SolarResponse::success($data);
	}

	public function addAudience(Request $request): JsonResponse
	{
		$waBlastId   = $request->input("wa_blast_id");
		$isSelectAll = $request->input("select_all");
		$selected    = $request->input("selected");
		$excluded    = $request->input("excluded");
		$filters     = $request->input("filters");

		return response()->json(["success" => $this->repo->addAudience($waBlastId, $isSelectAll, $selected, $excluded, $filters)]);
	}

	public function sendNow(Request $request): JsonResponse
	{
		try {
			WaBlastService::send($request->input("id"), $request->user());
		} catch (\Exception $e) {
			return SolarResponse::error($e->getMessage());
		}

		return SolarResponse::success();
	}

	public function schedule(Request $request): JsonResponse
	{
		try {
			WaBlastService::schedule($request->input("id"), $request->input("schedule_at"), user: $request->user());
		} catch (\Exception $e) {
			return SolarResponse::error($e->getMessage());
		}

		return SolarResponse::success();
	}

	public function sendTest(Request $request): JsonResponse
	{
		$waBlastId = $request->input("id");
		$phone 	   = $request->input("phone");
		$contact   = Helper::model('contact')::find($request->input("contact_id"));

		return response()->json(WaBlastService::sendTest($waBlastId, $phone, $contact));
	}

	public function getAvailableSchedule(): JsonResponse
	{
		$provider   = Helper::config('wa_blast.default');
		$availDates = CampaignBlastQuotaService::getAvailableScheduleDates($provider, CampaignBlastTypeConst::WhatsApp);

		return SolarResponse::success($availDates);
	}

	public function cancelSchedule(Request $request): JsonResponse
	{
		try {
			WaBlastService::cancel($request->input("id"));
		} catch (\Exception $e) {
			return SolarResponse::error($e->getMessage());
		}

		return SolarResponse::success();
	}

	public function destroy(string $id): JsonResponse
	{
		return SolarResponse::deleted($this->repo->delete($id));
	}

	public function batchDelete(Request $request, ModelBindingResult $modelParsing): JsonResponse
	{
		return SolarResponse::success($this->repo->requestBatchDelete($request, $modelParsing));
	}

	public function templateParamColumns(): JsonResponse
	{
		return response()->json(
			WaTemplateService::resolveParams(Helper::model('contact'))
		);
	}

	public function extendColumns(): array
	{
		return [];
	}
}
