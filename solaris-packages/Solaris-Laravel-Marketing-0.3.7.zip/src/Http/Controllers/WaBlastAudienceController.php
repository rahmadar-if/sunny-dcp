<?php

namespace Solaris\Marketing\Http\Controllers;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Core\Services\ModelBinding\ModelBindingResult;
use Solaris\Marketing\Repositories\WaBlastAudienceRepository;

#[FormAccess()]
class WaBlastAudienceController
{
	/** @var WaBlastAudienceRepository */
	protected $repo;

	public function __construct()
	{
		$this->repo = new (Helper::repository('wa_blast_audience'))(new (Helper::model('wa_blast_audience')));
	}

	public function store(): JsonResponse
	{
		$request = app(Helper::formRequest("wa_blast_audience"));
		$data    = $this->repo->create($request->cleanData());

		return SolarResponse::success($data);
	}

	public function show(string $id): JsonResponse
	{
		return response()->json($this->repo->findComplete($id, $this->extendColumns()));
	}

	public function destroy(string $id): JsonResponse
	{
		return SolarResponse::deleted($this->repo->delete($id));
	}

	public function batchDelete(Request $request, ModelBindingResult $modelParsing): JsonResponse
	{
		return SolarResponse::success($this->repo->requestBatchDelete($request, $modelParsing));
	}

	public function extendColumns(): array
	{
		return [];
	}
}
