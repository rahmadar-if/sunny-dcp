<?php

namespace Solaris\Marketing\Http\Controllers;

use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Mail\Mailables\Address;
use Solaris\Marketing\Const\CampaignBlastTypeConst;
use Solaris\Marketing\Services\CampaignBlastQuotaService;
use Solaris\Marketing\Services\Email\EmailBlastService;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Core\Services\ModelBinding\ModelBindingResult;
use Solaris\Marketing\Repositories\EmailBlastRepository;
use Solaris\Marketing\Services\Email\EmailMergeTagService;
use Solaris\Marketing\Services\StripoPlugin;
use Solaris\Marketing\Services\TestEmailThrottle;

#[FormAccess()]
class EmailBlastController
{
    /** @var EmailBlastRepository */
    protected $repo;

    public function __construct()
    {
        $this->repo = new (Helper::repository('email_blast'))(new (Helper::model('email_blast')));
    }

    public function index(): View
    {
        $breadcrumbs = [
            ['label' => 'Marketing'],
            ['label' => 'Campaign'],
            ['label' => 'Email Blast']
        ];

        return view(Helper::view("email_blast.list"), [
            'breadcrumbs' => $breadcrumbs
        ]);
    }

    public function editor(string $id): View
    {
        $data = Helper::model('email_blast')::select("id", "html", "css")->firstWhere("id", $id);
        if(is_null($data)) {
            abort('404');
        }

        return view(Helper::view("email_blast.editor"), [
            'email_id'   => StripoPlugin::getEmailId(),
            'id'         => $data->id,
            'html'       => $data->html,
            'css'        => $data->css,
            'merge_tags' => EmailMergeTagService::resolve(Helper::model('contact')),
        ]);
    }

    public function editorPreview(string $id): Response
    {
        $data = Helper::model('email_blast')::select("body")->firstWhere("id", $id);
        if(empty($data?->body)) {
            return response()
                ->view(Helper::view("email_blast.preview"))
                ->header('Content-Type', 'text/html');
        }

        return response($data->body)
            ->header('Content-Type', 'text/html');
    }

    public function store(): JsonResponse
    {
        $request = app(Helper::formRequest("email_blast"));
        $data    = $this->repo->create($request->cleanData());

        return SolarResponse::success($data);
    }

    public function show(Request $request, string $id): RedirectResponse|JsonResponse
    {
        if(!$request->expectsJson()) {
            return redirect(route('marketing.email-blast.edit', ['id' => $id]));
        }

        return response()->json($this->repo->findComplete($id, $this->extendColumns()));
    }

    public function edit(string $id): View
    {
        $data = $this->repo->findComplete($id, $this->extendColumns());
        $breadcrumbs = [
            ['label' => 'Marketing'],
            ['label' => 'Campaign'],
            ['label' => 'Email Blast'],
            ['label' => $data->title]
        ];

        return view(Helper::view("email_blast.page"), [
            'data'        => $data,
            'breadcrumbs' => $breadcrumbs
        ]);
    }

    public function update(string $id): JsonResponse
    {
        $request = app(Helper::formRequest("email_blast"));
        $data    = $this->repo->update($id, $request->cleanData());

        return SolarResponse::success($data);
    }

    public function addAudience(Request $request): JsonResponse
    {
        $eventId     = $request->input("email_blast_id");
        $isSelectAll = $request->input("select_all");
        $selected    = $request->input("selected");
        $excluded    = $request->input("excluded");
        $filters     = $request->input("filters");
        
        return response()->json(["success" => $this->repo->addAudience($eventId, $isSelectAll, $selected, $excluded, $filters)]);
    }

    public function testEmail(Request $request): JsonResponse
    {
        $request->validate([
            'id'         => 'required|uuid',
            'email'      => 'required|email',
            'subject'    => 'nullable|string|max:255',
            'contact_id' => 'nullable|uuid',
        ]);

        $scope       = TestEmailThrottle::ScopeBlast;
        $secondsLeft = TestEmailThrottle::secondsLeft($scope);

        if ($secondsLeft > 0) {
            return response()->json([
                'success' => false,
                'message' => TestEmailThrottle::message($secondsLeft),
                'data'    => ['retry_at' => TestEmailThrottle::retryAt($scope)],
            ], 400);
        }

        $data = Helper::model('email_blast')::select('body', 'subject')->firstWhere('id', $request->id);

        if(empty($data?->body)) {
            return SolarResponse::error('Email body is empty. Please edit the template first.');
        }

        $contact = $request->contact_id
            ? Helper::model('contact')::find($request->contact_id)
            : null;

        StripoPlugin::sendTestEmail(
            $request->email,
            $request->subject ?? $data->subject ?? 'Test Email',
            $data->body,
            $contact
        );

        TestEmailThrottle::mark($scope);

        return SolarResponse::success(['retry_at' => TestEmailThrottle::retryAt($scope)]);
    }

    public function sendNow(Request $request): JsonResponse
    {
        try {
            EmailBlastService::send($request->input("id"), $request->user());
        } catch (\Exception $e) {
            return SolarResponse::error($e->getMessage());
        }

        return SolarResponse::success();
    }

    public function schedule(Request $request): JsonResponse
    {
        try {
            EmailBlastService::schedule($request->input("id"), $request->input("schedule_at"), user: $request->user());
        } catch (\Exception $e) {
            return SolarResponse::error($e->getMessage());
        }

        return SolarResponse::success();
    }

    public function getAvailableSchedule(): JsonResponse
    {
        $provider   = Helper::config('email_blast.default');
        $availDates = CampaignBlastQuotaService::getAvailableScheduleDates($provider, CampaignBlastTypeConst::Email);

        return SolarResponse::success($availDates);
    }

    public function cancelSchedule(Request $request): JsonResponse
    {
        try {
            EmailBlastService::cancel($request->input("id"));
        } catch (\Exception $e) {
            return SolarResponse::error($e->getMessage());
        }

        return SolarResponse::success();
    }

    public function destroy(string $id): JsonResponse
    {
        return SolarResponse::deleted($this->repo->delete($id));
    }

    public function batchDelete(Request $request, ModelBindingResult $modelParsing): JsonResponse
    {
        return SolarResponse::success($this->repo->requestBatchDelete($request, $modelParsing));
    }

    public function extendColumns(): array
    {
        return [];
    }
}
