<?php

namespace Solaris\Marketing\Http\Controllers;

use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Core\Services\ModelBinding\ModelBindingResult;
use Solaris\Marketing\Repositories\WaTemplateRepository;
use Solaris\Marketing\Services\WhatsApp\WaTemplateService;

#[FormAccess()]
class WaTemplateController
{
	/** @var WaTemplateRepository */
	protected $repo;

	public function __construct()
	{
		$this->repo = new (Helper::repository('wa_template'))(new (Helper::model('wa_template')));
	}

	public function index(): View
	{
		$breadcrumbs = [
			['label' => 'Marketing'],
			['label' => 'WhatsApp Template']
		];

		return view(Helper::view("wa_template.list"), [
			'breadcrumbs' => $breadcrumbs
		]);
	}

	public function store(): JsonResponse
	{
		$request = app(Helper::formRequest("wa_template"));
		$data    = $this->repo->create($request->cleanData());

		return SolarResponse::success($data);
	}

	public function show(Request $request, string $id): RedirectResponse|JsonResponse
	{
		if (!$request->expectsJson()) {
			return redirect(route('marketing.wa-template.edit', ['id' => $id]));
		}

		return response()->json($this->repo->findComplete($id, $this->extendColumns()));
	}

	public function edit(string $id): View
	{
		$data        = $this->repo->findComplete($id, $this->extendColumns());
		$breadcrumbs = [
			['label' => 'Marketing'],
			['label' => 'WhatsApp Template'],
			['label' => $data->name]
		];

		return view(Helper::view("wa_template.page"), [
			'data'        => $data,
			'breadcrumbs' => $breadcrumbs
		]);
	}

	public function update(string $id): JsonResponse
	{
		$request = app(Helper::formRequest("wa_template"));
		$data    = $this->repo->update($id, $request->cleanData());

		return SolarResponse::success($data);
	}

	public function submitToMeta(Request $request): JsonResponse
	{
		try {
			return response()->json(WaTemplateService::createTemplate($request->input('id')));
		} catch (\Exception $e) {
			return SolarResponse::error($e->getMessage());
		}
	}

	public function syncTemplate(Request $request): JsonResponse
	{
		try {
			return response()->json(WaTemplateService::syncTemplate($request->input('id')));
		} catch (\Exception $e) {
			return SolarResponse::error($e->getMessage());
		}
	}

	public function syncAllTemplates(): JsonResponse
	{
		try {
			return response()->json(WaTemplateService::syncAllTemplates());
		} catch (\Exception $e) {
			return SolarResponse::error($e->getMessage());
		}
	}

	public function destroy(string $id): JsonResponse
	{
		return SolarResponse::deleted($this->repo->delete($id));
	}

	public function batchDelete(Request $request, ModelBindingResult $modelParsing): JsonResponse
	{
		return SolarResponse::success($this->repo->requestBatchDelete($request, $modelParsing));
	}

	public function extendColumns(): array
	{
		return [
			"name",
			"template_name",
			"category",
			"details[language,status]"
		];
	}
}
