<?php

namespace Solaris\Marketing\Http\Controllers;

use Solaris\BaseCRM\Http\Controllers\ActivityController as BaseActivityController;

class ActivityController extends BaseActivityController
{
    public function extendColumns(): array
    {
        return array_merge(parent::extendColumns(), [
            "event_id",
            "email_blast_id",
            "wa_blast_id"
        ]);
    }
}