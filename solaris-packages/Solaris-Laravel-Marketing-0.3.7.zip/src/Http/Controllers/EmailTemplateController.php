<?php

namespace Solaris\Marketing\Http\Controllers;

use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\Core\Services\ModelBinding\ModelBindingResult;
use Solaris\Marketing\Services\Email\EmailMergeTagService;
use Solaris\Marketing\Services\StripoPlugin;

#[FormAccess()]
class EmailTemplateController
{
    /** @var BaseRepository */
    protected $repo;

    public function __construct()
    {
        $this->repo = new (Helper::repository('email_template'))(new (Helper::model('email_template')));
    }

    public function index(): View
    {
        $breadcrumbs = [
            ['label' => 'Marketing'],
            ['label' => 'Email Template']
        ];

        return view(Helper::view("email_template.list"), [
            'breadcrumbs' => $breadcrumbs
        ]);
    }

    public function new(): View
    {
        return view(Helper::view("email_template.page"), [
            'email_id'   => StripoPlugin::getEmailId(),
            'merge_tags' => EmailMergeTagService::resolve(Helper::model('contact')),
        ]);
    }

    public function store(): JsonResponse
    {
        $request = app(Helper::formRequest("email_template"));
        $data    = $this->repo->create($request->cleanData());

        return SolarResponse::success($data->id);
    }

    public function show(Request $request, string $id): RedirectResponse|JsonResponse
    {
        if(!$request->expectsJson()) {
            return redirect(route('marketing.email-template.edit', ['id' => $id]));
        }

        return response()->json($this->repo->findComplete($id, $this->extendColumns()));
    }

    public function edit(string $id): View
    {
        $data = $this->repo->findComplete($id, $this->extendColumns());

        return view(Helper::view("email_template.page"), [
            'id'         => $data->id,
            'name'       => $data->name,
            'html'       => $data->html,
            'css'        => $data->css,
            'email_id'   => StripoPlugin::getEmailId(),
            'merge_tags' => EmailMergeTagService::resolve(Helper::model('contact')),
        ]);
    }

    public function update(string $id): JsonResponse
    {
        $request = app(Helper::formRequest("email_template"));
        $data    = $this->repo->update($id, $request->cleanData());

        return SolarResponse::success($data);
    }

    public function listForPicker(): JsonResponse
    {
        $data = Helper::model('email_template')::select('id', 'name', 'html_compiled', 'html', 'css')
            ->whereNotNull('html_compiled')
            ->orderBy('created_at', 'desc')
            ->get();

        return SolarResponse::success($data);
    }

    public function destroy(string $id): JsonResponse
    {
        return SolarResponse::deleted($this->repo->delete($id));
    }

    public function batchDelete(Request $request, ModelBindingResult $modelParsing): JsonResponse
    {
        return SolarResponse::success($this->repo->requestBatchDelete($request, $modelParsing));
    }

    public function extendColumns(): array
    {
        return ["html", "css", "html_compiled"];
    }
}