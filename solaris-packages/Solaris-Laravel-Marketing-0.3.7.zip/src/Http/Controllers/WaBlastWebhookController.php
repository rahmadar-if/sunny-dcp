<?php

namespace Solaris\Marketing\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Solaris\Marketing\Services\WhatsApp\WaBlastService;

class WaBlastWebhookController
{
	public function __invoke(Request $request): Response
	{
		return WaBlastService::queueWebhook($request->getContent(), $request->headers->all());
	}
}
