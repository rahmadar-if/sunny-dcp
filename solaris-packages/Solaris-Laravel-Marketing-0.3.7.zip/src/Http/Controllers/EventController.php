<?php

namespace Solaris\Marketing\Http\Controllers;

use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Core\Services\ModelBinding\ModelBindingResult;
use Solaris\Marketing\Repositories\EventRepository;

#[FormAccess()]
class EventController
{
    /** @var EventRepository */
    protected $repo;

    public function __construct()
    {
        $this->repo = new (Helper::repository('event'))(new (Helper::model('event')));
    }

    public function index(): View
    {
        $breadcrumbs = [
            ['label' => 'Marketing'],
            ['label' => 'Event']
        ];

        return view(Helper::view("event.list"), [
            'breadcrumbs' => $breadcrumbs
        ]);
    }

    public function store(): JsonResponse
    {
        $request = app(Helper::formRequest("event"));
        $data    = $this->repo->create($request->cleanData());

        return SolarResponse::success($data);
    }

    public function show(Request $request, string $id): RedirectResponse|JsonResponse
    {
        if(!$request->expectsJson()) {
            return redirect(route('marketing.event.edit', ['id' => $id]));
        }

        return response()->json($this->repo->findComplete($id, $this->extendColumns()));
    }

    public function edit(string $id): View
    {
        $data = $this->repo->findComplete($id, $this->extendColumns());
        $breadcrumbs = [
            ['label' => 'Marketing'],
            ['label' => 'Event'],
            ['label' => $data->name]
        ];

        return view(Helper::view("event.page"), [
            'data'        => $data,
            'breadcrumbs' => $breadcrumbs
        ]);
    }

    public function update(string $id): JsonResponse
    {
        $request = app(Helper::formRequest("event"));
        $data    = $this->repo->update($id, $request->cleanData());

        return SolarResponse::success($data);
    }

    public function addAudience(Request $request): JsonResponse
    {
        $eventId     = $request->input("event_id");
        $isSelectAll = $request->input("select_all");
        $selected    = $request->input("selected");
        $excluded    = $request->input("excluded");
        $filters     = $request->input("filters");
        
        return response()->json(["success" => $this->repo->addAudience($eventId, $isSelectAll, $selected, $excluded, $filters)]);
    }

    public function destroy(string $id): JsonResponse
    {
        return SolarResponse::deleted($this->repo->delete($id));
    }

    public function batchDelete(Request $request, ModelBindingResult $modelParsing): JsonResponse
    {
        return SolarResponse::success($this->repo->requestBatchDelete($request, $modelParsing));
    }

    public function extendColumns(): array
    {
        return [];
    }
}
