<?php

namespace Solaris\Marketing\Console\Commands;

use Illuminate\Console\Command;
use Solaris\Marketing\Services\CampaignBlastQuotaService;

class CampaignBlastQuotaAutoRenewCommand extends Command
{
	protected $signature   = 'solaris:campaign-blast-quota';
	protected $description = 'Renew campaign blast quotas expiring tomorrow';

	public function handle(): void
	{
		$count = CampaignBlastQuotaService::autoRenew();
		$this->info("Auto-renewed {$count} quota(s).");
	}
}
