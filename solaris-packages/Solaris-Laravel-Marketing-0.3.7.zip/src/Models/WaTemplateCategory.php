<?php

namespace Solaris\Marketing\Models;

use Solaris\Core\Models\LookupModel;

class WaTemplateCategory extends LookupModel
{
	protected $table = 'wa_template_categories';
}
