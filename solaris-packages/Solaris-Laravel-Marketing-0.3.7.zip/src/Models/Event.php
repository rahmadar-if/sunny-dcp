<?php

namespace Solaris\Marketing\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Solaris\Marketing\Const\EventStageConst;
use Solaris\Marketing\Const\EventStatusConst;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FolderAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\ImportAccess;
use Solaris\Core\Attributes\LookupAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Traits\Model\HasStageHistory;

#[FormAccess()]
#[DataTableAccess()]
#[LookupAccess()]
#[ExportAccess()]
#[ImportAccess()]
#[FolderAccess()]
class Event extends BaseModel
{
    use HasStageHistory;

    protected $table        = 'events';
    protected ?string $displayValue = 'name';

    protected static function booted(): void
    {
        parent::booted();

        static::creating(function ($event){
            $event->status_id = EventStatusConst::Planned;
            $event->stage_id  = EventStageConst::Draft;
        });
    }

    protected function casts(): array
    {
        return array_merge(parent::casts(),
        [
            'start_date'  => 'date',
            'end_date'    => 'date',
            'budget_cost' => 'float',
            'actual_cost' => 'float'
        ]);
    }

    protected static function stageHistoryModel(): string
    {
        return Helper::model('event_stage_history');
    }

    protected static function stageColumn(): string
    {
        return "stage_id";
    }

    public function status(): BelongsTo
    {
        return $this->belongsTo(Helper::model('event_status'), 'status_id', 'id');
    }

    public function type(): BelongsTo
    {
        return $this->belongsTo(Helper::model('event_type'), 'type_id', 'id');
    }

    public function stage(): BelongsTo
    {
        return $this->belongsTo(Helper::model('event_stage'), 'stage_id', 'id');
    }

    public function stage_history(): HasMany
    {
        return $this->hasMany(Helper::model('event_stage_history'), 'event_id', 'id');
    }

    public function audiences(): HasMany
    {
        return $this->hasMany(Helper::model('event_audience'), 'event_id', 'id');
    }
}