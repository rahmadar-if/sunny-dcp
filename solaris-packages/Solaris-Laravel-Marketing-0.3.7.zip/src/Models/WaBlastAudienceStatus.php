<?php

namespace Solaris\Marketing\Models;

use Solaris\Core\Models\LookupModel;

class WaBlastAudienceStatus extends LookupModel
{
	protected $table = 'wa_blast_audience_statuses';
}
