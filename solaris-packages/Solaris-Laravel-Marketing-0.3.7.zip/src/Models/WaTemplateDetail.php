<?php

namespace Solaris\Marketing\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\LookupAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

#[FormAccess()]
#[DataTableAccess()]
#[ExportAccess()]
#[LookupAccess()]
class WaTemplateDetail extends BaseModel
{
	protected $table = "wa_template_details";

	protected function casts(): array
    {
        return array_merge(parent::casts(), [
            'disclaimer' => 'boolean',
        ]);
    }

	public function getDisplayValue(): ?string
	{
		return $this->wa_template->name." - ".$this->language->name;
	}

	public function wa_template(): BelongsTo
	{
		return $this->belongsTo(Helper::model('wa_template'), 'wa_template_id');
	}

    public function sub_type(): BelongsTo
	{
		return $this->belongsTo(Helper::model('wa_template_sub_type'), 'sub_type_id');
	}

	public function language(): BelongsTo
	{
		return $this->belongsTo(Helper::model('wa_template_language'), 'language_id');
	}

	public function status(): BelongsTo
	{
		return $this->belongsTo(Helper::model('wa_template_status'), 'status_id');
	}

	public function header_type(): BelongsTo
	{
		return $this->belongsTo(Helper::model('wa_template_header_type'), 'header_type_id');
	}
}
