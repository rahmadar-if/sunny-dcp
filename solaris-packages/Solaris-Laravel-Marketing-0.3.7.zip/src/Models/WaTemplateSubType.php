<?php

namespace Solaris\Marketing\Models;

use Solaris\Core\Models\LookupModel;

class WaTemplateSubType extends LookupModel
{
	protected $table = 'wa_template_sub_types';
}
