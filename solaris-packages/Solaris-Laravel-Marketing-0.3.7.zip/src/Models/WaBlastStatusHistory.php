<?php

namespace Solaris\Marketing\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\StageHistoryModel;

class WaBlastStatusHistory extends StageHistoryModel
{
	protected $table = 'wa_blast_status_histories';

	public function status(): BelongsTo
	{
		return $this->belongsTo(Helper::model('campaign_blast_status'), 'status_id', 'id');
	}

	public function wa_blast(): BelongsTo
	{
		return $this->belongsTo(Helper::model('wa_blast'), 'wa_blast_id', 'id');
	}

	protected static function parentModel(): string
	{
		return Helper::model('wa_blast');
	}

	protected static function parentColumn(): string
	{
		return "wa_blast_id";
	}

	protected static function stageModel(): string
	{
		return Helper::model('campaign_blast_status');
	}

	protected static function stageColumn(): string
	{
		return "status_id";
	}
}
