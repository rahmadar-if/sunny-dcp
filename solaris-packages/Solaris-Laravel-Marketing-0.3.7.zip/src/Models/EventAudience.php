<?php

namespace Solaris\Marketing\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

#[FormAccess()]
#[DataTableAccess()]
#[ExportAccess()]
class EventAudience extends BaseModel
{
    protected $table = "event_audiences";

    public function event(): BelongsTo
    {
        return $this->belongsTo(Helper::model('event'), 'event_id', 'id');
    }
    
    public function contact(): BelongsTo
    {
        return $this->belongsTo(Helper::model('contact'), 'contact_id', 'id');
    }
}