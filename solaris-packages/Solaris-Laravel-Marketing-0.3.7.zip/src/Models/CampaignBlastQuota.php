<?php

namespace Solaris\Marketing\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Facades\Log;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\FolderAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Models\BaseModel;
use Solaris\Marketing\Const\CampaignBlastQuotaActionConst;

#[FormAccess()]
#[DataTableAccess()]
#[FolderAccess()]
#[ExportAccess()]
class CampaignBlastQuota extends BaseModel
{
    protected $table     = "campaign_blast_quotas";
    protected string|array $orderBy   = [
        ['column' => 'expired_at', 'direction' => 'desc'],
        ['column' => 'effective_at', 'direction' => 'asc']
    ];

    protected function casts(): array
    {
        return array_merge(parent::casts(), [
            "effective_at"    => 'datetime',
            "expired_at"      => 'datetime',
            "total_quota"     => "integer",
            "quota_book"      => "integer",
            "quota_used"      => "integer",
            "auto_renew"      => "boolean",
            "auto_renew_days" => "integer",
        ]);
    }

    public function type(): BelongsTo
    {
        return $this->belongsTo(CampaignBlastType::class, 'type_id', 'id');
    }

    public function logs(): HasMany
    {
        return $this->hasMany(CampaignBlastQuotaLog::class, 'quota_id', 'id');
    }

    public function quota(): int
    {
        return $this->total_quota - $this->quota_book - $this->quota_used;
    }

    public function book(
        int $request,
        ?string $context = null,
        ?string $sourceType = null,
        ?string $sourceId = null,
        ?string $userId = null): void
    {
        if ($request <= 0) {
            return;
        }

        $this->quota_book += $request;
        $this->save();

        CampaignBlastQuotaLog::record(
            quota     : $this,
            action    : CampaignBlastQuotaActionConst::Book,
            context   : $context,
            bookDelta : $request,
            usedDelta : 0,
            sourceType: $sourceType,
            sourceId  : $sourceId,
            userId    : $userId
        );
    }

    public function cancelBook(
        int $bookQty,
        ?string $context = null,
        ?string $sourceType = null,
        ?string $sourceId = null,
        ?string $userId = null): void
    {
        $actualBook = $this->clampBook($bookQty, "cancel");

        if ($actualBook <= 0) {
            return;
        }

        $this->quota_book -= $actualBook;
        $this->save();

        CampaignBlastQuotaLog::record(
            quota     : $this,
            action    : CampaignBlastQuotaActionConst::Release,
            context   : $context,
            bookDelta : -$actualBook,
            usedDelta : 0,
            sourceType: $sourceType,
            sourceId  : $sourceId,
            userId    : $userId
        );
    }

    public function consume(
        int $bookQty,
        int $usedQty,
        ?string $context = null,
        ?string $sourceType = null,
        ?string $sourceId = null,
        ?string $userId = null): void
    {
        $actualBook = $this->clampBook($bookQty, "consume");
        $actualUsed = max(0, min($usedQty, $actualBook));

        if ($actualBook <= 0 && $actualUsed <= 0) {
            return;
        }

        $this->quota_book -= $actualBook;
        $this->quota_used += $actualUsed;
        $this->save();

        CampaignBlastQuotaLog::record(
            quota     : $this,
            action    : CampaignBlastQuotaActionConst::Consume,
            context   : $context,
            bookDelta : -$actualBook,
            usedDelta : $actualUsed,
            sourceType: $sourceType,
            sourceId  : $sourceId,
            userId    : $userId
        );
    }

    private function clampBook(int $request, string $operation): int
    {
        $actual = max(0, min($request, $this->quota_book));

        if ($actual === $request) {
            return $actual;
        }

        Log::warning("Campaign blast quota {$operation} clamped", [
            'quota_id'   => $this->id,
            'requested'  => $request,
            'applied'    => $actual,
            'quota_book' => $this->quota_book,
        ]);

        return $actual;
    }
}
