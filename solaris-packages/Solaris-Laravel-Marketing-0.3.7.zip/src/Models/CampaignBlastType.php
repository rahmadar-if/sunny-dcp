<?php

namespace Solaris\Marketing\Models;

use Solaris\Core\Models\LookupModel;

class CampaignBlastType extends LookupModel
{
    protected $table = 'campaign_blast_types';
}