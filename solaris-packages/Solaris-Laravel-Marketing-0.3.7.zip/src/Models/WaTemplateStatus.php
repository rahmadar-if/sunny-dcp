<?php

namespace Solaris\Marketing\Models;

use Solaris\Core\Models\LookupStage;

class WaTemplateStatus extends LookupStage
{
	protected $table = 'wa_template_statuses';
}
