<?php

namespace Solaris\Marketing\Models;

use Solaris\Core\Models\LookupModel;

class EventStatus extends LookupModel
{
    protected $table = 'event_statuses';
}