<?php

namespace Solaris\Marketing\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\StageHistoryModel;

class EventStageHistory extends StageHistoryModel
{
    protected $table = 'event_stage_histories';

    public function stage(): BelongsTo
    {
        return $this->belongsTo(Helper::model('event_stage'), 'stage_id', 'id');
    }

    public function event(): BelongsTo
    {
        return $this->belongsTo(Helper::model('event'), 'event_id', 'id');
    }

    protected static function parentModel(): string
    {
        return Helper::model('event');
    }

    protected static function parentColumn(): string
    {
        return "event_id";
    }

    protected static function stageModel(): string
    {
        return Helper::model('event_stage');
    }

    protected static function stageColumn(): string
    {
        return "stage_id";
    }
}