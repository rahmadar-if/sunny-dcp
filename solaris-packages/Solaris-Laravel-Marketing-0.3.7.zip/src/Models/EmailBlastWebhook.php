<?php

namespace Solaris\Marketing\Models;

use Solaris\Core\Models\BaseModel;

class EmailBlastWebhook extends BaseModel
{
    protected $table = 'email_blast_webhooks';
}