<?php

namespace Solaris\Marketing\Models;

use Solaris\Core\Models\LookupModel;

class EventType extends LookupModel
{
    protected $table = 'event_types';
}