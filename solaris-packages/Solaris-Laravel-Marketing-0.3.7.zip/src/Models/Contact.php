<?php

namespace Solaris\Marketing\Models;

use Illuminate\Database\Eloquent\Builder;
use Solaris\BaseCRM\Models\Contact as BaseContact;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Marketing\Attributes\EmailMergeTags;
use Solaris\Marketing\Attributes\WaTemplateParam;

#[DataTableAccess(scopes: [
    "availableInEventAudience", 
    "availableInEmailBlastAudience",
    "availableInWaBlastAudience"
], extend: true)]
#[EmailMergeTags(exclude: ['id', 'created_at', 'updated_at', 'created_by_id', 'updated_by_id', 'profile_picture_id', 'notes'], extend: true)]
#[WaTemplateParam(exclude: ['id', 'created_at', 'updated_at', 'created_by_id', 'updated_by_id', 'profile_picture_id', 'notes'], extend: true)]
class Contact extends BaseContact
{
    public function scopeAvailableInEventAudience(Builder $query, string $eventId)
    {
        return $query->whereNotIn("id", function($query) use($eventId) {
            $query->select("contact_id")
                ->from("event_audiences")
                ->where("event_id", $eventId);
        });
    }

    public function scopeAvailableInEmailBlastAudience(Builder $query, string $emailBlastId)
    {
        return $query->whereNotIn("id", function($query) use($emailBlastId) {
            $query->select("contact_id")
                ->from("email_blast_audiences")
                ->where("email_blast_id", $emailBlastId);
        });
    }

    public function scopeAvailableInWaBlastAudience(Builder $query, string $waBlastId)
    {
        return $query->whereNotIn("id", function($query) use($waBlastId) {
            $query->select("contact_id")
                ->from("wa_blast_audiences")
                ->where("wa_blast_id", $waBlastId);
        });
    }
}