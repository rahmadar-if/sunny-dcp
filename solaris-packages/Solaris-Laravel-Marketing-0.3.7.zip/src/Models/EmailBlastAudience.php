<?php

namespace Solaris\Marketing\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Marketing\Const\EmailBlastAudienceStatusConst;

#[FormAccess()]
#[DataTableAccess()]
#[ExportAccess()]
class EmailBlastAudience extends BaseModel
{
    protected $table = "email_blast_audiences";

    protected static function booted(): void
    {
        parent::booted();

        static::deleted(function ($audience) {
            $emailBlast = Helper::model('email_blast')::find($audience->email_blast_id);
            $emailBlast->total_audience -= 1;
            $emailBlast->save();
        });
    }

    public function scopeBlastable(Builder $query): Builder
    {
        return $query
            ->whereIn($this->qualifyColumn("status_id"), [
                EmailBlastAudienceStatusConst::Pending,
                EmailBlastAudienceStatusConst::SoftBounce
            ])
            ->whereHas('contact', fn($q) => $q->whereNotNull('email')->where('email', '!=', ''));
    }

    public function email_blast(): BelongsTo
    {
        return $this->belongsTo(Helper::model('email_blast'), 'email_blast_id', 'id');
    }
    
    public function contact(): BelongsTo
    {
        return $this->belongsTo(Helper::model('contact'), 'contact_id', 'id');
    }

    public function status(): BelongsTo
    {
        return $this->belongsTo(Helper::model('email_blast_audience_status'), 'status_id', 'id');
    }
}