<?php

namespace Solaris\Marketing\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Solaris\Marketing\Const\CampaignBlastStatusConst;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\FolderAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\LookupAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Traits\Model\HasStageHistory;

#[FormAccess()]
#[DataTableAccess()]
#[LookupAccess()]
#[FolderAccess()]
class EmailBlast extends BaseModel
{
    use HasStageHistory;

    protected $table        = 'email_blasts';
    protected ?string $displayValue = 'title';

    protected function casts(): array
    {
        return array_merge(parent::casts(),
        [
            'sent_at'            => 'datetime',
            'schedule_at'        => 'datetime',
            'completed_at'       => 'datetime',
            'total_audience'     => 'integer',
            'total_pending'      => 'integer',
            'total_progress'     => 'integer',
            'total_failed'       => 'integer',
            'total_success'      => 'integer',
            'total_open'         => 'integer',
            'total_click'        => 'integer',
            'total_unique_open'  => 'integer',
            'total_unique_click' => 'integer',
            'total_unsubscribe'  => 'integer',
            'total_spam'         => 'integer',
        ]);
    }

    protected static function stageHistoryModel(): string
    {
        return Helper::model('email_blast_status_history');
    }

    protected static function stageColumn(): string
    {
        return "status_id";
    }

    public function status(): BelongsTo
    {
        return $this->belongsTo(Helper::model('campaign_blast_status'), 'status_id', 'id');
    }

    public function priority(): BelongsTo
    {
        return $this->belongsTo(Helper::model('activity_priority'), 'priority_id', 'id');
    }

    public function audiences(): HasMany
    {
        return $this->hasMany(Helper::model('email_blast_audience'), 'email_blast_id', 'id');
    }

    public function status_history(): HasMany
    {
        return $this->hasMany(Helper::model('email_blast_history'), 'email_blast_id', 'id');
    }

    public function canAddAudience(): bool
    {
        $blockAddAudience = [CampaignBlastStatusConst::Queued, CampaignBlastStatusConst::Sending, CampaignBlastStatusConst::Scheduled];
        if($this->status_id && in_array($this->status_id, $blockAddAudience)) {
            return false;
        }

        return true;
    }

}