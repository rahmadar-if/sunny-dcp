<?php

namespace Solaris\Marketing\Models;

use Solaris\Core\Models\LookupStage;

class CampaignBlastStatus extends LookupStage
{
    protected $table = 'campaign_blast_statuses';
}
