<?php

namespace Solaris\Marketing\Models;

use Solaris\Core\Models\LookupModel;

class WaTemplateHeaderType extends LookupModel
{
	protected $table = 'wa_template_header_types';
}
