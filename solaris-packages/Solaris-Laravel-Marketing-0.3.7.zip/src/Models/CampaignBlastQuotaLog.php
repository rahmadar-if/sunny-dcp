<?php

namespace Solaris\Marketing\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Facades\Auth;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

#[DataTableAccess()]
class CampaignBlastQuotaLog extends BaseModel
{
	protected $table   = "campaign_blast_quota_logs";
	protected string|array $orderBy = 'created_at';

	protected function casts(): array
	{
		return array_merge(parent::casts(), [
			"book_delta"        => "integer",
			"used_delta"        => "integer",
			"quota_book_after"  => "integer",
			"quota_used_after"  => "integer",
		]);
	}

	public function quota(): BelongsTo
	{
		return $this->belongsTo(CampaignBlastQuota::class, 'quota_id', 'id');
	}

	public function user(): BelongsTo
	{
		return $this->belongsTo(Helper::model('user'), 'created_by_id', 'id');
	}

	public static function record(
		CampaignBlastQuota $quota,
		string $action,
		?string $context,
		int $bookDelta,
		int $usedDelta,
		?string $sourceType = null,
		?string $sourceId = null,
		?string $userId = null): void
	{
		$log = new static();

		$log->quota_id          = $quota->id;
		$log->action            = $action;
		$log->context           = $context;
		$log->book_delta        = $bookDelta;
		$log->used_delta        = $usedDelta;
		$log->quota_book_after  = $quota->quota_book;
		$log->quota_used_after  = $quota->quota_used;
		$log->source_type       = $sourceType;
		$log->source_id         = $sourceId;
		$log->created_by_id     = $userId ?? Auth::id();
		$log->updated_by_id     = $log->created_by_id;

		$log->save();
	}
}
