<?php

namespace Solaris\Marketing\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\BaseCRM\Models\Activity as BaseActivity;
use Solaris\Core\Helpers\Helper;

class Activity extends BaseActivity
{
    public function event() : BelongsTo
    {
        return $this->belongsTo(Helper::model('event'), 'event_id', 'id');
    }

    public function email_blast() : BelongsTo
    {
        return $this->belongsTo(Helper::model('email_blast'), 'email_blast_id', 'id');
    }

    public function wa_blast() : BelongsTo
    {
        return $this->belongsTo(Helper::model('wa_blast'), 'wa_blast_id', 'id');
    }
}