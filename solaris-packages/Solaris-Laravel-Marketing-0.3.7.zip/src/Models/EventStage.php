<?php

namespace Solaris\Marketing\Models;

use Solaris\Core\Models\LookupStage;

class EventStage extends LookupStage
{
    protected $table = 'event_stages';
}
