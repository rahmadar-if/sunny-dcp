<?php

namespace Solaris\Marketing\Models;

use Illuminate\Database\Eloquent\Builder;
use Solaris\Core\Attributes\LookupAccess;
use Solaris\Core\Models\LookupModel;

#[LookupAccess(scopes: ["availableInWaTemplateDetail"], extend: true)]
class WaTemplateLanguage extends LookupModel
{
	protected $table = 'wa_template_languages';
    protected array $prepareColumns = ['id', 'name', 'position', 'code'];

	public function scopeAvailableInWaTemplateDetail(Builder $query, string $waTemplateId)
    {
        return $query->whereNotIn("id", function($query) use($waTemplateId) {
            $query->select("language_id")
                ->from("wa_template_details")
                ->where("wa_template_id", $waTemplateId);
        });
    }
}
