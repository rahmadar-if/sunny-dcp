<?php

namespace Solaris\Marketing\Models;

use Solaris\Core\Models\BaseModel;

class WaBlastWebhook extends BaseModel
{
	protected $table = 'wa_blast_webhooks';
}
