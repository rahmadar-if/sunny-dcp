<?php

namespace Solaris\Marketing\Models;

use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Models\BaseModel;

#[FormAccess()]
#[DataTableAccess()]
class EmailTemplate extends BaseModel
{
    protected $table        = 'email_templates';
    protected ?string $displayValue = 'name';
}