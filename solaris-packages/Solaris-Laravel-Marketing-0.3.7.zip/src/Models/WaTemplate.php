<?php

namespace Solaris\Marketing\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

#[FormAccess()]
#[DataTableAccess()]
class WaTemplate extends BaseModel
{
	protected $table        = 'wa_templates';
	protected ?string $displayValue = 'name';

	public function category(): BelongsTo
	{
		return $this->belongsTo(Helper::model('wa_template_category'), 'category_id');
	}

	public function details(): HasMany
	{
		return $this->hasMany(Helper::model('wa_template_detail'), 'wa_template_id', 'id');
	}
}
