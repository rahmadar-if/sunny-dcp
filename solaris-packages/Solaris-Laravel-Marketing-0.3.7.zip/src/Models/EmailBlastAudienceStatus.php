<?php

namespace Solaris\Marketing\Models;

use Solaris\Core\Models\LookupModel;

class EmailBlastAudienceStatus extends LookupModel
{
    protected $table = 'email_blast_audience_statuses';
}