<?php

namespace Solaris\Marketing\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Marketing\Const\WaBlastAudienceStatusConst;

#[FormAccess()]
#[DataTableAccess()]
#[ExportAccess()]
class WaBlastAudience extends BaseModel
{
	protected $table = "wa_blast_audiences";

	protected static function booted(): void
	{
		parent::booted();

		static::deleted(function ($audience) {
			$waBlast = Helper::model('wa_blast')::find($audience->wa_blast_id);
			$waBlast->total_audience -= 1;
			$waBlast->save();
		});
	}

	public function scopeBlastable(Builder $query, string $phoneColumn): Builder
	{
		return $query
			->where($this->qualifyColumn("status_id"), WaBlastAudienceStatusConst::Pending)
			->whereHas('contact', fn($q) => $q->whereNotNull($phoneColumn)->where($phoneColumn, '!=', ''));
	}

	public function wa_blast(): BelongsTo
	{
		return $this->belongsTo(Helper::model('wa_blast'), 'wa_blast_id', 'id');
	}

	public function contact(): BelongsTo
	{
		return $this->belongsTo(Helper::model('contact'), 'contact_id', 'id');
	}

	public function status(): BelongsTo
	{
		return $this->belongsTo(Helper::model('wa_blast_audience_status'), 'status_id', 'id');
	}
}
