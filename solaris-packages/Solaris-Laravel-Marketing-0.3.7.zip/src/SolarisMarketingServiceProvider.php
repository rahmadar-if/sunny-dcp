<?php

namespace Solaris\Marketing;

use Illuminate\Support\Facades\Route;
use Solaris\Marketing\Console\Commands\CampaignBlastQuotaAutoRenewCommand;
use Spatie\LaravelPackageTools\Package;
use Spatie\LaravelPackageTools\PackageServiceProvider;

class SolarisMarketingServiceProvider extends PackageServiceProvider
{
    public function configurePackage(Package $package): void
    {
        /*
         * This class is a Package Service Provider
         *
         * More info: https://github.com/spatie/laravel-package-tools
         */
        $package
            ->name('marketing')
            ->hasConfigFile(['solaris'])
            ->hasViews('marketing')
            ->hasCommands([CampaignBlastQuotaAutoRenewCommand::class])
            ->discoversMigrations()
            ->runsMigrations();
    }

    public function packageBooted()
    {
        Route::middleware('web')->group(__DIR__ . '/../routes/web.php');
    }
}
