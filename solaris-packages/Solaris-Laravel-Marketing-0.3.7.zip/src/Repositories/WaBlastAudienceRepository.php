<?php

namespace Solaris\Marketing\Repositories;

use Solaris\Core\Helpers\Helper;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\Marketing\Models\WaBlastAudience;

class WaBlastAudienceRepository extends BaseRepository
{
	public function __construct(WaBlastAudience $model)
	{
		parent::__construct($model);
	}

	protected function batchDeleting(array $ids): void
	{
		$waBlastId = $this->model->query()
			->select('wa_blast_id')
			->where("id", $ids[0])
			->first()
			->wa_blast_id;

		$total   = count($ids);
		$waBlast = Helper::model('wa_blast')::find($waBlastId);
		$waBlast->total_audience -= $total;
		$waBlast->total_pending  -= $total;
		$waBlast->save();
	}
}
