<?php

namespace Solaris\Marketing\Repositories;

use Carbon\Carbon;
use Exception;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Interfaces\Model\SolarisModel;
use Solaris\Core\Models\Attachment;
use Solaris\Core\Repositories\AttachmentRepository;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\Marketing\Const\WaBlastAudienceStatusConst;
use Solaris\Marketing\Models\WaBlast;

class WaBlastRepository extends BaseRepository
{
	public function __construct(WaBlast $model)
	{
		parent::__construct($model);
	}

	public function findComplete(string $id, array $columns = []): WaBlast
	{
		$defaultColumns = [
			'title',
			'sent_at',
			'schedule_at',
			'completed_at',
			'total_audience',
			'total_progress',
			'total_pending',
			'total_success',
			'total_fail',
			'total_read',
			'total_replied',
			'status_id',
			'priority_id',
			'error_message',
			'wa_template_detail',
			'template_params',
			'notes'
		];

		$data = $this->model
			->prepared(array_merge($defaultColumns, $columns))
			->where('id', $id)
			->first();

		$data->delivery_rate           = $data->total_audience > 0 ? ($data->total_success / $data->total_audience) * 100 : 0;
		$data->read_rate               = $data->total_success > 0 ? ($data->total_read / $data->total_success) * 100 : 0;
		$data->reply_rate              = $data->total_success > 0 ? ($data->total_replied / $data->total_success) * 100 : 0;
		$data->total_pending_percent   = $data->total_audience > 0 ? ($data->total_pending / $data->total_audience) * 100 : 0;
		$data->total_progress_percent  = $data->total_audience > 0 ? ($data->total_progress / $data->total_audience) * 100 : 0;
		$data->total_fail_percent      = $data->total_audience > 0 ? ($data->total_fail / $data->total_audience) * 100 : 0;
		$data->total_delivered_percent = $data->total_audience > 0 ? ($data->total_success / $data->total_audience) * 100 : 0;
		$data->read_to_reply_rate	   = $data->total_read > 0 ? ($data->total_replied / $data->total_read) * 100 : 0;

		return $data;
	}

	public function addAudience(string $id, bool $isSelectAll, array $selected = [], array $excluded = [], ?array $filters = null): bool
	{
		$userId  = Auth::user()->id;
		$success = false;

		try {
			DB::beginTransaction();

			$waBlast = $this->find($id);
			if (!$waBlast->canAddAudience()) {
				throw new Exception("Cannot add audience in this status");
			}

			if ($isSelectAll) {
				$executionTime = now();
				$query = Helper::model('contact')::availableInWaBlastAudience($id)
					->select('id')
					->when(!empty($excluded), fn($query) => $query->whereNotIn('id', $excluded))
					->when(
						!empty($filters),
						fn($q) => $q
							->when(isset($filters["search"]) && !empty($filters["search"]),
								fn($q) => $q->search($filters["search"], ["name", "primary_mobile_phone", "email"]))
							->when(isset($filters["preFilters"]) && !empty($filters["preFilters"]),
								fn($q) => $q->filter($filters["preFilters"]))
							->when(isset($filters["filters"]) && !empty($filters["filters"]),
								fn($q) => $q->filter($filters["filters"]))
					)
					->where('created_at', '<', $executionTime)
					->orderBy('created_at', 'desc');

				$count = $query->count();
				if ($count == 0) {
					throw new Exception("Please select the audience");
				}

				do {
					$data = $query->limit(1000)->pluck('id')->all();
					if (empty($data)) {
						break;
					}

					$this->insertAudience($id, $data, $userId);
				} while (true);
			} else {
				if (count($selected) == 0) {
					throw new Exception("Please select the audience");
				}

				foreach (array_chunk($selected, 1000) as $chunk) {
					$this->insertAudience($id, $chunk, $userId);
				}
			}

			$waBlast->total_audience = $waBlast->audiences()->count();
			$waBlast->total_pending  = $waBlast->total_audience;
			$waBlast->save();

			$success = true;

			DB::commit();
		} catch (\Exception $e) {
			DB::rollBack();
			throw $e;
		}

		return $success;
	}

	protected function insertAudience(string $waBlastId, array $contactIds, string $createdById): void
	{
		$now       = Carbon::now();
		$batchData = [];

		foreach ($contactIds as $contactId) {
			$batchData[] = [
				'id'            => (string)Str::uuid7(),
				'created_at'    => $now,
				'updated_at'    => $now,
				'created_by_id' => $createdById,
				'updated_by_id' => $createdById,
				'wa_blast_id'   => $waBlastId,
				'contact_id'    => $contactId,
				'status_id'     => WaBlastAudienceStatusConst::Pending
			];
		}

		DB::table('wa_blast_audiences')->insert($batchData);
	}

	protected function deleted(Model|SolarisModel $record): void
	{
		$attachmentRepo = new AttachmentRepository(new Attachment());
		$attachmentRepo->deleteRelation($this->getModel()->getTable(), $record->id);
	}

	protected function batchDeleted(array $ids): void
	{
		$attachmentRepo = new AttachmentRepository(new Attachment());
		$attachmentRepo->batchDelete(
			user : null,
			model: $attachmentRepo->getModel()
				->query()
				->where("table_name", $this->getModel()->getTable())
				->whereIn("record_id", $ids)
		);
	}
}
