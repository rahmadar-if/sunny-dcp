<?php

namespace Solaris\Marketing\Repositories;

use Solaris\Core\Helpers\Helper;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\Marketing\Models\EmailBlastAudience;

class EmailBlastAudienceRepository extends BaseRepository
{
    public function __construct(EmailBlastAudience $model)
    {
        parent::__construct($model);
    }

    protected function batchDeleting(array $ids): void
    {
        $emailBlastId = $this->model->query()
            ->select('email_blast_id')
            ->where("id", $ids[0])
            ->first()
            ->email_blast_id;

        $total = count($ids);
        $emailBlast = Helper::model('email_blast')::find($emailBlastId);
        $emailBlast->total_audience -= $total;
        $emailBlast->total_pending  -= $total;
        $emailBlast->save();
    }
}
