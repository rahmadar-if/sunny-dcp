<?php

namespace Solaris\Marketing\Repositories;

use Carbon\Carbon;
use Exception;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Solaris\Marketing\Const\EmailBlastAudienceStatusConst;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Interfaces\Model\SolarisModel;
use Solaris\Core\Models\Attachment;
use Solaris\Core\Repositories\AttachmentRepository;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\Marketing\Const\CampaignBlastStatusConst;
use Solaris\Marketing\Models\EmailBlast;

class EmailBlastRepository extends BaseRepository
{
    public function __construct(EmailBlast $model)
    {
        parent::__construct($model);
    }
    
    public function findComplete(string $id, array $columns = []): EmailBlast
    {
        $defaultColumns = [
            'title',
            'subject',
            'sender_name',
            'sender_email',
            'sent_at',
            'schedule_at',
            'completed_at',
            'total_audience',
            'total_success',
            'total_fail',
            'total_open',
            'total_click',
            'total_unsubscribe',
            'total_spam',
            'total_pending',
            'total_progress',
            'total_unique_open',
            'total_unique_click',
            'status_id',
            'priority_id',
            'error_message',
            'body',
            'notes'
        ];

        $data = $this->model
            ->prepared(array_merge($defaultColumns, $columns))
            ->where('id', $id)
            ->first();

        $data->delivery_rate             = $data->total_audience > 0 ? ($data->total_success / $data->total_audience) * 100 : 0;
        $data->open_rate                 = $data->total_success > 0 ? ($data->total_unique_open / $data->total_success) * 100 : 0;
        $data->click_rate                = $data->total_success > 0 ? ($data->total_unique_click / $data->total_success) * 100 : 0;
        $data->total_pending_percent     = $data->total_audience > 0 ? ($data->total_pending / $data->total_audience) * 100 : 0;
        $data->total_progress_percent    = $data->total_audience > 0 ? ($data->total_progress / $data->total_audience) * 100 : 0;
        $data->total_fail_percent        = $data->total_audience > 0 ? ($data->total_fail / $data->total_audience) * 100 : 0;
        $data->total_delivered_percent   = $data->total_audience > 0 ? ($data->total_success / $data->total_audience) * 100 : 0;
        $data->click_to_open_rate        = $data->total_unique_open > 0 ? ($data->total_unique_click / $data->total_unique_open) * 100 : 0;
        $data->total_spam_percent        = $data->total_success > 0 ? ($data->total_spam / $data->total_success) * 100 : 0;
        $data->total_unsubscribe_percent = $data->total_success > 0 ? ($data->total_unsubscribe / $data->total_success) * 100 : 0;
        $data->avg_open                  = $data->total_unique_open > 0 ? $data->total_open / $data->total_unique_open : 0;
        $data->avg_click                 = $data->total_unique_click > 0 ? $data->total_click / $data->total_unique_click : 0;

        return $data;
    }

    protected function creating(array $data): array
    {
        if(isset($data['sender_email'])) {
            $data['sender_email'] = $this->compileSenderEmail($data['sender_email']);
        }

        $data['status_id'] = CampaignBlastStatusConst::Draft;

        return $data;
    }

    protected function updating(Model|SolarisModel $record, array $data): array
    {
        if(isset($data['sender_email'])) {
            $data['sender_email'] = $this->compileSenderEmail($data['sender_email']);
        }
        
        return [$record, $data];
    }

    protected function compileSenderEmail(string $senderEmail): string
    {
        $provider = Helper::config("email_blast.default");
        $domain   = Helper::config("email_blast.providers.{$provider}.domain");
        if(!$domain) {
            return $senderEmail;
        }

        return explode("@", $senderEmail)[0]."@{$domain}";
    }

    public function addAudience(string $id, bool $isSelectAll, array $selected = [], array $excluded = [], ?array $filters = null): bool
    {
        $userId  = Auth::user()->id;
        $success = false;

        try {
            DB::beginTransaction();

            $emailBlast = $this->find($id);
            if(!$emailBlast->canAddAudience()) {
                throw new Exception("Cannot add audience in this status");
            }

            if($isSelectAll) {
                $executionTime = now();
                $query = Helper::model('contact')::availableInEmailBlastAudience($id)
                    ->select('id')
                    ->when(!empty($excluded), fn($query) => $query->whereNotIn('id', $excluded))
                    ->when(
                        !empty($filters), 
                        fn($q) => $q
                            ->when(isset($filters["search"]) && !empty($filters["search"]), 
                                fn($q) => $q->search($filters["search"], ["name", "primary_mobile_phone", "email"]))
                            ->when(isset($filters["preFilters"]) && !empty($filters["preFilters"]), 
                                fn($q) => $q->filter($filters["preFilters"]))
                            ->when(isset($filters["filters"]) && !empty($filters["filters"]), 
                                fn($q) => $q->filter($filters["filters"]))
                    )
                    ->where('created_at', '<', $executionTime)
                    ->orderBy('created_at', 'desc');
                
                $count = $query->count();
                if($count == 0) {
                    throw new Exception("Please select the audience");
                }

                do {
                    $data = $query->limit(1000)->pluck('id')->all();
                    if (empty($data)) {
                        break;
                    }

                    $this->insertAudience($id, $data, $userId);
                } while (true);
            } else {
                if(count($selected) == 0) {
                    throw new Exception("Please select the audience");
                }

                foreach (array_chunk($selected, 1000) as $chunk) {
                    $this->insertAudience($id, $chunk, $userId);
                }
            }

            $emailBlast->total_audience = $emailBlast->audiences()->count();
            $emailBlast->total_pending  = $emailBlast->total_audience;
            $emailBlast->save();

            $success = true;

            DB::commit();
        } catch (\Exception $e) {
            DB::rollBack();

            throw $e;
        }

        return $success;
    }

    protected function insertAudience(string $emailBlastId, array $contactIds, string $createdById): void
    {
        $now = Carbon::now();
        $batchData = [];
        foreach ($contactIds as $contactId) {
            $batchData[] = [
                'id'             => (string)Str::uuid7(),
                'created_at'     => $now,
                'updated_at'     => $now,
                'created_by_id'  => $createdById,
                'updated_by_id'  => $createdById,
                'email_blast_id' => $emailBlastId,
                'contact_id'     => $contactId,
                'status_id'      => EmailBlastAudienceStatusConst::Pending
            ];
        }

        DB::table('email_blast_audiences')->insert($batchData);
    }

    protected function deleted(Model|SolarisModel $record): void
    {
        $attachmentRepo = new AttachmentRepository(new Attachment());
        $attachmentRepo->deleteRelation($this->getModel()->getTable(), $record->id);
    }

    protected function batchDeleted(array $ids): void
    {
        $attachmentRepo = new AttachmentRepository(new Attachment());
        $attachmentRepo->batchDelete(
            user: null, 
            model: $attachmentRepo->getModel()
                ->query()
                ->where("table_name", $this->getModel()->getTable())
                ->whereIn("record_id", $ids)
        );
    }
}
