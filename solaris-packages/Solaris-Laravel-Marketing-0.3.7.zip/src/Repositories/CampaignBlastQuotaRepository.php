<?php

namespace Solaris\Marketing\Repositories;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Interfaces\Model\SolarisModel;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\Marketing\Models\CampaignBlastQuota;

class CampaignBlastQuotaRepository extends BaseRepository
{
	public function __construct(CampaignBlastQuota $model)
	{
		parent::__construct($model);
	}

	public function disableAutoRenew(string $id): void
	{
		$quota = $this->find($id);

		if (!$quota->auto_renew || Carbon::now()->gt($quota->expired_at)) {
			throw new \Exception('Action not allowed.');
		}

		$quota->auto_renew = false;
		$quota->save();
	}

	protected function creating(array $data): array
	{
		$effectiveAt        = Carbon::parse($data['effective_at']);
		$data['expired_at'] = $this->calculateExpiredAt($effectiveAt, $data['period'], $data['auto_renew_days'] ?? null);

		return $data;
	}

	protected function deleting(Model|SolarisModel $record): void
	{
		if ($record->quota_book > 0) {
			throw new \Exception('Cannot delete quota with active bookings.');
		}

		if ($record->quota_used > 0) {
			throw new \Exception('Cannot delete quota that has already been used.');
		}
	}

	private function calculateExpiredAt(Carbon $effectiveAt, string $period, ?int $autoRenewDays): Carbon
	{
		return match ($period) {
			'daily'   => $effectiveAt->copy()->addDay(),
			'weekly'  => $effectiveAt->copy()->addWeek(),
			'monthly' => $effectiveAt->copy()->addMonth(),
			'yearly'  => $effectiveAt->copy()->addYear(),
			'custom'  => $effectiveAt->copy()->addDays($autoRenewDays),
		};
	}
}
