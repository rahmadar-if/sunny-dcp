<?php

namespace Solaris\Marketing\Repositories;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Solaris\Core\Interfaces\Model\SolarisModel;
use Solaris\Core\Models\Attachment;
use Solaris\Core\Repositories\AttachmentRepository;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\Marketing\Const\WaTemplateStatusConst;
use Solaris\Marketing\Const\WaTemplateSubTypeConst;
use Solaris\Marketing\Models\WaTemplate;

class WaTemplateRepository extends BaseRepository
{
	public function __construct(WaTemplate $model)
	{
		parent::__construct($model);
	}

	protected function creating(array $data): array
	{
		unset($data['languages']);

		return $data;
	}

	protected function created(Model|SolarisModel $record, array $data, array $rawData): void
	{
		$userId    = Auth::user()->id;
		$now 	   = Carbon::now();
		$languages = array_map(function($language) use($record, $userId, $now) {
			return [
				'id' 			 => Str::uuid7(),
				'created_by_id'  => $userId,
				'updated_by_id'	 => $userId,
				'created_at'	 => $now,
				'updated_at'	 => $now,
				'wa_template_id' => $record->id,
				'language_id'    => $language,
				'sub_type_id'    => WaTemplateSubTypeConst::Regular,
				'status_id'      => WaTemplateStatusConst::Draft
			];
		}, $rawData['languages']);

		DB::table('wa_template_details')->insert($languages);
	}

	protected function deleting(Model|SolarisModel $record): void
	{
		$details = $record->details()->select("id")->get();
		if($details->isEmpty()) {
			return;
		}

		$attachmentRepo = new AttachmentRepository(new Attachment());
		foreach ($details as $detail) {
			$attachmentRepo->deleteRelation('wa_template_details', $detail->id);
		}
	}

	protected function batchDeleting(array $ids): void
	{
		$attachmentRepo = new AttachmentRepository(new Attachment());
		$attachmentRepo->batchDelete(
			user : null,
			model: $attachmentRepo->getModel()
				->query()
				->where("table_name", 'wa_template_details')
				->whereIn(
					"record_id", 
					DB::table($this->getModel()->getTable())
						->select('id')
						->whereIn('wa_template_id', $ids)
				)
		);
	}
}
