<?php

namespace Solaris\Marketing\Repositories;

use Carbon\Carbon;
use Exception;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Interfaces\Model\SolarisModel;
use Solaris\Core\Models\Attachment;
use Solaris\Core\Repositories\AttachmentRepository;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\Marketing\Models\Event;

class EventRepository extends BaseRepository
{
    public function __construct(Event $model)
    {
        parent::__construct($model);
    }
    
    public function findComplete(string $id, array $columns = []): Event
    {
        $defaultColumns = [
            'stage_id', 
            'status_id', 
            'type_id', 
            'start_date', 
            'end_date', 
            'goal', 
            'budget_cost', 
            'actual_cost',
            'created_by_id'
        ];

        $data = $this->model
            ->prepared(array_merge($defaultColumns, $columns))
            ->where('id', $id)
            ->first();

        return $data;
    }

    public function addAudience(string $id, bool $isSelectAll, array $selected = [], array $excluded = [], ?array $filters = null): bool
    {
        $userId  = Auth::user()->id;
        $success = false;
        try {
            DB::beginTransaction();

            if($isSelectAll) {
                $executionTime = now();
                $query = Helper::model('contact')::availableInEventAudience($id)
                    ->select('id')
                    ->when(!empty($excluded), fn($query) => $query->whereNotIn('id', $excluded))
                    ->when(
                        !empty($filters), 
                        fn($q) => $q
                            ->when(isset($filters["search"]) && !empty($filters["search"]), 
                                fn($q) => $q->search($filters["search"], ["name", "primary_mobile_phone", "email"]))
                            ->when(isset($filters["preFilters"]) && !empty($filters["preFilters"]), 
                                fn($q) => $q->filter($filters["preFilters"]))
                            ->when(isset($filters["filters"]) && !empty($filters["filters"]), 
                                fn($q) => $q->filter($filters["filters"]))
                    )
                    ->where('created_at', '<', $executionTime)
                    ->orderBy('created_at', 'desc');
                
                $count = $query->count();
                if($count == 0) {
                    throw new Exception("Please select the audience");
                }

                do {
                    $data = $query->limit(1000)->pluck('id')->all();
                    if (empty($data)) {
                        break;
                    }

                    $this->insertAudience($id, $data, $userId);
                } while (true);
            } else {
                if(count($selected) == 0) {
                    throw new Exception("Please select the audience");
                }

                foreach (array_chunk($selected, 1000) as $chunk) {
                    $this->insertAudience($id, $chunk, $userId);
                }
            }

            $success = true;

            DB::commit();
        } catch (\Exception $e) {
            DB::rollBack();

            throw $e;
        }

        return $success;
    }

    protected function insertAudience(string $eventId, array $contactIds, string $createdById): void
    {
        $now = Carbon::now();
        $batchData = [];
        foreach ($contactIds as $contactId) {
            $batchData[] = [
                'id'            => (string)Str::uuid7(),
                'created_at'    => $now,
                'updated_at'    => $now,
                'created_by_id' => $createdById,
                'updated_by_id' => $createdById,
                'event_id'      => $eventId,
                'contact_id'    => $contactId,
            ];
        }

        DB::table('event_audiences')->insert($batchData);
    }

    protected function deleted(Model|SolarisModel $record): void
    {
        $attachmentRepo = new AttachmentRepository(new Attachment());
        $attachmentRepo->deleteRelation($this->getModel()->getTable(), $record->id);
    }

    protected function batchDeleted(array $ids): void
    {
        $attachmentRepo = new AttachmentRepository(new Attachment());
        $attachmentRepo->batchDelete(
            user: null, 
            model: $attachmentRepo->getModel()
                ->query()
                ->where("table_name", $this->getModel()->getTable())
                ->whereIn("record_id", $ids)
        );
    }
}
