<?php

namespace Solaris\Marketing\Repositories;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;
use Solaris\Core\Interfaces\Model\SolarisModel;
use Solaris\Core\Models\Attachment;
use Solaris\Core\Repositories\AttachmentRepository;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\Marketing\Const\WaTemplateStatusConst;
use Solaris\Marketing\Models\WaTemplateDetail;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class WaTemplateDetailRepository extends BaseRepository
{
	public function __construct(WaTemplateDetail $model)
	{
		parent::__construct($model);
	}

	protected function creating(array $data): array
	{
		$data['status_id'] = WaTemplateStatusConst::Draft;
		return $data;
	}

	protected function deleted(Model|SolarisModel $record): void
	{
		$attachmentRepo = new AttachmentRepository(new Attachment());
		$attachmentRepo->deleteRelation($this->getModel()->getTable(), $record->id);
	}

	protected function batchDeleted(array $ids): void
	{
		$attachmentRepo = new AttachmentRepository(new Attachment());
		$attachmentRepo->batchDelete(
			user : null,
			model: $attachmentRepo->getModel()
				->query()
				->where("table_name", $this->getModel()->getTable())
				->whereIn("record_id", $ids)
		);
	}

	public function updateMedia(array $data): Model
	{
		$template = $this->find($data['id']);

		// Collect all attachment IDs in one shot
		$attachmentIds = [];
		if (!empty($data['header_attachment_id'])) {
			$attachmentIds[] = $data['header_attachment_id'];
		}
		$cardAttachments = !empty($data['card_attachments']) ? $data['card_attachments'] : [];
		foreach ($cardAttachments as $item) {
			$attachmentIds[] = $item['attachment_id'];
		}

		$getUrl = fn(string $id): string => route('marketing.wa-template.media', ['id' => $id]);

		if (!empty($data['header_attachment_id'])) {
			$template->header_content = $getUrl($data['header_attachment_id']);
		}

		if (!empty($data['card_attachments'])) {
			$cardUrlMap = [];
			foreach ($data['card_attachments'] as $item) {
				$cardUrlMap[$item['card_id']] = $getUrl($item['attachment_id']);
			}

			$existingCards = json_decode($template->cards ?? '[]', true) ?? [];
			$cards         = array_map(function ($card) use($cardUrlMap) {
				$cardId = $card['id'] ?? null;
				if ($cardId !== null && isset($cardUrlMap[$cardId])) {
					$card['header_content'] = $cardUrlMap[$cardId];
				}

				return $card;
			}, $existingCards);

			$template->cards = json_encode($cards);
		}

		$template->save();

		return $template;
	}

	public function previewMedia(string $id): BinaryFileResponse
	{
		$attachment = Attachment::where('id', $id)
			->where('table_name', 'wa_template_details')
			->firstOrFail();

		$path = $attachment->path;
		if (!Storage::disk('public')->exists($path)) {
			abort(404);
		}

		$mimeType    = Storage::disk('public')->mimeType($path);
		$storagePath = Storage::disk('public')->path($path);

		return response()->file($storagePath, ['Content-Type' => $mimeType]);
	}
}
