<?php

namespace Solaris\Marketing\Facades;

use Illuminate\Support\Facades\Facade;

/**
 * @see \VendorName\Skeleton\Skeleton
 */
class SolarisMarketing extends Facade
{
    protected static function getFacadeAccessor(): string
    {
        return \Solaris\Marketing\SolarisMarketing::class;
    }
}
