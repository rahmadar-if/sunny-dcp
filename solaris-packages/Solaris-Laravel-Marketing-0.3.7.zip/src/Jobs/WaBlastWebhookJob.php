<?php

namespace Solaris\Marketing\Jobs;

use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Solaris\Marketing\Models\WaBlastWebhook;

class WaBlastWebhookJob implements ShouldQueue
{
	use Queueable;

	public function __construct(
		protected string $rawPayload,
		protected string $messageId,
		protected string $eventType,
		protected ?string $message       = null,
		protected ?string $buttonPayload = null
	) {
		$this->onQueue('wa-blast-webhook');
	}

	public function handle(): void
	{
		WaBlastWebhook::create([
			"raw"            => $this->rawPayload,
			"message_id"     => $this->messageId,
			"message"        => $this->message,
			"event_type"     => $this->eventType,
			"button_payload" => $this->buttonPayload
		]);
	}
}
