<?php

namespace Solaris\Marketing\Jobs;

use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Support\Facades\Log;
use Solaris\Marketing\Services\WhatsApp\WhatsAppWebhookProcessor;
use Throwable;

class WaBlastWebhookProcessJob implements ShouldQueue
{
	use Queueable;

	public function __construct(protected string $driver)
	{
		$this->onQueue('wa-blast-webhook');
	}

	public function handle(): void
	{
		(new WhatsAppWebhookProcessor($this->driver))->process();
	}

	public function failed(?Throwable $exception): void
	{
		Log::error("WaBlastWebhookProcessJob fail", [
			'message'   => $exception?->getMessage(),
			'exception' => $exception
		]);
	}
}
