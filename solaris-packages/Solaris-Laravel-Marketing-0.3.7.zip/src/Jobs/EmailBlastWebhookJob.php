<?php

namespace Solaris\Marketing\Jobs;

use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Solaris\Marketing\Models\EmailBlastWebhook;

class EmailBlastWebhookJob implements ShouldQueue
{
    use Queueable;

    public function __construct(
        protected string $rawPayload, 
        protected string $messageId, 
        protected string $eventType,
        protected ?string $message = null
    ) 
    {
        $this->onQueue('email-blast-webhook');
    }

    public function handle(): void
    {
        EmailBlastWebhook::create([
            "raw"        => $this->rawPayload,
            "message_id" => $this->messageId,
            "message"    => $this->message,
            "event_type" => $this->eventType
        ]);
    }
}