<?php

namespace Solaris\Marketing\Jobs;

use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Support\Facades\Mail;

class SendTestEmailJob implements ShouldQueue
{
	use Queueable;

	public function __construct(
		protected string $email,
		protected string $subject,
		protected string $html
	) {}

	public function handle(): void
	{
		Mail::html($this->html, function ($message) {
			$message->to($this->email)
					->subject($this->subject);
		});
	}
}
