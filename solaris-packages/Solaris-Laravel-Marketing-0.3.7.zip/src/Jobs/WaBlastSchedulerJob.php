<?php

namespace Solaris\Marketing\Jobs;

use Carbon\Carbon;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Solaris\Marketing\Const\CampaignBlastStatusConst;
use Solaris\Core\Helpers\Helper;
use Solaris\Marketing\Services\WhatsApp\WaBlastService;

class WaBlastSchedulerJob implements ShouldQueue
{
	use Queueable;

	public function __construct(protected string $dateTime)
	{
		$this->onQueue('wa-blast-schedule');
	}

	public function handle(): void
	{
		$query = Helper::model("wa_blast")::select("wa_blasts.*")
			->where("status_id", CampaignBlastStatusConst::Scheduled)
			->leftJoin('activity_priorities', 'activity_priorities.id', '=', 'wa_blasts.priority_id')
			->where("schedule_at", $this->dateTime)
			->orderBy("activity_priorities.position")
			->orderBy("total_audience")
			->orderBy("wa_blasts.created_at");

		$count = $query->count();
		if ($count == 0) {
			return;
		}

		$data = $query->limit(Helper::config("wa_blast.daily_limit"))->get();

		foreach ($data as $campaign) {
			$campaign->status_id     = CampaignBlastStatusConst::Queued;
			$campaign->queue_at      = Carbon::now();
			$campaign->error_message = null;
			$campaign->save();

			WaBlastJob::dispatch(
				WaBlastService::getDriver(Helper::config('wa_blast.default')),
				$campaign,
				Helper::model('user')::find($campaign->updated_by_id)
			);
		}
	}
}
