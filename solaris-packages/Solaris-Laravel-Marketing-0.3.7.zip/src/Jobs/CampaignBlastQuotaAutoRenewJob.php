<?php

namespace Solaris\Marketing\Jobs;

use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Solaris\Marketing\Services\CampaignBlastQuotaService;

class CampaignBlastQuotaAutoRenewJob implements ShouldQueue
{
	use Queueable;

	public function __construct()
	{
		$this->onQueue('default');
	}

	public function handle(): void
	{
		CampaignBlastQuotaService::autoRenew();
	}
}
