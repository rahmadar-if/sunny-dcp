<?php

namespace Solaris\Marketing\Jobs;

use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Support\Facades\Log;
use Solaris\Marketing\Services\Email\EmailWebhookProcessor;
use Throwable;

class EmailBlastWebhookProcessJob implements ShouldQueue
{
	use Queueable;

	public function __construct(protected string $driver)
	{
		$this->onQueue('email-blast-webhook');
	}

	public function handle(): void
	{
		(new EmailWebhookProcessor($this->driver))->process();
	}

	public function failed(?Throwable $exception): void
	{
		Log::error("EmailBlastWebhookProcessJob fail", [
			'message'   => $exception?->getMessage(),
			'exception' => $exception
		]);
	}
}
