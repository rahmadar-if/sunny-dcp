<?php

namespace Solaris\Marketing\Jobs;

use Carbon\Carbon;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Solaris\Marketing\Const\CampaignBlastStatusConst;
use Solaris\Marketing\Services\Email\EmailBlastService;
use Solaris\Core\Helpers\Helper;

class EmailBlastSchedulerJob implements ShouldQueue
{
    use Queueable;

    public function __construct(protected string $dateTime)
    {
        $this->onQueue('email-blast-schedule');
    }

    public function handle(): void
    {
        $query = Helper::model("email_blast")::select("email_blasts.*")
            ->where("status_id", CampaignBlastStatusConst::Scheduled)
            ->leftJoin('activity_priorities', 'activity_priorities.id', '=', 'email_blasts.priority_id')
            ->where("schedule_at", $this->dateTime)
            ->orderBy("activity_priorities.position")
            ->orderBy("total_audience")
            ->orderBy("email_blasts.created_at");

        $count = $query->count();
        if($count == 0) {
            return;
        }

        $data = $query->limit(Helper::config("email_blast.daily_limit"))->get();

        foreach ($data as $campaign) {
            $campaign->status_id     = CampaignBlastStatusConst::Queued;
            $campaign->queue_at      = Carbon::now();
            $campaign->error_message = null;
            $campaign->save();

            EmailBlastJob::dispatch(EmailBlastService::getDriver(Helper::config('email_blast.default')), $campaign, Helper::model('user')::find($campaign->updated_by_id));
        }
    }
}