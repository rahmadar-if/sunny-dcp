<?php

namespace Solaris\Marketing\Jobs;

use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Support\Facades\Log;
use Solaris\Core\Helpers\Helper;
use Solaris\Marketing\Const\CampaignBlastQuotaContextConst;
use Solaris\Marketing\Const\CampaignBlastStatusConst;
use Solaris\Marketing\Models\WaBlast;
use Solaris\Marketing\Services\CampaignBlastQuotaService;
use Throwable;

class WaBlastJob implements ShouldQueue
{
	use Queueable;

	public $timeout = 0;

	public function __construct(
		protected string $driver,
		protected WaBlast $campaign,
		protected Model $user
	) {
		$this->onQueue('wa-blast');
	}

	public function handle(): void
	{
		$instance = ($this->driver)::forBlast($this->campaign, $this->user);
		$instance->blast();
	}

	public function failed(?Throwable $exception): void
	{
		$leftover = array_filter(json_decode($this->campaign->quotas ?? '[]', true) ?? [], fn ($amount) => $amount > 0);

		if (!empty($leftover)) {
			try {
				CampaignBlastQuotaService::cancel(
					quotas    : $leftover,
					context   : CampaignBlastQuotaContextConst::JobFailed,
					sourceType: Helper::model("wa_blast"),
					sourceId  : $this->campaign->id,
					userId    : $this->user?->id
				);
			} catch (\Throwable $e) {
				Log::error("WaBlastJob failed(): quota cancel failed", [
					'campaign_id' => $this->campaign->id,
					'quotas'      => $leftover,
					'message'     => $e->getMessage(),
				]);
			}
		}

		$this->campaign->status_id     = CampaignBlastStatusConst::Failed;
		$this->campaign->error_message = $exception->getMessage();
		$this->campaign->quotas        = null;
		$this->campaign->save();

		$this->user->sendInAppNotification(
			title  : "WhatsApp Blast '" . $this->campaign->title . "' is error",
			message: $exception->getMessage(),
			url    : route("marketing.wa-blast", ["id" => $this->campaign->id])
		);
	}
}
