<?php

namespace Solaris\Marketing;

class SolarisMarketing {}
