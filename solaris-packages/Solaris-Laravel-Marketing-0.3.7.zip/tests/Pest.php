<?php

use Solaris\Marketing\Tests\TestCase;

uses(TestCase::class)->in(__DIR__);
