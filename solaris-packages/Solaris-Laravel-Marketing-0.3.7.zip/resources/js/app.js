import SolarUI from "@core-js/solaris/solar/solar-ui"
import StripoEditor from "./solaris/stripo-editor"
import WhatsAppPreview from "./solaris/whatsapp-preview"

SolarUI.register('div[solar-ui="stripo-editor"]', StripoEditor)
SolarUI.register('div[solar-ui="whatsapp-preview"]', WhatsAppPreview)