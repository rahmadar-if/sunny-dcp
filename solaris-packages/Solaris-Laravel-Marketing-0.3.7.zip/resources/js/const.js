const EventType = {
    Seminar   : "698a5f68-551a-4ce3-9947-9b501ca2444c",
    Exhibition: "9269653c-f0a9-4009-9cc3-88805795c3f0",
    Promotion : "a6b4e1fd-6d6a-4fb4-8659-9723e02e2d0d",
    Tutorial  : "e726a651-e869-46c4-bee1-b869e51233ad",
    Webinar   : "9af948f7-31fd-4a1b-a816-47865cc0d636",
}

const EventStatus = {
    InProgress: "954960c6-d6ae-453c-8d72-41a2f79e3df3",
    Planned   : "e8868cb0-3450-44e7-92ab-fed5dab90051",
    Completed : "f31b54e5-b32b-4b6d-84e9-02beef44f3e6",
    Canceled  : "48c42636-dfb9-4f55-8345-f4fa902b1d21",
}

const CampaignBlastType = {
    Email   : "019bb575-ce3b-7fe4-a6da-06d34f857327",
    WhatsApp: "019bb575-ce3b-73d2-a9eb-13c35f9b3fd3"
}

const CampaignBlastStatus = {
    Draft    : "17cd3914-0116-4aae-9e49-2d0d6aee84b1",
    Scheduled: "fe6e96a5-fc08-4ae1-b63b-305c9a042e2a",
    Queued   : "019bbc6c-3183-79be-b7fd-c34235cbdc3f",
    Sending  : "246eb45c-8fd0-4492-b1b0-c1f1d1277174",
    Completed: "3d25c459-ee8b-4317-b47a-ab9745303634",
    Canceled : "c0cf4e3b-949c-4582-8c0c-25f4b3671650",
    Failed   : "11a8c68a-1217-4698-96ce-48ed5418ee53",
}

const EmailBlastAudienceStatus = {
    Pending   : "019bd922-451e-76bd-a7c8-9fa412877886",
    Progress  : "019bd920-0288-7989-ac1c-295318f6d137",
    Delivered : "019bd920-0288-7c95-b6e0-3c80ede61536",
    SoftBounce: "019bd920-0288-7974-b629-1bb667de3774",
    HardBounce: "019bd920-0288-7edb-9114-ca3a2fc17ea1",
    Failed    : "019bd98a-3e0b-7da2-9ab4-813de42b9ef7",
}

const WaBlastAudienceStatus = {
    Pending : "019d65ff-c0da-7031-86b4-cecb26544691",
    Progress: "019d65ff-c0da-7af3-b9bb-9d4b5adb3084",
    Sent    : "019d65ff-c0da-77bb-9e39-995fec256ff7",
    Read    : "019d65ff-c0da-7f27-a7ce-b24b4f4996a7",
    Failed  : "019d65ff-c0da-79e8-95b9-9089c1f1b216",
}

const WaTemplateCategory = {
    Marketing     : "019d65fd-cbba-79b3-9bc8-71e7e1436fdf",
    Utility       : "019d65fd-cbba-7acb-9afa-bde5a2614d86",
    Authentication: "019d65fd-cbba-731f-bbfa-1e05a27965ba",
}

const WaTemplateStatus = {
    Draft   : "019d65fd-cbba-797a-9420-03b27dd53fe0",
    Pending : "019d65fd-cbba-753d-9e18-3611dd5c4720",
    Approved: "019d65fd-cbba-7d58-b087-1fb1b3c8eb40",
    Rejected: "019d65fd-cbba-7a2c-85b3-f74686d11cf2",
    Paused  : "019d65fd-cbba-7ddf-b759-3bb189124cad",
    Disabled: "019d65fd-cbba-7f7e-a050-f2120071a94a",
}

const WaTemplateSubType = {
    Regular : "019d65fd-cbba-76d3-a3ac-5304fc4ee3bc",
    Carousel: "019d65fd-cbba-707d-aefa-e42c3412e9c3",
}

const WaTemplateHeaderType = {
    Text    : "019d65fd-cbba-7e73-a442-060631603e6b",
    Image   : "019d65fd-cbba-7098-a80f-3b6f28092ec2",
    Video   : "019d65fd-cbba-7924-92ca-8c1a79026711",
    Document: "019d65fd-cbba-7305-b961-d6ec3bff88cb",
}

const WaTemplateLanguage = {
    English   : "019d65fd-cbba-760e-aa96-e67c08037ff9",
    Indonesian: "019d65fd-cbba-7599-be78-f1dec780ba95",
}

const WaTemplateAuthBody = {
    [WaTemplateLanguage.English]   : "*{{1}}* is your verification code.",
    [WaTemplateLanguage.Indonesian]: "*{{1}}* adalah kode verifikasi Anda.",
}

export {
    EventType,
    EventStatus,
    CampaignBlastType,
    CampaignBlastStatus,
    EmailBlastAudienceStatus,
    WaBlastAudienceStatus,
    WaTemplateCategory,
    WaTemplateStatus,
    WaTemplateSubType,
    WaTemplateHeaderType,
    WaTemplateLanguage,
    WaTemplateAuthBody,
}
