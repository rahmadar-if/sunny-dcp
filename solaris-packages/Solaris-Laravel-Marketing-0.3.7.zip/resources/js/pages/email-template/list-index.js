import EmailTemplateListPage from "./list"

new EmailTemplateListPage("email-template")