import SolarListPage from "@core-js/solaris/solar/solar-list-page";

export default class EmailTemplateListPage extends SolarListPage {
    init() {
        this.columnRender("name", this.nameColumnRender.bind(this))
        this.columnCreated("name", this.nameColumnCreated.bind(this))
    }

    async new() {
        window.open(`${BASE_URL}/marketing/email-template/editor`, '_blank');
    }

    openEditPage(id) {
        window.open(`${BASE_URL}/marketing/email-template/editor/${id}`, '_blank');
    }

    async edit(row, data) {
        this.openEditPage(data.id)
    }

    rowDoubleClick(row, data) {
        this.openEditPage(data.id)
    }

    nameColumnRender(data, rowData) {
        return `<div class="d-flex flex-column align-items-stretch gap-2">
            <div class="template-thumb-container">
                <iframe class="template-thumb-iframe" frameborder="0"></iframe>
            </div>
            <h6
                class="fw-medium mb-0 text-truncate"
                data-bs-toggle="tooltip"
                data-bs-placement="top"
                data-bs-title="${data}">
                <a href="${BASE_URL}/marketing/email-template/editor/${rowData.id}">${data}</a>
            </h6>
            <small class="text-muted">${rowData.created_by.name}</small>
            <div class="d-flex gap-1">
                <button type="button" class="btn btn-sm btn-wave btn-primary waves-effect waves-light flex-fill open-action">Open</button>
                <button type="button" class="btn btn-sm btn-danger delete-action"><i class="ri-delete-bin-fill"></i></button>
            </div>
        </div>`
    }

    nameColumnCreated(row, cell, cellData, rowData) {
        cell.querySelector(".template-thumb-iframe").srcdoc = rowData.html_compiled ?? ''

        cell.querySelector("button.delete-action")
            .addEventListener("click", async(e) => this.table.delete(row, rowData))

        cell.querySelector("button.open-action")
            .addEventListener("click", async(e) => this.openEditPage(rowData.id))
    }
}