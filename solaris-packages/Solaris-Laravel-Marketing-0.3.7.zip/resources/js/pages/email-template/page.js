import Model from "@core-js/solaris/model"
import StripoEditor from "@marketing-js/solaris/stripo-editor"
import SolarPage from "@core-js/solaris/solar/solar-page"
import TextInput from "@core-js/solaris/form/text-input"

export default class EmailTemplatePage extends SolarPage {
	init() {
		this.id      = document.querySelector(`input[type="hidden"][name="_id"]`)?.value
		this._isEdit = this.id ? true : false

		/** @type {TextInput} */
		this.name = this.get("template-name")
		this.name?.on("change", (val) => {
			if(!this.helper.isEmpty(val) && this.name.isError()) {
				this.name.resetValidation()
			}
		})

		this.getTemplate().then(res => {
			this.stripoEditor = new StripoEditor('#stripo-editor', STRIPO_EMAIL_ID, res?.html, res?.css, [], "email_template")
			this.stripoEditor
				?.on("ready", this.ready.bind(this))
				.on("saving", this.saving.bind(this))
				.on("save", this.save.bind(this))
		})
	}

	ready() {
		this.name?.enabled()
	}

	async saving() {
		if(this.name && this.helper.isEmpty(this.name.get())) {
			this.name.error()
			this.helper.toast({message: "Template name is required", color: "danger"})

			throw null
		}
	}

	async save({html, css, width, height, htmlCompiled, ampHtml}) {
		const data = {
			name: this.name?.get(),
			html,
			css,
			width,
			height,
			html_compiled: htmlCompiled,
			amp_html: ampHtml
		}

		const res = !this._isEdit ? await Model.create("EmailTemplate", data) : await Model.update("EmailTemplate", this.id, data)
		if(!res.success) {
			if(res.errors?.name) {
				this.name.error()
			}

			this.helper.toast({message: "Some fields are invalid or incomplete. Please check again.", color: "danger"})
			return
		}

		if(!this._isEdit) {
			this.id = res.data
			history.replaceState({ id: this.id }, '', `/marketing/email-template/editor/${this.id}`)
			this._isEdit = true
		}

		this.helper.successAlert({title: "Data saved successfully"})
	}

	async getTemplate() {
		if(!this.id) {
			return null
		}

		const data = await Model.get("EmailTemplate", this.id)
		return {
			html: data.html,
			css : data.css
		}
	}
}
