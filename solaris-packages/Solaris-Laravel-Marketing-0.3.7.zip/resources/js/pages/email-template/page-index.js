import EmailTemplatePage from "./page"

new EmailTemplatePage()