import CampaignBlastQuotaListPage from "./list"

new CampaignBlastQuotaListPage("campaign-blast-quota")