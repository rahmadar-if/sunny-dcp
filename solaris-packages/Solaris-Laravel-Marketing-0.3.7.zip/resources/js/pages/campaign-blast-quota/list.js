import SolarListPage from "@core-js/solaris/solar/solar-list-page"
import Filter from "@core-js/solaris/filter/filter"
import { CampaignBlastType } from "@marketing-js/const"
import DateHelper from "@core-js/solaris/date-helper"
import CampaignBlastQuotaUsageModal from "./usage-modal"
import FilterConstants from "@core-js/solaris/filter/filter-constants"

export default class CampaignBlastQuotaListPage extends SolarListPage {
    init() {
        this.columnRender("info", this.infoColumnRender.bind(this))
        this.columnRender("quota_info", this.quotaInfoColumnRender.bind(this))

        this.initModal()
        this.initFilters()

        if (document.getElementById("campaign-blast-quota-usage")) {
            this.usageModal = new CampaignBlastQuotaUsageModal(this)
        }
    }

    initModal() {
        if(!this.hasModalForm()) {
            return
        }

        const type          = this.form.get("type_id")
        const provider      = this.form.get("provider")
        const period        = this.form.get("period")
        const autoRenewDays = this.form.get("auto_renew_days")

        period?._plugin.setOptions([
            {id: "daily",   name: "Daily"},
            {id: "weekly",  name: "Weekly"},
            {id: "monthly", name: "Monthly"},
            {id: "yearly",  name: "Yearly"},
            {id: "custom",  name: "Custom"},
        ])

        type?.on("change", (val) => {
            if (!val) {
                provider.set(null)
                provider.disabled()
                provider._plugin.clear()
                return
            }

            provider.enabled()

            if (val.id == CampaignBlastType.Email) {
                provider._plugin.setOptions(EMAIL_PROVIDERS)
            } else if (val.id == CampaignBlastType.WhatsApp) {
                provider._plugin.setOptions(WA_PROVIDERS)
            }
        }, "CampaignBlastQuotaListPage")

        period?.on("change", (val) => {
            autoRenewDays.set(null)

            if (val?.id === "custom") {
                autoRenewDays.show()
                autoRenewDays.required()
            } else {
                autoRenewDays.hidden()
                autoRenewDays.optional()
            }
        }, "CampaignBlastQuotaListPage")
    }

    initFilters() {
        document.querySelectorAll('input[name="filter-type"]')?.forEach(radio => {
            radio.addEventListener("change", async (e) => {
                const val = e.target.value
                if (!val) {
                    await this.table.filter("type", null)
                    return
                }
                const typeId = val === "email" ? CampaignBlastType.Email : CampaignBlastType.WhatsApp
                await this.table.filter("type", new Filter().and("type_id", typeId))
            })
        })

        const activeCheckbox = this.get("filter-active")
        activeCheckbox?.on("change", async (val) => {
            if (!val) {
                await this.table.filter("active", null)
                return
            }
            const now = new Date().toISOString()
            await this.table.filter("active", new Filter().and("expired_at", FilterConstants.OperatorType.GreaterOrEqual, now))
        }, "CampaignBlastQuotaListPage")
    }

    onActionCreated(row, cell, rowData) {
        if (this.usageModal) {
            this.actionPrepend(row, {
                selector: "usage-history-action",
                label   : "Usage History",
                icon    : "ri-history-line",
                color   : "info",
                callback: async () => await this.usageModal.show(rowData.id)
            })
        }

        const now       = new Date()
        const expiredAt = rowData.expired_at ? new Date(rowData.expired_at) : null
        const isExpired = expiredAt && now > expiredAt

        if (rowData.auto_renew && !isExpired) {
            this.actionPrepend(row, {
                selector: "disable-auto-renew-action",
                label   : "Disable Auto Renew",
                icon    : "ri-loop-left-line",
                color   : "warning",
                callback: async () => await this.disableAutoRenew(rowData)
            })
        }

        if(rowData.quota_book > 0) {
            this.actionRemove(row, "delete-action")
        }
    }

    async disableAutoRenew(rowData) {
        try {
            await this.axios.post(`${BASE_URL}/admin/marketing/campaign-blast-quota/${rowData.id}/disable-auto-renew`)
            await this.refresh()
        } catch (e) {
            this.helper.alert({title: "Something wrong happen", message: e.response?.data?.message ?? "Failed to disable auto renew."})
        }
    }

    infoColumnRender(data, rowData) {
        const now         = new Date()
        const expiredDate = rowData.expired_at ? new Date(rowData.expired_at) : null
        const isActive    = expiredDate && expiredDate >= now

        const statusBadge = isActive
            ? `<span class="badge bg-success fs-11"><i class="ri-checkbox-circle-line me-1"></i>Active</span>`
            : `<span class="badge bg-danger fs-11"><i class="ri-close-circle-line me-1"></i>Inactive</span>`

        const type     = rowData.type?.name ?? "—"
        const provider = this.helper.toHeadline(rowData.provider ?? "—")

        let renewBadge = ""
        if (rowData.auto_renew) {
            let periodLabel = rowData.period ? this.helper.toHeadline(rowData.period) : "—"
            if (rowData.period === "custom" && rowData.auto_renew_days) {
                periodLabel = `Every ${rowData.auto_renew_days}d`
            }
            renewBadge = `<span class="badge bg-info fs-11"><i class="ri-loop-left-line me-1"></i>Renew every ${periodLabel}</span>`
        }

        const effectiveAt  = DateHelper.formatDatetime(rowData.effective_at)
        const expiredAtStr = DateHelper.formatDatetime(rowData.expired_at)

        return `<div style="min-width: 260px;">
            <div class="d-flex align-items-center gap-2 flex-wrap">
                ${statusBadge}
                <span class="fw-medium">${type} <span class="text-muted mx-1">·</span> ${provider}</span>
                ${renewBadge}
            </div>
            <hr class="my-1 opacity-25">
            <div class="d-flex align-items-center gap-2">
                <span class="text-success"><i class="ri-play-circle-line me-1"></i>${effectiveAt}</span>
                <i class="ri-arrow-right-line text-muted"></i>
                <span class="text-danger"><i class="ri-stop-circle-line me-1"></i>${expiredAtStr}</span>
            </div>
        </div>`
    }

    quotaInfoColumnRender(data, rowData) {
        const total  = rowData.total_quota ?? 0
        const used   = rowData.quota_used  ?? 0
        const booked = rowData.quota_book  ?? 0
        const avail  = total - used - booked

        const pct = (val) => total > 0 ? (val / total * 100).toFixed(1) : "0.0"
        const fmt = (val) => Number(val).toLocaleString()

        const usedPct   = pct(used)
        const bookedPct = pct(booked)
        const availPct  = pct(Math.max(0, avail))

        const dot = (color) => `<span style="display:inline-block;width:8px;height:8px;border-radius:2px;background:var(--bs-${color});flex-shrink:0"></span>`

        return `<div style="min-width: 240px;">
            <div class="d-grid gap-2 mb-2" style="grid-template-columns: repeat(4, 1fr);">
                <div>
                    <div class="text-muted fs-12">Total</div>
                    <div class="fw-semibold">${fmt(total)}</div>
                </div>
                <div>
                    <div class="text-muted fs-12">Used</div>
                    <div class="fw-medium">${fmt(used)} (${usedPct}%)</div>
                </div>
                <div>
                    <div class="text-muted fs-12">Booked</div>
                    <div class="fw-medium">${fmt(booked)} (${bookedPct}%)</div>
                </div>
                <div>
                    <div class="text-muted fs-12">Available</div>
                    <div class="fw-medium">${fmt(avail)} (${availPct}%)</div>
                </div>
            </div>
            <div class="progress" style="height: 6px;">
                <div class="progress-bar bg-danger"  style="width:${usedPct}%"   title="Used: ${fmt(used)}"></div>
                <div class="progress-bar bg-warning" style="width:${bookedPct}%" title="Booked: ${fmt(booked)}"></div>
                <div class="progress-bar bg-success" style="width:${availPct}%"  title="Available: ${fmt(avail)}"></div>
            </div>
            <div class="d-flex gap-3 mt-1">
                <span class="d-flex align-items-center gap-1 fs-11 text-muted">${dot("danger")} Used</span>
                <span class="d-flex align-items-center gap-1 fs-11 text-muted">${dot("warning")} Booked</span>
                <span class="d-flex align-items-center gap-1 fs-11 text-muted">${dot("success")} Available</span>
            </div>
        </div>`
    }
}
