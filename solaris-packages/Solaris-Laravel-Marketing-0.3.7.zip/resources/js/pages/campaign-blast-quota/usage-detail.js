import Filter from "@core-js/solaris/filter/filter"

const ACTION_STYLE = {
    book   : { label: "Book",    color: "warning" },
    consume: { label: "Consume", color: "danger"  },
    release: { label: "Release", color: "success" },
}

export default class CampaignBlastQuotaUsageDetail {
    constructor(page, id = "campaign-blast-quota-usage") {
        this.page  = page
        this.id    = id
        this.table = this.page.get(`${id}-detail_table`)

        this.table.on("column render:entry", this.renderEntry.bind(this), "UsageDetail.entry")
        this.table.on("column render:delta", this.renderDelta.bind(this), "UsageDetail.delta")
    }

    async load(quotaId, sourceId) {
        const filter = new Filter().and("quota_id", quotaId)

        sourceId ? filter.and("source_id", sourceId) : filter.andNull("source_id")

        await this.table.filter("usage", filter, false)

        this.table._table ? await this.table.refresh() : await this.table.render()
    }

    toLabel(value) {
        return this.page.helper.toHeadline(String(value ?? "").replace(/_/g, " "))
    }

    renderEntry(data, rowData) {
        const style = ACTION_STYLE[rowData.action] ?? { label: this.toLabel(rowData.action), color: "secondary" }

        return `<div class="d-flex align-items-center gap-2 flex-wrap">
            <span class="badge bg-${style.color} fs-11">${style.label}</span>
            <span class="text-muted fs-12">${this.toLabel(rowData.context)}</span>
        </div>`
    }

    renderDelta(data, rowData) {
        const book = Number(rowData.book_delta ?? 0)
        const used = Number(rowData.used_delta ?? 0)

        const signed = (value, color) => {
            if (value === 0) {
                return `<span class="text-muted">—</span>`
            }

            return `<span class="text-${color}">${value > 0 ? "+" : ""}${value.toLocaleString()}</span>`
        }

        return `<div class="d-flex justify-content-end gap-3">
            <span><span class="text-muted fs-11 me-1">book</span>${signed(book, book < 0 ? "danger" : "warning")}</span>
            <span><span class="text-muted fs-11 me-1">used</span>${signed(used, "success")}</span>
        </div>`
    }
}
