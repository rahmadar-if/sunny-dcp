import ListModal from "@core-js/solaris/list-modal"
import DateHelper from "@core-js/solaris/date-helper"
import CampaignBlastQuotaUsageDetail from "./usage-detail"

const LIST_TITLE = "Quota Usage History"

export default class CampaignBlastQuotaUsageModal {
    constructor(page, id = "campaign-blast-quota-usage") {
        this.page    = page
        this.id      = id
        this.quotaId = null
        this.detail  = new CampaignBlastQuotaUsageDetail(page, id)

        this.listPane   = document.querySelector(`#${id} .usage-list-pane`)
        this.detailPane = document.querySelector(`#${id} .usage-detail-pane`)
        this.titleEl    = document.getElementById(`${id}_title`)
        this.backBtn    = document.getElementById(`${id}_back`)

        this.modal = new ListModal(this.id, { length: 10 })
        this.modal
            .on("load", this.loadGroups.bind(this))
            .on("render", this.renderRow.bind(this))
            .on("rendered", this.onRowRendered.bind(this))
            .on("closed", this.showList.bind(this))

        this.backBtn?.addEventListener("click", () => this.showList())
    }

    async show(quotaId) {
        this.quotaId = quotaId

        this.showList()

        await this.modal.show()
    }

    showList() {
        this.listPane?.classList.remove("d-none")
        this.detailPane?.classList.add("d-none")
        this.backBtn?.classList.add("d-none")

        if (this.titleEl) {
            this.titleEl.textContent = LIST_TITLE
        }
    }

    async showDetail(item) {
        const title = this.rowTitle(item)

        this.page.helper.loadingPage(true)

        try {
            await this.detail.load(this.quotaId, item.source_id)
        } finally {
            this.page.helper.loadingPage(false)
        }

        this.listPane?.classList.add("d-none")
        this.detailPane?.classList.remove("d-none")
        this.backBtn?.classList.remove("d-none")

        if (this.titleEl) {
            this.titleEl.textContent = title
        }
    }

    async loadGroups({ search, start, length }) {
        const response = await this.page.axios.get(
            `${BASE_URL}/admin/marketing/campaign-blast-quota/${this.quotaId}/usage/groups`,
            { params: { search: search || null, start: start, length: length } }
        )

        const data = response.data?.data ?? {}

        return { items: data.items ?? [], total: data.total ?? 0 }
    }

    onRowRendered(element, item) {
        element.classList.add("usage-row-clickable")
        element.setAttribute("role", "button")
        element.addEventListener("click", () => this.showDetail(item))
    }

    rowTitle(item) {
        if (!item.source_id) {
            return "Others"
        }

        return item.title ?? "Deleted campaign"
    }

    fmt(value) {
        return Number(value ?? 0).toLocaleString()
    }

    pct(value, total) {
        return total > 0 ? (value / total * 100).toFixed(1) : "0.0"
    }

    renderRow(item) {
        // Usage that never attached to a campaign: single sends, tests, anything ad-hoc.
        const isOthers = !item.source_id
        const title    = isOthers
            ? `Others <span class="text-muted fw-normal">(${this.fmt(item.entries)}x)</span>`
            : (item.title ?? `<span class="text-muted fst-italic">Deleted campaign</span>`)

        const settled = item.outstanding === 0
        const badge   = settled
            ? `<span class="badge bg-success fs-11"><i class="ri-checkbox-circle-line me-1"></i>Settled</span>`
            : `<span class="badge bg-warning fs-11"><i class="ri-time-line me-1"></i>Booked ${this.fmt(item.outstanding)}</span>`

        const failed   = item.consumed - item.sent
        const deliver  = item.consumed > 0 ? this.pct(item.sent, item.consumed) : null

        const period = item.first_at === item.last_at
            ? DateHelper.formatDatetime(item.last_at)
            : `${DateHelper.formatDatetime(item.first_at)} <i class="ri-arrow-right-line mx-1"></i> ${DateHelper.formatDatetime(item.last_at)}`

        const bar = item.booked > 0
            ? `<div class="progress mt-2" style="height: 5px;">
                   <div class="progress-bar bg-danger"  style="width:${this.pct(item.consumed, item.booked)}%" title="Consumed ${this.fmt(item.consumed)}"></div>
                   <div class="progress-bar bg-success" style="width:${this.pct(item.released, item.booked)}%" title="Released ${this.fmt(item.released)}"></div>
                   <div class="progress-bar bg-warning" style="width:${this.pct(item.outstanding, item.booked)}%" title="Still booked ${this.fmt(item.outstanding)}"></div>
               </div>`
            : ""

        const note = failed > 0
            ? `<div class="text-warning fs-11 mt-2"><i class="ri-error-warning-line me-1"></i>${this.fmt(item.consumed)} quota consumed, ${this.fmt(item.sent)} sent — ${this.fmt(failed)} failed during delivery.</div>`
            : ""

        return `<div class="usage-row">
            <div class="d-flex justify-content-between align-items-start gap-3 flex-wrap">
                <div class="flex-grow-1" style="min-width: 14rem;">
                    <div class="fw-medium">${title}</div>
                    <div class="text-muted fs-11 mt-1">${period}</div>
                    <div class="mt-2">${badge}</div>
                </div>
                <div class="d-flex gap-3 text-end fs-12">
                    <div class="usage-metric">
                        <div class="text-muted fs-11">Booked</div>
                        <div class="fw-medium">${this.fmt(item.booked)}</div>
                    </div>
                    <div class="usage-metric">
                        <div class="text-muted fs-11">Consumed</div>
                        <div class="fw-medium text-danger">${this.fmt(item.consumed)}</div>
                    </div>
                    <div class="usage-metric">
                        <div class="text-muted fs-11">Released</div>
                        <div class="fw-medium text-success">${this.fmt(item.released)}</div>
                    </div>
                    <div class="usage-metric">
                        <div class="text-muted fs-11">Sent</div>
                        <div class="fw-semibold">${this.fmt(item.sent)}</div>
                        ${deliver ? `<div class="text-muted fs-11">${deliver}%</div>` : ""}
                    </div>
                </div>
            </div>
            ${bar}
            ${note}
        </div>`
    }
}
