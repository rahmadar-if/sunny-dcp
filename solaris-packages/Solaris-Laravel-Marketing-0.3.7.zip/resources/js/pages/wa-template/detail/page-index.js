import WaTemplateDetailPage from "./page"

new WaTemplateDetailPage()
