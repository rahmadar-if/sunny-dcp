import DropzoneUpload from "@core-js/solaris/dropzone"
import { WaTemplateHeaderType } from "@marketing-js/const"
import {
	esc,
	updateCharCount,
	showSamplePopover,
	enforceCharLimit,
	extractBodyValue,
	renderBodyEditor,
	applyBodyFormat,
	renumberBodyParams,
	syncBodyExamples,
	createSingleParamChip,
	extractSingleParamValue,
	renderSingleParamEditor,
	insertChipAtCursor,
} from "./editor-utils"
import SolarSingleton from "@core-js/solaris/solar/solar-singleton"
import Helper from "@core-js/solaris/helper"

const { limits: _limits, media_constraints: _mediaConstraints } = WaTemplateLimits

const WA_CAROUSEL_LIMITS = {
	minCards     : _limits.carousel_min_cards,
	maxCards     : _limits.carousel_max_cards,
	bodyMaxChars : _limits.carousel_body_max_chars,
	bodyMaxParams: _limits.carousel_body_max_params,
	labelMaxChars: _limits.carousel_label_max_chars,
	urlMaxChars  : _limits.carousel_url_max_chars,
}

const CAROUSEL_MEDIA_CONSTRAINTS = {
	[WaTemplateHeaderType.Image]: { exts: _mediaConstraints.image.exts.join(','), maxBytes: _mediaConstraints.image.max_mb },
	[WaTemplateHeaderType.Video]: { exts: _mediaConstraints.video.exts.join(','), maxBytes: _mediaConstraints.video.max_mb },
}

export default class WaTemplateCarousel
{
	constructor(form, onMediaTypeChange, renderPreview, disabled = false) {
		this._solarUI           = SolarSingleton.getSolarUI()
		this._form              = form
		this._addCardComp       = this._solarUI.get('wa-carousel-add-card')
		this._onMediaTypeChange = onMediaTypeChange
		this._renderPreview     = renderPreview
		this._disabled          = disabled
		this._cards             = []
		this._cardIdSeq         = 0
		this._currentMediaType  = WaTemplateHeaderType.Image
		this._globalButtons     = []
	}

	//#region Public

	clearButtonValidation() {
		const container = document.getElementById('wa-carousel-cards-container')
		container?.querySelectorAll('.wa-slot-label, .wa-slot-value').forEach(el => {
			el.classList.remove('is-invalid')
		})
	}

	validateButtonSlots() {
		const valueTypes = ['url', 'phone_number']
		let isError      = false

		this._cards.forEach(card => {
			const cardEl = document.querySelector(`[data-card-id="${card.id}"]`)
			if (!cardEl) {
				return
			}

			;(card.buttons ?? []).forEach((btn, i) => {
				const slot = cardEl.querySelector(`[data-slot-index="${i}"]`)
				if (!slot) {
					return
				}

				if (!btn.label?.trim()) {
					slot.querySelector('.wa-slot-label')?.classList.add('is-invalid')
					isError = true
				}

				const btnType = this._globalButtons[i]?.type
				if (valueTypes.includes(btnType) && !btn.value?.trim()) {
					slot.querySelector('.wa-slot-value')?.classList.add('is-invalid')
					isError = true
				}
			})
		})

		return !isError
	}

	init(initialButtons) {
		this._globalButtons  = initialButtons ?? []
		this._addCardWired   = false
		this._mediaTypeWired = false

		const cardValues = this._form.get('cards')
		if (cardValues?.get()) {
			try {
				const saved = JSON.parse(cardValues.get())
				if (Array.isArray(saved)) {
					saved.forEach(c => this._addCard(c, this._globalButtons))
				}
			} catch {}
		}

		if (this._disabled) {
			this._addCardComp.disabled()
			return
		}

		this._wireAddCard()
		this._initMediaTypeRadio()
	}

	reset(schema, disabled = this._disabled) {
		this._disabled = disabled

		this._clearAllCards()
		this._globalButtons = schema ?? []

		// Sync media type radio from header_type_id
		const headerTypeId     = this._form.get('header_type_id')?.get()?.id
		const isVideo          = headerTypeId === WaTemplateHeaderType.Video
		this._currentMediaType = isVideo ? WaTemplateHeaderType.Video : WaTemplateHeaderType.Image
		this._form.get('wa-carousel-media-type').set(this._currentMediaType, true)

		const cardValues = this._form.get('cards')
		if (cardValues?.get()) {
			try {
				const saved = JSON.parse(cardValues.get())
				if (Array.isArray(saved)) {
					saved.forEach(c => this._addCard(c, this._globalButtons))
				}
			} catch {}
		}

		if (this._disabled) {
			this._addCardComp.disabled()
		}

		this._syncCardValidation()

		if (!this._disabled) {
			this._wireAddCard()
			this._initMediaTypeRadio()
		}
	}

	/**
	 * Wire the add-card click listener (once).
	 * @returns {void}
	 */
	_wireAddCard() {
		if (this._addCardWired) {
			return
		}
		this._addCardWired = true
		this._addCardComp.on('click', () => {
			if (this._cards.length >= WA_CAROUSEL_LIMITS.maxCards) {
				return
			}
			this._addCard({}, this._globalButtons)
			this._syncCards()
			this._syncCardValidation()
			this._renderPreview()
		})
	}

	applyCarouselMode(isInitial) {
		if (isInitial) {
			if (this._cards.length === 0) {
				this._addCard({}, this._globalButtons)
				this._addCard({}, this._globalButtons)
				this._syncCards()
			}
			this._syncCardValidation()
			return
		}

		this._clearAllCards()
		this._addCard({}, this._globalButtons)
		this._addCard({}, this._globalButtons)
		this._syncCards()
		this._syncCardValidation()
	}

	applyNormalMode(isInitial) {
		if (isInitial) {
			return
		}
		this._clearAllCards()
		this._syncCards()
	}

	onGlobalButtonSchemaChange(buttons) {
		const prevButtons   = this._globalButtons
		this._globalButtons = buttons

		this._cards.forEach(card => {
			const cardEl = document.querySelector(`[data-card-id="${card.id}"]`)
			if (!cardEl) {
				return
			}

			let slotsWrap = cardEl.querySelector('.wa-card-btn-slots')

			if (!slotsWrap) {
				if (buttons.length === 0) {
					return
				}
				slotsWrap           = document.createElement('div')
				slotsWrap.className = 'wa-card-btn-slots'
				cardEl.querySelector('.card-body').appendChild(slotsWrap)
			}

			const currentSlots = slotsWrap.querySelectorAll('.wa-card-btn-slot')

			// Remove extra slots
			for (let i = buttons.length; i < currentSlots.length; i++) {
				currentSlots[i].remove()
				if (card.buttons[i]) {
					card.buttons.splice(i, 1)
				}
			}

			// Add missing slots
			for (let i = currentSlots.length; i < buttons.length; i++) {
				const slot = this._createButtonSlot(card, i, buttons[i].type)
				slotsWrap.appendChild(slot)
				if (!card.buttons[i]) {
					card.buttons.push({ label: '', value: '', url_example: '' })
				}
			}

			// Update slot labels for type changes
			buttons.forEach((btn, i) => {
				const slot    = slotsWrap.querySelector(`[data-slot-index="${i}"]`)
				const oldType = prevButtons[i]?.type ?? btn.type

				if (!slot) {
					return
				}

				// Re-create slot when type changes so url editor is properly wired
				if (oldType !== btn.type) {
					if (card.buttons[i]) {
						card.buttons[i].value       = ''
						card.buttons[i].url_example = ''
					}
					const newSlot = this._createButtonSlot(card, i, btn.type)
					slot.replaceWith(newSlot)
					return
				}

				const typeBadge = slot.querySelector('.wa-slot-type-label')
				if (typeBadge) {
					typeBadge.textContent = this._buttonTypeLabel(btn.type)
				}

				const valueLabel = slot.querySelector('.wa-slot-value-label')
				if (valueLabel) {
					valueLabel.textContent = btn.type === 'url' ? 'URL' : btn.type === 'phone_number' ? 'Phone' : ''
				}

				const valueInput = slot.querySelector('.wa-slot-value')
				if (valueInput) {
					valueInput.placeholder = btn.type === 'phone_number' ? '+62...' : ''
				}

				const valueWrap = slot.querySelector('.wa-slot-value-wrap')
				if (valueWrap) {
					valueWrap.classList.toggle('d-none', btn.type === 'quick_reply')
				}
			})

			if (buttons.length === 0) {
				slotsWrap.remove()
			}
		})

		this._syncCards()
	}

	onGlobalMediaTypeChange(typeId) {
		this._currentMediaType = typeId
		const constraint = CAROUSEL_MEDIA_CONSTRAINTS[typeId] ?? CAROUSEL_MEDIA_CONSTRAINTS[WaTemplateHeaderType.Image]

		this._cards.forEach(card => {
			const cardEl    = document.querySelector(`[data-card-id="${card.id}"]`)
			const mediaInfo = cardEl?.querySelector('.wa-card-media-info')
			if (mediaInfo) {
				mediaInfo.textContent = this._mediaTypeHint(typeId)
			}
			if (card.mediaDropzone) {
				card.mediaDropzone.setAcceptFiles(constraint.exts)
				card.mediaDropzone.setMaxFileSize(constraint.maxBytes)
			}
		})
	}

	getCards() {
		return this._cards.map(card => ({
			id            : card.id,
			header_content: card.mediaMode === 'upload' ? '' : (card.mediaUrl ?? ''),
			header_examples: card.mediaUrl ?? '',
			body          : card.body ?? '',
			body_examples : card.bodyExamples ?? {},
			buttons       : (card.buttons ?? []).map((b, i) => ({
				type       : this._globalButtons[i]?.type ?? '',
				label      : b.label ?? '',
				value      : b.value ?? '',
				url_example: b.url_example ?? '',
			})),
		}))
	}

	hasContent() {
		return this._cards.some(card =>
			(card.body ?? '').length > 0 ||
			(card.mediaUrl ?? '').length > 0 ||
			card.mediaLocalUrl !== null
		)
	}

	hasPendingUploads() {
		return this._cards.some(card =>
			card.mediaMode === 'upload'
			&& card.mediaDropzone !== null
			&& card.mediaDropzone.getFiles().length > 0
		)
	}

	triggerAllUploads(recordId) {
		const pendingCards = this._cards.filter(card =>
			card.mediaMode === 'upload'
			&& card.mediaDropzone !== null
			&& card.mediaDropzone.getFiles().length > 0
		)

		return Promise.all(pendingCards.map(card => new Promise((resolve, reject) => {
			card._uploadResolver = resolve
			card._uploadRejecter = reject
			card.mediaDropzone.setTableName('wa_template_details')
			card.mediaDropzone.setRecordId(recordId)
			card.mediaDropzone.processQueue()
		})))
	}

	getCardsForPreview() {
		return this._cards.map(card => ({
			id            : card.id,
			header_content: card.mediaMode === 'upload' ? (card.mediaLocalUrl ?? '') : (card.mediaUrl ?? ''),
			body          : card.body ?? '',
			body_examples : card.bodyExamples ?? {},
			buttons       : (card.buttons ?? []).map((b, i) => ({
				type       : this._globalButtons[i]?.type ?? '',
				label      : b.label ?? '',
				value      : b.value ?? '',
				url_example: b.url_example ?? '',
			})),
		}))
	}

	//#endregion

	//#region Private — setup

	_initMediaTypeRadio() {
		if (this._mediaTypeWired) {
			return
		}
		this._mediaTypeWired = true

		const mediaType = this._form.get("wa-carousel-media-type")
		mediaType.on("change", async (val) => {
			const hasPendingUploads = this._cards.some(c => c.mediaLocalUrl !== null)

			if (hasPendingUploads) {
				const confirmed = await Helper.confirm({
					title  : 'Change Media Type?',
					message: 'All uploaded media will be reset. Continue?',
				})

				if (!confirmed) {
					mediaType.set(this._currentMediaType, true)
					return
				}

				this._cards.forEach(card => {
					card.mediaDropzone?.clear()
					this._revokeBlobUrl(card.mediaLocalUrl)
					card.mediaLocalUrl = null
				})
				this._syncCards()
				this._renderPreview()
			}

			this._currentMediaType = val.id
			this.onGlobalMediaTypeChange(val.id)
			this._onMediaTypeChange?.(val.id)
		})
	}

	_clearAllCards() {
		const container = document.getElementById('wa-carousel-cards-container')
		this._cards.forEach(card => {
			card.mediaDropzone?._dropzone?.destroy()
			container?.querySelector(`[data-card-id="${card.id}"]`)?.remove()
		})
		this._cards = []
	}

	//#endregion

	//#region Private — card management

	_addCard(data = {}, globalButtons = []) {
		if (this._cards.length >= WA_CAROUSEL_LIMITS.maxCards) {
			return
		}

		const id   = `c${++this._cardIdSeq}`
		const card = {
			id,
			_uploadResolver : null,
			_uploadRejecter : null,
			mediaMode       : 'url',
			mediaUrl        : data.header_content ?? data.mediaUrl ?? '',
			mediaLocalUrl   : null,
			mediaDropzone   : null,
			popoverCleanup  : null,
			body            : data.body ?? '',
			bodyExamples    : data.body_examples ?? data.bodyExamples ?? {},
			buttons         : (data.buttons ?? []).map(b => ({
				label      : b.label ?? '',
				value      : b.value ?? '',
				url_example: b.url_example ?? '',
			})),
		}

		// Fill missing button slots
		for (let i = card.buttons.length; i < globalButtons.length; i++) {
			card.buttons.push({ label: '', value: '', url_example: '' })
		}

		this._cards.push(card)

		const container = document.getElementById('wa-carousel-cards-container')
		if (!container) {
			return
		}

		const el          = document.createElement('div')
		el.className      = 'card wa-carousel-card'
		el.dataset.cardId = id
		el.innerHTML      = this._cardHtml(card, globalButtons)
		container.appendChild(el)

		this._wireCard(el, card, globalButtons)
	}

	_removeCard(id) {
		const container = document.getElementById('wa-carousel-cards-container')
		const card      = this._cards.find(c => c.id === id)
		if (card) {
			card.mediaDropzone?._dropzone?.destroy()
			this._revokeBlobUrl(card.mediaLocalUrl)
		}
		container?.querySelector(`[data-card-id="${id}"]`)?.remove()
		this._cards = this._cards.filter(c => c.id !== id)
	}

	_wireCard(el, card, globalButtons) {
		this._wireCardMedia(el, card)
		this._wireCardBody(el, card)

		const removeBtn = el.querySelector('.wa-card-remove')
		removeBtn?.addEventListener('click', () => {
			this._removeCard(card.id)
			this._syncCards()
			this._syncCardValidation()
			this._renderPreview()
		})

		globalButtons.forEach((btnSchema, i) => {
			const slot = el.querySelector(`.wa-card-btn-slots [data-slot-index="${i}"]`)
			if (!slot) {
				return
			}
			this._wireButtonSlot(slot, card, i, btnSchema.type)
		})
	}

	_wireCardMedia(el, card) {
		const mediaUrlInput = el.querySelector('.wa-card-media-url')
		const dropzoneWrap  = el.querySelector('.wa-card-dropzone-wrap')
		const dropzoneEl    = el.querySelector('[data-card-dropzone]')
		const modeRadios    = el.querySelectorAll('.wa-card-media-mode')

		if (this._disabled) {
			modeRadios.forEach(r => {
				r.disabled = true
			})
			if (mediaUrlInput) {
				mediaUrlInput.disabled = true
			}
			return
		}

		if (dropzoneEl) {
			const constraint = CAROUSEL_MEDIA_CONSTRAINTS[this._currentMediaType] ?? CAROUSEL_MEDIA_CONSTRAINTS[WaTemplateHeaderType.Image]
			dropzoneEl.setAttribute('accept-files', constraint.exts)
			dropzoneEl.setAttribute('max-file-size', constraint.maxBytes)

			card.mediaDropzone = new DropzoneUpload(dropzoneEl)

			card.mediaDropzone.on('addedfile', (file) => {
				const oldUrl = card.mediaLocalUrl
				card.mediaLocalUrl = URL.createObjectURL(file)
				this._syncCards()
				this._renderPreview()
				this._revokeBlobUrl(oldUrl)
			})

			card.mediaDropzone.on('removedfile', () => {
				const oldUrl = card.mediaLocalUrl
				card.mediaLocalUrl = null
				this._syncCards()
				this._renderPreview()
				this._revokeBlobUrl(oldUrl)
			})

			card.mediaDropzone.on('success', (file, response) => {
				if (!card._uploadResolver) {
					return
				}
				const resolve = card._uploadResolver
				card._uploadResolver = null
				card._uploadRejecter = null
				resolve({ card_id: card.id, attachment_id: response?.data?.id ?? null })
			})

			card.mediaDropzone.on('error', (file, msg) => {
				if (!card._uploadRejecter) {
					return
				}
				const reject = card._uploadRejecter
				card._uploadResolver = null
				card._uploadRejecter = null
				reject(msg)
			})
		}

		modeRadios.forEach(radio => {
			radio.addEventListener('change', () => {
				if (!radio.checked) {
					return
				}
				card.mediaMode = radio.value

				if (radio.value === 'url') {
					mediaUrlInput?.classList.remove('d-none')
					dropzoneWrap?.classList.add('d-none')
					card.mediaDropzone?.clear()
					this._revokeBlobUrl(card.mediaLocalUrl)
					card.mediaLocalUrl = null
					if (mediaUrlInput) {
						mediaUrlInput.value = ''
					}
					card.mediaUrl = ''
				} else {
					mediaUrlInput?.classList.add('d-none')
					dropzoneWrap?.classList.remove('d-none')
					if (mediaUrlInput) {
						mediaUrlInput.value = ''
					}
					card.mediaUrl = ''
				}

				this._syncCards()
				this._renderPreview()
			})
		})

		mediaUrlInput?.addEventListener('input', () => {
			card.mediaUrl = mediaUrlInput.value
			this._syncCards()
			this._renderPreview()
		})
	}

	_wireCardBody(el, card) {
		const editor    = el.querySelector('.wa-card-body-editor')
		const bodyCount = el.querySelector('.wa-card-body-count')
		const paramBtn  = el.querySelector('.wa-card-param-btn')

		if (!editor) {
			return
		}

		if (this._disabled) {
			editor.contentEditable = 'false'
			el.querySelectorAll('[data-wa-format]').forEach(btn => {
				btn.disabled = true
			})
			if (paramBtn) {
				paramBtn.disabled = true
			}
			return
		}

		const createChip = (n, sample) => {
			const span = document.createElement('span')
			span.className       = 'wa-param-chip'
			span.contentEditable = 'false'
			span.dataset.param   = n
			span.dataset.sample  = sample ?? ''
			span.innerHTML       = `{{${n}}} <i class="ri-pencil-line wa-chip-edit-icon"></i>`
			span.classList.toggle('has-sample', !!(sample ?? ''))
			span.addEventListener('click', (e) => {
				e.preventDefault()
				showSamplePopover(
					e, span,
					() => {
						card.bodyExamples = syncBodyExamples(editor)
						this._syncCards()
					},
					() => card.popoverCleanup,
					(fn) => { card.popoverCleanup = fn },
					this._disabled
				)
			})
			return span
		}

		const syncParamBtn = () => {
			const count = editor.querySelectorAll('[data-param]').length
			if (paramBtn) {
				paramBtn.disabled = count >= WA_CAROUSEL_LIMITS.bodyMaxParams
			}
		}

		const syncAll = () => {
			renumberBodyParams(editor)
			const val = extractBodyValue(editor)
			card.body         = val
			card.bodyExamples = syncBodyExamples(editor)
			updateCharCount(bodyCount, val.length, WA_CAROUSEL_LIMITS.bodyMaxChars)
			syncParamBtn()
			this._syncCards()
			this._renderPreview()
		}

		renderBodyEditor(editor, card.body ?? '', card.bodyExamples ?? {}, createChip)
		syncParamBtn()

		editor.addEventListener('beforeinput', (e) => {
			enforceCharLimit(editor, extractBodyValue, WA_CAROUSEL_LIMITS.bodyMaxChars, e)
		})

		editor.addEventListener('input', () => {
			if (extractBodyValue(editor) === '') {
				editor.innerHTML = ''
			}
			syncAll()
		})

		editor.addEventListener('keydown', e => {
			if (e.ctrlKey) {
				const formatMap = {
					'b': { shift: false, format: 'bold' },
					'i': { shift: false, format: 'italic' },
					'X': { shift: true,  format: 'strikethrough' },
					'M': { shift: true,  format: 'code' },
				}
				const hit = formatMap[e.key]
				if (hit && e.shiftKey === hit.shift) {
					e.preventDefault()
					applyBodyFormat(editor, hit.format)
					editor.normalize()
					syncAll()
					return
				}

				if (e.shiftKey && e.key === 'P') {
					e.preventDefault()
					this._insertBodyParamChip(editor, createChip)
					syncAll()
					return
				}
			}

			if (e.key !== 'Enter') {
				return
			}

			e.preventDefault()
			const sel = window.getSelection()
			if (!sel.rangeCount) {
				return
			}

			const range = sel.getRangeAt(0)
			range.deleteContents()

			const br = document.createElement('br')
			range.insertNode(br)

			const afterBr = br.nextSibling
			if (afterBr?.nodeType === Node.TEXT_NODE && afterBr.textContent === '') {
				afterBr.remove()
			}

			const newRange = document.createRange()
			if (!br.nextSibling) {
				const sentinel = document.createElement('br')
				br.after(sentinel)
				newRange.setStartBefore(sentinel)
			} else {
				newRange.setStartAfter(br)
			}

			newRange.collapse(true)
			sel.removeAllRanges()
			sel.addRange(newRange)
			syncAll()
		})

		editor.addEventListener('paste', e => {
			e.preventDefault()
			const text = e.clipboardData.getData('text/plain')
			if (!text) {
				return
			}
			const sel = window.getSelection()
			if (!sel.rangeCount) {
				return
			}
			const range       = sel.getRangeAt(0)
			const selectedLen = range.toString().length
			const currentLen  = extractBodyValue(editor).length
			const available   = WA_CAROUSEL_LIMITS.bodyMaxChars - (currentLen - selectedLen)
			const clipped     = text.slice(0, Math.max(0, available))
			if (!clipped) {
				return
			}
			range.deleteContents()
			const textNode = document.createTextNode(clipped)
			range.insertNode(textNode)
			range.setStartAfter(textNode)
			range.collapse(true)
			sel.removeAllRanges()
			sel.addRange(range)
			syncAll()
		})

		el.querySelectorAll('[data-wa-format]').forEach(btn => {
			btn.addEventListener('mousedown', e => e.preventDefault())
			btn.addEventListener('click', () => {
				applyBodyFormat(editor, btn.dataset.waFormat)
				editor.normalize()
				syncAll()
			})
		})

		paramBtn?.addEventListener('click', () => {
			this._insertBodyParamChip(editor, createChip)
			syncAll()
		})
	}

	_insertBodyParamChip(editor, createChip) {
		const val  = extractBodyValue(editor)
		const used = new Set()
		const re   = /\{\{(\d+)\}\}/g
		let m
		while ((m = re.exec(val)) !== null) {
			used.add(parseInt(m[1]))
		}

		if (used.size >= WA_CAROUSEL_LIMITS.bodyMaxParams) {
			return
		}

		let maxN = 0
		used.forEach(n => {
			if (n > maxN) {
				maxN = n
			}
		})

		const nextN = maxN + 1
		editor.focus()

		const selection = window.getSelection()
		let range

		if (selection.rangeCount && editor.contains(selection.getRangeAt(0).commonAncestorContainer)) {
			range = selection.getRangeAt(0)
		} else {
			range = document.createRange()
			range.selectNodeContents(editor)
			range.collapse(false)
		}

		range.deleteContents()
		const chip = createChip(nextN, '')
		range.insertNode(chip)
		range.setStartAfter(chip)
		range.collapse(true)
		selection.removeAllRanges()
		selection.addRange(range)
	}

	_wireButtonSlot(slot, card, index, type) {
		const labelInput    = slot.querySelector('.wa-slot-label')
		const valueInput    = slot.querySelector('.wa-slot-value')
		const urlEditor     = slot.querySelector('.wa-slot-url-editor')
		const paramBtn      = slot.querySelector('.wa-slot-url-param-btn')
		const labelCount    = slot.querySelector('.wa-slot-label-count')
		const valueCount    = slot.querySelector('.wa-slot-value-count')
		const btnData       = card.buttons[index] ?? { label: '', value: '', url_example: '' }

		if (this._disabled) {
			if (labelInput) {
				labelInput.disabled = true
			}
			if (valueInput) {
				valueInput.disabled = true
			}
			if (paramBtn) {
				paramBtn.disabled = true
			}
			if (urlEditor) {
				urlEditor.contentEditable = 'false'
			}
			return
		}

		const makeUrlChip = (sample) => createSingleParamChip(
			'wa-param-chip', sample,
			(e, span) => showSamplePopover(
				e, span,
				() => {
					syncUrlExample()
					this._syncCards()
				},
				() => card.popoverCleanup,
				(fn) => { card.popoverCleanup = fn },
				this._disabled
			)
		)

		const syncUrlCount = () => {
			if (!urlEditor || !valueCount) {
				return
			}
			updateCharCount(valueCount, extractSingleParamValue(urlEditor).length, WA_CAROUSEL_LIMITS.urlMaxChars)
		}

		const syncUrlExample = () => {
			const chip = urlEditor?.querySelector('.wa-param-chip')
			if (card.buttons[index]) {
				card.buttons[index].url_example = chip ? (chip.dataset.sample ?? '') : ''
			}
		}

		if (type === 'url' && urlEditor && btnData.value) {
			renderSingleParamEditor(urlEditor, btnData.value, btnData.url_example ?? '', makeUrlChip)
			syncUrlCount()
			if (paramBtn) {
				paramBtn.disabled = btnData.value.includes('{{1}}')
			}
		}

		labelInput?.addEventListener('input', () => {
			if (!card.buttons[index]) {
				card.buttons[index] = { label: '', value: '', url_example: '' }
			}
			card.buttons[index].label = labelInput.value
			labelInput.classList.toggle('is-invalid', labelInput.value.length === 0)
			updateCharCount(labelCount, labelInput.value.length, WA_CAROUSEL_LIMITS.labelMaxChars)
			this._syncCards()
			this._renderPreview()
		})

		valueInput?.addEventListener('input', () => {
			if (!card.buttons[index]) {
				card.buttons[index] = { label: '', value: '', url_example: '' }
			}
			card.buttons[index].value = valueInput.value
			valueInput.classList.toggle('is-invalid', valueInput.value.length === 0)
			updateCharCount(valueCount, valueInput.value.length, WA_CAROUSEL_LIMITS.urlMaxChars)
			this._syncCards()
		})

		urlEditor?.addEventListener('keydown', e => {
			if (e.key === 'Enter') {
				e.preventDefault()
			}

			if (e.ctrlKey && e.shiftKey && e.key === 'P') {
				e.preventDefault()
				if (extractSingleParamValue(urlEditor).includes('{{1}}')) {
					return
				}
				insertChipAtCursor(urlEditor, makeUrlChip(''))
				if (card.buttons[index]) {
					card.buttons[index].value = extractSingleParamValue(urlEditor)
				}
				if (paramBtn) {
					paramBtn.disabled = true
				}
				syncUrlCount()
				this._syncCards()
			}
		})

		urlEditor?.addEventListener('beforeinput', e => {
			enforceCharLimit(urlEditor, extractSingleParamValue, WA_CAROUSEL_LIMITS.urlMaxChars, e)
		})

		urlEditor?.addEventListener('input', () => {
			if (!card.buttons[index]) {
				card.buttons[index] = { label: '', value: '', url_example: '' }
			}
			const val                     = extractSingleParamValue(urlEditor)
			card.buttons[index].value     = val
			if (paramBtn) {
				paramBtn.disabled = val.includes('{{1}}')
			}
			syncUrlCount()
			syncUrlExample()
			urlEditor.classList.toggle('is-invalid', val.length === 0)
			this._syncCards()
		})

		paramBtn?.addEventListener('click', () => {
			if (extractSingleParamValue(urlEditor).includes('{{1}}')) {
				return
			}
			insertChipAtCursor(urlEditor, makeUrlChip(''))
			if (card.buttons[index]) {
				card.buttons[index].value = extractSingleParamValue(urlEditor)
			}
			if (paramBtn) {
				paramBtn.disabled = true
			}
			syncUrlCount()
			this._syncCards()
		})
	}

	_createButtonSlot(card, index, type) {
		const btnData     = card.buttons[index] ?? { label: '', value: '', url_example: '' }
		const wrapper     = document.createElement('div')
		wrapper.innerHTML = this._buttonSlotHtml(type, btnData, index)
		const slot        = wrapper.firstElementChild
		this._wireButtonSlot(slot, card, index, type)
		return slot
	}

	_syncCards() {
		const cardValues = this._form.get("cards")
		if (!cardValues) {
			return
		}

		cardValues.set(JSON.stringify(this.getCards()))
	}

	_syncCardValidation() {
		if (this._disabled || this._cards.length >= WA_CAROUSEL_LIMITS.maxCards) {
			this._addCardComp.disabled()
		} else {
			this._addCardComp.enabled()
		}
	}

	//#endregion

	//#region Private — HTML

	_cardHtml(card, globalButtons) {
		const n           = this._cards.length
		const bodyLen     = (card.body ?? '').length
		const removeAttrs = this._disabled ? ' disabled' : ''
		const slotsHtml   = globalButtons.map((btn, i) =>
			this._buttonSlotHtml(btn.type, card.buttons[i] ?? {}, i)
		).join('')

		return `<div class="card-header d-flex justify-content-between align-items-center py-2">
			<span class="fw-semibold small">Card ${n}</span>
			<button type="button" class="btn btn-sm btn-outline-danger wa-card-remove"${removeAttrs}>
				<i class="ri-delete-bin-line"></i>
			</button>
		</div>
		<div class="card-body">
			<div class="mb-3">
				<label class="form-label fw-semibold small mb-1">Media</label>
				<small class="text-muted d-block mb-2 wa-card-media-info">${this._mediaTypeHint(this._currentMediaType)}</small>
				<div class="d-flex gap-3 mb-2">
					<div class="form-check">
						<input class="form-check-input wa-card-media-mode" type="radio"
							id="wa-card-media-url-${card.id}"
							name="wa-card-media-mode-${card.id}" value="url" checked>
						<label class="form-check-label small" for="wa-card-media-url-${card.id}">URL</label>
					</div>
					<div class="form-check">
						<input class="form-check-input wa-card-media-mode" type="radio"
							id="wa-card-media-upload-${card.id}"
							name="wa-card-media-mode-${card.id}" value="upload">
						<label class="form-check-label small" for="wa-card-media-upload-${card.id}">Upload</label>
					</div>
				</div>
				<input type="text" class="form-control form-control-sm wa-card-media-url"
					value="${esc(card.mediaUrl ?? '')}"
					placeholder="Paste a public media URL...">
				<div class="wa-card-dropzone-wrap d-none">
					${this._dropzoneHtml(card.id)}
				</div>
			</div>

			<div class="mb-3">
				<label class="form-label fw-semibold small mb-1">Body</label>
				<div class="border rounded">
					<div class="d-flex gap-1 p-2 border-bottom bg-light rounded-top flex-wrap">
						<button type="button" class="btn btn-sm btn-outline-secondary" data-wa-format="bold" title="Bold"><b>B</b></button>
						<button type="button" class="btn btn-sm btn-outline-secondary" data-wa-format="italic" title="Italic"><em>I</em></button>
						<button type="button" class="btn btn-sm btn-outline-secondary" data-wa-format="strikethrough" title="Strikethrough"><s>S</s></button>
						<button type="button" class="btn btn-sm btn-outline-secondary" data-wa-format="code" title="Monospace"><></button>
						<button type="button" class="btn btn-sm btn-outline-secondary wa-card-param-btn" title="Parameter">{{ }} Param</button>
					</div>
					<div class="form-control border-0 rounded-0 rounded-bottom wa-body-editor wa-card-body-editor"
						contenteditable="true"
						data-placeholder="Card text..."></div>
				</div>
				<div class="d-flex justify-content-end mt-1">
					<small class="text-muted wa-card-body-count">${bodyLen} / ${WA_CAROUSEL_LIMITS.bodyMaxChars}</small>
				</div>
			</div>

			${globalButtons.length > 0 ? `<div class="wa-card-btn-slots">${slotsHtml}</div>` : ''}
		</div>`
	}

	_dropzoneHtml(cardId) {
		return `<div class="dropzone dropzone-sm mb-0" data-card-dropzone="${cardId}">
			<div class="fallback">
				<input name="file" type="file">
			</div>
			<div class="dz-message needsclick">
				<h6>Drop file here or click to upload.</h6>
			</div>
		</div>`
	}

	_buttonSlotHtml(type, btnData, index) {
		const isQR             = type === 'quick_reply'
		const isUrl            = type === 'url'
		const typeLabel        = this._buttonTypeLabel(type)
		const valueLabel       = isUrl ? 'URL' : type === 'phone_number' ? 'Phone' : ''
		const valuePlaceholder = type === 'phone_number' ? '+62...' : ''
		const labelLen         = (btnData.label ?? '').length
		const valueLen         = (btnData.value ?? '').length
		const hasParam         = isUrl && (btnData.value ?? '').includes('{{1}}')

		return `<div class="wa-card-btn-slot border rounded p-2 mb-2" data-slot-index="${index}">
			<div class="mb-2">
				<span class="badge bg-secondary wa-slot-type-label">${typeLabel}</span>
			</div>
			<div class="mb-2">
				<label class="form-label fw-semibold small mb-1">Label</label>
				<input type="text" class="form-control form-control-sm wa-slot-label"
					value="${esc(btnData.label ?? '')}"
					maxlength="${WA_CAROUSEL_LIMITS.labelMaxChars}"
					placeholder="Button text...">
				<div class="d-flex justify-content-end mt-1">
					<small class="text-muted wa-slot-label-count">${labelLen}/${WA_CAROUSEL_LIMITS.labelMaxChars}</small>
				</div>
			</div>
			<div class="wa-slot-value-wrap${isQR ? ' d-none' : ''}">
				<div class="d-flex justify-content-between align-items-center mb-1">
					<label class="form-label fw-semibold small mb-0 wa-slot-value-label">${valueLabel}</label>
					<button type="button" class="btn btn-sm btn-outline-secondary wa-slot-url-param-btn${isUrl ? '' : ' d-none'}"${hasParam ? ' disabled' : ''}>
						{{ }} Param
					</button>
				</div>
				<div class="wa-slot-url-editor-wrap${isUrl ? '' : ' d-none'}">
					<div class="form-control form-control-sm wa-slot-url-editor"
						contenteditable="true"
						data-placeholder="https://..."></div>
				</div>
				<input type="text" class="form-control form-control-sm wa-slot-value${isUrl ? ' d-none' : ''}"
					value="${esc(isUrl ? '' : (btnData.value ?? ''))}"
					placeholder="${valuePlaceholder}"
					maxlength="${WA_CAROUSEL_LIMITS.urlMaxChars}">
				<div class="d-flex justify-content-end mt-1">
					<small class="text-muted wa-slot-value-count">${valueLen}/${WA_CAROUSEL_LIMITS.urlMaxChars}</small>
				</div>
			</div>
		</div>`
	}

	_buttonTypeLabel(type) {
		const map = {
			quick_reply : 'Quick Reply',
			url         : 'URL',
			phone_number: 'Phone Number',
		}
		return map[type] ?? type
	}

	_mediaTypeHint(typeId) {
		if (typeId === WaTemplateHeaderType.Video) {
			return 'MP4 / 3GP — max 16MB'
		}
		return 'JPG / PNG — max 5MB'
	}

	_revokeBlobUrl(url) {
		if (url?.startsWith('blob:')) {
			URL.revokeObjectURL(url)
		}
	}

	//#endregion
}
