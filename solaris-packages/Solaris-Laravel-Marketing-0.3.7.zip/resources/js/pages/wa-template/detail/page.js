import SolarEditPage from "@core-js/solaris/solar/solar-edit-page"
import { WaTemplateCategory, WaTemplateHeaderType, WaTemplateSubType, WaTemplateLanguage, WaTemplateAuthBody, WaTemplateStatus } from "@marketing-js/const"
import WhatsAppPreview from "@marketing-js/solaris/whatsapp-preview"
import WaTemplateContent from "./content"
import WaTemplateButtons from "./buttons"
import WaTemplateCarousel from "./carousel"

const CAROUSEL_TAB_ID = 'wa-template-page-tabs_message_carousel'
const BUTTONS_TAB_ID  = 'wa-template-page-tabs_message_buttons'

export default class WaTemplateDetailPage extends SolarEditPage
{
	init() {
		/** @type {WhatsAppPreview} */
		this._preview  = this.get("wa-template-page-preview")
		this._disabled = document.getElementById('wa-template-page-disabled')?.value === '1'

		const name = this.form.get("name")
		name?.on('input',(value) => this.breadcrumbName.innerText = value, "WaTemplatePage")

		this._content = new WaTemplateContent(
			this.form,
			() => this.renderPreview(),
			this._disabled
		)

		this._buttonsModule = new WaTemplateButtons(
			this.form,
			() => this.renderPreview(),
			this._disabled
		)

		this._carouselModule = new WaTemplateCarousel(
			this.form,
			(typeId) => {
				this.form.get('header_type_id')?.set(typeId, true)
				this.renderPreview()
			},
			() => this.renderPreview(),
			this._disabled
		)

		this.form.exclude([
			'wa-carousel-media-type', 
			'wa-template-page-status',  
			'media_mode',
			'name',
		])

		this._tabs = this.get('wa-template-page-tabs')

		this._prevSubTypeId = this.form.get("sub_type_id")?.get()?.id ?? null

		this._content.init()
		this._buttonsModule.init()
		this._carouselModule.init(this._buttonsModule.getCarouselSchema())

		this._initSubTypeListener()
		this._onSubTypeChange(true)

		this.renderPreview()
	}

	renderPreview() {
		if (!this._preview) {
			return
		}

		const categoryId = this.form.get('category_id')?.get()
		const subTypeId  = this.form.get('sub_type_id')?.get()?.id
		const isAuth     = categoryId === WaTemplateCategory.Authentication
		const isCarousel = categoryId === WaTemplateCategory.Marketing
		                && subTypeId  === WaTemplateSubType.Carousel

		if (isAuth) {
			this._renderAuthPreview()
			return
		}

		if (isCarousel) {
			this._renderCarouselPreview()
			return
		}

		const headerType    = this.form.get("header_type_id")
		const headerContent = this.form.get("header_content")
		const mediaMode     = this.form.get("media_mode")
		const body          = this.form.get('body').get() ?? ''
		const footer        = this.form.get('footer').get() ?? ''

		const typeMap = {
			[WaTemplateHeaderType.Text]    : 'text',
			[WaTemplateHeaderType.Image]   : 'image',
			[WaTemplateHeaderType.Video]   : 'video',
			[WaTemplateHeaderType.Document]: 'document',
		}

		let headerValue = headerContent.get()
		if (mediaMode?.get()?.id === 'upload' && this._content.headerMediaLocalUrl) {
			headerValue = this._content.headerMediaLocalUrl
		}

		const header = headerType.get() ? { type: typeMap[headerType.get().id], value: headerValue } : null

		this._preview.clearMessages()
		this._preview.addTemplateMessage({
			id     : 'main',
			header : header,
			text   : body,
			footer,
			buttons: this._buttonsModule.getButtons(),
		})
	}

	async invalid(result) {
		if (result.errors.body) {
			const bodyField = this.form.get("body")
			const editor = document.getElementById('wa-template-body-content-editor')
			bodyField.error()
			bodyField.setMessage(result.errors.body)
			editor?.closest('.border.rounded')?.classList.add('is-invalid')
			bodyField._message.style.display = 'block'
		}
	}

	async submitting() {
		const categoryId = this.form.get('category_id')?.get()
		const subTypeId  = this.form.get('sub_type_id')?.get()?.id
		const isAuth     = categoryId === WaTemplateCategory.Authentication
		const isCarousel = categoryId === WaTemplateCategory.Marketing
		                && subTypeId  === WaTemplateSubType.Carousel

		if (isAuth) {
			this._validateAuthSubmit()
			return
		}

		if (isCarousel) {
			this._validateCarouselSubmit()
			return
		}

		this._validateNormalSubmit()
	}

	/**
	 * Validate authentication template before submit.
	 * @returns {void}
	 */
	_validateAuthSubmit() {
		const limits = WaTemplateLimits.limits
		const expiry = this.form.get('expiry_minutes')?.get()
		const hasExp = expiry !== null && expiry !== '' && expiry !== undefined

		if (hasExp) {
			const exp = Number(expiry)
			if (isNaN(exp) || exp < limits.auth_expiry_min || exp > limits.auth_expiry_max) {
				this.form.hiddenErrorAlert()
				this.helper.toast({ message: `Expiry minutes must be between ${limits.auth_expiry_min} and ${limits.auth_expiry_max}.`, color: "danger" })
				throw null
			}
		}

		this.form.showErrorAlert()
	}

	/**
	 * Validate carousel template before submit.
	 * @returns {void}
	 */
	_validateCarouselSubmit() {
		const limits = WaTemplateLimits.limits

		this._carouselModule.clearButtonValidation()

		const cards = this._carouselModule.getCardsForPreview()
		if (cards.length < limits.carousel_min_cards) {
			this._tabs?.setActive(CAROUSEL_TAB_ID)
			this.form.hiddenErrorAlert()
			this.helper.toast({ message: `Carousel requires at least ${limits.carousel_min_cards} cards.`, color: "danger" })
			throw null
		}

		if (!this._carouselModule.validateButtonSlots()) {
			this._tabs?.setActive(CAROUSEL_TAB_ID)
			this.form.hiddenErrorAlert()
			this.helper.toast({ message: "Some fields are invalid or incomplete. Please check again.", color: "danger" })
			throw null
		}

		this.form.showErrorAlert()
	}

	/**
	 * Validate regular/utility template before submit.
	 * @returns {void}
	 */
	_validateNormalSubmit() {
		const mediaHeaderTypes = [
			WaTemplateHeaderType.Image,
			WaTemplateHeaderType.Video,
			WaTemplateHeaderType.Document,
		]
		const headerType = this.form.get('header_type_id')?.get()

		if (headerType && mediaHeaderTypes.includes(headerType.id)) {
			const mediaMode     = this.form.get('media_mode')?.get()?.id
			const headerContent = this.form.get('header_content')?.get()
			const hasUpload     = this._content.hasHeaderUpload()
			const isInvalid     = mediaMode === 'url' ? !headerContent : !hasUpload

			if (isInvalid) {
				this._tabs?.setActive('wa-template-page-tabs_message_content')
				this.form.hiddenErrorAlert()
				this.helper.toast({ message: "Header media is required.", color: "danger" })
				throw null
			}
		}

		const buttons    = this._buttonsModule.getButtonsData()
		const valueTypes = ['url', 'phone_number', 'copy_code']

		this._buttonsModule.clearValidation()

		if (buttons.length === 0) {
			this.form.showErrorAlert()
			return
		}

		let isError = false
		for (let i = 0; i < buttons.length; i++) {
			const btn = buttons[i]
			if (!btn.label?.trim()) {
				this._buttonsModule.markInvalid(btn.id, 'label')
				isError = true
			}
			if (valueTypes.includes(btn.type) && !btn.value?.trim()) {
				this._buttonsModule.markInvalid(btn.id, 'value')
				isError = true
			}
		}

		if (isError) {
			this._tabs?.setActive(BUTTONS_TAB_ID)
			this.form.hiddenErrorAlert()
			this.helper.toast({ message: "Some fields are invalid or incomplete. Please check again.", color: "danger" })
			throw null
		}

		this.form.showErrorAlert()
	}

	async success(response) {
		const hasHeader   = this._content.hasHeaderUpload()
		const hasCarousel = this._carouselModule.hasPendingUploads()

		if (!hasHeader && !hasCarousel) {
			return
		}

		try {
			const [headerAttachmentId, cardAttachments] = await Promise.all([
				hasHeader   ? this._content.triggerHeaderUpload(this.id) : Promise.resolve(null),
				hasCarousel ? this._carouselModule.triggerAllUploads(this.id) : Promise.resolve([]),
			])

			const payload = { id: this.id }
			if (headerAttachmentId) {
				payload.header_attachment_id = headerAttachmentId
			}
			if (cardAttachments.length > 0) {
				payload.card_attachments = cardAttachments
			}

			const req = await this.axios({
				method: 'POST',
				url   : `${BASE_URL}/marketing/wa-template/update-media`,
				data  : payload,
			})

			if (!req.data.success) {
				throw req.data.message ?? 'Media update failed'
			}

			await this.refresh()
		} catch (error) {
			this.helper.errorAlert({ title: error?.message ?? error ?? 'Upload failed' })
		}
	}

	async onRefreshed(data) {
		this.breadcrumbName.innerText = data.language.name

		this.form.set("status_id", data.status?.name ?? '')
		this.form.set("category_id", data.wa_template?.category_id ?? '')

		this._prevSubTypeId = data.sub_type_id
		this._disabled      = data.status_id !== WaTemplateStatus.Draft

		this._syncSubTypeFieldState(data.wa_template?.category_id)

		this._content.reset(this._disabled)
		this._buttonsModule.reset(this._disabled)
		this._carouselModule.reset(this._buttonsModule.getCarouselSchema(), this._disabled)

		this._onSubTypeChange(true)

		this.renderPreview()
	}

	/**
	 * Enable or disable the sub_type field based on status and category.
	 * Mirrors the blade logic: enabled only when status is Draft AND category is Marketing.
	 * @param {string|null} categoryId
	 * @returns {void}
	 */
	_syncSubTypeFieldState(categoryId) {
		const subTypeField = this.form.get('sub_type_id')
		const isMarketing  = categoryId === WaTemplateCategory.Marketing

		if (this._disabled || !isMarketing) {
			subTypeField?.disabled()
		} else {
			subTypeField?.enabled()
		}
	}

	_initSubTypeListener() {
		const category = this.form.get("category_id")
		const subType  = this.form.get("sub_type_id")

		subType.on("change", async (val) => {
			const subTypeId = val?.id ?? null
			if (category.get() !== WaTemplateCategory.Marketing) {
				return
			}

			const toCarousel   = subTypeId === WaTemplateSubType.Carousel
			const fromCarousel = this._prevSubTypeId === WaTemplateSubType.Carousel

			const confirmTitle = toCarousel && this._hasContentValues() ? 
				'Switch to Carousel?' : 
				fromCarousel && this._carouselModule.hasContent() ? 'Switch to Regular?' : null
			
			const confirmMessage = toCarousel && this._hasContentValues() ? 
				'Header and footer will be reset. Continue?' : 
				fromCarousel && this._carouselModule.hasContent() ? 'All carousel cards will be reset. Continue?' : null

			if (confirmTitle && !await this.helper.confirm({ title: confirmTitle, message: confirmMessage })) {
				subType.set(this._prevSubTypeId, true)
				return
			}

			this._prevSubTypeId = subTypeId
			this._onSubTypeChange(false)
		})
	}

	_onSubTypeChange(isInitial) {
		const categoryId = this.form.get('category_id')?.get()
		const subTypeId  = this.form.get('sub_type_id')?.get()?.id
		const isAuth     = categoryId === WaTemplateCategory.Authentication
		const isCarousel = categoryId === WaTemplateCategory.Marketing
		                && subTypeId  === WaTemplateSubType.Carousel

		if (isAuth) {
			if (this._tabs?.getActive() === CAROUSEL_TAB_ID) {
				this._tabs.setActive('wa-template-page-tabs_message_content')
			}
			this._tabs?.hide(CAROUSEL_TAB_ID)

			const languageId = this.form.get('language_id')?.get()?.id
			this._content.applyAuthContent(languageId, isInitial)
			this._buttonsModule.applyAuthButtons(isInitial)
			this._carouselModule.applyNormalMode(isInitial)
		} else if (isCarousel) {
			this._tabs?.show(CAROUSEL_TAB_ID)
			this._content.applyCarouselContent(isInitial)
			this._buttonsModule.applyCarouselButtons(isInitial, (schema) => {
				this._carouselModule.onGlobalButtonSchemaChange(schema)
				this.renderPreview()
			})
			this._carouselModule.applyCarouselMode(isInitial)
		} else {
			if (this._tabs?.getActive() === CAROUSEL_TAB_ID) {
				this._tabs.setActive('wa-template-page-tabs_message_content')
			}
			this._tabs?.hide(CAROUSEL_TAB_ID)
			this._content.applyNormalContent(isInitial)
			this._buttonsModule.applyNormalButtons(isInitial)
			this._carouselModule.applyNormalMode(isInitial)
		}

		if(isAuth) {
			this.form.get("body").optional()
		} else {
			this.form.get("body").required()
		}

		if (!isInitial) {
			this.renderPreview()
		}
	}

	_renderAuthPreview() {
		const languageId = this.form.get('language_id')?.get()?.id
		const fallback   = WaTemplateAuthBody[WaTemplateLanguage.English]
		let body         = WaTemplateAuthBody[languageId] ?? fallback

		const disclaimerVal = this.form.get('disclaimer')?.get()
		const isDisclaimer  = !!disclaimerVal
		if (isDisclaimer) {
			const disclaimerText = {
				[WaTemplateLanguage.English]   : " For your security, do not share this code.",
				[WaTemplateLanguage.Indonesian]: " Demi keamanan Anda, jangan bagikan kode ini.",
			}
			body += disclaimerText[languageId] ?? disclaimerText[WaTemplateLanguage.English]
		}

		const expiryMinutes = this.form.get('expiry_minutes')?.get()
		let footer          = null
		if (expiryMinutes) {
			const expiryText = {
				[WaTemplateLanguage.English]   : `This code expires in ${expiryMinutes} minutes.`,
				[WaTemplateLanguage.Indonesian]: `Kode ini berlaku ${expiryMinutes} menit.`,
			}
			footer = expiryText[languageId] ?? expiryText[WaTemplateLanguage.English]
		}

		this._preview.clearMessages()
		this._preview.addTemplateMessage({
			id     : 'main',
			header : null,
			text   : body,
			footer,
			buttons: this._buttonsModule.getButtons(),
		})
	}

	_renderCarouselPreview() {
		const body      = this.form.get('body').get() ?? ''
		const cards     = this._carouselModule.getCardsForPreview()
		const schema    = this._buttonsModule.getCarouselSchema()
		const typeId    = this.form.get('header_type_id')?.get()?.id
		const mediaType = typeId === WaTemplateHeaderType.Video ? 'video' : 'image'

		const previewCards = cards.map(card => ({
			id        : card.id,
			media_type: mediaType,
			src       : card.header_content,
			body      : card.body,
			buttons   : (card.buttons ?? []).map((btn, i) => ({
				type : schema[i]?.type ?? 'quick_reply',
				label: btn.label,
			})),
		}))

		this._preview.clearMessages()
		this._preview.addCarousel({ text: body, cards: previewCards })
	}

	_hasContentValues() {
		const body         = this.form.get('body')?.get() ?? ''
		const footer       = this.form.get('footer')?.get() ?? ''
		const header       = this.form.get('header_content')?.get() ?? ''
		const headerUpload = this._content.headerMediaLocalUrl !== null
		return body.length > 0 || footer.length > 0 || header.length > 0 || headerUpload
	}

	_hasAuthValues() {
		const disclaimer    = this.form.get('disclaimer')?.get()
		const expiryMinutes = this.form.get('expiry_minutes')?.get()
		return !!disclaimer || Number(expiryMinutes) > 0
	}
}
