import SolarSingleton from "@core-js/solaris/solar/solar-singleton"
import { WaTemplateCategory, WaTemplateHeaderType, WaTemplateLanguage, WaTemplateAuthBody } from "@marketing-js/const"
import {
	updateCharCount,
	showSamplePopover,
	createSingleParamChip,
	extractSingleParamValue,
	renderSingleParamEditor,
	insertChipAtCursor,
	enforceCharLimit,
	extractBodyValue,
	renderBodyEditor,
	applyBodyFormat,
	renumberBodyParams,
	syncBodyExamples,
} from "./editor-utils"

const { limits: _limits, media_constraints: _mediaConstraints } = WaTemplateLimits

const WA_TEMPLATE_LIMITS = {
	headerMaxChars: _limits.header_max_chars,
	footerMaxChars: _limits.footer_max_chars,
	bodyMaxChars  : _limits.body_max_chars,
	bodyMaxParams : _limits.body_max_params,
}

const MEDIA_CONSTRAINTS = {
	[WaTemplateHeaderType.Image]   : { exts: _mediaConstraints.image.exts,    maxBytes: _mediaConstraints.image.max_mb },
	[WaTemplateHeaderType.Video]   : { exts: _mediaConstraints.video.exts,    maxBytes: _mediaConstraints.video.max_mb },
	[WaTemplateHeaderType.Document]: { exts: _mediaConstraints.document.exts, maxBytes: _mediaConstraints.document.max_mb },
}

export default class WaTemplateContent {
	constructor(form, renderPreview, disabled = false) {
		this._form                 = form
		this._solarUI              = SolarSingleton.getSolarUI()
		this._renderPreview        = renderPreview
		this._disabled             = disabled
		this._headerMediaLocalUrl  = null
		this._popoverCleanup       = null
		this._headerContentUpload  = null
		this._headerUploadResolver = null
		this._headerUploadRejecter = null
	}

	get headerMediaLocalUrl() {
		return this._headerMediaLocalUrl
	}

	//#region Public init

	init() {
		this.initHeaderType()
		this.initBody()
		this.initFooter()
		this.initLanguageSync()
		this.initAuthFooter()
	}

	applyAuthContent(languageId, isInitial) {
		document.getElementById('wa-template-header-section')?.classList.add('d-none')

		document.getElementById('wa-template-body-section')?.classList.add('d-none')
		document.getElementById('wa-template-auth-body-preview')?.classList.remove('d-none')
		this._updateAuthBodyPreview(languageId)

		document.getElementById('wa-template-footer-section')?.classList.add('d-none')
		document.getElementById('wa-template-auth-footer-wrap')?.classList.remove('d-none')

		if (isInitial) {
			return
		}

		this._form.get('header_type_id').set(null)
		this._form.get('header_content').set('')
		this._form.get('header_examples').set(null)

		const bodyEditor = document.getElementById('wa-template-body-content-editor')
		if (bodyEditor) {
			bodyEditor.innerHTML = ''
		}
		this._form.get('body').set('')
		this._form.get('body_examples').set(null)
		updateCharCount('wa-template-body-count', 0, WA_TEMPLATE_LIMITS.bodyMaxChars)

		this._form.get('footer').set('')
		updateCharCount('wa-template-footer-count', 0, WA_TEMPLATE_LIMITS.footerMaxChars)

		this._form.get('disclaimer').set(false)
		this._form.get('expiry_minutes').set(null)
		this._form.set('header_type_id', null, true)
	}

	applyNormalContent(isInitial) {
		document.getElementById('wa-template-header-section')?.classList.remove('d-none')

		document.getElementById('wa-template-body-section')?.classList.remove('d-none')
		document.getElementById('wa-template-auth-body-preview')?.classList.add('d-none')

		document.getElementById('wa-template-footer-section')?.classList.remove('d-none')
		document.getElementById('wa-template-auth-footer-wrap')?.classList.add('d-none')

		if (isInitial) {
			return
		}

		this._form.get('disclaimer').set(false)
		this._form.get('expiry_minutes').set(null)
		this._form.set('header_type_id', null, true)
	}

	applyCarouselContent(isInitial) {
		document.getElementById('wa-template-header-section')?.classList.add('d-none')
		document.getElementById('wa-template-footer-section')?.classList.add('d-none')

		document.getElementById('wa-template-body-section')?.classList.remove('d-none')
		document.getElementById('wa-template-auth-body-preview')?.classList.add('d-none')
		document.getElementById('wa-template-auth-footer-wrap')?.classList.add('d-none')

		if (isInitial) {
			return
		}

		this._form.set('header_type_id', WaTemplateHeaderType.Image, true)
		this._form.get('header_content').set('')
		this._form.get('header_content_url').set('')
		this._form.get('header_examples').set(null)
		this._form.get('footer').set('')
		updateCharCount('wa-template-footer-count', 0, WA_TEMPLATE_LIMITS.footerMaxChars)
	}

	initLanguageSync() {
		const language = this._form.get('language_id')
		const category = this._form.get('category_id')

		language.on('change', (val) => {
			if (category.get()?.id !== WaTemplateCategory.Authentication) {
				return
			}
			this._updateAuthBodyPreview(val?.id)
			this._renderPreview()
		})
	}

	initAuthFooter() {
		const disclaimerField = this._form.get('disclaimer')
		const expiryField     = this._form.get('expiry_minutes')

		disclaimerField.on("change", (val) => this._renderPreview())
		expiryField.on("input", (val) => this._renderPreview())
	}

	initHeaderType() {
		this._initHeaderText()
		this._initHeaderMedia()

		const headerType = this._form.get("header_type_id")
		headerType.on("change", () => this._renderPreview())
	}

	initBody() {
		const bodyField = this._form.get("body")
		const editor    = document.getElementById('wa-template-body-content-editor')

		const paramBtn     = document.getElementById('wa-template-body-param-btn')
		const syncParamBtn = () => {
			const count = editor.querySelectorAll('[data-param]').length
			if (paramBtn) {
				paramBtn.disabled = count >= WA_TEMPLATE_LIMITS.bodyMaxParams
			}
		}

		const syncValue = () => {
			renumberBodyParams(editor)
			const val     = extractBodyValue(editor)
			const wrapper = editor?.closest('.border.rounded')
			bodyField.set(val)
			this._syncBodyExamples(editor)
			this._onBodyChange(val)
			syncParamBtn()

			if (val.length === 0) {
				wrapper?.classList.add('is-invalid')
			} else {
				wrapper?.classList.remove('is-invalid')
				bodyField._message.style.display = ''
			}
		}

		const initVal      = bodyField.get() ?? ''
		const initExamples = (() => {
			try { 
				return JSON.parse(this._form.get('body_examples').get() ?? '{}') 
			} catch { 
				return {} 
			}
		})()
		this._renderBodyEditor(editor, initVal, initExamples)
		syncParamBtn()

		editor?.addEventListener('beforeinput', (e) => {
			enforceCharLimit(editor, extractBodyValue, WA_TEMPLATE_LIMITS.bodyMaxChars, e)
		})

		editor?.addEventListener('input', () => {
			if (extractBodyValue(editor) === '') {
				editor.innerHTML = ''
			}
			syncValue()
		})

		editor?.addEventListener('keydown', e => {
			if (e.ctrlKey) {
				const formatMap = {
					'b': { shift: false, format: 'bold' },
					'i': { shift: false, format: 'italic' },
					'X': { shift: true,  format: 'strikethrough' },
					'M': { shift: true,  format: 'code' },
				}
				const hit = formatMap[e.key]
				if (hit && e.shiftKey === hit.shift) {
					e.preventDefault()
					applyBodyFormat(editor, hit.format)
					editor.normalize()
					syncValue()
					return
				}

				if (e.shiftKey && e.key === 'P') {
					e.preventDefault()
					this._insertBodyParamChip(editor)
					syncValue()
					return
				}
			}

			if (e.key !== 'Enter') {
				return
			}

			e.preventDefault()
			const sel = window.getSelection()
			if (!sel.rangeCount) {
				return
			}

			const range = sel.getRangeAt(0)
			range.deleteContents()

			const br = document.createElement('br')
			range.insertNode(br)

			const afterBr = br.nextSibling
			if (afterBr?.nodeType === Node.TEXT_NODE && afterBr.textContent === '') {
				afterBr.remove()
			}

			const newRange = document.createRange()
			if (!br.nextSibling) {
				const sentinel = document.createElement('br')
				br.after(sentinel)
				newRange.setStartBefore(sentinel)
			} else {
				newRange.setStartAfter(br)
			}

			newRange.collapse(true)
			sel.removeAllRanges()
			sel.addRange(newRange)
			syncValue()
		})

		editor?.addEventListener('paste', e => {
			e.preventDefault()
			const text = e.clipboardData.getData('text/plain')
			if (!text) {
				return
			}
			const sel = window.getSelection()
			if (!sel.rangeCount) {
				return
			}
			const range       = sel.getRangeAt(0)
			const selectedLen = range.toString().length
			const currentLen  = extractBodyValue(editor).length
			const available   = WA_TEMPLATE_LIMITS.bodyMaxChars - (currentLen - selectedLen)
			const clipped     = text.slice(0, Math.max(0, available))
			if (!clipped) {
				return
			}
			range.deleteContents()
			const textNode = document.createTextNode(clipped)
			range.insertNode(textNode)
			range.setStartAfter(textNode)
			range.collapse(true)
			sel.removeAllRanges()
			sel.addRange(range)
			syncValue()
		})

		document.querySelectorAll('[data-wa-format]').forEach(btn => {
			btn.addEventListener('mousedown', e => {
				e.preventDefault()
			})
			btn.addEventListener('click', () => {
				applyBodyFormat(editor, btn.dataset.waFormat)
				editor.normalize()
				syncValue()
			})
		})

		document.getElementById('wa-template-body-param-btn')?.addEventListener('click', () => {
			this._insertBodyParamChip(editor)
			syncValue()
		})

		this._onBodyChange(initVal)

		if (this._disabled) {
			this._syncEditorDisabledState()
		}
	}

	/**
	 * Sync contentEditable and toolbar button states for body and header editors.
	 * Handles both disabling and re-enabling. Must be called after _syncHeaderState()
	 * in reset() so it overrides any var-button state set by _syncHeaderState().
	 * @returns {void}
	 */
	_syncEditorDisabledState() {
		const bodyEditor = document.getElementById('wa-template-body-content-editor')
		if (bodyEditor) {
			bodyEditor.contentEditable = this._disabled ? 'false' : 'true'
		}
		document.querySelectorAll('[data-wa-format]').forEach(btn => {
			btn.disabled = this._disabled
		})
		const paramBtn = document.getElementById('wa-template-body-param-btn')
		if (paramBtn) {
			paramBtn.disabled = this._disabled
		}

		if (this._headerTextEditor) {
			this._headerTextEditor.contentEditable = this._disabled ? 'false' : 'true'
		}
		if (this._headerVarButton) {
			if (this._disabled) {
				this._headerVarButton.disabled = true
			} else {
				this._headerVarButton.disabled = this._headerTextEditor
					? extractSingleParamValue(this._headerTextEditor).includes('{{1}}')
					: false
			}
		}
	}

	/**
	 * Sync disabled state for form fields that respect the $disabled flag.
	 * Only called from reset() since blade handles the initial state on page load.
	 * @returns {void}
	 */
	_syncFormFieldsDisabledState() {
		const fields = ['header_type_id', 'body', 'footer', 'disclaimer', 'expiry_minutes', 'media_mode', 'header_content_url']
		fields.forEach(name => {
			const field = this._form.get(name)
			if (!field) {
				return
			}
			if (this._disabled) {
				field.disabled()
			} else {
				field.enabled()
			}
		})
	}

	initFooter() {
		const footer = this._form.get("footer")
		footer._plugin._element.maxLength = WA_TEMPLATE_LIMITS.footerMaxChars
		updateCharCount('wa-template-footer-count', footer.get().length, WA_TEMPLATE_LIMITS.footerMaxChars)

		footer.on('input', (val) => {
			updateCharCount('wa-template-footer-count', val.length, WA_TEMPLATE_LIMITS.footerMaxChars)
			this._renderPreview()
		})
	}

	reset(disabled = this._disabled) {
		this._disabled = disabled

		// Re-render body editor from current form values
		const bodyField    = this._form.get("body")
		const bodyEditor   = document.getElementById('wa-template-body-content-editor')
		const bodyExamples = (() => {
			try { return JSON.parse(this._form.get('body_examples').get() ?? '{}') } catch { return {} }
		})()
		if (bodyEditor) {
			this._renderBodyEditor(bodyEditor, bodyField.get() ?? '', bodyExamples)
			this._onBodyChange(bodyField.get() ?? '')
		}

		// Reset blob and dropzone
		this._revokeBlobUrl(this._headerMediaLocalUrl)
		this._headerMediaLocalUrl = null
		this._headerContentUpload?.clear()

		// Reset media_mode ke URL secara silent (non-silent trigger event pada radio yang di-deselect → val null → crash)
		// Lalu sync UI manual: show URL input, hide dropzone
		this._form.get('media_mode').set('url', true)
		this._form.get('header_content_url').show()
		if (this._headerContentUpload) {
			this._headerContentUpload._element?.classList.add('d-none')
		}

		// Sync URL input value with header_content (server data is always URL)
		this._form.get('header_content_url').set(this._form.get('header_content').get() ?? '', true)

		// Re-render header editor + sync section visibility
		this._syncHeaderState()

		// Sync editor and form field disabled states (after _syncHeaderState so var-button override holds)
		this._syncEditorDisabledState()
		this._syncFormFieldsDisabledState()

		// Sync footer char count
		updateCharCount('wa-template-footer-count', (this._form.get("footer").get() ?? '').length, WA_TEMPLATE_LIMITS.footerMaxChars)
	}

	//#endregion

	//#region Header

	_syncHeaderState() {
		const headerType = this._form.get("header_type_id")
		const typeId     = headerType.get()?.id
		const isText     = typeId === WaTemplateHeaderType.Text

		// Re-render text editor content
		if (this._headerTextEditor) {
			this._headerTextEditor.innerHTML = ''
			if (isText && this._form.get('header_content').get()) {
				const initExample = (() => {
					try { return JSON.parse(this._form.get('header_examples')?.get() ?? '{}')['1'] ?? '' } catch { return '' }
				})()
				renderSingleParamEditor(this._headerTextEditor, this._form.get('header_content').get(), initExample, this._makeHeaderChip)
			}
		}

		// Show/hide header type sections
		const headerContent = this._form.get("header_content")
		if (isText) {
			headerContent.show()
			this._headerVarWrap?.classList.remove('d-none')
		} else {
			headerContent.hidden()
			this._headerVarWrap?.classList.add('d-none')
		}

		const headerMediaWrap = document.querySelector('#wa-template-header-media-wrap')
		if (typeId && !isText) {
			headerMediaWrap?.classList.remove('d-none')
			const constraint = MEDIA_CONSTRAINTS[typeId]
			if (constraint && this._headerContentUpload) {
				this._headerContentUpload.setAcceptFiles(constraint.exts.join(','))
				this._headerContentUpload.setMaxFileSize(constraint.maxBytes)
			}
		} else {
			headerMediaWrap?.classList.add('d-none')
		}

		// Sync var button state and char count
		if (this._headerVarButton && this._headerTextEditor) {
			this._headerVarButton.disabled = extractSingleParamValue(this._headerTextEditor).includes('{{1}}')
		}
		updateCharCount(
			'wa-template-header-count',
			this._headerTextEditor ? extractSingleParamValue(this._headerTextEditor).length : 0,
			WA_TEMPLATE_LIMITS.headerMaxChars
		)
	}

	_initHeaderText() {
		const headerType      = this._form.get("header_type_id")
		const headerContent   = this._form.get("header_content")
		const headerVarWrap   = document.querySelector('#wa-template-header-var-wrap')
		const headerVarButton = headerVarWrap?.querySelector('button')
		const editor          = document.querySelector('#wa-template-header-content-editor')

		const makeChip = (sample) => createSingleParamChip(
			'wa-header-var-chip', sample,
			(e, span) => this._popover(e, span, () => this._syncHeaderExample(editor))
		)

		this._headerTextEditor = editor
		this._headerVarWrap    = headerVarWrap
		this._headerVarButton  = headerVarButton
		this._makeHeaderChip   = makeChip

		const syncValue     = () => {
			headerContent.set(extractSingleParamValue(editor))
			this._syncHeaderExample(editor)
		}
		const syncVarButton = () => { headerVarButton.disabled = extractSingleParamValue(editor).includes('{{1}}') }
		const syncCount     = () => updateCharCount('wa-template-header-count', extractSingleParamValue(editor).length, WA_TEMPLATE_LIMITS.headerMaxChars)

		const initVal           = headerContent.get() ?? ''
		const initHeaderExample = (() => {
			try { 
				return JSON.parse(this._form.get('header_examples')?.get() ?? '{}')['1'] ?? '' 
			} catch { return '' }
		})()
		if (initVal) {
			renderSingleParamEditor(editor, initVal, initHeaderExample, makeChip)
		}

		headerType.on("change", (val) => {
			if (val && val.id == WaTemplateHeaderType.Text) {
				headerContent.show()
				headerVarWrap.classList.remove('d-none')
			} else {
				headerContent.hidden()
				headerVarWrap.classList.add('d-none')
				if (editor) {
					editor.innerHTML = ''
				}
				syncValue()
			}
			syncVarButton()
			syncCount()
		})

		editor?.addEventListener('keydown', e => {
			if (e.key === 'Enter') {
				e.preventDefault()
			}

			if (e.ctrlKey && e.shiftKey && e.key === 'P') {
				e.preventDefault()
				if (extractSingleParamValue(editor).includes('{{1}}')) {
					return
				}
				insertChipAtCursor(editor, makeChip(''))
				syncValue()
				syncVarButton()
				syncCount()
				this._renderPreview()
			}
		})

		editor?.addEventListener('beforeinput', e => {
			enforceCharLimit(editor, extractSingleParamValue, WA_TEMPLATE_LIMITS.headerMaxChars, e)
		})

		editor?.addEventListener('input', () => {
			if (extractSingleParamValue(editor) === '') {
				editor.innerHTML = ''
			}
			syncValue()
			syncVarButton()
			syncCount()
			this._renderPreview()
		})

		headerVarButton?.addEventListener('click', () => {
			insertChipAtCursor(editor, makeChip(''))
			syncValue()
			syncVarButton()
			syncCount()
			this._renderPreview()
		})

		syncVarButton()
		syncCount()
	}

	_initHeaderMedia() {
		this._headerMediaLocalUrl = null

		const headerType          = this._form.get("header_type_id")
		const mediaMode           = this._form.get("media_mode")
		const headerMediaWrap     = document.querySelector('#wa-template-header-media-wrap')
		const headerContentUrl    = this._form.get("header_content_url")
		const headerContentUpload = this._headerContentUpload = this._solarUI.get("wa-header-media-dropzone")

		if (mediaMode.get().id == 'url') {
			headerContentUrl.show()
		}

		mediaMode.on("change", (val) => {
			if (val.id == 'url') {
				headerContentUrl.show()
				headerContentUrl.required()
				headerContentUpload._element.classList.add("d-none")
				headerContentUpload.clear()
			} else {
				headerContentUrl.hidden()
				headerContentUrl.optional()
				headerContentUrl.set(null)
				this._form.get("header_content").set(null)
				headerContentUpload._element.classList.remove("d-none")
			}
			this._renderPreview()
		})

		headerType.on("change", (val) => {
			this._revokeBlobUrl(this._headerMediaLocalUrl)
			this._headerMediaLocalUrl = null
			headerContentUpload.clear()

			if (val && val.id != WaTemplateHeaderType.Text) {
				headerMediaWrap.classList.remove('d-none')
				const constraint = MEDIA_CONSTRAINTS[val.id]
				if (constraint) {
					headerContentUpload.setAcceptFiles(constraint.exts.join(','))
					headerContentUpload.setMaxFileSize(constraint.maxBytes)
				}
				if (mediaMode.get()?.id === 'url') {
					this._form.get('header_content').set(headerContentUrl.get())
				}
			} else {
				headerMediaWrap.classList.add('d-none')
				mediaMode.set('url', true)
			}
		})

		headerContentUrl.on("input", (val) => {
			this._form.get("header_content").set(val)
			this._renderPreview()
		})

		headerContentUpload.on("addedfile", (file) => {
			this._revokeBlobUrl(this._headerMediaLocalUrl)
			if (headerType.get()?.id === WaTemplateHeaderType.Document) {
				this._headerMediaLocalUrl = file.name
			} else {
				this._headerMediaLocalUrl = URL.createObjectURL(file)
			}
			this._renderPreview()
		})

		headerContentUpload.on("removedfile", () => {
			this._revokeBlobUrl(this._headerMediaLocalUrl)
			this._headerMediaLocalUrl = null
			this._renderPreview()
		})

		headerContentUpload.on('success', (file, response) => {
			if (!this._headerUploadResolver) {
				return
			}
			const resolve = this._headerUploadResolver
			this._headerUploadResolver = null
			this._headerUploadRejecter = null
			resolve(response?.data?.id ?? null)
		})

		headerContentUpload.on('error', (file, msg) => {
			if (!this._headerUploadRejecter) {
				return
			}
			const reject = this._headerUploadRejecter
			this._headerUploadResolver = null
			this._headerUploadRejecter = null
			reject(msg)
		})
	}

	hasHeaderUpload() {
		return this._headerContentUpload !== null
			&& this._headerContentUpload.getFiles().length > 0
	}

	triggerHeaderUpload(recordId) {
		return new Promise((resolve, reject) => {
			this._headerUploadResolver = resolve
			this._headerUploadRejecter = reject
			this._headerContentUpload.setTableName('wa_template_details')
			this._headerContentUpload.setRecordId(recordId)
			this._headerContentUpload.processQueue()
		})
	}

	_syncHeaderExample(editor) {
		const chip = editor?.querySelector('.wa-header-var-chip')
		const val  = chip ? (chip.dataset.sample ?? '') : ''
		this._form.get('header_examples').set(val ? JSON.stringify({ '1': val }) : null)
	}

	//#endregion

	//#region Body

	_onBodyChange(value) {
		updateCharCount('wa-template-body-count', value.length, WA_TEMPLATE_LIMITS.bodyMaxChars)
		this._renderPreview()
	}

	_renderBodyEditor(editor, rawValue, examples = {}) {
		renderBodyEditor(editor, rawValue, examples, (n, sample) => this._createBodyParamChip(n, sample))
	}

	_createBodyParamChip(n, sample = '') {
		const span = document.createElement('span')
		span.className       = 'wa-param-chip'
		span.contentEditable = 'false'
		span.dataset.param   = n
		span.dataset.sample  = sample
		span.innerHTML       = `{{${n}}} <i class="ri-pencil-line wa-chip-edit-icon"></i>`
		span.classList.toggle('has-sample', !!sample)
		span.addEventListener('click', (e) => {
			e.preventDefault()
			this._popover(e, span, () => this._syncBodyExamples(span.closest('[id$="-content-editor"]') ?? span.parentElement))
		})
		return span
	}

	_syncBodyExamples(editor) {
		const examples = syncBodyExamples(editor)
		this._form.get('body_examples').set(Object.keys(examples).length ? JSON.stringify(examples) : null)
	}

	_insertBodyParamChip(editor) {
		const val  = extractBodyValue(editor)
		const used = new Set()
		const re   = /\{\{(\d+)\}\}/g
		let m
		while ((m = re.exec(val)) !== null) {
			used.add(parseInt(m[1]))
		}

		if (used.size >= WA_TEMPLATE_LIMITS.bodyMaxParams) {
			return
		}

		let maxN = 0
		used.forEach(n => {
			if (n > maxN) {
				maxN = n
			}
		})
		const nextN = maxN + 1

		editor.focus()
		const selection = window.getSelection()
		let range

		if (selection.rangeCount && editor.contains(selection.getRangeAt(0).commonAncestorContainer)) {
			range = selection.getRangeAt(0)
		} else {
			range = document.createRange()
			range.selectNodeContents(editor)
			range.collapse(false)
		}

		range.deleteContents()
		const chip = this._createBodyParamChip(nextN)
		range.insertNode(chip)
		range.setStartAfter(chip)
		range.collapse(true)
		selection.removeAllRanges()
		selection.addRange(range)
	}

	//#endregion

	//#region Auth

	_updateAuthBodyPreview(languageId) {
		const el = document.getElementById('wa-template-auth-body-text')
		if (!el) {
			return
		}
		const fallback = WaTemplateAuthBody[WaTemplateLanguage.English]
		el.textContent = WaTemplateAuthBody[languageId] ?? fallback
	}

	//#endregion

	//#region Utilities

	_revokeBlobUrl(url) {
		if (url?.startsWith('blob:')) {
			URL.revokeObjectURL(url)
		}
	}

	_popover(e, chip, onUpdate) {
		showSamplePopover(
			e, chip, onUpdate,
			() => this._popoverCleanup,
			(fn) => { this._popoverCleanup = fn },
			this._disabled
		)
	}

	//#endregion
}
