import SolarSingleton from "@core-js/solaris/solar/solar-singleton"
import {
	esc,
	updateCharCount,
	showSamplePopover,
	createSingleParamChip,
	extractSingleParamValue,
	renderSingleParamEditor,
	insertChipAtCursor,
	enforceCharLimit,
} from "./editor-utils"

const { limits: _limits } = WaTemplateLimits

const WA_BUTTON_LIMITS = {
	maxTotal      : _limits.button_total_max,
	maxUrl        : _limits.button_url_max,
	maxPhone      : _limits.button_phone_max,
	maxCopyCode   : _limits.button_copy_code_max,
	labelMaxChars : _limits.button_label_max_chars,
	valueMaxChars : {
		url          : _limits.button_url_max_chars,
		phone_number : _limits.button_phone_max_chars,
		copy_code    : _limits.button_code_max_chars,
	},
}

const WA_CAROUSEL_BUTTON_LIMITS = {
	maxTotal: _limits.carousel_button_max,
}

const BUTTON_TYPE_OPTIONS = [
	{ value: 'quick_reply',  label: 'Quick Reply' },
	{ value: 'url',          label: 'Visit Website (URL)' },
	{ value: 'phone_number', label: 'Call Phone Number' },
	{ value: 'copy_code',    label: 'Copy Code' },
]

export default class WaTemplateButtons {
	constructor(form, renderPreview, disabled = false) {
		this._form           = form
		this._solarUI        = SolarSingleton.getSolarUI()
		this._addBtnComp     = this._solarUI.get('wa-template-add-button')
		this._renderPreview  = renderPreview
		this._disabled       = disabled
		this._buttons        = []
		this._buttonIdSeq    = 0
		this._popoverCleanup = null
	}

	init() {
		this._onCarouselSchemaChange = null
		this._addBtnWired            = false

		const buttons = this._form.get("buttons")
		try {
			const saved = JSON.parse(buttons.get())
			if (Array.isArray(saved)) {
				saved.forEach(b => this._addButtonCard(b))
			}
		} catch {}

		if (this._disabled) {
			this._addBtnComp.disabled()
			return
		}

		this._wireAddButton()
	}

	reset(disabled = this._disabled) {
		this._disabled = disabled

		const container = document.getElementById('wa-template-buttons-container')
		this._buttons.forEach(btn => {
			container?.querySelector(`[data-btn-id="${btn.id}"]`)?.remove()
		})
		this._buttons                = []
		this._onCarouselSchemaChange = null

		const buttons = this._form.get("buttons")
		try {
			const saved = JSON.parse(buttons.get())
			if (Array.isArray(saved)) {
				saved.forEach(b => this._addButtonCard(b))
			}
		} catch {}

		if (this._disabled) {
			this._addBtnComp.disabled()
			return
		}

		this._wireAddButton()
	}

	/**
	 * Wire the add-button click listener (once).
	 * @returns {void}
	 */
	_wireAddButton() {
		if (this._addBtnWired) {
			return
		}
		this._addBtnWired = true
		this._addBtnComp.on('click', () => {
			if (this._onCarouselSchemaChange) {
				this._addCarouselSchemaCard({ type: 'quick_reply' })
			} else {
				this._addButtonCard({ type: 'quick_reply', label: '', value: '' })
			}
		})
	}

	getButtons() {
		return this._buttons.map(b => ({ type: b.type, label: b.label }))
	}

	getButtonsData() {
		return this._buttons.map(b => ({ ...b }))
	}

	clearValidation() {
		const container = document.getElementById('wa-template-buttons-container')
		container?.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'))
	}

	markInvalid(btnId, field) {
		const container = document.getElementById('wa-template-buttons-container')
		const card      = container?.querySelector(`[data-btn-id="${btnId}"]`)
		if (!card) {
			return
		}

		if (field === 'label') {
			card.querySelector('.wa-btn-label')?.classList.add('is-invalid')
			return
		}

		if (field === 'value') {
			const isUrl = !card.querySelector('.wa-btn-url-editor-wrap')?.classList.contains('d-none')
			if (isUrl) {
				card.querySelector('.wa-btn-url-editor')?.classList.add('is-invalid')
			} else {
				card.querySelector('.wa-btn-value')?.classList.add('is-invalid')
			}
		}
	}

	//#region Private

	_popover(e, chip, onUpdate) {
		showSamplePopover(
			e, chip, onUpdate,
			() => this._popoverCleanup,
			(fn) => { this._popoverCleanup = fn },
			this._disabled
		)
	}

	applyAuthButtons(isInitial) {
		this._addBtnComp.hidden()
		document.getElementById('wa-template-auth-button-info')?.classList.remove('d-none')

		const container = document.getElementById('wa-template-buttons-container')
		this._buttons.forEach(btn => {
			container?.querySelector(`[data-btn-id="${btn.id}"]`)?.remove()
		})
		this._buttons                = []
		this._onCarouselSchemaChange = null

		if (!isInitial) {
			this._syncButtons()
		}
	}

	applyNormalButtons(isInitial) {
		this._addBtnComp.show()
		document.getElementById('wa-template-auth-button-info')?.classList.add('d-none')

		if (this._disabled) {
			this._addBtnComp.disabled()
		}

		if (isInitial) {
			return
		}

		const container = document.getElementById('wa-template-buttons-container')
		this._buttons.forEach(btn => {
			container?.querySelector(`[data-btn-id="${btn.id}"]`)?.remove()
		})
		this._buttons                = []
		this._onCarouselSchemaChange = null
		this._syncButtons()
		this._syncButtonValidation()
	}

	applyCarouselButtons(isInitial, onSchemaChange) {
		this._onCarouselSchemaChange = onSchemaChange

		this._addBtnComp.show()

		if (this._disabled) {
			this._addBtnComp.disabled()
		}

		if (!isInitial) {
			const container = document.getElementById('wa-template-buttons-container')
			this._buttons.forEach(btn => {
				container?.querySelector(`[data-btn-id="${btn.id}"]`)?.remove()
			})
			this._buttons = []
			this._onCarouselSchemaChange?.(this.getCarouselSchema())
		} else {
			// Re-render existing buttons as carousel schema cards
			const container = document.getElementById('wa-template-buttons-container')
			const existing  = [...this._buttons]
			existing.forEach(btn => {
				container?.querySelector(`[data-btn-id="${btn.id}"]`)?.remove()
			})
			this._buttons = []
			const savedCallback = this._onCarouselSchemaChange
			this._onCarouselSchemaChange = null
			existing.forEach(btn => this._addCarouselSchemaCard(btn))
			this._onCarouselSchemaChange = savedCallback
		}

		this._syncButtons()
		this._syncCarouselValidation()
	}

	getCarouselSchema() {
		return this._buttons.map(b => ({ type: b.type }))
	}

	_addButtonCard(data = {}) {
		if (this._buttons.length >= WA_BUTTON_LIMITS.maxTotal) {
			return
		}

		const id  = ++this._buttonIdSeq
		const btn = {
			id,
			type        : data.type        ?? 'quick_reply',
			label       : data.label       ?? '',
			value       : data.value       ?? '',
			url_example : data.url_example ?? '',
		}
		this._buttons.push(btn)

		const container = document.getElementById('wa-template-buttons-container')
		if (!container) {
			return
		}

		const card         = document.createElement('div')
		card.className     = 'card mb-3'
		card.dataset.btnId = id

		card.innerHTML = this._buttonCardHtml(btn)
		container.appendChild(card)

		const typeSelect    = card.querySelector('.wa-btn-type')
		const labelInput    = card.querySelector('.wa-btn-label')
		const valueInput    = card.querySelector('.wa-btn-value')
		const valueWrap     = card.querySelector('.wa-btn-value-wrap')
		const valueLabel    = card.querySelector('.wa-btn-value-label')
		const urlEditorWrap = card.querySelector('.wa-btn-url-editor-wrap')
		const urlEditor     = card.querySelector('.wa-btn-url-editor')
		const labelCount    = card.querySelector('.wa-btn-label-count')
		const valueCount    = card.querySelector('.wa-btn-value-count')
		const paramBtn      = card.querySelector('.wa-btn-param')
		const removeBtn     = card.querySelector('.wa-btn-remove')

		if (this._disabled) {
			if (typeSelect) {
				typeSelect.disabled = true
			}
			if (labelInput) {
				labelInput.disabled = true
			}
			if (valueInput) {
				valueInput.disabled = true
			}
			if (paramBtn) {
				paramBtn.disabled = true
			}
			if (removeBtn) {
				removeBtn.disabled = true
			}
			if (urlEditor) {
				urlEditor.contentEditable = 'false'
			}

			this._syncButtons()
			this._syncButtonValidation()
			this._renderPreview()
			return
		}

		const makeUrlChip = (sample) => createSingleParamChip(
			'wa-param-chip', sample,
			(e, span) => this._popover(e, span, () => {
				syncUrlExample()
				this._syncButtons()
			})
		)

		// Initialize URL editor content if type is URL
		if (btn.type === 'url' && btn.value) {
			renderSingleParamEditor(urlEditor, btn.value, btn.url_example, makeUrlChip)
		}

		const syncUrlCount = () => {
			updateCharCount(valueCount, extractSingleParamValue(urlEditor).length, WA_BUTTON_LIMITS.valueMaxChars.url)
		}

		const syncUrlExample = () => {
			const chip      = urlEditor?.querySelector('.wa-param-chip')
			btn.url_example = chip ? (chip.dataset.sample ?? '') : ''
		}

		const syncValueConfig = (type) => {
			const isQR  = type === 'quick_reply'
			const isUrl = type === 'url'
			const max   = WA_BUTTON_LIMITS.valueMaxChars[type] ?? 0

			const labelMap = {
				url          : 'URL',
				phone_number : 'Phone Number',
				copy_code    : 'Code',
			}
			const placeholderMap = {
				phone_number : '+62...',
				copy_code    : 'Coupon code...',
			}

			valueWrap.classList.toggle('d-none', isQR)
			paramBtn.classList.toggle('d-none', !isUrl)

			if (isQR) {
				return
			}

			valueLabel.textContent = labelMap[type] ?? 'Value'
			urlEditorWrap.classList.toggle('d-none', !isUrl)
			valueInput.classList.toggle('d-none', isUrl)

			if (isUrl) {
				syncUrlCount()
				paramBtn.disabled = extractSingleParamValue(urlEditor).includes('{{1}}')
			} else {
				valueInput.placeholder = placeholderMap[type] ?? ''
				valueInput.maxLength   = max
				updateCharCount(valueCount, valueInput.value.length, max)
			}
		}

		typeSelect?.addEventListener('change', e => {
			const newType = e.target.value
			const oldType = btn.type

			if (newType !== oldType) {
				const counts       = this._getButtonCounts()
				const countWithout = (counts[newType] ?? 0) - (oldType === newType ? 1 : 0)

				if (newType !== 'quick_reply' && countWithout >= this._getTypeMax(newType)) {
					e.target.value = oldType
					return
				}

				if (oldType === 'url' && newType !== 'url') {
					const urlText       = extractSingleParamValue(urlEditor).replace('{{1}}', '')
					urlEditor.innerHTML = ''
					btn.value           = urlText
					btn.url_example     = ''
					valueInput.value    = urlText
				} else if (oldType !== 'url' && newType === 'url') {
					renderSingleParamEditor(urlEditor, btn.value, '', makeUrlChip)
				}

				btn.type = newType
				syncValueConfig(newType)
			}

			this._syncButtons()
			this._syncButtonValidation()
			this._renderPreview()
		})

		labelInput?.addEventListener('input', e => {
			btn.label = labelInput.value
			updateCharCount(labelCount, btn.label.length, WA_BUTTON_LIMITS.labelMaxChars)
			labelInput.classList.toggle('is-invalid', btn.label.length === 0)
			this._syncButtons()
			this._renderPreview()
		})

		valueInput?.addEventListener('input', e => {
			btn.value     = valueInput.value
			const max     = WA_BUTTON_LIMITS.valueMaxChars[btn.type] ?? 0
			updateCharCount(valueCount, btn.value.length, max)
			valueInput.classList.toggle('is-invalid', btn.value.length === 0)
			this._syncButtons()
		})

		urlEditor?.addEventListener('keydown', e => {
			if (e.key === 'Enter') {
				e.preventDefault()
			}

			if (e.ctrlKey && e.shiftKey && e.key === 'P') {
				e.preventDefault()
				if (extractSingleParamValue(urlEditor).includes('{{1}}')) {
					return
				}
				insertChipAtCursor(urlEditor, makeUrlChip(''))
				btn.value         = extractSingleParamValue(urlEditor)
				paramBtn.disabled = true
				syncUrlCount()
				this._syncButtons()
			}
		})

		urlEditor?.addEventListener('beforeinput', e => {
			enforceCharLimit(urlEditor, extractSingleParamValue, WA_BUTTON_LIMITS.valueMaxChars.url, e)
		})

		urlEditor?.addEventListener('input', () => {
			btn.value         = extractSingleParamValue(urlEditor)
			paramBtn.disabled = btn.value.includes('{{1}}')
			syncUrlCount()
			urlEditor.classList.toggle('is-invalid', btn.value.length === 0)
			this._syncButtons()
		})

		paramBtn?.addEventListener('click', () => {
			if (extractSingleParamValue(urlEditor).includes('{{1}}')) {
				return
			}
			insertChipAtCursor(urlEditor, makeUrlChip(''))
			btn.value         = extractSingleParamValue(urlEditor)
			paramBtn.disabled = true
			syncUrlCount()
			this._syncButtons()
		})

		removeBtn?.addEventListener('click', () => {
			this._buttons = this._buttons.filter(b => b.id !== id)
			card.remove()
			this._syncButtons()
			this._syncButtonValidation()
			this._renderPreview()
		})

		this._syncButtons()
		this._syncButtonValidation()
		this._renderPreview()
	}

	_addCarouselSchemaCard(data = {}) {
		if (this._buttons.length >= WA_CAROUSEL_BUTTON_LIMITS.maxTotal) {
			return
		}

		const id  = ++this._buttonIdSeq
		const btn = {
			id,
			type : data.type ?? 'quick_reply',
			label: '',
			value: '',
		}
		this._buttons.push(btn)

		const container = document.getElementById('wa-template-buttons-container')
		if (!container) {
			return
		}

		const card         = document.createElement('div')
		card.className     = 'card mb-3'
		card.dataset.btnId = id
		card.innerHTML     = this._carouselSchemaButtonCardHtml(btn)
		container.appendChild(card)

		const typeSelect = card.querySelector('.wa-btn-type')
		const removeBtn  = card.querySelector('.wa-btn-remove')

		if (this._disabled) {
			if (typeSelect) {
				typeSelect.disabled = true
			}
			if (removeBtn) {
				removeBtn.disabled = true
			}

			this._syncButtons()
			this._syncCarouselValidation()
			this._onCarouselSchemaChange?.(this.getCarouselSchema())
			return
		}

		typeSelect?.addEventListener('change', e => {
			btn.type = e.target.value
			this._syncButtons()
			this._syncCarouselValidation()
			this._onCarouselSchemaChange?.(this.getCarouselSchema())
		})

		removeBtn?.addEventListener('click', () => {
			this._buttons = this._buttons.filter(b => b.id !== id)
			card.remove()
			this._syncButtons()
			this._syncCarouselValidation()
			this._onCarouselSchemaChange?.(this.getCarouselSchema())
		})

		this._syncButtons()
		this._syncCarouselValidation()
		this._onCarouselSchemaChange?.(this.getCarouselSchema())
	}

	_syncCarouselValidation() {
		if (this._disabled || this._buttons.length >= WA_CAROUSEL_BUTTON_LIMITS.maxTotal) {
			this._addBtnComp.disabled()
		} else {
			this._addBtnComp.enabled()
		}
	}

	_carouselSchemaButtonCardHtml(btn) {
		const optionsHtml = BUTTON_TYPE_OPTIONS.slice(0, 3).map(o =>
			`<option value="${o.value}"${btn.type === o.value ? ' selected' : ''}>${o.label}</option>`
		).join('')

		return `<div class="card-body">
			<div class="d-flex gap-3 align-items-center">
				<div class="flex-fill">
					<label class="form-label fw-semibold small mb-1">Type</label>
					<select class="form-select form-select-sm wa-btn-type">${optionsHtml}</select>
					<small class="text-muted d-block mt-1">Label &amp; value are set in each carousel card..</small>
				</div>
				<button type="button" class="btn btn-sm btn-outline-danger wa-btn-remove">
					<i class="ri-delete-bin-line"></i>
				</button>
			</div>
		</div>`
	}

	_buttonCardHtml(btn) {
		const optionsHtml = BUTTON_TYPE_OPTIONS.map(o =>
			`<option value="${o.value}"${btn.type === o.value ? ' selected' : ''}>${o.label}</option>`
		).join('')

		const isQR       = btn.type === 'quick_reply'
		const isUrl      = btn.type === 'url'
		const valueMax   = WA_BUTTON_LIMITS.valueMaxChars[btn.type] ?? 0
		const hasParam   = isUrl && (btn.value ?? '').includes('{{1}}')
		const labelLen   = (btn.label ?? '').length
		const valueLen   = (btn.value ?? '').length

		const valueLabelMap = {
			url          : 'URL',
			phone_number : 'Phone Number',
			copy_code    : 'Code',
		}
		const valuePlaceholderMap = {
			url          : 'https://...',
			phone_number : '+62...',
			copy_code    : 'Coupon code...',
		}

		const valueLabel       = valueLabelMap[btn.type] ?? 'Value'
		const valuePlaceholder = valuePlaceholderMap[btn.type] ?? ''

		return `<div class="card-body">
			<div class="row align-items-center mb-2">
				<label class="col-3 form-label fw-semibold small mb-0">Type</label>
				<div class="col-9 d-flex gap-2">
					<select class="form-select form-select-sm wa-btn-type flex-fill">${optionsHtml}</select>
					<button type="button" class="btn btn-sm btn-outline-danger wa-btn-remove flex-shrink-0">
						<i class="ri-delete-bin-line"></i>
					</button>
				</div>
			</div>
			<div class="row align-items-center mb-2">
				<label class="col-3 form-label fw-semibold small mb-0">Label</label>
				<div class="col-9 d-flex align-items-center gap-2">
					<input type="text" class="form-control form-control-sm wa-btn-label flex-fill" value="${esc(btn.label)}" placeholder="Button text..." maxlength="${WA_BUTTON_LIMITS.labelMaxChars}">
					<small class="text-muted text-nowrap wa-btn-label-count flex-shrink-0">${labelLen}/${WA_BUTTON_LIMITS.labelMaxChars}</small>
				</div>
			</div>
			<div class="row align-items-center wa-btn-value-wrap${isQR ? ' d-none' : ''}">
				<label class="col-3 form-label fw-semibold small mb-0 wa-btn-value-label">${valueLabel}</label>
				<div class="col-9 d-flex align-items-center gap-2">
					<div class="wa-btn-url-editor-wrap flex-fill${isUrl ? '' : ' d-none'}">
						<div class="form-control form-control-sm wa-btn-url-editor"
							contenteditable="true"
							data-placeholder="https://..."></div>
					</div>
					<input type="text" class="form-control form-control-sm wa-btn-value flex-fill${isUrl ? ' d-none' : ''}" value="${esc(isUrl ? '' : (btn.value ?? ''))}" placeholder="${valuePlaceholder}" maxlength="${valueMax}">
					<small class="text-muted text-nowrap wa-btn-value-count flex-shrink-0">${valueLen}/${valueMax}</small>
					<button type="button" class="btn btn-sm btn-outline-secondary wa-btn-param flex-shrink-0${isUrl ? '' : ' d-none'}"${hasParam ? ' disabled' : ''}>
						{{ }} Parameter
					</button>
				</div>
			</div>
		</div>`
	}

	_syncButtons() {
		const hidden = document.getElementById('wa-template-page-buttons')
		if (!hidden) {
			return
		}
		hidden.value = JSON.stringify(this._buttons.map(({ type, label, value, url_example }) => ({ type, label, value, url_example })))
	}

	_getButtonCounts() {
		const counts = { quick_reply: 0, url: 0, phone_number: 0, copy_code: 0 }
		this._buttons.forEach(b => {
			if (counts[b.type] !== undefined) {
				counts[b.type]++
			}
		})
		return counts
	}

	_getTypeMax(type) {
		const map = {
			url          : WA_BUTTON_LIMITS.maxUrl,
			phone_number : WA_BUTTON_LIMITS.maxPhone,
			copy_code    : WA_BUTTON_LIMITS.maxCopyCode,
			quick_reply  : WA_BUTTON_LIMITS.maxTotal,
		}
		return map[type] ?? WA_BUTTON_LIMITS.maxTotal
	}

	_syncButtonValidation() {
		const counts    = this._getButtonCounts()
		const total     = this._buttons.length
		const container = document.getElementById('wa-template-buttons-container')

		if (this._disabled || total >= WA_BUTTON_LIMITS.maxTotal) {
			this._addBtnComp.disabled()
		} else {
			this._addBtnComp.enabled()
		}

		if (!container) {
			return
		}

		this._buttons.forEach(btn => {
			const card   = container.querySelector(`[data-btn-id="${btn.id}"]`)
			const select = card?.querySelector('.wa-btn-type')
			if (!select) {
				return
			}

			const types = ['quick_reply', 'url', 'phone_number', 'copy_code']
			types.forEach(type => {
				const option = select.querySelector(`option[value="${type}"]`)
				if (!option) {
					return
				}

				if (type === 'quick_reply') {
					option.disabled = false
					return
				}

				const countWithout = counts[type] - (btn.type === type ? 1 : 0)
				option.disabled    = countWithout >= this._getTypeMax(type)
			})
		})
	}

	//#endregion
}
