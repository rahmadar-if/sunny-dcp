export function esc(str) {
	return String(str ?? '')
		.replace(/&/g, '&amp;')
		.replace(/"/g, '&quot;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
}

export function updateCharCount(target, current, max) {
	const el = typeof target === 'string' ? document.getElementById(target) : target
	if (el) {
		el.textContent = `${current} / ${max}`
	}
}

export function showSamplePopover(e, chip, onUpdate, getCleanup, setCleanup, disabled = false) {
	e.stopPropagation()

	document.querySelector('.wa-sample-popover')?.remove()
	getCleanup()?.()

	const rect    = chip.getBoundingClientRect()
	const popover = document.createElement('div')
	popover.className = 'wa-sample-popover'
	popover.style.top  = `${rect.bottom + 6}px`
	popover.style.left = `${rect.left}px`
	popover.innerHTML  = `<label>Sample value</label><input type="text" value="${esc(chip.dataset.sample ?? '')}" placeholder="e.g. John Doe"${disabled ? ' disabled' : ''}>`

	document.body.appendChild(popover)

	const input = popover.querySelector('input')
	input.focus()

	if (!disabled) {
		input.addEventListener('input', () => {
			chip.dataset.sample = input.value
			chip.classList.toggle('has-sample', !!input.value)
			onUpdate?.()
		})
	}

	const closePopover = (ev) => {
		if (!popover.contains(ev.target) && ev.target !== chip) {
			popover.remove()
			document.removeEventListener('mousedown', closePopover)
			setCleanup(null)
		}
	}

	// Delay agar event mousedown yang sama tidak langsung menutup
	setTimeout(() => document.addEventListener('mousedown', closePopover), 0)
	setCleanup(() => {
		popover.remove()
		document.removeEventListener('mousedown', closePopover)
	})
}

export function createSingleParamChip(cssClass, sample, onClickCallback) {
	const span = document.createElement('span')
	span.className       = cssClass
	span.contentEditable = 'false'
	span.dataset.sample  = sample
	span.innerHTML       = `{{1}} <i class="ri-pencil-line wa-chip-edit-icon"></i>`
	span.classList.toggle('has-sample', !!sample)
	span.addEventListener('click', (e) => {
		e.preventDefault()
		onClickCallback(e, span)
	})
	return span
}

export function extractSingleParamValue(editor) {
	if (!editor) {
		return ''
	}
	let value = ''
	editor.childNodes.forEach(node => {
		if (node.nodeType === Node.TEXT_NODE) {
			value += node.textContent.replace(/\u00A0/g, ' ')
		} else if (node.nodeName === 'SPAN') {
			value += '{{1}}'
		}
	})
	return value
}

export function renderSingleParamEditor(editor, rawValue, example, createChipFn) {
	if (!editor) {
		return
	}

	editor.innerHTML = ''
	const parts = rawValue.split('{{1}}')
	parts.forEach((part, i) => {
		if (part) {
			editor.appendChild(document.createTextNode(part))
		}
		if (i < parts.length - 1) {
			editor.appendChild(createChipFn(example))
		}
	})
}

export function insertChipAtCursor(editor, chip) {
	editor.focus()

	const selection = window.getSelection()
	let range

	if (selection.rangeCount && editor.contains(selection.getRangeAt(0).commonAncestorContainer)) {
		range = selection.getRangeAt(0)
	} else {
		range = document.createRange()
		range.selectNodeContents(editor)
		range.collapse(false)
	}

	range.deleteContents()
	range.insertNode(chip)
	range.setStartAfter(chip)
	range.collapse(true)
	selection.removeAllRanges()
	selection.addRange(range)
}

export function enforceCharLimit(editor, extractValueFn, maxChars, event) {
	const insertTypes = ['insertText', 'insertFromPaste', 'insertFromDrop', 'insertCompositionText', 'insertReplacementText']
	if (!insertTypes.includes(event.inputType)) {
		return
	}
	const sel         = window.getSelection()
	const selectedLen = sel.rangeCount ? sel.getRangeAt(0).toString().length : 0
	const currentLen  = extractValueFn(editor).length
	const insertLen   = (event.data || event.dataTransfer?.getData('text/plain') || '').length
	if (currentLen - selectedLen + insertLen > maxChars) {
		event.preventDefault()
	}
}

// =========================================
// Body editor shared utilities
// (used by both content.js and carousel.js)
// =========================================

export function extractBodyValue(editor) {
	if (!editor) {
		return ''
	}
	let value = ''
	const nodes = Array.from(editor.childNodes)
	nodes.forEach((node, i) => {
		if (node.nodeType === Node.TEXT_NODE) {
			value += node.textContent.replace(/\u00A0/g, ' ')
		} else if (node.nodeName === 'BR') {
			if (i < nodes.length - 1) {
				value += '\n'
			}
		} else if (node.nodeName === 'SPAN' && node.dataset.param) {
			value += `{{${node.dataset.param}}}`
		}
	})
	return value
}

export function renderBodyEditor(editor, rawValue, examples, createChipFn) {
	editor.innerHTML = ''
	const parts = rawValue.split(/(\{\{\d+\}\})/g)
	parts.forEach(part => {
		const match = part.match(/^\{\{(\d+)\}\}$/)
		if (match) {
			const n = parseInt(match[1])
			editor.appendChild(createChipFn(n, examples[n] ?? ''))
			return
		}
		part.split('\n').forEach((line, i) => {
			if (i > 0) {
				editor.appendChild(document.createElement('br'))
			}
			if (line) {
				editor.appendChild(document.createTextNode(line))
			}
		})
	})
}

export function applyBodyFormat(editor, format) {
	editor.focus()
	const selection = window.getSelection()
	if (!selection.rangeCount) {
		return
	}
	const range = selection.getRangeAt(0)
	if (!editor.contains(range.commonAncestorContainer)) {
		return
	}
	const markers = {
		bold         : ['*', '*'],
		italic       : ['_', '_'],
		strikethrough: ['~', '~'],
		code         : ['```', '```'],
	}
	const [open, close] = markers[format] ?? ['', '']
	if (!open) {
		return
	}
	const selectedText = range.toString()
	range.deleteContents()
	const node = document.createTextNode(`${open}${selectedText}${close}`)
	range.insertNode(node)
	range.setStart(node, open.length)
	range.setEnd(node, open.length + selectedText.length)
	selection.removeAllRanges()
	selection.addRange(range)
}

export function renumberBodyParams(editor) {
	let seq = 1
	editor.childNodes.forEach(node => {
		if (node.nodeName !== 'SPAN' || !node.dataset.param) {
			return
		}
		node.dataset.param = seq
		if (node.firstChild?.nodeType === Node.TEXT_NODE) {
			node.firstChild.textContent = `{{${seq}}} `
		}
		seq++
	})
}

export function syncBodyExamples(editor) {
	const examples = {}
	editor?.querySelectorAll('[data-param]').forEach(chip => {
		if (chip.dataset.sample) {
			examples[chip.dataset.param] = chip.dataset.sample
		}
	})
	return examples
}
