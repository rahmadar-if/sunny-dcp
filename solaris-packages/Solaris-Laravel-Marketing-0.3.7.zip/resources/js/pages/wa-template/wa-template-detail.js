import { WaTemplateSubType, WaTemplateCategory, WaTemplateStatus } from "@marketing-js/const";
import SolarListDetail from "@core-js/solaris/solar/solar-list-detail";

export default class WaTemplateDetail extends SolarListDetail {
    static supportedEvent() {
        return [
            ...super.supportedEvent(), 
            "preview-whatsapp"
        ]
    }
    
    init() {
        this._categoryId = this.form.getValue("category_id")
        this.initModal()
    }
    
    initModal() {
        if(!this.hasModalForm()) {
            return
        }

        this.modal.on("show", () => {
            const subType  = this.form.get("sub_type_id")
            
            subType.set({
                id: WaTemplateSubType.Regular,
                name: "Regular"
            })
            
            if(this._categoryId == WaTemplateCategory.Marketing) {
                subType.enabled()
            } else {
                subType.disabled()
            }
        })
        .on("hidden", () => {
            this.form.set("category_id", this._categoryId)
        })
    }

    openEditPage(id) {
        this.helper.loadingPage(true)
        window.location = `${BASE_URL}/marketing/wa-template/detail/edit/${id}`
    }

    async edit(row, data) {
        this.openEditPage(data.id)
    }

    rowDoubleClick(row, data) {
        this.openEditPage(data.id)
    }

    onActionCreated(row, cell, rowData) {
        this.actionAfter(row, "edit-action", {
            selector: "preview-action",
            label: "Preview",
            icon: "ri-eye-line",
            color: "success",
            callback: async () => await this.previewWhatsapp(rowData)
        })

        if (rowData.status_id !== WaTemplateStatus.Draft) {
            this.actionRemove(row, "delete-action")
        }
    }

    async previewWhatsapp(rowData) {
        if (rowData.sub_type?.name === 'Carousel') {
            await this.trigger("preview-whatsapp", {
                type       : 'carousel',
                body       : rowData.body || null,
                cards      : JSON.parse(rowData.cards) || [],
                header_type: rowData.header_type?.name?.toLowerCase() || 'image',
            })
            return
        }

        const headerType = rowData.header_type?.name?.toLowerCase() || null
        await this.trigger("preview-whatsapp", {
            type          : 'regular',
            header        : headerType ? { type: headerType, value: rowData.header_content } : null,
            body          : rowData.body,
            footer        : rowData.footer,
            buttons       : JSON.parse(rowData.buttons) || [],
            disclaimer    : rowData.disclaimer,
            expiry_minutes: rowData.expiry_minutes,
            language_id   : rowData.language?.id,
            language_code : rowData.language?.code,
        })
    }

    updateCategory(categoryId) {
        this._categoryId = categoryId
        this.form.set("category_id", this._categoryId)
    }
}