import SolarListPage from "@core-js/solaris/solar/solar-list-page"
import { WaTemplateCategory, WaTemplateStatus } from "@marketing-js/const"

export default class WaTemplateListPage extends SolarListPage {
	init() {
		this.columnRender("name", this.nameColumnRender.bind(this))
		this.columnRender("category_id", this.categoryColumnRender.bind(this))
		this.columnRender("languages", this.languagesColumnRender.bind(this))

		this.get("wa-template-sync")?.on("click", this.syncAllTemplates.bind(this))
	}

	async syncAllTemplates() {
		if (!await this.helper.confirm({ title: "Sync Templates?", message: "Sync all templates from provider to database?" })) {
			return
		}

		try {
			this.helper.loadingPage(true)

			const req = await this.axios({
				method: "POST",
				url   : `${BASE_URL}/marketing/wa-template/sync-all`,
			})

			if (!req.data.success) {
				throw req.data.message
			}

			this.helper.successAlert({ title: req.data.message })
			this.table.refresh()
		} catch (error) {
			this.helper.errorAlert({ title: "Sync failed", message: error })
		} finally {
			this.helper.loadingPage(false)
		}
	}

	openEditPage(id) {
		this.helper.loadingPage(true)
		window.location = `${BASE_URL}/marketing/wa-template/edit/${id}`
	}

	async edit(row, data) {
		this.openEditPage(data.id)
	}

	rowDoubleClick(row, data) {
		this.openEditPage(data.id)
	}

	nameColumnRender(data, rowData) {
		return `<div class="d-flex flex-column gap-1">
			<a class="text-decoration-underline" href="${BASE_URL}/marketing/wa-template/edit/${rowData.id}">${data}</a>
			<span class="text-muted fs-12">${rowData.template_name ?? '-'}</span>
		</div>`
	}

	categoryColumnRender(data, rowData) {
		let categoryColor = 'primary'
		switch (rowData.category_id) {
			case WaTemplateCategory.Utility:
				categoryColor = 'info'
				break

			case WaTemplateCategory.Authentication:
				categoryColor = 'purple'
				break
			
			case WaTemplateCategory.Marketing:
			default:
				categoryColor = 'primary'
				break;
		}

		return `<span class="badge rounded-pill fs-11 bg-${categoryColor}-transparent text-${categoryColor} border border-${categoryColor} border-opacity-25">
			${rowData.category.name}
		</span>`
	}

	languagesColumnRender(data, rowData) {
		return `<div class="d-flex align-items-center gap-1">
			${rowData.details.map(d => {
				const dotColor = this._getStatusDotColor(d.status_id)
				return `<span class="badge rounded-pill fs-11 bg-secondary-transparent text-secondary border border-secondary border-opacity-10">
					<i class="ri-circle-fill fs-9 me-1 text-${dotColor}"></i><i class="ri-translate-2 me-1"></i>${d.language.name}
				</span>`
			}).join("")}
		</div>`
	}
 
	/**
	 * @param {string} statusId
	 * @returns {string}
	 */
	_getStatusDotColor(statusId) {
		switch (statusId) {
			case WaTemplateStatus.Approved: 
				return 'success'
			case WaTemplateStatus.Rejected: 
				return 'danger'
			case WaTemplateStatus.Pending:  
				return 'warning'
			case WaTemplateStatus.Paused:   
				return 'orange'
			case WaTemplateStatus.Draft:
			default:
				return 'secondary'
		}
	}
}
