import WaTemplatePage from "./page"

new WaTemplatePage()
