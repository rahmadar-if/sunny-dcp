import SolarEditPage from "@core-js/solaris/solar/solar-edit-page"
import WhatsAppPreview from "../../solaris/whatsapp-preview"
import WaTemplateDetail from "./wa-template-detail"
import { WaTemplateCategory, WaTemplateStatus, WaTemplateAuthBody, WaTemplateLanguage } from "@marketing-js/const"
import Button from "@core-js/solaris/button"

export default class WaTemplatePage extends SolarEditPage
{
	init() {
		/** @type {WhatsAppPreview} */
		this._preview = this.get("wa-template-page-preview")
		
		/** @type {Button} */
		this.submitMetaBtn = this.get("wa-template-page-submit")
		this.submitMetaBtn?.on("click", this.submitToMeta.bind(this))

		/** @type {Button} */
		this.syncBtn = this.get("wa-template-page-sync")
		this.syncBtn?.on("click", this.syncTemplate.bind(this))

		this.initForm()
		this.registerDetail("wa-template-detail", WaTemplateDetail, "wa_template_id")
	}

	initForm() {
		const name 	   = this.form.get("name")
		const category = this.form.get("category_id")

		name?.on('input',(value) => this.breadcrumbName.innerText = value, "WaTemplatePage")
		category?.on('change', (value) => this.waTemplateDetail?.updateCategory(value?.id ?? null))
	}

	initDetail() {
		this.waTemplateDetail?.on("preview-whatsapp", this.previewWhatsApp.bind(this))
	}

	async submitToMeta() {
		if (!await this.helper.confirm({ title: "Submit to Meta?", message: "This template will be submitted for review by Meta." })) {
			return
		}

		try {
			if (!await this.save(false)) {
				return
			}

			this.helper.loadingPage(true)

			const req = await this.axios({
				method: "POST",
				url   : `${BASE_URL}/marketing/wa-template/submit`,
				data  : { id: this.id },
			})

			if (!req.data.success) {
				throw req.data.message
			}

			this.helper.successAlert({ title: req.data.message })
			await this.refresh()
		} catch (error) {
			this.helper.errorAlert({ title: "Something wrong happen", message: error })
		} finally {
			this.helper.loadingPage(false)
		}
	}

	async syncTemplate() {
		if (!await this.helper.confirm({ title: "Sync Template?", message: "This will sync the template status from Meta." })) {
			return
		}

		try {
			this.helper.loadingPage(true)

			const req = await this.axios({
				method: "POST",
				url   : `${BASE_URL}/marketing/wa-template/sync`,
				data  : { id: this.id },
			})

			if (!req.data.success) {
				throw req.data.message
			}

			this.helper.successAlert({ title: req.data.message })
			await this.refresh()
		} catch (error) {
			this.helper.errorAlert({ title: "Something wrong happen", message: error })
		} finally {
			this.helper.loadingPage(false)
		}
	}

	async onRefreshed(data) {
		this.breadcrumbName.innerText = data.name

		const isCanSubmit = data.details.every(d => d.status_id === WaTemplateStatus.Draft)
		const isCanSync   = data.details.some(d => d.status_id === WaTemplateStatus.Pending)

		isCanSubmit ? this.submitMetaBtn?.enabled() : this.submitMetaBtn?.disabled()
		isCanSync   ? this.syncBtn?.enabled() : this.syncBtn?.disabled()
	}

	previewWhatsApp(data) {
		this._preview.clearMessages()

		if (data.type === 'carousel') {
			if(!data.body || (!data.cards || (data.cards && data.cards.length == 0))) {
				return
			}

			const mediaType    = data.header_type === 'video' ? 'video' : 'image'
			const previewCards = data.cards.map(card => ({
				id        : card.id ?? null,
				media_type: mediaType,
				src       : card.header_content ?? '',
				body      : card.body ?? '',
				buttons   : (card.buttons ?? []).map(btn => ({
					type : 'quick_reply',
					label: btn.label ?? '',
				})),
			}))

			this._preview.addCarousel({
				id   : 'main',
				text : data.body ?? '',
				cards: previewCards,
			})

			return
		}

		const category       = this.form.getValue("category_id")
		const isAuth         = category?.id === WaTemplateCategory.Authentication
		const supportedLangs = ['en', 'en_US', 'en_GB', 'id']
		const buttons        = isAuth && !supportedLangs.includes(data.language_code)
			? (data.buttons || []).map(btn => ({ ...btn, label: btn.label || 'Copy Code' }))
			: (data.buttons || [])

		const authBody = WaTemplateAuthBody[data.language_id] ?? WaTemplateAuthBody[WaTemplateLanguage.English]
		const body     = isAuth ? authBody : data.body

		if (!isAuth && !body) {
			return
		}

		this._preview.addTemplateMessage({
			id            : 'main',
			header        : data.header,
			text          : body,
			footer        : data.footer,
			buttons,
			disclaimer    : isAuth && !!data.disclaimer,
			expiry_minutes: isAuth ? (data.expiry_minutes || 0) : 0,
		})
	}
}