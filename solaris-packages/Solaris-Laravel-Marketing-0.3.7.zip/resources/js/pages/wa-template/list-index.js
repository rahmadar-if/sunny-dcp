import WaTemplateListPage from "./list"

new WaTemplateListPage("wa-template")
