import Filter from "@core-js/solaris/filter/filter"
import Helper from "@core-js/solaris/helper"
import Modal from "@core-js/solaris/modal"
import Model from "@core-js/solaris/model"
import SolarComponent from "@core-js/solaris/solar/solar-component"
import SolarSingleton from "@core-js/solaris/solar/solar-singleton"
import Table from "@core-js/solaris/table/table"
import axios from "@core-js/libs/axios"

export default class AudienceSegmentationModal extends SolarComponent {
    
    /**
     * @param {string} selector 
     * @param {string} addAudienceEndpoint 
     * @param {string} parentColumn
     * @param {string} parentValue
     */
    constructor(selector, addAudienceEndpoint, parentColumn, parentValue) {
        super()

        this.solarUI = SolarSingleton.getSolarUI()

        this.selector     = selector
        this.endpoint     = addAudienceEndpoint
        this.parentColumn = parentColumn
        this.parentValue  = parentValue

        this.init()
    }

    static supportedEvent() {
        return [
            "change",
        ]
    }

    init() {
        this._listRender        = false
        this._previewListRender = false

        /** @type {Table} */
        this._list = this.solarUI.get(`${this.selector}-list`)
        this._list
            .on("column render:name", this.segmentationNameColumnRender.bind(this))
            .on("column created:name", this.segmentationNameColumnCreated.bind(this))

        /** @type {Table} */
        this._previewList = this.solarUI.get(`${this.selector}-list-preview`)

        /** @type {Modal} */
        this.modal = this.solarUI.get(`${this.selector}-modal`)
        this.modal
            .on("show", this.segmentationShow.bind(this))
            .on("hide", this.segmentationHide.bind(this))
    }

    addSegmentation() {
        this.modal.show()
    }

    segmentationShow() {
        if(!this._listRender) {
            this._listRender = true
            this._list.render()
        }
    }

    async segmentationHide() {
        this._list._table.rows().nodes().each(function (row) {
            row.classList.remove('table-active')
        })

        await this._previewList.filter("segmentation", null, false)
        if(this._previewListRender) {
            this._previewList.clear()
        }
    }

    async previewSegmentation(id) {
        const data = await Model.get('folder', id)
        
        if(!this._previewListRender) {
            this._previewListRender = true
            await this._previewList.filter("segmentation", new Filter(data.filters), false)
            this._previewList.render()
        } else {
            await this._previewList.filter("segmentation", new Filter(data.filters), true)
        }
    }

    async applySegmentation(id) {
        Helper.loadingPage(true)

        try {
            const data    = await Model.get('folder', id)
            const reqData = {
                select_all: true,
                selected  : [],
                excluded  : [],
                filters   : {
                    filters: JSON.parse(data.filters)
                }
            }
            reqData[this.parentColumn] = this.parentValue

            const req = await axios({
                method: "POST",
                url   : this.endpoint,
                data  : reqData
            })

            const res = req.data
            if(res.success) {
                this.modal.hide()
                Helper.successAlert({title: "Data saved successfully"})
                await this.trigger("change")
            }
        } catch (error) {
            console.error({error})
        } finally {
            Helper.loadingPage(false)
        }
    }

    segmentationNameColumnRender(data, row) {
        return `<div class="d-flex justify-content-between">
            <div class="d-flex flex-column gap-1">
                <p class="fw-medium mb-0">${data}</p>
                <span class="fs-12 text-muted">${row.description ?? ''}</span>
                <span class="fs-12 text-muted"><i class="ri-user-line me-1"></i>${row.created_by.name}</span>
            </div>

            <div class="d-flex gap-1">
                <button data-id="${row.id}" class="btn btn-wave btn-outline-info btn-icon btn-sm waves-effect waves-light action-preview" type="button" title="Preview">
                    <i class="ri-eye-line"></i>
                </button>
                <button data-id="${row.id}" class="btn btn-wave btn-outline-success btn-icon btn-sm waves-effect waves-light action-apply" type="button" title="Apply Segmentation">
                    <i class="ri-check-line"></i>
                </button>
            </div>
        </div>`
    }

    segmentationNameColumnCreated(row, cell, cellData, rowData) {
        const previewBtn = cell.querySelector("button.action-preview")
        if(previewBtn) {
            previewBtn.addEventListener("click", async () => {
                previewBtn.disabled = true

                await this.previewSegmentation(rowData.id)

                this._list._table.rows().nodes().each(function (row) {
                    row.classList.remove('table-active')
                })

                row.classList.add("table-active")

                previewBtn.disabled = false
            })
        }
        
        const applyBtn = cell.querySelector("button.action-apply")
        if(applyBtn) {
            applyBtn.addEventListener("click", async () => {
                applyBtn.disabled = true

                await this.applySegmentation(rowData.id)

                applyBtn.disabled = false
            })
        }
    }
}