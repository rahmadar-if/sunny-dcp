import WaBlastListPage from "./list"

new WaBlastListPage("wa-blast")