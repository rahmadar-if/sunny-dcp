import WaBlastPage from "./page"

new WaBlastPage()