import SolarEditPage from "@core-js/solaris/solar/solar-edit-page"
import WhatsAppPreview from "@marketing-js/solaris/whatsapp-preview"
import WaBlastWaTemplate from "./wa-template"
import WaBlastAudienceDetail from "./audience-detail"
import { CampaignBlastStatus } from "@marketing-js/const"
import WaBlastStatusHistoryDetail from "./status-history-detail"
import WaBlastActivityDetail from "./activity-detail"
import MetricDashboard from "@core-js/solaris/metric-dashboard"

export default class WaBlastPage extends SolarEditPage {
	init() {
		this.displayValueName = "title"

		this.registerDetail("wa-blast-audience", WaBlastAudienceDetail, "wa_blast_id")
		this.registerDetail("wa-blast-activity", WaBlastActivityDetail, "wa_blast_id")
        this.registerDetail("wa-blast-status-history", WaBlastStatusHistoryDetail, "wa_blast_id")

		this.initActionButton()
        this.initSchedule()
        this.initTestWa()
		this.initWaTemplate()
        this.initCampaignStatus()
	}

    initDetail() {
        this.waBlastAudience?.on("ready", () => this.setAddAudienceState())
    }

	initActionButton() {
        /** @type {Button} */
        this.sendNowBtn = this.get("wa-blast-page-send-now")
        this.sendNowBtn?.on("click", this.sendNow.bind(this))
        
        /** @type {Button} */
        this.cancelScheduleBtn = this.get("wa-blast-page-schedule-cancel")
        this.cancelScheduleBtn?.on("click", this.cancelSchedule.bind(this))
    }

	initSchedule() {
        /** @type {Button} */
        this.scheduleBtn = this.get("wa-blast-page-schedule")
        this.scheduleBtn?.on("click", this.schedule.bind(this))

        /** @type {ModalForm} */
        this.scheduleModal = this.get("wa-blast-schedule-modal_ModalForm")
        this.scheduleModal?.form
            .on("submitting", () => {
                this.scheduleBtn?.disabled()
                this.scheduleModal.form.addData("id", this.id)
            })
            .on("failed", () => this.scheduleBtn?.enabled())
            .on("error", () => this.scheduleBtn?.enabled())
            .on("success", async () => {
                await this.refreshForm()
                this.setButtonState()
            })
    }

	initTestWa() {
        /** @type {Button} */
        this.testWaBtn = this.get("wa-blast-page-test-email")
        this.testWaBtn?.on("click", async () => {
            if(!await this.save(false)) {
                return
            }

            this.testWaModal.modal.show()
        })

        /** @type {ModalForm} */
        this.testWaModal = this.get("wa-blast-test-wa-modal_ModalForm")
        this.testWaModal?.form
            .on("validated", async () => {
                if (!await this.helper.confirm({
                    title: "Are you sure?",
                    message: "Warning: This action sends a real WhatsApp message and uses your quota."
                })) {
                    throw null
                }
            })
            .on("submitting", () => {
                this.testWaBtn?.disabled()
                this.testWaModal.form.addData("id", this.id)
            })
            .on("failed", () => this.testWaBtn?.enabled())
            .on("error", () => this.testWaBtn?.enabled())
            .on("success", (res) => {
                this.helper.successAlert({ title: "Success send test WhatsApp"})
                this.testWaBtn?.enabled()
            })
    }

    initCampaignStatus() {
        /** @type { MetricDashboard } */
        this.totalAudience = this.get("wa-blast-page-total_audience")

        /** @type { MetricDashboard } */
        this.deliveryRate = this.get("wa-blast-page-delivery_rate")
        
        /** @type { MetricDashboard } */
        this.readRate = this.get("wa-blast-page-read_rate")

        /** @type { MetricDashboard } */
        this.replyRate = this.get("wa-blast-page-reply_rate")

        /** @type { MetricDashboard } */
        this.pending = this.get("wa-blast-page-pending")
        
        /** @type { MetricDashboard } */
        this.progress = this.get("wa-blast-page-progress")
        
        /** @type { MetricDashboard } */
        this.failedMetric = this.get("wa-blast-page-failed")
        
        /** @type { MetricDashboard } */
        this.delivered = this.get("wa-blast-page-delivered")

        Array.from([
            this.totalAudience, this.deliveryRatetotalAudience, this.readRatetotalAudience, this.replyRatetotalAudience,
            this.pendingtotalAudience, this.progresstotalAudience, this.failedMetrictotalAudience, this.deliveredtotalAudience, 
        ]).forEach(m => m?.init())

        const totalRead         = document.querySelector("#wa-blast-page-total_read")
        this.totalRead          = totalRead?.querySelector("span.value")
        this.totalRead_percent  = totalRead?.querySelector("span.value-percent")
        this.totalRead_progress = totalRead?.querySelector("div.progress")

        const totalReply         = document.querySelector("#wa-blast-page-total_reply")
        this.totalReply          = totalReply?.querySelector("span.value")
        this.totalReply_percent  = totalReply?.querySelector("span.value-percent")
        this.totalReply_progress = totalReply?.querySelector("div.progress")

        this.readToReplyRate = document.querySelector("#wa-blast-page-read_to_reply_rate")
    }

	openScheduleModal(availableDates = []) {
        const scheduleAt = this.scheduleModal?.form.get("schedule_at")
        scheduleAt?.init({enable: availableDates})
        
        this.scheduleModal?.modal.show()
    }

	setButtonState() {
        const statusId   = this.form.get("status_id")?.get()?.id
        const isEditable = [CampaignBlastStatus.Draft, CampaignBlastStatus.Failed].includes(statusId)

        if(isEditable) {
            this.sendNowBtn?.enabled()
            this.sendNowBtn?.show()
            this.scheduleBtn?.enabled()
            this.scheduleBtn?.show()
            this.cancelScheduleBtn?.disabled()
            this.cancelScheduleBtn?.hidden()
        } else if([
            CampaignBlastStatus.Queued,
            CampaignBlastStatus.Sending,
            CampaignBlastStatus.Completed,
            CampaignBlastStatus.Canceled
        ].includes(statusId)) {
            this.sendNowBtn?.disabled()
            this.sendNowBtn?.hidden()
            this.scheduleBtn?.disabled()
            this.scheduleBtn?.hidden()
            this.cancelScheduleBtn?.disabled()
            this.cancelScheduleBtn?.hidden()
        } else if(statusId == CampaignBlastStatus.Scheduled) {
            this.sendNowBtn?.disabled()
            this.sendNowBtn?.hidden()
            this.scheduleBtn?.disabled()
            this.scheduleBtn?.hidden()
            this.cancelScheduleBtn?.enabled()
            this.cancelScheduleBtn?.show()
        }

        this.setFormFieldsState(isEditable)
    }

	/**
	 * @param {boolean} editable
	 * @returns {void}
	 */
	setFormFieldsState(editable) {
        const titleField    = this.form.get("title")
        const priorityField = this.form.get("priority_id")
        const templateField = this.form.get("wa_template_detail_id")

        if(editable) {
            titleField?.enabled()
            priorityField?.enabled()
            templateField?.enabled()
            this._waTemplate?.setDisabled(false)
        } else {
            titleField?.disabled()
            priorityField?.disabled()
            templateField?.disabled()
            this._waTemplate?.setDisabled(true)
        }
    }

	/**
	 * @returns {void}
	 */
	initWaTemplate() {
		/** @type {WhatsAppPreview} */
		this._preview = this.get("wa-blast-page-preview")

		/** @type {WaBlastWaTemplate} */
		this._waTemplate = this._preview ? new WaBlastWaTemplate(this.form, this._preview) : null
		this._waTemplate?.init()
	}

	async submitting() {
		if (!this._waTemplate?.validate()) {
            this.form.hiddenErrorAlert()
            this.helper.toast({ message: "Some fields are invalid or incomplete. Please check again.", color: "danger" })
			throw null
		}

        this.form.showErrorAlert()
		this.form.addData("template_params", this._waTemplate.getParams())
	}

	async sendNow() {
        if(!await this.helper.confirm({title: "Are you sure?"})) {
            return
        }

        try {
            if(!await this.save(false)) {
                this.sendNowBtn?.enabled()
                return
            }

            this.sendNowBtn?.disabled()
            this.helper.loadingPage(true)

            const req = await this.axios({
                method: "POST",
                url: `${BASE_URL}/marketing/wa-blast/send-now`,
                data: {
                    id: this.id
                }
            })
            const res = req.data
            if(!res.success) {
                throw res.message
            }
            
            this.helper.alert({title: "Processing WhatsApp Blast", message: "This process runs in the background. You can leave this page and will be notified when it's done."})
            await this.refreshForm()
            this.setButtonState()
        } catch (error) {
            this.helper.errorAlert({title: error})
            this.sendNowBtn?.enabled()
        } finally {
            this.helper.loadingPage(false)
        }
    }

    async schedule() {
        if(!await this.helper.confirm({title: "Are you sure?"})) {
            return
        }

        this.helper.loadingPage(true)
    
        try {
            if(!await this.save(false)) {
                return
            }
            
            const req = await this.axios({
                method: "GET",
                url: `${BASE_URL}/marketing/wa-blast/available-schedule`,
            })
            const res = req.data

            if(res.success && res.data) {
                this.openScheduleModal([res.data])
            }
        } catch (error) {
            this.helper.errorAlert({title: error})
        } finally {
            this.helper.loadingPage(false)
        }
    }

    async cancelSchedule() {
        if(!await this.helper.confirm({title: "Are you sure?"})) {
            return
        }

        this.helper.loadingPage(true)
    
        try {
            const req = await this.axios({
                method: "POST",
                url: `${BASE_URL}/marketing/wa-blast/cancel-schedule`,
                data: {
                    id: this.id
                }
            })
            const res = req.data
            if(!res.success) {
                throw res.message
            }

            await this.refreshForm()
            this.setButtonState()
        } catch (error) {
            this.helper.errorAlert({title: error})
        } finally {
            this.helper.loadingPage(false)
        }
    }

	/**
	 * @param {Object} data
	 * @returns {Promise<void>}
	 */
	async onRefreshed(data) {
		this.breadcrumbName.innerText = data.title

		await this._waTemplate?.onRefreshed(data)

        if(data.template_params) {
            this.testWaBtn?.enabled()
        } else {
            this.testWaBtn?.disabled()
        }

		this.setButtonState()
		this.setAddAudienceState()
        this.campaignStatusRefresh(data)
	}

	setAddAudienceState() {
        const blockAddAudience = [
            CampaignBlastStatus.Queued,
            CampaignBlastStatus.Sending,
            CampaignBlastStatus.Scheduled,
            CampaignBlastStatus.Completed,
        ]
        const status = this.form.get("status_id")
        if(status?.get()?.id && blockAddAudience.includes(status.get().id)) {
            this.waBlastAudience.table.disableNew()
            this.waBlastAudience.addSegmenBtn?.disabled()
        } else {
            this.waBlastAudience.table.enableNew()
            this.waBlastAudience.addSegmenBtn?.enabled()
        }
    }

	campaignStatusRefresh(data) {
        this.totalAudience?.setValue(data.total_audience)
        this.deliveryRate?.setValue(this.helper.readableNumber(data.delivery_rate, 1) + "%")
        this.readRate?.setValue(this.helper.readableNumber(data.read_rate, 1) + "%")
        this.replyRate?.setValue(this.helper.readableNumber(data.reply_rate, 1) + "%")

        this.pending?.setValue(data.total_pending)
        this.pending?.setChange({value: this.helper.readableNumber(data.total_pending_percent, 1) + "%"})

        this.progress?.setValue(data.total_progress)
        this.progress?.setChange({value: this.helper.readableNumber(data.total_pending_percent, 1) + "%"})

        this.delivered?.setValue(data.total_success)
        this.delivered?.setChange({value: this.helper.readableNumber(data.total_delivered_percent, 1) + "%"})

        this.failedMetric?.setValue(data.total_fail)
        this.failedMetric?.setChange({value: this.helper.readableNumber(data.total_fail_percent, 1) + "%"})

        if(this.totalRead) {
            this.totalRead.textContent = data.total_read
        }

        if(this.totalRead_percent) {
            this.totalRead_percent.textContent = `(${this.helper.readableNumber(data.read_rate, 1)}%)`
        }
        this.totalRead_progress?.setAttribute("aria-valuenow", data.read_rate)
        
        if(this.totalRead_progress?.firstElementChild) {
            this.totalRead_progress.firstElementChild.style.width = `${data.read_rate}%`
        }

        if(this.totalReply.textContent) {
            this.totalReply.textContent = data.total_reply
        }

        if(this.totalReply_percent) {
            this.totalReply_percent.textContent = `(${this.helper.readableNumber(data.reply_rate, 1)}%)`
        }

        this.totalReply_progress?.setAttribute("aria-valuenow", data.reply_rate)
        
        if(this.totalReply_progress?.firstElementChild) {
            this.totalReply_progress.firstElementChild.style.width = `${data.reply_rate}%`
        }
        
        if(this.readToReplyRate) {
            this.readToReplyRate.textContent = this.helper.readableNumber(data.read_to_reply_rate, 1) + "%"
        }
    }
}