import axios from "@core-js/libs/axios"
import LookupInput from "@core-js/solaris/form/lookup-input"
import Model from "@core-js/solaris/model"
import Filter from "@core-js/solaris/filter/filter"
import Form from "@core-js/solaris/form/form"
import Helper from "@core-js/solaris/helper"
import { CampaignBlastStatus, WaTemplateCategory, WaTemplateHeaderType, WaTemplateStatus, WaTemplateSubType } from "@marketing-js/const"
import WhatsAppPreview from "@marketing-js/solaris/whatsapp-preview"

/**
 * @typedef {{ type: 'simple', key: string, label: string, params: number[] }} SimpleGroup
 * @typedef {{ type: 'card', key: string, label: string, subsections: Array<{key: string, label: string, params: number[]}> }} CardGroup
 * @typedef {SimpleGroup|CardGroup} ParamGroup
 */

export default class WaBlastWaTemplate {
	/** @type {Form} */
	_form = null

	/** @type {WhatsAppPreview} */
	_preview = null

	/** @type {HTMLElement|null} */
	_container = null

	/** @type {Object|null} */
	_templateData = null

	/**
	 * Current param values.
	 * Shape: { [sectionKey]: { [paramIndex]: { source: string, value: string } } }
	 * @type {Object}
	 */
	_params = {}

	/**
	 * Resolved contact columns from backend, cached after first fetch.
	 * @type {Array<{id: string, name: string}>}
	 */
	_columns = []

	/**
	 * LookupInput instances keyed by elId.
	 * @type {Object<string, LookupInput>}
	 */
	_lookups = {}

	/**
	 * Param groups from last rendered template. Used for validation.
	 * @type {ParamGroup[]}
	 */
	_groups = []

	/** @type {string|null} */
	_templateId = null

	/** @type {boolean} */
	_disabled = false

	/**
	 * @param {Object} form
	 * @param {import("@marketing-js/solaris/whatsapp-preview").default} preview
	 */
	constructor(form, preview) {
		this._form      = form
		this._preview   = preview
		this._container = document.getElementById('wa-blast-page-template-params')
	}

	/**
	 * Attach listeners and handle initial state from current DOM values.
	 * @returns {void}
	 */
	init() {
		const templateField = this._form.get("wa_template_detail_id")

		templateField?.init({
			param: (param) => {
				const filter = new Filter()
				filter.and("status_id", WaTemplateStatus.Approved)

				param.filter = filter.get()

				return param
			}
		})

		templateField?.on("change", async (value) => {
			await this._onTemplateChange(value)
		}, "WaBlastWaTemplate")

		const currentValue  = templateField?.get()
		const initialParams = this._readInitialParams()

		this._disabled = this._computeDisabled()

		if (currentValue?.id) {
			this._loadTemplate(currentValue.id, initialParams)
		}
	}

	/**
	 * Called after form refresh (save/reload). Re-renders with fresh server data.
	 * @param {Object} data  Full WaBlast record from server
	 * @returns {Promise<void>}
	 */
	async onRefreshed(data) {
		const templateDetail = data.wa_template_detail
		const savedParams    = data.template_params ?? null

		this._disabled = this._computeDisabled()

		if (templateDetail?.id) {
			await this._loadTemplate(templateDetail.id, savedParams)
			return
		}

		this._clearAll()
	}

	/**
	 * Disables or enables all param input fields in the template params container.
	 * @param {boolean} disabled
	 * @returns {void}
	 */
	setDisabled(disabled) {
		this._disabled = disabled

		if(!this._container) {
			return
		}

		this._container.querySelectorAll('select, input').forEach(el => {
			el.disabled = disabled
		})

		Object.values(this._lookups).forEach(lookup => {
			disabled ? lookup.disabled?.() : lookup.enabled?.()
		})
	}

	/**
	 * Returns current param values for form submission.
	 * @returns {string} JSON string
	 */
	getParams() {
		return JSON.stringify(this._params)
	}

	/**
	 * Validates all template params. Marks invalid fields with is-invalid and returns result.
	 * @returns {boolean}
	 */
	validate() {
		this._container?.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'))
		Object.values(this._lookups).forEach(lookup => lookup.resetValidation())

		if (this._groups.length === 0) {
			return true
		}

		let valid = true

		const checkParam = (sectionKey, paramIndex) => {
			const paramData    = this._params[sectionKey]?.[paramIndex]
			const source       = paramData?.source ?? 'data_source'
			const value        = paramData?.value ?? ''
			const defaultValue = paramData?.default_value ?? ''
			const elId         = this._elId(sectionKey, paramIndex)

			if (!value) {
				valid = false
				if (source === 'data_source') {
					this._lookups[elId]?.error()
				} else {
					document.getElementById(`${elId}_value_${source}`)?.classList.add('is-invalid')
				}
			}

			if (source === 'data_source' && !defaultValue) {
				valid = false
				document.getElementById(`${elId}_default_value`)?.classList.add('is-invalid')
			}
		}

		this._groups.forEach(group => {
			if (group.type === 'card') {
				group.subsections.forEach(sub => sub.params.forEach(p => checkParam(sub.key, p)))
			} else {
				group.params.forEach(p => checkParam(group.key, p))
			}
		})

		return valid
	}

	// =========================================
	// Private — lifecycle
	// =========================================

	/**
	 * @param {Object|null} value  Selected template object from lookup
	 * @returns {Promise<void>}
	 */
	async _onTemplateChange(value) {
		if (!value?.id) {
			this._clearAll()
			return
		}

		await this._loadTemplate(value.id, null)
	}

	/**
	 * @param {string}             id
	 * @param {Object|string|null} savedParams
	 * @returns {Promise<void>}
	 */
	async _loadTemplate(id, savedParams) {
		Helper.loadingPage(true)

		try {
			this._params = {}

			if (this._templateId !== id || !this._templateData) {
				this._templateData = null
				this._templateId   = id

				// Fetch columns and template in parallel
				const [, response] = await Promise.all([
					this._ensureColumns(),
					this._fetchTemplate(id),
				])

				if (!response) {
					return
				}

				// Core form endpoint may return { success, data } or the model directly
				this._templateData = response?.data ?? response
			} else {
				await this._ensureColumns()
			}

			const groups = this._detectParamGroups(this._templateData)
			this._renderParamForm(groups)

			if (savedParams) {
				const parsed = typeof savedParams === 'string'
					? this._tryParse(savedParams)
					: savedParams

				if (parsed) {
					this._params = parsed
					this._populateFormValues()
				}
			}

			this._renderPreview()
		} catch (error) {
			console.error({error})
		} finally {
			Helper.loadingPage(false)
		}
	}

	/**
	 * @param {string} id
	 * @returns {Promise<Object|null>}
	 */
	async _fetchTemplate(id) {
		return Model.get('WaTemplateDetail', id)
	}

	/**
	 * Fetches contact columns from backend (lazy, cached).
	 * @returns {Promise<void>}
	 */
	async _ensureColumns() {
		if (this._columns.length > 0) {
			return
		}
		const res = await axios.get(`${BASE_URL}/marketing/wa-blast/template-param-columns`)
		this._columns = res.data ?? []
	}

	// =========================================
	// Private — param detection
	// =========================================

	/**
	 * Extracts {{N}} param groups from all template sections.
	 * Carousel cards are returned as a single CardGroup with subsections.
	 * @param {Object} data  WaTemplateDetail record
	 * @returns {ParamGroup[]}
	 */
	_detectParamGroups(data) {
		/** @type {ParamGroup[]} */
		const groups  = []
		const buttons = this._parseJson(data.buttons) ?? []
		const cards   = this._parseJson(data.cards)   ?? []

		const categoryId = data.wa_template?.category_id
		const subTypeId  = data.sub_type_id
		const isCarousel = categoryId === WaTemplateCategory.Marketing
		                && subTypeId  === WaTemplateSubType.Carousel

		// Header — only when text type
		if (data.header_type_id === WaTemplateHeaderType.Text) {
			const params = this._extractParams(data.header_content)
			if (params.length > 0) {
				groups.push({ type: 'simple', key: 'header', label: 'Header', params })
			}
		}

		// Body
		const bodyParams = this._extractParams(data.body)
		if (bodyParams.length > 0) {
			groups.push({ type: 'simple', key: 'body', label: 'Body', params: bodyParams })
		}

		if (isCarousel) {
			// Each card becomes one CardGroup containing its body + buttons as subsections
			cards.forEach((card, cardIndex) => {
				/** @type {Array<{key: string, label: string, params: number[]}>} */
				const subsections = []

				const cardBodyParams = this._extractParams(card.body)
				if (cardBodyParams.length > 0) {
					subsections.push({
						key   : `card_${cardIndex}_body`,
						label : 'Body',
						params: cardBodyParams,
					})
				}

				// Card buttons: type lives in the shared button schema, not per-card.
				// Detect params from btn.value directly without type guard.
				const cardButtons = Array.isArray(card.buttons) ? card.buttons : []
				cardButtons.forEach((btn, btnIndex) => {
					const btnParams = this._extractParams(btn.value)
					if (btnParams.length > 0) {
						const btnLabel = btn.label ? ` — ${btn.label}` : ''
						subsections.push({
							key   : `card_${cardIndex}_button_${btnIndex}`,
							label : `Button ${btnIndex + 1}${btnLabel}`,
							params: btnParams,
						})
					}
				})

				if (subsections.length > 0) {
					groups.push({
						type       : 'card',
						key        : `card_${cardIndex}`,
						label      : `Card ${cardIndex + 1}`,
						subsections,
					})
				}
			})
		} else {
			// Regular template URL buttons only
			buttons.forEach((btn, btnIndex) => {
				if (btn.type !== 'url') {
					return
				}
				const btnParams = this._extractParams(btn.value)
				if (btnParams.length > 0) {
					const btnLabel = btn.label ? ` — ${btn.label}` : ''
					groups.push({
						type  : 'simple',
						key   : `button_${btnIndex}`,
						label : `Button ${btnIndex + 1}${btnLabel}`,
						params: btnParams,
					})
				}
			})
		}

		return groups
	}

	/**
	 * @param {string|null} text
	 * @returns {number[]} Sorted unique {{N}} indices found in text
	 */
	_extractParams(text) {
		if (!text) {
			return []
		}
		const matches = [...text.matchAll(/\{\{(\d+)\}\}/g)]
		return [...new Set(matches.map(m => parseInt(m[1])))].sort((a, b) => a - b)
	}

	// =========================================
	// Private — rendering
	// =========================================

	/**
	 * Builds the grouped param form HTML and attaches listeners.
	 * @param {ParamGroup[]} groups
	 * @returns {void}
	 */
	_renderParamForm(groups) {
		if (!this._container) {
			return
		}

		this._groups = groups
		this._container.style.display = ''

		if (groups.length === 0) {
			this._container.innerHTML = '<p class="text-muted small mb-0">This template has no parameters.</p>'
			return
		}

		let html = ''

		groups.forEach((group, groupIndex) => {
			const mt = groupIndex > 0 ? ' class="mt-3"' : ''

			if (group.type === 'card') {
				html += this._renderCardGroup(group, mt)
			} else {
				html += this._renderSimpleGroup(group, mt)
			}
		})

		this._container.innerHTML = html

		// Init LookupInput on all data source selects
		this._initLookups(groups)

		// Attach param field listeners
		groups.forEach(group => {
			if (group.type === 'card') {
				group.subsections.forEach(sub => {
					sub.params.forEach(p => this._attachParamListeners(sub.key, p))
				})
			} else {
				group.params.forEach(p => this._attachParamListeners(group.key, p))
			}
		})

		// Attach collapse chevron rotation listeners
		this._initCollapseChevrons()

		// Re-apply disabled state after DOM rebuild
		this.setDisabled(this._disabled)
	}

	/**
	 * @param {SimpleGroup} group
	 * @param {string}      mt   Class string for top margin
	 * @returns {string}
	 */
	_renderSimpleGroup(group, mt) {
		const collapseId = `wa-blast-section-${group.key}`

		return `
			<div${mt}>
				${this._sectionHeader(group.label, collapseId)}
				<div id="${collapseId}" class="collapse show">
					${group.params.map(p => this._paramRow(group.key, p)).join('')}
				</div>
			</div>
		`
	}

	/**
	 * @param {CardGroup} group
	 * @param {string}    mt   Class string for top margin
	 * @returns {string}
	 */
	_renderCardGroup(group, mt) {
		const collapseId = `wa-blast-section-${group.key}`

		let subsHtml = ''
		group.subsections.forEach((sub, subIndex) => {
			subsHtml += `
				<div${subIndex > 0 ? ' class="mt-2"' : ''}>
					<p class="text-muted small mb-1 mt-2">${this._esc(sub.label)}</p>
					<div class="border-bottom mb-2"></div>
					${sub.params.map(p => this._paramRow(sub.key, p)).join('')}
				</div>
			`
		})

		return `
			<div${mt}>
				${this._sectionHeader(group.label, collapseId)}
				<div id="${collapseId}" class="collapse show ps-3">
					${subsHtml}
				</div>
			</div>
		`
	}

	/**
	 * Renders a collapsible section header button with a chevron icon.
	 * @param {string} label
	 * @param {string} collapseId
	 * @returns {string}
	 */
	_sectionHeader(label, collapseId) {
		return `
			<button type="button"
				class="btn btn-link p-0 d-flex align-items-center w-100 gap-1 text-decoration-none text-reset"
				data-bs-toggle="collapse"
				data-bs-target="#${collapseId}"
				aria-expanded="true">
				<i class="ti ti-chevron-down section-chevron" style="font-size:.8rem;transition:transform .2s;"></i>
				<span class="text-muted small fw-semibold">${this._esc(label)}</span>
				<span class="flex-fill border-bottom ms-1" style="margin-top:1px"></span>
			</button>
		`
	}

	/**
	 * Renders a single param input row (badge + source select + value field).
	 * LookupInput is initialized separately via _initLookups() after innerHTML is set.
	 * @param {string} sectionKey
	 * @param {number} paramIndex
	 * @returns {string}
	 */
	_paramRow(sectionKey, paramIndex) {
		const elId     = this._elId(sectionKey, paramIndex)
		const sourceId = `${elId}_source`

		return `
			<div class="row g-2 align-items-center mb-2">
				<div class="col-auto">
					<span class="badge text-bg-secondary">&#123;&#123;${paramIndex}&#125;&#125;</span>
				</div>
				<div class="col-auto" style="min-width:160px">
					<select id="${sourceId}" class="form-select form-select-sm">
						<option value="data_source">Data source</option>
						<option value="hardcode">Hardcode</option>
					</select>
				</div>
				<div class="col">
					${LookupInput.renderHTML({ size: 'sm', placeholder: 'Select column' }, { id: `${elId}_value_data_source` })}
					<input type="text"
						id="${elId}_value_hardcode"
						class="form-control form-control-sm d-none"
						placeholder="Enter value...">
				</div>
				<div class="col" id="${elId}_default_value_wrap">
					<input type="text"
						id="${elId}_default_value"
						class="form-control form-control-sm"
						placeholder="Default value (if empty)...">
				</div>
			</div>
		`
	}

	/**
	 * Instantiates LookupInput on every data source select in the current param form.
	 * Must be called after innerHTML is set.
	 * @param {ParamGroup[]} groups
	 * @returns {void}
	 */
	_initLookups(groups) {
		this._lookups = {}

		const attach = (sectionKey, paramIndex) => {
			const elId = this._elId(sectionKey, paramIndex)
			const el   = document.getElementById(`${elId}_value_data_source`)
			if (!el) {
				return
			}
			this._lookups[elId] = new LookupInput(el, {
				data       : this._columns,
				placeholder: 'Select column',
			})
		}

		groups.forEach(group => {
			if (group.type === 'card') {
				group.subsections.forEach(sub => sub.params.forEach(p => attach(sub.key, p)))
			} else {
				group.params.forEach(p => attach(group.key, p))
			}
		})
	}

	/**
	 * Attaches collapse chevron rotation listeners for all section headers in the container.
	 * @returns {void}
	 */
	_initCollapseChevrons() {
		this._container.querySelectorAll('[data-bs-toggle="collapse"]').forEach(btn => {
			const target = document.querySelector(btn.dataset.bsTarget)
			if (!target) {
				return
			}

			target.addEventListener('hide.bs.collapse', () => {
				const icon = btn.querySelector('.section-chevron')
				if (icon) icon.style.transform = 'rotate(-90deg)'
			})

			target.addEventListener('show.bs.collapse', () => {
				const icon = btn.querySelector('.section-chevron')
				if (icon) icon.style.transform = 'rotate(0deg)'
			})
		})
	}

	/**
	 * Attaches change/input listeners to a single param row.
	 * @param {string} sectionKey
	 * @param {number} paramIndex
	 * @returns {void}
	 */
	_attachParamListeners(sectionKey, paramIndex) {
		const elId     = this._elId(sectionKey, paramIndex)
		const sourceEl = this._getSourceEl(sectionKey, paramIndex)
		const hcEl     = document.getElementById(`${elId}_value_hardcode`)

		const defaultEl = document.getElementById(`${elId}_default_value`)

		sourceEl?.addEventListener('change', () => {
			this._applySourceToggle(sectionKey, paramIndex)
			this._saveParamValue(sectionKey, paramIndex)
			this._renderPreview()
		})

		this._lookups[elId]?.on('change', () => {
			this._saveParamValue(sectionKey, paramIndex)
			this._renderPreview()

			const value = this._lookups[elId]?.get()?.id ?? ''
			if (value) {
				this._lookups[elId].resetValidation()
			} else {
				this._lookups[elId].error()
			}
		}, 'WaBlastWaTemplate')

		hcEl?.addEventListener('input', () => {
			this._saveParamValue(sectionKey, paramIndex)
			this._renderPreview()

			hcEl.classList.toggle('is-invalid', !hcEl.value)
		})

		defaultEl?.addEventListener('input', () => {
			this._saveParamValue(sectionKey, paramIndex)

			defaultEl.classList.toggle('is-invalid', !defaultEl.value)
		})
	}

	/**
	 * Toggles visibility of value fields based on current source selection.
	 * @param {string} sectionKey
	 * @param {number} paramIndex
	 * @returns {void}
	 */
	_applySourceToggle(sectionKey, paramIndex) {
		const elId      = this._elId(sectionKey, paramIndex)
		const source    = this._getSourceEl(sectionKey, paramIndex)?.value ?? 'data_source'
		const isDataSrc = source === 'data_source'

		const lookup = this._lookups[elId]
		if (lookup) {
			isDataSrc ? lookup.show() : lookup.hidden()
			lookup.reset(true)
		}

		document.getElementById(`${elId}_value_hardcode`)
			?.classList.toggle('d-none', isDataSrc)

		document.getElementById(`${elId}_default_value_wrap`)
			?.classList.toggle('d-none', !isDataSrc)
	}

	/**
	 * Reads current DOM values for a param and stores in _params.
	 * @param {string} sectionKey
	 * @param {number} paramIndex
	 * @returns {void}
	 */
	_saveParamValue(sectionKey, paramIndex) {
		const elId     = this._elId(sectionKey, paramIndex)
		const sourceEl = this._getSourceEl(sectionKey, paramIndex)

		if (!sourceEl) {
			return
		}

		const source = sourceEl.value

		let value = ''
		if (source === 'data_source') {
			value = this._lookups[elId]?.get()?.id ?? ''
		} else {
			const valueEl = document.getElementById(`${elId}_value_${source}`)
			value = valueEl?.value ?? ''
		}

		if (!this._params[sectionKey]) {
			this._params[sectionKey] = {}
		}

		const defaultValue = source === 'data_source'
			? (document.getElementById(`${elId}_default_value`)?.value ?? '')
			: ''

		this._params[sectionKey][paramIndex] = { source, value, default_value: defaultValue }
	}

	/**
	 * Populates form fields from current _params state. Called after loading saved params.
	 * @returns {void}
	 */
	_populateFormValues() {
		Object.entries(this._params).forEach(([sectionKey, paramMap]) => {
			Object.entries(paramMap).forEach(([paramIndexStr, paramData]) => {
				const paramIndex = parseInt(paramIndexStr)
				const elId       = this._elId(sectionKey, paramIndex)
				const sourceEl   = this._getSourceEl(sectionKey, paramIndex)

				if (!sourceEl) {
					return
				}

				sourceEl.value = paramData.source ?? 'data_source'
				this._applySourceToggle(sectionKey, paramIndex)

				if ((paramData.source ?? 'data_source') === 'data_source') {
					// Populate default_value BEFORE lookup.set() — set() may trigger change →
					// _saveParamValue reads DOM, so DOM must be correct first.
					const defaultEl = document.getElementById(`${elId}_default_value`)
					if (defaultEl) {
						defaultEl.value = paramData.default_value ?? ''
					}

					const col = this._columns.find(c => c.id === paramData.value)
					if (col) {
						this._lookups[elId]?.set(col)
					}
				} else {
					const valueEl = document.getElementById(`${elId}_value_${paramData.source}`)
					if (valueEl) {
						valueEl.value = paramData.value ?? ''
					}
				}
			})
		})
	}

	// =========================================
	// Private — preview
	// =========================================

	/**
	 * Renders the WhatsApp preview using current template data and param values.
	 * @returns {void}
	 */
	_renderPreview() {
		if (!this._preview || !this._templateData) {
			return
		}

		const data       = this._templateData
		const categoryId = data.wa_template?.category_id
		const subTypeId  = data.sub_type_id
		const isCarousel = categoryId === WaTemplateCategory.Marketing
		                && subTypeId  === WaTemplateSubType.Carousel

		const buttons = this._parseJson(data.buttons) ?? []
		const cards   = this._parseJson(data.cards)   ?? []

		this._preview.clearMessages()

		if (isCarousel) {
			this._renderCarouselPreview(data, cards)
			return
		}

		this._renderRegularPreview(data, buttons)
	}

	/**
	 * @param {Object}   data
	 * @param {Object[]} cards
	 * @returns {void}
	 */
	_renderCarouselPreview(data, cards) {
		const body         = this._substituteParams(data.body ?? '', 'body')
		const headerTypeId = data.header_type_id
		const mediaType    = headerTypeId === WaTemplateHeaderType.Video ? 'video' : 'image'

		const previewCards = cards.map((card, cardIndex) => ({
			id        : `card-${cardIndex}`,
			media_type: mediaType,
			src       : card.header_content ?? card.media_url ?? '',
			body      : this._substituteParams(card.body ?? '', `card_${cardIndex}_body`),
			buttons   : (Array.isArray(card.buttons) ? card.buttons : []).map(btn => ({
				type : btn.type ?? 'quick_reply',
				label: btn.label ?? '',
			})),
		}))

		this._preview.addCarousel({ text: body, cards: previewCards })
	}

	/**
	 * @param {Object}   data
	 * @param {Object[]} buttons
	 * @returns {void}
	 */
	_renderRegularPreview(data, buttons) {
		const typeMap = {
			[WaTemplateHeaderType.Text]    : 'text',
			[WaTemplateHeaderType.Image]   : 'image',
			[WaTemplateHeaderType.Video]   : 'video',
			[WaTemplateHeaderType.Document]: 'document',
		}

		let header = null
		if (data.header_type_id) {
			let headerValue = data.header_content ?? ''
			if (data.header_type_id === WaTemplateHeaderType.Text) {
				headerValue = this._substituteParams(headerValue, 'header')
			}
			header = { type: typeMap[data.header_type_id], value: headerValue }
		}

		const previewButtons = buttons.map(btn => ({
			type : btn.type ?? 'quick_reply',
			label: btn.label ?? '',
		}))

		this._preview.addTemplateMessage({
			id     : 'main',
			header,
			text   : this._substituteParams(data.body ?? '', 'body'),
			footer : data.footer ?? '',
			buttons: previewButtons,
		})
	}

	/**
	 * Replaces {{N}} placeholders with resolved param values.
	 * data_source → "[Column Label]", hardcode → actual value (or original if empty).
	 * @param {string} text
	 * @param {string} sectionKey
	 * @returns {string}
	 */
	_substituteParams(text, sectionKey) {
		if (!text) {
			return ''
		}

		return text.replace(/\{\{(\d+)\}\}/g, (match, numStr) => {
			const paramIndex = parseInt(numStr)
			const paramData  = this._params[sectionKey]?.[paramIndex]

			if (!paramData) {
				return match
			}

			if (paramData.source === 'data_source') {
				const col = this._columns.find(c => c.id === paramData.value)
				return col ? `[${col.name}]` : match
			}

			return paramData.value || match
		})
	}

	/**
	 * Clears preview, hides and empties the param form.
	 * @returns {void}
	 */
	_clearAll() {
		this._templateData = null
		this._templateId   = null
		this._params       = {}
		this._lookups      = {}
		this._groups       = []

		if (this._container) {
			this._container.style.display = 'none'
			this._container.innerHTML     = ''
		}

		this._preview?.clearMessages()
	}

	// =========================================
	// Private — helpers
	// =========================================

	/**
	 * Returns true when the form status is not Draft or Failed (fields should be read-only).
	 * @returns {boolean}
	 */
	_computeDisabled() {
		const statusId = this._form.get('status_id')?.get()?.id
		if (!statusId) {
			return false
		}
		return statusId !== CampaignBlastStatus.Draft && statusId !== CampaignBlastStatus.Failed
	}

	/**
	 * Reads initial template_params from the container's data attribute (server-rendered).
	 * @returns {Object|null}
	 */
	_readInitialParams() {
		const raw = this._container?.dataset?.params
		if (!raw || raw === 'null') {
			return null
		}
		return this._tryParse(raw)
	}

	/**
	 * @param {string} sectionKey
	 * @param {number} paramIndex
	 * @returns {string}
	 */
	_elId(sectionKey, paramIndex) {
		return `wa-blast-param-${sectionKey}-${paramIndex}`
	}

	/**
	 * @param {string} sectionKey
	 * @param {number} paramIndex
	 * @returns {HTMLSelectElement|null}
	 */
	_getSourceEl(sectionKey, paramIndex) {
		return document.getElementById(`${this._elId(sectionKey, paramIndex)}_source`)
	}

	/**
	 * @param {string|Array|null} value
	 * @returns {Array|null}
	 */
	_parseJson(value) {
		if (Array.isArray(value)) {
			return value
		}
		if (typeof value === 'string') {
			return this._tryParse(value)
		}
		return value ?? null
	}

	/**
	 * @param {string} str
	 * @returns {any|null}
	 */
	_tryParse(str) {
		try {
			return JSON.parse(str)
		} catch {
			return null
		}
	}

	/**
	 * @param {string|number} text
	 * @returns {string} HTML-escaped string
	 */
	_esc(text) {
		const d = document.createElement('div')
		d.appendChild(document.createTextNode(String(text)))
		return d.innerHTML
	}
}
