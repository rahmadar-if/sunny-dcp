import ActivityDetail from "@master-data-js/pages/activity/detail";

export default class WaBlastActivityDetail extends ActivityDetail {
    init() {
        super.init()
    }
}