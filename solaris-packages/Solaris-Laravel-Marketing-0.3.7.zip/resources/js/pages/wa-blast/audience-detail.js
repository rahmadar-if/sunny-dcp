import SolarListDetail from "@core-js/solaris/solar/solar-list-detail";
import AudienceSegmentationModal from "../audience-segmentation-modal";
import { WaBlastAudienceStatus } from "@marketing-js/const";
import WaBlastAudienceModal from "./audience-detail-modal";
import LookupInput from "@core-js/solaris/form/lookup-input";
import Filter from "@core-js/solaris/filter/filter";

export default class WaBlastAudienceDetail extends SolarListDetail {
    init() {
        this.eventAudienceModal = new WaBlastAudienceModal()

        this.columnRender("contact_id", this.contactColumnRender.bind(this))
        this.columnRender("status_id", this.statusColumnRender.bind(this))
        this.columnRender("replied", this.repliedColumnRender.bind(this))
        
        this.addSegmenBtn = this.get("add-wa-blast-segmentation")

        /** @type { LookupInput } */
        this.statusFilter = new LookupInput("div[solar-id='audience_status_filter']")
    }

    contactColumnRender(data, rowData) {
        const initialName = this.helper.getInitialName(data)
        return `<div class="d-flex align-items-center gap-2">
            <div class="lh-1">
                <span class="avatar avatar-rounded avatar-sm ${!rowData.contact.profile_picture_id ? "bg-secondary" : ""}">
                    ${rowData.contact.profile_picture_id ? `<img src="${BASE_URL}/core/images/thumbnail/${rowData.contact.profile_picture_id}" alt="">` : initialName}
                </span>
            </div>
            <div class="d-flex flex-column gap-1">
                <a class="text-decoration-underline" href="${BASE_URL}/master-data/contact/edit/${rowData.contact_id}">${data}</a>
                <span class="text-muted fs-12"><i class="ri-smartphone-line me-2"></i></i>${rowData.contact.primary_mobile_phone ?? ""}</span>
            </div>
        </div>`
    }

    statusColumnRender(data, rowData) {
        let color = 'primary'
        switch (rowData.status?.id) {
            case WaBlastAudienceStatus.Progress:
                color = "info"
                break
            case WaBlastAudienceStatus.Sent:
            case WaBlastAudienceStatus.Read:
                color = "success"
                break
            case WaBlastAudienceStatus.Failed:
                color = "danger"
                break
            default:
                color = "primary"
                break
        }

        return `<span class="badge bg-${color}">${data}</span>`
    }

    repliedColumnRender(data, rowData) {
        if (!data) {
            return `<span class="badge bg-danger">No Replied</span>`
        }

        const payloads = JSON.parse(data)
        if (!payloads || payloads.length === 0) {
            return `<span class="badge bg-danger">No Replied</span>`
        }

        return payloads.map(payload => `<span class="badge bg-primary">${payload}</span>`).join(' ')
    }

    async ready(settings, json) {
        this.segmentation = new AudienceSegmentationModal(
            "wa-blast-segmentation", 
            `${BASE_URL}/marketing/wa-blast/add-audience`,
            "wa_blast_id",
            this.parentValue.id
        )

        this.segmentation.on("change", () => this.refresh())
        
        this.addSegmenBtn.on("click", () => this.segmentation.addSegmentation())
        this.addSegmenBtn.enabled()

        this.statusFilter.enabled()
        this.statusFilter.on("change", (val) => {
            this.table.filter("status", val ? new Filter().andIn("status_id", val.map(i => i.id)) : null)
        })
    }
}