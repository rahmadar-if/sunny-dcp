import SolarListPage from "@core-js/solaris/solar/solar-list-page";

export default class EmailBlastListPage extends SolarListPage {
    init() {
        this.columnRender("title", this.titleColumnRender.bind(this))
        this.columnCreated("title", this.titleColumnCreated.bind(this))
    }

    openEditPage(id) {
        this.helper.loadingPage(true)
        window.location = `${BASE_URL}/marketing/email-blast/edit/${id}`
    }

    async edit(row, data) {
        this.openEditPage(data.id)
    }

    rowDoubleClick(row, data) {
        this.openEditPage(data.id)
    }

    titleColumnRender(data, rowData) {
        const priority = {
            High  : 'danger',
            Medium: 'info',
            Low   : 'success'
        }
        const priorityColor = priority[rowData.priority.name]
        const statusColor   = rowData.status.color
        const openPercent   = rowData.total_success > 0 ? (rowData.total_unique_open / rowData.total_success * 100).toFixed(2) : 0
        const clickPercent  = rowData.total_success > 0 ? (rowData.total_unique_click / rowData.total_success * 100).toFixed(2) : 0

        const thumbHtml = rowData.body
            ? `<div class="template-thumb-container">
                <iframe class="template-thumb-iframe" frameborder="0"></iframe>
            </div>`
            : `<div class="template-thumb-container no-template">
                <i class="ri-mail-forbid-line fs-3"></i>
                <small>No template</small>
            </div>`

        return `<div class="d-flex flex-column align-items-stretch gap-2">
            ${thumbHtml}
            <h6
                class="fw-medium mb-0 d-inline-block text-truncate align-middle"
                style="max-width: 20rem;"
                data-bs-toggle="tooltip"
                data-bs-placement="top"
                data-bs-title="${data}">
                <a href="${BASE_URL}/marketing/email-blast/edit/${rowData.id}">${data}</a>
            </h6>
            <span class="text-muted">${rowData.created_by.name}</span>
            <div class="d-flex gap-2 flex-wrap align-items-center mb-2"> 
                <span class="badge rounded-pill fs-11 bg-${priorityColor}">${rowData.priority.name}</span> 
                <span class="badge rounded-pill fs-11 bg-${statusColor}">${rowData.status.name}</span> 
            </div>
            <div class="d-flex gap-2 flex-wrap align-items-center">
                <span class="badge rounded-pill fs-11 border border-primary border-opacity-10 text-primary bg-primary-transparent">
                    <i class="ri-contacts-line me-1"></i>Audience: ${rowData.total_audience} contact
                </span>
                <span class="badge rounded-pill fs-11 border border-success border-opacity-10 text-success bg-success-transparent">
                    <i class="ri-mail-open-line me-1"></i>Open: ${openPercent}%
                </span>
                <span class="badge rounded-pill fs-11 border border-info border-opacity-10 text-info bg-info-transparent">
                    <i class="ri-cursor-line me-1"></i>Click: ${clickPercent}%
                </span>
            </div>
            <div class="d-flex gap-1 my-2"> 
                <a href="${BASE_URL}/marketing/email-blast/edit/${rowData.id}" class="btn btn-wave btn-primary waves-effect waves-light flex-fill">Open campaign</a>
                <button type="button" class="btn btn-danger delete-action"><i class="ri-delete-bin-fill"></i></button>
            </div>
        </div>`
    }

    titleColumnCreated(row, cell, cellData, rowData) {
        if(rowData.body) {
            cell.querySelector(".template-thumb-iframe").srcdoc = rowData.body
        }

        cell.querySelector("button.delete-action")
            .addEventListener("click", async(e) => this.table.delete(row, rowData))
    }
}