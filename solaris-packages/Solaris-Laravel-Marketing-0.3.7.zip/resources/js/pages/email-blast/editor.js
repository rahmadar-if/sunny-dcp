import StripoEditor from "@marketing-js/solaris/stripo-editor"
import SolarPage from "@core-js/solaris/solar/solar-page"
import Button from "@core-js/solaris/button"

export default class EmailBlastEditor extends SolarPage {
	init() {
		this.id = document.querySelector(`input[type="hidden"][name="email_blast_id"]`)?.value

		this._initChooseTemplateModal()
		this._initSaveTemplateModal()

		/** @type {Button} */
		this.chooseTemplateBtn = this.get("choose-template-button")
		this.chooseTemplateBtn?.on("click", () => this._chooseTemplateModal.show())

		/** @type {Button} */
		this.saveTemplateBtn = this.get("save-template-button")
		this.saveTemplateBtn?.on("click", () => this._saveTemplateModal.modal.show())

		this.stripoEditor = new StripoEditor('#stripo-editor', STRIPO_EMAIL_ID, TEMPLATE_HTML, TEMPLATE_CSS, [], "email_editor")
		this.stripoEditor
			?.on("ready", this.ready.bind(this))
			.on("change-template", this.onChangeTemplate.bind(this))
			.on("save", this.save.bind(this))
	}

	ready() {
		this.chooseTemplateBtn?.enabled()
		this.saveTemplateBtn?.enabled()
	}

	onChangeTemplate() {
		this.chooseTemplateBtn?.disabled()
		this.saveTemplateBtn?.disabled()
	}

	async save({html, css, width, height, htmlCompiled, ampHtml}) {
		const data = {
			html,
			css,
			body: htmlCompiled
		}

		const req = await this.axios({
			method: "PUT",
			url: `${BASE_URL}/marketing/email-blast/editor/${this.id}`,
			data: data
		})

		const res = req.data
		if(!res.success) {
			this.helper.toast({message: "Some fields are invalid or incomplete. Please check again.", color: "danger"})
			return
		}

		this.helper.successAlert({title: "Data saved successfully"})
	}

	_initChooseTemplateModal() {
		this._chooseTemplateModal = this.get("choose-template-modal")
		this._chooseTemplateTable = this.get("choose-template-modal_table")
		this._chooseTemplateTable
			?.on("column render:name", this.chooseTemplateRender.bind(this))
			.on("column created:name", this.chooseTemplateCreated.bind(this))
			.render()
	}

	_initSaveTemplateModal() {
		this._saveTemplateModal = this.get("save-template-modal_ModalForm")
		this._saveTemplateModal?.form
			.hiddenSuccessAlert()
			.on("submitting", this._confirmSaveTemplate.bind(this))
			.on("success", () => {
				this.helper.successAlert({title: "Template saved successfully"})
			})
	}

	chooseTemplateRender(data, rowData) {
		return `<div class="card template-picker-card" data-id="${rowData.id}">
			<div class="template-thumb-container card-img-top">
				<iframe class="template-thumb-iframe" frameborder="0"></iframe>
			</div>
			<div class="card-footer text-center py-2">
				<small class="fw-medium text-truncate d-block">${rowData.name}</small>
			</div>
		</div>`
	}

	chooseTemplateCreated(row, cell, cellData, rowData) {
		cell.querySelector('.template-thumb-iframe').srcdoc = rowData.html_compiled ?? ''
		cell.querySelector('.card').addEventListener('click', () => this._selectTemplate(rowData))
	}

	async _selectTemplate(template) {
		if(!await this.helper.confirm({title: "Replace current content?", text: "This will replace the current email content with the selected template."})) {
			return
		}

		this._chooseTemplateModal?.hide()
		this.stripoEditor?.setTemplate(template.html, template.css)
	}

	async _confirmSaveTemplate() {
		if(!this.stripoEditor) {
			return
		}
		
		const [templateData, compiled] = await Promise.all([
			this.stripoEditor.getTemplateData(),
			this.stripoEditor.compile()
		])

		this._saveTemplateModal?.form
			.addData('html', templateData.html)
			.addData('css', templateData.css)
			.addData('width', templateData.width)
			.addData('height', templateData.height)
			.addData('html_compiled', compiled.html)
			.addData('amp_html', compiled.ampHtml ?? null)
	}
}
