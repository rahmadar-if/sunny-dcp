import EmailBlastEditor from "./editor"

new EmailBlastEditor()