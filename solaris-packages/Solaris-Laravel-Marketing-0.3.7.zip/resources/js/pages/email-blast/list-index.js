import EmailBlastListPage from "./list"

new EmailBlastListPage("email-blast")