import EmailBlastPage from "./page"

new EmailBlastPage()