import ActivityDetail from "@master-data-js/pages/activity/detail";

export default class EmailBlastActivityDetail extends ActivityDetail {
    init() {
        super.init()
    }
}