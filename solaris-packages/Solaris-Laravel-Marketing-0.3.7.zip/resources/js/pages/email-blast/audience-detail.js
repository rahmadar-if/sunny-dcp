import SolarListDetail from "@core-js/solaris/solar/solar-list-detail";
import AudienceSegmentationModal from "../audience-segmentation-modal";
import EmailBlastAudienceModal from "./audience-detail-modal";
import { EmailBlastAudienceStatus } from "@marketing-js/const";
import LookupInput from "@core-js/solaris/form/lookup-input";
import Filter from "@core-js/solaris/filter/filter";

export default class EmailBlastAudienceDetail extends SolarListDetail {
    init() {
        this.eventAudienceModal = new EmailBlastAudienceModal()

        this.columnRender("contact_id", this.contactColumnRender.bind(this))
        this.columnRender("status_id", this.statusColumnRender.bind(this))
        this.columnRender("open", this.openClickColumnRender.bind(this))
        this.columnRender("click", this.openClickColumnRender.bind(this))
        this.columnRender("unsubscribe", this.spamUnsubColumnRender.bind(this))
        this.columnRender("spam", this.spamUnsubColumnRender.bind(this))
        
        this.addSegmenBtn = this.get("add-email-blast-segmentation")

        /** @type { LookupInput } */
        this.statusFilter = new LookupInput("div[solar-id='audience_status_filter']")
    }

    contactColumnRender(data, rowData) {
        const initialName = this.helper.getInitialName(data)
        return `<div class="d-flex align-items-center gap-2">
            <div class="lh-1">
                <span class="avatar avatar-rounded avatar-sm ${!rowData.contact.profile_picture_id ? "bg-secondary" : ""}">
                    ${rowData.contact.profile_picture_id ? `<img src="${BASE_URL}/core/images/thumbnail/${rowData.contact.profile_picture_id}" alt="">` : initialName}
                </span>
            </div>
            <div class="d-flex flex-column gap-1">
                <a class="text-decoration-underline" href="${BASE_URL}/master-data/contact/edit/${rowData.contact_id}">${data}</a>
                <span class="text-muted fs-12"><i class="ri-mail-line me-2"></i>${rowData.contact.email ?? ""}</span>
            </div>
        </div>`
    }

    statusColumnRender(data, rowData) {
        let color = 'primary'
        switch (rowData.status?.id) {
            case EmailBlastAudienceStatus.Progress:
                color = "info"
                break
            case EmailBlastAudienceStatus.Delivered:
                color = "success"
                break
            case EmailBlastAudienceStatus.SoftBounce:
            case EmailBlastAudienceStatus.HardBounce:
                color = "danger"
                break
            default:
                color = "primary"
                break
        }

        return `<span class="badge bg-${color}">${data}</span>`
    }

    openClickColumnRender(data, rowData) {
        const color = data > 0 ? "success" : "danger"
        return `<span class="badge bg-${color}-transparent">${data}</span>`
    }

    spamUnsubColumnRender(data, rowData) {
        const color = data ? "danger" : "success"
        return `<span class="badge bg-${color}-transparent">${data ? "Yes" : "No"}</span>`
    }

    ready() {
        this.segmentation = new AudienceSegmentationModal(
            "email-blast-segmentation", 
            `${BASE_URL}/marketing/email-blast/add-audience`,
            "email_blast_id",
            this.parentValue.id
        )

        this.segmentation.on("change", () => this.refresh())
        
        this.addSegmenBtn.on("click", () => this.segmentation.addSegmentation())
        this.addSegmenBtn.enabled()

        this.statusFilter.enabled()
        this.statusFilter.on("change", (val) => {
            this.table.filter("status", val ? new Filter().andIn("status_id", val.map(i => i.id)) : null)
        })
    }
}