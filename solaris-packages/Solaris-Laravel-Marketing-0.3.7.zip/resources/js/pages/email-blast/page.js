import SolarEditPage from "@core-js/solaris/solar/solar-edit-page"
import EmailBlastStatusHistoryDetail from "./status-history-detail"
import EmailBlastAudienceDetail from "./audience-detail"
import Button from "@core-js/solaris/button"
import ModalForm from "@core-js/solaris/modal-form"
import { CampaignBlastStatus } from "@marketing-js/const"
import EmailBlastActivityDetail from "./activity-detail"
import MetricDashboard from "@core-js/solaris/metric-dashboard"
import TestEmailCooldown from "@marketing-js/solaris/test-email-cooldown"

export default class EmailBlastPage extends SolarEditPage {
    init() {
        this.displayValueName = "title"

        this.registerDetail("email-blast-audience", EmailBlastAudienceDetail, "email_blast_id")
        this.registerDetail("email-blast-activity", EmailBlastActivityDetail, "email_blast_id")
        this.registerDetail("email-blast-status-history", EmailBlastStatusHistoryDetail, "email_blast_id")
        
        this.initActionButton()
        this.initSchedule()
        this.initTestEmail()

        this.emailTemplateFrame = document.querySelector("#email-blast-page-email-template-frame")

        this._isSendNow  = false
        this._isSchedule = false

        this.form
            .addValidation("subject", (value) => this.blastValidation(value, "Subject is required"))
            .addValidation("sender_name", (value) => this.blastValidation(value, "Sender name is required"))
            .addValidation("sender_email", (value) => this.blastValidation(value, "Sender email is required"))

        this.initCampaignStatus()
    }
    
    initDetail() {
        this.emailBlastAudience?.on("ready", () => this.setAddAudienceState())
    }

    initActionButton() {
        /** @type {Button} */
        this.sendNowBtn = this.get("email-blast-page-send-now")
        this.sendNowBtn?.on("click", this.sendNow.bind(this))
        
        /** @type {Button} */
        this.cancelScheduleBtn = this.get("email-blast-page-schedule-cancel")
        this.cancelScheduleBtn?.on("click", this.cancelSchedule.bind(this))

        /** @type {Button} */
        this.editTemplateBtn = this.get("email-blast-page-edit-template")
        this.editTemplateBtn?.on("click", this.editTemplate.bind(this))
    }

    initCampaignStatus() {
        /** @type { MetricDashboard } */
        this.totalAudience = this.get("email-blast-page-total_audience")
        
        /** @type { MetricDashboard } */
        this.deliveryRate = this.get("email-blast-page-delivery_rate")
        
        /** @type { MetricDashboard } */
        this.openRate = this.get("email-blast-page-open_rate")
        
        /** @type { MetricDashboard } */
        this.clickRate = this.get("email-blast-page-click_rate")

        /** @type { MetricDashboard } */
        this.pending = this.get("email-blast-page-pending")

        /** @type { MetricDashboard } */
        this.progress = this.get("email-blast-page-progress")

        /** @type { MetricDashboard } */
        this.failedMetric = this.get("email-blast-page-failed")

        /** @type { MetricDashboard } */
        this.delivered = this.get("email-blast-page-delivered")

        /** @type { MetricDashboard } */
        this.totalOpen = this.get("email-blast-page-total_open")

        /** @type { MetricDashboard } */
        this.totalClick = this.get("email-blast-page-total_click")

        /** @type { MetricDashboard } */
        this.activeSubscribe = this.get("email-blast-page-active_subscribe")

        Array.from([
            this.totalAudience, this.deliveryRate, this.openRate, this.clickRate, 
            this.pending, this.progress, this.failedMetric, this.delivered, 
            this.totalOpen, this.totalClick, this.activeSubscribe,
        ]).forEach(m => m?.init())

        const totalUniqueOpen         = document.querySelector("#email-blast-page-total_unique_open")
        this.totalUniqueOpen          = totalUniqueOpen?.querySelector("span.value")
        this.totalUniqueOpen_percent  = totalUniqueOpen?.querySelector("span.value-percent")
        this.totalUniqueOpen_progress = totalUniqueOpen?.querySelector("div.progress")

        const totalUniqueClick         = document.querySelector("#email-blast-page-total_unique_click")
        this.totalUniqueClick          = totalUniqueClick?.querySelector("span.value")
        this.totalUniqueClick_percent  = totalUniqueClick?.querySelector("span.value-percent")
        this.totalUniqueClick_progress = totalUniqueClick?.querySelector("div.progress")

        this.clickToOpenRate = document.querySelector("#email-blast-page-click_to_open_rate")

        const totalSpam        = document.querySelector("#email-blast-page-total_spam")
        this.totalSpam         = totalSpam?.querySelector("span.value")
        this.totalSpam_percent = totalSpam?.querySelector("span.value-percent")

        const totalUnsubscribe        = document.querySelector("#email-blast-page-total_unsubscribe")
        this.totalUnsubscribe         = totalUnsubscribe?.querySelector("span.value")
        this.totalUnsubscribe_percent = totalUnsubscribe?.querySelector("span.value-percent")
    }

    setButtonState() {
        const statusId   = this.form.get("status_id")?.get()?.id
        const isEditable = [CampaignBlastStatus.Draft, CampaignBlastStatus.Failed].includes(statusId)

        if(isEditable) {
            this.sendNowBtn?.enabled()
            this.sendNowBtn?.show()
            this.scheduleBtn?.enabled()
            this.scheduleBtn?.show()
            this.cancelScheduleBtn?.disabled()
            this.cancelScheduleBtn?.hidden()
        } else if([
            CampaignBlastStatus.Queued,
            CampaignBlastStatus.Sending,
            CampaignBlastStatus.Completed,
            CampaignBlastStatus.Canceled
        ].includes(statusId)) {
            this.sendNowBtn?.disabled()
            this.sendNowBtn?.hidden()
            this.scheduleBtn?.disabled()
            this.scheduleBtn?.hidden()
            this.cancelScheduleBtn?.disabled()
            this.cancelScheduleBtn?.hidden()
        } else if(statusId == CampaignBlastStatus.Scheduled) {
            this.sendNowBtn?.disabled()
            this.sendNowBtn?.hidden()
            this.scheduleBtn?.disabled()
            this.scheduleBtn?.hidden()
            this.cancelScheduleBtn?.enabled()
            this.cancelScheduleBtn?.show()
        }

        this.setFormFieldsState(isEditable)
    }

    /**
     * @param {boolean} editable
     * @returns {void}
     */
    setFormFieldsState(editable) {
        const titleField       = this.form.get("title")
        const priorityField    = this.form.get("priority_id")
        const subjectField     = this.form.get("subject")
        const senderNameField  = this.form.get("sender_name")
        const senderEmailField = this.form.get("sender_email")

        if(editable) {
            titleField?.enabled()
            priorityField?.enabled()
            subjectField?.enabled()
            senderNameField?.enabled()
            senderEmailField?.enabled()
            this.editTemplateBtn?.enabled()
        } else {
            titleField?.disabled()
            priorityField?.disabled()
            subjectField?.disabled()
            senderNameField?.disabled()
            senderEmailField?.disabled()
            this.editTemplateBtn?.disabled()
        }
    }

    initTestEmail() {
        /** @type {Button} */
        this.testEmailBtn = this.get("email-blast-page-test-email")
        this.testEmailBtn?.on("click", () => this.testEmailModal.modal.show())

        this.testEmailCooldown = new TestEmailCooldown("email_blast", this.testEmailBtn)
        this.testEmailCooldown.sync()

        /** @type {ModalForm} */
        this.testEmailModal = this.get("email-blast-page-test-email-modal_ModalForm")

        this.testEmailModal?.form
            .hiddenSuccessAlert()
            .on("submitting", () => {
                this.testEmailModal.form.addData("id", this.id)
            })
            .on("success", (res) => {
                this.testEmailCooldown.start(res?.data?.retry_at)
                this.helper.toast({message: "Test email sent successfully!", color: "success"})
            })
            .on("error", (error) => {
                this.testEmailCooldown.startFromError(error)
            })
    }

    initSchedule() {
        /** @type {Button} */
        this.scheduleBtn = this.get("email-blast-page-schedule")
        this.scheduleBtn?.on("click", this.schedule.bind(this))
        
        /** @type {ModalForm} */
        this.scheduleModal = this.get("email-blast-schedule-modal_ModalForm")

        const handleScheduleBtnFail = () => {
            this._isSchedule = false
            this.scheduleBtn?.enabled()
        }

        this.scheduleModal?.form
            .on("submitting", () => {
                this._isSchedule = true
                this.scheduleBtn?.disabled()

                this.scheduleModal.form.addData("id", this.id)
            })
            .on("failed", () => handleScheduleBtnFail())
            .on("error", () => handleScheduleBtnFail())
            .on("success", async () => {
                await this.refreshForm()
                this.setButtonState()
            })
    }

    openScheduleModal(availableDates = []) {
        const scheduleAt = this.scheduleModal?.form.get("schedule_at")
        scheduleAt?.init({enable: availableDates})
        
        this.scheduleModal?.modal.show()
    }

    async sendNow() {
        if(!await this.helper.confirm({title: "Are you sure?"})) {
            return
        }

        this._isSendNow = true
        this.sendNowBtn?.disabled()
        this.helper.loadingPage(true)

        try {
            if(!await this.save(false)) {
                this.sendNowBtn?.enabled()
                return
            }

            const req = await this.axios({
                method: "POST",
                url: `${BASE_URL}/marketing/email-blast/send-now`,
                data: {
                    id: this.id
                }
            })
            const res = req.data
            if(!res.success) {
                throw res.message
            }
            
            this.helper.alert({title: "Processing Email Blast", message: "This process runs in the background. You can leave this page and will be notified when it's done."})
            await this.refreshForm()
            this.setButtonState()
        } catch (error) {
            this.helper.errorAlert({title: error})
            this.sendNowBtn?.enabled()
        } finally {
            this.helper.loadingPage(false)
            this._isSendNow = false
        }
    }

    async schedule() {
        if(!await this.helper.confirm({title: "Are you sure?"})) {
            return
        }

        this.helper.loadingPage(true)
    
        try {
            if(!await this.save(false)) {
                return
            }
            
            const req = await this.axios({
                method: "GET",
                url: `${BASE_URL}/marketing/email-blast/available-schedule`,
            })
            const res = req.data

            if(res.success && res.data) {
                this.openScheduleModal([res.data])
            }
        } catch (error) {
            this.helper.errorAlert({title: error})
        } finally {
            this.helper.loadingPage(false)
        }
    }

    async cancelSchedule() {
        if(!await this.helper.confirm({title: "Are you sure?"})) {
            return
        }

        this.helper.loadingPage(true)
    
        try {
            const req = await this.axios({
                method: "POST",
                url: `${BASE_URL}/marketing/email-blast/cancel-schedule`,
                data: {
                    id: this.id
                }
            })
            const res = req.data
            if(!res.success) {
                throw res.message
            }

            await this.refreshForm()
            this.setButtonState()
        } catch (error) {
            this.helper.errorAlert({title: error})
        } finally {
            this.helper.loadingPage(false)
        }
    }

    async onRefreshed(data) {
        this.breadcrumbName.innerText = data.title
        this.setButtonState()

        this.form.get("sender_email")?.set(data.sender_email?.split("@")[0] ?? "")
        
        if(data.body) {
            this.testEmailBtn?.enabled()
            this.emailTemplateFrame.contentWindow.location.reload()
        } else {
            this.testEmailBtn?.disabled()
        }

        this.setAddAudienceState()
        this.campaignStatusRefresh(data)
    }
    
    campaignStatusRefresh(data) {
        this.totalAudience?.setValue(data.total_audience)
        this.deliveryRate?.setValue(this.helper.readableNumber(data.delivery_rate, 1) + "%")
        this.openRate?.setValue(this.helper.readableNumber(data.open_rate, 1) + "%")
        this.clickRate?.setValue(this.helper.readableNumber(data.click_rate, 1) + "%")

        this.pending?.setValue(data.total_pending)
        this.pending?.setChange({value: this.helper.readableNumber(data.total_pending_percent, 1) + "%"})

        this.progress?.setValue(data.total_progress)
        this.progress?.setChange({value: this.helper.readableNumber(data.total_pending_percent, 1) + "%"})

        this.failedMetric?.setValue(data.total_fail)
        this.failedMetric?.setChange({value: this.helper.readableNumber(data.total_fail_percent, 1) + "%"})

        this.delivered?.setValue(data.total_success)
        this.delivered?.setChange({value: this.helper.readableNumber(data.total_delivered_percent, 1) + "%"})

        this.totalOpen?.setValue(data.total_open)
        this.totalOpen?.setChange({value: this.helper.readableNumber(data.avg_open, 1)})

        this.totalClick?.setValue(data.total_click)
        this.totalClick?.setChange({value: this.helper.readableNumber(data.avg_click, 1)})

        this.activeSubscribe?.setValue(data.total_success - data.total_unsubscribe)
        
        if(this.totalUniqueOpen) {
            this.totalUniqueOpen.textContent = data.total_unique_open
        }

        if(this.totalUniqueOpen_percent) {
            this.totalUniqueOpen_percent.textContent = `(${this.helper.readableNumber(data.open_rate, 1)}%)`
        }
        this.totalUniqueOpen_progress?.setAttribute("aria-valuenow", data.open_rate)

        if(this.totalUniqueOpen_progress?.firstElementChild) {
            this.totalUniqueOpen_progress.firstElementChild.style.width = `${data.open_rate}%`
        }

        if(this.totalUniqueClick) {
            this.totalUniqueClick.textContent = data.total_unique_click
        }

        if(this.totalUniqueClick_percent) {
            this.totalUniqueClick_percent.textContent = `(${this.helper.readableNumber(data.click_rate, 1)}%)`
        }
        this.totalUniqueClick_progress?.setAttribute("aria-valuenow", data.click_rate)

        if(this.totalUniqueClick_progress?.firstElementChild) {
            this.totalUniqueClick_progress.firstElementChild.style.width = `${data.click_rate}%`
        }
        
        if(this.clickToOpenRate) {
            this.clickToOpenRate.textContent = this.helper.readableNumber(data.click_to_open_rate, 1) + "%"
        }

        if(this.totalSpam) {
            this.totalSpam.textContent = data.total_spam
        }

        if(this.totalSpam_percent) {
            this.totalSpam_percent.textContent = this.helper.readableNumber(data.total_spam_percent, 1) + "%"
        }
        
        if(this.totalUnsubscribe) {
            this.totalUnsubscribe.textContent = data.total_unsubscribe
        }

        if(this.totalUnsubscribe_percent) {
            this.totalUnsubscribe_percent.textContent = this.helper.readableNumber(data.total_unsubscribe_percent, 1) + "%"
        }
    }

    /**
     * @param {string} value 
     * @param {string} message 
     * @returns {{success: boolean, message: string}}
     */
    blastValidation(value, message) {
        let isValid = true
        if((this._isSendNow || this._isSchedule) && this.helper.isEmpty(value)) {
            isValid = false
        }
        
        return {
            success: isValid,
            message: isValid ? null : message
        }
    }

    setAddAudienceState() {
        const blockAddAudience = [
            CampaignBlastStatus.Queued,
            CampaignBlastStatus.Sending,
            CampaignBlastStatus.Scheduled,
            CampaignBlastStatus.Completed,
        ]
        const status = this.form.get("status_id")
        if(status?.get()?.id && blockAddAudience.includes(status.get().id)) {
            this.emailBlastAudience.table.disableNew()
            this.emailBlastAudience.addSegmenBtn?.disabled()
        } else {
            this.emailBlastAudience.table.enableNew()
            this.emailBlastAudience.addSegmenBtn?.enabled()
        }
    }

    editTemplate() {
        window.open(`${BASE_URL}/marketing/email-blast/editor/${this.id}`, '_blank')
    }
}