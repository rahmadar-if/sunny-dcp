import SolarModalPage from "@core-js/solaris/solar/solar-modal-page";
import Table from "@core-js/solaris/table/table";

export default class EmailBlastAudienceModal extends SolarModalPage {
    constructor() {
        super("email-blast-audience-modal")
    }

    init() {
        this.initTable()
        this.initForm()
        this._handleFolderModal()
    }

    initTable() {
        this._isTableRender = false

        /** @type {Table} */
        this.table = this.get("email-blast-audience-modal_list")
        this.table.on("column render:contact.name", this.nameColumnRender.bind(this))
    }

    initForm() {
        this.modal
            ?.on("show", () => this.table.clearAllSelected())
            .on("shown", () => {
                if(!this._isTableRender) {
                    this._isTableRender = true
                    this.table.render()
                } else {
                    this.table.refresh()
                }
            })
            .on("hide", () => this.table.clear())

        this.form.on("submitting", () => {
            const selected         = this.table.getSelected()
            const isSelectAllEmpty = selected.isSelectAll && this.table._recordsFiltered == 0
            const isSelectedEmpty  = !selected.isSelectAll && selected.selected.length == 0

            if(isSelectAllEmpty || isSelectedEmpty) {
                throw "Please select the audience"
            }

            this.form.addData("select_all", selected.isSelectAll)
            this.form.addData("selected", selected.selected)
            this.form.addData("excluded", selected.excluded)

            const filters = selected.isSelectAll ? {
                search    : this.table._searchValue?.trim().toLowerCase() ?? null,
                preFilters: this.table._preFilters?.get() ?? null,
                filters   : this.table._getFilters()?.get() ?? null
            } : null
            this.form.addData("filters", filters)
        })
    }

    _handleFolderModal() {
        this.table._folder._modal
            .on("show", () => {
                this.table._folder._modal._element.style.zIndex = 1057
                const mainModalBackdrop = document.querySelectorAll('.modal-backdrop.show')[0]
                if (mainModalBackdrop) {
                    mainModalBackdrop.style.zIndex = 1050
                }

                setTimeout(() => {
                    const backdrops = document.querySelectorAll('.modal-backdrop.show')
                    if (backdrops.length > 1) {
                        backdrops[backdrops.length - 1].style.zIndex = 1056;
                    }
                }, 10)
            })
            .on("hide", () => {
                const backdrop = document.querySelector('.modal-backdrop.show')
                if(backdrop) {
                    backdrop.style.zIndex = null
                }
            })
    }

    /**
     * @param {*} data 
     * @param {*} rowData 
     */
    nameColumnRender(data, rowData) {
        const initialName = this.helper.getInitialName(data)
        return `<div class="d-flex align-items-center gap-2">
            <div class="lh-1">
                <span class="avatar avatar-rounded avatar-sm ${!rowData.profile_picture_id ? "bg-secondary" : ""}">
                    ${rowData.profile_picture_id ? `<img src="${BASE_URL}/core/images/thumbnail/${rowData.profile_picture_id}" alt="">` : initialName}
                </span>
            </div>
            <div class="d-flex flex-wrap">${data}</div>
        </div>`
    }
}