import { WaBlastAudienceStatus } from "@marketing-js/const";
import SolarListDetail from "@core-js/solaris/solar/solar-list-detail";

export default class WaBlastDetail extends SolarListDetail {
    init() {
        this.columnRender("status_id", this.statusColumnRender.bind(this))
        this.columnRender("replied", this.repliedColumnRender.bind(this))
    }

    statusColumnRender(data, rowData) {
        let color = 'primary'
        switch (rowData.status?.id) {
            case WaBlastAudienceStatus.Progress:
                color = "info"
                break
            case WaBlastAudienceStatus.Sent:
            case WaBlastAudienceStatus.Read:
                color = "success"
                break
            case WaBlastAudienceStatus.Failed:
                color = "danger"
                break
            default:
                color = "primary"
                break
        }

        return `<span class="badge bg-${color}">${data}</span>`
    }

    repliedColumnRender(data, rowData) {
        if (!data) {
            return `<span class="badge bg-danger">No Replied</span>`
        }

        const payloads = JSON.parse(data)
        if (!payloads || payloads.length === 0) {
            return `<span class="badge bg-danger">No Replied</span>`
        }

        return payloads.map(payload => `<span class="badge bg-primary">${payload}</span>`).join(' ')
    }
}