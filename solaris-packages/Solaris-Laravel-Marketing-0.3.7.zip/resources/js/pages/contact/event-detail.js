import SolarListDetail from "@core-js/solaris/solar/solar-list-detail";

export default class EventDetail extends SolarListDetail {
    init() {
        this.columnRender("event_stage", this.eventStageColumnRender.bind(this))
    }

    eventStageColumnRender(data, rowData) {
        return `<span class="badge bg-${rowData.event.stage.color}">${data}</span>`
    }

}