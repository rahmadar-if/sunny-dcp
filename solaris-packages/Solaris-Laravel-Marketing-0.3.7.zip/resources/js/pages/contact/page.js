import BaseContactPage from "@base-crm-js/pages/contact/page"
import EventDetail from "./event-detail"
import EmailBlastDetail from "./email-blast-detail"
import WaBlastDetail from "./wa-blast-detail"

export default class ContactPage extends BaseContactPage {
    init() {
        super.init()
        this.registerDetail("contact-event", EventDetail, "contact_id")
        this.registerDetail("contact-email-blast", EmailBlastDetail, "contact_id")
        this.registerDetail("contact-wa-blast", WaBlastDetail, "contact_id")
    }
}