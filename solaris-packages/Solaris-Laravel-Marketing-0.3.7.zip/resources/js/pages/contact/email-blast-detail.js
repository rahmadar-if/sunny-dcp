import { EmailBlastAudienceStatus } from "@marketing-js/const";
import SolarListDetail from "@core-js/solaris/solar/solar-list-detail";

export default class EmailBlastDetail extends SolarListDetail {
    init() {
        this.columnRender("status_id", this.statusColumnRender.bind(this))
        this.columnRender("open", this.openClickColumnRender.bind(this))
        this.columnRender("click", this.openClickColumnRender.bind(this))
        this.columnRender("unsubscribe", this.spamUnsubColumnRender.bind(this))
        this.columnRender("spam", this.spamUnsubColumnRender.bind(this))
    }

    statusColumnRender(data, rowData) {
        let color = 'primary'
        switch (rowData.status?.id) {
            case EmailBlastAudienceStatus.Progress:
                color = "info"
                break
            case EmailBlastAudienceStatus.Delivered:
                color = "success"
                break
            case EmailBlastAudienceStatus.SoftBounce:
            case EmailBlastAudienceStatus.HardBounce:
                color = "danger"
                break
            default:
                color = "primary"
                break
        }

        return `<span class="badge bg-${color}">${data}</span>`
    }

    openClickColumnRender(data, rowData) {
        const color = data > 0 ? "success" : "danger"
        return `<span class="badge bg-${color}-transparent">${data}</span>`
    }

    spamUnsubColumnRender(data, rowData) {
        const color = data ? "danger" : "success"
        return `<span class="badge bg-${color}-transparent">${data ? "Yes" : "No"}</span>`
    }
}