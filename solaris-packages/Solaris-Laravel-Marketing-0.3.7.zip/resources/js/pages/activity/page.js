import BaseActivityPage from "@base-crm-js/pages/activity/page";

export default class ActivityPage extends BaseActivityPage {
}
