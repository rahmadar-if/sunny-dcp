import SolarListDetail from "@core-js/solaris/solar/solar-list-detail";
import EventAudienceModal from "./audience-detail-modal";
import AudienceSegmentationModal from "../audience-segmentation-modal";

export default class EventAudienceDetail extends SolarListDetail {
    init() {
        this.eventAudienceModal = new EventAudienceModal()
        this.columnRender("contact_id", this.contactColumnRender.bind(this))
        
        this.addSegmenBtn = this.get("add-event-segmentation")
    }

    contactColumnRender(data, rowData) {
        const initialName = this.helper.getInitialName(data)
        return `<div class="d-flex align-items-center gap-2">
            <div class="lh-1">
                <span class="avatar avatar-rounded avatar-sm ${!rowData.contact.profile_picture_id ? "bg-secondary" : ""}">
                    ${rowData.contact.profile_picture_id ? `<img src="${BASE_URL}/core/images/thumbnail/${rowData.contact.profile_picture_id}" alt="">` : initialName}
                </span>
            </div>
            <div>
                <a class="text-decoration-underline" href="${BASE_URL}/master-data/contact/edit/${rowData.contact_id}">${data}</a>
            </div>
        </div>`
    }

    ready() {
        this.segmentation = new AudienceSegmentationModal(
            "event-segmentation", 
            `${BASE_URL}/marketing/event/add-audience`,
            "event_id",
            this.parentValue.id
        )

        this.segmentation.on("change", () => this.refresh())
        
        this.addSegmenBtn.on("click", () => this.segmentation.addSegmentation())
        this.addSegmenBtn.enabled()
    }
}