import EventPage from "./page"

new EventPage()