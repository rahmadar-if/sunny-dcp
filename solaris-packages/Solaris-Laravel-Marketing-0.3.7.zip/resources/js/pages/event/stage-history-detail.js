import SolarListDetail from "@core-js/solaris/solar/solar-list-detail";

export default class EventStageHistoryDetail extends SolarListDetail {
    init() {
        this.columnRender("stage_id", this.stageColumnRender.bind(this))
    }

    stageColumnRender(data, rowData) {
        return `<span class="badge bg-${rowData.stage.color}">${data}</span>`
    }
}