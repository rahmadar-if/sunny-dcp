import EventListPage from "./list"

new EventListPage("event")