import SolarListPage from "@core-js/solaris/solar/solar-list-page";

export default class EventListPage extends SolarListPage {
    init() {
        this.columnRender("stage_id", this.stageColumnRender.bind(this))
    }

    openEditPage(id) {
        this.helper.loadingPage(true)
        window.location = `${BASE_URL}/marketing/event/edit/${id}`
    }

    async edit(row, data) {
        this.openEditPage(data.id)
    }

    rowDoubleClick(row, data) {
        this.openEditPage(data.id)
    }

    stageColumnRender(data, rowData) {
        return `<span class="badge bg-${rowData.stage.color}">${data}</span>`
    }
}