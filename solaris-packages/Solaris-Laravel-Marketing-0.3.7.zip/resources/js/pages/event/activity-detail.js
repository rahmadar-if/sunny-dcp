import ActivityDetail from "@master-data-js/pages/activity/detail";

export default class EventActivityDetail extends ActivityDetail {
    init() {
        super.init()
    }
}