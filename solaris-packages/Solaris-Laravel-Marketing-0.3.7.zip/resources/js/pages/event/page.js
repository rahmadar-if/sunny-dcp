import SolarEditPage from "@core-js/solaris/solar/solar-edit-page";
import EventAudienceDetail from "./audience-detail";
import EventStageHistoryDetail from "./stage-history-detail";
import EventActivityDetail from "./activity-detail";

export default class EventPage extends SolarEditPage {
    init() {
        this.registerDetail("event-audience", EventAudienceDetail, "event_id")
        this.registerDetail("event-activity", EventActivityDetail, "event_id")
        this.registerDetail("event-stage-history", EventStageHistoryDetail, "event_id")
    }

    async success(response) {
        this.eventStageHistory?.refresh()
    }

    async onRefreshed(data) {
        this.breadcrumbName.innerText = data.name
    }
}