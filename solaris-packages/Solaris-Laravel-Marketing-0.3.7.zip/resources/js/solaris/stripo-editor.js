import axios from "@core-js/libs/axios"
import Button from "@core-js/solaris/button"
import Helper from "@core-js/solaris/helper"
import Modal from "@core-js/solaris/modal"
import SolarComponent from "@core-js/solaris/solar/solar-component"
import SolarSingleton from "@core-js/solaris/solar/solar-singleton"
import TestEmailCooldown from "./test-email-cooldown"
import ModalForm from "@core-js/solaris/modal-form"
import Form from "@core-js/solaris/form/form"

export default class StripoEditor extends SolarComponent {
    constructor(selector, emailId, html = null, css = null, mergeTags = [], testScope = "email_template") {
        super()

        if(selector instanceof Element) {
            this._element = selector
        } else if(Helper.isString(selector) && !Helper.isEmpty(selector)) {
            this._element = document.querySelector(selector)
            if(!this._element) {
                throw new Error(`Element with query selector ${selector} is not found`)
            }
        } else {
            throw new Error(`Selector is not supported`)
        }

        this.id        = this._element.id
        this.emailId   = emailId
        this.testScope = testScope
        this.mergeTags = [...(MERGE_TAGS ?? []), ...mergeTags]
        this._editor   = this._element.querySelector('div.stripo-editor-content')
        this._isReady  = false

        this.init(html, css)
    }
    
    static supportedEvent() {
        return ["ready", "saving", "save", "preview", "test-email", "change-template"]
    }

    init(html = null, css = null) {
        this._element.classList.remove("d-none")

        this._initTestEmailModal()
        this._initPreviewModal()
        
        this._initHeaderAction()
        this._loadScript(html, css)
    }

    _initTestEmailModal() {
		this._testEmailHtml  = null
		this._testEmailModal = new ModalForm(
            new Modal(`#${this.id}_test-email-modal`),
            new Form(`#${this.id}_test-email-modal_form`)
        )

        this._testEmailModal?.form
            .hiddenSuccessAlert()
			.on("submitting", () => {
				this._testEmailModal.form
                    .addData("html", this._testEmailHtml)
				    .addData("scope", this.testScope)
			})
			.on("success", (res) => {
				this._testEmailCooldown?.start(res?.data?.retry_at)
				Helper.toast({message: "Test email sent successfully!", color: "success"})
			})
			.on("error", (error) => {
				this._testEmailCooldown?.startFromError(error)
			})
	}

    _initPreviewModal() {
		this._previewModal        = new Modal(`#${this.id}_preview-modal`)
        this._previewDesktopFrame = document.getElementById(`${this.id}_preview-desktop-frame`)
        this._previewPhoneFrame   = document.getElementById(`${this.id}_preview-phone-frame`)
	}

    async back() {
        if(await Helper.confirm({title: "Are you sure"})) {
            window.close()
        }
    }

    async save(error) {
        Helper.loadingPage(true)

        try {
            if(error) {
                throw error
            }

            await this.trigger("saving")

            const saving        = await Promise.all([this.getTemplateData(), this.compile()])
            const emailTemplate = {
                html         : saving[0].html,
                css          : saving[0].css,
                width        : saving[0].width,
                height       : saving[0].height,
                htmlCompiled : saving[1].html,
                ampHtml      : saving[1].ampHtml ?? null,
            }

            await this.trigger("save", emailTemplate)
        } catch (e) {
            console.error({e})
            if(e) {
                Helper.toast({message: e.toString()})
            }
        } finally {
            Helper.loadingPage(false)
        }
    }

    async testEmail() {
        Helper.loadingPage(true)
        try {
            const compiled = await this.compile()
            this._testEmailHtml = compiled.html
		    this._testEmailModal?.modal.show()
            
            await this.trigger("test-email", { htmlCompiled: compiled.html })
        } catch(e) {
            console.error({e})
            if(e) {
                Helper.toast({message: e.toString()})
            }
        } finally {
            Helper.loadingPage(false)
        }
    }

    codeEditor() {
        const state = window.StripoEditorApi.codeEditorApi.getCodeEditorState()
        if(state.isOpen) {
            window.StripoEditorApi.codeEditorApi.closeCodeEditor()
        } else {
            window.StripoEditorApi.codeEditorApi.openCodeEditor()
        }
    }

    async preview() {
        Helper.loadingPage(true)
        try {
            const compiled = await this.compile()
            this._previewDesktopFrame.srcdoc = compiled.html
            this._previewPhoneFrame.srcdoc   = compiled.html
            this._previewModal.show()

            await this.trigger("preview", { htmlCompiled: compiled.html })
        } catch(e) {
            console.error({e})
            if(e) {
                Helper.toast({message: e.toString()})
            }
        } finally {
            Helper.loadingPage(false)
        }
    }

    setTemplate(html, css) {
        this.trigger("change-template")

        if(this._isReady) {
            this._backBtn.disabled()
            this._saveBtn.disabled()
            this._testEmailBtn.disabled()
            this._codeBtn.disabled()
            this._previewBtn.disabled()
            
            this._desktopMode.disabled = true
            this._mobileMode.disabled  = true
            this._isReady = false

            window.UIEditor.removeEditor()
        }

        this._initEditor(html, css)
    }

    /**
     * @returns {Promise<{html: string, css: string, width: number, height: number, utmParams, syncModulesIds}>} 
     */
    getTemplateData() {
        return new Promise((resolve, reject) => {
            window.StripoEditorApi.actionsApi.getTemplateData(function ({html, css, width, height, utmParams, syncModulesIds}) {
                if(!html || !css) {
                    reject("Get HTML or CSS template is failed")
                }

                resolve({html, css, width, height, utmParams, syncModulesIds})
            })
        }) 
    }

    /**
     * @returns {Promise<{html: string, ampHtml: string}>}
     */
    compile() {
        return new Promise((resolve, reject) => {
            window.StripoEditorApi.actionsApi.compileEmail({
                callback: function (error, html, ampHtml, ampErrors) {
                    if(error) {
                        reject({error, ampErrors})
                    }

                    resolve({html, ampHtml})
                }
            })
        })
    }

    _initHeaderAction() {
        this._backBtn = new Button(`#${this.id}_back`)
        this._backBtn.on("click", this.back.bind(this))

        this._saveBtn = new Button(`#${this.id}_save`)
        this._saveBtn.on("click", () => window.StripoEditorApi.actionsApi.save(this.save.bind(this)))
        
        this._desktopMode = document.querySelector(`#${this.id}_desktop_mode`)
        this._desktopMode.addEventListener("change", (e) => {
            const target = e.target
            if(target.checked) {
                window.StripoEditorApi.versionHistoryApi.switchToDesktopPreview()
            }
        })

        this._mobileMode  = document.querySelector(`#${this.id}_mobile_mode`)
        this._mobileMode.addEventListener("change", (e) => {
            const target = e.target
            if(target.checked) {
                window.StripoEditorApi.versionHistoryApi.switchToMobilePreview()
            }
        })

        this._testEmailBtn = new Button(`#${this.id}_test_email`)
        this._testEmailBtn.on("click", this.testEmail.bind(this))

        this._testEmailCooldown = new TestEmailCooldown(this.testScope, this._testEmailBtn)
        
        this._codeBtn = new Button(`#${this.id}_code`)
        this._codeBtn.on("click", this.codeEditor.bind(this))
        
        this._previewBtn = new Button(`#${this.id}_preview`)
        this._previewBtn.on("click", this.preview.bind(this))
    }
    
    _initEditor(html, css) {
        window.UIEditor.initEditor(this._editor, this._getConfig(html, css))
    }

    _loadScript(html, css) {
        const script  = document.createElement('script')
        script.id     = 'UiEditorScript'
        script.type   = 'module'
        script.src    = 'https://plugins.stripo.email/resources/uieditor/latest/UIEditor.js'
        script.onload = async () => {
            const template = (html && css) ? { html, css } : await this._getDefaultTemplate()
            this._initEditor(template.html, template.css)
        }

        document.body.appendChild(script)
    }

    _ready() {
        this._backBtn.enabled()
        this._saveBtn.enabled()
        this._testEmailBtn.enabled()
        this._testEmailCooldown?.sync()
        this._codeBtn.enabled()
        this._previewBtn.enabled()

        this._desktopMode.disabled = false
        this._mobileMode.disabled  = false
        
        this._isReady = true

        this.trigger("ready")
    }

    /**
     * @param {string} html 
     * @param {string} css 
     * @returns {*}
     */
    _getConfig(html, css) {
         return {
            forceRecreate: true,
            html         : html,
            css          : css,
            metadata     : {
                emailId: this.emailId,
            },
            locale    : 'en',
            mergeTags : this.mergeTags,
            onTokenRefreshRequest: async (callback) => {
                const token = await this._getToken()
                callback(token)
            },
            notifications: {
                info: (message, id, params) => {
                    Helper.toast({message: message})
                    console.log("info notification", {message, id, params})
                },
                error: (message, id, params) => {
                    Helper.toast({message: message, color: "danger"})
                    console.log("error notification", {message, id, params})
                },
                warn: (message, id, params) => {
                    Helper.toast({message: message, color: "warning"})
                    console.log("warn notification", {message, id, params})
                },
                loader: (id) => {
                    console.log("loader notification", {id})
                },
                hide: (message, id, params) => {
                    console.log("hide notification", {message, id, params})
                },
                success: (message, id, params) => {
                    Helper.toast({message: message, color: "success"})
                    console.log("success notification", {message, id, params})
                }
            },
            onTemplateLoaded: () => {
                this._ready()
            }
        }
    }

    /**
     * @returns {Promise<{html: string, css: string}>} 
     */
    async _getDefaultTemplate() {
        const req = await axios.get(`${BASE_URL}/marketing/stripo/default-template`)
        const res = req.data

        return res.data
    }

    /**
     * @returns {Promise<string>} 
     */
    async _getToken() {
        const req = await axios.post(`${BASE_URL}/marketing/stripo/token`)
        const res = req.data

        return res.data
    }
}