import PhonePreview from '@core-js/solaris/phone-preview'

const _iconMap = {
	pdf:  'bi-file-earmark-pdf-fill',
	doc:  'bi-file-earmark-word-fill',
	docx: 'bi-file-earmark-word-fill',
	xls:  'bi-file-earmark-excel-fill',
	xlsx: 'bi-file-earmark-excel-fill',
	ppt:  'bi-file-earmark-ppt-fill',
	pptx: 'bi-file-earmark-ppt-fill',
	zip:  'bi-file-earmark-zip-fill',
	mp4:  'bi-file-earmark-play-fill',
	mp3:  'bi-file-earmark-music-fill',
}

/**
 * @typedef {'text'|'image'|'video'|'document'} HeaderType
 * @typedef {'url'|'phone_number'|'copy_code'|'quick_reply'|'one_tap'|'marketing_opt_out'} ButtonType
 * @typedef {'incoming'|'outgoing'} MessageType
 * @typedef {'sent'|'delivered'|'read'} MessageStatus
 */

/**
 * @typedef {Object} TemplateHeader
 * @property {HeaderType} type
 * @property {string}     value  URL for image/video/document, plain text for text type
 */

/**
 * @typedef {Object} Button
 * @property {ButtonType} type
 * @property {string}     label
 */

/**
 * @typedef {Object} CarouselCard
 * @property {string|null}      [id]
 * @property {'image'|'video'}  [media_type='image']
 * @property {string}           [src]
 * @property {string}           [body]        Card body text — max 160 chars per Meta spec
 * @property {string}           [subtitle]    Visual enhancement only, not part of Meta API spec
 * @property {Button[]}         [buttons]     Max 2 buttons; all cards in a carousel must share the same button config
 */

export default class WhatsAppPreview extends PhonePreview {
	/** @type {{ INCOMING: 'incoming', OUTGOING: 'outgoing' }} */
	static TYPE = {
		INCOMING: 'incoming',
		OUTGOING: 'outgoing',
	}

	/** @type {{ SENT: 'sent', DELIVERED: 'delivered', READ: 'read' }} */
	static STATUS = {
		SENT:      'sent',
		DELIVERED: 'delivered',
		READ:      'read',
	}

	/** @type {HTMLElement|null} */ _chatEl   = null
	/** @type {HTMLElement|null} */ _chatArea = null

	/** @param {HTMLElement} element */
	constructor(element) {
		const phoneEl = element.closest('[solar-ui="phone-preview"]')
		super(phoneEl)
		this._chatEl   = element
		this._chatArea = element.querySelector('.wa-preview-chat')
	}

	// =========================================
	// Public API
	// =========================================

	/**
	 * @param {Object}        [options]
	 * @param {string|null}   [options.id]
	 * @param {MessageType}   [options.type]
	 * @param {string}        [options.text]
	 * @param {string|null}   [options.time]
	 * @param {MessageStatus} [options.status]
	 * @returns {this}
	 */
	addMessage({ id = null, type = WhatsAppPreview.TYPE.INCOMING, text = '', time = null, status = WhatsAppPreview.STATUS.DELIVERED } = {}) {
		const content = `<div class="wa-preview-bubble-text">${this._renderText(text)}</div>`
		const bubble  = this._bubble(id, type, content, time, status)
		this._chatArea.appendChild(bubble)
		this._scroll()
		return this
	}

	/**
	 * @param {Object}        [options]
	 * @param {string|null}   [options.id]
	 * @param {MessageType}   [options.type]
	 * @param {string}        [options.src]
	 * @param {string}        [options.caption]
	 * @param {string|null}   [options.time]
	 * @param {MessageStatus} [options.status]
	 * @returns {this}
	 */
	addImageMessage({ id = null, type = WhatsAppPreview.TYPE.INCOMING, src = '', caption = '', time = null, status = WhatsAppPreview.STATUS.DELIVERED } = {}) {
		let content = `<img class="wa-preview-media-image" src="${src}" alt="">`
		if (caption) {
			content += `<div class="wa-preview-bubble-text wa-preview-media-caption">${this._renderText(caption)}</div>`
		}
		const bubble = this._bubble(id, type, content, time, status)
		this._chatArea.appendChild(bubble)
		this._scroll()
		return this
	}

	/**
	 * @param {Object}        [options]
	 * @param {string|null}   [options.id]
	 * @param {MessageType}   [options.type]
	 * @param {string}        [options.filename]
	 * @param {string}        [options.filesize]  Human-readable size, e.g. "2.4 MB"
	 * @param {string}        [options.filetype]  File extension override, e.g. "pdf"
	 * @param {string}        [options.caption]
	 * @param {string|null}   [options.time]
	 * @param {MessageStatus} [options.status]
	 * @returns {this}
	 */
	addFileMessage({ id = null, type = WhatsAppPreview.TYPE.INCOMING, filename = 'document', filesize = '', filetype = '', caption = '', time = null, status = WhatsAppPreview.STATUS.DELIVERED } = {}) {
		const ext  = filetype || filename.split('.').pop().toLowerCase()
		const icon = _iconMap[ext] || 'bi-file-earmark-text-fill'

		let content = `
			<div class="wa-preview-file">
				<i class="bi ${icon} wa-preview-file-icon"></i>
				<div class="wa-preview-file-info">
					<span class="wa-preview-file-name">${this._esc(filename)}</span>
					${filesize ? `<span class="wa-preview-file-meta">${this._esc(filesize)}${ext ? ' · ' + ext.toUpperCase() : ''}</span>` : ''}
				</div>
			</div>
		`
		if (caption) {
			content += `<div class="wa-preview-bubble-text wa-preview-media-caption">${this._renderText(caption)}</div>`
		}

		const bubble = this._bubble(id, type, content, time, status)
		this._chatArea.appendChild(bubble)
		this._scroll()
		return this
	}

	/**
	 * Renders a WhatsApp template message (MARKETING / UTILITY / AUTHENTICATION).
	 *
	 * @param {Object}         [options]
	 * @param {string|null}    [options.id]
	 * @param {MessageType}    [options.type]
	 * @param {TemplateHeader} [options.header]          Optional header component
	 * @param {string}         [options.text]            Body text — supports WhatsApp markdown
	 * @param {string}         [options.otp_code]        AUTHENTICATION: OTP code to display
	 * @param {boolean}        [options.disclaimer]      AUTHENTICATION: show "do not share" disclaimer
	 * @param {number}         [options.expiry_minutes]  AUTHENTICATION: OTP expiry in minutes
	 * @param {string}         [options.footer]          Footer text — max 60 chars, plain text only
	 * @param {Button[]}       [options.buttons]         Max 3 QUICK_REPLY or max 2 CTA buttons
	 * @param {string|null}    [options.time]
	 * @param {MessageStatus}  [options.status]
	 * @returns {this}
	 */
	addTemplateMessage({
		id              = null,
		type            = WhatsAppPreview.TYPE.INCOMING,
		header          = null,
		text            = '',
		otp_code        = '',
		disclaimer      = false,
		expiry_minutes  = 0,
		footer          = '',
		buttons         = [],
		time            = null,
		status          = WhatsAppPreview.STATUS.DELIVERED,
	} = {}) {
		let content = this._renderHeader(header)
		content    += `<div class="wa-preview-bubble-text">${this._renderText(text)}</div>`

		if (otp_code) {
			content += `<div class="wa-preview-otp-code">${this._esc(otp_code)}</div>`
		}
		if (disclaimer) {
			content += `<div class="wa-preview-bubble-footer">For your security, do not share this code.</div>`
		}
		if (expiry_minutes) {
			content += `<div class="wa-preview-bubble-footer">This code expires in ${this._esc(String(expiry_minutes))} minutes.</div>`
		}
		if (footer) {
			content += `<div class="wa-preview-bubble-footer">${this._esc(footer)}</div>`
		}

		const bubble = this._bubble(id, type, content, time, status)

		if (buttons.length) {
			const btnWrap     = document.createElement('div')
			btnWrap.className = 'wa-preview-buttons'
			btnWrap.innerHTML = this._renderButtons(buttons)
			bubble.appendChild(btnWrap)
		}

		this._chatArea.appendChild(bubble)
		this._scroll()
		return this
	}

	/**
	 * Renders a MARKETING carousel message — body text above + horizontally scrollable cards.
	 *
	 * @param {Object}       [options]
	 * @param {string|null}  [options.id]
	 * @param {MessageType}  [options.type]
	 * @param {string}       [options.text]   Body text shown above the carousel — required per Meta spec
	 * @param {CarouselCard[]} [options.cards] Min 2, max 10 cards
	 * @param {string|null}  [options.time]
	 * @returns {this}
	 */
	addCarousel({ id = null, type = WhatsAppPreview.TYPE.INCOMING, text = '', cards = [], time = null } = {}) {
		const wrapper     = document.createElement('div')
		wrapper.className = `wa-preview-carousel-wrapper ${type}`
		if (id) wrapper.dataset.waId = id

		if (text) {
			// Body dirender sebagai proper bubble (selalu dengan tail — pesan pertama)
			const bodyBubble     = document.createElement('div')
			bodyBubble.className = `wa-preview-bubble ${type}`
			bodyBubble.innerHTML = `<div class="wa-preview-bubble-text">${this._renderText(text)}</div>`
			wrapper.appendChild(bodyBubble)
		}

		const carousel     = document.createElement('div')
		carousel.className = 'wa-preview-carousel'

		cards.forEach(card => carousel.appendChild(this._carouselCard(card)))

		wrapper.appendChild(carousel)
		wrapper.appendChild(this._timeEl(time, type))

		this._chatArea.appendChild(wrapper)
		this._scroll()
		return this
	}

	/**
	 * Appends a card to an existing carousel.
	 *
	 * @param {string}      carouselId  `data-wa-id` of the target carousel wrapper
	 * @param {CarouselCard} [card]
	 * @returns {this}
	 */
	addCarouselCard(carouselId, { id = null, media_type = 'image', src = '', body = '', subtitle = '', buttons = [] } = {}) {
		const wrapper  = this._chatArea.querySelector(`[data-wa-id="${carouselId}"]`)
		if (!wrapper) return this

		const carousel = wrapper.querySelector('.wa-preview-carousel')
		carousel.appendChild(this._carouselCard({ id, media_type, src, body, subtitle, buttons }))
		this._scroll()
		return this
	}

	/**
	 * Updates specific fields of an existing carousel card. Only provided fields are updated.
	 *
	 * @param {string}  carouselId             `data-wa-id` of the carousel wrapper
	 * @param {string}  cardId                 `data-wa-id` of the target card
	 * @param {Object}  [options]
	 * @param {string}  [options.src]
	 * @param {'image'|'video'} [options.media_type]  Required when updating `src` to a video
	 * @param {string}  [options.body]
	 * @param {string}  [options.subtitle]
	 * @param {Button[]} [options.buttons]
	 * @returns {this}
	 */
	updateCarouselCard(carouselId, cardId, { src, media_type, body, subtitle, buttons } = {}) {
		const wrapper = this._chatArea.querySelector(`[data-wa-id="${carouselId}"]`)
		if (!wrapper) return this

		const card = wrapper.querySelector(`[data-wa-id="${cardId}"]`)
		if (!card) return this

		if (src !== undefined) {
			const existingImg   = card.querySelector('.wa-preview-carousel-img')
			const existingVideo = card.querySelector('.wa-preview-video-thumb')
			existingImg?.remove()
			existingVideo?.remove()

			if (src) {
				const resolvedType = media_type || 'image'
				const mediaEl      = document.createElement('div')
				mediaEl.innerHTML  = resolvedType === 'video'
					? `<div class="wa-preview-video-thumb"><video src="${this._esc(src)}" muted playsinline preload="metadata"></video><i class="bi bi-play-circle-fill wa-preview-video-play"></i></div>`
					: `<img class="wa-preview-carousel-img" src="${this._esc(src)}" alt="">`
				card.insertBefore(mediaEl.firstElementChild, card.firstChild)
			}
		}

		if (body !== undefined) {
			let bodyEl = card.querySelector('.wa-preview-carousel-title')
			if (body) {
				if (!bodyEl) {
					bodyEl           = document.createElement('div')
					bodyEl.className = 'wa-preview-carousel-title'
					card.querySelector('.wa-preview-carousel-body').prepend(bodyEl)
				}
				bodyEl.innerHTML = this._esc(body)
			} else {
				bodyEl?.remove()
			}
		}

		if (subtitle !== undefined) {
			let subtitleEl = card.querySelector('.wa-preview-carousel-subtitle')
			if (subtitle) {
				if (!subtitleEl) {
					subtitleEl           = document.createElement('div')
					subtitleEl.className = 'wa-preview-carousel-subtitle'
					const bodyAreaEl     = card.querySelector('.wa-preview-carousel-body')
					const bodyTextEl     = bodyAreaEl.querySelector('.wa-preview-carousel-title')
					bodyTextEl ? bodyTextEl.after(subtitleEl) : bodyAreaEl.prepend(subtitleEl)
				}
				subtitleEl.innerHTML = this._esc(subtitle)
			} else {
				subtitleEl?.remove()
			}
		}

		if (buttons !== undefined) {
			const bodyAreaEl = card.querySelector('.wa-preview-carousel-body')
			bodyAreaEl.querySelectorAll('.wa-preview-btn').forEach(el => el.remove())
			if (buttons.length) {
				bodyAreaEl.insertAdjacentHTML('beforeend', this._renderButtons(buttons))
			}
		}

		return this
	}

	/**
	 * Updates specific fields of an existing message bubble. Only provided fields are updated.
	 *
	 * @param {string}          id
	 * @param {Object}          [options]
	 * @param {TemplateHeader|null} [options.header]  Pass `null` to remove the header
	 * @param {string}          [options.text]
	 * @param {string}          [options.footer]
	 * @param {Button[]}        [options.buttons]
	 * @param {MessageStatus}   [options.status]
	 * @returns {this}
	 */
	updateMessage(id, { header, text, footer, buttons, status } = {}) {
		const bubble = this._chatArea.querySelector(`[data-wa-id="${id}"]`)
		if (!bubble) return this

		if (header !== undefined) {
			bubble.querySelector('.wa-preview-bubble-header-text')?.remove()
			bubble.querySelector('.wa-preview-media-image')?.remove()
			bubble.querySelector('.wa-preview-video-thumb')?.remove()
			bubble.querySelector('.wa-preview-file')?.remove()

			if (header) {
				const headerHtml = this._renderHeader(header)
				if (headerHtml) {
					const textEl = bubble.querySelector('.wa-preview-bubble-text')
					textEl
						? textEl.insertAdjacentHTML('beforebegin', headerHtml)
						: bubble.insertAdjacentHTML('afterbegin', headerHtml)
				}
			}
		}

		if (text !== undefined) {
			const textEl = bubble.querySelector('.wa-preview-bubble-text')
			if (textEl) textEl.innerHTML = this._renderText(text)
		}

		if (footer !== undefined) {
			const footerEl = bubble.querySelector('.wa-preview-bubble-footer')
			if (footerEl) footerEl.innerHTML = this._esc(footer)
		}

		if (buttons !== undefined) {
			const btnWrap = bubble.querySelector('.wa-preview-buttons')
			if (btnWrap) btnWrap.innerHTML = this._renderButtons(buttons)
		}

		if (status !== undefined) {
			const timeEl = bubble.querySelector('.wa-preview-bubble-time')
			if (timeEl) {
				const type     = bubble.classList.contains(WhatsAppPreview.TYPE.OUTGOING)
					? WhatsAppPreview.TYPE.OUTGOING
					: WhatsAppPreview.TYPE.INCOMING
				const timeText = Array.from(timeEl.childNodes)
					.find(n => n.nodeType === Node.TEXT_NODE)
					?.textContent.trim() || this._now()
				timeEl.innerHTML = this._timeEl(timeText, type, status).innerHTML
			}
		}

		return this
	}

	/** @returns {this} */
	clearMessages() {
		this._chatArea.querySelectorAll('.wa-preview-bubble, .wa-preview-carousel-wrapper').forEach(el => el.remove())
		return this
	}

	/**
	 * @param {'iphone'|'android'} type
	 * @returns {this}
	 */
	setType(type) {
		super.setType(type)
		this.setNotch(type === 'android' ? 'punch-hole' : 'dynamic-island')
		return this
	}

	// =========================================
	// Internals
	// =========================================

	/** @param {CarouselCard} card */
	_carouselCard({ id = null, media_type = 'image', src = '', body = '', subtitle = '', buttons = [] } = {}) {
		const cardEl     = document.createElement('div')
		cardEl.className = 'wa-preview-carousel-card'
		if (id) cardEl.dataset.waId = id

		let mediaHtml = ''
		if (src) {
			mediaHtml = media_type === 'video'
				? `<div class="wa-preview-video-thumb"><video src="${this._esc(src)}" muted playsinline preload="metadata"></video><i class="bi bi-play-circle-fill wa-preview-video-play"></i></div>`
				: `<img class="wa-preview-carousel-img" src="${this._esc(src)}" alt="">`
		}

		cardEl.innerHTML = `
			${mediaHtml}
			<div class="wa-preview-carousel-body">
				${body     ? `<div class="wa-preview-carousel-title">${this._renderText(body)}</div>`       : ''}
				${subtitle ? `<div class="wa-preview-carousel-subtitle">${this._esc(subtitle)}</div>` : ''}
				${buttons?.length ? this._renderButtons(buttons) : ''}
			</div>
		`
		return cardEl
	}

	/** @param {TemplateHeader|null} header @returns {string} */
	_renderHeader(header) {
		if (!header?.type) return ''

		const { type, value } = header

		if (type === 'text') {
			return `<div class="wa-preview-bubble-header-text">${this._renderText(value || '')}</div>`
		}
		if (type === 'image') {
			return `<img class="wa-preview-media-image" src="${this._esc(value || '')}" alt="">`
		}
		if (type === 'video') {
			const mediaHtml = value ? `<video src="${this._esc(value)}" muted playsinline preload="metadata"></video>` : ''
			return `<div class="wa-preview-video-thumb">${mediaHtml}<i class="bi bi-play-circle-fill wa-preview-video-play"></i></div>`
		}
		if (type === 'document') {
			const name = value || 'document'
			const ext  = name.split('.').pop().toLowerCase()
			const icon = _iconMap[ext] || 'bi-file-earmark-text-fill'
			return `<div class="wa-preview-file"><i class="bi ${icon} wa-preview-file-icon"></i><div class="wa-preview-file-info"><span class="wa-preview-file-name">${this._esc(name)}</span></div></div>`
		}

		return ''
	}

	/** @param {Button[]} buttons @returns {string} */
	_renderButtons(buttons) {
		const icons = {
			url:                'bi-box-arrow-up-right',
			phone_number:       'bi-telephone-fill',
			copy_code:          'bi-clipboard',
			quick_reply:        '',
			one_tap:            'bi-lightning-charge-fill',
			marketing_opt_out:  'bi-bell-slash',
		}
		return buttons.map(btn => {
			const icon = icons[btn.type] || ''
			return `<div class="wa-preview-btn">
				${icon ? `<i class="bi ${icon}"></i>` : ''}
				${this._esc(btn.label || '')}
			</div>`
		}).join('')
	}

	/** Converts WhatsApp markdown to HTML. Supports *bold*, _italic_, ~strikethrough~, ```code``` */
	_renderText(text) {
		let html = this._esc(text)
		html = html.replace(/\*([^*\n]+)\*/g,             '<strong>$1</strong>')
		html = html.replace(/_([^_\n]+)_/g,               '<em>$1</em>')
		html = html.replace(/~([^~\n]+)~/g,               '<del>$1</del>')
		html = html.replace(/```([^`]+?)```/gs,           '<code>$1</code>')
		html = html.replace(/\n/g,                        '<br>')
		return html
	}

	/** @returns {string} Current time as HH:MM */
	_now() {
		const d = new Date()
		return `${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}`
	}

	/**
	 * Fallback implementation — used when PhonePreview constructor skips setup
	 * (e.g. when the phone-preview element has the `ignore` attribute).
	 *
	 * @param {string|null}   id
	 * @param {string}        type     'incoming' | 'outgoing'
	 * @param {string}        content  Inner HTML string
	 * @param {string|null}   time
	 * @param {string}        status   'sent' | 'delivered' | 'read'
	 * @returns {HTMLElement}
	 */
	_bubble(id = null, type = 'incoming', content = '', time = null, status = 'delivered') {
		const div = document.createElement('div')

		// Bubble lanjutan dari tipe yang sama — tidak perlu tail
		const lastEl         = this._chatArea?.lastElementChild
		const isContinuation = lastEl?.classList.contains('wa-preview-bubble') &&
		                       lastEl.classList.contains(type)

		div.className = `wa-preview-bubble ${type}${isContinuation ? ' no-tail' : ''}`
		if (id) div.dataset.waId = id
		div.innerHTML = content
		div.appendChild(this._timeEl(time, type, status))
		return div
	}

	/**
	 * Fallback implementation — used when PhonePreview constructor skips setup.
	 *
	 * @param {string|null} time
	 * @param {string}      type    'incoming' | 'outgoing'
	 * @param {string}      status  'sent' | 'delivered' | 'read'
	 * @returns {HTMLElement}
	 */
	_timeEl(time = null, type = 'incoming', status = 'delivered') {
		const div     = document.createElement('div')
		div.className = 'wa-preview-bubble-time'
		const icons   = {
			read     : '<i class="bi bi-check2-all wa-check-read"></i>',
			delivered: '<i class="bi bi-check2-all"></i>',
			sent     : '<i class="bi bi-check2"></i>',
		}
		const icon    = type === 'outgoing' ? (icons[status] ?? icons.sent) : ''
		div.innerHTML = `${this._esc(time || this._now())}${icon}`
		return div
	}

	_scroll() {
		this._chatArea.scrollTop = this._chatArea.scrollHeight
	}

	/** @param {string|number} text @returns {string} HTML-escaped string */
	_esc(text) {
		const d = document.createElement('div')
		d.appendChild(document.createTextNode(String(text)))
		return d.innerHTML
	}
}
