/**
 * Keeps a test email button locked until its cooldown expires.
 *
 * Stores the moment sending becomes allowed again instead of a remaining count, so a reloaded or
 * long-idle tab resolves the same deadline the server holds in session. Each scope locks on its
 * own — the Email Blast page, the Email Template menu and the Email Editor never share a lock.
 */
export default class TestEmailCooldown {
    /**
     * @param {string} scope
     * @param {import("@core-js/solaris/button").default} button
     */
    constructor(scope, button) {
        this._scope  = scope
        this._button = button
        this._timer  = null
    }

    // #region Public API

    /**
     * Locks the button when a deadline is already stored. Call once on init.
     * @returns {void}
     */
    sync() {
        this._applyDeadline(this._read())
    }

    /**
     * Stores a deadline coming from the server and locks the button.
     * @param {number|null|undefined} retryAt - Unix timestamp in seconds.
     * @returns {void}
     */
    start(retryAt) {
        if (!retryAt) {
            return
        }

        localStorage.setItem(this._storageKey(), String(retryAt))
        this._applyDeadline(retryAt)
    }

    /**
     * Reads the deadline carried by a rejected submit, so a wiped localStorage re-locks the UI.
     * @param {unknown} error
     * @returns {void}
     */
    startFromError(error) {
        this.start(error?.response?.data?.data?.retry_at)
    }

    /**
     * @returns {number} Seconds still remaining, 0 when free.
     */
    secondsLeft() {
        const retryAt = this._read()

        if (!retryAt) {
            return 0
        }

        return Math.max(0, retryAt - Math.floor(Date.now() / 1000))
    }

    /**
     * @returns {void}
     */
    destroy() {
        this._clearTimer()
    }

    // #endregion

    // #region Internal

    /**
     * @param {number|null} retryAt
     * @returns {void}
     */
    _applyDeadline(retryAt) {
        this._clearTimer()

        if (!retryAt) {
            return
        }

        const remaining = retryAt - Math.floor(Date.now() / 1000)

        if (remaining <= 0) {
            this._release()
            return
        }

        this._button?.load()
        this._timer = setTimeout(() => this._release(), remaining * 1000)
    }

    /**
     * @returns {void}
     */
    _release() {
        this._clearTimer()
        localStorage.removeItem(this._storageKey())
        this._button?.unload()
    }

    /**
     * @returns {number|null}
     */
    _read() {
        const stored = parseInt(localStorage.getItem(this._storageKey()), 10)

        if (isNaN(stored) || stored <= Math.floor(Date.now() / 1000)) {
            return null
        }

        return stored
    }

    /**
     * @returns {string}
     */
    _storageKey() {
        return `solaris.test_email_retry_at.${this._scope}`
    }

    /**
     * @returns {void}
     */
    _clearTimer() {
        if (!this._timer) {
            return
        }

        clearTimeout(this._timer)
        this._timer = null
    }

    // #endregion
}
