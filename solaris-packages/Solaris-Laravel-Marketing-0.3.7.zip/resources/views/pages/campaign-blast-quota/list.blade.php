<x-core::page.list
	id="campaign-blast-quota"
	title="Campaign Blast Quota"
	class="table-hover"
	:breadcrumbs="$breadcrumbs"
	model="CampaignBlastQuota"
	package="marketing"
	path="campaign-blast-quota/list-index"
	new="@campaign-blast-quota-modal"
	extend_columns="total_quota,quota_book,quota_used,auto_renew_days,effective_at,expired_at,provider,auto_renew,period"
	export folder lazy :select_all="false">

	<x-slot:table-pre-right-action>
		<div class="btn-group btn-group-sm" role="group">
			<input type="radio" class="btn-check" name="filter-type" id="filter-type-all" value="" checked>
			<label class="btn btn-outline-primary" for="filter-type-all">All</label>

			<input type="radio" class="btn-check" name="filter-type" id="filter-type-email" value="email">
			<label class="btn btn-outline-primary" for="filter-type-email">Email</label>

			<input type="radio" class="btn-check" name="filter-type" id="filter-type-wa" value="wa">
			<label class="btn btn-outline-primary" for="filter-type-wa">WhatsApp</label>
		</div>
	</x-slot>

	<x-slot:table-left-action>
		<x-core::checkbox id="filter-active" switch label="Active only" />
	</x-slot>

	<x-slot:table-column>
		<x-core::table-action-column :view="false" :edit="false"/>

		<x-core::table-column
			name="info"
			data="type.name"
			searchable
			width="25%">
			Info
		</x-core::table-column>

		<x-core::table-column
			cell_class="text-nowrap"
			name="quota_info">
			Quota
		</x-core::table-column>
	</x-slot>

	@push('modal-content')
		@include("marketing::pages.campaign-blast-quota.modal")
		@include("marketing::pages.campaign-blast-quota.usage-modal")
	@endpush

	@push('scripts')
		<script>
			const EMAIL_PROVIDERS = {{ Js::from($email_providers) }};
			const WA_PROVIDERS = {{ Js::from($wa_providers) }};
		</script>
	@endpush

</x-core::page.list>
