@push('styles')
    <style>
        #campaign-blast-quota-usage .modal-dialog {
            max-width: 56rem;
        }

        #campaign-blast-quota-usage .list-container {
            max-height: 55vh;
            overflow-y: auto;
            scrollbar-width: thin;
        }

        #campaign-blast-quota-usage .list-container::-webkit-scrollbar {
            width: 0.5rem !important;
        }

        #campaign-blast-quota-usage .list-container::-webkit-scrollbar-track {
            background: var(--default-background);
            border-radius: 0.25rem;
        }

        #campaign-blast-quota-usage .list-container::-webkit-scrollbar-thumb {
            background: var(--default-border);
            border-radius: 0.25rem;
        }

        #campaign-blast-quota-usage .list-container::-webkit-scrollbar-thumb:hover {
            background: var(--text-muted);
        }

        #campaign-blast-quota-usage .usage-row {
            border: 1px solid var(--default-border);
            border-radius: 0.35rem;
            padding: 0.75rem 0.9rem;
        }

        #campaign-blast-quota-usage .usage-metric {
            min-width: 5rem;
        }

        #campaign-blast-quota-usage .usage-row-clickable {
            cursor: pointer;
            transition: border-color .15s ease, background-color .15s ease;
        }

        #campaign-blast-quota-usage .usage-row-clickable:hover {
            border-color: var(--primary-color);
            background-color: var(--primary01);
        }
    </style>
@endpush

<x-core::modal
    id="campaign-blast-quota-usage"
    body:class="p-3 p-lg-4"
    animation="scale"
    static
    center>

    <x-slot:header class="border-0">
        <button type="button" class="btn-close" id="campaign-blast-quota-usage_close" aria-label="Close"></button>
    </x-slot>

    <div class="d-flex align-items-center gap-2 mb-3">
        <x-core::button
            id="campaign-blast-quota-usage_back"
            icon
            variant="outline"
            color="light"
            size="sm"
            class="d-none">
            <i class="ri-arrow-left-line"></i>
        </x-core::button>

        <h5 class="mb-0" id="campaign-blast-quota-usage_title">Quota Usage History</h5>
    </div>

    <div class="usage-list-pane">
        <div class="d-flex align-items-center gap-2">
            <x-core::search-input id="campaign-blast-quota-usage_search" wrap:class="w-100" disabled placeholder="Search campaign" />
            <x-core::refresh-button id="campaign-blast-quota-usage_refresh" disabled color="light" />
        </div>

        <div class="mt-3 vstack gap-3 list-container p-1"></div>

        <div class="text-center py-5 d-none empty-state">
            <i class="bi bi-search text-muted" style="font-size: 3rem;"></i>
            <p class="text-muted mt-2 mb-0">No usage recorded for this quota</p>
        </div>
    </div>

    <div class="usage-detail-pane d-none">
        <x-core::table
            id="campaign-blast-quota-usage-detail_table"
            model="CampaignBlastQuotaLog"
            order_by="created_at:desc"
            extend_columns="action,context,book_delta,used_delta"
            :card_wrapper="false"
            :new="false"
            :search="false"
            :export="false"
            :import="false"
            :select_all="false"
            :delete_all="false"
            :folder="false"
            :length="10"
            lazy>

            <x-slot:column>
                <x-core::table-column
                    name="created_at"
                    data="created_at"
                    type="datetime"
                    orderable
                    default_order="desc"
                    cell_class="text-nowrap"
                    width="20%">
                    Time
                </x-core::table-column>

                <x-core::table-column name="entry" width="34%">
                    Entry
                </x-core::table-column>

                <x-core::table-column
                    name="delta"
                    cell_class="text-nowrap text-end"
                    width="22%">
                    Movement
                </x-core::table-column>

                <x-core::table-column
                    name="quota_book_after"
                    data="quota_book_after"
                    cell_class="text-nowrap text-end"
                    width="12%">
                    Quota Book
                </x-core::table-column>

                <x-core::table-column
                    name="created_by"
                    data="created_by.name"
                    lookup
                    cell_class="text-nowrap"
                    width="12%">
                    By
                </x-core::table-column>
            </x-slot>

        </x-core::table>
    </div>

    <x-slot:footer>
        <x-core::button color="light" data-bs-dismiss="modal" aria-label="Close">Cancel</x-core::button>
    </x-slot>

</x-core::modal>
