<x-core::modal-form
	id="campaign-blast-quota-modal"
	title="Campaign Blast Quota"
	model="CampaignBlastQuota"
	size="md">

	<x-core::field id="campaign-blast-quota-type_id:type_id" label="Type" required>
		<x-core::lookup
			:options="Solaris\Marketing\Models\CampaignBlastType::toSelect()"
			placeholder="Choose type"/>
	</x-core::field>

	<x-core::field id="campaign-blast-quota-provider:provider" label="Provider" required disabled>
		<x-core::lookup placeholder="Choose Provider" />
	</x-core::field>

	<x-core::field id="campaign-blast-quota-total_quota:total_quota" label="Quota" required>
		<x-core::input number placeholder="Enter Quota"/>
	</x-core::field>

	<x-core::field id="campaign-blast-quota-effective_at:effective_at" label="Effective at" required>
		<x-core::date-picker placeholder="Enter Effective At" mode="datetime"/>
	</x-core::field>

	<x-core::field id="campaign-blast-quota-period:period" label="Period" required>
		<x-core::lookup placeholder="Choose Period" />
	</x-core::field>

	<x-core::field id="campaign-blast-quota-auto_renew_days:auto_renew_days" label="Reset Every (Days)" hidden>
		<x-core::input number placeholder="Enter number of days" />
	</x-core::field>

	<x-core::checkbox
		id="campaign-blast-quota-auto_renew:auto_renew"
		wrap:class="mb-3"
		switch
		label="Auto renew" />

</x-core::modal-form>
