<x-core::table
    id="event-audience_list" 
    class="table-hover"
    model="EventAudience"
    new="@event-audience-modal"
    delete_all :card_wrapper="false"
    extend_search="contact[primary_phone,primary_mobile_phone,email]"
    filter="event_id = {{ $id }}" lazy>

    <x-slot:left-action>
        <x-core::button id="add-event-segmentation" size="sm" color="secondary" disabled>
            <span class="ri-folders-line me-1"></span>Add from segmentation
        </x-core::button>
    </x-slot:left-action>
    
    <x-slot:column>
        <x-core::table-action-column :view="false" :edit="false" />

        <x-core::table-column 
            cell_class="text-nowrap"
            name="contact_name"
            data="contact.name" 
            lookup="profile_picture_id" 
            searchable 
            orderable>
            Contact
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            name="contact_primary_mobile_phone"
            data="contact.primary_mobile_phone" 
            searchable 
            orderable>
            Mobile phone
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            name="contact_email"
            data="contact.email" 
            searchable 
            orderable>
            Email
        </x-core::table-column>
    </x-slot>

</x-core::table>

@push('modal-content')
    @include("marketing::pages.event.audience.modal", ["id" => $id])
    <x-marketing::audience-segmentation-modal 
        id="event-segmentation" 
        title="Event Audience" 
        preview_model="Contact@availableInEventAudience({{ $id }})" />
@endpush