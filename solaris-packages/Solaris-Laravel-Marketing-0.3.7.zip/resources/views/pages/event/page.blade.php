<x-core::page.edit
    :id="$data->id"
    title="Event"
    :breadcrumbs="$breadcrumbs"
    model="Event"
    package="marketing"
    path="event/page-index"
    profile-position="left">

    <x-slot:header>
        <div class="row mb-3">
            <div class="col">
                <x-core::stage-buttons id="event-page-stage_id:stage_id" :stages="SolarHelper::model('event_stage')::toStage(true)" :value="$data->stage_id" />
            </div>
        </div>
    </x-slot>

    <x-slot:profile>
        @include('marketing::pages.event.sections.profile', ["data" => $data])
    </x-slot>

    @php
        $tabId = "event-page-tabs";
    @endphp

    <x-core::tab id="{{ $tabId }}" class="p-0 mb-4">
        <x-slot:nav>
            <x-core::tab-nav id="{{ $tabId }}_audience" active>Audience</x-core::tab-nav>
            <x-core::tab-nav id="{{ $tabId }}_history">History</x-core::tab-nav>
            <x-core::tab-nav id="{{ $tabId }}_attachment">Attachment</x-core::tab-nav>
            <x-core::tab-nav id="{{ $tabId }}_notes">Notes</x-core::tab-nav>
        </x-slot>

        <x-slot:content>
            <x-core::tab-content id="{{ $tabId }}_audience" active class="p-0 border-0">
                <x-core::field id="event-page-goal:goal" label="Goal" >
                    <x-core::input 
                        id="event-page-goal" 
                        placeholder="Enter Goal"
                        :value="$data->goal"/>
                </x-core::field>

                <div class="row">
                    <div class="col-md-6">
                        <x-core::field id="event-page-budget_cost:budget_cost" label="Budget Cost" >
                            <x-core::input 
                                id="event-page-budget_cost" 
                                number 
                                decimal 
                                :value="$data->budget_cost" />
                        </x-core::field>
                    </div>

                    <div class="col-md-6">
                        <x-core::field id="event-page-actual_cost:actual_cost" label="Actual Cost" >
                            <x-core::input 
                                id="event-page-actual_cost" 
                                number decimal 
                                :value="$data->actual_cost" />
                        </x-core::field>
                    </div>
                </div>

                @include("marketing::pages.event.audience.list", ["id" => $data->id])
            </x-core::tab-content>

            <x-core::tab-content id="{{ $tabId }}_history" class="p-0 border-0">

                <x-core::tab id="{{ $tabId }}_history_tab" class="scaleX p-0 mb-4" variant="tab-style-7">
                    <x-slot:nav>
                        <x-core::tab-nav id="{{ $tabId }}_history_tab_activity" active>Activity</x-core::tab-nav>
                        <x-core::tab-nav id="{{ $tabId }}_history_tab_stage">Stage history</x-core::tab-nav>
                    </x-slot>

                    <x-slot:content>

                        <x-core::tab-content id="{{ $tabId }}_history_tab_activity" active class="p-0 border-0">
                            @include("marketing::pages.event.activity.list", ["id" => $data->id])
                        </x-core::tab-content>

                        <x-core::tab-content id="{{ $tabId }}_history_tab_stage" class="p-0 border-0">
                            @include('marketing::pages.event.stage-history.list', ['id' => $data->id])
                        </x-core::tab-content>

                    </x-slot>
                </x-core::tab>

            </x-core::tab-content>

            <x-core::tab-content id="{{ $tabId }}_attachment" class="p-0 border-0">
                <x-core::attachment id="event-page-attachment" relation="events:{{ $data->id }}"/>
            </x-core::tab-content>

            <x-core::tab-content id="{{ $tabId }}_notes" class="p-0 border-0">
                <x-core::notes 
                    id="event-page-notes:notes"
                    model="Event"
                    column="notes"
                    :record_id="$data->id">{!! $data->notes !!}</x-core::notes>
            </x-core::tab-content>
        </x-slot>
    </x-core::tab>

</x-core::page.edit>