<x-core::table
    id="event-stage-history_list"
    class="table-hover"
    model="EventStageHistory"
    :new="false"
    :import="false"
    :select_all="false"
    export lazy :card_wrapper="false"
    filter="event_id = {{ $id }}">

    <x-slot:column>
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="stage.name" 
            searchable 
            orderable>
            Stage
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="start"
            type="datetime" 
            searchable 
            orderable>
            Start
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="end"
            type="datetime" 
            searchable 
            orderable>
            End
        </x-core::table-column>
    </x-slot>

</x-core::table>