<x-core::card>
    <x-core::field id="event-page-name:name" label="Name" required>
        <x-core::input
            placeholder="Enter Name"
            :value="$data->name"/>
    </x-core::field>

    <x-core::field id="event-page-status_id:status_id" label="Status" required>
        <x-core::lookup
            placeholder="Choose Status"
            :options="SolarHelper::model('event_status')::toSelect()"
            :value="json_encode($data->status)" />
    </x-core::field>

    <x-core::field id="event-page-type_id:type_id" label="Type" required>
        <x-core::lookup
            placeholder="Choose Type"
            :options="SolarHelper::model('event_type')::toSelect()"
            :value="json_encode($data->type)" />
    </x-core::field>

    <x-core::field id="event-page-start_date:start_date" label="Start Date" required>
        <x-core::date-picker
            placeholder="Enter Start Date"
            :value="$data->start_date" />
    </x-core::field>

    <x-core::field id="event-page-end_date:end_date" label="End Date" >
        <x-core::date-picker
            placeholder="Enter End Date"
            :value="$data->end_date" />
    </x-core::field>
</x-core::card>