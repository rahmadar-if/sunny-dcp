<x-core::modal-form  
    id="event-modal" 
    title="Event" 
    model="Event"
    size="md">

    <x-core::field id="event-modal-name:name" label="Name" required>
        <x-core::input
            placeholder="Enter Name"/>
    </x-core::field>

    <x-core::field id="event-modal-type_id:type_id" label="Type" required>
        <x-core::lookup
            placeholder="Choose Type"
            :options="SolarHelper::model('event_type')::toSelect()" />
    </x-core::field>

    <x-core::field id="event-modal-start_date:start_date" label="Start date" required>
        <x-core::date-picker
            placeholder="Enter Start Date"/>
    </x-core::field>

    <x-core::field id="event-modal-end_date:end_date" label="End date" required>
        <x-core::date-picker
            placeholder="Enter End Date"/>
    </x-core::field>
</x-core::modal-form>