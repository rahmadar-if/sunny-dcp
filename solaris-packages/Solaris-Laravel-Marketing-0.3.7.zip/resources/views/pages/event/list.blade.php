<x-core::page.list
    id="event"
    title="Event"
    class="table-hover"
    :breadcrumbs="$breadcrumbs"
    model="Event"
    package="marketing"
    path="event/list-index"
    new="@event-modal"
    import export folder lazy delete_all>

    <x-slot:table-column>
        <x-core::table-action-column :view="false"/>

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="name" 
            searchable 
            orderable>
            Name
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="type.name" 
            searchable 
            orderable
            format="badge:secondary">
            Type
        </x-core::table-column>

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="start_date" 
            searchable 
            orderable
            type="date">
            Start date
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="end_date" 
            searchable 
            orderable
            type="date">
            End date
        </x-core::table-column>

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="status.name" 
            searchable 
            orderable
            format="badge:primary">
            Status
        </x-core::table-column>

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="stage.name" 
            searchable 
            orderable>
            Stage
        </x-core::table-column>
    </x-slot>

    @push('modal-content')
        @include("marketing::pages.event.modal")
    @endpush

</x-core::page.list>