<x-core::page.blank
    title="Email Template"
    package="marketing"
    path="email-template/page-index">

    <input type="hidden" name="_id" value="{{ isset($id) ? $id : '' }}">

    <x-marketing::stripo-editor id="stripo-editor" ignore>
        <x-slot:pre-left-action>
            <x-core::input
                id="template-name"
                placeholder="Template name"
                size="sm" disabled
                value="{{ isset($name) ? $name : '' }}"
                style="min-width: 250px;" />
        </x-slot>
    </x-marketing::stripo-editor>

    @push('scripts')
        <script>
            const STRIPO_EMAIL_ID = {{ Js::from($email_id) }};
            const MERGE_TAGS = {!! json_encode($merge_tags) !!};
        </script>
    @endpush

</x-core::page.blank>