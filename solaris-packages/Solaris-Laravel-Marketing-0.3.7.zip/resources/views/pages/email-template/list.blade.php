@push('styles')
<style>
    .template-thumb-container {
        height: 200px;
        overflow: hidden;
        position: relative;
        background: #f8f9fa;
    }

    .template-thumb-iframe {
        width: 600px;
        height: 500px;
        transform: translateX(-50%) scale(0.4);
        transform-origin: top center;
        position: absolute;
        top: 0;
        left: 50%;
        border: none;
        pointer-events: none;
    }
</style>
@endpush

<x-core::page.list
    id="email-template"
    title="Email Template"
    class="table-hover"
    :breadcrumbs="$breadcrumbs"
    model="EmailTemplate"
    package="marketing"
    path="email-template/list-index"
    mode="card"
    length="12"
    :card_wrapper="false"
    extend_columns="created_by.name,html_compiled"
    lazy>
    
    <x-slot:table-column class="d-none">
        <x-core::table-column data="name" searchable orderable></x-table-column>
    </x-slot>

</x-core::page.list>