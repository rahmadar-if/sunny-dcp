<x-core::modal-form  
    id="email-blast-modal" 
    title="Email Blast" 
    model="EmailBlast"
    size="md">

    <x-core::field id="email-blast-modal-title:title" label="Title" required>
        <x-core::input
            placeholder="Enter Title"/>
    </x-core::field>

    <x-core::field id="email-blast-modal-priority_id:priority_id" label="Priority" required>
        <x-core::lookup
            placeholder="Choose Priority"
            :options="SolarHelper::model('activity_priority')::toSelect()" />
    </x-core::field>
</x-core::modal-form>