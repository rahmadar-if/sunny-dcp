<x-core::page.blank
    title="Email Blast - Template Editor"
    package="marketing"
    path="email-blast/editor-index">

    <input type="hidden" name="email_blast_id" value="{{ $id }}">

    <x-marketing::stripo-editor id="stripo-editor" ignore>
        <x-slot:left-action>
            <x-core::button id="choose-template-button" size="sm" class="w-100" disabled>
                <i class="ri-book-marked-line me-1"></i> Choose template
            </x-core::button>
            <x-core::button id="save-template-button" size="sm" style="min-width: 150px;" disabled>
                <i class="ri-file-marked-line me-1"></i> Save as template
            </x-core::button>
        </x-slot>
    </x-marketing::stripo-editor>

    @push('modal-content')
    {{-- Choose Template Modal --}}
    <x-core::modal 
        id="choose-template-modal" 
        size="xl"
        title="Choose Template"
        center 
        static>

        <x-core::table 
            id="choose-template-modal_table"
            :card_wrapper="false"
            mode="card"
            :new="false"
            :select_all="false"
            model="EmailTemplate"
            extend_columns="html_compiled,html,css"
            length="12" lazy>
            <x-slot:column class="d-none">
                <x-core::table-column data="name" searchable orderable></x-table-column>
            </x-slot>
        </x-core::table>

        <div id="template-picker-grid" class="d-none row g-3"></div>
    </x-core::modal>

    {{-- Save as Template Modal --}}
    <x-core::modal-form 
        id="save-template-modal" 
        size="md" 
        title="Save as Template"
        model="EmailTemplate">

        <x-core::field id="save-template-modal_name:name" label="Template Name" required>
            <x-core::input placeholder="Enter template name" />
        </x-core::field>
    </x-core::modal>
    @endpush

    @push('styles')
        <style>
            .template-picker-card {
                cursor: pointer;
                transition: box-shadow 0.15s ease, transform 0.15s ease;
                border: 2px solid transparent;
            }

            .template-picker-card:hover {
                box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
                transform: translateY(-2px);
                border-color: var(--bs-primary);
            }

            .template-thumb-container {
                height: 200px;
                overflow: hidden;
                position: relative;
                border-radius: 4px;
                background: #f8f9fa;
            }

            .template-thumb-iframe {
                width: 600px;
                height: 500px;
                transform: translateX(-50%) scale(0.4);
                transform-origin: top center;
                position: absolute;
                top: 0;
                left: 50%;
                border: none;
                pointer-events: none;
            }
        </style>
    @endpush

    @push('scripts')
        <script>
            const TEMPLATE_HTML = {{ Js::from($html) }};
            const TEMPLATE_CSS  = {{ Js::from($css) }};
            const STRIPO_EMAIL_ID = {{ Js::from($email_id) }};
            const MERGE_TAGS = {!! json_encode($merge_tags) !!};
        </script>
    @endpush

</x-core::page.blank>