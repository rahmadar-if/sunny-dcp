<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Email Preview - No Template</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        html, body {
            height: 100%;
            margin: 0;
            background: rgb(246, 246, 251);
            font-family: "Poppins", sans-serif;
            font-size: 0.8125rem;
            font-weight: 400;
            color: #191919;
        }
        .container {
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .card {
            background: #ffffff;
            border-radius: 10px;
            border: 1px solid #e6ebf1;
            padding: 32px 40px;
            max-width: 420px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
        }
        .icon {
            font-size: 48px;
            margin-bottom: 16px;
        }
        .title {
            font-size: 1.125rem;
            font-weight: 600;
            margin-bottom: 8px;
        }
        .desc {
            font-size: 0.8125rem;
            line-height: 1.5;
            color: #5c708f;
        }
        .hint {
            margin-top: 16px;
            font-size: 0.75rem;
            color: #949eb7;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="card">
        <div class="icon">📭</div>
        <div class="title">No email template available</div>
        <div class="desc">
            This email has not been created or generated yet.
            There is no content to preview at the moment.
        </div>
        <div class="hint">
            Create or generate the email template to see a preview.
        </div>
    </div>
</div>
</body>
</html>