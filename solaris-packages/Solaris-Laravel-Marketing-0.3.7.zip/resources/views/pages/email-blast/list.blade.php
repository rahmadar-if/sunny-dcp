@push('styles')
<style>
    .template-thumb-container {
        height: 200px;
        overflow: hidden;
        position: relative;
        background: #f8f9fa;
    }

    .template-thumb-container.no-template {
        display: flex;
        align-items: center;
        justify-content: center;
        flex-direction: column;
        gap: .5rem;
        color: #adb5bd;
    }

    .template-thumb-iframe {
        width: 600px;
        height: 500px;
        transform: translateX(-50%) scale(0.4);
        transform-origin: top center;
        position: absolute;
        top: 0;
        left: 50%;
        border: none;
        pointer-events: none;
    }
</style>
@endpush

<x-core::page.list
    id="email-blast"
    title="Email Blast"
    class="table-hover"
    :breadcrumbs="$breadcrumbs"
    model="EmailBlast"
    package="marketing"
    path="email-blast/list-index"
    mode="card"
    length="12"
    :card_wrapper="false"
    new="@email-blast-modal"
    extend_columns="priority,created_by,status,total_audience,total_success,total_unique_open,total_unique_click,body"
    export folder lazy>
    
    <x-slot:table-column class="d-none">
        <x-core::table-column data="title" searchable orderable></x-table-column>
    </x-slot>

    @push('modal-content')
        @include("marketing::pages.email-blast.modal")
    @endpush

</x-core::page.list>