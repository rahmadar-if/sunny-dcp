<x-core::table
    id="email-blast-audience_list" 
    class="table-hover"
    model="EmailBlastAudience"
    :new="!$disabled ? '@email-blast-audience-modal' : false"
    delete_all :card_wrapper="false"
    extend_search="contact.email"
    filter="email_blast_id = {{ $id }}" lazy>

    <x-slot:left-action>
        <x-core::button id="add-email-blast-segmentation" size="sm" color="secondary" disabled>
            <span class="ri-folders-line me-1"></span>Add from segmentation
        </x-core::button>
    </x-slot:left-action>

    <x-slot:pre-right-action>
        <x-core::lookup
            id="audience_status_filter"
            placeholder="Choose audience status" 
            size="sm"
            multiple
            :options="SolarHelper::model('email_blast_audience_status')::toSelect()"
            wrapper_style="width: 250px"
            :copy="false"
            disabled
            ignore />
    </x-slot:pre-right-action>

    <x-slot:column>
        <x-core::table-action-column :view="false" :edit="false" />

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="contact.name" 
            lookup="email,profile_picture_id" 
            searchable 
            orderable>
            Contact
        </x-core::table-column>

        <x-core::table-column 
            data="status.name" 
            searchable 
            orderable>
            Status
        </x-table-column>

        <x-core::table-column 
            data="open" 
            orderable>
            Open
        </x-table-column>
        
        <x-core::table-column 
            data="click" 
            orderable>
            Click
        </x-table-column>
        
        <x-core::table-column 
            data="unsubscribe" 
            orderable>
            Unsubscribe
        </x-table-column>

        <x-core::table-column 
            data="spam" 
            orderable>
            Spam
        </x-table-column>

        <x-core::table-column 
            data="message"
            expand>
            Message
        </x-table-column>
    </x-slot>

</x-core::table>

@push('modal-content')
    @include("marketing::pages.email-blast.audience.modal", ["id" => $id])
    <x-marketing::audience-segmentation-modal 
        id="email-blast-segmentation" 
        title="Email Blast Audience" 
        preview_model="Contact@availableInEmailBlastAudience({{ $id }})" />
@endpush