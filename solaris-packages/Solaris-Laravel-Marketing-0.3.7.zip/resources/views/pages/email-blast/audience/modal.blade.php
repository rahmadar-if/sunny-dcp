<x-core::modal-form
	id="email-blast-audience-modal"
	title="Email Blast audience"
	size="lg"
    save="Select"
    action="{{ route('marketing.email-blast.add-audience') }}">

    <x-core::table
        id="email-blast-audience-modal_list" 
        class="table-hover"
        model="Contact@availableInEmailBlastAudience({{ $id }})"
        :new="false"
        vertical="350"
        extend_columns="profile_picture_id"
        :card_wrapper="false"
        folder lazy>

        <x-slot:column>
            <x-core::table-select-column/>
            <x-core::table-column 
                data="name" 
                searchable 
                orderable>
                Contact
            </x-core::table-column>
            
            <x-core::table-column 
                data="primary_mobile_phone" 
                searchable 
                orderable>
                Mobile phone
            </x-core::table-column>
            
            <x-core::table-column 
                data="email" 
                searchable 
                orderable>
                Email
            </x-core::table-column>
        </x-slot>

    </x-core::table>

</x-core::modal>
