<x-core::table
    id="email-blast-status-history_list"
    class="table-hover"
    model="EmailBlastStatusHistory"
    :new="false"
    :import="false"
    :select_all="false"
    export lazy :card_wrapper="false"
    filter="email_blast_id = {{ $id }}">

    <x-slot:column>
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="status.name" 
            searchable 
            orderable>
            Status
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="start"
            type="datetime" 
            searchable 
            orderable>
            Start
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="end" 
            type="datetime"
            searchable 
            orderable>
            End
        </x-core::table-column>
    </x-slot>

</x-core::table>