<x-core::modal-form  
    id="email-blast-schedule-modal" 
    title="Schedule" 
    action="{{ route('marketing.email-blast.schedule') }}"
    size="md">

    <x-core::field id="email-blast-schedule-modal-schedule_at:schedule_at" label="Schedule at" required>
        <x-core::date-picker
            mode="datetime"
            placeholder="Enter Schedule At" />
    </x-core::field>
</x-core::modal-form>