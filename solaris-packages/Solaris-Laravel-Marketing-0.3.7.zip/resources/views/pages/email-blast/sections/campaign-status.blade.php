<div class="row">
    <div class="col-xl-3 col-md-6">
        <x-core::metric 
            id="email-blast-page-total_audience"
            title="Total Audience"
            value="{{ $data->total_audience }}"
            lazy />
    </div>

    <div class="col-xl-3 col-md-6">
        <x-core::metric
            id="email-blast-page-delivery_rate"
            title="Delivery Rate"
            value="{{ SolarNumber::readableNumber($data->delivery_rate, 1) }}%"
            lazy />
    </div>

    <div class="col-xl-3 col-md-6">
        <x-core::metric 
            id="email-blast-page-open_rate"
            title="Open Rate"
            value="{{ SolarNumber::readableNumber($data->open_rate, 1) }}%"
            lazy />
    </div>

    <div class="col-xl-3 col-md-6">
        <x-core::metric 
            id="email-blast-page-click_rate"
            title="Click Rate"
            value="{{ SolarNumber::readableNumber($data->click_rate, 1) }}%"
            lazy />
    </div>
</div>

<div class="row">
    <div class="col-xxl-3 col-xl-4 col-md-6">
        <x-core::metric
            variant="simple-icon" 
            id="email-blast-page-pending"
            icon="ri-time-line"
            title="Pending"
            color="primary"
            value="{{ $data->total_pending }}"
            changeValue="{{ SolarNumber::readableNumber($data->total_pending_percent, 1) }}%"
            changeTitle="Percentage"
            lazy />
    </div>

    <div class="col-xxl-3 col-xl-4 col-md-6">
        <x-core::metric
            variant="simple-icon" 
            id="email-blast-page-progress"
            icon="ri-progress-2-line"
            title="In Progress"
            color="info"
            value="{{ $data->total_progress }}"
            changeValue="{{ SolarNumber::readableNumber($data->total_progress_percent, 1) }}%" 
            changeTitle="Percentage"
            lazy />
    </div>

    <div class="col-xxl-3 col-xl-4 col-md-6">
        <x-core::metric
            variant="simple-icon" 
            id="email-blast-page-failed"
            icon="ri-close-circle-line"
            color="danger"
            title="Failed"
            value="{{ $data->total_fail }}"
            changeValue="{{ SolarNumber::readableNumber($data->total_fail_percent, 1) }}%"
            changeTitle="Percentage"
            lazy />
    </div>

    <div class="col-xxl-3 col-xl-12 col-md-6">
        <x-core::metric
            variant="simple-icon" 
            id="email-blast-page-delivered"
            icon="ri-checkbox-circle-line"
            title="Delivered"
            color="success"
            value="{{ $data->total_success }}"
            changeValue="{{ SolarNumber::readableNumber($data->total_delivered_percent, 1) }}%"
            changeTitle="Percentage"
            lazy />
    </div>
</div>

<div class="row">
    <div class="col-xl-6 d-flex align-items-stretch">
        <x-core::card>
            <x-slot:header>
                <div class="card-title">Engagement Funnel</div>
            </x-slot:header>

            <ul class="list-unstyled top-countries-list"> 
                <li id="email-blast-page-total_unique_open"> 
                    <div class="d-flex justify-content-between mb-1">
                        <span class="fw-medium d-block">Opened</span>
                        <div>
                            <span class="fw-medium value">{{ $data->total_unique_open }}</span>
                            <span class="text-muted value-percent">({{ SolarNumber::readableNumber($data->open_rate, 1) }}%)</span>
                        </div>
                    </div>
                    <div class="progress progress-animate" role="progressbar" aria-valuenow="{{ $data->open_rate }}" aria-valuemin="0" aria-valuemax="100"> 
                        <div class="progress-bar progress-bar-striped progress-bar-animated bg-info" style="width: {{$data->open_rate}}%"> </div> 
                    </div>
                </li>
                
                <li id="email-blast-page-total_unique_click"> 
                    <div class="d-flex justify-content-between mb-1">
                        <span class="fw-medium d-block">Clicked</span>
                        <div>
                            <span class="fw-medium value">{{ $data->total_unique_click }}</span>
                            <span class="text-muted value-percent">({{ SolarNumber::readableNumber($data->click_rate, 1) }}%)</span>
                        </div>
                    </div>
                    <div class="progress progress-animate" role="progressbar" aria-valuenow="{{ $data->click_rate }}" aria-valuemin="0" aria-valuemax="100"> 
                        <div class="progress-bar progress-bar-striped progress-bar-animated bg-secondary" style="width: {{$data->click_rate}}%"> </div> 
                    </div>
                </li>

                <li>
                    <div class="d-flex justify-content-between mb-1">
                        <div class="d-flex flex-column gap-1">
                            <span class="fw-medium d-block">Click to Open Rate</span>
                            <span class="text-muted">Percentage of openers who clicked</span>
                        </div>
                        <span id="email-blast-page-click_to_open_rate" class="fw-medium">{{ SolarNumber::readableNumber($data->click_to_open_rate, 1) }}%</span>
                    </div>
                </li>
            </ul>
        </x-core::card>
    </div>

    <div class="col-xl-6">
        <x-core::card>
            <x-slot:header>
                <div class="card-title">Issues & Alerts</div>
            </x-slot:header>

            <x-core::card class="border border-warning">
                <div class="d-flex justify-content-between">
                    <div class="d-flex align-items-center"> 
                        <span class="avatar avatar-rounded bg-warning svg-white me-2"> 
                            <i class="ri-error-warning-line fs-20"></i>
                        </span> 
                        <div class="d-flex flex-column"> 
                            <span class="fs-15 fw-medium">Spam Reports</span> 
                            <span class="op-7 fs-12">Marked as spam by recipients</span>
                        </div> 
                    </div>
                    <div class="d-flex flex-column align-items-end gap-1" id="email-blast-page-total_spam">
                        <span class="fs-15 fw-medium value">{{ $data->total_spam }}</span> 
                        <span class="op-7 fs-12 value-percent">{{ SolarNumber::readableNumber($data->total_spam_percent, 1) }}%</span>
                    </div>
                </div>
            </x-core::card>

            <x-core::card class="border border-danger">
                <div class="d-flex justify-content-between">
                    <div class="d-flex align-items-center"> 
                        <span class="avatar avatar-rounded bg-danger svg-white me-2"> 
                            <i class="ri-user-unfollow-line fs-20"></i>
                        </span> 
                        <div class="d-flex flex-column"> 
                            <span class="fs-15 fw-medium">Unsubscribed</span> 
                            <span class="op-7 fs-12">Opted out from future emails</span>
                        </div> 
                    </div>
                    <div class="d-flex flex-column align-items-end gap-1" id="email-blast-page-total_unsubscribe">
                        <span class="fs-15 fw-medium value">{{ $data->total_unsubscribe }}</span> 
                        <span class="op-7 fs-12 value-percent">{{ SolarNumber::readableNumber($data->total_unsubscribe_percent, 1) }}%</span>
                    </div>
                </div>
            </x-core::card>

        </x-core::card>
    </div>
</div>

<div class="row">
    <div class="col-xxl-4 col-md-6">
        <x-core::metric
            variant="simple-icon" 
            id="email-blast-page-total_open"
            icon="ri-time-line"
            title="Total Opens"
            color="info"
            value="{{ $data->total_open }}"
            changeTitle="Avg per recipient"
            changeValue="{{ SolarNumber::readableNumber($data->avg_open, 1) }}"
            lazy />
    </div>

    <div class="col-xxl-4 col-md-6">
        <x-core::metric
            variant="simple-icon" 
            id="email-blast-page-total_click"
            icon="ri-time-line"
            title="Total Clicks"
            color="secondary"
            value="{{ $data->total_click }}"
            changeTitle="Avg per recipient"
            changeValue="{{ SolarNumber::readableNumber($data->avg_click, 1) }}"
            lazy />
    </div>

    <div class="col-xxl-4 col-md-12">
        <x-core::metric
            variant="simple-icon" 
            id="email-blast-page-active_subscribe"
            icon="ri-time-line"
            title="Active Subscribers"
            color="success"
            value="{{ $data->total_success - $data->total_unsubscribe }}"
            lazy />
    </div>
</div>