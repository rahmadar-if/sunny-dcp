@php
    $provider = SolarHelper::config("email_blast.default");
    $domain   = SolarHelper::config("email_blast.providers.{$provider}.domain");
@endphp

<x-core::field id="email-blast-page-subject:subject" label="Subject" :disabled="$disabled">
    <x-core::input
        id="email-blast-page-subject"
        placeholder="Enter Subject"
        :value="$data->subject"/>
</x-core::field>

<div class="row">
    <div class="col-md-6">
        <x-core::field id="email-blast-page-sender_name:sender_name" label="Sender Name" :disabled="$disabled">
            <x-core::input
                id="email-blast-page-sender_name"
                placeholder="Enter Sender Name"
                :value="$data->sender_name"/>
        </x-core::field>
    </div>

    <div class="col-md-6">
        <x-core::field id="email-blast-page-sender_email:sender_email" label="Sender Email" :disabled="$disabled">

            <div class="input-group mb-3">
                <x-core::input
                    id="email-blast-page-sender_email"
                    placeholder="Enter Sender Email"
                    :value="explode('@', $data->sender_email)[0]"/>
                <span class="input-group-text">&commat;{{ $domain }}</span>
            </div>

        </x-core::field>
    </div>
</div>

<div class="my-3"></div>

<div class="d-flex gap-1">
    <x-core::button id="email-blast-page-edit-template" :disabled="$disabled ?? false">Edit template</x-button>
    <x-core::button id="email-blast-page-test-email" color="success" :disabled="empty($data->body)"><i class="ti ti-send me-1"></i>Test email</x-core::button>
</div>

<div class="mt-3">
    <iframe
        id="email-blast-page-email-template-frame"
        src="{{ route('marketing.email-blast.editor.preview', ['id' => $data->id]) }}"
        style="width:100%; height:100vh; border:0;">
    </iframe>
</div>