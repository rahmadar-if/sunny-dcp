<x-core::table
    id="contact-email-blast_list" 
    class="table-hover"
    model="EmailBlastAudience"
    :new="false"
    export lazy
    :card_wrapper="false"
    filter="contact_id = {{ $id }}">

    <x-slot:column>
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="email_blast.title" 
            lookup="status" 
            searchable 
            orderable>
            Campaign
        </x-core::table-column>

        <x-core::table-column 
            data="status.name" 
            searchable 
            orderable>
            Status
        </x-table-column>

        <x-core::table-column 
            data="open" 
            orderable>
            Open
        </x-table-column>
        
        <x-core::table-column 
            data="click" 
            orderable>
            Click
        </x-table-column>
        
        <x-core::table-column 
            data="unsubscribe" 
            orderable>
            Unsubscribe
        </x-table-column>

        <x-core::table-column 
            data="spam" 
            orderable>
            Spam
        </x-table-column>

        <x-core::table-column 
            data="message"
            expand>
            Message
        </x-table-column>
    </x-slot>

</x-core::table>