@php
    $id = "contact-page-tabs_history";
@endphp

<x-core::tab-content :id="$id" :active="$active ?? false" class="p-0 border-0">
    <x-core::tab id="{{ $id }}-tabs" class="p-0 mb-4" variant="tab-style-7" class="scaleX p-0 mb-4">
        <x-slot:nav>
            <x-core::tab-nav id="{{ $id }}-tabs_activity" active>Activity</x-core::tab-nav>
            
            {{-- BASE CRM UPDATE --}}
            <x-core::tab-nav id="{{ $id }}-tabs_contact_lead">Lead</x-core::tab-nav>

                {{-- MARKETING UPDATE --}}
                <x-core::tab-nav id="{{ $id }}-tabs_contact_event">Event</x-core::tab-nav>
                <x-core::tab-nav id="{{ $id }}-tabs_contact_email_blast">Email Blast</x-core::tab-nav>
                <x-core::tab-nav id="{{ $id }}-tabs_contact_wa_blast">WhatsApp Blast</x-core::tab-nav>
                {{-- END MARKETING UPDATE --}}

            <x-core::tab-nav id="{{ $id }}-tabs_status_history">Status History</x-core::tab-nav>
            {{-- END BASE CRM UPDATE --}}
        </x-slot>

        <x-slot:content>
            <x-core::tab-content id="{{ $id }}-tabs_activity" active class="p-0 border-0">
                @include('master-data::pages.contact.activity.list', ['id' => $data->id])
            </x-core::tab-content>

            {{-- BASE CRM UPDATE --}}
            <x-core::tab-content id="{{ $id }}-tabs_contact_lead" class="p-0 border-0">
                @include("base-crm::pages.contact.lead.list", ["id" => $data->id])
            </x-core::tab-content>

                {{-- MARKETING UPDATE --}}
                <x-core::tab-content id="{{ $id }}-tabs_contact_event" class="p-0 border-0">
                    @include("marketing::pages.contact.event.list", ["id" => $data->id])
                </x-core::tab-content>
                
                <x-core::tab-content id="{{ $id }}-tabs_contact_email_blast" class="p-0 border-0">
                    @include("marketing::pages.contact.email-blast.list", ["id" => $data->id])
                </x-core::tab-content>

                <x-core::tab-content id="{{ $id }}-tabs_contact_wa_blast" class="p-0 border-0">
                    @include("marketing::pages.contact.wa-blast.list", ["id" => $data->id])
                </x-core::tab-content>
                {{-- END MARKETING UPDATE --}}

            <x-core::tab-content id="{{ $id }}-tabs_status_history" class="p-0 border-0">
                @include('base-crm::pages.contact.status-history.list', ['id' => $data->id])
            </x-core::tab-content>
            {{-- END BASE CRM UPDATE --}}
        </x-slot>
    </x-core::tab>
</x-core::tab-content>