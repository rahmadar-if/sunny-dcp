@php
	$id = "contact-page-tabs_marketing";
@endphp

<x-core::tab-content :id="$id" :active="$active ?? false" class="p-0 border-0">
	<x-core::tab id="{{ $id }}-tabs" variant="tab-style-7" class="scaleX p-0 mb-4">
		<x-slot:nav>
			<x-core::tab-nav id="{{ $id }}-tabs_event" active>Event</x-core::tab-nav>
			<x-core::tab-nav id="{{ $id }}-tabs_email_blast">Email Blast</x-core::tab-nav>
			<x-core::tab-nav id="{{ $id }}-tabs_wa_blast">WhatsApp Blast</x-core::tab-nav>
		</x-slot>

		<x-slot:content>
			<x-core::tab-content id="{{ $id }}-tabs_event" active class="p-0 border-0">
				@include('marketing::pages.contact.event.list', ['id' => $data->id])
			</x-core::tab-content>

			<x-core::tab-content id="{{ $id }}-tabs_email_blast" class="p-0 border-0">
				@include('marketing::pages.contact.email-blast.list', ['id' => $data->id])
			</x-core::tab-content>

			<x-core::tab-content id="{{ $id }}-tabs_wa_blast" class="p-0 border-0">
				@include('marketing::pages.contact.wa-blast.list', ['id' => $data->id])
			</x-core::tab-content>
		</x-slot>
	</x-core::tab>
</x-core::tab-content>
