<x-core::table
    id="contact-wa-blast_list" 
    class="table-hover"
    model="WaBlastAudience"
    :new="false"
    export lazy
    :card_wrapper="false"
    filter="contact_id = {{ $id }}">

    <x-slot:column>
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="wa_blast.title" 
            lookup="status" 
            searchable 
            orderable>
            Campaign
        </x-core::table-column>

        <x-core::table-column 
            data="status.name" 
            searchable 
            orderable>
            Status
        </x-table-column>

        <x-core::table-column 
            data="replied" 
            orderable>
            Replied
        </x-table-column>

        <x-core::table-column 
            data="message"
            expand>
            Message
        </x-table-column>
    </x-slot>

</x-core::table>