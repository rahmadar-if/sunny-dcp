<x-core::table
    id="contact-event_list" 
    class="table-hover"
    model="EventAudience"
    :new="false"
    export lazy
    :card_wrapper="false"
    filter="contact_id = {{ $id }}">

    <x-slot:column>
        <x-core::table-column 
            cell_class="text-nowrap" 
            name="event_name"
            data="event.name"  
            searchable 
            orderable>
            Event
        </x-core::table-column>

        <x-core::table-column 
            cell_class="text-nowrap" 
            name="event_type"
            data="event.type.name"
            searchable 
            orderable
            format="badge:secondary">
            Type
        </x-core::table-column>

        <x-core::table-column 
            cell_class="text-nowrap"
            name="event_start_date" 
            data="event.start_date" 
            searchable 
            orderable
            type="date">
            Start Date
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap"
            name="event_end_date" 
            data="event.end_date" 
            searchable 
            orderable
            type="date">
            End Date
        </x-core::table-column>

        <x-core::table-column 
            cell_class="text-nowrap" 
            name="event_status" 
            data="event.status.name"  
            searchable 
            orderable
            format="badge:primary">
            Status
        </x-core::table-column>

        <x-core::table-column 
            cell_class="text-nowrap" 
            name="event_stage" 
            data="event.stage.name"  
            searchable 
            orderable>
            Stage
        </x-core::table-column>
    </x-slot>

</x-core::table>