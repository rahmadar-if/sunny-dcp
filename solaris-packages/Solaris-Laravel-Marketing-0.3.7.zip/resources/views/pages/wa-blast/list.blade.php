<x-core::page.list
    id="wa-blast"
    title="WhatsApp Blast"
    class="table-hover"
    :breadcrumbs="$breadcrumbs"
    model="WaBlast"
    package="marketing"
    path="wa-blast/list-index"
    mode="card"
    length="12"
    :card_wrapper="false"
    new="@wa-blast-modal"
    extend_columns="priority,created_by,status,total_audience,total_success,total_read"
    export folder lazy>
    
    <x-slot:table-column class="d-none">
        <x-core::table-column data="title" searchable orderable></x-table-column>
    </x-slot>

    @push('modal-content')
        @include("marketing::pages.wa-blast.modal")
    @endpush

</x-core::page.list>