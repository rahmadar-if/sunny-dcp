<x-core::modal-form
    id="wa-blast-test-wa-modal"
    title="Send Test WhatsApp"
    action="{{ route('marketing.wa-blast.send-test') }}"
    save="Send"
    size="md">

    <x-core::field id="wa-blast-test-wa-modal-phone:phone" label="Phone Number" required>
        <x-core::input
            phone
            placeholder="Enter the phone number" />
    </x-core::field>

    <x-core::field id="wa-blast-test-wa-modal-contact_id:contact_id" label="Contact">
        <x-core::lookup
            pagination
            placeholder="Choose a contact person"
            extend_search="primary_phone,primary_mobile_phone"
            source="Contact"
            link_url="/master-data/contact/{id}" />
    </x-core::field>

</x-core::modal-form>
