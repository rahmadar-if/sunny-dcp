<x-core::modal-form  
    id="wa-blast-schedule-modal" 
    title="Schedule" 
    action="{{ route('marketing.wa-blast.schedule') }}"
    size="md">

    <x-core::field id="wa-blast-schedule-modal-schedule_at:schedule_at" label="Schedule at" required>
        <x-core::date-picker
            mode="datetime"
            placeholder="Enter Schedule At" />
    </x-core::field>
</x-core::modal-form>