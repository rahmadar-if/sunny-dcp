<x-core::modal-form  
    id="wa-blast-modal" 
    title="WhatsApp Blast" 
    model="WaBlast"
    size="md">

    <x-core::field id="wa-blast-modal-title:title" label="Title" required>
        <x-core::input 
            placeholder="Enter Title"/>
    </x-core::field>

    <x-core::field id="wa-blast-modal-priority_id:priority_id" label="Priority" required>
        <x-core::lookup
            placeholder="Choose Priority"
            :options="SolarHelper::model('activity_priority')::toSelect()" />
    </x-core::field>
</x-core::modal-form>