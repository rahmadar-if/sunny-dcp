<x-core::table
    id="wa-blast-audience_list" 
    class="table-hover"
    model="WaBlastAudience"
    :new="!$disabled ? '@wa-blast-audience-modal' : false"
    delete_all :card_wrapper="false"
    extend_search="contact.primary_mobile_phone"
    filter="wa_blast_id = {{ $id }}" lazy>

    <x-slot:left-action>
        <x-core::button id="add-wa-blast-segmentation" size="sm" color="secondary" disabled>
            <span class="ri-folders-line me-1"></span>Add from segmentation
        </x-core::button>
    </x-slot:left-action>
    
    <x-slot:pre-right-action>
        <x-core::lookup
            id="audience_status_filter"
            placeholder="Choose audience status" 
            size="sm"
            multiple
            :options="SolarHelper::model('wa_blast_audience_status')::toSelect()"
            wrapper_style="width: 250px"
            :copy="false"
            disabled
            ignore />
    </x-slot:pre-right-action>

    <x-slot:column>
        <x-core::table-action-column :view="false" :edit="false" />

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="contact.name" 
            lookup="primary_phone,primary_mobile_phone,profile_picture_id" 
            searchable 
            orderable>
            Contact
        </x-core::table-column>

        <x-core::table-column 
            data="status.name" 
            searchable 
            orderable>
            Status
        </x-table-column>

        <x-core::table-column 
            data="replied" 
            orderable>
            Replied
        </x-table-column>

        <x-core::table-column 
            data="message" 
            expand>
            Message
        </x-table-column>
    </x-slot>

</x-core::table>

@push('modal-content')
    @include("marketing::pages.wa-blast.audience.modal", ["id" => $id])
    <x-marketing::audience-segmentation-modal 
        id="wa-blast-segmentation" 
        title="WhatsApp Blast Audience" 
        preview_model="Contact@availableInWaBlastAudience({{ $id }})" />
@endpush