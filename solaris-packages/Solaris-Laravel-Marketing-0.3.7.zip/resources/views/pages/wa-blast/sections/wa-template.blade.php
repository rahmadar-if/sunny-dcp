<x-core::button
    id="wa-blast-page-test-email"
    color="success"
    :disabled="empty($data->wa_template_detail)">
    <i class="ti ti-send me-1"></i>Test whatsapp
</x-core::button>

<div class="row mt-3">
    <div class="col-md-7">
        <x-core::field id="wa-blast-page-wa_template_detail_id:wa_template_detail_id" label="Template" lazy :disabled="$disabled">
            <x-core::lookup
                pagination
                source="WaTemplateDetail"
                placeholder="Choose Template"
                extend_columns="wa_template.name,language"
                extend_search="wa_template[name,template_name]"
                order_by="wa_template.name"
                :value="json_encode($data->wa_template_detail)"/>
        </x-core::field>

        <div id="wa-blast-page-template-params"
             data-params="{{ $data->template_params ?? 'null' }}"
             class="mt-3"
             style="display:none">
        </div>
    </div>

    <div class="col-md-5">
        <div class="d-flex justify-content-center">
            <x-marketing::whatsapp-preview
                id="wa-blast-page-preview"
                size="md" />
        </div>
    </div>
</div>