<div class="row">
    <div class="col-xl-3 col-md-6">
        <x-core::metric 
            id="wa-blast-page-total_audience"
            title="Total Audience"
            value="{{ $data->total_audience }}" 
            lazy />
    </div>

    <div class="col-xl-3 col-md-6">
        <x-core::metric 
            id="wa-blast-page-delivery_rate"
            title="Delivery Rate"
            value="{{ SolarNumber::readableNumber($data->delivery_rate, 1) }}%" 
            lazy />
    </div>

    <div class="col-xl-3 col-md-6">
        <x-core::metric 
            id="wa-blast-page-read_rate"
            title="Read Rate"
            value="{{ SolarNumber::readableNumber($data->read_rate, 1) }}%" 
            lazy />
    </div>

    <div class="col-xl-3 col-md-6">
        <x-core::metric 
            id="wa-blast-page-reply_rate"
            title="Reply Rate"
            value="{{ SolarNumber::readableNumber($data->reply_rate, 1) }}%" 
            lazy />
    </div>
</div>

<div class="row">
    <div class="col-xl-6 d-flex align-items-stretch">
        <x-core::card>
            <x-slot:header>
                <div class="card-title">Engagement Funnel</div>
            </x-slot:header>

            <ul class="list-unstyled top-countries-list"> 
                <li id="wa-blast-page-total_read"> 
                    <div class="d-flex justify-content-between mb-1">
                        <span class="fw-medium d-block">Read</span>
                        <div>
                            <span class="fw-medium value">{{ $data->total_read }}</span>
                            <span class="text-muted value-percent">({{ SolarNumber::readableNumber($data->read_rate, 1) }}%)</span>
                        </div>
                    </div>
                    <div class="progress progress-animate" role="progressbar" aria-valuenow="{{ $data->read_rate }}" aria-valuemin="0" aria-valuemax="100"> 
                        <div class="progress-bar progress-bar-striped progress-bar-animated bg-info" style="width: {{$data->read_rate}}%"> </div> 
                    </div>
                </li>
                
                <li id="wa-blast-page-total_reply"> 
                    <div class="d-flex justify-content-between mb-1">
                        <span class="fw-medium d-block">Reply</span>
                        <div>
                            <span class="fw-medium value">{{ $data->total_replied }}</span>
                            <span class="text-muted value-percent">({{ SolarNumber::readableNumber($data->reply_rate, 1) }}%)</span>
                        </div>
                    </div>
                    <div class="progress progress-animate" role="progressbar" aria-valuenow="{{ $data->reply_rate }}" aria-valuemin="0" aria-valuemax="100"> 
                        <div class="progress-bar progress-bar-striped progress-bar-animated bg-secondary" style="width: {{$data->click_rate}}%"> </div> 
                    </div>
                </li>

                <li>
                    <div class="d-flex justify-content-between mb-1">
                        <div class="d-flex flex-column gap-1">
                            <span class="fw-medium d-block">Open to Reply Rate</span>
                            <span class="text-muted">Percentage of recipients who opened the WhatsApp message and replied</span>
                        </div>
                        <span id="wa-blast-page-read_to_reply_rate" class="fw-medium">{{ SolarNumber::readableNumber($data->read_to_reply_rate, 1) }}%</span>
                    </div>
                </li>
            </ul>
        </x-core::card>
    </div>

    <div class="col-xl-6">
        <div class="row">
            <div class="col-md-6">
                <x-core::metric
                    variant="simple-icon" 
                    id="wa-blast-page-pending"
                    icon="ri-time-line"
                    title="Pending"
                    color="primary"
                    value="{{ $data->total_pending }}"
                    changeValue="{{ SolarNumber::readableNumber($data->total_pending_percent, 1) }}%"
                    changeTitle="Percentage" />
            </div>
    
            <div class="col-md-6">
                <x-core::metric
                    variant="simple-icon" 
                    id="wa-blast-page-progress"
                    icon="ri-progress-2-line"
                    title="In Progress"
                    color="info"
                    value="0" 
                    value="{{ $data->total_progress }}"
                    changeValue="{{ SolarNumber::readableNumber($data->total_progress_percent, 1) }}%" 
                    changeTitle="Percentage"/>
            </div>
    
            <div class="col-md-6">
                <x-core::metric
                    variant="simple-icon" 
                    id="wa-blast-page-failed"
                    icon="ri-close-circle-line"
                    color="danger"
                    title="Failed"
                    value="0" 
                    value="{{ $data->total_fail }}"
                    changeValue="{{ SolarNumber::readableNumber($data->total_fail_percent, 1) }}%"
                    changeTitle="Percentage" />
            </div>
    
            <div class="col-md-6">
                <x-core::metric
                    variant="simple-icon" 
                    id="wa-blast-page-delivered"
                    icon="ri-checkbox-circle-line"
                    title="Delivered"
                    color="success"
                    value="0" 
                    value="{{ $data->total_success }}"
                    changeValue="{{ SolarNumber::readableNumber($data->total_delivered_percent, 1) }}%"
                    changeTitle="Percentage" />
            </div>
        </div>
    </div>
</div>