<x-core::tab id="{{ $tabId }}_history_tab" class="scaleX p-0 mb-4" variant="tab-style-7">
    <x-slot:nav>
        <x-core::tab-nav id="{{ $tabId }}_history_tab_activity" active>Activity</x-core::tab-nav>
        <x-core::tab-nav id="{{ $tabId }}_history_tab_status">Status history</x-core::tab-nav>
    </x-slot>

    <x-slot:content>

        <x-core::tab-content id="{{ $tabId }}_history_tab_activity" active class="p-0 border-0">
            @include("marketing::pages.wa-blast.activity.list", ["id" => $data->id])
        </x-core::tab-content>

        <x-core::tab-content id="{{ $tabId }}_history_tab_status" class="p-0 border-0">
            @include('marketing::pages.wa-blast.status-history.list', ['id' => $data->id])
        </x-core::tab-content>

    </x-slot>
</x-core::tab>