<div class="alert svg-danger alert-danger alert-dismissible fade show custom-alert-icon shadow-sm {{ empty($data->error_message) ? 'd-none' : '' }}" role="alert"> 
    <svg xmlns="http://www.w3.org/2000/svg" height="1.5rem" viewBox="0 0 24 24" width="1.5rem" fill="#000000">
        <path d="M0 0h24v24H0z" fill="none"></path>
        <path d="M15.73 3H8.27L3 8.27v7.46L8.27 21h7.46L21 15.73V8.27L15.73 3zM12 17.3c-.72 0-1.3-.58-1.3-1.3 0-.72.58-1.3 1.3-1.3.72 0 1.3.58 1.3 1.3 0 .72-.58 1.3-1.3 1.3zm1-4.3h-2V7h2v6z"></path>
    </svg> 
    <span class="error-message">{{ $data->error_message }}</span> 
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
        <i class="bi bi-x"></i>
    </button> 
</div>

<x-core::card>
    <x-core::field id="wa-blast-page-title:title" label="Title" required :disabled="$disabled">
        <x-core::input
            placeholder="Enter Title"
            :value="$data->title"/>
    </x-core::field>

    <x-core::field id="wa-blast-page-priority_id:priority_id" label="Priority" required :disabled="$disabled">
        <x-core::lookup
            placeholder="Choose Priority"
            :options="SolarHelper::model('activity_priority')::toSelect()"
            :value="json_encode($data->priority)" />
    </x-core::field>

    <x-core::field id="wa-blast-page-sent_at:sent_at" label="Sent At" disabled>
        <x-core::date-picker
            mode="datetime"
            placeholder="Enter Sent At"
            :value="$data->sent_at?->toJSON()" />
    </x-core::field>

    <x-core::field id="wa-blast-page-schedule_at:schedule_at" label="Schedule At" disabled>
        <x-core::date-picker
            mode="datetime"
            placeholder="Enter Schedule At"
            :value="$data->schedule_at?->toJSON()" />
    </x-core::field>

    <x-core::field id="wa-blast-page-completed_at:completed_at" label="Completed At" disabled>
        <x-core::date-picker
            mode="datetime"
            placeholder="Enter Completed At"
            :value="$data->completed_at?->toJSON()" />
    </x-core::field>
</x-core::card>