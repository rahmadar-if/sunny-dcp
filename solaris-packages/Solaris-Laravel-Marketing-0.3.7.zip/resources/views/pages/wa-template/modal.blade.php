<x-core::modal-form
	id="wa-template-modal"
	title="WhatsApp Template"
	model="WaTemplate"
	size="md">

	<x-core::field id="wa-template-modal-name:name" label="Template Name" required>
		<x-core::input placeholder="e.g. Promo Lebaran 2025" />
	</x-core::field>

	<x-core::field id="wa-template-modal-category_id:category_id" label="Category" required>
		<x-core::lookup
			placeholder="Choose Category"
			:options="SolarHelper::model('wa_template_category')::toSelect()" />
	</x-core::field>

	<x-core::field id="wa-template-modal-languages:languages" label="Language" required>
		<x-core::lookup
			multiple
			placeholder="Choose Language"
			:options="SolarHelper::model('wa_template_language')::toSelect()" />
	</x-core::field>

</x-core::modal-form>
