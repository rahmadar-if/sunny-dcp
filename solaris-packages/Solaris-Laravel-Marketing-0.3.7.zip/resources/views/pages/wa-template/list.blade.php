<x-core::page.list
	id="wa-template"
	title="WhatsApp Template"
	class="table-hover"
	:breadcrumbs="$breadcrumbs"
	model="WaTemplate"
	package="marketing"
	path="wa-template/list-index"
	length="12"
	new="@wa-template-modal"
	extend_columns="template_name,details[status,language]"
	lazy>

	<x-slot:table-pre-right-action>
		<x-core::button id="wa-template-sync" size="sm">Sync Template</x-core::button>
	</x-slot>

	<x-slot:table-column>
		<x-core::table-action-column :view="false"/>
		<x-core::table-column data="name" searchable orderable>Name</x-core::table-column>
		<x-core::table-column 
			data="category.name" 
			searchable 
			orderable
			width="10%">
			Category
		</x-core::table-column>
		<x-core::table-column name="languages" searchable orderable>Language</x-core::table-column>
	</x-slot>

	@push('modal-content')
		@include("marketing::pages.wa-template.modal")
	@endpush

</x-core::page.list>
