<x-core::table
    id="wa-template-detail_list" 
    class="table-hover"
    model="WaTemplateDetail"
    delete_all
    new="@wa-template-detail-modal"
    extend_columns="wa_template.name,sub_type,language,header_type,header_content,body,footer,buttons,cards,disclaimer,expiry_minutes"
    filter="wa_template_id = {{ $id }}" lazy>
    
    <x-slot:column>
        <x-core::table-action-column :view="false" />

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="language.name"
            lookup="code"
            searchable 
            orderable>
            Language
        </x-core::table-column>

        <x-core::table-column 
            data="sub_type.name" 
            searchable 
            orderable>
            Type
        </x-table-column>

        <x-core::table-column 
            data="status.name" 
            searchable 
            orderable>
            Status
        </x-table-column>

        <x-core::table-column data="reject_reason">Reject Reason</x-table-column>
    </x-slot>

</x-core::table>

@push('modal-content')
    @include("marketing::pages.wa-template.detail.modal", ["id" => $id, "category_id" => $category_id])
@endpush