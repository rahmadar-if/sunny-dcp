<x-core::page.edit
	:id="$data->id"
	title="WhatsApp Template"
	:breadcrumbs="$breadcrumbs"
	model="WaTemplateDetail"
	package="marketing"
	path="wa-template/detail/page-index"
	profile-position="left">

	@push('styles')
		@vite([SolarAsset::css('pages/wa-template/detail.page.scss', 'marketing')])
	@endpush

	@push('scripts')
		<script>
			const WaTemplateLimits = {!! Js::from($waTemplateConfig) !!};
		</script>
	@endpush

	@php
		$disabled = $data->status_id != \Solaris\Marketing\Const\WaTemplateStatusConst::Draft;
	@endphp

	<input type="hidden" id="wa-template-page-disabled" value="{{ $disabled ? '1' : '0' }}">

	<x-slot:profile>
		<div class="d-flex justify-content-center">
			<x-marketing::whatsapp-preview
				id="wa-template-page-preview"
				size="md"
				scale="0.85" />
		</div>
	</x-slot>

	@include('marketing::pages.wa-template.detail.partials.main', ['data' => $data, 'disabled' => $disabled])
	
	<x-slot:footer>
		<x-core::card>
			@php $tabId = "wa-template-page-tabs"; @endphp
		
			<x-core::tab id="{{ $tabId }}" class="p-0">
				<x-slot:nav>
					<x-core::tab-nav id="{{ $tabId }}_message_content" active>Content</x-core::tab-nav>
					<x-core::tab-nav id="{{ $tabId }}_message_carousel" class="{{ $data->sub_type_id != \Solaris\Marketing\Const\WaTemplateSubTypeConst::Carousel ? 'd-none' : '' }}">Carousel</x-core::tab-nav>
					<x-core::tab-nav id="{{ $tabId }}_message_buttons">Buttons</x-core::tab-nav>
				</x-slot>
		
				<x-slot:content>
		
					<x-core::tab-content id="{{ $tabId }}_message_content" active class="mt-4 p-0 border-0">
						@include('marketing::pages.wa-template.detail.partials.content', ['data' => $data, 'disabled' => $disabled])
						@include('marketing::pages.wa-template.detail.partials.authentication', ['data' => $data, 'disabled' => $disabled])
					</x-core::tab-content>
		
					<x-core::tab-content id="{{ $tabId }}_message_carousel" class="mt-4 p-0 border-0">
						@include('marketing::pages.wa-template.detail.partials.carousel', ['data' => $data, 'disabled' => $disabled])
					</x-core::tab-content>
		
					<x-core::tab-content id="{{ $tabId }}_message_buttons" class="mt-4 p-0 border-0">
						@include('marketing::pages.wa-template.detail.partials.buttons', ['data' => $data, 'disabled' => $disabled])
					</x-core::tab-content>
		
				</x-slot>
			</x-core::tab>
		</x-core::card>
	</x-slot:footer>

</x-core::page.edit>