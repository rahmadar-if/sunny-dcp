<x-core::modal-form
	id="wa-template-detail-modal"
	title="WhatsApp Template"
	model="WaTemplateDetail"
	size="md">

	<x-core::input 
		type="hidden" 
		id="wa-template-detail-modal_category_id:category_id"
		:value="$category_id" />

	<x-core::field id="wa-template-detail-modal_language_id:language_id" label="Language" required>
		<x-core::lookup
			placeholder="Choose Language"
			source="WaTemplateLanguage@availableInWaTemplateDetail({{ $id }})"
			:options="SolarHelper::model('wa_template_language')::toSelect()" />
	</x-core::field>

	<x-core::field id="wa-template-detail-modal-sub_type_id:sub_type_id" label="Template Type" required>
		<x-core::lookup
			placeholder="Choose Template Type"
			:options="SolarHelper::model('wa_template_sub_type')::toSelect()" />
	</x-core::field>

</x-core::modal-form>