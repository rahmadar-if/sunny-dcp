@php
	$isHide 	= $data->wa_template->category_id == \Solaris\Marketing\Const\WaTemplateCategoryConst::Authentication;
	$isCarousel = $data->sub_type_id == \Solaris\Marketing\Const\WaTemplateSubTypeConst::Carousel;
@endphp

{{-- Header --}}
<div id="wa-template-header-section" class="{{ $isHide || $isCarousel ? 'd-none' : '' }}">
	<x-core::field id="wa-template-page-header_type:header_type_id" label="Header Type" :disabled="$disabled">
		<x-core::lookup
			placeholder="No Header"
			:options="SolarHelper::model('wa_template_header_type')::toSelect()"
			:value="json_encode($data->header_type)" />
	</x-core::field>

	<div id="wa-template-header-content-wrap">
		<x-core::field
			id="wa-template-page-header_content:header_content"
			label="Header Content"
			:disabled="$disabled"
			:hidden="is_null($data->header_type_id) || ($data->header_type_id && $data->header_type_id != \Solaris\Marketing\Const\WaTemplateHeaderTypeConst::Text)">
			<x-core::input
				class="d-none"
				:value="$data->header_content ?? ''"
				placeholder="Header text..." />
			<div id="wa-template-header-content-editor"
				class="form-control wa-header-editor"
				contenteditable="true"
				data-placeholder="Header text..."></div>
		</x-core::field>

		<div id="wa-template-header-var-wrap" class="{{ $data->header_type_id === \Solaris\Marketing\Const\WaTemplateHeaderTypeConst::Text ? '' : 'd-none' }} mb-3">
			<div class="d-flex justify-content-between align-items-center">
				<button type="button" class="btn btn-sm btn-outline-secondary">@{{ }} Parameter</button>
				<small class="text-muted" id="wa-template-header-count">{{ strlen($data->header_content ?? '') }} / 60</small>
			</div>
		</div>

		@php
			$isHeaderMediaHidden = !($data->header_type_id && $data->header_type_id !== \Solaris\Marketing\Const\WaTemplateHeaderTypeConst::Text);
		@endphp

		<div id="wa-template-header-media-wrap" class="{{ $isHeaderMediaHidden ? 'd-none' : '' }} mb-3">
			<x-core::radio-group
				name="wa-header-media-mode:media_mode"
				wrap:class="mb-3"
				inline
				:disabled="$disabled"
				:options="[
					['label' => 'URL', 'value' => 'url', 'checked' => true],
					['label' => 'Upload', 'value' => 'upload'],
				]" />

			<x-core::input
				id="wa-header-media-url-input:header_content_url"
				placeholder="Paste a public media URL..."
				value="{{ $data->header_content ?? '' }}"
				:hidden="$isHeaderMediaHidden"
				:disabled="$disabled" />

			<x-core::dropzone
				id="wa-header-media-dropzone"
				class="d-none"
				:multiple="false"
				:auto="false" />
		</div>
	</div>

	<hr class="my-4">
</div>

{{-- Body --}}
<div id="wa-template-body-section" class="{{ $isHide ? 'd-none' : '' }}">
	<x-core::field id="wa-template-page-body:body" label="Body" required :disabled="$disabled">
		<div class="border rounded">
			<div class="d-flex gap-1 p-2 border-bottom bg-light rounded-top">
				<button type="button" class="btn btn-sm btn-outline-secondary" data-wa-format="bold" title="Bold"><b>B</b></button>
				<button type="button" class="btn btn-sm btn-outline-secondary" data-wa-format="italic" title="Italic"><em>I</em></button>
				<button type="button" class="btn btn-sm btn-outline-secondary" data-wa-format="strikethrough" title="Strikethrough"><s>S</s></button>
				<button type="button" class="btn btn-sm btn-outline-secondary" data-wa-format="code" title="Monospace"><></button>
				<button type="button" class="btn btn-sm btn-outline-secondary" id="wa-template-body-param-btn" title="Parameter">@{{ }} Parameter</button>
				<button type="button" class="btn btn-sm btn-icon btn-outline-secondary rounded-pill"
					data-bs-toggle="popover"
					data-bs-placement="top"
					data-bs-html="true"
					data-bs-content="<b>Keyboard Shortcuts</b><br><code>Ctrl+B</code> Bold<br><code>Ctrl+I</code> Italic<br><code>Ctrl+Shift+X</code> Strikethrough<br><code>Ctrl+Shift+M</code> Monospace<br><code>Ctrl+Shift+P</code> Parameter">
					<i class="ri-information-line"></i>
				</button>
			</div>
			<x-core::textarea
				class="d-none"
				rows="5"
				placeholder="Type your message here..."
				value="{{ $data->body ?? '' }}" />
			<div id="wa-template-body-content-editor"
				class="form-control border-0 rounded-0 rounded-bottom wa-body-editor"
				contenteditable="true"
				data-placeholder="Type your message here..."></div>
		</div>
	</x-core::field>

	<x-core::input hidden
		id="wa-template-page-header_examples:header_examples"
		:value="$data->header_examples" />
	<x-core::input hidden
		id="wa-template-page-body_examples:body_examples"
		:value="$data->body_examples" />

	<div class="d-flex justify-content-end mt-1 mb-3">
		<small class="text-muted" id="wa-template-body-count">{{ strlen($data->body ?? '') }} / 1024</small>
	</div>

	<hr class="my-4">
</div>

{{-- Footer --}}
<div id="wa-template-footer-section" class="{{ $isHide || $isCarousel ? 'd-none' : '' }}">
	<x-core::field id="wa-template-page-footer:footer" label="Footer" :disabled="$disabled">
		<x-core::input :value="$data->footer ?? ''" placeholder="Footer text..." maxlength="60" />
	</x-core::field>

	<div class="d-flex justify-content-end mt-n2 mb-2">
		<small class="text-muted" id="wa-template-footer-count">{{ strlen($data->footer ?? '') }} / 60</small>
	</div>
</div>