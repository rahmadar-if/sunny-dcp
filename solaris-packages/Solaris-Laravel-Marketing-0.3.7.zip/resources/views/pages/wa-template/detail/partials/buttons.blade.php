<x-core::button id="wa-template-add-button" size="sm" variant="outline" class="mb-3" :disabled="$disabled">
	<i class="ri-add-line me-1"></i>Add Button
</x-core::button>

<div id="wa-template-auth-button-info" class="mb-3{{ $data->wa_template->category_id !== \Solaris\Marketing\Const\WaTemplateCategoryConst::Authentication ? ' d-none' : '' }}">
	<div class="card">
		<div class="card-body">
			<div class="d-flex align-items-center gap-2 text-muted">
				<i class="ri-lock-line"></i>
				<span class="fw-semibold text-body">Copy Code</span>
				<span class="badge bg-secondary">OTP</span>
				<small>Auto-added for Authentication templates</small>
			</div>
		</div>
	</div>
</div>

<div id="wa-template-buttons-container"></div>

<x-core::input type="hidden" id="wa-template-page-buttons:buttons" :value="$data->buttons" />
