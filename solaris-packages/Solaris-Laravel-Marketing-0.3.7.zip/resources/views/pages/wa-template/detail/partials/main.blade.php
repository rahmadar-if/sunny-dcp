<div class="row">
	<div class="col-6">
		<x-core::field id="wa-template-page-name:name" label="Name" disabled>
			<x-core::input
				placeholder="e.g. Promo Lebaran 2025"
				:value="$data->wa_template->name" />
		</x-core::field>

		<x-core::field id="wa-template-page-language:language_id" label="Language" disabled>
			<x-core::lookup
				placeholder="Choose Language"
				:options="SolarHelper::model('wa_template_language')::toSelect()"
				:value="json_encode($data->language)" />
		</x-core::field>
	</div>
	<div class="col-6">
		<x-core::field id="wa-template-page-status:status_id" label="Status" disabled>
			<x-core::input :value="$data->status->name" />
		</x-core::field>

		<x-core::input 
			type="hidden" 
			id="wa-template-page-category:category_id" 
			:value="$data->wa_template->category_id" />

		<x-core::field
			id="wa-template-page-sub_type:sub_type_id"
			label="Template Type"
			:disabled="!$disabled ? $data->wa_template->category_id !== Solaris\Marketing\Const\WaTemplateCategoryConst::Marketing : $disabled">
			<x-core::lookup
				:options="SolarHelper::model('wa_template_sub_type')::toSelect()"
				:value="json_encode($data->sub_type)" />
		</x-core::field>
	</div>
</div>
