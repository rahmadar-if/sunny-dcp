@php
	$isHide = $data->wa_template->category_id != \Solaris\Marketing\Const\WaTemplateCategoryConst::Authentication;
@endphp

{{-- Auth Body Preview --}}
<div id="wa-template-auth-body-preview" class="{{ $isHide ? 'd-none' : '' }} mb-3">
	<label class="form-label fw-semibold">Body</label>
	<div class="border rounded p-3 bg-light" id="wa-template-auth-body-text"></div>
	<small class="text-muted d-block mt-1">This body template is determined by Meta and cannot be changed.</small>
</div>

{{-- Auth Footer --}}
<div id="wa-template-auth-footer-wrap" class="{{ $isHide ? 'd-none' : '' }}">
	<x-core::field id="wa-template-disclaimer:disclaimer" label="Security Recommendation" :disabled="$disabled">
		<x-core::checkbox label="Add security recommendation" switch :checked="$data->disclaimer" />
	</x-core::field>

	<x-core::field id="wa-template-expiry-input:expiry_minutes" label="Code expires in minutes" :disabled="$disabled">
		<x-core::input number value="{{ $data->expiry_minutes ?? '' }}" placeholder="-" />
	</x-core::field>
</div>
