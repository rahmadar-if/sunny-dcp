@php
	use Solaris\Marketing\Const\WaTemplateHeaderTypeConst;
	$isVideo = $data->header_type_id === WaTemplateHeaderTypeConst::Video;
@endphp

<x-core::field id="wa-carousel-media-type" label="Card Media Type">
	<x-core::radio-group
		inline
		name="wa-carousel-media-type"
		:disabled="$disabled"
		:options="[
			['label' => 'Image', 'value' => WaTemplateHeaderTypeConst::Image, 'checked' => !$isVideo],
			['label' => 'Video', 'value' => WaTemplateHeaderTypeConst::Video, 'checked' => $isVideo],
		]" />
</x-core::field>

<x-core::button id="wa-carousel-add-card" size="sm" variant="outline" class="mb-3" :disabled="$disabled">
	<i class="ri-add-line me-1"></i>Add Card
</x-core::button>

<div id="wa-carousel-cards-container" class="wa-carousel-cards-container"></div>

<x-core::input id="wa-template-page-cards:cards" hidden :value="$data->cards" />
