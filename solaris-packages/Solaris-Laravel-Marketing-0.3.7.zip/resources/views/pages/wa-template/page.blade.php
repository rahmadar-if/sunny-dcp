<x-core::page.edit
	:id="$data->id"
	title="WhatsApp Template"
	:breadcrumbs="$breadcrumbs"
	model="WaTemplate"
	package="marketing"
	path="wa-template/page-index"
	profile-position="left">

	@php
		$isCanSubmit = $data->details->every(fn($item) => $item->status_id == \Solaris\Marketing\Const\WaTemplateStatusConst::Draft);
		$isCanSync 	 = $data->details->contains(fn($item) => $item->status_id == \Solaris\Marketing\Const\WaTemplateStatusConst::Pending);
	@endphp

	<x-slot:pre-buttons>
		<x-core::button 
			id="wa-template-page-submit" 
			color="success"
			:disabled="!$isCanSubmit">
			<i class="ri-whatsapp-line me-2"></i>Submit to Meta
		</x-core::button>
		<x-core::button 
			id="wa-template-page-sync" 
			color="info"
			:disabled="!$isCanSync">
			<i class="ri-refresh-line me-2"></i>Sync
		</x-core::button>
	</x-slot>

	<x-slot:profile>
		<div class="d-flex justify-content-center">
			<x-marketing::whatsapp-preview
				id="wa-template-page-preview"
				size="md"
				scale="0.85" />
		</div>
	</x-slot>

	<div class="row">
		<div class="col-6">
			<x-core::field id="wa-template-page-template_name:template_name" label="WA Template ID" disabled>
				<x-core::input :value="$data->template_name" placeholder="WA Template ID" />
			</x-core::field>
		</div>
	</div>
	<div class="row">
		<div class="col-6">
			<x-core::field id="wa-template-page-name:name" label="Template Name" required>
				<x-core::input
					placeholder="e.g. Promo Lebaran 2025"
					:value="$data->name" />
			</x-core::field>
		</div>
		<div class="col-6">
			<x-core::field id="wa-template-page-category:category_id" label="Category" disabled>
				<x-core::lookup
					placeholder="Choose Category"
					:options="SolarHelper::model('wa_template_category')::toSelect()"
					:value="json_encode($data->category)" />
			</x-core::field>
		</div>
	</div>

	<x-slot:footer>
		@include('marketing::pages.wa-template.detail.list', ['id' => $data->id, 'category_id' => $data->category_id])
	</x-slot>

</x-core::page.edit>
