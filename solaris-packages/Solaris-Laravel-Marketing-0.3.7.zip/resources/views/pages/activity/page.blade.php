<x-core::page.edit
	:id="$data->id"
	title="Activity"
	:breadcrumbs="$breadcrumbs"
	model="Activity"
	package="marketing"
	path="activity/page-index"
	profile-position="left">

	<x-slot:profile>
		@include('master-data::pages.activity.sections.profile-container', ["data" => $data])

		<x-core::card>
			<x-core::field id="activity-page-lead_id:lead_id" label="Lead" lazy>
				<x-core::lookup
					extend_columns="date,account.primary_contact,contact.account,status"
					placeholder="Choose lead"
					source="Lead"
					:value="json_encode($data->lead)"
					link_url="/marketing/lead/{id}"
				/>
			</x-core::field>

			{{-- MARKETING UPDATE --}}
			<x-core::field id="activity-page-email_blast_id:email_blast_id" label="Email Blast">
				<x-core::lookup
					placeholder="Choose email blast campaign"
					source="EmailBlast"
					:value="json_encode($data->email_blast)"
					link_url="/marketing/email-blast/{id}"
				/>
			</x-core::field>

			<x-core::field id="activity-page-wa_blast_id:wa_blast_id" label="WA Blast">
				<x-core::lookup
					placeholder="Choose whatsapp blast campaign"
					source="WaBlast"
					:value="json_encode($data->wa_blast)"
					link_url="/marketing/wa-blast/{id}"
				/>
			</x-core::field>

			<x-core::field id="activity-page-event_id:event_id" label="Event">
				<x-core::lookup
					placeholder="Choose event"
					source="Event"
					:value="json_encode($data->event)"
					link_url="/marketing/event/{id}"
				/>
			</x-core::field>
			{{-- END MARKETING UPDATE --}}
		</x-core::card>

		@include('master-data::pages.activity.sections.reminder', ["data" => $data])
	</x-slot>

	@php $tabId = "activity-page-tabs"; @endphp

	{{-- MARKETING UPDATE --}}
	<x-core::tab id="{{ $tabId }}" class="p-0 mb-4">
		<x-slot:nav>
			<x-core::tab-nav id="{{ $tabId }}_info" active>Info</x-core::tab-nav>
			<x-core::tab-nav id="{{ $tabId }}_notes_files">Notes & Files</x-core::tab-nav>
		</x-slot>

		<x-slot:content>
			@include('base-crm::pages.activity.sections.info', ['data' => $data, 'active' => true])
			@include('master-data::pages.activity.sections.notes-files', ['data' => $data, 'active' => false])
		</x-slot>
	</x-core::tab>
	{{-- END MARKETING UPDATE --}}

</x-core::page.edit>
