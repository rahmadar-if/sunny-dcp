@props([
	'id',
	'type'           => 'iphone',
	'device'         => null,
	'size'           => 'md',
	'scale'          => null,
	'contact_name'   => 'Solaris Marketing',
	'contact_status' => 'online',
	'ignore'         => false,
	'color'          => null,
	'messages'       => [],
])

@php
	$notch    = $type === 'android' ? 'punch-hole' : 'dynamic-island';
	$initials = collect(explode(' ', $contact_name))
		->take(2)
		->map(fn($w) => strtoupper(substr($w, 0, 1)))
		->implode('');

	$now = now()->format('H:i');

	$iconMap = [
		'pdf'  => 'bi-file-earmark-pdf-fill',
		'doc'  => 'bi-file-earmark-word-fill',
		'docx' => 'bi-file-earmark-word-fill',
		'xls'  => 'bi-file-earmark-excel-fill',
		'xlsx' => 'bi-file-earmark-excel-fill',
		'ppt'  => 'bi-file-earmark-ppt-fill',
		'pptx' => 'bi-file-earmark-ppt-fill',
		'zip'  => 'bi-file-earmark-zip-fill',
		'mp4'  => 'bi-file-earmark-play-fill',
		'mp3'  => 'bi-file-earmark-music-fill',
	];

	$btnIconMap = [
		'url'               => 'bi-box-arrow-up-right',
		'phone_number'      => 'bi-telephone-fill',
		'copy_code'         => 'bi-clipboard',
		'quick_reply'       => '',
		'one_tap'           => 'bi-lightning-charge-fill',
		'marketing_opt_out' => 'bi-bell-slash',
	];
@endphp

<x-core::phone-preview
	:id="$id . '_phone'"
	:type="$type"
	:notch="$notch"
	:size="$size"
	:scale="$scale"
	:device="$device"
	:color="$color"
	:ignore="$ignore"
>
	<div
		solar-ui="whatsapp-preview"
		id="{{ $id }}"
		class="wa-preview-container"
	>
		<div class="wa-preview-header">
			<i class="bi bi-arrow-left"></i>
			<div class="wa-preview-avatar">{{ $initials }}</div>
			<div class="wa-preview-contact-info">
				<span class="wa-preview-name">{{ $contact_name }}</span>
				<span class="wa-preview-status">{{ $contact_status }}</span>
			</div>
			<div class="wa-preview-actions">
				<i class="bi bi-camera-video"></i>
				<i class="bi bi-telephone"></i>
				<i class="bi bi-three-dots-vertical"></i>
			</div>
		</div>

		<div class="wa-preview-chat">
			<div class="wa-preview-date-chip">Today</div>

			@foreach ($messages as $msg)
				@php
					$msgType = $msg['type']         ?? 'incoming';
					$msgTime = $msg['time']         ?? $now;
					$status  = $msg['status']       ?? 'delivered';
					$msgKind = $msg['message_type'] ?? 'text';
				@endphp

				@if ($msgKind === 'carousel')
					<div class="wa-preview-carousel-wrapper {{ $msgType }}"{{ !empty($msg['id']) ? ' data-wa-id="' . $msg['id'] . '"' : '' }}>
						@if (!empty($msg['text']))
							<div class="wa-preview-bubble-text wa-preview-carousel-body-text">{{ $msg['text'] }}</div>
						@endif
						<div class="wa-preview-carousel">
							@foreach ($msg['cards'] ?? [] as $card)
								@php
									$cardMediaType = $card['media_type'] ?? 'image';
								@endphp
								<div class="wa-preview-carousel-card"{{ !empty($card['id']) ? ' data-wa-id="' . $card['id'] . '"' : '' }}>
									@if (!empty($card['src']))
										@if ($cardMediaType === 'video')
											<div class="wa-preview-video-thumb">
												<img src="{{ $card['src'] }}" alt="">
												<i class="bi bi-play-circle-fill wa-preview-video-play"></i>
											</div>
										@else
											<img class="wa-preview-carousel-img" src="{{ $card['src'] }}" alt="">
										@endif
									@endif
									<div class="wa-preview-carousel-body">
										@if (!empty($card['body']))
											<div class="wa-preview-carousel-title">{{ $card['body'] }}</div>
										@endif
										@if (!empty($card['subtitle']))
											<div class="wa-preview-carousel-subtitle">{{ $card['subtitle'] }}</div>
										@endif
										@if (!empty($card['buttons']))
											@foreach ($card['buttons'] as $btn)
												@php $btnIcon = $btnIconMap[$btn['type'] ?? ''] ?? '' @endphp
												<div class="wa-preview-btn">
													@if ($btnIcon)<i class="bi {{ $btnIcon }}"></i>@endif
													{{ $btn['label'] ?? '' }}
												</div>
											@endforeach
										@endif
									</div>
								</div>
							@endforeach
						</div>
						<div class="wa-preview-bubble-time">
							{{ $msgTime }}
							@if ($msgType === 'outgoing')
								@if ($status === 'read')
									<i class="bi bi-check2-all wa-check-read"></i>
								@elseif ($status === 'delivered')
									<i class="bi bi-check2-all"></i>
								@else
									<i class="bi bi-check2"></i>
								@endif
							@endif
						</div>
					</div>
				@else
					<div class="wa-preview-bubble {{ $msgType }}"{{ !empty($msg['id']) ? ' data-wa-id="' . $msg['id'] . '"' : '' }}>
						@if ($msgKind === 'text')
							<div class="wa-preview-bubble-text">{{ $msg['text'] ?? '' }}</div>

						@elseif ($msgKind === 'image')
							<img class="wa-preview-media-image" src="{{ $msg['src'] ?? '' }}" alt="">
							@if (!empty($msg['caption']))
								<div class="wa-preview-bubble-text wa-preview-media-caption">{{ $msg['caption'] }}</div>
							@endif

						@elseif ($msgKind === 'file')
							@php
								$filename = $msg['filename'] ?? 'document';
								$filetype = $msg['filetype'] ?? '';
								$filesize = $msg['filesize'] ?? '';
								$ext      = $filetype ?: strtolower(pathinfo($filename, PATHINFO_EXTENSION));
								$fileIcon = $iconMap[$ext] ?? 'bi-file-earmark-text-fill';
							@endphp
							<div class="wa-preview-file">
								<i class="bi {{ $fileIcon }} wa-preview-file-icon"></i>
								<div class="wa-preview-file-info">
									<span class="wa-preview-file-name">{{ $filename }}</span>
									@if ($filesize)
										<span class="wa-preview-file-meta">{{ $filesize }}{{ $ext ? ' · ' . strtoupper($ext) : '' }}</span>
									@endif
								</div>
							</div>
							@if (!empty($msg['caption']))
								<div class="wa-preview-bubble-text wa-preview-media-caption">{{ $msg['caption'] }}</div>
							@endif

						@elseif ($msgKind === 'template')
							@if (!empty($msg['header']))
								@php $header = $msg['header'] @endphp
								@if ($header['type'] === 'text')
									<div class="wa-preview-bubble-header-text">{{ $header['value'] ?? '' }}</div>
								@elseif ($header['type'] === 'image')
									<img class="wa-preview-media-image" src="{{ $header['value'] ?? '' }}" alt="">
								@elseif ($header['type'] === 'video')
									<div class="wa-preview-video-thumb">
										@if (!empty($header['value']))<img src="{{ $header['value'] }}" alt="">@endif
										<i class="bi bi-play-circle-fill wa-preview-video-play"></i>
									</div>
								@elseif ($header['type'] === 'document')
									@php
										$docName = $header['value'] ?? 'document';
										$docExt  = strtolower(pathinfo($docName, PATHINFO_EXTENSION));
										$docIcon = $iconMap[$docExt] ?? 'bi-file-earmark-text-fill';
									@endphp
									<div class="wa-preview-file">
										<i class="bi {{ $docIcon }} wa-preview-file-icon"></i>
										<div class="wa-preview-file-info">
											<span class="wa-preview-file-name">{{ $docName }}</span>
										</div>
									</div>
								@endif
							@endif
							<div class="wa-preview-bubble-text">{{ $msg['text'] ?? '' }}</div>
							@if (!empty($msg['otp_code']))
								<div class="wa-preview-otp-code">{{ $msg['otp_code'] }}</div>
							@endif
							@if (!empty($msg['disclaimer']))
								<div class="wa-preview-bubble-footer">For your security, do not share this code.</div>
							@endif
							@if (!empty($msg['expiry_minutes']))
								<div class="wa-preview-bubble-footer">This code expires in {{ $msg['expiry_minutes'] }} minutes.</div>
							@endif
							@if (!empty($msg['footer']))
								<div class="wa-preview-bubble-footer">{{ $msg['footer'] }}</div>
							@endif
						@endif

						<div class="wa-preview-bubble-time">
							{{ $msgTime }}
							@if ($msgType === 'outgoing')
								@if ($status === 'read')
									<i class="bi bi-check2-all wa-check-read"></i>
								@elseif ($status === 'delivered')
									<i class="bi bi-check2-all"></i>
								@else
									<i class="bi bi-check2"></i>
								@endif
							@endif
						</div>

						@if ($msgKind === 'template' && !empty($msg['buttons']))
							<div class="wa-preview-buttons">
								@foreach ($msg['buttons'] as $btn)
									@php $btnIcon = $btnIconMap[$btn['type'] ?? ''] ?? '' @endphp
									<div class="wa-preview-btn">
										@if ($btnIcon)<i class="bi {{ $btnIcon }}"></i>@endif
										{{ $btn['label'] ?? '' }}
									</div>
								@endforeach
							</div>
						@endif
					</div>
				@endif
			@endforeach
		</div>

		<div class="wa-preview-inputbar">
			<div class="wa-preview-input-field">
				<i class="bi bi-emoji-smile wa-input-icon-left"></i>
				<span class="wa-input-placeholder">Message</span>
				<i class="bi bi-paperclip wa-input-icon-right"></i>
				<i class="bi bi-camera-fill wa-input-icon-right"></i>
			</div>
			<div class="wa-preview-mic">
				<i class="bi bi-mic-fill"></i>
			</div>
		</div>
	</div>
</x-core::phone-preview>
