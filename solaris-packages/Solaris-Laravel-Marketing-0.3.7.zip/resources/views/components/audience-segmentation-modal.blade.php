@props([
    'id',
    'title',
    'preview_model' => 'Contact'
])

<x-core::modal 
    id="{{ $id }}-modal" 
    body:class="p-3 p-lg-4"
    center 
    static 
    size="xl">

    <x-slot:header class="border-0">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </x-slot::slot>

    <div class="text-center mb-3">
        <h4 class="mb-2">{{ $title }}</h4>
    </div>

    <div class="p-lg-4 p-2">
        <div class="row">
            <div class="col-6">
                <x-core::table 
                    id="{{ $id }}-list" 
                    model="Folder@list(contact)"
                    :folder="false"
                    :select_all="false"
                    :new="false"
                    vertical="350"
                    extend_columns="created_by.name" lazy>

                    <x-slot:left-action>
                        <h6 class="mb-0">Segmentation</h6>
                    </x-slot:left-action>

                    <x-slot:column class="d-none">
                        <x-core::table-column data="name" searchable>Name</x-core::table-column>
                        <x-core::table-column cell_class="d-none" data="description" searchable>Description</x-core::table-column>
                    </x-slot>

                </x-core::table>
            </div>

            <div class="col-6">
                <x-core::table 
                    id="{{ $id }}-list-preview" 
                    :model="$preview_model"
                    :folder="false"
                    :select_all="false"
                    :new="false"
                    vertical="350"
                    extend_columns="profile_picture_id" lazy>

                    <x-slot:left-action>
                        <h6 class="mb-0">Preview</h6>
                    </x-slot:left-action>

                    <x-slot:column class="d-none">
                        <x-core::table-column 
                            data="name" 
                            searchable 
                            orderable>
                            Contact
                        </x-core::table-column>
                        
                        <x-core::table-column 
                            data="primary_mobile_phone" 
                            searchable 
                            orderable>
                            Mobile phone
                        </x-core::table-column>
                        
                        <x-core::table-column 
                            data="email" 
                            searchable 
                            orderable>
                            Email
                        </x-core::table-column>
                    </x-slot>

                </x-core::table>
            </div>
        </div>

        <div class="hstack gap-2 justify-content-center mt-4">
            <x-core::button data-bs-dismiss="modal" color="light" aria-label="Close">Cancel</x-core::button>
        </div>
    </div>
</x-core::modal>