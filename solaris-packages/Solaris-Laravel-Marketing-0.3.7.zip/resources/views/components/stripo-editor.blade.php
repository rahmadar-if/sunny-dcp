@props([
    "id",
    "logo"     => Vite::asset(SolarHelper::config('application.assets.logo.header.icon')),
    "logo_url" => route('home'),
    "ignore"   => false
])

@push('styles')
    <style>
        .stripo-header {
            max-width: 100%;
            height: 4.25rem;
            z-index: 100;
            inset-block-start: 0;
            inset-inline: 0;
            background: var(--header-bg);
            transition: all 0.1s ease;

            padding: calc(calc(5 * 1px) * 3);
        }

        @media (min-width: 992px) {
            .stripo-header {
                padding-inline-start: 0;
            }
        }

        header.stripo-header a {
            padding: 0 calc(calc(calc(5 * 1px) * 4) + calc(5 * 1px));
        }
        
        header.stripo-header a img {
            height: 2rem;
        }

        /* Baseline for every breakpoint: without it the wrapper collapses to zero height below
           992px, because h-100 resolves against an auto-height parent. */
        .stripo-content {
            display: flex;
            flex-direction: column;
            min-height: calc(100vh - 4.25rem);
        }

        @media (min-width: 992px) {
            .stripo-content {
                min-height: calc(100vh - 8rem);
                margin-block-end: 0;
                margin-block-start: 0;
                margin-inline-start: 0;
                transition: all 0.05s ease;
            }
        }

        .stripo-editor-content {
            height: 100%;
            width: 100%;
            max-width: 100dvw;
            overflow-x: auto;
            overflow-y: hidden;
            flex: 1;
            background-color: var(--default-body-bg-color);;
        }

        .monitor-frame {
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 100%;
        }

        .monitor-bezel {
            width: 100%;
            background: #1e1e2e;
            border-radius: 12px 12px 0 0;
            padding: 20px 20px 14px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.35);
        }

        .monitor-screen {
            display: block;
            width: 100%;
            height: 520px;
            border-radius: 4px;
            background: #fff;
        }

        .monitor-neck {
            width: 60px;
            height: 24px;
            background: linear-gradient(to bottom, #1e1e2e, #2d2d4e);
        }

        .monitor-base {
            width: 180px;
            height: 14px;
            background: #1e1e2e;
            border-radius: 0 0 10px 10px;
        }
    </style>
@endpush

<div {{ $attributes->merge([
        "id"       => $id,
        "solar-ui" => "stripo-editor",
        "ignore"   => $ignore
    ])->class(["d-none"]) }}>
    <header class="stripo-header sticky">
        <div class="d-flex align-items-center h-100">
            <a href="{{ $logo_url }}">
                <img src="{{ $logo }}" alt="logo">
            </a>

            <div class="d-flex align-items-center justify-content-between flex-fill">
                <div class="d-flex align-items-center gap-2">
                    <x-core::button id="{{ $id }}_back" size="sm" icon title="Back" disabled ignore>
                        <i class="ri-arrow-left-line"></i>
                    </x-core::button>

                    @if (isset($preLeftAction))
                        {{ $preLeftAction }}
                    @endif

                    <x-core::button id="{{ $id }}_save" size="sm" icon title="Save" disabled ignore>
                        <i class="ri-save-line"></i>
                    </x-core::button>

                    @if (isset($leftAction))
                        {{ $leftAction }}
                    @endif
                </div>
                
                <div class="d-flex align-items-center gap-2">
                    @if (isset($preMiddleAction))
                        {{ $preMiddleAction }}
                    @endif

                    <div class="btn-group btn-group-sm" role="group"> 
                        <input type="radio" class="btn-check" name="mode" id="{{ $id }}_desktop_mode" checked disabled>
                        <label class="btn btn-outline-primary" for="{{ $id }}_desktop_mode" title="Desktop view mode"><i class="ri-computer-line"></i></label>
                        
                        <input type="radio" class="btn-check" name="mode" id="{{ $id }}_mobile_mode" disabled>
                        <label class="btn btn-outline-primary" for="{{ $id }}_mobile_mode" title="Mobile view mode"><i class="ri-smartphone-line"></i></label>
                    </div>

                    <x-core::button id="{{ $id }}_test_email" size="sm" class="w-100" disabled ignore>
                        <i class="ri-mail-send-line"></i> Test email
                    </x-core::button>

                    @if (isset($middleAction))
                        {{ $middleAction }}
                    @endif
                </div>

                <div class="d-flex align-items-center gap-2">
                    @if (isset($preRightAction))
                        {{ $preRightAction }}
                    @endif

                    <x-core::button id="{{ $id }}_code" size="sm" icon title="Code editor" disabled ignore>
                        <i class="ri-code-s-slash-line"></i>
                    </x-core::button>

                    <x-core::button id="{{ $id }}_preview" size="sm" disabled ignore>
                        <i class="ri-eye-line me-1"></i> Preview
                    </x-core::button>

                    @if (isset($rightAction))
                        {{ $rightAction }}
                    @endif
                </div>
            </div>
        </div>
    </header>

    <div class="stripo-content h-100">
        <div class="stripo-editor-content"></div>
    </div>
</div>

@push('modal-content')
{{-- Test Email Modal --}}
<x-core::modal-form
    id="{{ $id }}_test-email-modal"
    title="Send Test Email"
    action="{{ route('marketing.stripo.test-email') }}"
    save="Send"
    size="md"
    ignore>

    <x-core::field id="{{ $id }}_test-email-modal-contact_id:contact_id" label="Contact">
        <x-core::lookup placeholder="Choose contact to render merge tags" source="Contact" />
    </x-core::field>

    <x-core::field id="{{ $id }}_test-email-modal-email:email" label="Email Address" required>
        <x-core::input type="email" placeholder="enter@example.com" />
    </x-core::field>

    <x-core::field id="{{ $id }}_test-email-modal-subject:subject" label="Subject">
        <x-core::input placeholder="Test Email" />
    </x-core::field>
</x-core::modal-form>

{{-- Preview Modal --}}
<x-core::modal id="{{ $id }}_preview-modal" fullscreen static :close="false">
    <x-slot:header>
        <h6 class="modal-title mb-0">Preview</h6>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </x-slot>

    {{-- Side-by-side: Desktop (left) + Phone (right) --}}
    <div class="d-flex gap-5 p-5 overflow-auto" style="min-height: calc(100vh - 60px);">
        {{-- Desktop 70% --}}
        <div class="d-flex flex-column align-items-center gap-2" style="width: 70%;">
            <span class="text-muted small"><i class="ri-computer-line me-1"></i>Desktop</span>
            <div class="monitor-frame">
                <div class="monitor-bezel">
                    <iframe id="{{ $id }}_preview-desktop-frame" class="monitor-screen" frameborder="0"></iframe>
                </div>
                <div class="monitor-neck"></div>
                <div class="monitor-base"></div>
            </div>
        </div>

        {{-- Phone 30% --}}
        <div class="d-flex flex-column align-items-center gap-2" style="width: 30%;">
            <span class="text-muted small"><i class="ri-smartphone-line me-1"></i>Mobile</span>
            <x-core::phone-preview id="{{ $id }}_preview-phone-shell" type="iphone" size="lg" scale="0.8" ignore>
                <iframe id="{{ $id }}_preview-phone-frame" style="width: 100%; height: 100%; border: none;" frameborder="0"></iframe>
            </x-core::phone-preview>
        </div>
    </div>
</x-core::modal>
@endpush