# Solaris Master Data

A Laravel package for managing core master data entities — built on top of `solaris/solaris-laravel-core`.

Covers the full lifecycle of Accounts, Contacts, Products, Activities, Knowledge Base, and Documents, with audit trails, access control, and scheduled notifications wired in from the start.

---

## Requirements

- PHP 8.2+
- Laravel 11 or 12
- `solaris/solaris-laravel-core` v0.8.1+

---

## Modules

### Account
Manages business organizations/companies.

- Basic info: name, website, email, phone
- Classification: type, industry, business entity, employee range
- Profile picture support
- Linked contacts, activities, and documents
- Auto-links primary contact on creation

### Contact
Manages individual people linked to accounts.

- Personal info: name, gender, religion, marital status, salutation, education, preferred language
- Multiple **addresses** per contact (with country, province, city)
- Multiple **communication channels** per contact (phone, email, messaging)
- **Hobbies/interests**
- **Related contacts** with relationship category mapping (colleague, family, friend, etc.)
- Profile picture support

### Product
Manages the product/service catalog.

- Type classification and active/inactive status
- **Price tracking** with automatic history on every price change
- **Inventory availability** per warehouse/location with geo-tagging (country, province, city)
- **Product features/specs** list
- Aggregate availability auto-updated when location quantities change

### Activity
Task and event management with scheduling.

- Subject, description, notes
- Date range with timezone support
- Priority, category, and status tracking (`OnSchedule`, `InProgress`, `Finish`)
- Linked to Account and Contact
- **Reminders** with per-channel control (in-app, push, email)
- Reminder scheduling runs every minute via a background job

### Knowledge Base
Internal documentation and wiki.

- Article content with type categorization
- Status workflow: `Draft` → `Published`
- Author tracking

### Document
Document and contract management.

- Document number/reference
- Linked to Account and Contact
- Type and status tracking

---

## Architecture

All modules follow the same pattern inherited from `solaris-laravel-core`:

- **Models** extend `BaseModel` (UUID primary key, audit fields, soft deletes)
- **Repositories** extend `BaseRepository` (CRUD, batch ops, attachment handling)
- **Controllers** handle list, edit, avatar upload, and batch delete via standard endpoints
- **FormRequests** extend `BaseFormRequest` for consistent validation

Routes are prefixed under `/master-data` and protected by `auth` and `menu.access` middleware.

---

## Lookup / Reference Data

The following reference models are bundled and auto-registered for lookup management:

| Model | Description |
|---|---|
| `AccountType` | Account classifications |
| `ActivityCategory` | Activity categories (To-Do, Call, Meeting, etc.) |
| `ActivityPriority` | Priority levels |
| `ActivityStatus` | Status tracking |
| `AddressType` | Address types (Home, Office, Shipping, etc.) |
| `BusinessEntity` | Business structure types |
| `CommunicationType` | Communication channels |
| `DocumentStatus` | Document approval states |
| `DocumentType` | Document categorizations |
| `Education` | Education level reference |
| `Industry` | Industry classifications |
| `KnowledgeBaseStatus` | Publication status |
| `KnowledgeBaseType` | Knowledge Base categories |
| `MaritalStatus` | Marital status reference |
| `NumberOfEmployee` | Employee count ranges |
| `PreferredLanguage` | Language preferences |
| `ProductType` | Product categories |
| `RelatedContactCategory` | Contact relationship types |
| `ReminderType` | Reminder notification types |

---

## Scheduled Jobs

The package registers a background job that runs **every minute**:

- `ReminderNotification` — processes due activity reminders, handles timezone conversion, sends notifications via configured channels (in-app, push, email), and tracks success/failure per reminder.

No manual setup required — it registers automatically via `routes/console.php`.

---

## Changelog

Please see [CHANGELOG](CHANGELOG.md) for recent changes.
