# Changelog

All notable changes to `Solaris-Laravel-MasterData` will be documented in this file.

---

## [v0.11.4] — 18 Aug 2026

- Exposed account, contact, activity and product over the 3rd-party API — each declares its own public contract (fields, lookups by id/name) rather than deriving one from the table; new `Api\{Account,Contact,Activity,Product}Controller` + matching `Api\*Resource`. Rule sets gain a PATCH branch (previously only Account had one); `ActivityRequest` states its date pair explicitly and excludes reminders (internal, web-form-shaped).
- Fixed a partial activity update wiping its reminders — `updated()` treated a missing `remind_me` the same as `false`; now an absent key leaves reminders alone, only an explicit `false` clears them.
- `ApiPermissionSeeder` regrouped from `api` to `integration`, seeding one `Role` per entity (`API - Account`, etc.) with its permissions attached, instead of loose ungrouped permissions.
- Agent descriptions (`ActivityAgent`, `CatalogAgent`, `ContentAgent`, `CustomerAgent`) now state which specialist owns resolving a referenced record (e.g. a product named inside an activity), so the orchestrator stops pre-resolving entities the target specialist would resolve itself.

---

## [v0.11.3] — 12 Aug 2026

- Moved `activity/list.docs.json` component doc under `resources/views/components/docs/activity/`.
- Updated `solaris-laravel-core` dependency to `^v1.6.1`.

---

## [v0.11.2] — 11 Aug 2026

- Added lookup-shaped basic search tools (`SearchAccountBasicTool`, `SearchContactBasicTool`, `SearchProductBasicTool`) for lightweight ID resolution; registered in `config/solaris.php` and `AiRegistrySeeder`.
- Added `AiScopedToolSeeder` to grant basic lookup variants to `ContentAgent`/`ActivityAgent` and revoke superseded full search tools; wired into `DatabaseSeeder`.
- Agents' `instructions()` renamed to protected `buildInstructions()`; standardized "search tool available to you" phrasing across AI tool instructions.
- Removed redundant audit timestamp columns from search tool outputs; date formatting now uses `Carbon` where needed.
- Updated `solaris-laravel-core` dependency to `^v1.6.0`.

---

## [v0.11.1] — 30 Jul 2026

- Added `ActivityAgent` (activities, reminders, participants, promoted products); registered as `activity` role/agent with `activity_specialist` in `AiRegistrySeeder` and `config/solaris.php`, including WhatsApp routing.
- `CustomerAgent` scope narrowed to accounts/contacts (activities moved to `ActivityAgent`); `CatalogAgent`/`ContentAgent`/`CustomerAgent` instructions standardized — confirmation tokens now kept in agent memory instead of surfaced to the orchestrator, with expanded result-reporting rules.
- `CustomerAgent` `tools()`/`essentialTools()` helpers removed in favor of `essentialToolClasses()`.
- Refactored `findRecord(Request)` to `findRecordById(string $id)` across Account, AccountAddress, Contact, ContactAddress, ContactCommunication, ContactHobby, RelatedContact, Product, ProductAvailability, ProductFeature, Document, and KnowledgeBase AI tools; delete methods now type-hint `Model` instead of `mixed`.
- Standardized AI tool error responses to `AiErrorCode::UserError` instead of string error keys.
- `CreateAccountTool` field layout refactored with a `baseFields` property to avoid recursive embedding.
- `ProductRepository` constructor accepts an optional `$transaction` flag, passed through to `BaseRepository`.
- Updated `solaris-laravel-core` dependency to `^v1.5.1`.

---

## [v0.11.0] — 28 Jul 2026

- Replaced `MasterDataAgent`/`MasterDataDelegateTool` with three domain-specific agents: `CustomerAgent`, `CatalogAgent`, `ContentAgent`.
- Migrated all AI tools (Account, Activity, Contact, ContactAddress/Communication/Hobby, RelatedContact, Product, ProductAvailability/Feature, Document, KnowledgeBase) to new API: `slug()`, `fields(JsonSchema)`, `lookupChecks()`, `rules()`, `validateConfirmation()`, and `AiResponse` results; removed old `columns()`/`identifierSchema()`/`Authenticatable`/`WaConversation` constructors and `make()` factories.
- Create/Update tools now run inside DB transactions with before/after repository hooks and handle nested detail records (contacts, addresses, activities, reminders, features, availabilities) consistently.
- Added `SearchRelatedContactTool`, `CreateRelatedContactTool`, `UpdateRelatedContactTool`, `DeleteRelatedContactTool`; split `RelatedContactRequest` into separate create/update rules.
- Removed `ExtractBusinessCardTool`.
- Migrated AI tool/agent registration from `AiToolRegistry` service-provider calls to declarative config in `config/solaris.php`, regrouped by domain; added `AiRegistrySeeder` to manage roles, permissions, and tool-agent wiring.
- Document/KnowledgeBase tools convert WhatsApp-formatted notes/articles to HTML where needed; `DocumentRequest` now permits nullable `notes`.
- Updated `solaris-laravel-core` dependency to `^v1.5.0`.

---

## [v0.10.0] — 21 Jul 2026

- Migrated all AI tool column definitions (Account, AccountAddress, Contact, ContactAddress, ContactCommunication, ContactHobby, Document, KnowledgeBase, Product, ProductAvailability, ProductFeature, Activity, ActivityReminder, ProductPriceHistory) from array-based config to fluent `AiColumn`/`AiSearchColumn` builders; `columns()` methods made `public static` for reuse.
- Added nested resource management (contacts, addresses, activities) to `CreateAccountTool`/`UpdateAccountTool`, including validation and primary-contact creation/resolution.
- Added `BatchableAiTool` interface and `HasConfirmationBatch` trait to Create/Delete AI tools for batch operations; renamed `model_key` parameter to `modelKey`.
- Added `SearchRelatedContactTool` for querying contact relationships and `relations()` support to `SearchContactTool`/`SearchProductTool`/`SearchActivityTool`.
- Added `MasterDataAgent` and `MasterDataDelegateTool` for AI delegation to the master data module.
- Registered new AI tools and agent in `ai.tools`/`ai.agents` config and `SolarisMasterDataServiceProvider`.
- Added optional transaction parameter to `AccountRepository`, `ActivityRepository`, and `ContactRepository` constructors.
- Updated `Contact` model.

---

## [v0.9.3] — 10 Jul 2026

- Added `SIMILAR` operator and `primary_contact_id` search/reference field to `SearchAccountTool`.
- Improved search/create/update tools for Contact, KnowledgeBase, Activity, and Product modules with refined field descriptions and operators.

---

## [v0.9.2] — 9 Jul 2026

- Updated `solaris-laravel-core` dependency to `^v1.3.3`.
- Added `ExtractBusinessCardTool` AI tool to extract contact fields from a business card photo; registered in `ai.tools` config and `SolarisMasterDataServiceProvider`.
- Updated `CreateContactTool` instructions to call `extract_business_card` for business-card-based contact creation, while still resolving `account_id` via the existing account-matching rule.

---

## [v0.9.1] — 8 Jul 2026

- Renamed `knowledge-base` view folder to `knowledge_base` and updated config reference.

---

## [v0.9.0] — 8 Jul 2026

- Updated `solaris-laravel-core` dependency to `^v1.3.2`.
- Added AI Tools (Create/Update/Delete/Search) for Account, AccountAddress, Contact, ContactAddress, ContactCommunication, ContactHobby, Document, Product, ProductAvailability, ProductFeature, and Activity modules, plus `SearchActivityReminderTool` and `SearchProductPriceHistoryTool`.
- Extended KnowledgeBase AI tools (`CreateKnowledgeBaseTool`, `UpdateKnowledgeBaseTool`, `SearchKnowledgeBaseTool`).
- Registered new AI tool classes in `ai.tools` config and auto-registration in `SolarisMasterDataServiceProvider`.
- New migrations adding FTS support to KnowledgeBase, Document, and Product `notes`/`notes_plain` columns.
- Handled contact-updated event in `ContactRepository`.
- Updated document editor and notes component props across Account, Activity, Contact, Document, KnowledgeBase, and Product pages.
- Updated `DocumentRequest` validation rules.
- Fixed JS alias resolution in `account`, `contact`, and `product` page scripts.

---

## [v0.8.3] — 29 Jun 2026

- Updated activity page layout.
- Added `notes-files` section to activity detail page.

---

## [v0.8.2] — 26 Jun 2026

- Updated `solaris-laravel-core` dependency to `^v1.2.5`.
- Fixed table issue and calendar race condition in activity list.
- Removed `row` param from `importRules` in model.
- Added `card_wrapper: false` support in table detail.

---

## [v0.8.1] — 24 Jun 2026

- Updated `solaris-laravel-core` dependency to `^v1.2.4`.
- Fixed bug in activity modal (remind me feature).

---

## [v0.8.0] — 23 Jun 2026

- Added AI Tools for KnowledgeBase module: `CreateKnowledgeBaseTool`, `UpdateKnowledgeBaseTool`, `DeleteKnowledgeBaseTool`, `SearchKnowledgeBaseTool`.
- AI Tools are auto-registered via `AiToolRegistry` on service provider boot.
- Added `ai.tools` section to `solaris.php` config for KnowledgeBase tool class mappings.
- New migration adding `_plain` columns for WYSIWYG fields across Account, Activity, Contact, Document, and KnowledgeBase models to support full-text searching.
- Updated `KnowledgeBaseRequest` validation rules.

---

## [v0.7.4] — 11 Jun 2026

- Updated `solaris-laravel-core` dependency to `^v1.1.0`.

---

## [v0.7.3] — 5 Jun 2026

- Replaced `TodayActivityResource` with `ActivityResource` in the mobile home controller.

---

## [v0.7.2] — 4 Jun 2026

- Updated mobile home page controller.

---

## [v0.7.1] — 3 Jun 2026

- Minor dependency update and list view adjustment.

---

## [v0.7.0] — 26 May 2026

- Added mobile API endpoints for Account, Contact, and Product modules.
- Enhanced account and contact detail pages with improved layout and data handling.
- Refactored activity reminder logic into a dedicated static method in the repository.
- Updated list views across modules.
- Various bug fixes and UI improvements.

---

## [v0.6.0] — 24 Apr 2026

- Notes now support media file uploads.
- Document editor updated with new configuration options.
- Renamed `ActivityModal` and moved default modal to `ActivityDetail`.
- Added return type hints to all methods across the codebase.
- New migration for nullable number field.
- Bug fixes for product list rendering and modal behavior.

---

## [v0.5.8] — 20 Apr 2026

- Fixed timezone display issue on the Knowledge Base page.

---

## [v0.5.7] — 19 Apr 2026

- Fixed a breaking change in blade component slot/lookup behavior.
- Added blade component documentation for the Solar UI VSCode extension.

---

## [v0.5.6] — 16 Apr 2026

- Fixed bugs on the Account page JavaScript.

---

## [v0.5.5] — 1 Apr 2026

- Fixed a bug in the activity reminder system.

---

## [v0.5.4] — 31 Mar 2026

- Added default import rules to model definitions.

---

## [v0.5.3] — 30 Mar 2026

- Added `ImportAccess` attribute support to models.
- Updated Product model and repository.

---

## [v0.5.2] — 27 Mar 2026

- Fixed profile picture upload in the modal page.
- Updated Code Generator and Document Number seeders.
- Added `name` key parameter support for solar component events.

---

## [v0.5.1] — 26 Mar 2026

- Removed deprecated `dropdown_parent` property from select components.

---

## [v0.5.0] — 26 Mar 2026

- Added `FolderAccess` and `ExportAccess` support to the master data module.
- Updated migrations.

---

## [v0.4.4] — 11 Mar 2026

- Fixed start date and end date bugs on the Activity page.

---

## [v0.4.3] — 11 Mar 2026

- Improved and fixed the activity reminder scheduler.
- Changed reminder value field to `offset_minutes`.
- Fixed reminder display in the edit modal and edit page.

---

## [v0.4.2] — 23 Feb 2026

- Version and configuration update.

---

## [v0.4.1] — 16 Feb 2026

- Renamed package alias from `solar-md` to `master-data`.
- Updated all view aliases: `@solar` → `@core`, `@solar-md` → `@master-data`.

---

## [v0.4.0] — 11 Feb 2026

- **Breaking:** Changed namespace from `Solaris\Laravel` to `Solaris\Core`.
- Removed old migrations that are no longer needed.
- Updated package configuration.

---

## [v0.3.2] — 29 Jan 2026

- Updated activity request validation.
- Removed `auth.json` file.

---

## [v0.3.1] — 12 Jan 2026

- Fixed a bug in the migration index update.

---

## [v0.3.0] — 8 Jan 2026

- Major database migration overhaul.
- Added batch delete support to controllers.
- Activity list view switched to card mode.
- Activity reminder job now ordered by scheduled time (`remind_at`).
- Updated repository layer.

---

## [v0.2.3.3] — 19 Dec 2025

- Fixed a calendar date selection issue where the start date was not properly applied on click.

---

## [v0.2.3.2] — 16 Dec 2025

- Added `extendColumns` method to all controllers for custom column support.
- Hotfix patches applied.

---

## [v0.2.3.1] — 16 Dec 2025

- Hotfix patch.

---

## [v0.2.3] — 15 Dec 2025

- Updated core package version.

---

## [v0.2.2] — 15 Dec 2025

- General update and maintenance.

---

## [v0.2.1] — 12 Dec 2025

- Updated to Solaris Core v0.4.1.
- Updated menu seeder.

---

## [v0.2.0] — 8 Dec 2025

- **Major redesign** of all blade views — view structure fully reworked.
- Added `ReminderNotification` for activity reminders.
- Simplified repository layer.
- Fixed image upload in modal pages.
- Various activity, tab, and page improvements.

---

## [v0.1.8] — 3 Dec 2025

- Refactored delete methods in repositories with `deleting` and `deleted` event hooks.
- Updated JSON response format to match Solaris Core v0.3.10.

---

## [v0.1.7] — 28 Nov 2025

- Updated Solaris Laravel dependency to v0.3.9.

---

## [v0.1.6] — 28 Nov 2025

- Refactored menu seeder to use dynamic UUIDs.
- Removed deprecated `configure.php`.

---

## [v0.1.5] — 27 Nov 2025

- Refactored store methods to resolve requests via the service container.
- Extracted activity detail logic into a shared class.
- Tab IDs now use dynamic `$id` variable.
- Updated to Solaris Core v0.3.8.

---

## [v0.1.4] — 26 Nov 2025

- Improved formatting in account and contact modals.
- Refactored update methods and validation logic in account module.
- Fixed field naming issues in the account page.
- Enhanced product list rendering.
- Updated migration publish path in the service provider.
- Updated to Solaris Core v0.3.7.

---

## [v0.1.3] — 24 Nov 2025

- Updated Solaris Laravel dependency to v0.3.6.

---

## [v0.1.2] — 24 Nov 2025

- Compatibility updates for Solaris Core v0.3.5.

---

## [v0.1.1] — 20 Nov 2025

- Updated Solaris Laravel dependency to v0.3.4.

---

## [v0.1.0] — 14 Nov 2025

- Compatibility updates for Solaris Core v0.3.2.
- Added avatar upload trait.
- Updated menu seeder and route stubs.

---

## [v0.0.5] — 31 Oct 2025

- Dependency update.

---

## [v0.0.4] — 31 Oct 2025

- Completed account module.
- Enhanced contact and activity components.
- Modularized product blade views.
- Removed old/unused views.

---

## [v0.0.3] — 29 Oct 2025

- Completed document module.
- Enhanced activity, product, contact, and account modules.
- Added knowledge base module.
- Added `const.js` for shared JS constants.
- Configuration and seeder updates.

---

## [v0.0.2] — 22 Oct 2025

- Minor update and merge.

---

## [v0.0.1] — 22 Oct 2025

- Initial release.
- Core modules: Account, Contact, Activity, Product, and Document.
- Includes migrations, seeders, routes, repositories, and blade views.
