<?php

namespace Solaris\MasterData\Repositories;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Interfaces\Model\SolarisModel;
use Solaris\Core\Models\Attachment;
use Solaris\Core\Repositories\AttachmentRepository;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\Core\Traits\UploadFile;
use Solaris\MasterData\Models\Product;
use Solaris\MasterData\Models\ProductPriceHistory;

class ProductRepository extends BaseRepository
{
    use UploadFile;

    private array $pendingProductPictureIds = [];

    public function __construct(Product $model, bool $transaction = true)
    {
        parent::__construct($model, $transaction);
    }

    public function findComplete(string $id, array $columns = []): Product
    {
        return $this->model
            ->prepared(array_merge(static::defaultColumns(), $columns))
            ->where('id', $id)
            ->first();
    }
    
    protected function created(Model|SolarisModel $record, array $data, array $rawData): void
    {
        if($record->price != 0) {
            $this->updatePriceHistory($record);
        }
    }

    protected function updated(Model|SolarisModel $record, array $data, array $rawData): void
    {
        if ($record->wasChanged('price')) {
            $this->updatePriceHistory($record);
        }
    }

    protected function deleted(Model|SolarisModel $record): void
    {
        $attachmentRepo = new AttachmentRepository(new Attachment());
        if(!is_null($record->product_picture_id)) {
            $attachmentRepo->delete($record->product_picture_id);
        }

        $attachmentRepo->deleteRelation($this->getModel()->getTable(), $record->id);
    }

    protected function batchDeleting(array $ids): void
    {
        $this->pendingProductPictureIds = DB::table($this->getModel()->getTable())
            ->select('product_picture_id')
            ->whereIn('id', $ids)
            ->whereNotNull('product_picture_id')
            ->pluck('product_picture_id')
            ->all();
    }

    protected function batchDeleted(array $ids): void
    {
        $table          = $this->getModel()->getTable();
        $attachmentRepo = new AttachmentRepository(new Attachment());

        if (!empty($this->pendingProductPictureIds)) {
            $attachmentRepo->batchDelete(
                user     : null,
                model    : $attachmentRepo->getModel(),
                selected : $this->pendingProductPictureIds
            );
            $this->pendingProductPictureIds = [];
        }

        $attachmentRepo->batchDelete(
            user  : null,
            model : $attachmentRepo->getModel()
                ->query()
                ->where('table_name', $table)
                ->whereIn('record_id', $ids)
        );
    }

    protected function updatePriceHistory(Product $product): void
    {
        $productPriceHistoryModel = Helper::model('product_price_history');

        $now = Carbon::now();

        /** @var ProductPriceHistory */
        $lastHistory = $productPriceHistoryModel::where('product_id', $product->id)
            ->whereNull('end')
            ->orderByDesc('from')
            ->first();

        if ($lastHistory) {
            $lastHistory->end = $now;
            $lastHistory->save();
        }

        $productPriceHistoryModel::create([
            'product_id' => $product->id,
            'price'      => $product->price,
            'from'       => $now,
            'end'        => null
        ]);
    }

    public static function defaultColumns(): array
    {
        return [
            'id',
            'name',
            'availability',
            'sku_number',
            'active',
            'category',
            'brand',
            'price',
            'unit_of_measure',
            'notes',
            'type_id',
            'product_picture_id',
            'created_by_id',
            'product_description',
            'updated_at'
        ];
    }
}
