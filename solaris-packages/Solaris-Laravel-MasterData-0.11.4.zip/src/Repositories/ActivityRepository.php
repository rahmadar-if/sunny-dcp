<?php

namespace Solaris\MasterData\Repositories;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Arr;
use Illuminate\Support\Collection as SupportCollection;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Solaris\MasterData\Const\ActivityPriorityConst;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Interfaces\Model\SolarisModel;
use Solaris\Core\Models\Attachment;
use Solaris\Core\Repositories\AttachmentRepository;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\MasterData\Const\ActivityStatusConst;
use Solaris\MasterData\Models\Activity;

class ActivityRepository extends BaseRepository
{
    public function __construct(Activity $model, bool $transaction = true)
    {
        parent::__construct($model, $transaction);
    }
    
    public function findComplete(string $id, array $columns = []): Activity
    {
        $record = $this->model
            ->prepared(array_merge(static::defaultColumns(), $columns))
            ->where('id', $id)
            ->first();

        if($record && $record->reminders->isNotEmpty()) {
            $record->setRelation('remind_users',
                $record->reminders
                    ->map(fn($r) => $r->to)
                    ->filter()
                    ->unique('id')
                    ->reject(fn($user) => $user->id === $record->created_by_id)
                    ->values()
            );

            $record->setRelation('reminders',
                $record->reminders
                    ->groupBy('type_id')
                    ->map(fn($group) => $group->sortByDesc('updated_at')->first())
                    ->values()
            );
        }

        return $record;
    }

    public function calendar(?string $startDate = null, ?string $endDate = null): Collection
    {
        if(empty($startDate) || empty($endDate)) {
            $now       = Carbon::now();
            $startDate = $now->startOfMonth()->format('Y-m-d');
            $endDate   = $now->endOfMonth()->format('Y-m-d');
        }

        return Helper::model('activity')::prepared('subject', 'start_date', 'end_date', 'category', 'priority', 'status', 'account', 'contact')
            ->whereBetween('start_date', [$startDate, $endDate])
            ->orderBy('start_date', 'ASC')
            ->get();
    }

    public function calendarWeb(?string $startDate = null, ?string $endDate = null): SupportCollection
    {
        return $this->calendar($startDate, $endDate)
            ->map(function($item) {
                $priorityId = $item->priority_id;
                $color      = match ($priorityId) {
                    ActivityPriorityConst::High   => "bg-danger",
                    ActivityPriorityConst::Medium => "bg-warning",
                    ActivityPriorityConst::Low    => "bg-info",
                    default                       => "bg-success"
                };

                $newItem = (object)[
                    'id'        => $item->id,
                    'title'     => $item->subject,
                    'start'     => $item->start_date,
                    'className' => $color
                ];
                if(!is_null($item->end_date)) {
                    $newItem->end = $item->end_date;
                }

                return $newItem;
            });
    }

    protected function creating(array $data): array
    {
        return Arr::except($data, ["remind_me", "reminder_types", "remind_to"]);
    }

    protected function created(Model|SolarisModel $record, array $data, array $rawData): void
    {
        if(!empty($rawData["reminder_types"])) {
            $reminder_to = array_values(array_unique(array_merge(
                [Auth::user()->id],
                $rawData["remind_to"] ?? []
            )));
            
            $reminderTypes = Helper::model('reminder_type')::select('id', 'offset_minutes')->get();
            
            foreach ($reminder_to as $to) {
                foreach ($rawData["reminder_types"] as $type) {
                    if($type["checked"]) {
                        $remindType = $reminderTypes->where('id', $type["id"])->first();
                        Helper::model('activity_reminder')::create([
                            "type_id"     => $type["id"],
                            "remind_at"   => $record->start_date->copy()->subMinutes($remindType->offset_minutes),
                            "to_id"       => $to,
                            "activity_id" => $record->id
                        ]);
                    }
                }
            }
        }
    }

    protected function updating(Model|SolarisModel $record, array $data): array
    {
        return [$record, Arr::except($data, ["remind_me", "reminder_types", "remind_to"])];
    }

    protected function updated(Model|SolarisModel $record, array $data, array $rawData): void
    {
        // Absent is not the same as false: a partial update that never mentions remind_me must
        // leave the reminders alone, otherwise editing any field at all wipes them.
        if(!array_key_exists("remind_me", $rawData)) return;

        if(empty($rawData["remind_me"])) {
            Helper::model('activity_reminder')::where('activity_id', $record->id)
                ->where('is_remind', false)
                ->delete();
            return;
        }

        if(empty($rawData["reminder_types"])) return;

        $remindTo = array_values(array_unique(array_merge(
            [Auth::user()->id],
            $rawData["remind_to"] ?? []
        )));

        $startDateChanged = $record->wasChanged('start_date');
        $reminderTypes    = Helper::model('reminder_type')::select('id', 'offset_minutes')->get();
        $existing         = Helper::model('activity_reminder')::where('activity_id', $record->id)->get();

        $checkedTypeIds   = collect($rawData["reminder_types"])->where('checked', true)->pluck('id')->toArray();
        $uncheckedTypeIds = collect($rawData["reminder_types"])->where('checked', false)->pluck('id')->toArray();

        if(!empty($uncheckedTypeIds)) {
            Helper::model('activity_reminder')::where('activity_id', $record->id)
                ->whereIn('type_id', $uncheckedTypeIds)
                ->where('is_remind', false)
                ->delete();
        }

        foreach ($checkedTypeIds as $typeId) {
            $remindType  = $reminderTypes->where('id', $typeId)->first();
            $newRemindAt = $record->start_date->copy()->subMinutes($remindType->offset_minutes);

            foreach ($remindTo as $userId) {
                $unprocessed = $existing->where('type_id', $typeId)->where('to_id', $userId)->where('is_remind', false)->first();
                $processed   = $existing->where('type_id', $typeId)->where('to_id', $userId)->where('is_remind', true)->first();

                if($unprocessed) {
                    if($startDateChanged) {
                        $unprocessed->update(['remind_at' => $newRemindAt]);
                    }
                } elseif($processed) {
                    if($startDateChanged) {
                        Helper::model('activity_reminder')::create([
                            "type_id"     => $typeId,
                            "remind_at"   => $newRemindAt,
                            "to_id"       => $userId,
                            "activity_id" => $record->id
                        ]);
                    }
                } else {
                    Helper::model('activity_reminder')::create([
                        "type_id"     => $typeId,
                        "remind_at"   => $newRemindAt,
                        "to_id"       => $userId,
                        "activity_id" => $record->id
                    ]);
                }
            }
        }

        $removedUserIds = $existing->where('is_remind', false)->pluck('to_id')->diff($remindTo)->values()->toArray();
        if(!empty($removedUserIds)) {
            Helper::model('activity_reminder')::where('activity_id', $record->id)
                ->whereIn('to_id', $removedUserIds)
                ->where('is_remind', false)
                ->delete();
        }
    }

    protected function deleted(Model|SolarisModel $record): void
    {
        $attachmentRepo = new AttachmentRepository(new Attachment());
        $attachmentRepo->deleteRelation($this->getModel()->getTable(), $record->id);
    }

    protected function batchDeleted(array $ids): void
    {
        $attachmentRepo = new AttachmentRepository(new Attachment());
        $attachmentRepo->batchDelete(
            user: null, 
            model: $attachmentRepo->getModel()
                ->query()
                ->where("table_name", $this->getModel()->getTable())
                ->whereIn("record_id", $ids)
        );
    }

    public function todayActivity(int $length = 5, string $timezone = "UTC"): Collection
    {
        $now   = Carbon::now($timezone);
        $start = $now->copy()->startOfDay()->utc();
        $end   = $now->copy()->endOfDay()->utc();

        return $this->model
            ->prepared(["subject", "start_date", "end_date", "category", "status", "priority", "account.name", "contact.name"])
            ->where(function($query) {
                $query->whereIn("status_id", [ActivityStatusConst::InProgress, ActivityStatusConst::OnSchedule])
                    ->orWhereNull("status_id");
            })
            ->whereBetween("start_date", [$start, $end])
            ->orderBy("start_date", "desc")
            ->skip(0)
            ->take($length)
            ->get();
    }

    public static function store(array $activityData, array $reminderTypeIds = [], array $remindTo = []): Activity
    {
        $repo = new static(new Activity());

        if (empty($reminderTypeIds)) {
            return $repo->create($activityData);
        }

        $reminderTypes = array_map(fn(string $id) => ['id' => $id, 'checked' => true], $reminderTypeIds);

        return $repo->create(array_merge($activityData, [
            'reminder_types' => $reminderTypes,
            'remind_to'      => $remindTo,
        ]));
    }

    public static function processReminders(): void
    {
        $successIds = [];
        $failIds    = [];
        $model      = Helper::model('activity_reminder');

        $model::prepared(
            'activity[id, subject, start_date, priority, category]',
            'to[id, email, is_app_notification, is_push_notification, is_email_notification, profile.timezone]'
        )
        ->leftJoin('activities', 'activity_reminders.activity_id', '=', 'activities.id')
        ->leftJoin('activity_priorities', 'activities.priority_id', '=', 'activity_priorities.id')
        ->where('activity_reminders.is_remind', false)
        ->where('activity_reminders.is_fail', false)
        ->where('activity_reminders.remind_at', '<=', now())
        ->orderBy('activity_priorities.position', 'asc')
        ->orderBy('activity_reminders.remind_at', 'asc')
        ->chunk(1000, function ($reminders) use (&$successIds, &$failIds) {
            foreach ($reminders as $reminder) {
                $user     = $reminder->to;
                $activity = $reminder->activity;

                $title     = "Reminder: {$activity->subject}";
                $startDate = Carbon::parse($activity->start_date)
                    ->timezone($user->profile->timezone)
                    ->format('d M Y H:i');
                $message = "Starts at {$startDate} • {$activity->category->name}, {$activity->priority->name}";
                $url     = url("/master-data/activity/{$activity->id}");

                try {
                    $user->sendPreferredNotification($title, $message, $url);
                    $successIds[] = $reminder->id;
                } catch (\Throwable $e) {
                    Log::error('ReminderNotification failed', [
                        'reminder_id' => $reminder->id,
                        'user_id'     => $user->id,
                        'message'     => $e->getMessage(),
                    ]);
                    $failIds[] = $reminder->id;
                }
            }
        });

        if (!empty($successIds)) {
            $model::whereIn('id', $successIds)->update(['is_remind' => true]);
        }

        if (!empty($failIds)) {
            $model::whereIn('id', $failIds)->update(['is_fail' => true]);
        }
    }

    public static function defaultColumns(): array
    {
        return [
            'id',
            'subject',
            'start_date',
            'end_date',
            'category_id',
            'priority_id',
            'status_id',
            'account_id',
            'contact_id',
            'created_by_id',
            'reminders[updated_at, is_remind, remind_at, type_id, to[name,profile_picture]]'
        ];
    }
}
