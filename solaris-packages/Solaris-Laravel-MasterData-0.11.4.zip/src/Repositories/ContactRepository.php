<?php

namespace Solaris\MasterData\Repositories;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Interfaces\Model\SolarisModel;
use Solaris\Core\Models\Attachment;
use Solaris\Core\Repositories\AttachmentRepository;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\Core\Traits\UploadFile;
use Solaris\MasterData\Models\Contact;

class ContactRepository extends BaseRepository
{
    use UploadFile;

    private array $pendingProfilePictureIds = [];

    public function __construct(Contact $model, bool $transaction = true)
    {
        parent::__construct($model, $transaction);
    }

    protected function updated(Model|SolarisModel $record, array $data, array $rawData): void
    {
        $previous = $record->getPrevious();

        if($record->wasChanged('account_id')) {
            $previousAccount = null;
            if(!empty($previous['account_id'])) {
                $previousAccount = Helper::model('account')::where('id', $previous['account_id'])
                    ->where('primary_contact_id', $record->id)
                    ->first();
            }

            if ($previousAccount && $previousAccount->primary_contact_id === $record->id) {
                $previousAccount->update(['primary_contact_id' => null]);
            }
        }
    }

    public function findComplete(string $id, array $columns = []): Contact
    {
        $data = $this->model
            ->prepared(array_merge(static::defaultColumns(), $columns))
            ->where('id', $id)
            ->first();

        $data->total_activity      = Helper::model('activity')::where('contact_id', $id)->count();
        $data->total_address       = Helper::model('contact_address')::where('contact_id', $id)->count();
        $data->total_communication = Helper::model('contact_communication')::where('contact_id', $id)->count();

        return $data;
    }

    protected function deleted(Model|SolarisModel $record): void
    {
        $attachmentRepo = new AttachmentRepository(new Attachment());
        if (!is_null($record->profile_picture_id)) {
            $attachmentRepo->delete($record->profile_picture_id);
        }

        $attachmentRepo->deleteRelation($this->getModel()->getTable(), $record->id);
    }

    protected function batchDeleting(array $ids): void
    {
        $this->pendingProfilePictureIds = DB::table($this->getModel()->getTable())
            ->select('profile_picture_id')
            ->whereIn('id', $ids)
            ->whereNotNull('profile_picture_id')
            ->pluck('profile_picture_id')
            ->all();
    }

    protected function batchDeleted(array $ids): void
    {
        $table          = $this->getModel()->getTable();
        $attachmentRepo = new AttachmentRepository(new Attachment());

        if (!empty($this->pendingProfilePictureIds)) {
            $attachmentRepo->batchDelete(
                user     : null,
                model    : $attachmentRepo->getModel(),
                selected : $this->pendingProfilePictureIds
            );
            $this->pendingProfilePictureIds = [];
        }

        $attachmentRepo->batchDelete(
            user  : null,
            model : $attachmentRepo->getModel()
                ->query()
                ->where('table_name', $table)
                ->whereIn('record_id', $ids)
        );
    }

    public static function defaultColumns(): array
    {
        return [
            'id',
            'name',
            'also_known_as',
            'primary_phone',
            'primary_mobile_phone',
            'email',
            'job_title',
            'birth_date',
            'notes',
            'account[name, email, type_id, industry_id, profile_picture_id]',
            'gender_id',
            'religion_id',
            'preferred_language_id',
            'marital_status_id',
            'salutation_id',
            'education_id',
            'profile_picture_id',
            'created_by_id',
            'recipients_name'
        ];
    }
}
