<?php

namespace Solaris\MasterData\Repositories;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Interfaces\Model\SolarisModel;
use Solaris\Core\Models\Attachment;
use Solaris\Core\Repositories\AttachmentRepository;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\Core\Traits\UploadFile;
use Solaris\MasterData\Models\Account;

class AccountRepository extends BaseRepository
{
    use UploadFile;

    private array $pendingProfilePictureIds = [];

    public function __construct(Account $model, bool $transaction = true)
    {
        parent::__construct($model, $transaction);
    }

    public function findComplete(string $id, array $columns = []): Account
    {
        $data = $this->model
            ->prepared(array_merge(static::defaultColumns(), $columns))
            ->where('id', $id)
            ->first();

        $data->total_contact  = Helper::model('contact')::where('account_id', $id)->count();
        $data->total_activity = Helper::model('activity')::where('account_id', $id)->count();
        $data->total_address  = Helper::model('account_address')::where('account_id', $id)->count();

        return $data;
    }

    protected function deleted(Model|SolarisModel $record): void
    {
        $attachmentRepo = new AttachmentRepository(new Attachment());
        if (!is_null($record->profile_picture_id)) {
            $attachmentRepo->delete($record->profile_picture_id);
        }

        $attachmentRepo->deleteRelation($this->getModel()->getTable(), $record->id);
    }

    protected function batchDeleting(array $ids): void
    {
        $this->pendingProfilePictureIds = DB::table($this->getModel()->getTable())
            ->select('profile_picture_id')
            ->whereIn('id', $ids)
            ->whereNotNull('profile_picture_id')
            ->pluck('profile_picture_id')
            ->all();
    }

    protected function batchDeleted(array $ids): void
    {
        $table          = $this->getModel()->getTable();
        $attachmentRepo = new AttachmentRepository(new Attachment());

        if (!empty($this->pendingProfilePictureIds)) {
            $attachmentRepo->batchDelete(
                user     : null,
                model    : $attachmentRepo->getModel(),
                selected : $this->pendingProfilePictureIds
            );
            $this->pendingProfilePictureIds = [];
        }

        $attachmentRepo->batchDelete(
            user  : null,
            model : $attachmentRepo->getModel()
                ->query()
                ->where('table_name', $table)
                ->whereIn('record_id', $ids)
        );
    }

    public static function defaultColumns(): array
    {
        return [
            'id', 
            'name',
            'website',
            'email',
            'primary_phone',
            'email',
            'category',
            'also_known_as',
            'notes',
            'type_id',
            'number_of_employee_id',
            'business_entity_id',
            'industry_id',
            'profile_picture_id',
            'created_by_id',
            'primary_contact[name, job_title, profile_picture_id]',
        ];
    }
}