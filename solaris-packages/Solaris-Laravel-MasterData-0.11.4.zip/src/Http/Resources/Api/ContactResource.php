<?php

namespace Solaris\MasterData\Http\Resources\Api;

use Illuminate\Http\Request;
use Solaris\Core\Helpers\LookupResource;
use Solaris\Core\Http\Resources\Api\BaseApiResource;

class ContactResource extends BaseApiResource
{
    protected function fields(Request $request): array
    {
        return [
            'id'                   => $this->id,
            'name'                 => $this->name,
            'also_known_as'        => $this->also_known_as,
            'recipients_name'      => $this->recipients_name,
            'salutation'           => LookupResource::from($this->salutation),
            'job_title'            => $this->job_title,
            'primary_phone'        => $this->primary_phone,
            'primary_mobile_phone' => $this->primary_mobile_phone,
            'email'                => $this->email,
            'account'              => LookupResource::from($this->account),
            'gender'               => LookupResource::from($this->gender),
            'birth_date'           => $this->birth_date,
            'marital_status'       => LookupResource::from($this->marital_status),
            'religion'             => LookupResource::from($this->religion),
            'education'            => LookupResource::from($this->education),
            'preferred_language'   => LookupResource::from($this->preferred_language),
            'notes'                => $this->notes,
            'created_at'           => $this->created_at,
            'updated_at'           => $this->updated_at,
            'created_by'           => LookupResource::user($this->created_by),
            'updated_by'           => LookupResource::user($this->updated_by),
        ];
    }
}
