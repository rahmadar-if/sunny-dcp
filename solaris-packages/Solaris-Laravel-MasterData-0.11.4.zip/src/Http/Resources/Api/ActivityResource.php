<?php

namespace Solaris\MasterData\Http\Resources\Api;

use Illuminate\Http\Request;
use Solaris\Core\Helpers\LookupResource;
use Solaris\Core\Http\Resources\Api\BaseApiResource;

class ActivityResource extends BaseApiResource
{
    protected function fields(Request $request): array
    {
        return [
            'id'         => $this->id,
            'subject'    => $this->subject,
            'start_date' => $this->start_date,
            'end_date'   => $this->end_date,
            'category'   => LookupResource::from($this->category),
            'priority'   => LookupResource::from($this->priority),
            'status'     => LookupResource::from($this->status),
            'account'    => LookupResource::from($this->account),
            'contact'    => LookupResource::from($this->contact),
            'notes'      => $this->notes,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
            'created_by' => LookupResource::user($this->created_by),
            'updated_by' => LookupResource::user($this->updated_by),
        ];
    }
}
