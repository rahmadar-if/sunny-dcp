<?php

namespace Solaris\MasterData\Http\Resources\Api;

use Illuminate\Http\Request;
use Solaris\Core\Helpers\LookupResource;
use Solaris\Core\Http\Resources\Api\BaseApiResource;

class AccountResource extends BaseApiResource
{
    protected function fields(Request $request): array
    {
        return [
            'id'                 => $this->id,
            'name'               => $this->name,
            'also_known_as'      => $this->also_known_as,
            'primary_phone'      => $this->primary_phone,
            'email'              => $this->email,
            'website'            => $this->website,
            'category'           => $this->category,
            'notes'              => $this->notes,
            'type'               => LookupResource::from($this->type),
            'industry'           => LookupResource::from($this->industry),
            'business_entity'    => LookupResource::from($this->business_entity),
            'number_of_employee' => LookupResource::from($this->number_of_employee),
            'primary_contact'    => LookupResource::from($this->primary_contact),
            'created_at'         => $this->created_at,
            'updated_at'         => $this->updated_at,
            'created_by'         => LookupResource::user($this->created_by),
            'updated_by'         => LookupResource::user($this->updated_by),
        ];
    }
}
