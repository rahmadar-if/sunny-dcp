<?php

namespace Solaris\MasterData\Http\Resources\Api;

use Illuminate\Http\Request;
use Solaris\Core\Helpers\LookupResource;
use Solaris\Core\Http\Resources\Api\BaseApiResource;

class ProductResource extends BaseApiResource
{
    protected function fields(Request $request): array
    {
        return [
            'id'                  => $this->id,
            'name'                => $this->name,
            'sku_number'          => $this->sku_number,
            'type'                => LookupResource::from($this->type),
            'category'            => $this->category,
            'brand'               => $this->brand,
            'unit_of_measure'     => $this->unit_of_measure,
            'price'               => $this->price,
            'availability'        => $this->availability,
            'active'              => $this->active,
            'product_description' => $this->product_description,
            'notes'               => $this->notes,
            'created_at'          => $this->created_at,
            'updated_at'          => $this->updated_at,
            'created_by'          => LookupResource::user($this->created_by),
            'updated_by'          => LookupResource::user($this->updated_by),
        ];
    }
}
