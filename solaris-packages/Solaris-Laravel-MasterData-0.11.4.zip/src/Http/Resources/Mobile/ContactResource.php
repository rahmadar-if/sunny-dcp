<?php

namespace Solaris\MasterData\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Http\Resources\BaseResource;
use Solaris\Core\Helpers\LookupResource;

class ContactResource extends BaseResource
{    
    protected function list(Request $request): array
    {
        return [
            "id"                   => $this->id,
            "name"                 => $this->name,
            "profile_picture"      => LookupResource::image($this->profile_picture_id)['thumbnail'],
            "job_title"            => $this->job_title,
            "primary_phone"        => $this->primary_phone,
            "primary_mobile_phone" => $this->primary_mobile_phone,
            "email"                => $this->email,
        ];
    }

    protected function detail(Request $request): array
    {
        return [
            "id"                   => $this->id,
            "name"                 => $this->name,
            "profile_picture"      => LookupResource::image($this->profile_picture_id),
            "primary_phone"        => $this->primary_phone,
            "primary_mobile_phone" => $this->primary_mobile_phone,
            "email"                => $this->email,
            "account"              => LookupResource::from($this->account),
            "salutation"           => LookupResource::from($this->salutation),
            "also_known_as"        => $this->also_known_as,
            "recipients_name"      => $this->recipients_name,
            "gender"               => LookupResource::from($this->gender),
            "birth_date"           => $this->birth_date,
            "marital_status"       => LookupResource::from($this->marital_status),
            "religion"             => LookupResource::from($this->religion),
            "education"            => LookupResource::from($this->education),
            "preferred_language"   => LookupResource::from($this->preferred_language),
            "job_title"            => $this->job_title,
            "degree"               => $this->degree,
            "notes"                => $this->notes,
            "created_at"           => $this->created_at,
            "updated_at"           => $this->updated_at,
            "created_by"           => LookupResource::user($this->created_by),
            "updated_by"           => LookupResource::user($this->updated_by),
        ];
    }
}
