<?php

namespace Solaris\MasterData\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Http\Resources\BaseResource;
use Solaris\Core\Helpers\LookupResource;

class RelatedContactResource extends BaseResource
{
	protected function list(Request $request): array
	{
		return [
			'id'              => $this->id,
			'related_contact' => LookupResource::from($this->related_contact),
			'category'        => LookupResource::from($this->category),
		];
	}

	protected function detail(Request $request): array
	{
		return [
			'id'              => $this->id,
			'related_contact' => LookupResource::from($this->related_contact),
			'category'        => LookupResource::from($this->category),
			'created_at'      => $this->created_at,
			'updated_at'      => $this->updated_at,
			'created_by'      => LookupResource::user($this->created_by),
			'updated_by'      => LookupResource::user($this->updated_by),
		];
	}
}
