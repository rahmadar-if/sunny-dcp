<?php

namespace Solaris\MasterData\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Http\Resources\BaseResource;
use Solaris\Core\Helpers\LookupResource;

class AccountResource extends BaseResource
{    
    protected function list(Request $request): array
    {
        return [
            "id"              => $this->id,
            "name"            => $this->name,
            "profile_picture" => LookupResource::image($this->profile_picture_id)['thumbnail'],
            "industry"        => LookupResource::from($this->industry),
            "type"            => LookupResource::from($this->type),
            "primary_phone"   => $this->primary_phone,
            "email"           => $this->email,
        ];
    }

    protected function detail(Request $request): array
    {
        return [
            "id"                 => $this->id,
            "name"               => $this->name,
            "profile_picture"    => LookupResource::image($this->profile_picture_id),
            "also_known_as"      => $this->also_known_as,
            "primary_phone"      => $this->primary_phone,
            "email"              => $this->email,
            "primary_contact"    => LookupResource::from($this->primary_contact),
            "type"               => LookupResource::from($this->type),
            "industry"           => LookupResource::from($this->industry),
            "business_entity"    => LookupResource::from($this->business_entity),
            "business_size"      => LookupResource::from($this->business_size),
            "number_of_employee" => LookupResource::from($this->number_of_employee),
            "category"           => $this->category,
            "notes"              => $this->notes,
            "created_at"         => $this->created_at,
            "updated_at"         => $this->updated_at,
            "created_by"         => LookupResource::user($this->created_by),
            "updated_by"         => LookupResource::user($this->updated_by),
        ];
    }
}
