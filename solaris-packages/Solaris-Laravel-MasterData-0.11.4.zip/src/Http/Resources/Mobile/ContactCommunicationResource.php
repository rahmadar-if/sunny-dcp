<?php

namespace Solaris\MasterData\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Http\Resources\BaseResource;
use Solaris\Core\Helpers\LookupResource;

class ContactCommunicationResource extends BaseResource
{
	protected function list(Request $request): array
	{
		return [
			'id'    => $this->id,
			'type'  => LookupResource::from($this->type),
			'value' => $this->value,
		];
	}

	protected function detail(Request $request): array
	{
		return [
			'id'         => $this->id,
			'type'       => LookupResource::from($this->type),
			'value'      => $this->value,
			'created_at' => $this->created_at,
			'updated_at' => $this->updated_at,
			'created_by' => LookupResource::user($this->created_by),
			'updated_by' => LookupResource::user($this->updated_by),
		];
	}
}
