<?php

namespace Solaris\MasterData\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Http\Resources\BaseResource;
use Solaris\Core\Helpers\LookupResource;

class AccountAddressResource extends BaseResource
{
    protected function list(Request $request): array
    {
        return [
            "id"           => $this->id,
            "address"      => $this->address,
            "postcode"     => $this->postcode,
            "address_type" => LookupResource::from($this->address_type),
            "country"      => LookupResource::from($this->country),
            "province"     => LookupResource::from($this->province),
            "city"         => LookupResource::from($this->city)
        ];
    }

    protected function detail(Request $request): array
    {
        return [
            "id"           => $this->id,
            "address"      => $this->address,
            "postcode"     => $this->postcode,
            "address_type" => LookupResource::from($this->address_type),
            "country"      => LookupResource::from($this->country),
            "province"     => LookupResource::from($this->province),
            "city"         => LookupResource::from($this->city),
            "created_at"   => $this->created_at,
            "updated_at"   => $this->updated_at,
            "created_by"   => LookupResource::user($this->created_by),
            "updated_by"   => LookupResource::user($this->updated_by),
        ];
    }
}
