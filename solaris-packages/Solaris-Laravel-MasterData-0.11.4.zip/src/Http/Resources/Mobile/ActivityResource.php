<?php

namespace Solaris\MasterData\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Http\Resources\BaseResource;
use Solaris\Core\Helpers\LookupResource;

class ActivityResource extends BaseResource
{    
    protected function list(Request $request): array
    {
        return [
            "id"         => $this->id, 
            "subject"    => $this->subject,  
            "start_date" => $this->start_date,
            "end_date"   => $this->end_date,
            "category"   => LookupResource::from($this->category),
            "priority"   => LookupResource::from($this->priority),
            "status"     => LookupResource::from($this->status),
            "account"    => LookupResource::from($this->account),
            "contact"    => LookupResource::from($this->contact),
        ];
    }

    protected function detail(Request $request): array
    {
        $reminders = $this->reminders?->map(function($reminder) {
            $to = LookupResource::user($reminder->to);
            $to['profile_picture'] = !is_null($reminder->to->profile_picture_id) ? route('mobile.images.thumbnail', ['id' => $reminder->to->profile_picture_id]) : null;

            return [
                "id"        => $reminder->id,
                "is_remind" => $reminder->is_remind,
                "remind_at" => $reminder->remind_at,
                "type" => [
                    "id"             => $reminder->type->id,
                    "name"           => $reminder->type->name,
                    "offset_minutes" => (int)$reminder->type->offset_minutes,
                ],
                "to" => $to
            ];
        });

        return [
            "id"           => $this->id,
            "subject"      => $this->subject,
            "start_date"   => $this->start_date,
            "end_date"     => $this->end_date,
            "category"     => LookupResource::from($this->category),
            "priority"     => LookupResource::from($this->priority),
            "status"       => LookupResource::from($this->status),
            "account"      => LookupResource::from($this->account),
            "contact"      => LookupResource::from($this->contact),
            "reminders"    => $reminders,
            "remind_users" => $this->remind_users?->map(fn($remindUser) => LookupResource::user($remindUser)),
            "notes"        => $this->notes,
            "created_at"   => $this->created_at,
            "updated_at"   => $this->updated_at,
            "created_by"   => LookupResource::user($this->created_by),
            "updated_by"   => LookupResource::user($this->updated_by),
        ];
    }
}
