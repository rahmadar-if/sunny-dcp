<?php

namespace Solaris\MasterData\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Http\Resources\BaseResource;
use Solaris\Core\Helpers\LookupResource;

class ProductAvailabilityResource extends BaseResource
{
	protected function list(Request $request): array
	{
		return [
			'id'        => $this->id,
			'warehouse' => $this->warehouse,
			'qty'       => $this->qty,
			'address'   => $this->address,
			'country'   => LookupResource::from($this->country),
			'province'  => LookupResource::from($this->province),
			'city'      => LookupResource::from($this->city),
			'post_code' => $this->post_code,
		];
	}

	protected function detail(Request $request): array
	{
		return [
			'id'         => $this->id,
			'warehouse'  => $this->warehouse,
			'qty'        => $this->qty,
			'address'    => $this->address,
			'country'    => LookupResource::from($this->country),
			'province'   => LookupResource::from($this->province),
			'city'       => LookupResource::from($this->city),
			'post_code'  => $this->post_code,
			'created_at' => $this->created_at,
			'updated_at' => $this->updated_at,
			'created_by' => LookupResource::user($this->created_by),
			'updated_by' => LookupResource::user($this->updated_by),
		];
	}
}
