<?php

namespace Solaris\MasterData\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Http\Resources\BaseResource;
use Solaris\Core\Helpers\LookupResource;

class ProductResource extends BaseResource
{    
    protected function list(Request $request): array
    {
        return [
            "id"              => $this->id, 
            "name"            => $this->name, 
            "product_picture" => LookupResource::image($this->product_picture_id)['thumbnail'], 
            "availability"    => (int) $this->availability,
            "unit_of_measure" => $this->unit_of_measure,
            "price"           => floatval($this->price),
            "active"          => (bool) $this->active,
            "type"            => LookupResource::from($this->type),
            "sku_number"      => $this->sku_number,
            "category"        => $this->category,
            "brand"           => $this->brand,
        ];
    }

    protected function detail(Request $request): array
    {
        return [
            "id"                  => $this->id,
            "name"                => $this->name,
            "product_picture"     => LookupResource::image($this->product_picture_id),
            "availability"        => (int) $this->availability,
            "unit_of_measure"     => $this->unit_of_measure,
            "sku_number"          => $this->sku_number,
            "category"            => $this->category,
            "brand"               => $this->brand,
            "price"               => floatval($this->price),
            "active"              => (bool) $this->active,
            "type"                => LookupResource::from($this->type),
            "product_description" => $this->product_description,
            "notes"               => $this->notes,
            "created_at"          => $this->created_at,
            "updated_at"          => $this->updated_at,
            "created_by"          => LookupResource::user($this->created_by),
            "updated_by"          => LookupResource::user($this->updated_by),
        ];
    }
}
