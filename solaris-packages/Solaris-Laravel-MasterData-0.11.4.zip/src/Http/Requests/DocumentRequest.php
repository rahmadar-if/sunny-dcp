<?php

namespace Solaris\MasterData\Http\Requests;

use Solaris\Core\Http\Requests\BaseFormRequest;

class DocumentRequest extends BaseFormRequest
{
    public function rules(): array
    {
        $rules = match ($this->method()) {
            'POST'  => static::createRules(),
            'PUT'   => static::updateRules()
        };

        return $rules;
    }

    public static function createRules(): array
    {
        return [
            'account_id' => 'nullable|uuid',
            'contact_id' => 'nullable|uuid',
            'date'       => 'required|date_format:Y-m-d',
            'type_id'    => 'required|uuid',
            'status_id'  => 'required|uuid',
            'notes'      => 'nullable|string',
        ];
    }

    public static function updateRules(): array
    {
        return array_merge(static::createRules(), [
            'notes' => 'required|string',
        ]);
    }
}