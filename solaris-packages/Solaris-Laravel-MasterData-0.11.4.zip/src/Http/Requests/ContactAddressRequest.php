<?php

namespace Solaris\MasterData\Http\Requests;

use Solaris\Core\Http\Requests\BaseFormRequest;

class ContactAddressRequest extends BaseFormRequest
{
    public function rules(): array
    {
        return match ($this->method()) {
            'POST' => static::createRules(),
            'PUT'  => static::updateRules(),
        };
    }

    public static function createRules(): array
    {
        return array_merge(static::updateRules(), [
            'contact_id' => 'required|uuid',
        ]);
    }

    public static function updateRules(): array
    {
        return [
            'address_type_id' => 'required|uuid',
            'address'          => 'required|string',
            'postcode'         => 'nullable|string|max:255',
            'country_id'       => 'nullable|uuid',
            'province_id'      => 'nullable|uuid',
            'city_id'          => 'nullable|uuid',
        ];
    }
}