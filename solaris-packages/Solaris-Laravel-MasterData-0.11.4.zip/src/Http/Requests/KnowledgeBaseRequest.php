<?php

namespace Solaris\MasterData\Http\Requests;

use Solaris\Core\Http\Requests\BaseFormRequest;

class KnowledgeBaseRequest extends BaseFormRequest
{
    public function rules(): array
    {
        return match ($this->method()) {
            'POST'  => static::createRules(),
            'PUT'   => static::updateRules(),
        };
    }

    public static function createRules(): array
    {
        return [
            'name'    => 'required|string|max:255',
            'type_id' => 'required|uuid',
        ];
    }

    public static function updateRules(): array
    {
        return array_merge(static::createRules(), [
            'status_id' => 'required|uuid',
            'article'   => 'required|string',
        ]);
    }
}
