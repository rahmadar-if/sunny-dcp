<?php

namespace Solaris\MasterData\Http\Requests;

use Solaris\Core\Http\Requests\BaseFormRequest;

class ContactCommunicationRequest extends BaseFormRequest
{
    public function rules(): array
    {
        return match ($this->method()) {
            'POST' => static::createRules(),
            'PUT'  => static::updateRules(),
        };
    }

    public static function createRules(): array
    {
        return array_merge(static::updateRules(), [
            'contact_id' => 'required|uuid',
        ]);
    }

    public static function updateRules(): array
    {
        return [
            'type_id' => 'required|uuid',
            'value'   => 'required|string',
        ];
    }
}