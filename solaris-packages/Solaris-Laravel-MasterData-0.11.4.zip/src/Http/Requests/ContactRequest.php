<?php

namespace Solaris\MasterData\Http\Requests;

use Closure;
use Illuminate\Support\Arr;
use Solaris\Core\Http\Requests\BaseFormRequest;

class ContactRequest extends BaseFormRequest
{
    public function rules(): array
    {
        if($this->routeIs('master-data.contact.update.avatar', 'mobile.master-data.contact.update.avatar')) {
            return [
                'profile_picture' => $this->pictureValidation()
            ];
        }

        $rules = match ($this->method()) {
            // The API has no two-step create, so it opens every writable field at once.
            'POST'  => $this->is('api/v1/*') ? static::apiCreateRules() : static::createRules(),
            'PUT'   => static::updateRules(),
            'PATCH' => static::patchRules(),
        };

        return $rules;
    }

    public static function createRules(): array
    {
        return [
            'name'                 => 'required|string|max:255',
            'job_title'            => 'nullable|string|max:255',
            'primary_phone'        => 'required|string|max:50',
            'primary_mobile_phone' => 'required|string|max:50',
            'email'                => 'nullable|string|email|max:255',
            'account_id'           => 'nullable|uuid',
        ];
    }

    public static function updateRules(): array
    {
        return array_merge(Arr::except(static::createRules(), 'profile_picture'), [
            'salutation_id'         => 'nullable|uuid',
            'also_known_as'         => 'nullable|string|max:255',
            'birth_date'            => 'nullable|date_format:Y-m-d',
            'gender_id'             => 'nullable|uuid',
            'education_id'          => 'nullable|uuid',
            'religion_id'           => 'nullable|uuid',
            'marital_status_id'     => 'nullable|uuid',
            'notes'                 => 'nullable|string',
            'recipients_name'       => 'nullable|string|max:255',
            'preferred_language_id' => 'nullable|uuid',
        ]);
    }
}
