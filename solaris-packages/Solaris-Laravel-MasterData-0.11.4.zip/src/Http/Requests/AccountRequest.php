<?php

namespace Solaris\MasterData\Http\Requests;

use Solaris\Core\Http\Requests\BaseFormRequest;

class AccountRequest extends BaseFormRequest
{
    public function rules(): array
    {
        if($this->routeIs('master-data.account.update.avatar', 'mobile.master-data.account.update.avatar')) {
            return [
                'profile_picture' => $this->pictureValidation()
            ];
        }

        $rules = match ($this->method()) {
            // The API has no two-step create, so it opens every writable field at once.
            'POST'  => $this->is('api/v1/*') ? static::apiCreateRules() : static::createRules(),
            'PUT'   => static::updateRules(),
            'PATCH' => static::patchRules(),
        };

        return $rules;
    }

    public static function createRules(): array
    {
        return [
            'name'               => 'required|string|max:255',
            'type_id'            => 'required|uuid',
            'primary_contact_id' => 'nullable|uuid',
            'primary_phone'      => 'required|string|max:50',
            'email'              => 'required|string|email|max:255',
            'category'           => 'nullable|string|max:255',
            'industry_id'        => 'required|uuid'
        ];
    }

    public static function updateRules(): array
    {
        return array_merge(static::createRules(), [
            'also_known_as'         => 'nullable|string|max:255',
            'website'               => 'nullable|string|max:255',
            'business_entity_id'    => 'nullable|uuid',
            'notes'                 => 'nullable|string',
            'number_of_employee_id' => 'nullable|uuid'
        ]);
    }
}