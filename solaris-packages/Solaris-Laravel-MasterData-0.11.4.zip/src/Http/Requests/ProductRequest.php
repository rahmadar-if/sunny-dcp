<?php

namespace Solaris\MasterData\Http\Requests;

use Solaris\Core\Http\Requests\BaseFormRequest;

class ProductRequest extends BaseFormRequest
{
    public function rules(): array
    {
        if($this->routeIs('master-data.product.update.avatar', 'mobile.master-data.product.update.avatar')) {
            return [
                'product_picture' => $this->pictureValidation()
            ];
        }

        $isApi = $this->is('api/v1/*');

        $rules = match ($this->method()) {
            // The API has no two-step create, so it opens every writable field at once.
            'POST'  => $isApi ? static::apiCreateRules() : static::createRules(),
            'PUT'   => $isApi ? static::apiUpdateRules() : static::updateRules(),
            'PATCH' => static::patchRules(),
        };

        return $rules;
    }

    public static function createRules(): array
    {
        return [
            'name'            => 'required|string|max:255',
            'price'           => 'nullable|numeric|min:0',
            'type_id'         => 'required|uuid',
            'unit_of_measure' => 'required|string|max:255',
            'sku_number'      => 'nullable|string|max:255',
            'category'        => 'nullable|string|max:255',
            'brand'           => 'nullable|string|max:255',
            'active'          => 'boolean',
        ];
    }

    public static function updateRules(): array
    {
        return array_merge(static::createRules(), [
            'product_description' => 'nullable|string|max:500',
            'notes'               => 'nullable|string'
        ]);
    }
}
