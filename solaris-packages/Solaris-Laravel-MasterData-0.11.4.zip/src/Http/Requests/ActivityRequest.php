<?php

namespace Solaris\MasterData\Http\Requests;

use Solaris\MasterData\Const\ActivityStatusConst;
use Solaris\Core\Http\Requests\BaseFormRequest;

class ActivityRequest extends BaseFormRequest
{
    public function rules(): array
    {
        $isApi = $this->is('api/v1/*');

        $rules = match ($this->method()) {
            // The API has no two-step create, so it opens every writable field at once.
            'POST'  => $isApi ? static::apiCreateRules() : static::createRules(),
            'PUT'   => $isApi ? static::apiUpdateRules() : static::updateRules(),
            'PATCH' => static::patchRules(),
        };

        return $rules;
    }

    /**
     * Reminders are shaped by the web form — a checkbox list, plus a recipient list of internal
     * users — so they are not part of the API contract and never reach the repository from there.
     */
    public static function apiExcluded(): array
    {
        return [
            'remind_me',
            'reminder_types',
            'reminder_types.*.id',
            'reminder_types.*.checked',
            'remind_to',
        ];
    }

    /**
     * Both rules below read a second field out of the request, which relaxRequired() cannot keep
     * intact on its own:
     *
     * - after_or_equal:start_date compares against the request, not the stored record. Sending
     *   end_date alone would compare against the literal string and always fail, so start_date
     *   has to travel with it.
     * - required_if never fires under 'sometimes', because an absent field skips every rule on it.
     *   Left unconditional so finishing an activity still demands an end date.
     */
    public static function patchRules(): array
    {
        return array_merge(parent::patchRules(), [
            'start_date' => ['sometimes', 'date', 'required_with:end_date'],
            'end_date'   => [
                'nullable',
                'date',
                'after_or_equal:start_date',
                'required_if:status_id,' . ActivityStatusConst::Finish,
            ],
        ]);
    }

    public static function createRules(): array
    {
        return [
            'subject'                  => 'required|string|max:255',
            'start_date'               => 'required|date',
            'end_date'                 => [
                'nullable',
                'date',
                'after_or_equal:start_date',
                'required_if:status_id,' . ActivityStatusConst::Finish,
            ],
            'category_id'              => 'required|uuid',
            'priority_id'              => 'required|uuid',
            'account_id'               => 'nullable|uuid',
            'contact_id'               => 'nullable|uuid',
            'remind_me'                => 'nullable|boolean',
            'reminder_types'           => 'required_if:remind_me,1|array',
            'reminder_types.*.id'      => 'required_with:reminder_types|string',
            'reminder_types.*.checked' => 'required_with:reminder_types|boolean',
            'remind_to'                => 'nullable',
        ];
    }

    public static function updateRules(): array
    {
        return array_merge(static::createRules(), [
            'status_id' => 'nullable|uuid',
            'notes'     => 'nullable|string',
        ]);
    }
}
