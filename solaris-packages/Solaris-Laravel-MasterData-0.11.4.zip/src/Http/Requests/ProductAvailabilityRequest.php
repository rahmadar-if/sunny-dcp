<?php

namespace Solaris\MasterData\Http\Requests;

use Solaris\Core\Http\Requests\BaseFormRequest;

class ProductAvailabilityRequest extends BaseFormRequest
{
    public function rules(): array
    {
        return match ($this->method()) {
            'POST' => static::createRules(),
            'PUT'  => static::updateRules(),
        };
    }

    public static function createRules(): array
    {
        return array_merge(static::updateRules(), [
            'product_id' => 'required|uuid',
        ]);
    }

    public static function updateRules(): array
    {
        return [
            'warehouse'   => 'required|string',
            'address'     => 'nullable|string',
            'qty'         => 'required|int',
            'country_id'  => 'nullable|uuid',
            'province_id' => 'nullable|uuid',
            'city_id'     => 'nullable|uuid',
            'post_code'   => 'nullable|string|max:255',
        ];
    }
}