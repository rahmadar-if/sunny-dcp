<?php

namespace Solaris\MasterData\Http\Controllers\Api;

use Solaris\Core\Docs\Api\ApiEntity;
use Solaris\Core\Docs\Api\ApiField;
use Solaris\Core\Docs\Api\ApiOperation;
use Solaris\Core\Http\Controllers\Api\BaseApiController;

/**
 * Single layer on purpose. BaseCRM and Sales both replace the Product model, but only to add
 * lookup scopes for their own selection screens — neither adds a column, a repository or a form
 * request, so there is nothing for them to extend here.
 */
class ProductController extends BaseApiController
{
    public function key(): string
    {
        return 'product';
    }

    // product_picture is left out: a file upload, outside plain CRUD, same as on Account and
    // Contact. Features, stock per warehouse and price history are separate entities.
    public function columns(): array
    {
        return [
            'id',
            'name',
            'sku_number',
            'type',
            'category',
            'brand',
            'unit_of_measure',
            'price',
            'availability',
            'active',
            'product_description',
            'notes',
            'created_at',
            'updated_at',
            'created_by',
            'updated_by',
        ];
    }

    public function relations(): array
    {
        return ['type'];
    }

    public function searchColumns(): array
    {
        return ['name', 'unit_of_measure', 'sku_number', 'category', 'brand'];
    }

    public function entityDocs(): ApiEntity
    {
        return ApiEntity::make('Product')
            ->description('Goods and services you sell.');
    }

    public function fieldDocs(): array
    {
        return [
            'id'                  => ApiField::uuid('Unique identifier.')->readOnly(),
            'name'                => ApiField::string('Product name.')->example('Solar Panel 450Wp'),
            'sku_number'          => ApiField::string('Stock keeping unit.')->example('SP-450-MONO'),
            'type'                => ApiField::lookup('Whether this is goods or a service.'),
            'category'            => ApiField::string('Free text category.')->example('Solar Panel'),
            'brand'               => ApiField::string('Brand name.')->example('Sunny'),
            'unit_of_measure'     => ApiField::string('Unit the product is sold in.')->example('pcs'),
            'price'               => ApiField::decimal('List price per unit.')->example(2750000),
            // Stock is entered per warehouse, so nothing writes this column directly.
            'availability'        => ApiField::decimal('Total stock on hand across warehouses.')->example(120)->readOnly(),
            'active'              => ApiField::boolean('Whether the product can still be sold.'),
            'product_description' => ApiField::string('Short description, up to 500 characters.'),
            'notes'               => ApiField::text('Rich text notes. HTML is accepted.'),
            'created_at'          => ApiField::dateTime('When the record was created.')->readOnly(),
            'updated_at'          => ApiField::dateTime('When the record was last changed.')->readOnly(),
            'created_by'          => ApiField::user('Who created the record.')->readOnly(),
            'updated_by'          => ApiField::user('Who last changed the record.')->readOnly(),
        ];
    }

    public function endpointDocs(): array
    {
        return [
            'index'  => ApiOperation::make('List products'),
            'search' => ApiOperation::make('Search products')
                ->description('Same as the list endpoint, but accepts the full Filter DSL in the body instead of a query string.'),
            'show'   => ApiOperation::make('Get one product'),
            'store'  => ApiOperation::make('Create a product')
                ->description("The type accepts either an id (`type_id`) or a name (`type`). A name that matches more than one record is rejected rather than guessed.\n\nStock is not set here — it is held per warehouse.\n\nSend an `Idempotency-Key` header so a retried request cannot create a duplicate."),
            'update' => ApiOperation::make('Update a product')
                ->description('Partial update — only the fields you send are changed. Fields you omit are left untouched. Send an explicit `null` to clear a field.'),
            'replace' => ApiOperation::make('Update a product (full)')
                ->description("Same effect as the partial update, but every required field must be present — use it when you are submitting a complete record and want that checked.\n\nFields you omit are still left untouched; this endpoint does not blank them."),
            'destroy' => ApiOperation::make('Delete a product'),
        ];
    }
}
