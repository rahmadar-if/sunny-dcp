<?php

namespace Solaris\MasterData\Http\Controllers\Api;

use Solaris\Core\Docs\Api\ApiEntity;
use Solaris\Core\Docs\Api\ApiField;
use Solaris\Core\Docs\Api\ApiOperation;
use Solaris\Core\Http\Controllers\Api\BaseApiController;

class AccountController extends BaseApiController
{
    public function key(): string
    {
        return 'account';
    }

    /**
     * The public contract. Deliberately explicit rather than derived from the table: notes_plain
     * is an internal search column, and a column added later must be an opt-in decision, not
     * something a partner discovers on its own.
     */
    public function columns(): array
    {
        return [
            'id',
            'name',
            'also_known_as',
            'primary_phone',
            'email',
            'website',
            'category',
            'notes',
            'type',
            'industry',
            'business_entity',
            'number_of_employee',
            'primary_contact',
            'created_at',
            'updated_at',
            'created_by',
            'updated_by',
        ];
    }

    public function relations(): array
    {
        return [
            'type',
            'industry',
            'business_entity',
            'number_of_employee',
            'primary_contact',
        ];
    }

    public function searchColumns(): array
    {
        return ['name', 'primary_phone', 'email'];
    }

    public function entityDocs(): ApiEntity
    {
        return ApiEntity::make('Account')
            ->description('Companies and organisations you do business with.');
    }

    public function fieldDocs(): array
    {
        return [
            'id'                 => ApiField::uuid('Unique identifier.')->readOnly(),
            'name'               => ApiField::string('Registered company name.')->example('PT Sinar Jaya Abadi'),
            'also_known_as'      => ApiField::string('Trading or short name.')->example('Sinar Jaya'),
            'primary_phone'      => ApiField::string('Main contact number. E.164 preferred.')->example('+628123456789'),
            'email'              => ApiField::email('Main contact email.')->example('info@sinarjaya.co.id'),
            'website'            => ApiField::url('Company website.')->example('https://sinarjaya.co.id'),
            'category'           => ApiField::string('Free text label for your own grouping.')->example('Key Account'),
            'notes'              => ApiField::text('Rich text notes. HTML is accepted.'),
            'type'               => ApiField::lookup('Account type, e.g. customer or prospect.'),
            'industry'           => ApiField::lookup('Industry classification.'),
            'business_entity'    => ApiField::lookup('Legal form of the company.'),
            'number_of_employee' => ApiField::lookup('Employee count bracket.'),
            'primary_contact'    => ApiField::lookup('Main person to contact at this account.'),
            'created_at'         => ApiField::dateTime('When the record was created.')->readOnly(),
            'updated_at'         => ApiField::dateTime('When the record was last changed.')->readOnly(),
            'created_by'         => ApiField::user('Who created the record.')->readOnly(),
            'updated_by'         => ApiField::user('Who last changed the record.')->readOnly(),
        ];
    }

    public function endpointDocs(): array
    {
        return [
            'index'  => ApiOperation::make('List accounts'),
            'search' => ApiOperation::make('Search accounts')
                ->description('Same as the list endpoint, but accepts the full Filter DSL in the body instead of a query string.'),
            'show'   => ApiOperation::make('Get one account'),
            'store'  => ApiOperation::make('Create an account')
                ->description("Lookup fields accept either an id (`industry_id`) or a name (`industry`). A name that matches more than one record is rejected rather than guessed.\n\nSend an `Idempotency-Key` header so a retried request cannot create a duplicate."),
            'update' => ApiOperation::make('Update an account')
                ->description('Partial update — only the fields you send are changed. Fields you omit are left untouched. Send an explicit `null` to clear a field.'),
            'replace' => ApiOperation::make('Update an account (full)')
                ->description("Same effect as the partial update, but every required field must be present — use it when you are submitting a complete record and want that checked.\n\nFields you omit are still left untouched; this endpoint does not blank them."),
            'destroy' => ApiOperation::make('Delete an account'),
        ];
    }
}
