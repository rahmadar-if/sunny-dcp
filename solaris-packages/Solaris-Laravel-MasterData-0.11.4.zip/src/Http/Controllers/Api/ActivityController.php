<?php

namespace Solaris\MasterData\Http\Controllers\Api;

use Solaris\Core\Docs\Api\ApiEntity;
use Solaris\Core\Docs\Api\ApiField;
use Solaris\Core\Docs\Api\ApiOperation;
use Solaris\Core\Http\Controllers\Api\BaseApiController;

class ActivityController extends BaseApiController
{
    public function key(): string
    {
        return 'activity';
    }

    /**
     * Relation names where the mobile controller lists raw ids, so category, priority and status
     * come out as objects here — the same shape every other lookup has across the API.
     *
     * Reminders are not part of the contract: their payload is shaped by the web form, and the
     * people they notify are internal users. See ActivityRequest::apiExcluded().
     */
    public function columns(): array
    {
        return [
            'id',
            'subject',
            'start_date',
            'end_date',
            'category',
            'priority',
            'status',
            'account',
            'contact',
            'notes',
            'created_at',
            'updated_at',
            'created_by',
            'updated_by',
        ];
    }

    public function relations(): array
    {
        return ['category', 'priority', 'status', 'account', 'contact'];
    }

    public function searchColumns(): array
    {
        return ['subject'];
    }

    public function entityDocs(): ApiEntity
    {
        return ApiEntity::make('Activity')
            ->description('Scheduled work against an account or contact — calls, meetings, to-dos.');
    }

    public function fieldDocs(): array
    {
        return [
            'id'         => ApiField::uuid('Unique identifier.')->readOnly(),
            'subject'    => ApiField::string('What the activity is about.')->example('Follow-up call on quotation'),
            'start_date' => ApiField::dateTime('When the activity starts.')->example('2026-08-20T09:00:00Z'),
            'end_date'   => ApiField::dateTime('When the activity ends. Required once the status is set to finished.')->example('2026-08-20T10:00:00Z'),
            'category'   => ApiField::lookup('Kind of activity, e.g. call, meeting or to-do.'),
            'priority'   => ApiField::lookup('Priority level.'),
            'status'     => ApiField::lookup('Progress of the activity.'),
            'account'    => ApiField::lookup('Account the activity belongs to.'),
            'contact'    => ApiField::lookup('Person the activity is with.'),
            'notes'      => ApiField::text('Rich text notes. HTML is accepted.'),
            'created_at' => ApiField::dateTime('When the record was created.')->readOnly(),
            'updated_at' => ApiField::dateTime('When the record was last changed.')->readOnly(),
            'created_by' => ApiField::user('Who created the record.')->readOnly(),
            'updated_by' => ApiField::user('Who last changed the record.')->readOnly(),
        ];
    }

    public function endpointDocs(): array
    {
        return [
            'index'  => ApiOperation::make('List activities'),
            'search' => ApiOperation::make('Search activities')
                ->description('Same as the list endpoint, but accepts the full Filter DSL in the body instead of a query string. Use it to pull a date range, in place of a calendar endpoint.'),
            'show'   => ApiOperation::make('Get one activity'),
            'store'  => ApiOperation::make('Create an activity')
                ->description("Lookup fields accept either an id (`category_id`) or a name (`category`). A name that matches more than one record is rejected rather than guessed.\n\nReminders cannot be set through the API; they are managed from the application.\n\nSend an `Idempotency-Key` header so a retried request cannot create a duplicate."),
            'update' => ApiOperation::make('Update an activity')
                ->description("Partial update — only the fields you send are changed. Fields you omit are left untouched. Send an explicit `null` to clear a field.\n\nTwo rules span fields: sending `end_date` also requires `start_date`, and setting the status to finished requires `end_date`."),
            'replace' => ApiOperation::make('Update an activity (full)')
                ->description("Same effect as the partial update, but every required field must be present — use it when you are submitting a complete record and want that checked.\n\nFields you omit are still left untouched; this endpoint does not blank them."),
            'destroy' => ApiOperation::make('Delete an activity'),
        ];
    }
}
