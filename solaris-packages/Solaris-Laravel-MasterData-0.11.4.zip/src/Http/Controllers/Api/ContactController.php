<?php

namespace Solaris\MasterData\Http\Controllers\Api;

use Solaris\Core\Docs\Api\ApiEntity;
use Solaris\Core\Docs\Api\ApiField;
use Solaris\Core\Docs\Api\ApiOperation;
use Solaris\Core\Http\Controllers\Api\BaseApiController;

class ContactController extends BaseApiController
{
    public function key(): string
    {
        return 'contact';
    }

    /**
     * Left out on purpose: profile_picture (a file upload, outside plain CRUD), notes_plain (an
     * internal search column) and degree (a column no rule set accepts, so nothing can write it).
     */
    public function columns(): array
    {
        return [
            'id',
            'name',
            'also_known_as',
            'recipients_name',
            'salutation',
            'job_title',
            'primary_phone',
            'primary_mobile_phone',
            'email',
            'account',
            'gender',
            'birth_date',
            'marital_status',
            'religion',
            'education',
            'preferred_language',
            'notes',
            'created_at',
            'updated_at',
            'created_by',
            'updated_by',
        ];
    }

    public function relations(): array
    {
        return [
            'salutation',
            'account',
            'gender',
            'marital_status',
            'religion',
            'education',
            'preferred_language',
        ];
    }

    public function searchColumns(): array
    {
        return ['name', 'job_title', 'primary_phone', 'email'];
    }

    public function entityDocs(): ApiEntity
    {
        return ApiEntity::make('Contact')
            ->description('People you deal with, optionally attached to an account.');
    }

    public function fieldDocs(): array
    {
        return [
            'id'                   => ApiField::uuid('Unique identifier.')->readOnly(),
            'name'                 => ApiField::string('Full name.')->example('Budi Santoso'),
            'also_known_as'        => ApiField::string('Nickname or preferred short name.')->example('Budi'),
            'recipients_name'      => ApiField::string('Name to address the person by in correspondence.')->example('Bapak Budi Santoso'),
            'salutation'           => ApiField::lookup('Form of address.'),
            'job_title'            => ApiField::string('Role at the account.')->example('Procurement Manager'),
            'primary_phone'        => ApiField::string('Landline or office number. E.164 preferred.')->example('+62215550123'),
            'primary_mobile_phone' => ApiField::string('Mobile number. E.164 preferred.')->example('+628123456789'),
            'email'                => ApiField::email('Contact email.')->example('budi@sinarjaya.co.id'),
            'account'              => ApiField::lookup('Account this person belongs to.'),
            'gender'               => ApiField::lookup('Gender.'),
            'birth_date'           => ApiField::date('Date of birth.')->example('1985-04-17'),
            'marital_status'       => ApiField::lookup('Marital status.'),
            'religion'             => ApiField::lookup('Religion.'),
            'education'            => ApiField::lookup('Highest level of education.'),
            'preferred_language'   => ApiField::lookup('Language to communicate in.'),
            'notes'                => ApiField::text('Rich text notes. HTML is accepted.'),
            'created_at'           => ApiField::dateTime('When the record was created.')->readOnly(),
            'updated_at'           => ApiField::dateTime('When the record was last changed.')->readOnly(),
            'created_by'           => ApiField::user('Who created the record.')->readOnly(),
            'updated_by'           => ApiField::user('Who last changed the record.')->readOnly(),
        ];
    }

    public function endpointDocs(): array
    {
        return [
            'index'  => ApiOperation::make('List contacts'),
            'search' => ApiOperation::make('Search contacts')
                ->description('Same as the list endpoint, but accepts the full Filter DSL in the body instead of a query string.'),
            'show'   => ApiOperation::make('Get one contact'),
            'store'  => ApiOperation::make('Create a contact')
                ->description("Lookup fields accept either an id (`account_id`) or a name (`account`). A name that matches more than one record is rejected rather than guessed.\n\nSend an `Idempotency-Key` header so a retried request cannot create a duplicate."),
            'update' => ApiOperation::make('Update a contact')
                ->description('Partial update — only the fields you send are changed. Fields you omit are left untouched. Send an explicit `null` to clear a field.'),
            'replace' => ApiOperation::make('Update a contact (full)')
                ->description("Same effect as the partial update, but every required field must be present — use it when you are submitting a complete record and want that checked.\n\nFields you omit are still left untouched; this endpoint does not blank them."),
            'destroy' => ApiOperation::make('Delete a contact'),
        ];
    }
}
