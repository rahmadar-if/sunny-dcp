<?php

namespace Solaris\MasterData\Http\Controllers\Mobile;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Core\Models\Attachment;
use Solaris\MasterData\Http\Requests\AccountRequest;
use Solaris\MasterData\Http\Resources\Mobile\AccountResource;
use Solaris\MasterData\Repositories\AccountRepository;

class AccountController
{
    /** @var AccountRepository */
    protected $repo;

    public function __construct()
    {
        $this->repo = new (Helper::repository('account'))(new (Helper::model('account')));
    }

    public function index(Request $request): JsonResponse
    {
        $search = $request->input('search');
        $data   = $this->repo->list(
            columns : $this->listColumn(),
            search  : !empty($this->searchColumn()) ? ['search' => $search, 'columns' => $this->searchColumn()] : $search, 
            filter  : $request->input('filter'),
            sort    : $request->input('sort'),
            page    : $request->input('page'),
            length  : $request->input('length'),
        );
        return SolarResponse::list(Helper::mobileResouces('account'), $data);
    }

    public function show(string $id): AccountResource
    {
        $data = $this->repo->findComplete($id, $this->detailColumns());
        return new (Helper::mobileResouces('account'))($data);
    }

    public function store(): JsonResponse
    {
        /** @var AccountRequest $request */
        $request = app(Helper::formRequest("account"));
        $data    = $this->repo->create($request->cleanData());

        return SolarResponse::success(['id' => $data->id]);
    }

    public function update(string $id): JsonResponse
    {
        /** @var AccountRequest $request */
        $request = app(Helper::formRequest("account"));
        $data    = $this->repo->update($id, $request->cleanData());

        return SolarResponse::success(['id' => $data->id]);
    }

    public function destroy(string $id): JsonResponse
    {
        return SolarResponse::deleted($this->repo->delete($id));
    }

    public function updateAvatar(string $id): JsonResponse
    {
        /** @var AccountRequest $request */
        $request = app(Helper::formRequest("account"));
        $result  = null;
        try {
            if(!$request->hasFile('profile_picture')) {
                throw new \Exception("File upload not found");
            }

            $upload = $this->repo->uploadFile($request, 'profile_picture_id', $id);
            $result = $upload instanceof Attachment ? ['id' => $upload->id] : $upload;
        } catch (\Exception $e) {
            return SolarResponse::error($e->getMessage());
        }

        return SolarResponse::success($result);
    }

    public function listColumn(): array
    {
        return [
            "id",
            "name",
            "profile_picture",
            "industry",
            "type",
            "primary_phone",
            "email",
        ];
    }

    public function detailColumns(): array
    {
        return [
            "id",
            "name",
            "profile_picture",
            "also_known_as",
            "primary_phone",
            "email",
            "primary_contact",
            "type",
            "industry",
            "business_entity",
            "business_size",
            "number_of_employee",
            "category",
            "notes",
            "created_at",
            "updated_at",
            "created_by",
            "updated_by",
        ];
    }

    public function searchColumn(): array
    {
        return [
            "name",
            "primary_phone",
            "email"
        ];
    }
}
