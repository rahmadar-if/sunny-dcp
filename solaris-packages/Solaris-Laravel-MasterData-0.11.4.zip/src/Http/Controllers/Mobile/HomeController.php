<?php

namespace Solaris\MasterData\Http\Controllers\Mobile;

use Illuminate\Http\JsonResponse;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\MasterData\Http\Resources\Mobile\ActivityResource;
use Solaris\MasterData\Repositories\ActivityRepository;

class HomeController
{
    public function index(): JsonResponse
    {
        return response()->json($this->buildIndexData());
    }

    protected function buildIndexData(): array
    {
        return [
            'today_activity' => $this->getTodayActivity(),
        ];
    }

    protected function getTodayActivity(): mixed
    {
        /** @var ActivityRepository */
        $repo = new (Helper::repository('activity'))(new (Helper::model('activity')));
        return ActivityResource::collection($repo->todayActivity());
    }

    public function todayActivity(): JsonResponse
    {
        /** @var ActivityRepository */
        $repo = new (Helper::repository('activity'))(new (Helper::model('activity')));
        return SolarResponse::list(ActivityResource::class, $repo->todayActivity());
    }
}