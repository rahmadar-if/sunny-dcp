<?php

namespace Solaris\MasterData\Http\Controllers\Mobile;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\MasterData\Http\Requests\ActivityRequest;
use Solaris\MasterData\Http\Resources\Mobile\ActivityResource;
use Solaris\MasterData\Repositories\ActivityRepository;

class ActivityController
{
    /** @var ActivityRepository */
    protected $repo;

    public function __construct()
    {
        $this->repo = new (Helper::repository('activity'))(new (Helper::model('activity')));
    }

    public function index(Request $request): JsonResponse
    {
        $search = $request->input('search');
        $data   = $this->repo->list(
            columns : $this->listColumn(),
            search  : !empty($this->searchColumn()) ? ['search' => $search, 'columns' => $this->searchColumn()] : $search, 
            filter  : $request->input('filter'),
            sort    : $request->input('sort'),
            page    : $request->input('page'),
            length  : $request->input('length'),
        );
        return SolarResponse::list(Helper::mobileResouces('activity'), $data);
    }

    public function calendar(Request $request): JsonResponse
    {
        $start = $request->input('start_date');
        $end   = $request->input('end_date');

        return SolarResponse::list(Helper::mobileResouces('activity'), $this->repo->calendar($start, $end));
    }

    public function show(string $id): ActivityResource
    {
        $data = $this->repo->findComplete($id, $this->detailColumns());
        return new (Helper::mobileResouces('activity'))($data);
    }

    public function store(): JsonResponse
    {
        /** @var ActivityRequest $request */
        $request = app(Helper::formRequest("activity"));
        $data    = $this->repo->create($request->cleanData());

        return SolarResponse::success(['id' => $data->id]);
    }

    public function update(string $id): JsonResponse
    {
        /** @var ActivityRequest $request */
        $request = app(Helper::formRequest("activity"));
        $data    = $this->repo->update($id, $request->cleanData());

        return SolarResponse::success(['id' => $data->id]);
    }

    public function destroy(string $id): JsonResponse
    {
        return SolarResponse::deleted($this->repo->delete($id));
    }

    public function listColumn(): array
    {
        return [
            "id",
            "subject",
            "start_date",
            "end_date",
            "category_id",
            "priority_id",
            "status_id",
            "account_id",
            "contact_id",
        ];
    }

    public function detailColumns(): array
    {
        return [
            "id",
            "subject",
            "start_date",
            "end_date",
            "category_id",
            "priority_id",
            "status_id",
            "account_id",
            "contact_id",
            "notes",
            "created_at",
            "updated_at",
            "created_by",
            "updated_by",
        ];
    }

    public function searchColumn(): array
    {
        return [
            "subject"
        ];
    }
}
