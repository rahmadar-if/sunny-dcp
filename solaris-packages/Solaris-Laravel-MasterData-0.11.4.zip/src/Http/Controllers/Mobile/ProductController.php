<?php

namespace Solaris\MasterData\Http\Controllers\Mobile;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Core\Models\Attachment;
use Solaris\MasterData\Http\Requests\ProductRequest;
use Solaris\MasterData\Http\Resources\Mobile\ProductResource;
use Solaris\MasterData\Repositories\ProductRepository;

class ProductController
{
    protected ProductRepository $repo;

    public function __construct()
    {
        $this->repo = new (Helper::repository('product'))(new (Helper::model('product')));
    }

    public function index(Request $request): JsonResponse
    {
        $search = $request->input('search');
        $data   = $this->repo->list(
            columns : $this->listColumn(),
            search  : !empty($this->searchColumn()) ? ['search' => $search, 'columns' => $this->searchColumn()] : $search, 
            filter  : $request->input('filter'),
            sort    : $request->input('sort'),
            page    : $request->input('page'),
            length  : $request->input('length'),
        );
        return SolarResponse::list(Helper::mobileResouces('product'), $data);
    }

    public function show(string $id): ProductResource
    {
        $data = $this->repo->findComplete($id, $this->detailColumns());
        return new (Helper::mobileResouces('product'))($data);
    }

    public function store(): JsonResponse
    {
        /** @var ProductRequest $request */
        $request = app(Helper::formRequest("product"));
        $data    = $this->repo->create($request->cleanData());

        return SolarResponse::success($data);
    }

    public function update(string $id): JsonResponse
    {
        /** @var ProductRequest $request */
        $request = app(Helper::formRequest("product"));
        $data    = $this->repo->update($id, $request->cleanData());

        return SolarResponse::success($data);
    }

    public function destroy(string $id): JsonResponse
    {
        return SolarResponse::deleted($this->repo->delete($id));
    }

    public function updateAvatar(string $id): JsonResponse
    {
        /** @var ProductRequest $request */
        $request = app(Helper::formRequest("product"));
        $result  = null;
        try {
            if(!$request->hasFile('product_picture')) {
                throw new \Exception("File upload not found");
            }

            $upload = $this->repo->uploadFile($request, 'product_picture_id', $id);
            $result = $upload instanceof Attachment ? ['id' => $upload->id] : $upload;
        } catch (\Exception $e) {
            return SolarResponse::error($e->getMessage());
        }

        return SolarResponse::success($result);
    }

    public function listColumn(): array
    {
        return [
            "id",
            "name",
            "product_picture_id",
            "availability",
            "unit_of_measure",
            "price",
            "active",
            "type",
            "sku_number",
            "category",
            "brand",
        ];
    }

    public function detailColumns(): array
    {
        return [
            "id",
            "name",
            "product_picture_id",
            "availability",
            "unit_of_measure",
            "sku_number",
            "category",
            "brand",
            "price",
            "active",
            "type",
            "product_description",
            "notes",
            "created_at",
            "updated_at",
            "created_by",
            "updated_by",
        ];
    }

    public function searchColumn(): array
    {
        return [
            "name",
            "unit_of_measure",
            "sku_number",
            "category",
            "brand",
        ];
    }
}
