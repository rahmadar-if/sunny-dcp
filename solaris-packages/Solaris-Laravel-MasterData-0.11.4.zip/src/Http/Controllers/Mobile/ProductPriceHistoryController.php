<?php

namespace Solaris\MasterData\Http\Controllers\Mobile;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Core\Repositories\BaseRepository;

class ProductPriceHistoryController
{
	/** @var BaseRepository */
	protected $repo;

	public function __construct()
	{
		$this->repo = new (Helper::repository('product_price_history'))(new (Helper::model('product_price_history')));
	}

	public function index(Request $request): JsonResponse
	{
		$data = $this->repo->list(
			columns : $this->listColumn(),
			search  : $request->input('search'),
			filter  : $request->input('filter'),
			sort    : $request->input('sort'),
			page    : $request->input('page'),
			length  : $request->input('length'),
		);
		return SolarResponse::list(Helper::mobileResouces('product_price_history'), $data);
	}

	public function show(string $id): JsonResponse
	{
		$data = $this->repo->findComplete($id, $this->detailColumns());
		return new (Helper::mobileResouces('product_price_history'))($data);
	}

	public function listColumn(): array
	{
		return [
			'id',
			'price',
			'from',
			'end',
		];
	}

	public function detailColumns(): array
	{
		return [
			'id',
			'price',
			'from',
			'end',
			'product',
			'created_at',
			'updated_at',
			'created_by',
			'updated_by',
		];
	}
}
