<?php

namespace Solaris\MasterData\Http\Controllers\Mobile;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Mail\Attachment;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\MasterData\Http\Requests\ContactRequest;
use Solaris\MasterData\Http\Resources\Mobile\ContactResource;
use Solaris\MasterData\Repositories\ContactRepository;

class ContactController
{
    /** @var ContactRepository */
    protected $repo;

    public function __construct()
    {
        $this->repo = new (Helper::repository('contact'))(new (Helper::model('contact')));
    }

    public function index(Request $request): JsonResponse
    {
        $search = $request->input('search');
        $data   = $this->repo->list(
            columns : $this->listColumn(),
            search  : !empty($this->searchColumn()) ? ['search' => $search, 'columns' => $this->searchColumn()] : $search, 
            filter  : $request->input('filter'),
            sort    : $request->input('sort'),
            page    : $request->input('page'),
            length  : $request->input('length'),
        );
        return SolarResponse::list(Helper::mobileResouces('contact'), $data);
    }

    public function show(string $id): ContactResource
    {
        $data = $this->repo->findComplete($id, $this->detailColumns());
        return new (Helper::mobileResouces('contact'))($data);
    }

    public function store(): JsonResponse
    {
        /** @var ContactRequest $request */
        $request = app(Helper::formRequest("contact"));
        $data    = $this->repo->create($request->cleanData());

        return SolarResponse::success($data);
    }

    public function update(string $id): JsonResponse
    {
        /** @var ContactRequest $request */
        $request = app(Helper::formRequest("contact"));
        $data    = $this->repo->update($id, $request->cleanData());

        return SolarResponse::success($data);
    }

    public function destroy(string $id): JsonResponse
    {
        return SolarResponse::deleted($this->repo->delete($id));
    }

    public function updateAvatar(string $id): JsonResponse
    {
        /** @var ContactRequest $request */
        $request = app(Helper::formRequest("contact"));
        $result  = null;
        try {
            if(!$request->hasFile('profile_picture')) {
                throw new \Exception("File upload not found");
            }

            $upload = $this->repo->uploadFile($request, 'profile_picture_id', $id);
            $result = $upload instanceof Attachment ? ['id' => $upload->id] : $upload;
        } catch (\Exception $e) {
            return SolarResponse::error($e->getMessage());
        }

        return SolarResponse::success($result);
    }

    public function listColumn(): array
    {
        return [
            "id",
            "name",
            "profile_picture",
            "job_title",
            "primary_phone",
            "primary_mobile_phone",
            "email",
        ];
    }

    public function detailColumns(): array
    {
        return [
            "id",
            "name",
            "profile_picture",
            "primary_phone",
            "primary_mobile_phone",
            "account",
            "salutation",
            "also_known_as",
            "recipients_name",
            "gender",
            "birth_date",
            "marital_status",
            "religion",
            "education",
            "preferred_language",
            "job_title",
            "degree",
            "notes",
            "created_at",
            "updated_at",
            "created_by",
            "updated_by",
        ];
    }

    public function searchColumn(): array
    {
        return [
            "name",
            "job_title",
            "primary_phone",
            "email"
        ];
    }
}
