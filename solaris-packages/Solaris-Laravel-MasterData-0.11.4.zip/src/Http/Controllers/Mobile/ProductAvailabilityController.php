<?php

namespace Solaris\MasterData\Http\Controllers\Mobile;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\MasterData\Http\Requests\ProductAvailabilityRequest;

class ProductAvailabilityController
{
	/** @var BaseRepository */
	protected $repo;

	public function __construct()
	{
		$this->repo = new (Helper::repository('product_availability'))(new (Helper::model('product_availability')));
	}

	public function index(Request $request): JsonResponse
	{
		$data = $this->repo->list(
			columns : $this->listColumn(),
			search  : $request->input('search'),
			filter  : $request->input('filter'),
			sort    : $request->input('sort'),
			page    : $request->input('page'),
			length  : $request->input('length'),
		);
		return SolarResponse::list(Helper::mobileResouces('product_availability'), $data);
	}

	public function show(string $id): JsonResponse
	{
		$data = $this->repo->findComplete($id, $this->detailColumns());
		return new (Helper::mobileResouces('product_availability'))($data);
	}

	public function store(): JsonResponse
	{
		/** @var ProductAvailabilityRequest */
		$request = app(Helper::formRequest('product_availability'));
		$data    = $this->repo->create($request->cleanData());

		return SolarResponse::success($data);
	}

	public function update(string $id): JsonResponse
	{
		/** @var ProductAvailabilityRequest */
		$request = app(Helper::formRequest('product_availability'));
		$data    = $this->repo->update($id, $request->cleanData());

		return SolarResponse::success($data);
	}

	public function destroy(string $id): JsonResponse
	{
		return SolarResponse::deleted($this->repo->delete($id));
	}

	public function listColumn(): array
	{
		return [
			'id',
			'warehouse',
			'qty',
			'address',
			'country',
			'province',
			'city',
			'post_code',
		];
	}

	public function detailColumns(): array
	{
		return [
			'id',
			'warehouse',
			'qty',
			'address',
			'product',
			'country',
			'province',
			'city',
			'post_code',
			'created_at',
			'updated_at',
			'created_by',
			'updated_by',
		];
	}
}
