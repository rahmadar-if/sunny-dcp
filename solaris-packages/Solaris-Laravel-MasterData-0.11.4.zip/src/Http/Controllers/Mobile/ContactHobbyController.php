<?php

namespace Solaris\MasterData\Http\Controllers\Mobile;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\MasterData\Http\Requests\ContactHobbyRequest;

class ContactHobbyController
{
	/** @var BaseRepository */
	protected $repo;

	public function __construct()
	{
		$this->repo = new (Helper::repository('contact_hobby'))(new (Helper::model('contact_hobby')));
	}

	public function index(Request $request): JsonResponse
	{
		$data = $this->repo->list(
			columns : $this->listColumn(),
			search  : $request->input('search'),
			filter  : $request->input('filter'),
			sort    : $request->input('sort'),
			page    : $request->input('page'),
			length  : $request->input('length'),
		);
		return SolarResponse::list(Helper::mobileResouces('contact_hobby'), $data);
	}

	public function show(string $id): JsonResponse
	{
		$data = $this->repo->findComplete($id, $this->detailColumns());
		return new (Helper::mobileResouces('contact_hobby'))($data);
	}

	public function store(): JsonResponse
	{
		/** @var ContactHobbyRequest */
		$request = app(Helper::formRequest('contact_hobby'));
		$data    = $this->repo->create($request->cleanData());

		return SolarResponse::success($data);
	}

	public function update(string $id): JsonResponse
	{
		/** @var ContactHobbyRequest */
		$request = app(Helper::formRequest('contact_hobby'));
		$data    = $this->repo->update($id, $request->cleanData());

		return SolarResponse::success($data);
	}

	public function destroy(string $id): JsonResponse
	{
		return SolarResponse::deleted($this->repo->delete($id));
	}

	public function listColumn(): array
	{
		return [
			'id',
			'hobby',
		];
	}

	public function detailColumns(): array
	{
		return [
			'id',
			'hobby',
			'contact',
			'created_at',
			'updated_at',
			'created_by',
			'updated_by',
		];
	}
}
