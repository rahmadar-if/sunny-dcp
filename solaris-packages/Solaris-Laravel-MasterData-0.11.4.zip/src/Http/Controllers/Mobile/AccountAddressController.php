<?php

namespace Solaris\MasterData\Http\Controllers\Mobile;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\MasterData\Http\Resources\Mobile\AccountAddressResource;

class AccountAddressController
{
    /** @var BaseRepository */
    protected $repo;

    public function __construct()
    {
        $this->repo = new (Helper::repository('account_address'))(new (Helper::model('account_address')));
    }

    public function index(Request $request): JsonResponse
    {
        $data = $this->repo->list(
            columns : $this->listColumn(),
            search  : $request->input('search'), 
            filter  : $request->input('filter'),
            sort    : $request->input('sort'),
            page    : $request->input('page'),
            length  : $request->input('length'),
        );
        return SolarResponse::list(Helper::mobileResouces('account_address'), $data);
    }

    public function show(string $id): AccountAddressResource
    {
        $data = $this->repo->findComplete($id, $this->detailColumns());
        return new (Helper::mobileResouces('account_address'))($data);
    }

    public function store(): JsonResponse
    {
        $request = app(Helper::formRequest("account_address"));
        $data    = $this->repo->create($request->cleanData());

        return SolarResponse::success($data);
    }

    public function update(string $id): JsonResponse
    {
        $request = app(Helper::formRequest("account_address"));
        $data    = $this->repo->update($id, $request->cleanData());

        return SolarResponse::success($data);
    }

    public function destroy(string $id): JsonResponse
    {
        return SolarResponse::deleted($this->repo->delete($id));
    }

    public function listColumn(): array
    {
        return [
            "id",
            "address_type",
            "address"
        ];
    }

    public function detailColumns(): array
    {
        return [
            "id",
            "address",
            "postcode",
            "account",
            "address_type",
            "country",
            "province",
            "city",
            "created_at",
            "updated_at",
            "created_by",
            "updated_by",
        ];
    }
}
