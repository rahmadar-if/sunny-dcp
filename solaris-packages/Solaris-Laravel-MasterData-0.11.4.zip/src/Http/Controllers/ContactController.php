<?php

namespace Solaris\MasterData\Http\Controllers;

use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Core\Models\Attachment;
use Solaris\Core\Services\ModelBinding\ModelBindingResult;
use Solaris\MasterData\Http\Requests\ContactRequest;
use Solaris\MasterData\Repositories\AccountRepository;
use Solaris\MasterData\Repositories\ContactRepository;

#[FormAccess()]
class ContactController
{
    /** @var ContactRepository */
    protected $repo;

    /** @var AccountRepository */
    protected $account_repo;

    public function __construct()
    {
        $this->repo = new (Helper::repository('contact'))(new (Helper::model('contact')));
        $this->account_repo = new (Helper::repository('account'))(new (Helper::model('account')));
    }

    public function index(): View
    {
        $breadcrumbs = [
            ['label' => 'Master Data'],
            ['label' => 'Contact'],
        ];

        return view(Helper::view('contact.list'), [
            'breadcrumbs' => $breadcrumbs,
        ]);
    }

    public function store(): JsonResponse
    {
        /** @var ContactRequest */
        $request = app(Helper::formRequest('contact'));
        $data = $this->repo->create($request->cleanData());

        return SolarResponse::success($data);
    }

    public function show(Request $request, string $id): RedirectResponse|JsonResponse
    {
        if (! $request->expectsJson()) {
            return redirect(route('master-data.contact.edit', ['id' => $id]));
        }

        return response()->json($this->repo->findComplete($id, $this->extendColumns()));
    }

    public function edit(string $id): View
    {
        $data = $this->repo->findComplete($id, $this->extendColumns());
        $breadcrumbs = [
            ['label' => 'Master Data'],
            ['label' => 'Contact'],
            ['label' => $data?->name],
        ];

        return view(Helper::view('contact.page'), [
            'data' => $data,
            'breadcrumbs' => $breadcrumbs,
        ]);
    }

    public function update(string $id): JsonResponse
    {
        /** @var ContactRequest */
        $request = app(Helper::formRequest('contact'));
        $data = $this->repo->update($id, $request->cleanData());

        return SolarResponse::success($data);
    }

    public function updateAvatar(string $id): JsonResponse
    {
        /** @var ContactRequest */
        $request = app(Helper::formRequest('contact'));
        $result  = null;
        try {
            if(!$request->hasFile('profile_picture')) {
                throw new \Exception("File upload not found");
            }

            $upload = $this->repo->uploadFile($request, 'profile_picture_id', $id);
            $result = $upload instanceof Attachment ? ['id' => $upload->id] : $upload;
        } catch (\Exception $e) {
            return SolarResponse::error($e->getMessage());
        }

        return SolarResponse::success($result);
    }

    public function destroy(string $id): JsonResponse
    {
        return SolarResponse::deleted($this->repo->delete($id));
    }

    public function batchDelete(Request $request, ModelBindingResult $modelParsing): JsonResponse
    {
        return SolarResponse::success($this->repo->requestBatchDelete($request, $modelParsing));
    }

    public function extendColumns(): array
    {
        return [];
    }
}
