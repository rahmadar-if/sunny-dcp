<?php

namespace Solaris\MasterData\Http\Controllers;

use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Core\Models\Attachment;
use Solaris\Core\Services\ModelBinding\ModelBindingResult;
use Solaris\MasterData\Http\Requests\AccountRequest;
use Solaris\MasterData\Repositories\AccountRepository;

#[FormAccess()]
class AccountController
{
    /** @var AccountRepository */
    protected $repo;

    public function __construct()
    {
        $this->repo = new (Helper::repository('account'))(new (Helper::model('account')));
    }

    public function index(): View
    {
        $breadcrumbs = [
            ['label' => 'Master Data'],
            ['label' => 'Account']
        ];

        return view(Helper::view("account.list"), [
            'breadcrumbs' => $breadcrumbs
        ]);
    }

    public function store(): JsonResponse
    {
        /** @var AccountRequest $request */
        $request = app(Helper::formRequest("account"));
        $data    = $this->repo->create($request->cleanData());

        return SolarResponse::success($data);
    }

    public function show(Request $request, string $id): RedirectResponse|JsonResponse
    {
        if(!$request->expectsJson()) {
            return redirect(route('master-data.account.edit', ['id' => $id]));
        }

        return response()->json($this->repo->findComplete($id, $this->extendColumns()));
    }

    public function edit(string $id): View
    {
        $data = $this->repo->findComplete($id, $this->extendColumns());
        $breadcrumbs = [
            ['label' => 'Master Data'],
            ['label' => 'Account'],
            ['label' => $data->name]
        ];

        return view(Helper::view("account.page"), [
            'data'        => $data,
            'breadcrumbs' => $breadcrumbs
        ]);
    }

    public function update(string $id): JsonResponse
    {
        /** @var AccountRequest $request */
        $request = app(Helper::formRequest("account"));
        $data    = $this->repo->update($id, $request->cleanData());

        return SolarResponse::success($data);
    }

    public function updateAvatar(string $id): JsonResponse
    {
        /** @var AccountRequest $request */
        $request = app(Helper::formRequest("account"));
        $result  = null;
        try {
            if(!$request->hasFile('profile_picture')) {
                throw new \Exception("File upload not found");
            }

            $upload = $this->repo->uploadFile($request, 'profile_picture_id', $id);
            $result = $upload instanceof Attachment ? ['id' => $upload->id] : $upload;
        } catch (\Exception $e) {
            return SolarResponse::error($e->getMessage());
        }

        return SolarResponse::success($result);
    }

    public function destroy(string $id): JsonResponse
    {
        return SolarResponse::deleted($this->repo->delete($id));
    }

    public function batchDelete(Request $request, ModelBindingResult $modelParsing): JsonResponse
    {
        return SolarResponse::success($this->repo->requestBatchDelete($request, $modelParsing));
    }

    public function extendColumns(): array
    {
        return [];
    }
}
