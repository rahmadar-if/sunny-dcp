<?php

namespace Solaris\MasterData\Http\Controllers;

use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\Core\Services\ModelBinding\ModelBindingResult;
use Solaris\MasterData\Http\Requests\KnowledgeBaseRequest;

#[FormAccess()]
class KnowledgeBaseController
{
    /** @var BaseRepository */
    protected $repo;

    public function __construct()
    {
        $this->repo = new (Helper::repository('knowledge_base'))(new (Helper::model('knowledge_base')));
    }

    public function index(): View
    {
        $breadcrumbs = [
            ['label' => 'Master Data'],
            ['label' => 'Knowledge Base'],
        ];

        return view(Helper::view('knowledge_base.list'), [
            'breadcrumbs' => $breadcrumbs,
        ]);
    }

    public function store(): JsonResponse
    {
        /** @var KnowledgeBaseRequest */
        $request = app(Helper::formRequest('knowledge_base'));
        $data = $this->repo->create($request->cleanData());

        return SolarResponse::success($data);
    }

    public function show(Request $request, string $id): RedirectResponse|JsonResponse
    {
        if (! $request->expectsJson()) {
            return redirect(route('master-data.knowledge-base.edit', ['id' => $id]));
        }

        return response()->json($this->repo->findComplete($id, $this->extendColumns()));
    }

    public function edit(string $id): View
    {
        $data = $this->repo->findComplete($id, $this->extendColumns());
        $breadcrumbs = [
            ['label' => 'Master Data'],
            ['label' => 'Knowledge Base'],
            ['label' => $data?->name],
        ];

        return view(Helper::view('knowledge_base.page'), [
            'data' => $data,
            'breadcrumbs' => $breadcrumbs,
        ]);
    }

    public function update(string $id): JsonResponse
    {
        /** @var KnowledgeBaseRequest */
        $request = app(Helper::formRequest('knowledge_base'));
        $data = $this->repo->update($id, $request->cleanData());

        return SolarResponse::success($data);
    }

    public function destroy(string $id): JsonResponse
    {
        return SolarResponse::deleted($this->repo->delete($id));
    }

    public function batchDelete(Request $request, ModelBindingResult $modelParsing): JsonResponse
    {
        return SolarResponse::success($this->repo->requestBatchDelete($request, $modelParsing));
    }

    public function extendColumns(): array
    {
        return [];
    }
}
