<?php

namespace Solaris\MasterData\Http\Controllers;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\Core\Services\ModelBinding\ModelBindingResult;
use Solaris\MasterData\Http\Requests\ContactHobbyRequest;

#[FormAccess()]
class ContactHobbyController
{
    /** @var BaseRepository */
    protected $repo;

    public function __construct()
    {
        $this->repo = new (Helper::repository('contact_hobby'))(new (Helper::model('contact_hobby')));
    }

    public function store(): JsonResponse
    {
        /** @var ContactHobbyRequest */
        $request = app(Helper::formRequest("contact_hobby"));
        $data    = $this->repo->create($request->cleanData());

        return SolarResponse::success($data);
    }

    public function show(string $id): JsonResponse
    {
        return response()->json($this->repo->findComplete($id, $this->extendColumns()));
    }

    public function update(string $id): JsonResponse
    {
        /** @var ContactHobbyRequest */
        $request = app(Helper::formRequest("contact_hobby"));
        $data    = $this->repo->update($id, $request->cleanData());

        return SolarResponse::success($data);
    }

    public function destroy(string $id): JsonResponse
    {
        return SolarResponse::deleted($this->repo->delete($id));
    }

    public function batchDelete(Request $request, ModelBindingResult $modelParsing): JsonResponse
    {
        return SolarResponse::success($this->repo->requestBatchDelete($request, $modelParsing));
    }

    public function extendColumns(): array
    {
        return [];
    }
}