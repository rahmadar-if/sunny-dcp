<?php

namespace Solaris\MasterData\Http\Controllers;

use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\Core\Services\ModelBinding\ModelBindingResult;
use Solaris\MasterData\Http\Requests\DocumentRequest;

#[FormAccess()]
class DocumentController
{
    /** @var BaseRepository */
    protected $repo;

    public function __construct()
    {
        $this->repo = new (Helper::repository('document'))(new (Helper::model('document')));
    }
    
    public function index(): View
    {
        $breadcrumbs = [
            ['label' => 'Master Data'],
            ['label' => 'Document']
        ];

        return view(Helper::view("document.list"), [
            'breadcrumbs' => $breadcrumbs
        ]);
    }

    public function store(): JsonResponse
    {
        /** @var DocumentRequest */
        $request = app(Helper::formRequest("document"));
        $data    = $this->repo->create($request->cleanData());

        return SolarResponse::success($data);
    }

    public function show(Request $request, string $id): RedirectResponse|JsonResponse
    {
        if(!$request->expectsJson()) {
            return redirect(route('master-data.document.edit', ['id' => $id]));
        }

        $data = $this->repo->findComplete($id, $this->extendColumns());
        return response()->json($data);
    }

    public function edit(string $id): View
    {
        $data = $this->repo->findComplete($id, $this->extendColumns());
        $breadcrumbs = [
            ['label' => 'Master Data'],
            ['label' => 'Document'],
            ['label' => $data->number]
        ];

        return view(Helper::view("document.page"), [
            'data'        => $data,
            'breadcrumbs' => $breadcrumbs
        ]);
    }

    public function update(string $id): JsonResponse
    {
        /** @var DocumentRequest */
        $request = app(Helper::formRequest("document"));
        $data    = $this->repo->update($id, $request->cleanData());

        return SolarResponse::success($data);
    }

    public function destroy(string $id): JsonResponse
    {
        return SolarResponse::deleted($this->repo->delete($id));
    }

    public function batchDelete(Request $request, ModelBindingResult $modelParsing): JsonResponse
    {
        return SolarResponse::success($this->repo->requestBatchDelete($request, $modelParsing));
    }

    public function extendColumns(): array
    {
        return [];
    }
}
