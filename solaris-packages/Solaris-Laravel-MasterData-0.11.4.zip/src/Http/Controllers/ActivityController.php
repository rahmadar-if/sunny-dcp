<?php

namespace Solaris\MasterData\Http\Controllers;

use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Core\Services\ModelBinding\ModelBindingResult;
use Solaris\MasterData\Http\Requests\ActivityRequest;
use Solaris\MasterData\Repositories\ActivityRepository;

#[FormAccess()]
class ActivityController
{
    /** @var ActivityRepository */
    protected $repo;

    public function __construct() 
    {
        $this->repo = new (Helper::repository('activity'))(new (Helper::model('activity')));
    }

    public function index(): View
    {
        $breadcrumbs = [
            ['label' => 'Master Data'],
            ['label' => 'Activity']
        ];

        return view(Helper::view("activity.list"), [
            "breadcrumbs" => $breadcrumbs
        ]);
    }

    public function calendar(Request $request): JsonResponse
    {
        $start = $request->input('start_date');
        $end   = $request->input('end_date');

        return response()->json($this->repo->calendarWeb($start, $end));
    }

    public function store(): JsonResponse
    {
        /** @var ActivityRequest */
        $request = app(Helper::formRequest("activity"));
        $data    = $this->repo->create($request->cleanData());

        return SolarResponse::success($data);
    }

    public function show(Request $request, string $id): RedirectResponse|JsonResponse
    {
        if(!$request->expectsJson()) {
            return redirect(route('master-data.activity.edit', ['id' => $id]));
        }

        return response()->json($this->repo->findComplete($id, $this->extendColumns()));
    }

    public function edit(string $id): View
    {
        $data = $this->repo->findComplete($id, $this->extendColumns());
        $breadcrumbs = [
            ['label' => 'Master Data'],
            ['label' => 'Activity'],
            ['label' => $data->subject],
        ];

        return view(Helper::view("activity.page"), [
            'data'        => $data,
            'breadcrumbs' => $breadcrumbs
        ]);
    }

    public function update(string $id): JsonResponse
    {
        /** @var ActivityRequest */
        $request = app(Helper::formRequest("activity"));
        $data    = $this->repo->update($id, $request->cleanData());

        return SolarResponse::success($data);
    }

    public function destroy(string $id): JsonResponse
    {
        return SolarResponse::deleted($this->repo->delete($id));
    }

    public function batchDelete(Request $request, ModelBindingResult $modelParsing): JsonResponse
    {
        return SolarResponse::success($this->repo->requestBatchDelete($request, $modelParsing));
    }

    public function extendColumns(): array
    {
        return [];
    }
}
