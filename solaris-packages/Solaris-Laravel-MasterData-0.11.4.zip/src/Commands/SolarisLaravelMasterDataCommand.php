<?php

namespace Solaris\MasterData\Commands;

use Illuminate\Console\Command;

class SolarisLaravelMasterDataCommand extends Command
{
    public $signature = 'solaris-laravel-masterdata';

    public $description = 'My command';

    public function handle(): int
    {
        $this->comment('All done');

        return self::SUCCESS;
    }
}
