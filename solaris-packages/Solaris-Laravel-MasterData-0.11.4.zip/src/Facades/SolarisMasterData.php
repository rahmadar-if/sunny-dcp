<?php

namespace Solaris\MasterData\Facades;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Solaris\MasterData\SolarisMasterData
 */
class SolarisMasterData extends Facade
{
    protected static function getFacadeAccessor(): string
    {
        return \Solaris\MasterData\SolarisMasterData::class;
    }
}
