<?php

namespace Solaris\MasterData;

class SolarisMasterData {}
