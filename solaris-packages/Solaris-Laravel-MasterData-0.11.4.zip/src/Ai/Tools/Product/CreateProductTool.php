<?php

namespace Solaris\MasterData\Ai\Tools\Product;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Arr;
use Illuminate\Support\Str;
use Laravel\Ai\Tools\Request;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseCreateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Ai\Tools\ProductAvailability\CreateProductAvailabilityTool;
use Solaris\MasterData\Ai\Tools\ProductFeature\CreateProductFeatureTool;
use Solaris\MasterData\Http\Requests\ProductAvailabilityRequest;
use Solaris\MasterData\Http\Requests\ProductFeatureRequest;
use Solaris\MasterData\Http\Requests\ProductRequest;

class CreateProductTool extends BaseCreateAiTool
{
	public static function slug(): string
	{
		return 'create_product';
	}

	protected function resourceLabel(): string
	{
		return 'product';
	}

	public static function fields(JsonSchema $schema): array
	{
		$featureFields      = Arr::except(CreateProductFeatureTool::fields($schema), ['product_id']);
		$availabilityFields = Arr::except(CreateProductAvailabilityTool::fields($schema), ['product_id']);

		return [
			'name' => $schema->string()
				->description('Name of the product.')
				->required(),
			'type_id' => $schema->string()
				->description(
					'Type of product. Resolve via lookup_options with type: "product_type". '
					. 'Still mandatory even if the user does not mention it — if not given, infer the most likely type '
					. 'from the product name; do not ask the user or leave this blank.'
				),
			'unit_of_measure' => $schema->string()
				->description(
					'Unit of measure, e.g. pcs, box, kg. Still mandatory even if the user does not '
					. 'mention it — if not given, infer the most sensible unit for that kind of product from its '
					. 'name; do not ask the user or leave this blank.'
				),
			'price'      => $schema->string()->description('Product price as a plain number.'),
			'sku_number' => $schema->string()->description('Stock keeping unit number.'),
			'category'   => $schema->string()->description('Free-text product category.'),
			'brand'      => $schema->string()->description('Product brand.'),
			'active'     => $schema->boolean()->description('Whether the product is active/available for sale. Defaults to active if not specified.'),
			'detail_features' => $schema->array()->items($schema->object($featureFields))->description(
				'Features to create under this product, each linked automatically. Supports multiple. Optional.'
			),
			'detail_availabilities' => $schema->array()->items($schema->object($availabilityFields))->description(
				'Stock/availability records to create under this product (one per warehouse), each linked automatically. '
					. 'Supports multiple. Optional. The product\'s total availability is recalculated automatically.'
			),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::lookup(column: 'type_id', label: 'product type', modelKey: 'product_type'),
		];
	}

	protected function rules(): array
	{
		return ProductRequest::createRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/add-product" with no other text, ask for the required fields. '
			. 'If the user sends "/add-product" followed by product details, extract the fields directly and proceed to confirmation — '
			. 'skip clarifying questions unless a field is ambiguous.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to add or create a new product, gather the required fields and confirm before calling this tool.'
			. "\n\n"
			. 'INFERENCE: type and unit_of_measure are mandatory but should NOT be asked from the user by '
			. 'default — infer type from the product name (matched against the product_type options in LOOKUP '
			. 'FIELDS above), and infer unit_of_measure from common sense for that kind of product (e.g. "pcs" '
			. 'for countable items, "kg"/"liter" for bulk goods, "box"/"pack" for bundled goods). Only ask the '
			. 'user if the name genuinely gives no clue for either one.'
			. "\n\n"
			. 'DETAILS: If the user also wants features or stock/availability records added under this product '
			. 'in the same request, pass them via detail_features/detail_availabilities — everything is created '
			. 'together in this same confirmation.'
			. "\n\n"
			. 'Product picture is not settable here — set it later via the web app.';
	}

	public function validateConfirmation(Request $request): array
	{
		$result = parent::validateConfirmation($request);

		if (isset($result['error'])) {
			return $result;
		}

		$productId = (string) Str::uuid7();

		[$features, $errors] = $this->validateDetailList((array) ($request['detail_features'] ?? []), ProductFeatureRequest::createRules(), 'product_id', $productId);
		if (!empty($errors)) {
			return AiResponse::error(AiErrorCode::UserError,'One or more detail features failed validation.', ['messages' => $errors]);
		}

		[$availabilities, $errors] = $this->validateDetailList((array) ($request['detail_availabilities'] ?? []), ProductAvailabilityRequest::createRules(), 'product_id', $productId);
		if (!empty($errors)) {
			return AiResponse::error(AiErrorCode::UserError,'One or more detail availabilities failed validation.', ['messages' => $errors]);
		}

		$result['payload']['raw']['id']                   = $productId;
		$result['payload']['raw']['detail_features']      = $features;
		$result['payload']['raw']['detail_availabilities'] = $availabilities;

		if (!empty($features)) {
			$result['summary']['detail_features'] = array_map(fn ($f) => $f['name'], $features);
		}

		if (!empty($availabilities)) {
			$result['summary']['detail_availabilities'] = array_map(fn ($a) => $a['warehouse'], $availabilities);
		}

		return $result;
	}

	protected function afterCreate(Model $record, array $raw): void
	{
		$detailFeatures       = $raw['detail_features'] ?? [];
		$detailAvailabilities = $raw['detail_availabilities'] ?? [];

		if (!empty($detailFeatures)) {
			$featureRepo = new (Helper::repository('product_feature'))(new (Helper::model('product_feature')), transaction: false);
			foreach ($detailFeatures as $data) {
				$featureRepo->create($data);
			}
		}

		if (!empty($detailAvailabilities)) {
			$availabilityRepo = new (Helper::repository('product_availability'))(new (Helper::model('product_availability')), transaction: false);
			foreach ($detailAvailabilities as $data) {
				$availabilityRepo->create($data);
			}
		}
	}

	protected function create(array $validated, array $raw): array
	{
		$validated['active'] = $validated['active'] ?? true;
		$validated['id']     = $raw['id'] ?? (string) Str::uuid7();

		$repo    = new (Helper::repository('product'))(new (Helper::model('product')));
		$product = $repo->create($validated,
			before: fn ($data)   => $this->beforeCreate($data, $raw),
			after:  fn ($record) => $this->afterCreate($record, $raw),
		);

		return AiResponse::success(
			['id' => $product->id, 'name' => $product->name],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
