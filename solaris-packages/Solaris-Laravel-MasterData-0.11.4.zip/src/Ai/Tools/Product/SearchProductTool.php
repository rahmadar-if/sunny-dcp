<?php

namespace Solaris\MasterData\Ai\Tools\Product;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Services\Filter;

class SearchProductTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_product';
	}

	protected function resourceLabel(): string
	{
		return 'products — sellable items with price, stock availability, and SKU';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('product'))();
	}

	protected function fields(): array
	{
		return [
			'name' => AiSearchColumn::string(
				column: 'name',
				description: 'Name of the product. For filters, combine SIMILAR OR LIKE in the same OR-group — '
					. 'SIMILAR tolerates typos/reordering/partial/extra wording, LIKE catches plain substring '
					. 'matches SIMILAR can miss.',
				searchable: true,
			),
			'sku_number' => AiSearchColumn::string(
				column: 'sku_number',
				description: 'Stock keeping unit number',
				searchable: true,
			),
			'category' => AiSearchColumn::string(
				column: 'category',
				description: 'Free-text product category',
				searchable: true,
			),
			'brand' => AiSearchColumn::string(
				column: 'brand',
				description: 'Product brand',
				searchable: true,
			),
			'type_id' => AiSearchColumn::lookup(
				column: 'type_id',
				description: 'Type of product',
				modelKey: 'product_type',
			),
			'price' => AiSearchColumn::number(
				column: 'price',
				description: 'Product price',
				operators: [
					Filter::Equal, Filter::NotEqual, Filter::Greater, Filter::GreaterOrEqual, Filter::Less, Filter::LessOrEqual,
					Filter::Between, Filter::NotBetween, Filter::IsNull, Filter::IsNotNull,
				],
			),
			'availability' => AiSearchColumn::number(
				column: 'availability',
				description: 'Total stock quantity across all warehouses',
			),
			'active' => AiSearchColumn::boolean(
				column: 'active',
				description: 'Whether the product is active/available for sale',
			),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'          => $record->id,
			'name'         => $record->name,
			'type'         => $record->type?->name,
			'sku_number'   => $record->sku_number,
			'brand'        => $record->brand,
			'price'        => $record->price,
			'availability' => $record->availability,
			'active'       => (bool) $record->active,
		];
	}

	protected function relations(): array
	{
		return [
			'availabilities'  => 'search_product_availability',
			'features'        => 'search_product_feature',
			'price_histories' => 'search_product_price_history',
		];
	}
}
