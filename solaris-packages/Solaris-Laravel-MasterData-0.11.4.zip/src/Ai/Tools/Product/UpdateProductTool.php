<?php

namespace Solaris\MasterData\Ai\Tools\Product;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Validator;
use Laravel\Ai\Tools\Request;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseUpdateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Ai\Tools\ProductAvailability\CreateProductAvailabilityTool;
use Solaris\MasterData\Ai\Tools\ProductFeature\CreateProductFeatureTool;
use Solaris\MasterData\Http\Requests\ProductAvailabilityRequest;
use Solaris\MasterData\Http\Requests\ProductFeatureRequest;
use Solaris\MasterData\Http\Requests\ProductRequest;
use Solaris\MasterData\Models\Product;

class UpdateProductTool extends BaseUpdateAiTool
{
	public static function slug(): string
	{
		return 'update_product';
	}

	protected function resourceLabel(): string
	{
		return 'product';
	}

	public static function fields(JsonSchema $schema): array
	{
		$featureFields      = Arr::except(CreateProductFeatureTool::fields($schema), ['product_id']);
		$availabilityFields = Arr::except(CreateProductAvailabilityTool::fields($schema), ['product_id']);

		$detailMeta = [
			'id'     => $schema->string()->description('Existing record id. Omit to create a new one.'),
			'delete' => $schema->boolean()->description('Set true (with id) to remove this record instead of updating it.'),
		];

		return [
			'id' => $schema->string()
				->description('The product id. Required.')
				->required(),
			'name'                => $schema->string()->description('New name of the product.'),
			'type_id'             => $schema->string()->description('New product type. Resolve via lookup_options with type: "product_type".'),
			'unit_of_measure'     => $schema->string()->description('New unit of measure, e.g. pcs, box, kg.'),
			'price'               => $schema->string()->description('New product price as a plain number.'),
			'sku_number'          => $schema->string()->description('New stock keeping unit number.'),
			'category'            => $schema->string()->description('New free-text product category.'),
			'brand'               => $schema->string()->description('New product brand.'),
			'active'              => $schema->boolean()->description('Whether the product is active/available for sale.'),
			'product_description' => $schema->string()->description('New product description.'),
			'notes'               => $schema->string()->description('Free-text notes about the product.'),
			'detail_features' => $schema->array()->items($schema->object(array_merge($detailMeta, $featureFields)))->description(
				'Manage features under this product in the same confirmation — omit id to add a new one, pass id '
					. 'with fields to update an existing one, pass id with delete:true to remove one. Supports multiple. Optional.'
			),
			'detail_availabilities' => $schema->array()->items($schema->object(array_merge($detailMeta, $availabilityFields)))->description(
				'Manage stock/availability records under this product in the same confirmation — omit id to add a new one, '
					. 'pass id with fields to update an existing one, pass id with delete:true to remove one. Supports multiple. Optional. '
					. 'The product\'s total availability is recalculated automatically.'
			),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::lookup(column: 'type_id', label: 'product type', modelKey: 'product_type'),
		];
	}

	protected function rules(): array
	{
		return ProductRequest::updateRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/update-product" with no other text, ask which product and what to change. '
			. 'If the user sends "/update-product" followed by a description of the changes, '
			. 'extract the fields directly and proceed to confirmation — skip clarifying questions unless a field is ambiguous.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to edit or update a product, first locate it with the product search tool available to you '
			. 'if the id is not already known, then confirm the changes before calling this tool.'
			. "\n\n"
			. 'DETAILS: If the user also wants features or stock/availability records added, changed, or removed under '
			. 'this product in the same request, pass them via detail_features/detail_availabilities — everything is '
			. 'applied together in this same confirmation.'
			. "\n\n"
			. 'Product picture is not settable here — set it via the web app.';
	}

	protected function findRecordById(string $id): ?Product
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('product'))(new (Helper::model('product')));

		return $repo->find($id);
	}

	protected function currentData(mixed $record): array
	{
		return [
			'name'                => $record->name,
			'type_id'             => $record->type_id,
			'unit_of_measure'     => $record->unit_of_measure,
			'price'               => $record->price,
			'sku_number'          => $record->sku_number,
			'category'            => $record->category,
			'brand'               => $record->brand,
			'active'              => (bool) $record->active,
			'product_description' => $record->product_description,
			'notes'               => $record->notes,
		];
	}

	public function validateConfirmation(Request $request): array
	{
		$result = parent::validateConfirmation($request);

		if (isset($result['error'])) {
			return $result;
		}

		$productId = trim((string) ($request['id'] ?? ''));

		[$features, $featureErrors] = $this->resolveDetailOperations(
			(array) ($request['detail_features'] ?? []), Helper::model('product_feature'), ProductFeatureRequest::createRules(), ProductFeatureRequest::updateRules(), 'product_id', $productId,
		);
		if (!empty($featureErrors)) {
			return AiResponse::error(AiErrorCode::UserError,'One or more detail features failed validation.', ['messages' => $featureErrors]);
		}

		[$availabilities, $availabilityErrors] = $this->resolveDetailOperations(
			(array) ($request['detail_availabilities'] ?? []), Helper::model('product_availability'), ProductAvailabilityRequest::createRules(), ProductAvailabilityRequest::updateRules(), 'product_id', $productId,
		);
		if (!empty($availabilityErrors)) {
			return AiResponse::error(AiErrorCode::UserError,'One or more detail availabilities failed validation.', ['messages' => $availabilityErrors]);
		}

		$result['payload']['changes']['detail_features']       = $features;
		$result['payload']['changes']['detail_availabilities'] = $availabilities;

		foreach ([
			'detail_features'       => $features,
			'detail_availabilities' => $availabilities,
		] as $key => $ops) {
			if (!empty($ops['create']) || !empty($ops['update']) || !empty($ops['delete'])) {
				$result['summary'][$key] = [
					'add'    => count($ops['create']),
					'update' => count($ops['update']),
					'delete' => count($ops['delete']),
				];
			}
		}

		return $result;
	}

	protected function afterUpdate(mixed $record, array $changes): void
	{
		$featureOps      = $changes['detail_features']       ?? ['create' => [], 'update' => [], 'delete' => []];
		$availabilityOps = $changes['detail_availabilities'] ?? ['create' => [], 'update' => [], 'delete' => []];

		$featureRepo      = new (Helper::repository('product_feature'))(new (Helper::model('product_feature')), transaction: false);
		$availabilityRepo = new (Helper::repository('product_availability'))(new (Helper::model('product_availability')), transaction: false);

		foreach ([[$featureRepo, $featureOps], [$availabilityRepo, $availabilityOps]] as [$repo, $ops]) {
			foreach ($ops['create'] as $data) { 
				$repo->create($data); 
			}

			foreach ($ops['update'] as $id => $data) { 
				$repo->update($id, $data); 
			}

			foreach ($ops['delete'] as $id) { 
				$repo->delete($id); 
			}
		}
	}

	protected function excludedChangeKeys(): array
	{
		return ['detail_features', 'detail_availabilities'];
	}

	protected function update(mixed $record, array $validated, array $changes): array
	{
		$repo = new (Helper::repository('product'))(new (Helper::model('product')));
		$repo->update($record->id, $validated,
			before: fn ($record, $data) => $this->beforeUpdate($record, $data, $changes),
			after:  fn ($record)        => $this->afterUpdate($record, $changes),
		);

		$fieldChanges = collect($changes)->except($this->excludedChangeKeys())->all();

		return AiResponse::success(
			[
				'id'      => $record->id,
				'name'    => $fieldChanges['name'] ?? $record->name,
				'updated' => array_keys($fieldChanges),
			],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
