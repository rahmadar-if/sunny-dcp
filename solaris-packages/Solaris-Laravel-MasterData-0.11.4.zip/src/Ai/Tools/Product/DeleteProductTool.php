<?php

namespace Solaris\MasterData\Ai\Tools\Product;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseDeleteAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Models\Product;

class DeleteProductTool extends BaseDeleteAiTool
{
	public static function slug(): string
	{
		return 'delete_product';
	}

	protected function resourceLabel(): string
	{
		return 'product';
	}

	protected function findRecordById(string $id): ?Product
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('product'))(new (Helper::model('product')));

		return $repo->find($id);
	}

	protected function delete(Model $record): array
	{
		$repo = new (Helper::repository('product'))(new (Helper::model('product')));
		$repo->delete($record->id);

		return AiResponse::success(
			['deleted' => $record->name],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
