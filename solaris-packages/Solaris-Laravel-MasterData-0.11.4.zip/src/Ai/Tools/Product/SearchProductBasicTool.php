<?php

namespace Solaris\MasterData\Ai\Tools\Product;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Services\Filter;

// Purpose-built variant of search_product for the agents that SELL: picking a product to put on an
// opportunity, order, or invoice line. Two narrowings, for two different reasons.
//
// Rows: only active products exist here at all. Whether a product may be sold is a business rule, not
// a filter the model should have to remember on every call — left as a plain column it would be
// forgotten eventually, and a discontinued item would end up on a real order.
//
// Columns: the three relation catalogues (availabilities, features, price histories) and the audit
// columns are dropped. Price and stock stay, because picking a line item is exactly what needs them —
// catalog management is the catalog specialist's job, and it keeps the full tool.
class SearchProductBasicTool extends SearchProductTool
{
	public static function slug(): string
	{
		return 'search_product_basic';
	}

	protected function resourceLabel(): string
	{
		return 'products available for sale — pick one to put on a quotation, order, or invoice line';
	}

	protected function fields(): array
	{
		return array_intersect_key(parent::fields(), array_flip([
			'name',
			'sku_number',
			'category',
			'brand',
			'type_id',
			'price',
			'availability',
		]));
	}

	protected function baseFilters(): array
	{
		return (new Filter())->and('active', Filter::Equal, true)->get();
	}

	protected function baseFilterLabel(): ?string
	{
		return 'Only products marked active are visible through this tool; discontinued or inactive ones are never returned.';
	}

	protected function auditFields(): array
	{
		return [];
	}

	protected function relations(): array
	{
		return [];
	}

	// `active` is gone from the output too — every row here is active by construction, so returning the
	// flag would only invite the model to reason about a distinction that cannot occur.
	protected function formatRecord(Model $record): array
	{
		return [
			'_id'          => $record->id,
			'name'         => $record->name,
			'type'         => $record->type?->name,
			'sku_number'   => $record->sku_number,
			'brand'        => $record->brand,
			'category'     => $record->category,
			'price'        => $record->price,
			'availability' => $record->availability,
		];
	}
}
