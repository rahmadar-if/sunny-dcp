<?php

namespace Solaris\MasterData\Ai\Tools\Contact;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

class SearchContactTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_contact';
	}

	protected function resourceLabel(): string
	{
		return 'contacts — individual people associated with accounts (clients, prospects, partners)';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('contact'))();
	}

	protected function fields(): array
	{
		return [
			'name' => AiSearchColumn::string(
				column: 'name',
				description: 'Full name of the contact person. For filters, combine SIMILAR OR LIKE in the '
					. 'same OR-group — SIMILAR tolerates typos/reordering/partial/extra wording, LIKE catches '
					. 'plain substring matches SIMILAR can miss.',
				searchable: true,
			),
			'email' => AiSearchColumn::string(
				column: 'email',
				description: 'Email address',
				searchable: true,
			),
			'primary_phone' => AiSearchColumn::string(
				column: 'primary_phone',
				description: 'Primary phone number',
				searchable: true,
			),
			'primary_mobile_phone' => AiSearchColumn::string(
				column: 'primary_mobile_phone',
				description: 'Primary mobile/cell phone number — usually the WhatsApp-capable one',
				searchable: true,
			),
			'job_title' => AiSearchColumn::string(
				column: 'job_title',
				description: 'Job title or position',
				searchable: true,
			),
			'account_id' => AiSearchColumn::reference(
				column: 'account_id',
				description: 'The account id this contact belongs to. Obtain it with the account search tool available to you first.',
				modelKey: 'account',
			),
			'gender_id' => AiSearchColumn::lookup(
				column: 'gender_id',
				description: 'Gender',
				modelKey: 'gender',
			),
			'religion_id' => AiSearchColumn::lookup(
				column: 'religion_id',
				description: 'Religion',
				modelKey: 'religion',
			),
			'marital_status_id' => AiSearchColumn::lookup(
				column: 'marital_status_id',
				description: 'Marital status',
				modelKey: 'marital_status',
			),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'                  => $record->id,
			'_account_id'          => $record->account_id,
			'name'                 => $record->name,
			'job_title'            => $record->job_title,
			'email'                => $record->email,
			'primary_phone'        => $record->primary_phone,
			'primary_mobile_phone' => $record->primary_mobile_phone,
			'account'              => $record->account?->name,
		];
	}

	protected function relations(): array
	{
		return [
			'activities'       => 'search_activity',
			'addresses'        => 'search_contact_address',
			'communications'   => 'search_contact_communication',
			'hobbies'          => 'search_contact_hobby',
			'related_contacts' => 'search_related_contact',
		];
	}
}
