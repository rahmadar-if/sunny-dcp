<?php

namespace Solaris\MasterData\Ai\Tools\Contact;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;

// Lookup-shaped variant of search_contact — see SearchAccountBasicTool for the reasoning behind the
// shape and behind extending the MasterData base instead of the slug's winning class.
class SearchContactBasicTool extends SearchContactTool
{
	public static function slug(): string
	{
		return 'search_contact_basic';
	}

	protected function resourceLabel(): string
	{
		return 'contacts (people) — name lookup only, for resolving a contact id';
	}

	protected function fields(): array
	{
		$fields = array_intersect_key(parent::fields(), array_flip([
			'name',
			'email',
			'primary_phone',
			'primary_mobile_phone',
			'job_title',
			'account_id',
		]));

		// Overridden purely to say WHY this column matters on a lookup tool: it is the one column that
		// separates people who share a name, which is the whole job here. The resolution pointer stays
		// slug-free, same as everywhere else.
		return array_merge($fields, [
			'account_id' => AiSearchColumn::reference(
				column: 'account_id',
				description: 'The account (company) this contact belongs to — the strongest way to tell '
					. 'apart people who share a name. Obtain it with the account search tool available to you first.',
				modelKey: 'account',
			),
		]);
	}

	protected function auditFields(): array
	{
		return [];
	}

	protected function relations(): array
	{
		return [];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'                  => $record->id,
			'_account_id'          => $record->account_id,
			'name'                 => $record->name,
			'job_title'            => $record->job_title,
			'account'              => $record->account?->name,
			'email'                => $record->email,
			'primary_phone'        => $record->primary_phone,
			'primary_mobile_phone' => $record->primary_mobile_phone,
		];
	}
}
