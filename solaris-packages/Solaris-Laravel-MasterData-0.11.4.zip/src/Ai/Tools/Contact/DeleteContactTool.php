<?php

namespace Solaris\MasterData\Ai\Tools\Contact;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseDeleteAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Models\Contact;

class DeleteContactTool extends BaseDeleteAiTool
{
	public static function slug(): string
	{
		return 'delete_contact';
	}

	protected function resourceLabel(): string
	{
		return 'contact';
	}

	protected function findRecordById(string $id): ?Contact
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('contact'))(new (Helper::model('contact')));

		return $repo->find($id);
	}

	protected function delete(Model $record): array
	{
		$repo = new (Helper::repository('contact'))(new (Helper::model('contact')));
		$repo->delete($record->id);

		return AiResponse::success(
			['deleted' => $record->name],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
