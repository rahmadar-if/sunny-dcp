<?php

namespace Solaris\MasterData\Ai\Tools\Contact;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Laravel\Ai\Tools\Request;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseCreateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Ai\Tools\Account\CreateAccountTool;
use Solaris\MasterData\Ai\Tools\ContactAddress\CreateContactAddressTool;
use Solaris\MasterData\Ai\Tools\ContactCommunication\CreateContactCommunicationTool;
use Solaris\MasterData\Ai\Tools\ContactHobby\CreateContactHobbyTool;
use Solaris\MasterData\Http\Requests\AccountRequest;
use Solaris\MasterData\Http\Requests\ContactAddressRequest;
use Solaris\MasterData\Http\Requests\ContactCommunicationRequest;
use Solaris\MasterData\Http\Requests\ContactHobbyRequest;
use Solaris\MasterData\Http\Requests\ContactRequest;
use Solaris\MasterData\Http\Requests\RelatedContactRequest;

class CreateContactTool extends BaseCreateAiTool
{
	public static function slug(): string
	{
		return 'create_contact';
	}

	protected function resourceLabel(): string
	{
		return 'contact';
	}

	public static function fields(JsonSchema $schema): array
	{
		$addressFields       = Arr::except(CreateContactAddressTool::fields($schema), ['contact_id']);
		$communicationFields = Arr::except(CreateContactCommunicationTool::fields($schema), ['contact_id']);
		$hobbyFields         = Arr::except(CreateContactHobbyTool::fields($schema), ['contact_id']);

		return [
			'name' => $schema->string()
				->description('Full name of the contact person.')
				->required(),
			'primary_phone' => $schema->string()
				->description('Landline/office phone number — see PHONE NUMBERS below for how to tell it apart from mobile.')
				->required(),
			'primary_mobile_phone' => $schema->string()
				->description('Mobile/HP/WhatsApp number — see PHONE NUMBERS below for how to tell it apart from landline.')
				->required(),
			'job_title'  => $schema->string()->description('Job title or position.'),
			'email'      => $schema->string()->description('Email address.'),
			'account_id' => $schema->string()->description(
				'The account id this contact belongs to. Obtain it with the account search tool available to you first. '
					. 'Use this OR new_account, never both. Optional.'
			),
			'new_account' => $schema->object(
				CreateAccountTool::coreFields($schema)
			)->description(
				'Provide instead of account_id ONLY when the user explicitly wants a brand-new company/account created '
					. 'and this contact set as its primary contact in the same confirmation — never as a substitute for '
					. 'resolving an existing one with the account search tool available to you. Optional.'
			),
			'detail_addresses' => $schema->array()->items($schema->object($addressFields))->description(
				'Addresses to create under this contact, each linked automatically. Supports multiple. Optional.'
			),
			'detail_communications' => $schema->array()->items($schema->object($communicationFields))->description(
				'Communication channels (WhatsApp, Instagram, LinkedIn, etc.) to add to this contact, '
					. 'each linked automatically. Supports multiple. Optional.'
			),
			'detail_hobbies' => $schema->array()->items($schema->object($hobbyFields))->description(
				'Hobbies or interests to add to this contact, each linked automatically. Supports multiple. Optional.'
			),
			'detail_related_contacts' => $schema->array()->items($schema->object([
				'related_contact_id' => $schema->string()
					->description('The other contact in this relationship. Obtain it with the contact search tool available to you first.')
					->required(),
				'category_id' => $schema->string()
					->description('Relationship category. Resolve via lookup_options with type: "related_contact_category".')
					->required(),
			]))->description(
				'Relationship links to other contacts (e.g. spouse, colleague, referrer). '
					. 'contact_id is injected automatically. Supports multiple. Optional.'
			),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::reference(column: 'account_id', label: 'account', modelKey: 'account'),
		];
	}

	protected function rules(): array
	{
		return ContactRequest::createRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/add-contact" with no other text, ask for the required fields. '
			. 'If the user sends "/add-contact" followed by contact details, extract the fields directly and proceed to confirmation — '
			. 'skip clarifying questions unless a field is ambiguous.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to add or create a new contact/person, gather the required fields and confirm before calling this tool.'
			. "\n\n"
			. 'ACCOUNT: If the contact belongs to a company, never resolve the account from a name alone — account '
			. 'names can repeat, be mistyped, reordered, or given partially/with extra words. Ask which account '
			. 'they mean if unclear, optionally narrowing by industry, phone, or email, then call the account search tool '
			. 'with an OR-group covering every possibility given: combine `name SIMILAR <value>` OR `name LIKE '
			. '<value>` for the name, plus `industry_id EQUAL`, `primary_phone LIKE`, `email LIKE` for whatever '
			. 'else was given. Any account is a valid match here — unlike primary contact on the account module, '
			. 'there is no base condition to keep (no account_id restriction). If results are still ambiguous, ask '
			. 'the user to pick manually. If the user explicitly wants to create a new company in the same step, '
			. 'use new_account instead.'
			. "\n\n"
			. 'PHONE NUMBERS: primary_phone is a landline/office number; primary_mobile_phone is a mobile/cell/'
			. 'WhatsApp number — they are different fields. Infer which is which from how the user refers to it '
			. '(mobile/cell/WhatsApp wording → primary_mobile_phone; landline/office/home phone wording → '
			. 'primary_phone), regardless of the language the user is speaking. If the user gives only ONE phone '
			. 'number and does not distinguish or does not have a second one, use that same number for both '
			. 'primary_phone and primary_mobile_phone — do not ask twice or leave either blank.'
			. "\n\n"
			. 'BUSINESS CARD / IMAGE: If the user wants to create a contact from a photo, resolve it via '
			. 'wa_media_tool (for:"read"), then extract_images with a task describing this tool\'s fields — '
			. 'never guess these fields from the image yourself. Multiple photos of different people each need '
			. 'their own extract_images group (one contact per group), not merged into one. A company name read '
			. 'off the card is still just a name — the ACCOUNT rule above applies, do not resolve account_id '
			. 'from it alone.'
			. "\n\n"
			. 'DETAILS: If the user also wants addresses, communication channels, hobbies, or relationship links '
			. 'added under this contact in the same request, pass them via detail_addresses/detail_communications/'
			. 'detail_hobbies/detail_related_contacts — everything is created together in this same confirmation.'
			. "\n\n"
			. 'Profile picture is not settable here — set it later via the web app.';
	}

	public function validateConfirmation(Request $request): array
	{
		$result = parent::validateConfirmation($request);

		if (isset($result['error'])) {
			return $result;
		}

		$newAccount = $request['new_account'] ?? null;
		if (!empty($newAccount)) {
			$accountValidator = Validator::make((array) $newAccount, AccountRequest::createRules());

			if ($accountValidator->fails()) {
				return AiResponse::error(AiErrorCode::UserError,'New account validation failed.', ['messages' => $accountValidator->errors()->all()]);
			}

			$result['payload']['raw']['new_account'] = $accountValidator->validated();
			$result['summary']['new_account']        = $accountValidator->validated()['name'];
		}

		$contactId = (string) Str::uuid7();

		[$addresses, $errors] = $this->validateDetailList((array) ($request['detail_addresses'] ?? []), ContactAddressRequest::createRules(), 'contact_id', $contactId);
		if (!empty($errors)) {
			return AiResponse::error(AiErrorCode::UserError,'One or more detail addresses failed validation.', ['messages' => $errors]);
		}

		[$communications, $errors] = $this->validateDetailList((array) ($request['detail_communications'] ?? []), ContactCommunicationRequest::createRules(), 'contact_id', $contactId);
		if (!empty($errors)) {
			return AiResponse::error(AiErrorCode::UserError,'One or more detail communications failed validation.', ['messages' => $errors]);
		}

		[$hobbies, $errors] = $this->validateDetailList((array) ($request['detail_hobbies'] ?? []), ContactHobbyRequest::createRules(), 'contact_id', $contactId);
		if (!empty($errors)) {
			return AiResponse::error(AiErrorCode::UserError,'One or more detail hobbies failed validation.', ['messages' => $errors]);
		}

		[$relatedContacts, $errors] = $this->validateDetailList((array) ($request['detail_related_contacts'] ?? []), RelatedContactRequest::createRules(), 'contact_id', $contactId);
		if (!empty($errors)) {
			return AiResponse::error(AiErrorCode::UserError,'One or more detail related contacts failed validation.', ['messages' => $errors]);
		}

		$result['payload']['raw']['id']                      = $contactId;
		$result['payload']['raw']['detail_addresses']        = $addresses;
		$result['payload']['raw']['detail_communications']   = $communications;
		$result['payload']['raw']['detail_hobbies']          = $hobbies;
		$result['payload']['raw']['detail_related_contacts'] = $relatedContacts;

		if (!empty($addresses)) {
			$result['summary']['detail_addresses'] = array_map(fn ($a) => $a['address'], $addresses);
		}

		if (!empty($communications)) {
			$result['summary']['detail_communications'] = array_map(fn ($c) => $c['value'], $communications);
		}

		if (!empty($hobbies)) {
			$result['summary']['detail_hobbies'] = array_map(fn ($h) => $h['hobby'], $hobbies);
		}

		if (!empty($relatedContacts)) {
			$result['summary']['detail_related_contacts'] = count($relatedContacts) . ' relationship(s)';
		}

		return $result;
	}

	protected function afterCreate(Model $record, array $raw): void
	{
		$newAccountId = $raw['_new_account_id'] ?? null;
		if ($newAccountId !== null) {
			$accountRepo = new (Helper::repository('account'))(new (Helper::model('account')), transaction: false);
			$accountRepo->update($newAccountId, ['primary_contact_id' => $record->id]);
		}

		$detailAddresses       = $raw['detail_addresses'] ?? [];
		$detailCommunications  = $raw['detail_communications'] ?? [];
		$detailHobbies         = $raw['detail_hobbies'] ?? [];
		$detailRelatedContacts = $raw['detail_related_contacts'] ?? [];

		if (!empty($detailAddresses)) {
			$addressRepo = new (Helper::repository('contact_address'))(new (Helper::model('contact_address')), transaction: false);
			foreach ($detailAddresses as $data) {
				$addressRepo->create($data);
			}
		}

		if (!empty($detailCommunications)) {
			$communicationRepo = new (Helper::repository('contact_communication'))(new (Helper::model('contact_communication')), transaction: false);
			foreach ($detailCommunications as $data) {
				$communicationRepo->create($data);
			}
		}

		if (!empty($detailHobbies)) {
			$hobbyRepo = new (Helper::repository('contact_hobby'))(new (Helper::model('contact_hobby')), transaction: false);
			foreach ($detailHobbies as $data) {
				$hobbyRepo->create($data);
			}
		}

		if (!empty($detailRelatedContacts)) {
			$relatedContactRepo = new (Helper::repository('related_contact'))(new (Helper::model('related_contact')), transaction: false);
			foreach ($detailRelatedContacts as $data) {
				$relatedContactRepo->create($data);
			}
		}
	}

	protected function create(array $validated, array $raw): array
	{
		$newAccount = $raw['new_account'] ?? null;

		$validated['id'] = $raw['id'] ?? (string) Str::uuid7();

		return DB::transaction(function () use ($validated, $raw, $newAccount) {
			if (!empty($newAccount)) {
				$accountRepo = new (Helper::repository('account'))(new (Helper::model('account')), transaction: false);
				$account     = $accountRepo->create($newAccount);

				$validated['account_id']    = $account->id;
				$raw['_new_account_id']     = $account->id;
			}

			$repo    = new (Helper::repository('contact'))(new (Helper::model('contact')), transaction: false);
			$contact = $repo->create($validated,
				before: fn ($data)   => $this->beforeCreate($data, $raw),
				after:  fn ($record) => $this->afterCreate($record, $raw),
			);

			return AiResponse::success(
				['id' => $contact->id, 'name' => $contact->name],
				instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
			);
		});
	}
}
