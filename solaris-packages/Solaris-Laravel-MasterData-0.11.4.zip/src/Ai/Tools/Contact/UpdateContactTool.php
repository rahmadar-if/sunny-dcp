<?php

namespace Solaris\MasterData\Ai\Tools\Contact;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Laravel\Ai\Tools\Request;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseUpdateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Ai\Tools\Account\CreateAccountTool;
use Solaris\MasterData\Ai\Tools\ContactAddress\CreateContactAddressTool;
use Solaris\MasterData\Ai\Tools\ContactCommunication\CreateContactCommunicationTool;
use Solaris\MasterData\Ai\Tools\ContactHobby\CreateContactHobbyTool;
use Solaris\MasterData\Http\Requests\AccountRequest;
use Solaris\MasterData\Http\Requests\ContactAddressRequest;
use Solaris\MasterData\Http\Requests\ContactCommunicationRequest;
use Solaris\MasterData\Http\Requests\ContactHobbyRequest;
use Solaris\MasterData\Http\Requests\ContactRequest;
use Solaris\MasterData\Http\Requests\RelatedContactRequest;
use Solaris\MasterData\Models\Contact;

class UpdateContactTool extends BaseUpdateAiTool
{
	public static function slug(): string
	{
		return 'update_contact';
	}

	protected function resourceLabel(): string
	{
		return 'contact';
	}

	public static function fields(JsonSchema $schema): array
	{
		$addressFields       = Arr::except(CreateContactAddressTool::fields($schema), ['contact_id']);
		$communicationFields = Arr::except(CreateContactCommunicationTool::fields($schema), ['contact_id']);
		$hobbyFields         = Arr::except(CreateContactHobbyTool::fields($schema), ['contact_id']);

		$detailMeta = [
			'id'     => $schema->string()->description('Existing record id. Omit to create a new one.'),
			'delete' => $schema->boolean()->description('Set true (with id) to remove this record instead of updating it.'),
		];

		$relatedContactFields = [
			'related_contact_id' => $schema->string()->description('The other contact in this relationship. Obtain it with the contact search tool available to you first.'),
			'category_id'        => $schema->string()->description('Relationship category. Resolve via lookup_options with type: "related_contact_category".'),
		];

		return [
			'id' => $schema->string()
				->description('The contact id. Required.')
				->required(),
			'name' => $schema->string()->description('New full name of the contact person.'),
			'primary_phone' => $schema->string()->description(
				'New landline/office phone number — see PHONE NUMBERS below for how to tell it apart from mobile.'
			),
			'primary_mobile_phone' => $schema->string()->description(
				'New mobile/HP/WhatsApp number — see PHONE NUMBERS below for how to tell it apart from landline.'
			),
			'job_title'   => $schema->string()->description('New job title or position.'),
			'email'       => $schema->string()->description('New email address.'),
			'account_id'  => $schema->string()->description(
				'New account id this contact belongs to. Use this OR new_account, never both. Obtain it with the account search tool available to you first.'
			),
			'salutation_id' => $schema->string()->description('New salutation. Resolve via lookup_options with type: "salutation".'),
			'also_known_as' => $schema->string()->description('Alternate name or alias.'),
			'birth_date'    => $schema->string()->description('Date of birth in Y-m-d format.'),
			'gender_id'     => $schema->string()->description('New gender. Resolve via lookup_options with type: "gender".'),
			'education_id'  => $schema->string()->description('New education level. Resolve via lookup_options with type: "education".'),
			'religion_id'   => $schema->string()->description('New religion. Resolve via lookup_options with type: "religion".'),
			'marital_status_id'     => $schema->string()->description('New marital status. Resolve via lookup_options with type: "marital_status".'),
			'preferred_language_id' => $schema->string()->description('New preferred language. Resolve via lookup_options with type: "preferred_language".'),
			'recipients_name' => $schema->string()->description('Name used when addressing correspondence to this contact.'),
			'notes'           => $schema->string()->description('Free-text notes about the contact.'),
			'new_account' => $schema->object(
				CreateAccountTool::coreFields($schema)
			)->description(
				'Provide instead of account_id ONLY when the user explicitly wants a brand-new company/account created '
					. 'and this contact set as its primary contact in the same confirmation — never as a substitute for '
					. 'resolving an existing one with the account search tool available to you. Optional.'
			),
			'detail_addresses' => $schema->array()->items($schema->object(array_merge($detailMeta, $addressFields)))->description(
				'Manage addresses under this contact in the same confirmation — omit id to add a new one, pass id '
					. 'with fields to update an existing one, pass id with delete:true to remove one. Supports multiple. Optional.'
			),
			'detail_communications' => $schema->array()->items($schema->object(array_merge($detailMeta, $communicationFields)))->description(
				'Manage communication channels under this contact in the same confirmation — omit id to add a new one, '
					. 'pass id with fields to update an existing one, pass id with delete:true to remove one. Supports multiple. Optional.'
			),
			'detail_hobbies' => $schema->array()->items($schema->object(array_merge($detailMeta, $hobbyFields)))->description(
				'Manage hobbies under this contact in the same confirmation — omit id to add a new one, '
					. 'pass id with fields to update an existing one, pass id with delete:true to remove one. Supports multiple. Optional.'
			),
			'detail_related_contacts' => $schema->array()->items($schema->object(array_merge($detailMeta, $relatedContactFields)))->description(
				'Manage relationship links under this contact in the same confirmation — omit id to add a new one, '
					. 'pass id with fields to update an existing one, pass id with delete:true to remove one. Supports multiple. Optional.'
			),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::reference(column: 'account_id', label: 'account', modelKey: 'account'),
			AiColumn::lookup(column: 'salutation_id', label: 'salutation', modelKey: 'salutation'),
			AiColumn::lookup(column: 'gender_id', label: 'gender', modelKey: 'gender'),
			AiColumn::lookup(column: 'education_id', label: 'education', modelKey: 'education'),
			AiColumn::lookup(column: 'religion_id', label: 'religion', modelKey: 'religion'),
			AiColumn::lookup(column: 'marital_status_id', label: 'marital status', modelKey: 'marital_status'),
			AiColumn::lookup(column: 'preferred_language_id', label: 'preferred language', modelKey: 'preferred_language'),
		];
	}

	protected function rules(): array
	{
		return ContactRequest::updateRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/update-contact" with no other text, ask which contact and what to change. '
			. 'If the user sends "/update-contact" followed by a description of the changes, '
			. 'extract the fields directly and proceed to confirmation — skip clarifying questions unless a field is ambiguous.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to edit or update a contact, first locate it with the contact search tool available to you '
			. 'if the id is not already known, then confirm the changes before calling this tool.'
			. "\n\n"
			. 'ACCOUNT: If the user wants to change which company this contact belongs to, never resolve the account '
			. 'from a name alone — account names can repeat, be mistyped, reordered, or given partially/with extra '
			. 'words. Ask which account they mean if unclear, optionally narrowing by industry, phone, or email, '
			. 'then call the account search tool with an OR-group covering every possibility given: combine `name SIMILAR '
			. '<value>` OR `name LIKE <value>` for the name, plus `industry_id EQUAL`, `primary_phone LIKE`, '
			. '`email LIKE` for whatever else was given. Any account is a valid match here — unlike primary contact '
			. 'on the account module, there is no base condition to keep (no account_id restriction). If results '
			. 'are still ambiguous, ask the user to pick manually. If the user explicitly wants to create a new '
			. 'company in the same step, use new_account instead.'
			. "\n\n"
			. 'PHONE NUMBERS: primary_phone is a landline/office number; primary_mobile_phone is a mobile/cell/'
			. 'WhatsApp number — they are different fields. Infer which is which from how the user refers to it '
			. '(mobile/cell/WhatsApp wording → primary_mobile_phone; landline/office/home phone wording → '
			. 'primary_phone), regardless of the language the user is speaking. If the user gives a single new '
			. 'number without saying which type, and the contact currently has no phone number on file at all, set '
			. 'both primary_phone and primary_mobile_phone to that value. Otherwise, if it is unclear which of the '
			. 'two they mean to change, ask.'
			. "\n\n"
			. 'If a salutation implies gender (Mr = Male, Mrs/Ms = Female) and gender is not given, set gender accordingly.'
			. "\n\n"
			. 'DETAILS: If the user also wants addresses, communication channels, hobbies, or relationship links '
			. 'added, changed, or removed under this contact in the same request, pass them via '
			. 'detail_addresses/detail_communications/detail_hobbies/detail_related_contacts — everything is applied '
			. 'together in this same confirmation.'
			. "\n\n"
			. 'Profile picture is not settable here — set it via the web app.';
	}

	protected function findRecordById(string $id): ?Contact
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('contact'))(new (Helper::model('contact')));

		return $repo->find($id);
	}

	protected function currentData(mixed $record): array
	{
		return [
			'name'                  => $record->name,
			'primary_phone'         => $record->primary_phone,
			'primary_mobile_phone'  => $record->primary_mobile_phone,
			'job_title'             => $record->job_title,
			'email'                 => $record->email,
			'account_id'            => $record->account_id,
			'salutation_id'         => $record->salutation_id,
			'also_known_as'         => $record->also_known_as,
			'birth_date'            => $record->birth_date,
			'gender_id'             => $record->gender_id,
			'education_id'          => $record->education_id,
			'religion_id'           => $record->religion_id,
			'marital_status_id'     => $record->marital_status_id,
			'preferred_language_id' => $record->preferred_language_id,
			'recipients_name'       => $record->recipients_name,
			'notes'                 => $record->notes,
		];
	}

	public function validateConfirmation(Request $request): array
	{
		$result = parent::validateConfirmation($request);

		if (isset($result['error'])) {
			return $result;
		}

		$newAccount = $request['new_account'] ?? null;
		if (!empty($newAccount)) {
			$accountValidator = Validator::make((array) $newAccount, AccountRequest::createRules());

			if ($accountValidator->fails()) {
				return AiResponse::error(AiErrorCode::UserError,'New account validation failed.', ['messages' => $accountValidator->errors()->all()]);
			}

			$result['payload']['changes']['new_account'] = $accountValidator->validated();
			$result['summary']['new_account']            = $accountValidator->validated()['name'];
		}

		$contactId = trim((string) ($request['id'] ?? ''));

		[$addresses, $addressErrors] = $this->resolveDetailOperations(
			(array) ($request['detail_addresses'] ?? []), Helper::model('contact_address'), ContactAddressRequest::createRules(), ContactAddressRequest::updateRules(), 'contact_id', $contactId,
		);
		if (!empty($addressErrors)) {
			return AiResponse::error(AiErrorCode::UserError,'One or more detail addresses failed validation.', ['messages' => $addressErrors]);
		}

		[$communications, $commErrors] = $this->resolveDetailOperations(
			(array) ($request['detail_communications'] ?? []), Helper::model('contact_communication'), ContactCommunicationRequest::createRules(), ContactCommunicationRequest::updateRules(), 'contact_id', $contactId,
		);
		if (!empty($commErrors)) {
			return AiResponse::error(AiErrorCode::UserError,'One or more detail communications failed validation.', ['messages' => $commErrors]);
		}

		[$hobbies, $hobbyErrors] = $this->resolveDetailOperations(
			(array) ($request['detail_hobbies'] ?? []), Helper::model('contact_hobby'), ContactHobbyRequest::createRules(), ContactHobbyRequest::updateRules(), 'contact_id', $contactId,
		);
		if (!empty($hobbyErrors)) {
			return AiResponse::error(AiErrorCode::UserError,'One or more detail hobbies failed validation.', ['messages' => $hobbyErrors]);
		}

		[$relatedContacts, $relatedErrors] = $this->resolveDetailOperations(
			(array) ($request['detail_related_contacts'] ?? []), Helper::model('related_contact'), RelatedContactRequest::createRules(), RelatedContactRequest::updateRules(), 'contact_id', $contactId,
		);
		if (!empty($relatedErrors)) {
			return AiResponse::error(AiErrorCode::UserError,'One or more detail related contacts failed validation.', ['messages' => $relatedErrors]);
		}

		$result['payload']['changes']['detail_addresses']        = $addresses;
		$result['payload']['changes']['detail_communications']   = $communications;
		$result['payload']['changes']['detail_hobbies']          = $hobbies;
		$result['payload']['changes']['detail_related_contacts'] = $relatedContacts;

		foreach ([
			'detail_addresses'        => $addresses,
			'detail_communications'   => $communications,
			'detail_hobbies'          => $hobbies,
			'detail_related_contacts' => $relatedContacts,
		] as $key => $ops) {
			if (!empty($ops['create']) || !empty($ops['update']) || !empty($ops['delete'])) {
				$result['summary'][$key] = [
					'add'    => count($ops['create']),
					'update' => count($ops['update']),
					'delete' => count($ops['delete']),
				];
			}
		}

		return $result;
	}

	protected function afterUpdate(mixed $record, array $changes): void
	{
		$newAccountId = $changes['_new_account_id'] ?? null;
		if ($newAccountId !== null) {
			$accountRepo = new (Helper::repository('account'))(new (Helper::model('account')), transaction: false);
			$accountRepo->update($newAccountId, ['primary_contact_id' => $record->id]);
		}

		$addressOps       = $changes['detail_addresses']        ?? ['create' => [], 'update' => [], 'delete' => []];
		$communicationOps = $changes['detail_communications']   ?? ['create' => [], 'update' => [], 'delete' => []];
		$hobbyOps         = $changes['detail_hobbies']          ?? ['create' => [], 'update' => [], 'delete' => []];
		$relatedOps       = $changes['detail_related_contacts'] ?? ['create' => [], 'update' => [], 'delete' => []];

		if (!empty($addressOps['create']) || !empty($addressOps['update']) || !empty($addressOps['delete'])) {
			$addressRepo = new (Helper::repository('contact_address'))(new (Helper::model('contact_address')), transaction: false);
			foreach ($addressOps['create'] as $data) { 
				$addressRepo->create($data); 
			}

			foreach ($addressOps['update'] as $id => $data) { 
				$addressRepo->update($id, $data); 
			}

			foreach ($addressOps['delete'] as $id) { 
				$addressRepo->delete($id); 
			}
		}

		if (!empty($communicationOps['create']) || !empty($communicationOps['update']) || !empty($communicationOps['delete'])) {
			$communicationRepo = new (Helper::repository('contact_communication'))(new (Helper::model('contact_communication')), transaction: false);
			foreach ($communicationOps['create'] as $data) { 
				$communicationRepo->create($data); 
			}

			foreach ($communicationOps['update'] as $id => $data) { 
				$communicationRepo->update($id, $data); 
			}

			foreach ($communicationOps['delete'] as $id) { 
				$communicationRepo->delete($id); 
			}
		}

		if (!empty($hobbyOps['create']) || !empty($hobbyOps['update']) || !empty($hobbyOps['delete'])) {
			$hobbyRepo = new (Helper::repository('contact_hobby'))(new (Helper::model('contact_hobby')), transaction: false);
			foreach ($hobbyOps['create'] as $data) { 
				$hobbyRepo->create($data); 
			}

			foreach ($hobbyOps['update'] as $id => $data) { 
				$hobbyRepo->update($id, $data); 
			}

			foreach ($hobbyOps['delete'] as $id) { 
				$hobbyRepo->delete($id); 
			}
		}

		if (!empty($relatedOps['create']) || !empty($relatedOps['update']) || !empty($relatedOps['delete'])) {
			$relatedContactRepo = new (Helper::repository('related_contact'))(new (Helper::model('related_contact')), transaction: false);
			foreach ($relatedOps['create'] as $data) { 
				$relatedContactRepo->create($data); 
			}

			foreach ($relatedOps['update'] as $id => $data) { 
				$relatedContactRepo->update($id, $data); 
			}

			foreach ($relatedOps['delete'] as $id) { 
				$relatedContactRepo->delete($id); 
			}
		}
	}

	protected function excludedChangeKeys(): array
	{
		return ['new_account', '_new_account_id', 'detail_addresses', 'detail_communications', 'detail_hobbies', 'detail_related_contacts'];
	}

	protected function update(mixed $record, array $validated, array $changes): array
	{
		$newAccount = $changes['new_account'] ?? null;

		return DB::transaction(function () use ($record, $validated, $changes, $newAccount) {
			if (!empty($newAccount)) {
				$accountRepo = new (Helper::repository('account'))(new (Helper::model('account')), transaction: false);
				$account     = $accountRepo->create($newAccount);

				$validated['account_id']    = $account->id;
				$changes['_new_account_id'] = $account->id;
			}

			$repo = new (Helper::repository('contact'))(new (Helper::model('contact')), transaction: false);
			$repo->update($record->id, $validated,
				before: fn ($record, $data) => $this->beforeUpdate($record, $data, $changes),
				after:  fn ($record) => $this->afterUpdate($record, $changes),
			);

			$fieldChanges = collect($changes)->except($this->excludedChangeKeys())->all();

			return AiResponse::success(
				[
					'id'      => $record->id,
					'name'    => $fieldChanges['name'] ?? $record->name,
					'updated' => array_keys($fieldChanges),
				],
				instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
			);
		});
	}
}
