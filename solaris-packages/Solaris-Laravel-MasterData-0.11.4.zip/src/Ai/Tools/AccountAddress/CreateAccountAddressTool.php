<?php

namespace Solaris\MasterData\Ai\Tools\AccountAddress;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseCreateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Http\Requests\AccountAddressRequest;

class CreateAccountAddressTool extends BaseCreateAiTool
{
	public static function slug(): string
	{
		return 'create_account_address';
	}

	protected function resourceLabel(): string
	{
		return 'account address';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'account_id' => $schema->string()
				->description('The account id this address belongs to. Obtain it with the account search tool available to you first.')
				->required(),
			'address_type_id' => $schema->string()
				->description('Type of address. Resolve via lookup_options with type: "address_type".')
				->required(),
			'address' => $schema->string()
				->description('Full street address detail.')
				->required(),
			'postcode'    => $schema->string()->description('Postal code.'),
			'country_id'  => $schema->string()->description('Country id from lookup_region.'),
			'province_id' => $schema->string()->description('Province id from lookup_region.'),
			'city_id'     => $schema->string()->description('City id from lookup_region.'),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::lookup(column: 'address_type_id', label: 'address type', modelKey: 'address_type'),
		];
	}

	protected function rules(): array
	{
		return AccountAddressRequest::createRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/add-account-address" with no other text, ask which account and for the address details. '
			. 'If the user sends "/add-account-address" followed by the address details, extract the fields directly and proceed to confirmation.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to add an address to an account, first locate the account via '
			. 'the account search tool if the id is not already known, then confirm the address details before calling this tool.'
			. "\n\n"
			. 'For address regions (country/province/city), resolve the id via lookup_region and pass only the most '
			. 'specific level the user provided.';
	}

	protected function create(array $validated, array $raw): array
	{
		$repo    = new (Helper::repository('account_address'))(new (Helper::model('account_address')));
		$address = $repo->create($validated,
			before: fn ($data)   => $this->beforeCreate($data, $raw),
			after:  fn ($record) => $this->afterCreate($record, $raw),
		);

		return AiResponse::success(
			['id' => $address->id, 'address' => $address->address],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
