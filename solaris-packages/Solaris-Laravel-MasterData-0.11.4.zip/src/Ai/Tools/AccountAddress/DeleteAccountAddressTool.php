<?php

namespace Solaris\MasterData\Ai\Tools\AccountAddress;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseDeleteAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Models\AccountAddress;

class DeleteAccountAddressTool extends BaseDeleteAiTool
{
	public static function slug(): string
	{
		return 'delete_account_address';
	}

	protected function resourceLabel(): string
	{
		return 'account address';
	}

	protected function findRecordById(string $id): ?AccountAddress
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('account_address'))(new (Helper::model('account_address')));

		return $repo->find($id);
	}

	protected function delete(Model $record): array
	{
		$repo = new (Helper::repository('account_address'))(new (Helper::model('account_address')));
		$repo->delete($record->id);

		return AiResponse::success(
			['deleted' => $record->address],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
