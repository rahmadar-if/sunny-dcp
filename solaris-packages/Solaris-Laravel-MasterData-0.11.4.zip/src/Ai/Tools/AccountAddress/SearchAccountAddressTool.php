<?php

namespace Solaris\MasterData\Ai\Tools\AccountAddress;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

class SearchAccountAddressTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_account_address';
	}

	protected function resourceLabel(): string
	{
		return 'account addresses — address records belonging to an account';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('account_address'))();
	}

	protected function fields(): array
	{
		return [
			'account_id' => AiSearchColumn::reference(
				column: 'account_id',
				description: 'The account id this address belongs to. Obtain it with the account search tool available to you first.',
				modelKey: 'account',
			),
			'address' => AiSearchColumn::string(
				column: 'address',
				description: 'Full street address detail',
				searchable: true,
			),
			'address_type_id' => AiSearchColumn::lookup(
				column: 'address_type_id',
				description: 'Type of address',
				modelKey: 'address_type',
			),
			'country_id' => AiSearchColumn::reference(
				column: 'country_id',
				description: 'Country id from lookup_region',
				modelKey: 'country',
			),
			'province_id' => AiSearchColumn::reference(
				column: 'province_id',
				description: 'Province id from lookup_region',
				modelKey: 'province',
			),
			'city_id' => AiSearchColumn::reference(
				column: 'city_id',
				description: 'City id from lookup_region',
				modelKey: 'city',
			),
			'postcode' => AiSearchColumn::string(
				column: 'postcode',
				description: 'Postal code',
			),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'      => $record->id,
			'address'  => $record->address,
			'type'     => $record->address_type?->name,
			'city'     => $record->city?->name,
			'province' => $record->province?->name,
			'country'  => $record->country?->name,
			'postcode' => $record->postcode,
		];
	}
}
