<?php

namespace Solaris\MasterData\Ai\Tools\AccountAddress;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseUpdateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Http\Requests\AccountAddressRequest;
use Solaris\MasterData\Models\AccountAddress;

class UpdateAccountAddressTool extends BaseUpdateAiTool
{
	public static function slug(): string
	{
		return 'update_account_address';
	}

	protected function resourceLabel(): string
	{
		return 'account address';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'id' => $schema->string()
				->description('The account address id. Required.')
				->required(),
			'address_type_id' => $schema->string()->description('New address type. Resolve via lookup_options with type: "address_type".'),
			'address'         => $schema->string()->description('New full street address detail.'),
			'postcode'        => $schema->string()->description('New postal code.'),
			'country_id'      => $schema->string()->description('New country id from lookup_region.'),
			'province_id'     => $schema->string()->description('New province id from lookup_region.'),
			'city_id'         => $schema->string()->description('New city id from lookup_region.'),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::lookup(column: 'address_type_id', label: 'address type', modelKey: 'address_type'),
		];
	}

	protected function rules(): array
	{
		return AccountAddressRequest::updateRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/update-account-address" with no other text, ask which address and what to change. '
			. 'If the user sends "/update-account-address" followed by a description of the changes, '
			. 'extract the fields directly and proceed to confirmation.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to edit or update an address, first locate it via '
			. 'the account address search tool if the id is not already known, then confirm the changes before calling this tool.'
			. "\n\n"
			. 'For address regions (country/province/city), resolve the id via lookup_region and pass only the most '
			. 'specific level the user provided.';
	}

	protected function findRecordById(string $id): ?AccountAddress
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('account_address'))(new (Helper::model('account_address')));

		return $repo->find($id);
	}

	protected function currentData(mixed $record): array
	{
		return [
			'address_type_id' => $record->address_type_id,
			'address'         => $record->address,
			'postcode'        => $record->postcode,
			'country_id'      => $record->country_id,
			'province_id'     => $record->province_id,
			'city_id'         => $record->city_id,
		];
	}

	protected function update(mixed $record, array $validated, array $changes): array
	{
		$repo = new (Helper::repository('account_address'))(new (Helper::model('account_address')));
		$repo->update($record->id, $validated,
			before: fn ($record, $data) => $this->beforeUpdate($record, $data, $changes),
			after:  fn ($record)        => $this->afterUpdate($record, $changes),
		);

		return AiResponse::success(
			['id' => $record->id, 'updated' => array_keys($changes)],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
