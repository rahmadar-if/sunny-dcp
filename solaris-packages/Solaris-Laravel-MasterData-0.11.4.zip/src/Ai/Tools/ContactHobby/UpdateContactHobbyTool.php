<?php

namespace Solaris\MasterData\Ai\Tools\ContactHobby;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseUpdateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Http\Requests\ContactHobbyRequest;
use Solaris\MasterData\Models\ContactHobby;

class UpdateContactHobbyTool extends BaseUpdateAiTool
{
	public static function slug(): string
	{
		return 'update_contact_hobby';
	}

	protected function resourceLabel(): string
	{
		return 'contact hobby';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'id' => $schema->string()
				->description('The contact hobby id. Required.')
				->required(),
			'hobby' => $schema->string()->description('New name of the hobby or interest.'),
		];
	}

	protected function rules(): array
	{
		return ContactHobbyRequest::updateRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/update-contact-hobby" with no other text, ask which hobby and what to change it to. '
			. 'If the user sends "/update-contact-hobby" followed by the new value, extract it directly and proceed to confirmation.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to edit or correct a contact\'s hobby, first locate it via '
			. 'the contact hobby search tool if the id is not already known, then confirm the change before calling this tool.';
	}

	protected function findRecordById(string $id): ?ContactHobby
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('contact_hobby'))(new (Helper::model('contact_hobby')));

		return $repo->find($id);
	}

	protected function currentData(mixed $record): array
	{
		return [
			'hobby' => $record->hobby,
		];
	}

	protected function update(mixed $record, array $validated, array $changes): array
	{
		$repo = new (Helper::repository('contact_hobby'))(new (Helper::model('contact_hobby')));
		$repo->update($record->id, $validated,
			before: fn ($record, $data) => $this->beforeUpdate($record, $data, $changes),
			after:  fn ($record)        => $this->afterUpdate($record, $changes),
		);

		return AiResponse::success(
			['id' => $record->id, 'updated' => array_keys($changes)],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
