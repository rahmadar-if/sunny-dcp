<?php

namespace Solaris\MasterData\Ai\Tools\ContactHobby;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseCreateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Http\Requests\ContactHobbyRequest;

class CreateContactHobbyTool extends BaseCreateAiTool
{
	public static function slug(): string
	{
		return 'create_contact_hobby';
	}

	protected function resourceLabel(): string
	{
		return 'contact hobby';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'contact_id' => $schema->string()
				->description('The contact id this hobby belongs to. Obtain it with the contact search tool available to you first.')
				->required(),
			'hobby' => $schema->string()
				->description('Name of the hobby or interest.')
				->required(),
		];
	}

	protected function rules(): array
	{
		return ContactHobbyRequest::createRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/add-contact-hobby" with no other text, ask which contact and which hobby. '
			. 'If the user sends "/add-contact-hobby" followed by the details, extract the fields directly and proceed to confirmation.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to add a hobby or interest to a contact, first locate the contact via '
			. 'the contact search tool if the id is not already known, then confirm before calling this tool.';
	}

	protected function create(array $validated, array $raw): array
	{
		$repo  = new (Helper::repository('contact_hobby'))(new (Helper::model('contact_hobby')));
		$hobby = $repo->create($validated,
			before: fn ($data)   => $this->beforeCreate($data, $raw),
			after:  fn ($record) => $this->afterCreate($record, $raw),
		);

		return AiResponse::success(
			['id' => $hobby->id, 'hobby' => $hobby->hobby],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
