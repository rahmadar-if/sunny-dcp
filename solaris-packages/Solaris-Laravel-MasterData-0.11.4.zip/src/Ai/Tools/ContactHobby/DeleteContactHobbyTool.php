<?php

namespace Solaris\MasterData\Ai\Tools\ContactHobby;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseDeleteAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Models\ContactHobby;

class DeleteContactHobbyTool extends BaseDeleteAiTool
{
	public static function slug(): string
	{
		return 'delete_contact_hobby';
	}

	protected function resourceLabel(): string
	{
		return 'contact hobby';
	}

	protected function findRecordById(string $id): ?ContactHobby
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('contact_hobby'))(new (Helper::model('contact_hobby')));

		return $repo->find($id);
	}

	protected function delete(Model $record): array
	{
		$repo = new (Helper::repository('contact_hobby'))(new (Helper::model('contact_hobby')));
		$repo->delete($record->id);

		return AiResponse::success(
			['deleted' => $record->hobby],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
