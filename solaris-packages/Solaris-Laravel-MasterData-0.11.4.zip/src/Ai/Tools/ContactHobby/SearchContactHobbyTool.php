<?php

namespace Solaris\MasterData\Ai\Tools\ContactHobby;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

class SearchContactHobbyTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_contact_hobby';
	}

	protected function resourceLabel(): string
	{
		return 'contact hobbies — hobby/interest records belonging to a contact';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('contact_hobby'))();
	}

	protected function fields(): array
	{
		return [
			'contact_id' => AiSearchColumn::reference(
				column: 'contact_id',
				description: 'The contact id this hobby belongs to. Obtain it with the contact search tool available to you first.',
				modelKey: 'contact',
			),
			'hobby' => AiSearchColumn::string(
				column: 'hobby',
				description: 'Name of the hobby or interest',
				searchable: true,
			),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'   => $record->id,
			'hobby' => $record->hobby,
		];
	}
}
