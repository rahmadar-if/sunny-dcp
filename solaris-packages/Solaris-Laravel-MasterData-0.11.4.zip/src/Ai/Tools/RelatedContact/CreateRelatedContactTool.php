<?php

namespace Solaris\MasterData\Ai\Tools\RelatedContact;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseCreateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Http\Requests\RelatedContactRequest;

class CreateRelatedContactTool extends BaseCreateAiTool
{
	public static function slug(): string
	{
		return 'create_related_contact';
	}

	protected function resourceLabel(): string
	{
		return 'related contact relationship';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'contact_id' => $schema->string()
				->description('The owning contact id (the person this relationship belongs to). Obtain it with the contact search tool available to you first.')
				->required(),
			'related_contact_id' => $schema->string()
				->description('The other contact in this relationship (e.g. spouse, colleague, referrer). Obtain it with the contact search tool available to you first.')
				->required(),
			'category_id' => $schema->string()
				->description('Relationship category. Resolve via lookup_options with type: "related_contact_category".')
				->required(),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::reference(column: 'contact_id', label: 'contact', modelKey: 'contact'),
			AiColumn::reference(column: 'related_contact_id', label: 'related contact', modelKey: 'contact'),
			AiColumn::lookup(column: 'category_id', label: 'relationship category', modelKey: 'related_contact_category'),
		];
	}

	protected function rules(): array
	{
		return RelatedContactRequest::createRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/add-related-contact" with no other text, ask for the two contacts and the relationship category. '
			. 'If the user sends "/add-related-contact" followed by the relationship details, extract the fields directly and proceed to confirmation.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to link or relate two contacts, first locate both contacts via '
			. 'the contact search tool if their ids are not already known, then resolve the category via lookup_options, '
			. 'then confirm before calling this tool.'
			. "\n\n"
			. 'The relationship is directional: contact_id is the owner of the record; related_contact_id is the other party. '
			. 'If the user describes a mutual relationship, create two records (one in each direction).';
	}

	protected function create(array $validated, array $raw): array
	{
		$repo   = new (Helper::repository('related_contact'))(new (Helper::model('related_contact')));
		$record = $repo->create($validated,
			before: fn ($data)   => $this->beforeCreate($data, $raw),
			after:  fn ($record) => $this->afterCreate($record, $raw),
		);

		return AiResponse::success(
			['id' => $record->id],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
