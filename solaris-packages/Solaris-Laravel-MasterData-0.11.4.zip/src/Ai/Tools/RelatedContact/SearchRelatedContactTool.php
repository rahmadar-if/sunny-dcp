<?php

namespace Solaris\MasterData\Ai\Tools\RelatedContact;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

class SearchRelatedContactTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_related_contact';
	}

	protected function resourceLabel(): string
	{
		return 'related contacts — relationship links between two contacts (e.g. spouse, colleague, referrer), with a category describing the relationship type';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('related_contact'))();
	}

	protected function fields(): array
	{
		return [
			'contact_id' => AiSearchColumn::reference(
				column: 'contact_id',
				description: 'The owning contact id (the person this relationship record belongs to). Obtain it with the contact search tool available to you first.',
				modelKey: 'contact',
			),
			'related_contact_id' => AiSearchColumn::reference(
				column: 'related_contact_id',
				description: 'The other contact in this relationship (e.g. the spouse, colleague, or referrer). Obtain it with the contact search tool available to you first.',
				modelKey: 'contact',
			),
			'category_id' => AiSearchColumn::lookup(
				column: 'category_id',
				description: 'Category of the relationship (e.g. spouse, colleague, referrer)',
				modelKey: 'related_contact_category',
			),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'                 => $record->id,
			'_contact_id'         => $record->contact_id,
			'_related_contact_id' => $record->related_contact_id,
			'contact'             => $record->contact?->name,
			'related_contact'     => $record->related_contact?->name,
			'category'            => $record->category?->name,
		];
	}
}
