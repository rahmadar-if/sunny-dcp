<?php

namespace Solaris\MasterData\Ai\Tools\RelatedContact;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseUpdateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Http\Requests\RelatedContactRequest;
use Solaris\MasterData\Models\RelatedContact;

class UpdateRelatedContactTool extends BaseUpdateAiTool
{
	public static function slug(): string
	{
		return 'update_related_contact';
	}

	protected function resourceLabel(): string
	{
		return 'related contact relationship';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'id' => $schema->string()
				->description('The related contact record id. Required.')
				->required(),
			'related_contact_id' => $schema->string()
				->description('New contact for the other party in this relationship. Obtain it with the contact search tool available to you first.'),
			'category_id' => $schema->string()
				->description('New relationship category. Resolve via lookup_options with type: "related_contact_category".'),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::reference(column: 'related_contact_id', label: 'related contact', modelKey: 'contact'),
			AiColumn::lookup(column: 'category_id', label: 'relationship category', modelKey: 'related_contact_category'),
		];
	}

	protected function rules(): array
	{
		return RelatedContactRequest::updateRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/update-related-contact" with no other text, ask which record and what to change. '
			. 'If the user sends "/update-related-contact" followed by a description of the changes, '
			. 'extract the fields directly and proceed to confirmation.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to change a relationship link, first locate the record via '
			. 'the related contact search tool if the id is not already known, then confirm the changes before calling this tool.'
			. "\n\n"
			. 'Note: the owning contact (contact_id) cannot be changed. To relink to a different owner, '
			. 'delete the existing record and create a new one.';
	}

	protected function findRecordById(string $id): ?RelatedContact
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('related_contact'))(new (Helper::model('related_contact')));

		return $repo->find($id);
	}

	protected function currentData(mixed $record): array
	{
		return [
			'related_contact_id' => $record->related_contact_id,
			'category_id'        => $record->category_id,
		];
	}

	protected function update(mixed $record, array $validated, array $changes): array
	{
		$repo = new (Helper::repository('related_contact'))(new (Helper::model('related_contact')));
		$repo->update($record->id, $validated,
			before: fn ($record, $data) => $this->beforeUpdate($record, $data, $changes),
			after:  fn ($record)        => $this->afterUpdate($record, $changes),
		);

		return AiResponse::success(
			[
				'id'      => $record->id,
				'updated' => array_keys($changes),
			],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
