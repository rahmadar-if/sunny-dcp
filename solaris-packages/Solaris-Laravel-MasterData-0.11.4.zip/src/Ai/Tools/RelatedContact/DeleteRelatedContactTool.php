<?php

namespace Solaris\MasterData\Ai\Tools\RelatedContact;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseDeleteAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Models\RelatedContact;

class DeleteRelatedContactTool extends BaseDeleteAiTool
{
	public static function slug(): string
	{
		return 'delete_related_contact';
	}

	protected function resourceLabel(): string
	{
		return 'related contact relationship';
	}

	protected function findRecordById(string $id): ?RelatedContact
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('related_contact'))(new (Helper::model('related_contact')));

		return $repo->find($id);
	}

	protected function delete(Model $record): array
	{
		$repo = new (Helper::repository('related_contact'))(new (Helper::model('related_contact')));
		$repo->delete($record->id);

		return AiResponse::success(
			['deleted' => $record->id],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
