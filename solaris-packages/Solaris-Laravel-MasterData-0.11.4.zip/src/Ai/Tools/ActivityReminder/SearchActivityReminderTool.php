<?php

namespace Solaris\MasterData\Ai\Tools\ActivityReminder;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

class SearchActivityReminderTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_activity_reminder';
	}

	protected function resourceLabel(): string
	{
		return 'activity reminders — scheduled reminder notifications for an activity, auto-managed by the activity itself '
			. '(created/updated/removed when the activity\'s reminder settings change on the web app). This is read-only.';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('activity_reminder'))();
	}

	protected function fields(): array
	{
		return [
			'activity_id' => AiSearchColumn::reference(
				column: 'activity_id',
				description: 'The activity id this reminder belongs to. Obtain it with the activity search tool available to you first.',
				modelKey: 'activity',
			),
			'type_id' => AiSearchColumn::lookup(
				column: 'type_id',
				description: 'Reminder delivery type',
				modelKey: 'reminder_type',
			),
			'remind_at' => AiSearchColumn::datetime('remind_at', 'When the reminder is scheduled to fire'),
			'is_remind' => AiSearchColumn::boolean(
				column: 'is_remind',
				description: 'Whether the reminder has already been sent',
			),
			'to_id' => AiSearchColumn::reference(
				column: 'to_id',
				description: 'The user id this reminder is for',
				modelKey: 'user',
			),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'       => $record->id,
			'activity'  => $record->activity?->subject,
			'type'      => $record->type?->name,
			'to'        => $record->to?->name,
			'remind_at' => $record->remind_at ? Carbon::parse($record->remind_at)->format('d M Y H:i') : null,
			'sent'      => (bool) $record->is_remind,
		];
	}
}
