<?php

namespace Solaris\MasterData\Ai\Tools\Document;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseCreateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Http\Requests\DocumentRequest;

class CreateDocumentTool extends BaseCreateAiTool
{
	public static function slug(): string
	{
		return 'create_document';
	}

	protected function resourceLabel(): string
	{
		return 'document';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'date' => $schema->string()
				->description('Document date in Y-m-d format.')
				->required(),
			'type_id' => $schema->string()
				->description('Document type. Resolve via lookup_options with type: "document_type".')
				->required(),
			'status_id' => $schema->string()
				->description('Document status. Resolve via lookup_options with type: "document_status".')
				->required(),
			'account_id' => $schema->string()
				->description('The account id this document relates to. Obtain it with the account search tool available to you first. Optional.'),
			'contact_id' => $schema->string()
				->description('The contact id this document relates to. Obtain it with the contact search tool available to you first. Optional.'),
			'notes' => $schema->string()
				->description(
					'Initial notes about the document in plain WhatsApp-formatted text. Optional. '
					. 'Supported: *bold*, _italic_, ~strikethrough~, `code`, '
					. '- or • for bullet lists, 1. for numbered lists, > for blockquotes.'
				),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::lookup(column: 'type_id', label: 'document type', modelKey: 'document_type'),
			AiColumn::lookup(column: 'status_id', label: 'document status', modelKey: 'document_status'),
			AiColumn::reference(column: 'account_id', label: 'account', modelKey: 'account'),
			AiColumn::reference(column: 'contact_id', label: 'contact', modelKey: 'contact'),
		];
	}

	protected function rules(): array
	{
		return DocumentRequest::createRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/add-document" with no other text, ask for the required fields. '
			. 'If the user sends "/add-document" followed by document details, extract the fields directly and proceed to confirmation — '
			. 'skip clarifying questions unless a field is ambiguous.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to add or log a new document, gather the required fields and confirm before calling this tool. '
			. 'If the document relates to a company or person, locate it with the account search tool available to you or the contact search tool first.'
			. "\n\n"
			. 'The document number is generated automatically — never ask the user for it.';
	}

	protected function create(array $validated, array $raw): array
	{
		if (isset($raw['notes']) && $raw['notes'] !== '') {
			$validated['notes'] = $this->waToHtml($raw['notes']);
		}

		$repo     = new (Helper::repository('document'))(new (Helper::model('document')));
		$document = $repo->create($validated,
			before: fn ($data)   => $this->beforeCreate($data, $raw),
			after:  fn ($record) => $this->afterCreate($record, $raw),
		);

		return AiResponse::success(
			['id' => $document->id, 'number' => $document->number],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
