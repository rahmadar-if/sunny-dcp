<?php

namespace Solaris\MasterData\Ai\Tools\Document;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseUpdateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Http\Requests\DocumentRequest;
use Solaris\MasterData\Models\Document;

class UpdateDocumentTool extends BaseUpdateAiTool
{
	public static function slug(): string
	{
		return 'update_document';
	}

	protected function resourceLabel(): string
	{
		return 'document';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'id' => $schema->string()
				->description('The document id. Required.')
				->required(),
			'date' => $schema->string()
				->description('New document date in Y-m-d format.'),
			'type_id' => $schema->string()
				->description('New document type. Resolve via lookup_options with type: "document_type".'),
			'status_id' => $schema->string()
				->description('New document status. Resolve via lookup_options with type: "document_status".'),
			'account_id' => $schema->string()
				->description('New account id this document relates to. Obtain it with the account search tool available to you first.'),
			'contact_id' => $schema->string()
				->description('New contact id this document relates to. Obtain it with the contact search tool available to you first.'),
			'notes' => $schema->string()
				->description('Notes about the document.'),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::lookup(column: 'type_id', label: 'document type', modelKey: 'document_type'),
			AiColumn::lookup(column: 'status_id', label: 'document status', modelKey: 'document_status'),
			AiColumn::reference(column: 'account_id', label: 'account', modelKey: 'account'),
			AiColumn::reference(column: 'contact_id', label: 'contact', modelKey: 'contact'),
		];
	}

	protected function rules(): array
	{
		return DocumentRequest::updateRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/update-document" with no other text, ask which document and what to change. '
			. 'If the user sends "/update-document" followed by a description of the changes, '
			. 'extract the fields directly and proceed to confirmation — skip clarifying questions unless a field is ambiguous.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to edit or update a document, first locate it with the document search tool available to you '
			. 'if the id is not already known, then confirm the changes before calling this tool.'
			. "\n\n"
			. 'Notes are required by this system on every update — if the user has no new notes to add, reuse the existing notes unchanged.';
	}

	protected function findRecordById(string $id): ?Document
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('document'))(new (Helper::model('document')));

		return $repo->find($id);
	}

	protected function currentData(mixed $record): array
	{
		return [
			'date'       => $record->date,
			'type_id'    => $record->type_id,
			'status_id'  => $record->status_id,
			'account_id' => $record->account_id,
			'contact_id' => $record->contact_id,
			'notes'      => $record->notes,
		];
	}

	protected function update(mixed $record, array $validated, array $changes): array
	{
		$repo = new (Helper::repository('document'))(new (Helper::model('document')));
		$repo->update($record->id, $validated,
			before: fn ($record, $data) => $this->beforeUpdate($record, $data, $changes),
			after:  fn ($record)        => $this->afterUpdate($record, $changes),
		);

		return AiResponse::success(
			[
				'id'      => $record->id,
				'number'  => $record->number,
				'updated' => array_keys($changes),
			],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
