<?php

namespace Solaris\MasterData\Ai\Tools\Document;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseDeleteAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Models\Document;

class DeleteDocumentTool extends BaseDeleteAiTool
{
	public static function slug(): string
	{
		return 'delete_document';
	}

	protected function resourceLabel(): string
	{
		return 'document';
	}

	protected function findRecordById(string $id): ?Document
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('document'))(new (Helper::model('document')));

		return $repo->find($id);
	}

	protected function delete(Model $record): array
	{
		$repo = new (Helper::repository('document'))(new (Helper::model('document')));
		$repo->delete($record->id);

		return AiResponse::success(
			['deleted' => $record->number],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
