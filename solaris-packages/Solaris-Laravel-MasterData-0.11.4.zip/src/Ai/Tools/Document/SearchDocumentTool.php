<?php

namespace Solaris\MasterData\Ai\Tools\Document;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Services\Filter;

class SearchDocumentTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_document';
	}

	protected function resourceLabel(): string
	{
		return 'documents — document records linked to accounts and/or contacts';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('document'))();
	}

	protected function fields(): array
	{
		return [
			'number' => AiSearchColumn::string(
				column: 'number',
				description: 'Document number',
				searchable: true,
			),
			'notes_plain' => AiSearchColumn::string(
				column: 'notes_plain',
				description: 'Plain text notes about the document',
				operators: [Filter::Contains, Filter::FullText],
				searchable: 'FullText',
			),
			'date' => AiSearchColumn::date('date', 'Document date'),
			'type_id' => AiSearchColumn::lookup(
				column: 'type_id',
				description: 'Document type',
				modelKey: 'document_type',
			),
			'status_id' => AiSearchColumn::lookup(
				column: 'status_id',
				description: 'Document status',
				modelKey: 'document_status',
			),
			'account_id' => AiSearchColumn::reference(
				column: 'account_id',
				description: 'The account id this document relates to. Obtain it with the account search tool available to you first.',
				modelKey: 'account',
			),
			'contact_id' => AiSearchColumn::reference(
				column: 'contact_id',
				description: 'The contact id this document relates to. Obtain it with the contact search tool available to you first.',
				modelKey: 'contact',
			),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'     => $record->id,
			'number'  => $record->number,
			'date'    => $record->date,
			'type'    => $record->type?->name,
			'status'  => $record->status?->name,
			'account' => $record->account?->name,
			'contact' => $record->contact?->name,
		];
	}
}
