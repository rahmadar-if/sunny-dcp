<?php

namespace Solaris\MasterData\Ai\Tools\ProductPriceHistory;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Services\Filter;

class SearchProductPriceHistoryTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_product_price_history';
	}

	protected function resourceLabel(): string
	{
		return 'product price histories — historical price records per product, tracking price changes over time. '
			. 'A record with a null "end" is the currently active price.';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('product_price_history'))();
	}

	protected function fields(): array
	{
		return [
			'product_id' => AiSearchColumn::reference(
				column: 'product_id',
				description: 'The product id this price history belongs to. Obtain it with the product search tool available to you first.',
				modelKey: 'product',
			),
			'price' => AiSearchColumn::number(
				column: 'price',
				description: 'Price value',
				operators: [
					Filter::Equal, Filter::NotEqual, Filter::Greater, Filter::GreaterOrEqual, Filter::Less, Filter::LessOrEqual,
					Filter::Between, Filter::NotBetween, Filter::IsNull, Filter::IsNotNull,
				],
			),
			'from' => AiSearchColumn::datetime('from', 'When this price became effective'),
			'end' => AiSearchColumn::datetime('end', 'When this price stopped being effective. Null means it is the current price.'),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'     => $record->id,
			'product' => $record->product?->name,
			'price'   => $record->price,
			'from'    => $record->from ? Carbon::parse($record->from)->format('d M Y') : null,
			'end'     => $record->end ? Carbon::parse($record->end)->format('d M Y') : null,
			'current' => is_null($record->end),
		];
	}
}
