<?php

namespace Solaris\MasterData\Ai\Tools\Account;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

class SearchAccountTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_account';
	}

	protected function resourceLabel(): string
	{
		return 'accounts — company/organization records (clients, prospects, partners)';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('account'))();
	}

	protected function fields(): array
	{
		return [
			'name' => AiSearchColumn::string(
				column: 'name',
				description: 'Name of the company or organization',
				searchable: true,
			),
			'email' => AiSearchColumn::string(
				column: 'email',
				description: 'Primary contact email address',
				searchable: true,
			),
			'primary_phone' => AiSearchColumn::string(
				column: 'primary_phone',
				description: 'Primary contact phone number',
				searchable: true,
			),
			'category' => AiSearchColumn::string(
				column: 'category',
				description: 'Free-text account category',
				searchable: true,
			),
			'type_id' => AiSearchColumn::lookup(
				column: 'type_id',
				description: 'Type of account',
				modelKey: 'account_type',
			),
			'industry_id' => AiSearchColumn::lookup(
				column: 'industry_id',
				description: 'Industry the account operates in',
				modelKey: 'industry',
			),
			'business_entity_id' => AiSearchColumn::lookup(
				column: 'business_entity_id',
				description: 'Business entity type',
				modelKey: 'business_entity',
			),
			'primary_contact_id' => AiSearchColumn::reference(
				column: 'primary_contact_id',
				description: 'The account\'s designated primary contact person',
				modelKey: 'contact',
			),
			'number_of_employee_id' => AiSearchColumn::lookup(
				column: 'number_of_employee_id',
				description: 'Employee count range',
				modelKey: 'number_of_employee',
			),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'                 => $record->id,
			'_primary_contact_id' => $record->primary_contact_id,
			'name'                => $record->name,
			'type'                => $record->type?->name,
			'industry'            => $record->industry?->name,
			'email'               => $record->email,
			'primary_phone'       => $record->primary_phone,
			'category'            => $record->category,
			'primary_contact'     => $record->primary_contact?->name,
		];
	}

	protected function relations(): array
	{
		return [
			'contacts'   => 'search_contact',
			'activities' => 'search_activity',
			'addresses'  => 'search_account_address',
		];
	}
}
