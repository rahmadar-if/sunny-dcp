<?php

namespace Solaris\MasterData\Ai\Tools\Account;

use Illuminate\Database\Eloquent\Model;

// Lookup-shaped variant of search_account: just enough to turn a name the user typed into an id.
// For agents that merely REFERENCE an account (a document's account_id, an activity's account_id)
// rather than analyse one — carrying the full tool there costs ~2K tokens of columns and peer
// relation catalogues on every single step, for a capability those agents never use.
//
// Narrows by allowlist, so it deliberately extends the MasterData base rather than whatever class
// currently wins the search_account slug: array_intersect_key yields the same four columns either
// way, and the shorter chain is the stabler one. (Row-level narrowing is the opposite case — that
// one must extend the winning class, or it filters against a stale column set.)
class SearchAccountBasicTool extends SearchAccountTool
{
	public static function slug(): string
	{
		return 'search_account_basic';
	}

	protected function resourceLabel(): string
	{
		return 'accounts (companies/organizations) — name lookup only, for resolving an account id';
	}

	protected function fields(): array
	{
		return array_intersect_key(parent::fields(), array_flip([
			'name',
			'email',
			'primary_phone',
			'industry_id',
		]));
	}

	// Audit columns are dead weight on a lookup — nobody resolves an account id by who created the
	// record, and created_by_id alone carries one of the longest descriptions in the catalogue.
	protected function auditFields(): array
	{
		return [];
	}

	protected function relations(): array
	{
		return [];
	}

	// Written out rather than inherited: scopePrepared() selects only this tool's own fields plus the
	// model's $prepareColumns, so the parent's category/type/primary_contact reads would come back
	// null or trigger a lazy load. Every key below maps to a column this tool actually selects.
	protected function formatRecord(Model $record): array
	{
		return [
			'_id'           => $record->id,
			'name'          => $record->name,
			'industry'      => $record->industry?->name,
			'email'         => $record->email,
			'primary_phone' => $record->primary_phone,
		];
	}
}
