<?php

namespace Solaris\MasterData\Ai\Tools\Account;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Laravel\Ai\Tools\Request;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseUpdateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Ai\Tools\AccountAddress\CreateAccountAddressTool;
use Solaris\MasterData\Ai\Tools\Activity\CreateActivityTool;
use Solaris\MasterData\Ai\Tools\Contact\CreateContactTool;
use Solaris\MasterData\Http\Requests\AccountAddressRequest;
use Solaris\MasterData\Http\Requests\AccountRequest;
use Solaris\MasterData\Http\Requests\ActivityRequest;
use Solaris\MasterData\Http\Requests\ContactRequest;
use Solaris\MasterData\Models\Account;

class UpdateAccountTool extends BaseUpdateAiTool
{
	public static function slug(): string
	{
		return 'update_account';
	}

	protected function resourceLabel(): string
	{
		return 'account';
	}

	public static function fields(JsonSchema $schema): array
	{
		$contactFields  = Arr::except(CreateContactTool::fields($schema), ['account_id']);
		$addressFields  = Arr::except(CreateAccountAddressTool::fields($schema), ['account_id']);
		$activityFields = Arr::except(CreateActivityTool::fields($schema), ['account_id']);

		$detailMeta = [
			'id'     => $schema->string()->description('Existing record id. Omit to create a new one.'),
			'delete' => $schema->boolean()->description('Set true (with id) to remove this record instead of updating it.'),
		];

		return [
			'id' => $schema->string()
				->description('The account id. Required.')
				->required(),
			'name'          => $schema->string()->description('New name of the company or organization.'),
			'type_id'       => $schema->string()->description('New account type. Resolve via lookup_options with type: "account_type".'),
			'primary_phone' => $schema->string()->description('New primary contact phone number.'),
			'email'         => $schema->string()->description('New primary contact email address.'),
			'industry_id'   => $schema->string()->description('New industry. Resolve via lookup_options with type: "industry".'),
			'category'      => $schema->string()->description('New free-text account category.'),
			'also_known_as' => $schema->string()->description('Alternate or trading name.'),
			'website'       => $schema->string()->description('Company website URL.'),
			'business_entity_id'    => $schema->string()->description('New business entity type. Resolve via lookup_options with type: "business_entity".'),
			'number_of_employee_id' => $schema->string()->description('New employee count range. Resolve via lookup_options with type: "number_of_employee".'),
			'notes'                 => $schema->string()->description('Free-text notes about the account.'),
			'primary_contact_id' => $schema->string()->description(
				'New contact id to set as primary contact. Optional — use this OR new_primary_contact, '
					. 'never both. Resolve with the contact search tool available to you first — never match a name alone (names repeat, can '
					. 'be mistyped/reordered/partial). Ask for a narrowing detail (job title, phone, or email) '
					. 'alongside the name, then filter on base condition `account_id IS_NULL OR account_id EQUAL '
					. '<this account\'s id>` AND an OR-group of `name SIMILAR/LIKE <value>` plus `phone LIKE`/'
					. '`job_title LIKE`/`email LIKE` for whatever else was given. Always keep the base condition; '
					. 're-ask and re-search if still ambiguous. Use the id only once the user confirms a single contact.',
			),
			'new_primary_contact' => $schema->object($contactFields)->description(
				'Provide instead of primary_contact_id ONLY when the user explicitly wants a brand-new contact '
					. 'created and set as primary contact in this same confirmation — never as a substitute for '
					. 'resolving an existing one with the contact search tool available to you. Optional.'
			),
			'detail_contacts' => $schema->array()->items($schema->object(array_merge($detailMeta, $contactFields)))->description(
				'Manage contacts under this account in the same confirmation — omit id to add a new one, pass id '
					. 'with fields to update an existing one, pass id with delete:true to remove one. Supports multiple. Optional.'
			),
			'detail_addresses' => $schema->array()->items($schema->object(array_merge($detailMeta, $addressFields)))->description(
				'Manage addresses under this account in the same confirmation — omit id to add a new one, pass id '
					. 'with fields to update an existing one, pass id with delete:true to remove one. Supports multiple. Optional.'
			),
			'detail_activities' => $schema->array()->items($schema->object(array_merge($detailMeta, $activityFields)))->description(
				'Manage activities under this account in the same confirmation — omit id to add a new one, pass id '
					. 'with fields to update an existing one, pass id with delete:true to remove one. Supports multiple. Optional.'
			),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::lookup(column: 'type_id', label: 'account type', modelKey: 'account_type'),
			AiColumn::lookup(column: 'industry_id', label: 'industry', modelKey: 'industry'),
			AiColumn::lookup(column: 'business_entity_id', label: 'business entity', modelKey: 'business_entity'),
			AiColumn::lookup(column: 'number_of_employee_id', label: 'number of employees', modelKey: 'number_of_employee'),
			AiColumn::reference(column: 'primary_contact_id', label: 'primary contact', modelKey: 'contact'),
		];
	}

	protected function rules(): array
	{
		return AccountRequest::updateRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/update-account" with no other text, ask which account and what to change. '
			. 'If the user sends "/update-account" followed by a description of the changes, '
			. 'extract the fields directly and proceed to confirmation — skip clarifying questions unless a field is ambiguous.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to edit or update an account, first locate it with the account search tool available to you '
			. 'if the id is not already known, then confirm the changes before calling this tool.'
			. "\n\n"
			. 'DETAILS: If the user also wants contacts, addresses, or activities added, changed, or removed under '
			. 'this account in the same request, pass them via detail_contacts/detail_addresses/detail_activities '
			. 'instead of calling their own tools — everything is applied together in this same confirmation.'
			. "\n\n"
			. 'Profile picture is not settable here — set it via the web app.';
	}

	protected function findRecordById(string $id): ?Account
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('account'))(new (Helper::model('account')));

		return $repo->find($id);
	}

	protected function currentData(mixed $record): array
	{
		return [
			'name'                  => $record->name,
			'type_id'               => $record->type_id,
			'primary_phone'         => $record->primary_phone,
			'email'                 => $record->email,
			'industry_id'           => $record->industry_id,
			'category'              => $record->category,
			'also_known_as'         => $record->also_known_as,
			'website'               => $record->website,
			'business_entity_id'    => $record->business_entity_id,
			'number_of_employee_id' => $record->number_of_employee_id,
			'notes'                 => $record->notes,
			'primary_contact_id'    => $record->primary_contact_id,
		];
	}

	public function validateConfirmation(Request $request): array
	{
		$result = parent::validateConfirmation($request);

		if (isset($result['error'])) {
			return $result;
		}

		$newContact = $request['new_primary_contact'] ?? null;
		if (!empty($newContact)) {
			$contactValidator = Validator::make((array) $newContact, ContactRequest::createRules());

			if ($contactValidator->fails()) {
				return AiResponse::error(AiErrorCode::UserError, 'New primary contact validation failed.', ['messages' => $contactValidator->errors()->all()]);
			}

			$result['payload']['changes']['new_primary_contact'] = $contactValidator->validated();
			$result['summary']['new_primary_contact']            = $contactValidator->validated();
		}

		$accountId = trim((string) ($request['id'] ?? ''));

		[$contacts, $contactErrors] = $this->resolveDetailOperations(
			(array) ($request['detail_contacts'] ?? []), Helper::model('contact'), ContactRequest::createRules(), ContactRequest::updateRules(), 'account_id', $accountId,
		);
		if (!empty($contactErrors)) {
			return AiResponse::error(AiErrorCode::UserError, 'One or more detail contacts failed validation.', ['messages' => $contactErrors]);
		}

		[$addresses, $addressErrors] = $this->resolveDetailOperations(
			(array) ($request['detail_addresses'] ?? []), Helper::model('account_address'), AccountAddressRequest::createRules(), AccountAddressRequest::updateRules(), 'account_id', $accountId,
		);
		if (!empty($addressErrors)) {
			return AiResponse::error(AiErrorCode::UserError, 'One or more detail addresses failed validation.', ['messages' => $addressErrors]);
		}

		[$activities, $activityErrors] = $this->resolveDetailOperations(
			(array) ($request['detail_activities'] ?? []), Helper::model('activity'), ActivityRequest::createRules(), ActivityRequest::updateRules(), 'account_id', $accountId,
		);
		if (!empty($activityErrors)) {
			return AiResponse::error(AiErrorCode::UserError, 'One or more detail activities failed validation.', ['messages' => $activityErrors]);
		}

		$result['payload']['changes']['detail_contacts']   = $contacts;
		$result['payload']['changes']['detail_addresses']  = $addresses;
		$result['payload']['changes']['detail_activities'] = $activities;

		foreach (['detail_contacts' => $contacts, 'detail_addresses' => $addresses, 'detail_activities' => $activities] as $key => $ops) {
			if (!empty($ops['create']) || !empty($ops['update']) || !empty($ops['delete'])) {
				$result['summary'][$key] = [
					'add'    => count($ops['create']),
					'update' => count($ops['update']),
					'delete' => count($ops['delete']),
				];
			}
		}

		return $result;
	}

	protected function afterUpdate(mixed $record, array $changes): void
	{
		$contactOps  = $changes['detail_contacts']   ?? ['create' => [], 'update' => [], 'delete' => []];
		$addressOps  = $changes['detail_addresses']  ?? ['create' => [], 'update' => [], 'delete' => []];
		$activityOps = $changes['detail_activities'] ?? ['create' => [], 'update' => [], 'delete' => []];

		if (!empty($contactOps['create']) || !empty($contactOps['update']) || !empty($contactOps['delete'])) {
			$contactRepo = new (Helper::repository('contact'))(new (Helper::model('contact')), transaction: false);

			foreach ($contactOps['create'] as $data) {
				$contactRepo->create($data);
			}

			foreach ($contactOps['update'] as $id => $data) {
				$contactRepo->update($id, $data);
			}

			foreach ($contactOps['delete'] as $id) {
				$contactRepo->delete($id);
			}
		}

		if (!empty($addressOps['create']) || !empty($addressOps['update']) || !empty($addressOps['delete'])) {
			$addressRepo = new (Helper::repository('account_address'))(new (Helper::model('account_address')), transaction: false);

			foreach ($addressOps['create'] as $data) {
				$addressRepo->create($data);
			}

			foreach ($addressOps['update'] as $id => $data) {
				$addressRepo->update($id, $data);
			}

			foreach ($addressOps['delete'] as $id) {
				$addressRepo->delete($id);
			}
		}

		if (!empty($activityOps['create']) || !empty($activityOps['update']) || !empty($activityOps['delete'])) {
			$activityRepo = new (Helper::repository('activity'))(new (Helper::model('activity')), transaction: false);

			foreach ($activityOps['create'] as $data) {
				$activityRepo->create($data);
			}

			foreach ($activityOps['update'] as $id => $data) {
				$activityRepo->update($id, $data);
			}

			foreach ($activityOps['delete'] as $id) {
				$activityRepo->delete($id);
			}
		}
	}

	protected function excludedChangeKeys(): array
	{
		return ['new_primary_contact', 'detail_contacts', 'detail_addresses', 'detail_activities'];
	}

	protected function update(mixed $record, array $validated, array $changes): array
	{
		$newContact = $changes['new_primary_contact'] ?? null;

		if ($newContact === null && array_key_exists('primary_contact_id', $changes) && !empty($changes['primary_contact_id'])) {
			$contact = Helper::model('contact')::find($changes['primary_contact_id']);

			if (!$contact) {
				return AiResponse::error(AiErrorCode::NotFound, 'Primary contact not found.');
			}

			if (!empty($contact->account_id) && $contact->account_id !== $record->id) {
				return AiResponse::error(
					AiErrorCode::BusinessRule,
					'This contact already belongs to another account. Search again with the account_id IS_NULL filter, or pick a different contact.',
				);
			}
		}

		return DB::transaction(function () use ($record, $validated, $changes, $newContact) {
			if (!empty($newContact)) {
				$contactRepo = new (Helper::repository('contact'))(new (Helper::model('contact')), transaction: false);
				$validated['primary_contact_id'] = $contactRepo->create($newContact)->id;
			}

			$repo = new (Helper::repository('account'))(new (Helper::model('account')), transaction: false);
			$repo->update($record->id, $validated,
				before: fn ($record, $data) => $this->beforeUpdate($record, $data, $changes),
				after:  fn ($record) => $this->afterUpdate($record, $changes),
			);

			$fieldChanges = collect($changes)->except($this->excludedChangeKeys())->all();

			return AiResponse::success(
				[
					'id'      => $record->id,
					'name'    => $fieldChanges['name'] ?? $record->name,
					'updated' => array_keys($fieldChanges),
				],
				instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
			);
		});
	}
}
