<?php

namespace Solaris\MasterData\Ai\Tools\Account;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Laravel\Ai\Tools\Request;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseCreateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Ai\Tools\AccountAddress\CreateAccountAddressTool;
use Solaris\MasterData\Ai\Tools\Activity\CreateActivityTool;
use Solaris\MasterData\Ai\Tools\Contact\CreateContactTool;
use Solaris\MasterData\Http\Requests\AccountAddressRequest;
use Solaris\MasterData\Http\Requests\AccountRequest;
use Solaris\MasterData\Http\Requests\ActivityRequest;
use Solaris\MasterData\Http\Requests\ContactRequest;

class CreateAccountTool extends BaseCreateAiTool
{
	public static function slug(): string
	{
		return 'create_account';
	}

	protected function resourceLabel(): string
	{
		return 'account';
	}

	// Scalar own-fields only — no nested contact/detail_* that would re-enter fields().
	// Safe to embed in other tools (e.g. new_account on CreateContactTool); calling fields()
	// here instead would cause infinite mutual recursion since fields() embeds contact, which
	// embeds account back via coreFields.
	protected static function baseFields(JsonSchema $schema): array
	{
		return [
			'name' => $schema->string()
				->description('Name of the company or organization.')
				->required(),
			'type_id' => $schema->string()
				->description('Account type id. Resolve via lookup_options with type: "account_type".')
				->required(),
			'primary_phone' => $schema->string()
				->description('Primary contact phone number.')
				->required(),
			'email' => $schema->string()
				->description('Primary contact email address.')
				->required(),
			'industry_id' => $schema->string()
				->description('Industry the account operates in. Resolve via lookup_options with type: "industry".')
				->required(),
			'category' => $schema->string()->description('Free-text account category.'),
		];
	}

	// Fields without primary_contact_id / new_primary_contact / detail_* — for embedding in other tools
	// (e.g. new_account on CreateContactTool) where nested children are not relevant.
	public static function coreFields(JsonSchema $schema): array
	{
		return static::baseFields($schema);
	}

	// Source of truth for detail_* stays on each resource's own create tool — reusing its fields()
	// (protected, but reachable here since both extend BaseCreateAiTool) keeps nested fields in sync
	// automatically instead of retyping them.
	public static function fields(JsonSchema $schema): array
	{
		$contactFields  = Arr::except(CreateContactTool::fields($schema), ['account_id']);
		$addressFields  = Arr::except(CreateAccountAddressTool::fields($schema), ['account_id']);
		$activityFields = Arr::except(CreateActivityTool::fields($schema), ['account_id']);

		return array_merge(static::baseFields($schema), [
			'primary_contact_id' => $schema->string()->description(
				'Contact id to set as primary contact. Optional — use this OR new_primary_contact, '
					. 'never both. Resolve with the contact search tool available to you first — never match a name alone (names repeat, can '
					. 'be mistyped/reordered/partial). Ask for a narrowing detail (job title, phone, or email) '
					. 'alongside the name, then filter on base condition `account_id IS_NULL` AND an OR-group of '
					. '`name SIMILAR/LIKE <value>` plus `phone LIKE`/`job_title LIKE`/`email LIKE` for whatever '
					. 'else was given. Always keep the base condition; re-ask and re-search if still ambiguous. '
					. 'Use the id only once the user confirms a single contact.'
			),
			'new_primary_contact' => $schema->object($contactFields)->description(
				'Provide instead of primary_contact_id ONLY when the user explicitly wants a brand-new contact '
					. 'created and set as primary contact in this same confirmation — never as a substitute for '
					. 'resolving an existing one with the contact search tool available to you. Optional.'
			),
			'detail_contacts' => $schema->array()->items($schema->object($contactFields))->description(
				'Additional contacts to create under this account (people who work there, besides the primary '
					. 'contact) — each gets linked to this account automatically. Supports multiple. Optional.'
			),
			'detail_addresses' => $schema->array()->items($schema->object($addressFields))->description(
				'Addresses to create under this account, each linked automatically. Supports multiple. Optional.'
			),
			'detail_activities' => $schema->array()->items($schema->object($activityFields))->description(
				'Activities/tasks to schedule under this account, each linked automatically. Supports multiple. Optional.'
			),
		]);
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::lookup(column: 'type_id', label: 'account type', modelKey: 'account_type'),
			AiColumn::lookup(column: 'industry_id', label: 'industry', modelKey: 'industry'),
			AiColumn::reference(column: 'primary_contact_id', label: 'primary contact', modelKey: 'contact'),
		];
	}

	protected function rules(): array
	{
		return AccountRequest::createRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/add-account" with no other text, ask for the required fields one at a time or all at once. '
			. 'If the user sends "/add-account" followed by account details, extract the fields directly and proceed to confirmation — '
			. 'skip clarifying questions unless a field is ambiguous.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to add or create a new account/company/client, gather the required fields and confirm before calling this tool.'
			. "\n\n"
			. 'DETAILS: If the user also wants contacts, addresses, or activities added under this account in the '
			. 'same request, pass them via detail_contacts/detail_addresses/detail_activities instead of calling '
			. 'their own create tools — everything is created together in this same confirmation.'
			. "\n\n"
			. 'Profile picture is not settable here — set it later via the web app.';
	}

	public function validateConfirmation(Request $request): array
	{
		$result = parent::validateConfirmation($request);

		if (isset($result['error'])) {
			return $result;
		}

		$newContact = $request['new_primary_contact'] ?? null;
		if (!empty($newContact)) {
			$contactValidator = Validator::make((array) $newContact, ContactRequest::createRules());

			if ($contactValidator->fails()) {
				return AiResponse::error(AiErrorCode::UserError, 'New primary contact validation failed.', ['messages' => $contactValidator->errors()->all()]);
			}

			$result['payload']['raw']['new_primary_contact'] = $contactValidator->validated();
			$result['summary']['new_primary_contact']        = $contactValidator->validated();
		}

		// Self-generated ahead of insert — Account uses HasUuids, which respects an id already set on the
		// data array instead of generating its own. Knowing it up front lets detail_* rows (which require
		// account_id) validate for real before any confirmation is shown, instead of faking the check.
		$accountId = (string) Str::uuid7();

		[$contacts, $errors] = $this->validateDetailList((array) ($request['detail_contacts'] ?? []), ContactRequest::createRules(), 'account_id', $accountId);
		if (!empty($errors)) {
			return AiResponse::error(AiErrorCode::UserError, 'One or more detail contacts failed validation.', ['messages' => $errors]);
		}

		[$addresses, $errors] = $this->validateDetailList((array) ($request['detail_addresses'] ?? []), AccountAddressRequest::createRules(), 'account_id', $accountId);
		if (!empty($errors)) {
			return AiResponse::error(AiErrorCode::UserError, 'One or more detail addresses failed validation.', ['messages' => $errors]);
		}

		[$activities, $errors] = $this->validateDetailList((array) ($request['detail_activities'] ?? []), ActivityRequest::createRules(), 'account_id', $accountId);
		if (!empty($errors)) {
			return AiResponse::error(AiErrorCode::UserError, 'One or more detail activities failed validation.', ['messages' => $errors]);
		}

		$result['payload']['raw']['id']                = $accountId;
		$result['payload']['raw']['detail_contacts']   = $contacts;
		$result['payload']['raw']['detail_addresses']  = $addresses;
		$result['payload']['raw']['detail_activities'] = $activities;

		if (!empty($contacts)) {
			$result['summary']['detail_contacts'] = array_map(fn ($c) => $c['name'], $contacts);
		}

		if (!empty($addresses)) {
			$result['summary']['detail_addresses'] = array_map(fn ($a) => $a['address'], $addresses);
		}

		if (!empty($activities)) {
			$result['summary']['detail_activities'] = array_map(fn ($a) => $a['subject'], $activities);
		}

		return $result;
	}

	protected function afterCreate(Model $record, array $raw): void
	{
		$detailContacts   = $raw['detail_contacts'] ?? [];
		$detailAddresses  = $raw['detail_addresses'] ?? [];
		$detailActivities = $raw['detail_activities'] ?? [];

		if (!empty($detailContacts)) {
			$contactRepo = new (Helper::repository('contact'))(new (Helper::model('contact')), transaction: false);
			foreach ($detailContacts as $data) {
				$contactRepo->create($data);
			}
		}

		if (!empty($detailAddresses)) {
			$addressRepo = new (Helper::repository('account_address'))(new (Helper::model('account_address')), transaction: false);
			foreach ($detailAddresses as $data) {
				$addressRepo->create($data);
			}
		}

		if (!empty($detailActivities)) {
			$activityRepo = new (Helper::repository('activity'))(new (Helper::model('activity')), transaction: false);
			foreach ($detailActivities as $data) {
				$activityRepo->create($data);
			}
		}
	}

	protected function create(array $validated, array $raw): array
	{
		$newContact = $raw['new_primary_contact'] ?? null;

		if ($newContact === null && !empty($validated['primary_contact_id'])) {
			$contact = Helper::model('contact')::find($validated['primary_contact_id']);

			if (!$contact) {
				return AiResponse::error(AiErrorCode::NotFound, 'Primary contact not found.');
			}

			if (!empty($contact->account_id)) {
				return AiResponse::error(
					AiErrorCode::BusinessRule,
					'This contact already belongs to another account. Search again with the account_id IS_NULL filter, or pick a different contact.',
				);
			}
		}

		$validated['id'] = $raw['id'] ?? (string) Str::uuid7();

		return DB::transaction(function () use ($validated, $raw, $newContact) {
			if (!empty($newContact)) {
				$contactRepo = new (Helper::repository('contact'))(new (Helper::model('contact')), transaction: false);
				$validated['primary_contact_id'] = $contactRepo->create($newContact)->id;
			}

			$repo    = new (Helper::repository('account'))(new (Helper::model('account')), transaction: false);
			$account = $repo->create($validated,
				before: fn ($data)   => $this->beforeCreate($data, $raw),
				after:  fn ($record) => $this->afterCreate($record, $raw),
			);

			return AiResponse::success(
				['id' => $account->id, 'name' => $account->name],
				instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
			);
		});
	}
}
