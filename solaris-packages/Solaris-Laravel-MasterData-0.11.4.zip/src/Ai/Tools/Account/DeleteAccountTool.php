<?php

namespace Solaris\MasterData\Ai\Tools\Account;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseDeleteAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Models\Account;

class DeleteAccountTool extends BaseDeleteAiTool
{
	public static function slug(): string
	{
		return 'delete_account';
	}

	protected function resourceLabel(): string
	{
		return 'account';
	}

	protected function findRecordById(string $id): ?Account
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('account'))(new (Helper::model('account')));

		return $repo->find($id);
	}

	protected function delete(Model $record): array
	{
		$repo = new (Helper::repository('account'))(new (Helper::model('account')));
		$repo->delete($record->id);

		return AiResponse::success(
			['deleted' => $record->name],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
