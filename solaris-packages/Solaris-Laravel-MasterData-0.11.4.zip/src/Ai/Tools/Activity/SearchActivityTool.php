<?php

namespace Solaris\MasterData\Ai\Tools\Activity;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Services\Filter;

class SearchActivityTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_activity';
	}

	protected function resourceLabel(): string
	{
		return 'activities — scheduled tasks, meetings, and to-dos, optionally linked to an account or contact';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('activity'))();
	}

	protected function fields(): array
	{
		return [
			'subject' => AiSearchColumn::string(
				column: 'subject',
				description: 'Subject or title of the activity. For filters, combine SIMILAR OR LIKE in the '
					. 'same OR-group — SIMILAR tolerates typos/reordering/partial/extra wording, LIKE catches '
					. 'plain substring matches SIMILAR can miss.',
				searchable: true,
			),
			'notes_plain' => AiSearchColumn::string(
				column: 'notes_plain',
				description: 'Plain text notes about the activity',
				operators: [Filter::Contains, Filter::FullText],
				searchable: 'FullText',
			),
			'start_date' => AiSearchColumn::datetime('start_date', 'Start date/time of the activity'),
			'end_date' => AiSearchColumn::datetime('end_date', 'End date/time of the activity'),
			'category_id' => AiSearchColumn::lookup(
				column: 'category_id',
				description: 'Activity category',
				modelKey: 'activity_category',
			),
			'priority_id' => AiSearchColumn::lookup(
				column: 'priority_id',
				description: 'Activity priority',
				modelKey: 'activity_priority',
			),
			'status_id' => AiSearchColumn::lookup(
				column: 'status_id',
				description: 'Activity status',
				modelKey: 'activity_status',
			),
			'account_id' => AiSearchColumn::reference(
				column: 'account_id',
				description: 'The account id this activity relates to. Obtain it with the account search tool available to you first.',
				modelKey: 'account',
			),
			'contact_id' => AiSearchColumn::reference(
				column: 'contact_id',
				description: 'The contact id this activity relates to. Obtain it with the contact search tool available to you first.',
				modelKey: 'contact',
			),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'        => $record->id,
			'subject'    => $record->subject,
			'start_date' => $record->start_date ? Carbon::parse($record->start_date)->format('d M Y H:i') : null,
			'end_date'   => $record->end_date ? Carbon::parse($record->end_date)->format('d M Y H:i') : null,
			'category'   => $record->category?->name,
			'priority'   => $record->priority?->name,
			'status'     => $record->status?->name,
			'account'    => $record->account?->name,
			'contact'    => $record->contact?->name,
		];
	}

	protected function relations(): array
	{
		return [
			'reminders' => 'search_activity_reminder',
		];
	}
}
