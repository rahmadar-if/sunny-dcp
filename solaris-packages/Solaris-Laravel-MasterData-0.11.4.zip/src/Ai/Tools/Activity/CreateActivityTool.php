<?php

namespace Solaris\MasterData\Ai\Tools\Activity;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseCreateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Http\Requests\ActivityRequest;

class CreateActivityTool extends BaseCreateAiTool
{
	public static function slug(): string
	{
		return 'create_activity';
	}

	protected function resourceLabel(): string
	{
		return 'activity';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'subject' => $schema->string()
				->description('Subject or title of the activity.')
				->required(),
			'start_date' => $schema->string()
				->description('Start date/time in Y-m-d H:i format.')
				->required(),
			'category_id' => $schema->string()
				->description('Activity category. Resolve via lookup_options with type: "activity_category".')
				->required(),
			'priority_id' => $schema->string()
				->description('Activity priority. Resolve via lookup_options with type: "activity_priority".')
				->required(),
			'end_date' => $schema->string()->description(
				'End date/time in Y-m-d H:i format. Must not be earlier than the start date.'
			),
			'account_id' => $schema->string()->description(
				'The account id this activity relates to. Obtain it with the account search tool available to you first. Optional.'
			),
			'contact_id' => $schema->string()->description(
				'The contact id this activity relates to. Obtain it with the contact search tool available to you first. Optional.'
			),
			'remind_me' => $schema->boolean()->description(
				'Set to true to create reminders for this activity. Requires reminder_type_ids. '
					. 'Only meaningful if start_date is in the future.'
			),
			'reminder_type_ids' => $schema->array()->items($schema->string())->description(
				'Reminder timing type ids (e.g. "15 minutes before", "1 hour before"). '
					. 'Resolve via lookup_options with type: "reminder_type". '
					. 'Required when remind_me is true. Only types whose offset still falls in the future are valid.'
			),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::lookup(column: 'category_id', label: 'category', modelKey: 'activity_category'),
			AiColumn::lookup(column: 'priority_id', label: 'priority', modelKey: 'activity_priority'),
		];
	}

	protected function rules(): array
	{
		$rules = ActivityRequest::createRules();

		unset(
			$rules['reminder_types'],
			$rules['reminder_types.*.id'],
			$rules['reminder_types.*.checked'],
			$rules['remind_to'],
		);

		return array_merge($rules, [
			'reminder_type_ids'   => 'nullable|array',
			'reminder_type_ids.*' => 'uuid',
		]);
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/add-activity" with no other text, ask for the required fields. '
			. 'If the user sends "/add-activity" followed by activity details, extract the fields directly and proceed to confirmation — '
			. 'skip clarifying questions unless a field is ambiguous.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to schedule, log, or add a new activity/task/meeting, gather the required '
			. 'fields and confirm before calling this tool. If it relates to a company or person, locate it via '
			. 'the account search tool or the contact search tool first.'
			. "\n\n"
			. 'REMINDERS: If the user wants to be reminded, set remind_me to true and pass one or more reminder_type_ids. '
			. 'Reminder types define how far in advance to notify (e.g. 15 minutes, 1 hour, 1 day before start). '
			. 'Only offer reminders when start_date is in the future. The current user is always included in the reminder.';
	}

	protected function create(array $validated, array $raw): array
	{
		$repoData = $validated;
		unset($repoData['reminder_type_ids']);

		if (!empty($raw['remind_me']) && !empty($raw['reminder_type_ids'])) {
			$repoData['remind_me']      = true;
			$repoData['reminder_types'] = array_map(
				fn ($id) => ['id' => $id, 'checked' => true],
				(array) $raw['reminder_type_ids'],
			);
		}

		$repo     = new (Helper::repository('activity'))(new (Helper::model('activity')));
		$activity = $repo->create($repoData,
			before: fn ($data)   => $this->beforeCreate($data, $raw),
			after:  fn ($record) => $this->afterCreate($record, $raw),
		);

		return AiResponse::success(
			['id' => $activity->id, 'subject' => $activity->subject],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
