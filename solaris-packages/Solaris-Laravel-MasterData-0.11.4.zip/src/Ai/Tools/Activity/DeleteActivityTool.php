<?php

namespace Solaris\MasterData\Ai\Tools\Activity;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseDeleteAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Models\Activity;

class DeleteActivityTool extends BaseDeleteAiTool
{
	public static function slug(): string
	{
		return 'delete_activity';
	}

	protected function resourceLabel(): string
	{
		return 'activity';
	}

	protected function findRecordById(string $id): ?Activity
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('activity'))(new (Helper::model('activity')));

		return $repo->find($id);
	}

	protected function delete(Model $record): array
	{
		$repo = new (Helper::repository('activity'))(new (Helper::model('activity')));
		$repo->delete($record->id);

		return AiResponse::success(
			['deleted' => $record->subject],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
