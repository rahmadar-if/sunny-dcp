<?php

namespace Solaris\MasterData\Ai\Tools\Activity;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseUpdateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Http\Requests\ActivityRequest;
use Solaris\MasterData\Models\Activity;

class UpdateActivityTool extends BaseUpdateAiTool
{
	public static function slug(): string
	{
		return 'update_activity';
	}

	protected function resourceLabel(): string
	{
		return 'activity';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'id' => $schema->string()
				->description('The activity id. Required.')
				->required(),
			'subject'    => $schema->string()->description('New subject or title of the activity.'),
			'start_date' => $schema->string()->description('New start date/time in Y-m-d H:i format.'),
			'end_date'   => $schema->string()->description(
				'New end date/time in Y-m-d H:i format. Must not be earlier than the start date. '
					. 'Required if status is set to Finish.'
			),
			'category_id' => $schema->string()->description('New activity category. Resolve via lookup_options with type: "activity_category".'),
			'priority_id' => $schema->string()->description('New activity priority. Resolve via lookup_options with type: "activity_priority".'),
			'status_id'   => $schema->string()->description('New activity status. Resolve via lookup_options with type: "activity_status".'),
			'account_id'  => $schema->string()->description('New account id this activity relates to. Obtain it with the account search tool available to you first.'),
			'contact_id'  => $schema->string()->description('New contact id this activity relates to. Obtain it with the contact search tool available to you first.'),
			'notes'       => $schema->string()->description('Free-text notes about the activity.'),
			'remind_me'   => $schema->boolean()->description(
				'Set to false to remove all pending reminders. Set to true with reminder_type_ids to configure reminders.'
			),
			'reminder_type_ids' => $schema->array()->items($schema->string())->description(
				'Full list of active reminder timing type ids. Replaces the current reminder configuration — '
					. 'types not in this list will be removed. Resolve via lookup_options with type: "reminder_type". '
					. 'Only meaningful when remind_me is true and start_date is in the future.'
			),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::lookup(column: 'category_id', label: 'category', modelKey: 'activity_category'),
			AiColumn::lookup(column: 'priority_id', label: 'priority', modelKey: 'activity_priority'),
			AiColumn::lookup(column: 'status_id', label: 'status', modelKey: 'activity_status'),
		];
	}

	protected function rules(): array
	{
		$rules = ActivityRequest::updateRules();

		unset(
			$rules['reminder_types'],
			$rules['reminder_types.*.id'],
			$rules['reminder_types.*.checked'],
			$rules['remind_to'],
		);

		return array_merge($rules, [
			'reminder_type_ids'   => 'nullable|array',
			'reminder_type_ids.*' => 'uuid',
		]);
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/update-activity" with no other text, ask which activity and what to change. '
			. 'If the user sends "/update-activity" followed by a description of the changes, '
			. 'extract the fields directly and proceed to confirmation — skip clarifying questions unless a field is ambiguous.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to reschedule, edit, or update an activity, first locate it via '
			. 'the activity search tool if the id is not already known, then confirm the changes before calling this tool.'
			. "\n\n"
			. 'REMINDERS: To remove all reminders, pass remind_me: false. To set or replace reminders, pass '
			. 'remind_me: true with the full desired list of reminder_type_ids — this replaces the current '
			. 'reminder configuration entirely. To leave reminders unchanged, omit both fields.';
	}

	protected function findRecordById(string $id): ?Activity
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('activity'))(new (Helper::model('activity')));

		return $repo->find($id);
	}

	protected function currentData(mixed $record): array
	{
		$pendingTypeIds = Helper::model('activity_reminder')
			::where('activity_id', $record->id)
			->where('is_remind', false)
			->pluck('type_id')
			->unique()
			->values()
			->toArray();

		return [
			'subject'           => $record->subject,
			'start_date'        => $record->start_date,
			'end_date'          => $record->end_date,
			'category_id'       => $record->category_id,
			'priority_id'       => $record->priority_id,
			'status_id'         => $record->status_id,
			'account_id'        => $record->account_id,
			'contact_id'        => $record->contact_id,
			'notes'             => $record->notes,
			'remind_me'         => !empty($pendingTypeIds),
			'reminder_type_ids' => $pendingTypeIds,
		];
	}

	// Ensure remind_me is injected when reminder_type_ids is provided alone, so
	// the repository's updated() hook does not treat it as "clear all reminders".
	protected function beforeValidation(mixed $record, array $changes): array
	{
		if (!empty($changes['reminder_type_ids']) && !array_key_exists('remind_me', $changes)) {
			$changes['remind_me'] = true;
		}

		return $changes;
	}

	protected function excludedChangeKeys(): array
	{
		return ['remind_me', 'reminder_type_ids'];
	}

	protected function update(mixed $record, array $validated, array $changes): array
	{
		$repoData = $validated;
		unset($repoData['reminder_type_ids']);

		// Resolve remind_me: prefer explicit change, fall back to current state.
		if (array_key_exists('remind_me', $changes)) {
			$remindMe = (bool) $changes['remind_me'];
		} else {
			$remindMe = Helper::model('activity_reminder')
				::where('activity_id', $record->id)
				->where('is_remind', false)
				->exists();
		}

		$repoData['remind_me'] = $remindMe;

		// If reminder_type_ids changed, build full reminder_types array (checked + unchecked)
		// so the repository can properly add new types and remove deselected ones.
		if (array_key_exists('reminder_type_ids', $changes) && $remindMe) {
			$allTypeIds  = Helper::model('reminder_type')::pluck('id')->toArray();
			$selectedIds = (array) ($changes['reminder_type_ids'] ?? []);

			$repoData['reminder_types'] = array_map(
				fn ($id) => ['id' => $id, 'checked' => in_array($id, $selectedIds)],
				$allTypeIds,
			);
		}

		$repo = new (Helper::repository('activity'))(new (Helper::model('activity')));
		$repo->update($record->id, $repoData,
			before: fn ($record, $data) => $this->beforeUpdate($record, $data, $changes),
			after:  fn ($record)        => $this->afterUpdate($record, $changes),
		);

		$fieldChanges = collect($changes)->except($this->excludedChangeKeys())->all();

		return AiResponse::success(
			[
				'id'      => $record->id,
				'subject' => $fieldChanges['subject'] ?? $record->subject,
				'updated' => array_keys($fieldChanges),
			],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
