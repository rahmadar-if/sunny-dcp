<?php

namespace Solaris\MasterData\Ai\Tools\ProductAvailability;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseCreateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Http\Requests\ProductAvailabilityRequest;

class CreateProductAvailabilityTool extends BaseCreateAiTool
{
	public static function slug(): string
	{
		return 'create_product_availability';
	}

	protected function resourceLabel(): string
	{
		return 'product availability record';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'product_id' => $schema->string()
				->description('The product id this stock belongs to. Obtain it with the product search tool available to you first.')
				->required(),
			'warehouse' => $schema->string()
				->description('Name of the warehouse or storage location.')
				->required(),
			'qty' => $schema->string()
				->description('Stock quantity as a plain integer.')
				->required(),
			'address' => $schema->string()
				->description('Warehouse address detail.'),
			'country_id' => $schema->string()
				->description('Country id from lookup_region.'),
			'province_id' => $schema->string()
				->description('Province id from lookup_region.'),
			'city_id' => $schema->string()
				->description('City id from lookup_region.'),
			'post_code' => $schema->string()
				->description('Postal code.'),
		];
	}

	protected function rules(): array
	{
		return ProductAvailabilityRequest::createRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/add-product-availability" with no other text, ask which product, warehouse, and quantity. '
			. 'If the user sends "/add-product-availability" followed by the details, extract the fields directly and proceed to confirmation.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to add stock or a warehouse location for a product, first locate the '
			. 'product with the product search tool available to you if the id is not already known, then confirm before calling this tool.'
			. "\n\n"
			. 'The product\'s total availability is recalculated automatically — never set it directly.';
	}

	protected function create(array $validated, array $raw): array
	{
		$repo         = new (Helper::repository('product_availability'))(new (Helper::model('product_availability')));
		$availability = $repo->create($validated,
			before: fn ($data)   => $this->beforeCreate($data, $raw),
			after:  fn ($record) => $this->afterCreate($record, $raw),
		);

		return AiResponse::success(
			['id' => $availability->id, 'warehouse' => $availability->warehouse, 'qty' => $availability->qty],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
