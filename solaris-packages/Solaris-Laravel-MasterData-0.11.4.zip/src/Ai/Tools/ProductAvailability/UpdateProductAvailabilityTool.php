<?php

namespace Solaris\MasterData\Ai\Tools\ProductAvailability;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseUpdateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Http\Requests\ProductAvailabilityRequest;
use Solaris\MasterData\Models\ProductAvailability;

class UpdateProductAvailabilityTool extends BaseUpdateAiTool
{
	public static function slug(): string
	{
		return 'update_product_availability';
	}

	protected function resourceLabel(): string
	{
		return 'product availability record';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'id' => $schema->string()
				->description('The product availability record id. Required.')
				->required(),
			'warehouse' => $schema->string()
				->description('New name of the warehouse or storage location.'),
			'qty' => $schema->string()
				->description('New stock quantity as a plain integer.'),
			'address' => $schema->string()
				->description('New warehouse address detail.'),
			'country_id' => $schema->string()
				->description('New country id from lookup_region.'),
			'province_id' => $schema->string()
				->description('New province id from lookup_region.'),
			'city_id' => $schema->string()
				->description('New city id from lookup_region.'),
			'post_code' => $schema->string()
				->description('New postal code.'),
		];
	}

	protected function rules(): array
	{
		return ProductAvailabilityRequest::updateRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/update-product-availability" with no other text, ask which record and what to change. '
			. 'If the user sends "/update-product-availability" followed by a description of the changes, '
			. 'extract the fields directly and proceed to confirmation.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to update stock quantity or warehouse info for a product, first locate '
			. 'the record with the product availability search tool available to you if the id is not already known, then confirm before calling this tool.'
			. "\n\n"
			. 'The product\'s total availability is recalculated automatically — never set it directly.';
	}

	protected function findRecordById(string $id): ?ProductAvailability
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('product_availability'))(new (Helper::model('product_availability')));

		return $repo->find($id);
	}

	protected function currentData(mixed $record): array
	{
		return [
			'warehouse'   => $record->warehouse,
			'qty'         => $record->qty,
			'address'     => $record->address,
			'country_id'  => $record->country_id,
			'province_id' => $record->province_id,
			'city_id'     => $record->city_id,
			'post_code'   => $record->post_code,
		];
	}

	protected function update(mixed $record, array $validated, array $changes): array
	{
		$repo = new (Helper::repository('product_availability'))(new (Helper::model('product_availability')));
		$repo->update($record->id, $validated,
			before: fn ($record, $data) => $this->beforeUpdate($record, $data, $changes),
			after:  fn ($record)        => $this->afterUpdate($record, $changes),
		);

		return AiResponse::success(
			[
				'id'      => $record->id,
				'updated' => array_keys($changes),
			],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
