<?php

namespace Solaris\MasterData\Ai\Tools\ProductAvailability;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

class SearchProductAvailabilityTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_product_availability';
	}

	protected function resourceLabel(): string
	{
		return 'product availability records — per-warehouse stock quantity for a product';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('product_availability'))();
	}

	protected function fields(): array
	{
		return [
			'product_id' => AiSearchColumn::reference(
				column: 'product_id',
				description: 'The product id this stock belongs to. Obtain it with the product search tool available to you first.',
				modelKey: 'product',
			),
			'warehouse' => AiSearchColumn::string(
				column: 'warehouse',
				description: 'Name of the warehouse or storage location',
				searchable: true,
			),
			'qty' => AiSearchColumn::number(
				column: 'qty',
				description: 'Stock quantity',
			),
			'country_id' => AiSearchColumn::reference(
				column: 'country_id',
				description: 'Country id from lookup_region',
				modelKey: 'country',
			),
			'province_id' => AiSearchColumn::reference(
				column: 'province_id',
				description: 'Province id from lookup_region',
				modelKey: 'province',
			),
			'city_id' => AiSearchColumn::reference(
				column: 'city_id',
				description: 'City id from lookup_region',
				modelKey: 'city',
			),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'      => $record->id,
			'warehouse' => $record->warehouse,
			'qty'      => $record->qty,
			'city'     => $record->city?->name,
			'province' => $record->province?->name,
			'country'  => $record->country?->name,
		];
	}
}
