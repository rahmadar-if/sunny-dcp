<?php

namespace Solaris\MasterData\Ai\Tools\ProductAvailability;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseDeleteAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Models\ProductAvailability;

class DeleteProductAvailabilityTool extends BaseDeleteAiTool
{
	public static function slug(): string
	{
		return 'delete_product_availability';
	}

	protected function resourceLabel(): string
	{
		return 'product availability record';
	}

	protected function findRecordById(string $id): ?ProductAvailability
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('product_availability'))(new (Helper::model('product_availability')));

		return $repo->find($id);
	}

	protected function delete(Model $record): array
	{
		$repo = new (Helper::repository('product_availability'))(new (Helper::model('product_availability')));
		$repo->delete($record->id);

		return AiResponse::success(
			['deleted' => $record->warehouse],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
