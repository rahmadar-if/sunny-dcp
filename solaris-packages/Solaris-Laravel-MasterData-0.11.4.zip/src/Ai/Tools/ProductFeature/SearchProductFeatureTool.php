<?php

namespace Solaris\MasterData\Ai\Tools\ProductFeature;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

class SearchProductFeatureTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_product_feature';
	}

	protected function resourceLabel(): string
	{
		return 'product features — feature records belonging to a product';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('product_feature'))();
	}

	protected function fields(): array
	{
		return [
			'product_id' => AiSearchColumn::reference(
				column: 'product_id',
				description: 'The product id this feature belongs to. Obtain it with the product search tool available to you first.',
				modelKey: 'product',
			),
			'name' => AiSearchColumn::string(
				column: 'name',
				description: 'Name of the feature',
				searchable: true,
			),
			'notes' => AiSearchColumn::string(
				column: 'notes',
				description: 'Additional detail about the feature',
				searchable: true,
			),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'   => $record->id,
			'name'  => $record->name,
			'notes' => $record->notes,
		];
	}
}
