<?php

namespace Solaris\MasterData\Ai\Tools\ProductFeature;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseCreateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Http\Requests\ProductFeatureRequest;

class CreateProductFeatureTool extends BaseCreateAiTool
{
	public static function slug(): string
	{
		return 'create_product_feature';
	}

	protected function resourceLabel(): string
	{
		return 'product feature';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'product_id' => $schema->string()
				->description('The product id this feature belongs to. Obtain it with the product search tool available to you first.')
				->required(),
			'name' => $schema->string()
				->description('Name of the feature.')
				->required(),
			'notes' => $schema->string()
				->description('Additional detail about the feature.'),
		];
	}

	protected function rules(): array
	{
		return ProductFeatureRequest::createRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/add-product-feature" with no other text, ask which product and for the feature details. '
			. 'If the user sends "/add-product-feature" followed by the details, extract the fields directly and proceed to confirmation.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to add a feature to a product, first locate the product via '
			. 'the product search tool if the id is not already known, then confirm before calling this tool.';
	}

	protected function create(array $validated, array $raw): array
	{
		$repo    = new (Helper::repository('product_feature'))(new (Helper::model('product_feature')));
		$feature = $repo->create($validated,
			before: fn ($data)   => $this->beforeCreate($data, $raw),
			after:  fn ($record) => $this->afterCreate($record, $raw),
		);

		return AiResponse::success(
			['id' => $feature->id, 'name' => $feature->name],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
