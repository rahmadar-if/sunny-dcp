<?php

namespace Solaris\MasterData\Ai\Tools\ProductFeature;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseDeleteAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Models\ProductFeature;

class DeleteProductFeatureTool extends BaseDeleteAiTool
{
	public static function slug(): string
	{
		return 'delete_product_feature';
	}

	protected function resourceLabel(): string
	{
		return 'product feature';
	}

	protected function findRecordById(string $id): ?ProductFeature
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('product_feature'))(new (Helper::model('product_feature')));

		return $repo->find($id);
	}

	protected function delete(Model $record): array
	{
		$repo = new (Helper::repository('product_feature'))(new (Helper::model('product_feature')));
		$repo->delete($record->id);

		return AiResponse::success(
			['deleted' => $record->name],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
