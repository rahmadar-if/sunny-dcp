<?php

namespace Solaris\MasterData\Ai\Tools\ProductFeature;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseUpdateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Http\Requests\ProductFeatureRequest;
use Solaris\MasterData\Models\ProductFeature;

class UpdateProductFeatureTool extends BaseUpdateAiTool
{
	public static function slug(): string
	{
		return 'update_product_feature';
	}

	protected function resourceLabel(): string
	{
		return 'product feature';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'id' => $schema->string()
				->description('The product feature id. Required.')
				->required(),
			'name' => $schema->string()
				->description('New name of the feature.'),
			'notes' => $schema->string()
				->description('New additional detail about the feature.'),
		];
	}

	protected function rules(): array
	{
		return ProductFeatureRequest::updateRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/update-product-feature" with no other text, ask which feature and what to change. '
			. 'If the user sends "/update-product-feature" followed by a description of the changes, '
			. 'extract the fields directly and proceed to confirmation.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to edit or update a product feature, first locate it via '
			. 'the product feature search tool if the id is not already known, then confirm the changes before calling this tool.';
	}

	protected function findRecordById(string $id): ?ProductFeature
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('product_feature'))(new (Helper::model('product_feature')));

		return $repo->find($id);
	}

	protected function currentData(mixed $record): array
	{
		return [
			'name'  => $record->name,
			'notes' => $record->notes,
		];
	}

	protected function update(mixed $record, array $validated, array $changes): array
	{
		$repo = new (Helper::repository('product_feature'))(new (Helper::model('product_feature')));
		$repo->update($record->id, $validated,
			before: fn ($record, $data) => $this->beforeUpdate($record, $data, $changes),
			after:  fn ($record)        => $this->afterUpdate($record, $changes),
		);

		return AiResponse::success(
			[
				'id'      => $record->id,
				'updated' => array_keys($changes),
			],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
