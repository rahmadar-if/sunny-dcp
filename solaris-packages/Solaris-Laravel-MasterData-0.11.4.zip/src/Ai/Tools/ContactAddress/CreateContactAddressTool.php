<?php

namespace Solaris\MasterData\Ai\Tools\ContactAddress;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseCreateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Http\Requests\ContactAddressRequest;

class CreateContactAddressTool extends BaseCreateAiTool
{
	public static function slug(): string
	{
		return 'create_contact_address';
	}

	protected function resourceLabel(): string
	{
		return 'contact address';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'contact_id' => $schema->string()
				->description('The contact id this address belongs to. Obtain it with the contact search tool available to you first.')
				->required(),
			'address_type_id' => $schema->string()
				->description('Type of address. Resolve via lookup_options with type: "address_type".')
				->required(),
			'address' => $schema->string()
				->description('Full street address detail.')
				->required(),
			'postcode'    => $schema->string()->description('Postal code.'),
			'country_id'  => $schema->string()->description('Country id from lookup_region.'),
			'province_id' => $schema->string()->description('Province id from lookup_region.'),
			'city_id'     => $schema->string()->description('City id from lookup_region.'),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::lookup(column: 'address_type_id', label: 'address type', modelKey: 'address_type'),
		];
	}

	protected function rules(): array
	{
		return ContactAddressRequest::createRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/add-contact-address" with no other text, ask which contact and for the address details. '
			. 'If the user sends "/add-contact-address" followed by the address details, extract the fields directly and proceed to confirmation.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to add an address to a contact, first locate the contact via '
			. 'the contact search tool if the id is not already known, then confirm the address details before calling this tool.'
			. "\n\n"
			. 'For address regions (country/province/city), resolve the id via lookup_region and pass only the most '
			. 'specific level the user provided.';
	}

	protected function create(array $validated, array $raw): array
	{
		$repo    = new (Helper::repository('contact_address'))(new (Helper::model('contact_address')));
		$address = $repo->create($validated,
			before: fn ($data)   => $this->beforeCreate($data, $raw),
			after:  fn ($record) => $this->afterCreate($record, $raw),
		);

		return AiResponse::success(
			['id' => $address->id, 'address' => $address->address],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
