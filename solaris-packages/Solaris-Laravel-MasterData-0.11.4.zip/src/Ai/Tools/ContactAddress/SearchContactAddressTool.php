<?php

namespace Solaris\MasterData\Ai\Tools\ContactAddress;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

class SearchContactAddressTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_contact_address';
	}

	protected function resourceLabel(): string
	{
		return 'contact addresses — address records belonging to a contact';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('contact_address'))();
	}

	protected function fields(): array
	{
		return [
			'contact_id' => AiSearchColumn::reference(
				column: 'contact_id',
				description: 'The contact id this address belongs to. Obtain it with the contact search tool available to you first.',
				modelKey: 'contact',
			),
			'address' => AiSearchColumn::string(
				column: 'address',
				description: 'Full street address detail',
				searchable: true,
			),
			'address_type_id' => AiSearchColumn::lookup(
				column: 'address_type_id',
				description: 'Type of address',
				modelKey: 'address_type',
			),
			'country_id' => AiSearchColumn::reference(
				column: 'country_id',
				description: 'Country id from lookup_region',
				modelKey: 'country',
			),
			'province_id' => AiSearchColumn::reference(
				column: 'province_id',
				description: 'Province id from lookup_region',
				modelKey: 'province',
			),
			'city_id' => AiSearchColumn::reference(
				column: 'city_id',
				description: 'City id from lookup_region',
				modelKey: 'city',
			),
			'postcode' => AiSearchColumn::string(
				column: 'postcode',
				description: 'Postal code',
			),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'      => $record->id,
			'address'  => $record->address,
			'type'     => $record->address_type?->name,
			'city'     => $record->city?->name,
			'province' => $record->province?->name,
			'country'  => $record->country?->name,
			'postcode' => $record->postcode,
		];
	}
}
