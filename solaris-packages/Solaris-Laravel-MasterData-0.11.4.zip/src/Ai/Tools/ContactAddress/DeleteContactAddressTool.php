<?php

namespace Solaris\MasterData\Ai\Tools\ContactAddress;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseDeleteAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Models\ContactAddress;

class DeleteContactAddressTool extends BaseDeleteAiTool
{
	public static function slug(): string
	{
		return 'delete_contact_address';
	}

	protected function resourceLabel(): string
	{
		return 'contact address';
	}

	protected function findRecordById(string $id): ?ContactAddress
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('contact_address'))(new (Helper::model('contact_address')));

		return $repo->find($id);
	}

	protected function delete(Model $record): array
	{
		$repo = new (Helper::repository('contact_address'))(new (Helper::model('contact_address')));
		$repo->delete($record->id);

		return AiResponse::success(
			['deleted' => $record->address],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
