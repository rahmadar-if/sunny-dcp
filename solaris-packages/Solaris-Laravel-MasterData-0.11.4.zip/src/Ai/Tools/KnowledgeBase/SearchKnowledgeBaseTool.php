<?php

namespace Solaris\MasterData\Ai\Tools\KnowledgeBase;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Services\Filter;

class SearchKnowledgeBaseTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_knowledge_base';
	}

	protected function resourceLabel(): string
	{
		return 'knowledge base articles — internal company documents, SOPs, guides, and FAQs';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('knowledge_base'))();
	}

	protected function fields(): array
	{
		return [
			'name' => AiSearchColumn::string(
				column: 'name',
				description: 'Title or name of the knowledge base article. For filters, combine SIMILAR OR '
					. 'LIKE in the same OR-group — SIMILAR tolerates typos/reordering/partial/extra wording, '
					. 'LIKE catches plain substring matches SIMILAR can miss.',
				searchable: true,
			),
			'article_plain' => AiSearchColumn::string(
				column: 'article_plain',
				description: 'Plain text content of the article body',
				operators: [Filter::Contains, Filter::FullText],
				searchable: 'FullText',
			),
			'type_id' => AiSearchColumn::lookup(
				column: 'type_id',
				description: 'Category type of the article',
				modelKey: 'knowledge_base_type',
			),
			'status_id' => AiSearchColumn::lookup(
				column: 'status_id',
				description: 'Publication status of the article',
				modelKey: 'knowledge_base_status',
			),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'           => $record->id,
			'name'          => $record->name,
			'type'          => $record->type?->name,
			'status'        => $record->status?->name,
			'article_plain' => $record->article_plain,
		];
	}
}
