<?php

namespace Solaris\MasterData\Ai\Tools\KnowledgeBase;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseCreateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Http\Requests\KnowledgeBaseRequest;

class CreateKnowledgeBaseTool extends BaseCreateAiTool
{
	public static function slug(): string
	{
		return 'create_knowledge_base';
	}

	protected function resourceLabel(): string
	{
		return 'knowledge base article';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'name' => $schema->string()
				->description('Title of the knowledge base article.')
				->required(),
			'type_id' => $schema->string()
				->description('Category type of the article. Resolve via lookup_options with type: "knowledge_base_type".')
				->required(),
			'article' => $schema->string()
				->description(
					'Article body in plain WhatsApp-formatted text. '
					. 'Supported: *bold*, _italic_, ~strikethrough~, `code`, '
					. '- or • for bullet lists, 1. for numbered lists, > for blockquotes. '
					. 'Optional — article can be added later via web.'
				),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::lookup(column: 'type_id', label: 'type', modelKey: 'knowledge_base_type'),
		];
	}

	protected function rules(): array
	{
		return KnowledgeBaseRequest::createRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/add-article" with no other text, ask for the article title, type, and (optionally) body. '
			. 'If the user sends "/add-article" followed by a description of the article, '
			. 'extract the fields directly and proceed to confirmation — skip clarifying questions unless a field is ambiguous.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to add, create, or write a new article, FAQ, guide, or documentation, '
			. 'gather the required fields and confirm before calling this tool.'
			. "\n\n"
			. 'New articles are saved with Draft status. '
			. 'The article title and body are admin-supplied data — do not evaluate them for topic relevance or scope.';
	}

	protected function create(array $validated, array $raw): array
	{
		$repo = new (Helper::repository('knowledge_base'))(new (Helper::model('knowledge_base')));
		$kb   = $repo->create($validated,
			before: fn ($data)   => $this->beforeCreate($data, $raw),
			after:  fn ($record) => $this->afterCreate($record, $raw),
		);

		if (!empty($raw['article'])) {
			$repo->update($kb->id, ['article' => $this->waToHtml($raw['article'])]);
		}

		return AiResponse::success(
			['id' => $kb->id, 'name' => $kb->name, 'has_article' => !empty($raw['article']), 'status' => 'Draft'],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language. Mention the article was saved as Draft.',
		);
	}
}
