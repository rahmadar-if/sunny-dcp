<?php

namespace Solaris\MasterData\Ai\Tools\KnowledgeBase;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseUpdateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Http\Requests\KnowledgeBaseRequest;
use Solaris\MasterData\Models\KnowledgeBase;

class UpdateKnowledgeBaseTool extends BaseUpdateAiTool
{
	public static function slug(): string
	{
		return 'update_knowledge_base';
	}

	protected function resourceLabel(): string
	{
		return 'knowledge base article';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'id' => $schema->string()
				->description('The knowledge base article id. Required.')
				->required(),
			'name' => $schema->string()
				->description('New title of the article.'),
			'type_id' => $schema->string()
				->description('New category type. Resolve via lookup_options with type: "knowledge_base_type".'),
			'status_id' => $schema->string()
				->description('New publication status. Resolve via lookup_options with type: "knowledge_base_status".'),
			'article' => $schema->string()
				->description(
					'New article body in plain WhatsApp-formatted text. Replaces existing content. '
					. 'Supported: *bold*, _italic_, ~strikethrough~, `code`, '
					. '- or • for bullet lists, 1. for numbered lists, > for blockquotes.'
				),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::lookup(column: 'type_id', label: 'type', modelKey: 'knowledge_base_type'),
			AiColumn::lookup(column: 'status_id', label: 'status', modelKey: 'knowledge_base_status'),
		];
	}

	protected function rules(): array
	{
		return KnowledgeBaseRequest::updateRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/update-article" with no other text, ask which article and what to change. '
			. 'If the user sends "/update-article" followed by a description of the changes, '
			. 'extract the fields directly and proceed to confirmation — skip clarifying questions unless a field is ambiguous.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to edit, update, or correct an article, first locate it via '
			. 'the knowledge base search tool if the id is not already known, then confirm the changes before calling this tool.'
			. "\n\n"
			. 'Article update always replaces the full content. '
			. 'For partial edits: first fetch the current article with the knowledge base search tool available to you '
			. '(article_plain field), present it to the user, apply their requested changes '
			. '(add, remove, or edit at any position), then pass the complete reconstructed '
			. 'article in WhatsApp format as the new content. '
			. 'The response includes article_plain of the saved result for follow-up edits.';
	}

	protected function findRecordById(string $id): ?KnowledgeBase
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('knowledge_base'))(new (Helper::model('knowledge_base')));

		return $repo->find($id);
	}

	protected function currentData(mixed $record): array
	{
		return [
			'name'      => $record->name,
			'type_id'   => $record->type_id,
			'status_id' => $record->status_id,
			'article'   => $record->article,
		];
	}

	protected function update(mixed $record, array $validated, array $changes): array
	{
		if (isset($changes['article'])) {
			$validated['article'] = $this->waToHtml($changes['article']);
		}

		$repo = new (Helper::repository('knowledge_base'))(new (Helper::model('knowledge_base')));
		$repo->update($record->id, $validated,
			before: fn ($record, $data) => $this->beforeUpdate($record, $data, $changes),
			after:  fn ($record)        => $this->afterUpdate($record, $changes),
		);

		$fresh = $repo->find($record->id);

		return AiResponse::success(
			[
				'id'            => $record->id,
				'name'          => $changes['name'] ?? $record->name,
				'updated'       => array_keys($changes),
				'article_plain' => $fresh?->article_plain,
			],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
