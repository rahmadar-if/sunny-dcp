<?php

namespace Solaris\MasterData\Ai\Tools\KnowledgeBase;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseDeleteAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Models\KnowledgeBase;

class DeleteKnowledgeBaseTool extends BaseDeleteAiTool
{
	public static function slug(): string
	{
		return 'delete_knowledge_base';
	}

	protected function resourceLabel(): string
	{
		return 'knowledge base article';
	}

	protected function findRecordById(string $id): ?KnowledgeBase
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('knowledge_base'))(new (Helper::model('knowledge_base')));

		return $repo->find($id);
	}

	protected function delete(Model $record): array
	{
		$repo = new (Helper::repository('knowledge_base'))(new (Helper::model('knowledge_base')));
		$repo->delete($record->id);

		return AiResponse::success(
			['deleted' => $record->name],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
