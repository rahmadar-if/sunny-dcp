<?php

namespace Solaris\MasterData\Ai\Tools\ContactCommunication;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

class SearchContactCommunicationTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_contact_communication';
	}

	protected function resourceLabel(): string
	{
		return 'contact communication channels — additional contact channels belonging to a contact (WhatsApp, social media, alternate phone, etc.)';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('contact_communication'))();
	}

	protected function fields(): array
	{
		return [
			'contact_id' => AiSearchColumn::reference(
				column: 'contact_id',
				description: 'The contact id this channel belongs to. Obtain it with the contact search tool available to you first.',
				modelKey: 'contact',
			),
			'value' => AiSearchColumn::string(
				column: 'value',
				description: 'The channel value, e.g. phone number, handle, or username',
				searchable: true,
			),
			'type_id' => AiSearchColumn::lookup(
				column: 'type_id',
				description: 'Type of communication channel',
				modelKey: 'communication_type',
			),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'   => $record->id,
			'type'  => $record->type?->name,
			'value' => $record->value,
		];
	}
}
