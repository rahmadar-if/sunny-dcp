<?php

namespace Solaris\MasterData\Ai\Tools\ContactCommunication;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseDeleteAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Models\ContactCommunication;

class DeleteContactCommunicationTool extends BaseDeleteAiTool
{
	public static function slug(): string
	{
		return 'delete_contact_communication';
	}

	protected function resourceLabel(): string
	{
		return 'contact communication channel';
	}

	protected function findRecordById(string $id): ?ContactCommunication
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('contact_communication'))(new (Helper::model('contact_communication')));

		return $repo->find($id);
	}

	protected function delete(Model $record): array
	{
		$repo = new (Helper::repository('contact_communication'))(new (Helper::model('contact_communication')));
		$repo->delete($record->id);

		return AiResponse::success(
			['deleted' => $record->value],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
