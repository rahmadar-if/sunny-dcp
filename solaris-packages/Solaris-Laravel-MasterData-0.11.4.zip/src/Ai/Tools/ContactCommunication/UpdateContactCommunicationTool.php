<?php

namespace Solaris\MasterData\Ai\Tools\ContactCommunication;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseUpdateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Http\Requests\ContactCommunicationRequest;
use Solaris\MasterData\Models\ContactCommunication;

class UpdateContactCommunicationTool extends BaseUpdateAiTool
{
	public static function slug(): string
	{
		return 'update_contact_communication';
	}

	protected function resourceLabel(): string
	{
		return 'contact communication channel';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'id' => $schema->string()
				->description('The contact communication id. Required.')
				->required(),
			'type_id' => $schema->string()->description('New communication type. Resolve via lookup_options with type: "communication_type".'),
			'value'   => $schema->string()->description('New channel value, e.g. phone number, handle, or username.'),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::lookup(column: 'type_id', label: 'communication type', modelKey: 'communication_type'),
		];
	}

	protected function rules(): array
	{
		return ContactCommunicationRequest::updateRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/update-contact-communication" with no other text, ask which channel and what to change. '
			. 'If the user sends "/update-contact-communication" followed by a description of the changes, '
			. 'extract the fields directly and proceed to confirmation.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to edit or update a contact\'s communication channel, first locate it via '
			. 'the contact communication search tool if the id is not already known, then confirm the changes before calling this tool.';
	}

	protected function findRecordById(string $id): ?ContactCommunication
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('contact_communication'))(new (Helper::model('contact_communication')));

		return $repo->find($id);
	}

	protected function currentData(mixed $record): array
	{
		return [
			'type_id' => $record->type_id,
			'value'   => $record->value,
		];
	}

	protected function update(mixed $record, array $validated, array $changes): array
	{
		$repo = new (Helper::repository('contact_communication'))(new (Helper::model('contact_communication')));
		$repo->update($record->id, $validated,
			before: fn ($record, $data) => $this->beforeUpdate($record, $data, $changes),
			after:  fn ($record)        => $this->afterUpdate($record, $changes),
		);

		return AiResponse::success(
			['id' => $record->id, 'updated' => array_keys($changes)],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
