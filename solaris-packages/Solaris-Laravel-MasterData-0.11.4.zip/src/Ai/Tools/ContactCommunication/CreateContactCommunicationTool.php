<?php

namespace Solaris\MasterData\Ai\Tools\ContactCommunication;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseCreateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Http\Requests\ContactCommunicationRequest;

class CreateContactCommunicationTool extends BaseCreateAiTool
{
	public static function slug(): string
	{
		return 'create_contact_communication';
	}

	protected function resourceLabel(): string
	{
		return 'contact communication channel';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'contact_id' => $schema->string()
				->description('The contact id this communication channel belongs to. Obtain it with the contact search tool available to you first.')
				->required(),
			'type_id' => $schema->string()
				->description('Type of communication channel (e.g. WhatsApp, Instagram, LinkedIn). Resolve via lookup_options with type: "communication_type".')
				->required(),
			'value' => $schema->string()
				->description('The channel value, e.g. phone number, handle, or username.')
				->required(),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::lookup(column: 'type_id', label: 'communication type', modelKey: 'communication_type'),
		];
	}

	protected function rules(): array
	{
		return ContactCommunicationRequest::createRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/add-contact-communication" with no other text, ask which contact, the channel type, and its value. '
			. 'If the user sends "/add-contact-communication" followed by the details, extract the fields directly and proceed to confirmation.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to add a communication channel (WhatsApp, social media, alternate phone, etc.) to a contact, '
			. 'first locate the contact with the contact search tool available to you if the id is not already known, then confirm before calling this tool. '
			. 'If uncertain about the channel type, call lookup_options first.';
	}

	protected function create(array $validated, array $raw): array
	{
		$repo = new (Helper::repository('contact_communication'))(new (Helper::model('contact_communication')));
		$comm = $repo->create($validated,
			before: fn ($data)   => $this->beforeCreate($data, $raw),
			after:  fn ($record) => $this->afterCreate($record, $raw),
		);

		return AiResponse::success(
			['id' => $comm->id, 'value' => $comm->value],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
