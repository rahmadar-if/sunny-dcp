<?php

namespace Solaris\MasterData\Jobs;

use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Solaris\MasterData\Repositories\ActivityRepository;

class ReminderNotification implements ShouldQueue, ShouldBeUnique
{
	use Queueable;

	public function handle(): void
	{
		ActivityRepository::processReminders();
	}
}
