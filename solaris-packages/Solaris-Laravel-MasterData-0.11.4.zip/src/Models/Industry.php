<?php

namespace Solaris\MasterData\Models;

use Solaris\Core\Models\LookupModel;

class Industry extends LookupModel
{
    protected $table = 'industries';
}
