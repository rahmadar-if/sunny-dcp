<?php

namespace Solaris\MasterData\Models;

use Solaris\Core\Models\LookupModel;

class BusinessEntity extends LookupModel
{
    protected $table = 'business_entities';
}
