<?php

namespace Solaris\MasterData\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Solaris\MasterData\Const\ActivityCategoryConst;
use Solaris\MasterData\Const\ActivityStatusConst;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FolderAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\ImportAccess;
use Solaris\Core\Attributes\LookupAccess;

#[FormAccess()]
#[LookupAccess()]
#[DataTableAccess(scopes: ["toDo"])]
#[FolderAccess()]
#[ExportAccess()]
#[ImportAccess()]
class Activity extends BaseModel
{
    protected $table                     = 'activities';
    protected ?string      $displayValue = 'subject';
    protected string|array $orderBy      = 'start_date';
    protected string       $direction    = 'desc';
    protected array        $searchColumns = ['notes_plain' => 'FullText'];

    protected static function booted()
    {
        parent::booted();

        $syncNotes = function ($activity) {
            if ($activity->isDirty('notes') || ($activity->notes && !$activity->notes_plain)) {
                $activity->notes_plain = $activity->notes ? Helper::stripHtml($activity->notes) : null;
            }
        };

        static::creating($syncNotes);
        static::updating($syncNotes);
    }

    protected function casts(): array
    {
        return array_merge(parent::casts(), [
            'start_date' => 'datetime',
            'end_date'   => 'datetime',
        ]);
    }

    public function priority() : BelongsTo
    {
        return $this->belongsTo(Helper::model('activity_priority'), 'priority_id', 'id');
    }

    public function category() : BelongsTo
    {
        return $this->belongsTo(Helper::model('activity_category'), 'category_id', 'id');
    }

    public function status() : BelongsTo
    {
        return $this->belongsTo(Helper::model('activity_status'), 'status_id', 'id');
    }

    public function account() : BelongsTo
    {
        return $this->belongsTo(Helper::model('account'), 'account_id', 'id');
    }

    public function contact() : BelongsTo
    {
        return $this->belongsTo(Helper::model('contact'), 'contact_id', 'id');
    }

    public function reminders() : HasMany
    {
        return $this->hasMany(Helper::model('activity_reminder'), 'activity_id', 'id');
    }

    public function scopeToDo(Builder $query)
    {
        return $query->where("category_id", ActivityCategoryConst::ToDo)
            ->where(fn($query) => $query
                ->where("status_id", "!=", ActivityStatusConst::Finish)
                ->orWhereNull("status_id")
            );
    }

    public function importRules(): array
    {
        return [
            'subject'     => ['required', 'string', 'max:255'],
            'start_date'  => ['required', 'date'],
            'category_id' => ['required', 'uuid'],
            'priority_id' => ['required', 'uuid'],
            'end_date'    => ['nullable', 'date'],
            'account_id'  => ['nullable', 'uuid'],
            'contact_id'  => ['nullable', 'uuid'],
            'remind_me'   => ['nullable', 'boolean'],
        ];
    }
}
