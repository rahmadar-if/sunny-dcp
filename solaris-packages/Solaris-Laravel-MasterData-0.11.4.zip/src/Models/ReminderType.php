<?php

namespace Solaris\MasterData\Models;

use Solaris\Core\Models\LookupModel;

class ReminderType extends LookupModel
{
    protected $table                = 'reminder_types';
    protected array $prepareColumns = ['id', 'name', 'position', 'offset_minutes'];

    protected function casts(): array
    {
        return array_merge(parent::casts(), [
            'offset_minutes' => 'integer',
        ]);
    }
}