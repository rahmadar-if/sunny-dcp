<?php

namespace Solaris\MasterData\Models;

use Solaris\Core\Models\LookupModel;

class KnowledgeBaseType extends LookupModel
{
    protected $table = 'knowledge_base_types';
}
