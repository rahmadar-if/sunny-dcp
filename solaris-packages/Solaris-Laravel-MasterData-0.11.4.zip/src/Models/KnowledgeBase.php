<?php

namespace Solaris\MasterData\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\MasterData\Const\KnowledgeBaseStatusConst;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FolderAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\ImportAccess;

#[FormAccess()]
#[DataTableAccess()]
#[ExportAccess()]
#[ImportAccess()]
#[FolderAccess()]
class KnowledgeBase extends BaseModel
{
    protected $table                  = 'knowledge_bases';
    protected ?string $displayValue   = 'name';
    protected array   $prepareColumns = ['name', 'article', 'type_id', 'status_id', 'created_by', 'updated_at'];
    protected array   $searchColumns  = ['article_plain' => 'FullText'];

    protected static function booted()
    {
        parent::booted();

        static::creating(function ($knowledgebase) {
            $knowledgebase->status_id = KnowledgeBaseStatusConst::Draft;

            if ($knowledgebase->isDirty('article') || ($knowledgebase->article && !$knowledgebase->article_plain)) {
                $knowledgebase->article_plain = $knowledgebase->article ? Helper::stripHtml($knowledgebase->article) : null;
            }
        });

        static::updating(function ($knowledgebase) {
            if ($knowledgebase->isDirty('article') || ($knowledgebase->article && !$knowledgebase->article_plain)) {
                $knowledgebase->article_plain = $knowledgebase->article ? Helper::stripHtml($knowledgebase->article) : null;
            }
        });
    }

    public function status() : BelongsTo
    {
        return $this->belongsTo(Helper::model('knowledge_base_status'), 'status_id', 'id');
    }

    public function type() : BelongsTo
    {
        return $this->belongsTo(Helper::model('knowledge_base_type'), 'type_id', 'id');
    }

    public function importRules(): array
    {
        return [
            'name'    => ['required', 'string', 'max:255'],
            'type_id' => ['nullable', 'uuid'],
        ];
    }
}