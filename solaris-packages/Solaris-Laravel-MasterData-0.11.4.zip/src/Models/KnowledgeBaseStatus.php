<?php

namespace Solaris\MasterData\Models;

use Solaris\Core\Models\LookupStage;

class KnowledgeBaseStatus extends LookupStage
{
    protected $table = 'knowledge_base_statuses';
}