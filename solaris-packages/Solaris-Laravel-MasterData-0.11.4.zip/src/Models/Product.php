<?php

namespace Solaris\MasterData\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\Attachment;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FolderAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\ImportAccess;
use Solaris\Core\Attributes\LookupAccess;

#[FormAccess()]
#[LookupAccess(scopes: ["active"])]
#[DataTableAccess(scopes: ["active"])]
#[ExportAccess(exclude: ['product_picture_id'])]
#[ImportAccess(exclude: ['product_picture_id'])]
#[FolderAccess(exclude: ['product_picture_id'])]
class Product extends BaseModel
{
    protected $table                = 'products';
    protected ?string $displayValue = 'name';
    protected array   $searchColumns = ['notes_plain' => 'FullText'];

    protected static function booted()
    {
        parent::booted();

        $syncNotes = function ($product) {
            if ($product->isDirty('notes') || ($product->notes && !$product->notes_plain)) {
                $product->notes_plain = $product->notes ? Helper::stripHtml($product->notes) : null;
            }
        };

        static::creating($syncNotes);
        static::updating($syncNotes);
    }

    protected function casts(): array
    {
        return array_merge(parent::casts(), [
            'availability' => 'float',
            'price'        => 'float',
            'active'       => 'boolean'
        ]);
    }

    public function type() : BelongsTo
    {
        return $this->belongsTo(Helper::model('product_type'), 'type_id', 'id');
    }

    public function product_picture() : BelongsTo
    {
        return $this->belongsTo(Attachment::class, 'product_picture_id', 'id');
    }

    public function availabilities(): HasMany
    {
        return $this->hasMany(Helper::model('product_availability'), 'product_id', 'id');
    }

    public function features(): HasMany
    {
        return $this->hasMany(Helper::model('product_feature'), 'product_id', 'id');
    }

    public function price_histories(): HasMany
    {
        return $this->hasMany(Helper::model('product_price_history'), 'product_id', 'id');
    }

    public function scopeActive(Builder $query)
    {
        return $query->where("active", true);
    }

    public function importRules(): array
    {
        return [
            'name'                => ['required', 'string', 'max:255'],
            'type_id'             => ['required', 'uuid'],
            'unit_of_measure'     => ['required', 'string', 'max:255'],
            'price'               => ['nullable', 'numeric', 'min:0'],
            'sku_number'          => ['nullable', 'string', 'max:255'],
            'category'            => ['nullable', 'string', 'max:255'],
            'brand'               => ['nullable', 'string', 'max:255'],
            'active'              => ['nullable', 'boolean'],
            'product_description' => ['nullable', 'string', 'max:500'],
        ];
    }
}