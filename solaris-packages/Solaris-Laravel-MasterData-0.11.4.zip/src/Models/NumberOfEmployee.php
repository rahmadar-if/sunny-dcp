<?php

namespace Solaris\MasterData\Models;

use Solaris\Core\Models\LookupModel;

class NumberOfEmployee extends LookupModel
{
    protected $table = 'number_of_employees';
}
