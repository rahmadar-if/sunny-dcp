<?php

namespace Solaris\MasterData\Models;

use Solaris\Core\Models\LookupModel;

class ActivityCategory extends LookupModel
{
    protected $table = 'activity_categories';
}
