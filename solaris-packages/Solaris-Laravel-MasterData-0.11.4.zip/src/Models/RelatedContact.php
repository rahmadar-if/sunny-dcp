<?php

namespace Solaris\MasterData\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FolderAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\ImportAccess;

#[FormAccess()]
#[DataTableAccess()]
#[ExportAccess()]
#[ImportAccess()]
#[FolderAccess()]
class RelatedContact extends BaseModel
{
    protected $table = 'related_contacts';
    protected array $prepareColumns = ['id', 'contact_id', 'related_contact_id', 'category_id'];

    public function contact() : BelongsTo
    {
        return $this->belongsTo(Helper::model('contact'), 'contact_id', 'id');
    }

    public function related_contact() : BelongsTo
    {
        return $this->belongsTo(Helper::model('contact'), 'related_contact_id', 'id');
    }

    public function category() : BelongsTo
    {
        return $this->belongsTo(Helper::model('related_contact_category'), 'category_id', 'id');
    }

    public function importRules(): array
    {
        return [
            'related_contact_id' => ['required', 'uuid'],
            'category_id'        => ['required', 'uuid'],
            'contact_id'         => ['required', 'uuid'],
        ];
    }
}