<?php

namespace Solaris\MasterData\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FolderAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\ImportAccess;

#[FormAccess()]
#[DataTableAccess()]
#[ExportAccess()]
#[ImportAccess()]
#[FolderAccess()]
class Document extends BaseModel
{
    protected $table                  = 'documents';
    protected ?string $displayValue   = 'number';
    protected array   $prepareColumns = ['number', 'account_id', 'contact_id', 'date', 'type_id', 'status_id', 'notes'];
    protected array   $searchColumns  = ['notes_plain' => 'FullText'];

    protected static function booted()
    {
        parent::booted();

        $syncNotes = function ($document) {
            if ($document->isDirty('notes') || ($document->notes && !$document->notes_plain)) {
                $document->notes_plain = $document->notes ? Helper::stripHtml($document->notes) : null;
            }
        };

        static::creating($syncNotes);
        static::updating($syncNotes);
    }

    protected function casts(): array
    {
        return array_merge(parent::casts(),
        [
            'date' => "date:d M Y"
        ]);
    }

    public function account(): BelongsTo
    {
        return $this->belongsTo(Helper::model('account'), 'account_id', 'id');
    }

    public function contact(): BelongsTo
    {
        return $this->belongsTo(Helper::model('contact'), 'contact_id', 'id');
    }

    public function status(): BelongsTo
    {
        return $this->belongsTo(Helper::model('document_status'), 'status_id', 'id');
    }

    public function type(): BelongsTo
    {
        return $this->belongsTo(Helper::model('document_type'), 'type_id', 'id');
    }

    public function importRules(): array
    {
        return [
            'date'       => ['required', 'date_format:Y-m-d'],
            'type_id'    => ['required', 'uuid'],
            'status_id'  => ['required', 'uuid'],
            'account_id' => ['nullable', 'uuid'],
            'contact_id' => ['nullable', 'uuid'],
        ];
    }
}