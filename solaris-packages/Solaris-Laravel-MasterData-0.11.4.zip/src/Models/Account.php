<?php

namespace Solaris\MasterData\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\Attachment;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FolderAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\ImportAccess;
use Solaris\Core\Attributes\LookupAccess;

#[FormAccess()]
#[LookupAccess()]
#[DataTableAccess()]
#[FolderAccess(include: ['created_at', 'updated_at', 'created_by_id', 'updated_by_id'], exclude: ['profile_picture_id'])]
#[ExportAccess(exclude: ['profile_picture_id'])]
#[ImportAccess(exclude: ['profile_picture_id'])]
class Account extends BaseModel
{
    protected $table                  = 'accounts';
    protected ?string $displayValue   = 'name';
    protected array   $prepareColumns = ["id", "name", "industry_id", "type_id", "email"];
    protected array   $searchColumns  = ['notes_plain' => 'FullText'];

    protected static function booted()
    {
        parent::booted();

        $syncNotes = function ($account) {
            if ($account->isDirty('notes') || ($account->notes && !$account->notes_plain)) {
                $account->notes_plain = $account->notes ? Helper::stripHtml($account->notes) : null;
            }
        };

        static::creating($syncNotes);

        static::created(function ($account) {
            if(!is_null($account->primary_contact_id)) {
                $contact = Helper::model('contact')::find($account->primary_contact_id);
                if(is_null($contact->account_id)) {
                    $contact->account_id = $account->id;
                    $contact->save();
                }
            }
        });

        static::updating($syncNotes);
    }

    public function type() : BelongsTo
    {
        return $this->belongsTo(Helper::model('account_type'), 'type_id', 'id');
    }

    public function number_of_employee() : BelongsTo
    {
        return $this->belongsTo(Helper::model('number_of_employee'), 'number_of_employee_id', 'id');
    }

    public function business_entity() : BelongsTo
    {
        return $this->belongsTo(Helper::model('business_entity'), 'business_entity_id', 'id');
    }

    public function industry() : BelongsTo
    {
        return $this->belongsTo(Helper::model('industry'), 'industry_id', 'id');
    }

    public function primary_contact(): BelongsTo
    {
        return $this->belongsTo(Helper::model('contact'), 'primary_contact_id', 'id');
    }

    public function profile_picture() : BelongsTo
    {
        return $this->belongsTo(Attachment::class, 'profile_picture_id', 'id');
    }

    public function contacts() : HasMany
    {
        return $this->hasMany(Helper::model('contact'), 'account_id', 'id');
    }

    public function activities() : HasMany
    {
        return $this->hasMany(Helper::model('activity'), 'account_id', 'id');
    }

    public function addresses() : HasMany
    {
        return $this->hasMany(Helper::model('account_address'), 'account_id', 'id');
    }

    public function importRules(): array
    {
        return [
            'name'                  => ['required', 'string', 'max:255'],
            'type_id'               => ['required', 'uuid'],
            'primary_phone'         => ['required', 'string', 'max:50'],
            'email'                 => ['required', 'string', 'email', 'max:255'],
            'industry_id'           => ['required', 'uuid'],
            'primary_contact_id'    => ['nullable', 'uuid'],
            'category'              => ['nullable', 'string', 'max:255'],
            'also_known_as'         => ['nullable', 'string', 'max:255'],
            'website'               => ['nullable', 'string', 'max:255'],
            'business_entity_id'    => ['nullable', 'uuid'],
            'number_of_employee_id' => ['nullable', 'uuid'],
            'notes'                 => ['nullable', 'string'],
        ];
    }
}