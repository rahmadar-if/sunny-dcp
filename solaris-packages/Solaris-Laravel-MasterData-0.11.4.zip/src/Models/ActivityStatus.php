<?php

namespace Solaris\MasterData\Models;

use Solaris\Core\Models\LookupModel;

class ActivityStatus extends LookupModel
{
    protected $table = 'activity_statuses';
}
