<?php

namespace Solaris\MasterData\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FolderAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\ImportAccess;

#[FormAccess()]
#[DataTableAccess()]
#[ExportAccess()]
#[ImportAccess()]
#[FolderAccess()]
class ProductAvailability extends BaseModel
{
    protected $table                  = 'product_availabilities';
    protected ?string $displayValue   = 'warehouse';
    protected array   $prepareColumns = ['id','warehouse', 'address', 'qty', 'post_code', 'product_id', 'country_id', 'province_id', 'city_id'];

    protected static function booted(): void
    {
        parent::booted();

        static::updated(function ($product_availability) {
            if ($product_availability->wasChanged('qty')) {
                static::updateAvailability($product_availability);
            }
        });

        static::created(function ($product_availability) {
            static::updateAvailability($product_availability);
        });

        static::deleted(function ($product_availability) {
            static::updateAvailability($product_availability);
        });
    }

    public function product() : BelongsTo
    {
        return $this->belongsTo(Helper::model('product'), 'product_id', 'id');
    }

    public function country() : BelongsTo
    {
        return $this->belongsTo(Helper::model('country'), 'country_id', 'id');
    }

    public function province() : BelongsTo
    {
        return $this->belongsTo(Helper::model('province'), 'province_id', 'id');
    }

    public function city() : BelongsTo
    {
        return $this->belongsTo(Helper::model('city'), 'city_id', 'id');
    }

    protected static function updateAvailability($product_availability)
    {
        $product_id = $product_availability->product_id;

        $sumAvailability = static::where('product_id', $product_id)
            ->sum('qty');

        Helper::model('product')::where('id', $product_id)->update([
            'availability' => $sumAvailability ?? 0,
        ]);
    }

    public function importRules(): array
    {
        return [
            'warehouse'   => ['required', 'string'],
            'qty'         => ['required', 'integer'],
            'product_id'  => ['required', 'uuid'],
            'address'     => ['nullable', 'string'],
            'country_id'  => ['nullable', 'uuid'],
            'province_id' => ['nullable', 'uuid'],
            'city_id'     => ['nullable', 'uuid'],
            'post_code'   => ['nullable', 'string', 'max:255'],
        ];
    }
}