<?php

namespace Solaris\MasterData\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Models\City;
use Solaris\Core\Models\Country;
use Solaris\Core\Models\Province;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FolderAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\ImportAccess;

#[FormAccess()]
#[DataTableAccess()]
#[ExportAccess()]
#[ImportAccess()]
#[FolderAccess()]
class ContactAddress extends BaseModel
{
    protected $table                = 'contact_addresses';
    protected array $prepareColumns = ['id', 'address_type_id', 'address', 'postcode', 'city_id', 'province_id', 'country_id'];

    public function contact() : BelongsTo
    {
        return $this->belongsTo(Helper::model('contact'), 'contact_id', 'id');
    }
    
    public function address_type() : BelongsTo
    {
        return $this->belongsTo(Helper::model('address_type'), 'address_type_id', 'id');
    }

    public function country() : BelongsTo
    {
        return $this->belongsTo(Country::class, 'country_id', 'id');
    }

    public function province() : BelongsTo
    {
        return $this->belongsTo(Province::class, 'province_id', 'id');
    }

    public function city() : BelongsTo
    {
        return $this->belongsTo(City::class, 'city_id', 'id');
    }

    public function importRules(): array
    {
        return [
            'address_type_id' => ['required', 'uuid'],
            'address'         => ['required', 'string'],
            'contact_id'      => ['required', 'uuid'],
            'postcode'        => ['nullable', 'string', 'max:255'],
            'country_id'      => ['nullable', 'uuid'],
            'province_id'     => ['nullable', 'uuid'],
            'city_id'         => ['nullable', 'uuid'],
        ];
    }
}
