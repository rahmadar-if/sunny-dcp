<?php

namespace Solaris\MasterData\Models;

use Solaris\Core\Models\LookupModel;

class Education extends LookupModel
{
    protected $table = 'educations';
}
