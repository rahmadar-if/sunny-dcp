<?php

namespace Solaris\MasterData\Models;

use Solaris\Core\Models\LookupModel;

class AddressType extends LookupModel
{
    protected $table = 'address_types';
}
