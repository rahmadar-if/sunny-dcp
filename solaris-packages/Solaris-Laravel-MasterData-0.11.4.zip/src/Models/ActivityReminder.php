<?php

namespace Solaris\MasterData\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Models\BaseModel;

#[ExportAccess()]
class ActivityReminder extends BaseModel
{
    protected $table = 'activity_reminders';
    
    protected static function booted()
    {
        parent::booted();
        unset(static::$globalScopes[static::class]['object_permission']);
        unset(static::$globalScopes[static::class]['record_permission']);
    }

    protected function casts(): array
    {
        return array_merge(parent::casts(), [
            'remind_at' => 'datetime',
            'is_fail'   => 'boolean',
            'is_remind' => 'boolean',
        ]);
    }

    public function type(): BelongsTo
    {
        return $this->belongsTo(Helper::model('reminder_type'), 'type_id', 'id');
    }

    public function activity(): BelongsTo
    {
        return $this->belongsTo(Helper::model('activity'), 'activity_id', 'id');
    }

    public function to(): BelongsTo
    {
        return $this->belongsTo(Helper::model('user'), 'to_id', 'id');
    }
}