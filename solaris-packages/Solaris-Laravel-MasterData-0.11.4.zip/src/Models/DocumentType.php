<?php

namespace Solaris\MasterData\Models;

use Solaris\Core\Models\LookupModel;

class DocumentType extends LookupModel
{
    protected $table = 'document_types';
}
