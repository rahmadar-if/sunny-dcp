<?php

namespace Solaris\MasterData\Models;

use Solaris\Core\Models\LookupModel;

class ActivityPriority extends LookupModel
{
    protected $table = 'activity_priorities';
}
