<?php

namespace Solaris\MasterData\Models;

use Solaris\Core\Models\LookupModel;

class ProductType extends LookupModel
{
    protected $table = 'product_types';
}