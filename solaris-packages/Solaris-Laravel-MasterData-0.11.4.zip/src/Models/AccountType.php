<?php

namespace Solaris\MasterData\Models;

use Solaris\Core\Models\LookupModel;

class AccountType extends LookupModel
{
    protected $table = 'account_types';
}
