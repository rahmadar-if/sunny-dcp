<?php

namespace Solaris\MasterData\Models;

use Solaris\Core\Models\LookupStage;

class DocumentStatus extends LookupStage
{
    protected $table = 'document_statuses';
}
