<?php

namespace Solaris\MasterData\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FolderAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\ImportAccess;

#[FormAccess()]
#[DataTableAccess()]
#[ExportAccess()]
#[ImportAccess()]
#[FolderAccess()]
class ProductPriceHistory extends BaseModel
{
    protected $table                  = 'product_price_histories';
    protected ?string $displayValue   = 'price';
    protected array   $prepareColumns = ['id', 'price', 'from', 'end', 'product_id'];

    protected function casts(): array
    {
        return array_merge(parent::casts(),
        [
            'from'=> 'datetime',
            'end' => 'datetime',
        ]);
    }

    public function product() : BelongsTo
    {
        return $this->belongsTo(Helper::model('product'), 'product_id', 'id');
    }

    public function importRules(): array
    {
        return [
            'price'      => ['required', 'numeric', 'min:0'],
            'from'       => ['required', 'date'],
            'product_id' => ['required', 'uuid'],
            'end'        => ['nullable', 'date'],
        ];
    }
}