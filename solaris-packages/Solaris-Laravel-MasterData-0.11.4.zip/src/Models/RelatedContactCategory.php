<?php

namespace Solaris\MasterData\Models;

use Solaris\Core\Models\LookupModel;

class RelatedContactCategory extends LookupModel
{
    protected $table = 'related_contact_categories';
}