<?php

namespace Solaris\MasterData\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FolderAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\ImportAccess;

#[FormAccess()]
#[DataTableAccess()]
#[ExportAccess()]
#[ImportAccess()]
#[FolderAccess()]
class ProductFeature extends BaseModel
{
    protected $table                  = 'product_features';
    protected ?string $displayValue   = 'name';
    protected array   $prepareColumns = ['id', 'name', 'product_id', 'notes'];

    public function product() : BelongsTo
    {
        return $this->belongsTo(Helper::model('product'), 'product_id', 'id');
    }

    public function importRules(): array
    {
        return [
            'name'       => ['required', 'string'],
            'product_id' => ['required', 'uuid'],
            'notes'      => ['nullable', 'string'],
        ];
    }
}