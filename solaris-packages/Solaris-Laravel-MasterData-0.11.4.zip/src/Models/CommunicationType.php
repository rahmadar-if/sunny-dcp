<?php

namespace Solaris\MasterData\Models;

use Solaris\Core\Models\LookupModel;

class CommunicationType extends LookupModel
{
    protected $table = 'communication_types';
}
