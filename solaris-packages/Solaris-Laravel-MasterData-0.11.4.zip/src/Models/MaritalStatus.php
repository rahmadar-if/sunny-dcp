<?php

namespace Solaris\MasterData\Models;

use Solaris\Core\Models\LookupModel;

class MaritalStatus extends LookupModel
{
    protected $table = 'marital_statuses';
}
