<?php

namespace Solaris\MasterData\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FolderAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\ImportAccess;

#[FormAccess()]
#[DataTableAccess()]
#[ExportAccess()]
#[ImportAccess()]
#[FolderAccess()]
class ContactHobby extends BaseModel
{
    protected $table                 = 'contact_hobbies';
    protected array  $prepareColumns = ['id', 'hobby'];

    public function contact() : BelongsTo
    {
        return $this->belongsTo(Helper::model('contact'), 'contact_id', 'id');
    }

    public function importRules(): array
    {
        return [
            'hobby'      => ['required', 'string'],
            'contact_id' => ['required', 'uuid'],
        ];
    }
}