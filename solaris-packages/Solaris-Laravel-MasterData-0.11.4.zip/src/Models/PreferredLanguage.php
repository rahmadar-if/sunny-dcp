<?php

namespace Solaris\MasterData\Models;

use Solaris\Core\Models\LookupModel;

class PreferredLanguage extends LookupModel
{
    protected $table = 'preferred_languages';
}
