<?php

namespace Solaris\MasterData\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\Attachment;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FolderAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\ImportAccess;
use Solaris\Core\Attributes\LookupAccess;

#[FormAccess()]
#[LookupAccess(scopes: ["availableInRelatedContact"])]
#[DataTableAccess()]
#[FolderAccess(exclude: ['profile_picture_id'])]
#[ExportAccess(exclude: ['profile_picture_id'])]
#[ImportAccess(exclude: ['profile_picture_id'])]
class Contact extends BaseModel
{
    protected $table                  = 'contacts';
    protected ?string $displayValue   = 'name';
    protected array   $prepareColumns = ['id', 'name', 'account_id', 'updated_at', 'profile_picture_id', 'recipients_name'];
    protected array   $searchColumns  = ['notes_plain' => 'FullText'];

    protected static function booted()
    {
        parent::booted();

        $syncNotes = function ($contact) {
            if ($contact->isDirty('notes') || ($contact->notes && !$contact->notes_plain)) {
                $contact->notes_plain = $contact->notes ? Helper::stripHtml($contact->notes) : null;
            }
        };

        static::creating($syncNotes);
        static::updating($syncNotes);
    }

    public function account() : BelongsTo
    {
        return $this->belongsTo(Helper::model('account'), 'account_id', 'id');
    }

    public function gender() : BelongsTo
    {
        return $this->belongsTo(Helper::model('gender'), 'gender_id', 'id');
    }

    public function religion() : BelongsTo
    {
        return $this->belongsTo(Helper::model('religion'), 'religion_id', 'id');
    }

    public function marital_status() : BelongsTo
    {
        return $this->belongsTo(Helper::model('marital_status'), 'marital_status_id', 'id');
    }

    public function salutation() : BelongsTo
    {
        return $this->belongsTo(Helper::model('salutation'), 'salutation_id', 'id');
    }

    public function education() : BelongsTo
    {
        return $this->belongsTo(Helper::model('education'), 'education_id', 'id');
    }

    public function preferred_language() : BelongsTo
    {
        return $this->belongsTo(Helper::model('preferred_language'), 'preferred_language_id', 'id');
    }

    public function profile_picture() : BelongsTo
    {
        return $this->belongsTo(Attachment::class, 'profile_picture_id', 'id');
    }

    public function activities() : HasMany
    {
        return $this->hasMany(Helper::model('activity'), 'contact_id', 'id');
    }

    public function addresses() : HasMany
    {
        return $this->hasMany(Helper::model('contact_address'), 'contact_id', 'id');
    }

    public function communications() : HasMany
    {
        return $this->hasMany(Helper::model('contact_communication'), 'contact_id', 'id');
    }

    public function hobbies() : HasMany
    {
        return $this->hasMany(Helper::model('contact_hobby'), 'contact_id', 'id');
    }

    public function related_contacts() : HasMany
    {
        return $this->hasMany(Helper::model('related_contact'), 'contact_id', 'id');
    }

    public function scopeAvailableInRelatedContact(Builder $query, string $contactId)
    {
        return $query->whereNotIn("id", function($query) use($contactId) {
            $query->select("related_contact_id")
                ->from("related_contacts")
                ->where("contact_id", $contactId);
        });
    }

    public function importRules(): array
    {
        return [
            'name'                  => ['required', 'string', 'max:255'],
            'job_title'             => ['nullable', 'string', 'max:255'],
            'primary_phone'         => ['nullable', 'string', 'max:50'],
            'primary_mobile_phone'  => ['nullable', 'string', 'max:50'],
            'email'                 => ['nullable', 'string', 'email', 'max:255'],
            'account_id'            => ['nullable', 'uuid'],
            'salutation_id'         => ['nullable', 'uuid'],
            'also_known_as'         => ['nullable', 'string', 'max:255'],
            'birth_date'            => ['nullable', 'date_format:Y-m-d'],
            'gender_id'             => ['nullable', 'uuid'],
            'education_id'          => ['nullable', 'uuid'],
            'religion_id'           => ['nullable', 'uuid'],
            'marital_status_id'     => ['nullable', 'uuid'],
            'last_meeting_status'   => ['nullable', 'string'],
            'notes'                 => ['nullable', 'string'],
            'recipients_name'       => ['nullable', 'string', 'max:255'],
            'preferred_language_id' => ['nullable', 'uuid'],
        ];
    }
}