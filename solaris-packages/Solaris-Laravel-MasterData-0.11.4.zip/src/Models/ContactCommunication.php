<?php

namespace Solaris\MasterData\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FolderAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\ImportAccess;

#[FormAccess()]
#[DataTableAccess()]
#[ExportAccess()]
#[ImportAccess()]
#[FolderAccess()]
class ContactCommunication extends BaseModel
{
    protected $table                = 'contact_communications';
    protected array $prepareColumns = ['id', 'type_id', 'value'];

    public function contact() : BelongsTo
    {
        return $this->belongsTo(Helper::model('contact'), 'contact_id', 'id');
    }

    public function type() : BelongsTo
    {
        return $this->belongsTo(Helper::model('communication_type'), 'type_id', 'id');
    }

    public function importRules(): array
    {
        return [
            'type_id'    => ['required', 'uuid'],
            'value'      => ['required', 'string'],
            'contact_id' => ['required', 'uuid'],
        ];
    }
}
