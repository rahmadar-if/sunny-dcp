<?php

namespace Solaris\MasterData\Const;

class EducationConst
{
    public const SMA_SMK    = "c7c4025a-fe43-4148-b1c7-05faf0dc21a8";
    public const D3         = "9c11967d-84fe-4374-811d-409baa0222b9";
    public const D4         = "b51f21a9-d368-4d7a-a2dd-1a4f048999b6";
    public const S1         = "848bd086-6154-4c12-b85c-9a50eab656bf";
    public const S2         = "fce82a6a-417c-4e96-8261-034c089e3a11";
    public const S3         = "6984df38-f965-443b-98f1-4203239dd5b6";
    public const Others     = "516c21b1-7a09-4285-92f3-b9152ba20638";
}