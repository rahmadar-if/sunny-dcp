<?php

namespace Solaris\MasterData\Const;

class CommunicationTypeConst
{
    public const PhoneNumber    = "e9e76017-b9ca-42a4-ab83-5ce045f44eac";
    public const MobileNumber   = "9476f50b-1986-4d97-a066-3c3a8d188a97";
    public const Email          = "25afa96f-2695-436a-a56b-6ebfd25c7363";
    public const Website        = "e8f7de8c-646a-4604-8686-ccf8631f874d";
    public const Instagram      = "cd8d1ea4-1bc1-4c48-8266-70a73a6709e9";
    public const Facebook       = "d2cb2663-6972-4719-a7bb-55bf297c1dd9";
    public const Youtube        = "e446f478-ea22-44b5-aa9f-22e34aa5109e";
    public const LinkdedIn      = "495b3f39-91c4-4803-ae38-89bdef6e7afe";
    public const Twitter        = "7c5ba1ea-416b-47e7-a73c-9a7ff4b05439";
    public const Fax            = "75d6d26b-2daf-4fca-8cba-69de75150110";
}