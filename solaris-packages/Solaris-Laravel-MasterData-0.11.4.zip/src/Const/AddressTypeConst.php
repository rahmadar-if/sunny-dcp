<?php

namespace Solaris\MasterData\Const;

class AddressTypeConst
{
    public const Home       = "5020736a-7009-4e2e-9eeb-9dbd9a1eed64";
    public const Business   = "8e4b277d-92a5-4b81-bf15-1a8abd40beb5";
    public const Shipping   = "3c233b14-8c27-47e4-a8e8-8bb6f61b7ef9";
    public const Other      = "e1fb86d3-7ddb-4b8b-9286-f8b4ea6ceb72";
}