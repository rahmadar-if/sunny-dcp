<?php

namespace Solaris\MasterData\Const;

class ReminderTypeConst
{
    public const StartEvent     = "0197f3d2-45da-7dbd-a594-f0c80b0864a0";
    public const FifteenMinutes = "0197f3d2-45da-72da-8dfb-1a8c1e7b5a00";
    public const ThirtyMinutes  = "0197f3d2-45da-71c5-b91d-e06dcfea03ba";
    public const OneHour        = "0197f3d2-45da-7f2a-8821-cda847e1c3cf";
    public const OneDay         = "0197f3d2-45da-7109-88fc-e7eeeb7acbdb";
}