<?php

namespace Solaris\MasterData\Const;

class KnowledgeBaseStatusConst
{
    public const Draft      = "5b2926ee-5f81-47bf-9c2c-c780184c40b5";
    public const Published  = "bfa68874-84ec-4550-bf0f-db3b91451611";
}
