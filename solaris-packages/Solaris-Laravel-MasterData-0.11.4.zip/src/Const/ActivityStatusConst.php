<?php

namespace Solaris\MasterData\Const;

class ActivityStatusConst
{
    public const OnSchedule = "f6613bbe-06bb-4062-b632-4f05695bcfb8";
    public const InProgress = "d029cad7-f4b3-477c-9e42-40a8246d63fb";
    public const Finish     = "808f166e-038c-4b55-85bc-2f86916ba98d";
}