<?php

namespace Solaris\MasterData\Const;

class ActivityCategoryConst
{
    public const Call       = "2737b8b6-93bb-4b86-81cd-faff70498e86";
    public const Visit      = "199eb80f-a29d-409c-9e4f-848752b42b8b";
    public const Meeting    = "c68495c2-6a7f-48d3-ac18-0dc43def60fb";
    public const Email      = "c9c6cdc9-dcd9-4cb2-8d65-926c57ea0e3b";
    public const ToDo       = "483670cf-7b6a-4bb6-b67c-da971fc46673";
}