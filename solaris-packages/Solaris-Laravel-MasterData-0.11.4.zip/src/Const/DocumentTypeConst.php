<?php

namespace Solaris\MasterData\Const;

class DocumentTypeConst
{
    public const Regulation         = "d2d492eb-33d8-4b60-87ff-19f20a770707";
    public const Minutes            = "408d3ea9-11bf-43fc-aaba-65d66d64417e";
    public const IncomingDocument   = "332b4b24-4eaa-4849-a0ce-a1fcacfcd897";
}