<?php

namespace Solaris\MasterData\Const;

class DocumentStatusConst
{
    public const Draft      = "8ae78e08-5220-46bb-8330-414bdcefebd8";
    public const Inactive   = "ab6bd4ee-5cf8-448a-a4d8-95ab0b7abb46";
    public const Final      = "33b25094-03b2-49e9-b2d2-a12d3f2d5079";
}