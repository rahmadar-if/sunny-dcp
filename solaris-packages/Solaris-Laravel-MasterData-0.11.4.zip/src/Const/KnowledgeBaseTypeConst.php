<?php

namespace Solaris\MasterData\Const;

class KnowledgeBaseTypeConst
{
    public const FAQ            = "e2bfeba0-1d96-4a7d-90a7-1c1ea6484c7b";
    public const Guide          = "eb19d79b-f147-4fd9-83db-32a7f6c34cc6";
    public const Documentation  = "7709f69a-f143-4801-931e-b2154b3a48b2";
}
