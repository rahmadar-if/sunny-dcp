<?php

namespace Solaris\MasterData\Const;

class ProductTypeConst
{
    public const GoodsAndServices   = "f42904c9-1ba0-4113-afd6-272bc144c00e";
    public const Goods              = "66ad0e7b-806e-4d5c-88e1-3918ed55236e";
    public const Services           = "67181c7a-8c86-4a4b-8f09-a858d8d4bc15";
}