<?php

namespace Solaris\MasterData\Const;

class PreferredLanguageConst
{
    public const English            = "b83b5052-9f49-401c-bc72-d73358f7fdde";
    public const BahasaIndonesia    = "99e68f3a-3f1f-41b9-84c5-1155d0bb218f";
}