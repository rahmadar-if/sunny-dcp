<?php

namespace Solaris\MasterData\Const;

class RelatedContactCategoryConst
{
    public const Spouse = "720fd606-6e7a-47f2-8b4f-f6da47f86b3d";
    public const Child  = "054aeb01-709e-42a1-ab88-8f0269ee6a1f";
    public const Friend = "c5672c88-cf70-4218-8461-130227e57d1f";
}