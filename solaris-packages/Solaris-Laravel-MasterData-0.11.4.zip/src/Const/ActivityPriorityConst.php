<?php

namespace Solaris\MasterData\Const;

class ActivityPriorityConst
{
    public const High   = "64734d93-17e4-4653-a3e9-a6345fe46f74";
    public const Medium = "58760289-d6bc-4df6-a070-993b488d9024";
    public const Low    = "8b8607d8-967f-43fe-a780-92092bea7adb";
}