<x-core::card>
    <x-core::field id="activity-page-owner_id:owner_id" label="Owner" disabled>
        <x-core::input
            :value="$data->created_by?->name"/>
    </x-core::field>

    <x-core::field id="activity-page-account_id:account_id" label="Account">
        <x-core::lookup
            placeholder="Choose account"
            extend_columns="primary_contact"
            source="Account"
            :value="json_encode($data->account)"
            link_url="/master-data/account/{id}" />
    </x-core::field>

    <x-core::field id="activity-page-contact_id:contact_id" label="Contact" lazy>
        <x-core::lookup
            label="Contact"
            bindTo="contact_id"
            placeholder="Choose contact"
            extend_columns="account"
            source="Contact"
            :value="json_encode($data->contact)"
            link_url="/master-data/contact/{id}" />
    </x-core::field>
</x-core::card>
