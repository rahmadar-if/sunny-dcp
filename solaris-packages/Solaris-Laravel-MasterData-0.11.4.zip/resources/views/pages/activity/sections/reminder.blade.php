@php
    $remindMe = $data->reminders->isNotEmpty();
    $remindTo = $data->remind_users;
    $remindTypes = $data->reminders
        ->map(fn($reminder) => $reminder->type_id)
        ->toArray();

    $now = now();
    $startDate = $data->start_date;
    $reminderTypeOptions = SolarHelper::model('reminder_type')::toRadio(checked: $remindTypes);

    $reminderTypeOptions->each(function($opt) use ($startDate, $now) {
        $shouldDisable = !$startDate
            || $startDate <= $now
            || $startDate->copy()->subMinutes($opt->offset_minutes) <= $now;

        if ($shouldDisable) {
            $opt->disabled = true;
        }
    });
@endphp

<x-core::card>
    <x-core::checkbox id="remind_me" label="Remind me" wrap:class="mb-3" switch :checked="$remindMe" />

    <x-core::field id="activity-page-reminder_types:reminder_types" label="Remind type" :hidden="!$remindMe">
        <x-core::checkbox-group
            name="reminder_types"
            switch
            :options="$reminderTypeOptions" />
    </x-core::field>

    <x-core::field id="activity-page-remind_to:remind_to" label="Remind to" :hidden="!$remindMe">
        <x-core::lookup
            multiple
            placeholder="Pick users you want to notify"
            source="User"
            :value="json_encode($remindTo)"
        />
    </x-core::field>

</x-core::card>
