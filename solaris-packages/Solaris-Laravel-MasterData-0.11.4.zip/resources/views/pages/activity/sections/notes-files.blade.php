@php
	$id = "activity-page-tabs_notes_files";
@endphp

<x-core::tab-content :id="$id" :active="$active ?? false" class="p-0 border-0">
	<x-core::tab id="{{ $id }}-tabs" variant="tab-style-7" class="scaleX p-0 mb-4">
		<x-slot:nav>
			<x-core::tab-nav id="{{ $id }}-tabs_attachment" active>Attachment</x-core::tab-nav>
			<x-core::tab-nav id="{{ $id }}-tabs_notes">Notes</x-core::tab-nav>
		</x-slot>

		<x-slot:content>
			<x-core::tab-content id="{{ $id }}-tabs_attachment" active class="p-0 border-0">
				<x-core::attachment id="activity-page-attachment" relation="activities:{{ $data->id }}" />
			</x-core::tab-content>

			<x-core::tab-content id="{{ $id }}-tabs_notes" class="p-0 border-0">
				<x-core::notes
					id="activity-page-notes:notes"
					model="Activity"
					column="notes"
					:record_id="$data->id">{!! $data->notes !!}</x-core::notes>
			</x-core::tab-content>
		</x-slot>
	</x-core::tab>
</x-core::tab-content>
