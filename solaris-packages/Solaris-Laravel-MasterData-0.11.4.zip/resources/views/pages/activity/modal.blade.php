<x-core::modal-form
	id="activity-modal"
	title="Activity"
    model="Activity">

    <div class="row">
        <div class="col">
            <x-core::field id="activity-modal-subject:subject" label="Subject" required>
                <x-core::input
                    placeholder="Enter subject activity"
                />
            </x-core::field>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6">
            <x-core::field id="activity-modal-priority_id:priority_id" label="Priority" required>
                <x-core::lookup
                    placeholder="Choose Priority"
                    :options="SolarHelper::model('activity_priority')::toSelect()"/>
            </x-core::field>

            <x-core::field id="activity-modal-start_date:start_date" label="Start Date" required>
                <x-core::date-picker
                    mode="datetime"
                    placeholder="Select start date"
                />
            </x-core::field>

            <x-core::field id="activity-modal-end_date:end_date" label="End Date">
                <x-core::date-picker
                    mode="datetime"
                    placeholder="Select end date"
                />
            </x-core::field>
        </div>

        <div class="col-lg-6">
            <x-core::field id="activity-modal-category_id:category_id" label="Category" required>
                <x-core::lookup
                    placeholder="Choose category"
                    :options="SolarHelper::model('activity_category')::toSelect()"/>
            </x-core::field>

            <x-core::field id="activity-modal-account_id:account_id" label="Account">
                <x-core::lookup
                    placeholder="Choose an associated account"
                    pagination
                    source="Account"
                    link_url="/master-data/account/{id}" />
            </x-core::field>

            <x-core::field id="activity-modal-contact_id:contact_id" label="Contact" lazy>
                <x-core::lookup
                    placeholder="Choose a contact person"
                    pagination
                    source="Contact"
                    link_url="/master-data/contact/{id}" />
            </x-core::field>
        </div>
    </div>

    <hr>

    <div class="row">
        <div class="col-lg-6">
            <x-core::checkbox id="remind_me" label="Remind me" wrap:class="mb-3" switch />
            <x-core::field id="activity-modal-reminder_types:reminder_types" label="Remind type" hidden>
                <x-core::checkbox-group name="reminder_types" switch :options="SolarHelper::model('reminder_type')::toRadio()" />
            </x-core::field>
        </div>

        <div class="col-md-6">
            <x-core::field id="activity-modal-remind_to:remind_to" label="Remind to" hidden>
                <x-core::lookup
                    multiple
                    placeholder="Pick users you want to notify"
                    source="User"
                />
            </x-core::field>
        </div>
    </div>

</x-core::modal-form>
