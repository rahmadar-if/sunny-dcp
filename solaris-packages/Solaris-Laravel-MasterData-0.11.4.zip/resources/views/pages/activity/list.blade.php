<x-master-data::activity.list
    id="activity"
    title="Activity"
    class="table-hover"
    :breadcrumbs="$breadcrumbs"
    model="Activity"
    package="master-data"
    path="activity/list-index"
    new="@activity-modal"
    mode="card"
    import export folder lazy
    :search="false" 
    :card_wrapper="false"
    extend_columns="start_date,end_date,account_id,contact_id,priority_id,category_id">

    @push('styles')
    <style>
        table.solar-table.card tbody tr {
            width: 100%;
        }
    </style>
    @endpush

    <x-slot:table-column class="d-none">
        <x-core::table-column 
            data="subject" 
            searchable>
            Subject
        </x-core::table-column>
    </x-slot:table-column>

    {{-- <x-slot:placeholder>
        <template for="subject">
            <div class="d-flex flex-column gap-2 placeholder-glow">
                <div class="d-flex align-items-center gap-2">
                    <div class="d-flex gap-1 align-items-center flex-fill">
                        <span class="placeholder w-25"></span>
                        <span class="placeholder w-50"></span>
                        <span class="placeholder w-25"></span>
                    </div>
                </div>
                <span class="placeholder w-75"></span>
                <div class="d-flex justify-content-between">
                    <div class="d-flex flex-column justify-content-center gap-2 flex-fill">
                        <div class="d-flex align-items-center gap-2">
                            <div class="lh-1">
                                <span class="avatar avatar-rounded avatar-xs placeholder"></span>
                            </div>
                            <span class="placeholder w-50"></span>
                        </div>
                        <div class="d-flex align-items-center gap-2">
                            <div class="lh-1">
                                <span class="avatar avatar-rounded avatar-xs placeholder"></span>
                            </div>
                            <span class="placeholder w-50"></span>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end align-items-end flex-fill">
                        <span class="placeholder w-25"></span>
                    </div>
                </div>
            </div>
        </template>
    </x-slot> --}}

    @push('modal-content')
        @include('master-data::pages.activity.modal')
    @endpush

</x-master-data::activity.list>