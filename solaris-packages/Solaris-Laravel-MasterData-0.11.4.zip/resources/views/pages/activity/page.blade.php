<x-core::page.edit
	:id="$data->id"
	title="Activity"
	:breadcrumbs="$breadcrumbs"
	model="Activity"
	package="master-data"
	path="activity/page-index"
	profile-position="left">

	<x-slot:profile>
		@include('master-data::pages.activity.sections.profile-container', ["data" => $data])
		@include('master-data::pages.activity.sections.reminder', ["data" => $data])
	</x-slot>

	@php $tabId = "activity-page-tabs"; @endphp

	<x-core::tab id="{{ $tabId }}" class="p-0 mb-4">
		<x-slot:nav>
			<x-core::tab-nav id="{{ $tabId }}_info" active>Info</x-core::tab-nav>
			<x-core::tab-nav id="{{ $tabId }}_notes_files">Notes & Files</x-core::tab-nav>
		</x-slot>

		<x-slot:content>
			<x-core::tab-content id="{{ $tabId }}_info" active class="p-0 border-0">
				@include('master-data::pages.activity.sections.general-info', ['data' => $data, 'active' => true])
			</x-core::tab-content>

			@include('master-data::pages.activity.sections.notes-files', ['data' => $data, 'active' => false])
		</x-slot>
	</x-core::tab>

</x-core::page.edit>
