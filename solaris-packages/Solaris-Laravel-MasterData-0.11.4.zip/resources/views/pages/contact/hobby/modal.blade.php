<x-core::modal-form
	id="contact-hobby-modal"
	title="Hobby"
	size="md"
    model="ContactHobby">

    <x-core::field label="Hobby" id="contact-hobby-modal-hobby:hobby" required>
        <x-core::textarea
            id="contact-hobby-modal-hobby"
            placeholder="Tell us a bit about their hobbies or interests..."
            rows="4" />
    </x-core::field>

</x-core::modal-form>