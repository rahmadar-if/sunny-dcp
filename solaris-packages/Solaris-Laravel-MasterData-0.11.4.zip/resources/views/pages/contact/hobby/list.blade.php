<x-core::table
    id="contact-hobby_list" 
    class="table-hover"
    model="ContactHobby"
    new="@contact-hobby-modal"
    import export delete_all
    :card_wrapper="false"
    filter="contact_id = {{ $id }}">

    <x-slot:column>
        <x-core::table-action-column :view="false" />

        <x-core::table-column 
            data="hobby" 
            searchable 
            orderable
            expand>
            Hobby
        </x-core::table-column>
    </x-slot>

</x-core::table>

@push('modal-content')
    @include("master-data::pages.contact.hobby.modal")
@endpush