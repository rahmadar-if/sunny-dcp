<x-core::table
    id="contact-address_list" 
    class="table-hover"
    model="ContactAddress"
    new="@contact-address-modal"
    import export lazy delete_all
    :card_wrapper="false"
    filter="contact_id = {{ $id }}">

    <x-slot:column>
        <x-core::table-action-column :view="false" />

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="address_type.name" 
            searchable 
            orderable>
            Address Type
        </x-core::table-column>
        
        <x-core::table-column 
            data="address" 
            searchable 
            orderable
            expand>
            Address
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="city.name" 
            searchable 
            orderable>
            City
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="province.name" 
            searchable 
            orderable>
            Province
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="postcode" 
            searchable 
            orderable>
            Postal Code
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="country.name" 
            searchable 
            orderable>
            Country
        </x-core::table-column>
    </x-slot>

</x-core::table>

@push('modal-content')
    @include("master-data::pages.contact.address.modal")
@endpush