<x-core::modal-form
	id="contact-related-contact-modal"
	title="Related Contact"
	size="md"
    model="RelatedContact">

    <x-core::field label="Contact" id="contact-related-contact-modal-related_contact_id:related_contact_id" required lazy>
        <x-core::lookup
            placeholder="Choose contact"
            Source="Contact@availableInRelatedContact({{ $id }})"
            pagination />
    </x-core::field>

    <x-core::field label="Category" id="contact-related-contact-modal-category_id:category_id" required>
        <x-core::lookup
            placeholder="Choose category"
            :options="SolarHelper::model('related_contact_category')::toSelect()" />
    </x-core::field>

</x-core::modal-form>
