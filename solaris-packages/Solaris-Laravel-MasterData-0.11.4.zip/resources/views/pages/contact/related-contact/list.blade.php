<x-core::table
    id="contact-related-contact_list" 
    class="table-hover"
    model="RelatedContact"
    new="@contact-related-contact-modal"
    import export lazy delete_all
    :card_wrapper="false"
    filter="contact_id = {{ $id }}">

    <x-slot:column>
        <x-core::table-action-column :view="false"/>

        <x-core::table-column 
            data="related_contact.name" 
            lookup="profile_picture_id" 
            searchable 
            orderable>
            Contact
        </x-core::table-column>
        
        <x-core::table-column 
            data="category.name" 
            searchable 
            orderable>
            Category
        </x-core::table-column>
    </x-slot>

</x-core::table>

@push('modal-content')
    @include("master-data::pages.contact.related-contact.modal")
@endpush