@php
    $id = "contact-page-tabs_general_information";
@endphp

<x-core::tab-content :id="$id" :active="$active ?? false" class="p-0 border-0">

    <x-core::fieldset label="Identity" />
    <div class="row mb-3">
        <div class="col-md-6">
            <x-core::field label="Full Name" id="contact-page-name:name" required>
                <x-core::input placeholder="Who's this contact?"
                    :value="$data->name" />
            </x-core::field>

            <x-core::field label="Salutation" id="contact-page-salutation_id:salutation_id" required>
                <x-core::lookup
                    placeholder="Choose a proper salutation"
                    :options="SolarHelper::model('salutation')::toSelect()"
                    :value="json_encode($data->salutation)" />
            </x-core::field>

            <x-core::field label="Recipient's name" id="contact-page-recipients_name:recipients_name">
                <x-core::input placeholder="Type the recipient name here..."
                    :value="$data->recipients_name" />
            </x-core::field>
        </div>
        <div class="col-md-6">
            <x-core::field label="Also known as" id="contact-page-also_known_as:also_known_as">
                <x-core::input placeholder="Any alternate names or alias"
                    :value="$data->also_known_as" />
            </x-core::field>

            <x-core::field label="Gender" id="contact-page-gender_id:gender_id" required>
                <x-core::lookup
                    placeholder="Choose a gender"
                    :options="SolarHelper::model('gender')::toSelect()"
                    :value="json_encode($data->gender)" />
            </x-core::field>
        </div>
    </div>

    <x-core::fieldset label="Personal" />
    <div class="row mb-3">
        <div class="col-md-6">
            <x-core::field label="Birth date" id="contact-page-birth_date:birth_date">
                <x-core::date-picker placeholder="Pick birth date"
                    :value="$data->birth_date" />
            </x-core::field>

            <x-core::field label="Marital status" id="contact-page-marital_status_id:marital_status_id">
                <x-core::lookup
                    placeholder="Current marital status"
                    :options="SolarHelper::model('marital_status')::toSelect()"
                    :value="json_encode($data->marital_status_id)" />
            </x-core::field>

            <x-core::field label="Education" id="contact-page-education_id:education_id">
                <x-core::lookup
                    placeholder="Highest education level"
                    :options="SolarHelper::model('education')::toSelect()"
                    :value="json_encode($data->education_id)" />
            </x-core::field>
        </div>
        <div class="col-md-6">
            <x-core::field label="Age" id="contact-page-age:age" disabled>
                <x-core::input :value="0" />
            </x-core::field>

            <x-core::field label="Religion" id="contact-page-religion_id:religion_id">
                <x-core::lookup
                    placeholder="Choose religion or belief"
                    :options="SolarHelper::model('religion')::toSelect()"
                    :value="json_encode($data->religion)" />
            </x-core::field>

            <x-core::field label="Preferred language" id="contact-page-preferred_language_id:preferred_language_id">
                <x-core::lookup
                    placeholder="Choose preferred language"
                    :options="SolarHelper::model('preferred_language')::toSelect()"
                    :value="json_encode($data->preferred_language_id)" />
            </x-core::field>
        </div>
    </div>

    <x-core::fieldset label="Professional" />
    <div class="row mb-3">
        <div class="col-md-6">
            <x-core::field label="Job title" id="contact-page-job_title:job_title" required>
                <x-core::input placeholder="Position or role within the organization"
                    :value="$data->job_title" />
            </x-core::field>
        </div>
        <div class="col-md-6">
            <x-core::field label="Account" id="contact-page-account_id:account_id">
                <x-core::lookup
                    placeholder="Link to the related account"
                    Source="Account"
                    :value="json_encode($data->account)"
                    pagination
                    link_url="/master-data/account/{id}"
                    extend_columns="email, industry_id, type_id" />
            </x-core::field>
        </div>
    </div>

    <x-core::fieldset label="Contact" />
    <div class="row">
        <div class="col-md-6">
            <x-core::field id="contact-page-primary_phone:primary_phone" label="Primary phone" required>
                <x-core::input placeholder="Their must-answer number"
                    :value="$data->primary_phone" phone />
            </x-core::field>

            <x-core::field id="contact-page-primary_mobile_phone:primary_mobile_phone" label="Mobile phone" required>
                <x-core::input placeholder="The number they always keep nearby"
                    :value="$data->primary_mobile_phone" phone />
            </x-core::field>
        </div>
        <div class="col-md-6">
            <x-core::field label="Email address" id="contact-page-email:email" required>
                <x-core::input placeholder="Provide an email address"
                    :value="$data->email" />
            </x-core::field>
        </div>
    </div>

</x-core::tab-content>
