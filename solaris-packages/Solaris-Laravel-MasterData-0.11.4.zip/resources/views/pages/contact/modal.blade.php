<x-core::modal-form
    id="contact-modal"
    model="Contact"
    title="Contact">

    <div class="row mb-3">
        <div class="d-flex justify-content-center">
            <x-core::profile-picture id="contact-profile_picture"/>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6">
            <x-core::field id="contact-modal-name:name" label="Name" required>
                <x-core::input
                    placeholder="Who's this contact?"/>
            </x-core::field>

            <x-core::field id="contact-modal-primary_phone:primary_phone" label="Primary phone" required>
                <x-core::input placeholder="Their must-answer number" phone/>
            </x-core::field>

            <x-core::field id="contact-modal-primary_mobile_phone:primary_mobile_phone" label="Mobile phone" required>
                <x-core::input
                    placeholder="The number they always keep nearby" phone/>
            </x-core::field>
        </div>
        <div class="col-lg-6">
            <x-core::field id="contact-modal-email:email" label="Email" required>
                <x-core::input placeholder="The inbox we should use"/>
            </x-core::field>

            <x-core::field id="contact-modal-job_title:job_title" label="Job Title" required>
                <x-core::input
                    placeholder="Position or role within the organization"/>
            </x-core::field>

            <x-core::field label="Account" id="contact-modal-account_id:account_id">
                <x-core::lookup
                    placeholder="Link to the related account"
                    Source="Account"
                    link_url="/master-data/account/{id}" />
            </x-core::field>
        </div>
    </div>

</x-core::modal-form>
