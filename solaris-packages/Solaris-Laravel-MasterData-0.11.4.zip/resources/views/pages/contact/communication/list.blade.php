<x-core::table
    id="contact-communication_list" 
    class="table-hover"
    model="ContactCommunication"
    new="@contact-communication-modal"
    import export delete_all
    :card_wrapper="false"
    filter="contact_id = {{ $id }}">

    <x-slot:column>
        <x-core::table-action-column :view="false"/>

        <x-core::table-column 
            data="type.name" 
            searchable 
            orderable>
            Type
        </x-core::table-column>
        
        <x-core::table-column 
            data="value" 
            searchable 
            orderable>
            Value
        </x-core::table-column>
    </x-slot>

</x-core::table>

@push('modal-content')
    @include("master-data::pages.contact.communication.modal")
@endpush