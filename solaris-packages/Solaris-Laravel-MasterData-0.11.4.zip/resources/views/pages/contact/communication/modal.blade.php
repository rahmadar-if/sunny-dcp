<x-core::modal-form
	id="contact-communication-modal"
	title="Contact Communication"
	size="md"
    model="ContactCommunication">

    <x-core::field id="contact-communication-modal-type_id:type_id" label="Type" required>
        <x-core::lookup
            placeholder="Choose communication type"
            :options="SolarHelper::model('communication_type')::toSelect()" />
    </x-core::field>

    <x-core::field label="Please complete the field" id="contact-communication-modal-value:value" required>
        <x-core::input
            placeholder="Please complete the field" />
    </x-core::field>

</x-core::modal-form>
