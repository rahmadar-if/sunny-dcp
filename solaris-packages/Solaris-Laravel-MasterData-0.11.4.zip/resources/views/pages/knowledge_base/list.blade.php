<x-core::page.list
    id="knowledge-base"
    title="Knowledge Base"
    class="table-hover"
    :breadcrumbs="$breadcrumbs"
    model="KnowledgeBase"
    package="master-data"
    path="knowledge-base/list-index"
    new="@knowledge-base-modal"
    import export folder lazy delete_all>

    <x-slot:table-column>
        <x-core::table-action-column :view="false" />

        <x-core::table-column 
            data="name" 
            searchable 
            orderable>
            Article
        </x-core::table-column>
        
        <x-core::table-column 
            data="type.name" 
            searchable 
            orderable>
            Type
        </x-core::table-column>

        <x-core::table-column 
            data="updated_at" 
            searchable 
            orderable
            type="datetime">
            Last Update
        </x-core::table-column>
        
        <x-core::table-column 
            data="created_by.name" 
            searchable 
            orderable>
            Author
        </x-core::table-column>
        
        <x-core::table-column 
            data="status.name" 
            searchable 
            orderable>
            Status
        </x-core::table-column>
    </x-slot>

    @push('modal-content')
        @include("master-data::pages.knowledge_base.modal")
    @endpush

</x-core::page.list>