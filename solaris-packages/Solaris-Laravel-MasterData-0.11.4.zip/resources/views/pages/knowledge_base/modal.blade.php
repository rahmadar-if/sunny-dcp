<x-core::modal-form id="knowledge-base-modal" title="Knowledge Base" size="md" model="KnowledgeBase">
    <div class="row">
        <div class="col-lg">
            <x-core::field id="knowledge-base-modal-name:name" label="Title" required>
                <x-core::input
                    placeholder="Knowledge base title"/>
            </x-core::field>

            <x-core::field id="knowledge-base-modal-type_id:type_id" label="Type" required>
                <x-core::lookup
                    placeholder="Choose Type"
                    :options="SolarHelper::model('knowledge_base_type')::toSelect()" />
            </x-core::field>
        </div>
    </div>
</x-core::modal-form>
