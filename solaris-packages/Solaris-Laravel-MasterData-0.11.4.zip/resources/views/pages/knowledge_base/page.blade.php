<x-core::page.edit
    :id="$data->id"
    title="Knowledge Base"
    :breadcrumbs="$breadcrumbs"
    model="KnowledgeBase"
    package="master-data"
    path="knowledge-base/page-index">

    <x-slot:header>
        <div class="row mb-3">
            <div class="col">
                <x-core::stage-buttons id="knowledge-base-page-status_id:status_id" :stages="SolarHelper::model('knowledge_base_status')::toStage(true)" :value="$data->status_id" />
            </div>
        </div>
    </x-slot>

    <div class="row">
        <div class="col-6">
            <x-core::field label="Title" id="knowledge-base-page-name:name" required>
                <x-core::input
                    placeholder="Type the account name here..."
                    :value="$data->name" />
            </x-core::field>
        </div>

        <div class="col-6">
            <x-core::field label="Type" id="knowledge-base-page-type_id:type_id" required>
                <x-core::lookup
                    placeholder="Choose Type"
                    :options="SolarHelper::model('knowledge_base_type')::toSelect()"
                    :value="json_encode($data->type)"/>
            </x-core::field>
        </div>
    </div>

    <div class="row">
        <div class="col-6">
            <x-core::field label="Owner" id="knowledge-base-page-created_by_id:created_by_id" disabled>
                <x-core::input
                    placeholder="Owner name..."
                    :value="$data->created_by->name" />
            </x-core::field>
        </div>

        <div class="col-md-6">
            <x-core::field label="Last Update" id="knowledge-base-page-updated_at:updated_at" disabled>
                <x-core::date-picker mode="datetime" :value="$data->updated_at?->toJSON()" />
            </x-core::field>
        </div>
    </div>

    <x-slot:footer>
        <x-core::document-editor 
            id="knowledge-base-page-article:article"
            model="KnowledgeBase"
            column="article"
            :record_id="$data->id">{!! $data->article !!}</x-core::document-editor>
    </x-slot:footer>

</x-core::page.edit>
