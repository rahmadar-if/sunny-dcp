<x-core::table
    id="product-availability_list"
    class="table-hover"
    model="ProductAvailability"
    import export lazy delete_all
    new="@product-availability-modal"
    filter="product_id = {{ $id }}">

    <x-slot:column>
        <x-core::table-action-column 
            :view="false" 
            edit 
            delete />

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="warehouse" 
            searchable 
            orderable>
            Warehouse
        </x-core::table-column>
        
        <x-core::table-column 
            data="qty" 
            searchable 
            orderable>
            Qty
        </x-core::table-column>
        
        <x-core::table-column 
            data="address" 
            searchable 
            orderable>
            Address
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            name="country_id" 
            data="country.name" 
            searchable 
            orderable>
            Country
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            name="province_id" 
            data="province.name" 
            searchable 
            orderable>
            Province
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            name="city_id" 
            data="city.name" 
            searchable 
            orderable>
            City
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="post_code" 
            searchable 
            orderable>
            Post Code
        </x-core::table-column>
    </x-slot>

</x-core::table>

@push('modal-content')
    @include("master-data::pages.product.availability.modal")
@endpush