<x-core::modal-form
	id="product-availability-modal"
	title="Product Availability"
	size="lg"
    model="ProductAvailability">

    <div class="row">
        <div class="col-lg-6">
            <x-core::field label="Warehouse" id="product-availability-modal-warehouse:warehouse" required>
                <x-core::input
                    placeholder="Enter Warehouse"
                />
            </x-core::field>
        </div>

        <div class="col-lg-6">
            <x-core::field label="QTY" id="product-availability-modal-qty:qty" required>
                <x-core::input
                    placeholder="Enter qty"
                    decimal number
                />
            </x-core::field>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <x-core::field label="Address" id="product-availability-modal-address:address">
                <x-core::textarea
                    placeholder="Enter address"
                />
            </x-core::field>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6">
            <x-core::field id="product-availability-modal-country_id:country_id" label="Country">
                <x-core::lookup
                    placeholder="Choose country"
                    Source="Country"
                    pagination
                />
            </x-core::field>

            <x-core::field id="product-availability-modal-province_id:province_id" label="Province" lazy>
                <x-core::lookup
                    placeholder="Choose province"
                    Source="Province"
                    pagination
                />
            </x-core::field>
        </div>

        <div class="col-lg-6">
            <x-core::field id="product-availability-modal-city_id:city_id" label="City" lazy>
                <x-core::lookup
                    placeholder="Choose city"
                    Source="City"
                    pagination
                />
            </x-core::field>

            <x-core::field id="product-availability-modal-post_code:post_code" label="Post code">
                <x-core::input
                    placeholder="Enter post code"
                />
            </x-core::field>
        </div>

    </div>

</x-core::modal-form>
