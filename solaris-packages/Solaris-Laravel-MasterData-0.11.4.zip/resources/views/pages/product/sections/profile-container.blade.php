<div class="card custom-card overflow-hidden border">
    <div class="card-body">
        <div class="text-center mb-3">
            <x-core::profile-picture
                id="product_picture"
                param_name="product_picture"
                :source="$data->product_picture_id"
                :preview_width="$data->product_picture?->image_width"
                :preview_height="$data->product_picture?->image_height"
                :upload_to="route('master-data.product.update.avatar', ['id' => $data->id])"
                size="lg"/>

            <h5 class="fw-medium mb-1 mt-4" id="name_display">{{ $data->name }}</h5>
            <span class="d-block fw-medium text-muted mb-2" id="type_display">{{ $data->type['name'] ?? "-" }} </span>

            <p class="fs-12 mb-0 text-muted">
                <span class="d-block mb-1">
                    <i class="ri-award-line me-1 align-middle"></i>
                    <span id="category_brand_display">{{ $data->category ?? "-"}} / {{ $data->brand ?? "-"  }}</span>
                </span>
                <span class="d-block">
                    <i class="ri-barcode-box-line me-1 align-middle"></i>
                    <span id="sku_number_display">{{ $data->sku_number ?? "-"}}</span>
                </span>
            </p>
        </div>
    </div>
</div>