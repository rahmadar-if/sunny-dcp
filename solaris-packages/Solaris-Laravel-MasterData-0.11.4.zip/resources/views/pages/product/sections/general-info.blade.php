@php
    $id = "product-page-tabs_general_information";
@endphp

<x-core::tab-content :id="$id" :active="$active ?? false" class="p-0 border-0">
    <div class="row">
        <div class="col-md-6">
            <x-core::field id="product-page-name:name" label="Product Name" required>
                <x-core::input
                    placeholder="Enter product name"
                    :value="$data->name"
                />
            </x-core::field>

            <x-core::field id="product-page-type:type_id" label="Type" required>
                <x-core::lookup
                    placeholder="Choose product type"
                    :options="SolarHelper::model('product_type')::toSelect()"
                    :value="json_encode($data->type)"
                />
            </x-core::field>

            <x-core::field id="product-page-price:price" label="Price">
                <x-core::input
                    number decimal prefix="Rp"
                    placeholder="Enter price"
                    :value="$data->price"
                />
            </x-core::field>

            <x-core::field  id="product-page-unit_of_measure:unit_of_measure" label="Unit of measure">
                <x-core::input
                    placeholder="e.g., kg, pcs, box"
                    :value="$data->unit_of_measure"
                />
            </x-core::field>

            <x-core::field  id="product-page-availability:availability" label="Availability" disabled>
                <x-core::input
                    :value="$data->availability"
                    decimal
                    number
                    placeholder="0"
                />
            </x-core::field>
        </div>

        <div class="col-md-6">
            <x-core::field  id="product-page-category:category" label="Category">
                <x-core::input
                    placeholder="Enter product category"
                    :value="$data->category"
                />
            </x-core::field>

            <x-core::field  id="product-page-brand:brand" label="Brand">
                <x-core::input
                    placeholder="Enter brand name"
                    :value="$data->brand"
                />
            </x-core::field>

            <x-core::field  id="product-page-sku_number:sku_number" label="SKU Number">
                <x-core::input
                    placeholder="Enter SKU (Stock Keeping Unit) number"
                    :value="$data->sku_number"
                />
            </x-core::field>

            <x-core::field  id="product-page-active:active" label="Active">
                <x-core::checkbox
                    :checked="$data->active"
                />
            </x-core::field>
        </div>
    </div>

    <div class="row">
        <div class="col">
            <x-core::field label="Product Description" id="contact-communication-page-product_description:product_description">
                <x-core::textarea
                    placeholder="Tell us a about product..."
                    rows="4"
                    :value="$data->product_description"
                />
            </x-core::field>
        </div>
    </div>
</x-core::tab-content>
