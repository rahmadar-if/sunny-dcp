@php
    $id = "product-page-tabs_detail_info";
@endphp

<x-core::tab-content id="{{ $id }}" :active="$active ?? false" class="p-0 border-0">
    <x-core::tab id="{{ $id }}-tabs" class="scaleX p-0 mb-4" variant="tab-style-7">
        <x-slot:nav>
            <x-core::tab-nav id="{{ $id }}-tabs_feature" active>Feature</x-core::tab-nav>
            <x-core::tab-nav id="{{ $id }}-tabs_availability">Availability</x-core::tab-nav>
        </x-slot>

        <x-slot:content>
            <x-core::tab-content id="product-page-tabs_detail_info-tabs_feature" active class="p-0 border-0">
                @include('master-data::pages.product.feature.list', ['id' => $data->id])
            </x-core::tab-content>

            <x-core::tab-content id="product-page-tabs_detail_info-tabs_availability" class="p-0 border-0">
                @include('master-data::pages.product.availability.list', ['id' => $data->id])
            </x-core::tab-content>
        </x-slot>
    </x-core::tab>
</x-core::tab-content>