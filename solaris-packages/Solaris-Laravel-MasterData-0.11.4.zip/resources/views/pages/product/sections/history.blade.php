@php
    $id = "product-page-tabs_history";
@endphp

<x-core::tab-content id="{{ $id }}" :active="$active ?? false" class="p-0 border-0">
    <x-core::tab id="{{ $id }}-tabs" class="scaleX p-0 mb-4" variant="tab-style-7">
        <x-slot:nav>
            <x-core::tab-nav id="{{ $id }}-tabs_price" active>Price history</x-core::tab-nav>
        </x-slot>

        <x-slot:content>
            <x-core::tab-content id="{{ $id }}-tabs_price" active class="p-0 border-0">
                @include('master-data::pages.product.price-history.list', ['id' => $data->id])
            </x-core::tab-content>
        </x-slot>
    </x-core::tab>
</x-core::tab-content>