<x-core::table
    id="product-price-history_list"
    class="table-hover"
    model="ProductPriceHistory"
    :new="false"
    :import="false"
    export lazy
    filter="product_id = {{ $id }}">

    <x-slot:column>
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="price" 
            searchable 
            orderable>
            Price
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="from" 
            searchable 
            orderable
            type="datetime">
            From
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="end" 
            searchable 
            orderable
            type="datetime">
            End
        </x-core::table-column>
    </x-slot>

</x-core::table>