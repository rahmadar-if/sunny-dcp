<x-core::modal-form
	id="product-feature-modal"
	title="Product Feature"
	size="md"
    model="ProductFeature">

    <x-core::field label="Name" id="product-feature-modal-name:name" required>
        <x-core::input
            id="product-feature-modal-name"
            placeholder="Enter feature name"
        />
    </x-core::field>

    <x-core::field label="Notes" id="product-feature-modal-notes:notes">
        <x-core::textarea
            id="product-feature-modal-notes"
            placeholder="Enter notes"
            rows="4"
        />
    </x-core::field>
    
</x-core::modal-form>
