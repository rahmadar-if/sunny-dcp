<x-core::table
    id="product-feature_list"
    class="table-hover"
    model="ProductFeature"
    import export lazy delete_all
    new="@product-feature-modal"
    filter="product_id = {{ $id }}">

    <x-slot:column>
        <x-core::table-action-column 
            :view="false" 
            edit 
            delete />

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="name" 
            searchable 
            orderable>
            Name
        </x-core::table-column>
        
        <x-core::table-column 
            data="notes" 
            searchable 
            orderable
            expand>
            Notes
        </x-core::table-column>
    </x-slot>

</x-core::table>

@push('modal-content')
    @include("master-data::pages.product.feature.modal")
@endpush