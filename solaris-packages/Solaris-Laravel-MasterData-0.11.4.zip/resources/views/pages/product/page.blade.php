<x-core::page.edit
    :id="$data->id"
    title="Product"
    :breadcrumbs="$breadcrumbs"
    model="Product"
    package="master-data"
    path="product/page-index">

    @php
        $tabId = "product-page-tabs";
    @endphp

    <x-core::tab id="{{ $tabId }}" class="p-0 mb-4">
        <x-slot:nav>
            <x-core::tab-nav id="{{ $tabId }}_general_information" active>General Information</x-core::tab-nav>
            <x-core::tab-nav id="{{ $tabId }}_detail_info">Detail Information</x-core::tab-nav>
            <x-core::tab-nav id="{{ $tabId }}_history">History</x-core::tab-nav>
            <x-core::tab-nav id="{{ $tabId }}_attachment">Attachment</x-core::tab-nav>
            <x-core::tab-nav id="{{ $tabId }}_notes">Notes</x-core::tab-nav>
        </x-slot>

        <x-slot:content>
            @include('master-data::pages.product.sections.general-info', ["data" => $data, "active" => true])
            @include('master-data::pages.product.sections.detail-info', ["data" => $data])
            @include('master-data::pages.product.sections.history', ["data" => $data])

            <x-core::tab-content id="{{ $tabId }}_attachment" class="p-0 border-0">
                <x-core::attachment id="product-attachment-table" relation="products:{{ $data->id }}"/>
            </x-core::tab-content>
            
            <x-core::tab-content id="{{ $tabId }}_notes" class="p-0 border-0">
                <x-core::notes 
                    id="product-notes:notes"
                    model="Product"
                    column="notes"
                    :record_id="$data->id">{!! $data->notes !!}</x-core::notes>
            </x-core::tab-content>
        </x-slot>
    </x-core::tab>

    <x-slot:profile>
        @include('master-data::pages.product.sections.profile-container', ["data" => $data])
    </x-slot>

</x-core::page.edit>