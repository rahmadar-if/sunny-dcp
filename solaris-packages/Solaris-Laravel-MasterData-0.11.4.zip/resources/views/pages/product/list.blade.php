<x-core::page.list
    id="product"
    title="Product"
    class="table-hover"
    :breadcrumbs="$breadcrumbs"
    model="Product"
    package="master-data"
    path="product/list-index"
    new="@product-modal"
    import export lazy folder delete_all
    extend_columns="active,product_picture_id,unit_of_measure">

    <x-slot:table-column>
        <x-core::table-action-column 
            edit 
            delete 
            :view="false"/>

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="name" 
            searchable 
            orderable>
            Name
        </x-core::table-column>
        
        <x-core::table-column  
            data="active"  
            orderable>
            Active
        </x-core::table-column>

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="type.name" 
            searchable 
            orderable>
            Type
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="price" 
            searchable 
            orderable>
            Price
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="availability" 
            searchable 
            orderable>
            Available stocks
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="category" 
            searchable 
            orderable>
            Category
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="brand" 
            searchable 
            orderable>
            Brand
        </x-core::table-column>
    </x-slot>

    @push('modal-content')
        @include("master-data::pages.product.modal")
    @endpush

</x-core::page.list>