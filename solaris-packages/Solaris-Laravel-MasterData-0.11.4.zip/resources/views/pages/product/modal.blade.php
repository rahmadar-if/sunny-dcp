<x-core::modal-form
    id="product-modal"
    title="Product"
    model="product">

    <div class="row mb-3">
        <div class="d-flex justify-content-center">
            <x-core::profile-picture 
                id="product_picture"
                param_name="product_picture"
                thumbnail="180"/>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6">
            <x-core::field id="product-modal-name:name" label="Name" required>
                <x-core::input
                    placeholder="Enter product name"
                />
            </x-core::field>

            <x-core::field id="product-modal-type:type_id" label="Type" required>
                <x-core::lookup
                    placeholder="Choose product type"
                    :options="SolarHelper::model('product_type')::toSelect()"
                />
            </x-core::field>

            <x-core::field id="product-modal-price:price" label="Price" required>
                <x-core::input
                    placeholder="Enter product price"
                    prefix="Rp"
                    number decimal
                />
            </x-core::field>

            <x-core::field id="product-modal-unit_of_measure:unit_of_measure" label="Unit of measure" required>
                <x-core::input
                    placeholder="e.g., kg, pcs, box"
                />
            </x-core::field>

        </div>
        <div class="col-lg-6">
            <x-core::field id="product-modal-category:category" label="Category">
                <x-core::input
                    placeholder="Enter product category"
                />
            </x-core::field>

            <x-core::field id="product-modal-brand:brand" label="Brand">
                <x-core::input
                    placeholder="Enter brand name"
                />
            </x-core::field>

            <x-core::field id="product-modal-sku_number:sku_number" label="SKU Number">
                <x-core::input
                    placeholder="Enter SKU (Stock Keeping Unit) number"
                />
            </x-core::field>

            <div class="d-flex align-items-center">
                <x-core::field id="product-modal-active:active">
                    <x-core::checkbox
                        label="Active"
                    />
                </x-core::field>
            </div>
        </div>
    </div>
</x-core::modal-form>
