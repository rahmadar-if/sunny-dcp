<x-core::page.list
    id="account"
    title="Account"
    class="table-hover"
    :breadcrumbs="$breadcrumbs"
    model="Account"
    package="master-data"
    path="account/list-index"
    new="@account-modal"
    import export folder lazy delete_all
    extend_columns="primary_phone,email,profile_picture_id">

    <x-slot:table-column>
        <x-core::table-action-column :view="false"/>

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="name" 
            searchable 
            orderable>
            Name
        </x-core::table-column>

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="primary_contact.name" 
            lookup="primary_mobile_phone,email,profile_picture_id" 
            searchable 
            orderable>
            Primary contact
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="type.name" 
            searchable 
            orderable>
            Type
        </x-core::table-column>

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="industry.name" 
            searchable 
            orderable>
            Industry
        </x-core::table-column>

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="category" 
            searchable 
            orderable>
            Category
        </x-core::table-column>
    </x-slot>

    @push('modal-content')
        @include("master-data::pages.account.modal")
    @endpush

</x-core::page.list>