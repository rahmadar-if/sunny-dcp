<x-core::table 
    id="account-contact_list" 
    class="table-hover" 
    model="Contact"
    new="@contact-modal" 
    export lazy delete_all
    extend_columns="profile_picture_id"
    :card_wrapper="false"
    filter="account_id = {{ $id }}">

    <x-slot:column>
        <x-core::table-action-column :view="false" />

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="name" 
            searchable 
            orderable>
            Name
        </x-core::table-column>

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="primary_mobile_phone" 
            searchable 
            orderable>
            Mobile phone
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="email" 
            searchable 
            orderable>
            Email
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="job_title" 
            searchable 
            orderable>
            Role
        </x-core::table-column>
    </x-slot>

</x-core::table>

@push('modal-content')
    @include("master-data::pages.contact.modal")
@endpush