<x-core::modal-form
    id="account-modal"
    model="Account"
    title="Account">

    <div class="row mb-4">
        <div class="d-flex justify-content-center">
            <x-core::profile-picture id="account-modal-profile_picture"/>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6">
            <x-core::field id="account-modal-name:name" label="Name" required>
                <x-core::input
                    placeholder="Type the account name here..."/>
            </x-core::field>

            <x-core::field id="account-modal-type_id:type_id" label="Type" required>
                <x-core::lookup
                    placeholder="Choose the account type"
                    :options="SolarHelper::model('account_type')::toSelect()"/>
            </x-core::field>

            <x-core::field id="account-modal-industry_id:industry_id" label="Industry" required>
                <x-core::lookup
                    placeholder="Choose industry or sector"
                    :options="SolarHelper::model('industry')::toSelect()"/>
            </x-core::field>

            <x-core::field id="account-modal-category:category" label="Category">
                <x-core::input
                    placeholder="Type the category here"/>
            </x-core::field>
        </div>

        <div class="col-lg-6">
            <x-core::field id="account-modal-primary_phone:primary_phone" label="Primary phone" required>
                <x-core::input
                    phone
                    placeholder="Enter the primary phone number"/>
            </x-core::field>

            <x-core::field id="account-modal-email:email" label="Email" required>
                <x-core::input
                    placeholder="Provide an email address"/>
            </x-core::field>

            <x-core::field id="account-modal-primary_contact_id:primary_contact_id" label="Primary contact" lazy>
                <x-core::lookup
                    source="Contact"
                    placeholder="Search and select a primary contact"
                    link_url="/master-data/contact/{id}" />
            </x-core::field>
        </div>
    </div>

</x-core::modal-form>
