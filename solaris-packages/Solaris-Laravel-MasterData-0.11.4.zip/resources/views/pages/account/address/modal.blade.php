<x-core::modal-form
	id="account-address-modal"
	title="Account Address"
    model="AccountAddress">

    <div class="row">
        <div class="col-lg-6">
            <x-core::field id="account-modal-address_type_id:address_type_id" label="Type" required>
                <x-core::lookup
                    placeholder="Choose address type"
                    :options="SolarHelper::model('address_type')::toSelect()"
                />
            </x-core::field>
        </div>
    </div>

    <x-core::field id="account-modal-address:address" label="Address" required>
        <x-core::textarea
            placeholder="Enter detailed address"
            rows="3"/>
    </x-core::field>

    <div class="row">
        <div class="col-lg-6">
            <x-core::field id="account-address-modal-country_id:country_id" label="Country">
                <x-core::lookup
                    pagination
                    placeholder="Choose country"
                    source="Country"
                />
            </x-core::field>

            <x-core::field id="account-address-modal-province_id:province_id" label="Province" lazy>
                <x-core::lookup
                    pagination
                    placeholder="Choose province"
                    source="Province"
                />
            </x-core::field>
        </div>
        <div class="col-lg-6">
            <x-core::field id="account-address-modal-city_id:city_id" label="City" lazy>
                <x-core::lookup
                    pagination
                    placeholder="Choose city"
                    source="City"
                />
            </x-core::field>

            <x-core::field id="account-address-modal-postcode:postcode" label="Postcode">
                <x-core::input
                    label="Postcode"
                    placeholder="Enter postcode"
                />
            </x-core::field>
        </div>
    </div>

</x-core::modal-form>
