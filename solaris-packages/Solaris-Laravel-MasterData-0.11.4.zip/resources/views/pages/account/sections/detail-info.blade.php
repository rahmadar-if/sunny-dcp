@php
    $id = "account-page-tabs_detail_information";
@endphp

<x-core::tab-content :id="$id" :active="$active ?? false" class="p-0 border-0">
    <x-core::tab id="{{ $id }}-tabs" variant="tab-style-7" class="scaleX p-0 mb-4">
        <x-slot:nav>
            <x-core::tab-nav id="{{ $id }}-tabs_contact" active>Contact</x-core::tab-nav>
            <x-core::tab-nav id="{{ $id }}-tabs_address">Address</x-core::tab-nav>
        </x-slot>

        <x-slot:content>
            <x-core::tab-content id="{{ $id }}-tabs_contact" active class="p-0 border-0">
                @include("master-data::pages.account.contact.list", ["id" => $data->id])
            </x-core::tab-content>

            <x-core::tab-content id="{{ $id }}-tabs_address" class="p-0 border-0">
                @include("master-data::pages.account.address.list", ["id" => $data->id])
            </x-core::tab-content>
        </x-slot>
    </x-core::tab>
</x-core::tab-content>