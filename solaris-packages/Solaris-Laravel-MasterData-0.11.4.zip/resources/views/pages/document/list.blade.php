<x-core::page.list
    id="document"
    title="Document"
    class="table-hover"
    :breadcrumbs="$breadcrumbs"
    model="Document"
    package="master-data"
    path="document/list-index"
    new="@document-modal"
    import export folder lazy delete_all>

    <x-slot:table-column>
        <x-core::table-action-column 
            edit 
            delete 
            :view="false"/>
        
        <x-core::table-column 
            class_cell="text-nowrap" 
            data="number" 
            searchable 
            orderable>
            Number
        </x-core::table-column>
        
        <x-core::table-column 
            class_cell="text-nowrap" 
            data="type.name" 
            searchable 
            orderable>
            Type
        </x-core::table-column>
        
        <x-core::table-column 
            class_cell="text-nowrap" 
            data="status.name" 
            searchable 
            orderable>
            Status
        </x-core::table-column>
        
        <x-core::table-column 
            class_cell="text-nowrap" 
            data="account.name" 
            lookup="profile_picture" 
            searchable 
            orderable>
            Account
        </x-core::table-column>
        
        <x-core::table-column 
            class_cell="text-nowrap" 
            data="contact.name" 
            lookup="profile_picture" 
            searchable 
            orderable>
            Contact
        </x-core::table-column>
    </x-slot>

    @push('modal-content')
        @include('master-data::pages.document.modal')
    @endpush

</x-core::page.list>