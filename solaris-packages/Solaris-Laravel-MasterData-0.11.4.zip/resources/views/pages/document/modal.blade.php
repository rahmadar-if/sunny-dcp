<x-core::modal-form id="document-modal" title="Document" model="Document">
    <div class="row">
        <div class="col-lg-6">
            <x-core::field label="Date" id="document-page-date:date" required>
                <x-core::date-picker
                    placeholder="Choose when this document was registered"/>
            </x-core::field>

            <x-core::field id="document-modal-type_id:type_id" label="Type" required>
                <x-core::lookup
                    :options="SolarHelper::model('document_type')::toSelect()"
                    placeholder="Choose document type" />
            </x-core::field>

            <x-core::field id="document-modal-status_id:status_id" label="Status" required>
                <x-core::lookup
                    :options="SolarHelper::model('document_status')::toSelect()"
                    placeholder="Choose document status" />
            </x-core::field>
        </div>

        <div class="col-lg-6">
            <x-core::field id="document-modal-account_id:account_id" label="Account">
                <x-core::lookup
                    pagination
                    placeholder="Choose the customer account"
                    extend_columns="primary_contact"
                    source="Account"
                    link_url="/master-data/account/{id}" />
            </x-core::field>

            <x-core::field id="document-modal-contact_id:contact_id" label="Contact" lazy>
                <x-core::lookup
                    pagination
                    placeholder="Choose a contact person"
                    source="Contact"
                    link_url="/master-data/contact/{id}" />
            </x-core::field>
        </div>
    </div>
</x-core::modal-form>
