<x-core::page.edit
    :id="$data->id"
    title="Document"
    :breadcrumbs="$breadcrumbs"
    model="Document"
    package="master-data"
    path="document/page-index">

    <x-slot:header>
        <div class="row mb-3">
            <div class="col">
                <x-core::stage-buttons id="document-page-status_id:status_id" :stages="SolarHelper::model('document_status')::toStage(true)" :value="$data->status_id" />
            </div>
        </div>
    </x-slot>

    <div class="row">
        <div class="col-4">
            <x-core::field label="Number" id="document-page-number:number" disabled>
                <x-core::input
                    placeholder="Type a unique contract reference"
                    :value="$data->number"/>
            </x-core::field>
        </div>

        <div class="col-4">
            <x-core::field label="Date" id="document-page-date:date" required>
                <x-core::date-picker
                    placeholder="Choose when this document was registered"
                    :value="$data->date"/>
            </x-core::field>
        </div>

        <div class="col-4">
            <x-core::field id="document-page-type_id:type_id" label="Type" required>
                <x-core::lookup
                    :options="SolarHelper::model('document_type')::toSelect()"
                    placeholder="Choose document type"
                    :value="json_encode($data->type)" />
            </x-core::field>
        </div>
    </div>

    <div class="row">
        <div class="col-4">
            <x-core::field label="Account" id="document-page-account_id:account_id">
                <x-core::lookup
                    pagination
                    source="Account"
                    placeholder="Choose the customer account"
                    :value="json_encode($data->account)"
                    link_url="/master-data/account/{id}" />
            </x-core::field>
        </div>

        <div class="col-4">
            <x-core::field label="Contact" id="document-page-contact_id:contact_id" lazy>
                <x-core::lookup
                    pagination
                    source="Contact"
                    placeholder="Choose the contact person"
                    :value="json_encode($data->contact)"
                    link_url="/master-data/contact/{id}" />
            </x-core::field>
        </div>
    </div>

    <x-slot:footer>
        <x-core::document-editor 
            id="document-page-notes:notes"
            model="Document"
            column="notes"
            :record_id="$data->id"
            >{!! $data->notes !!}</x-core::document-editor>
    </x-slot:footer>

</x-core::page.edit>
