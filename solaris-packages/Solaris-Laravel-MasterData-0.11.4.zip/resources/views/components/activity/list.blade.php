@props([
    "id",
    "title"          => "Activity",
    "breadcrumbs"    => [],
    "package"        => null,
    "path"           => null,
    "calendarSource" => "master-data/activity/calendar"
])

<x-core::page.base 
    :title="$title"
    :breadcrumbs="$breadcrumbs"
    :package="$package" 
    :path="$path">

    @if (isset($buttons))
    <x-slot:buttons>
        {{ $buttons }}
    </x-slot>
    @endif

    @if (isset($header))
        {{ $header }}
    @endif

    <div class="row">

        <div class="col-xxl-3 col-lg-4 col-12">
            <x-core::table {{ $attributes->merge(['id' => $id.'_list']) }}>
                @if (isset($tableHeader))
                    <x-slot:header>
                        {{ $tableHeader }}
                    </x-slot>
                @endif

                @if (isset($tablePreLeftAction))
                    <x-slot:pre-left-action>
                        {{ $tablePreLeftAction }}
                    </x-slot>
                @endif

                @if (isset($tableLeftAction))
                    <x-slot:left-action>
                        {{ $tableLeftAction }}
                    </x-slot>
                @endif

                @if (isset($tablePreRightAction))
                    <x-slot:pre-right-action>
                        {{ $tablePreRightAction }}
                    </x-slot>
                @endif

                @if (isset($tableRightAction))
                    <x-slot:right-action>
                        {{ $tableRightAction }}
                    </x-slot>
                @endif

                @if (isset($tableColumn))
                    <x-slot:column :attributes="$tableColumn->attributes">
                        {{ $tableColumn }}
                    </x-slot>
                @endif
            </x-core::table>
        </div>

        <div class="col-xxl-9 col-lg-8 col-12">
            <x-core::calendar id="{{ $id }}_calendar" source="{{ $calendarSource }}" lazy />
        </div>

    </div>

    {{ $slot }}

</x-core::page.base>