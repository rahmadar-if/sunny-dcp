const DocumentStatus = {
    Draft   : "8ae78e08-5220-46bb-8330-414bdcefebd8",
    Inactive: "ab6bd4ee-5cf8-448a-a4d8-95ab0b7abb46",
    Final   : "33b25094-03b2-49e9-b2d2-a12d3f2d5079"
}

const ReminderType = {
    StartEvent: {
        id: "0197f3d2-45da-7dbd-a594-f0c80b0864a0",
        offset_minutes: 0
    },
    FifteenMinutes: {
        id: "0197f3d2-45da-72da-8dfb-1a8c1e7b5a00",
        offset_minutes: 15
    },
    ThirtyMinutes: {
        id: "0197f3d2-45da-71c5-b91d-e06dcfea03ba",
        offset_minutes: 30
    },
    OneHour: {
        id: "0197f3d2-45da-7f2a-8821-cda847e1c3cf",
        offset_minutes: 60
    },
    OneDay: {
        id: "0197f3d2-45da-7109-88fc-e7eeeb7acbdb",
        offset_minutes: 60 * 24
    },
}

export { 
    DocumentStatus,
    ReminderType,
}