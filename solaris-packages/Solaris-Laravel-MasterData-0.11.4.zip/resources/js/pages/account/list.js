import Filter from "@core-js/solaris/filter/filter";
import SolarListPage from "@core-js/solaris/solar/solar-list-page";
import ProfilePicture from "@core-js/solaris/profile-picture";

export default class AccountListPage extends SolarListPage {
    init() {
        this._isProfilePicture = false
        this.initModal()

        this.columnRender("name", this.nameColumnRender.bind(this))
        this.columnRender("primary_contact_id", this.primaryContactColumnRender.bind(this))
        this.columnRender("type_id", this.typeColumnRender.bind(this))
    }

    initModal() {
        if(!this.hasModalForm()) {
            return
        }

        /** @type {ProfilePicture} */
        const profilePicture = this.get("account-modal-profile_picture")
        this.form.registerProfilePicture(profilePicture, (res) => `${BASE_URL}/master-data/account/avatar/${res.data.id}`)

        const primaryContact = this.form.get("primary_contact_id")
        primaryContact.init({
            param: (param) => {
                const filter = new Filter()
                filter.andNull("account_id")
        
                param.filter = filter.get()
                return param
            }
        })
    }

    openEditPage(id) {
        this.helper.loadingPage(true)
        window.location = `${BASE_URL}/master-data/account/edit/${id}`
    }

    async edit(row, data) {
        this.openEditPage(data.id)
    }

    rowDoubleClick(row, data) {
        this.openEditPage(data.id)
    }

    nameColumnRender(data, rowData) {
        const initialName   = this.helper.getInitialName(data)

        return `<div class="d-flex align-items-center gap-2">
            <div class="lh-1">
                <span class="avatar avatar-rounded avatar-md ${!rowData.profile_picture_id ? "bg-secondary" : ""}">
                    ${rowData.profile_picture_id ? `<img src="${BASE_URL}/core/images/thumbnail/${rowData.profile_picture_id}" alt="">` : initialName}
                </span>
            </div>
            <div class="d-flex flex-column gap-1">
                <a class="fw-medium text-decoration-underline" href="${BASE_URL}/master-data/account/edit/${rowData.id}">${data}</a>
                <span class="text-muted fs-12"><i class="ri-phone-line me-2"></i>${rowData.primary_phone ?? '-'}</span>
                <span class="text-muted fs-12"><i class="ri-mail-line me-2"></i>${rowData.email ?? '-'}</span>
            </div>
        </div>`
    }

    primaryContactColumnRender(data, rowData) {
        if(!data) {
            return data
        }
        
        const initialName = this.helper.getInitialName(data)
        return `<div class="d-flex align-items-center gap-2">
            <div class="lh-1">
                <span class="avatar avatar-rounded avatar-md ${!rowData.primary_contact.profile_picture_id ? "bg-secondary" : ""}">
                    ${rowData.primary_contact.profile_picture_id ? `<img src="${BASE_URL}/core/images/thumbnail/${rowData.primary_contact.profile_picture_id}" alt="">` : initialName}
                </span>
            </div>
            <div class="d-flex flex-column gap-1">
                <a class="fw-medium text-decoration-underline" href="${BASE_URL}/master-data/contact/${rowData.primary_contact.id}">${data}</a>
                <span class="text-muted fs-12"><i class="ri-smartphone-line me-2"></i>${rowData.primary_contact.primary_mobile_phone ?? '-'}</span>
                <span class="text-muted fs-12"><i class="ri-mail-line me-2"></i>${rowData.primary_contact.email ?? '-'}</span>
            </div>
        </div>`
    }

    typeColumnRender(data, rowData) {
        const typeBadge     = {
            Customer   : 'bg-success',
            Partner    : 'bg-primary',
            Competitor : 'bg-danger'
        }

        return data ? `<span class="badge ${typeBadge[data]}">${data}</span>` : ""
    }
}