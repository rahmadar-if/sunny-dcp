import SolarListDetail from "@core-js/solaris/solar/solar-list-detail";
import ContactModal from "../contact/modal";

export default class AccountContactDetail extends SolarListDetail {
    init() {
        this.contactModal = this.hasModalForm() ? new ContactModal(this.modalForm) : null
        this.columnRender("name", this.nameColumnRender.bind(this))
    }

    nameColumnRender(data, rowData) {
        const initialName = this.helper.getInitialName(data)
        return `<div class="d-flex align-items-center gap-2">
            <div class="lh-1">
                <span class="avatar avatar-rounded avatar-sm ${!rowData.profile_picture_id ? "bg-secondary" : ""}">
                    ${rowData.profile_picture_id ? `<img src="${BASE_URL}/core/images/thumbnail/${rowData.profile_picture_id}" alt="">` : initialName}
                </span>
            </div>
            <div class="d-flex flex-wrap">
                <a class="text-decoration-underline" href="${BASE_URL}/master-data/contact/edit/${rowData.id}">${data}</a>
            </div>
        </div>`
    }

    openEditPage(id) {
        this.helper.loadingPage(true)
        window.location = `${BASE_URL}/master-data/contact/edit/${id}`
    }

    async edit(row, data) {
        this.openEditPage(data.id)
    }

    rowDoubleClick(row, data) {
        this.openEditPage(data.id)
    }
}