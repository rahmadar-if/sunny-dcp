import Filter from "@core-js/solaris/filter/filter";
import SolarListDetail from "@core-js/solaris/solar/solar-list-detail";

export default class AccountAddressDetail extends SolarListDetail {
    init() {
        this.initModal()

        this.columnRender("address_type_id", this.addressTypeColumnRender.bind(this))
    }

    initModal() {
        if(!this.hasModalForm()) {
            return
        }

        const country  = this.form.get("country_id")
        const province = this.form.get("province_id")
        const city     = this.form.get("city_id")
        const postcode = this.form.get("postcode")

        province?.init({
            param: (param) => {
                const filter = new Filter()
                const countryId = country.get()?.id
                if(countryId) {
                    filter.and("country_id", countryId)
                    param.filter = filter.get()
                }
        
                return param
            }
        }, "AccountAddressDetail")

        city?.init({
            param: (param) => {
                const filter = new Filter()
                const countryId = country.get()?.id
                if(countryId) {
                    filter.and("country_id", countryId)
                }
        
                const provinceId = province.get()?.id
                if(provinceId) {
                    filter.and("province_id", provinceId)
                }
        
                if(filter.get().length > 0) {
                    param.filter = filter.get()
                }
        
                return param
            }
        }, "AccountAddressDetail")

        country?.on("change", (val) => {
            if(!val) {
                province.set(null)
            }
        }, "AccountAddressDetail")

        province?.on("change", (val) => {
            if(!val) {
                city.set(null)
                return
            }
            
            if(val && !country.get()) {
                country.set(val.country)
            }

            if(val && city.get() && city.get().province.id != val.id) {
                city.set(null)
            }
        }, "AccountAddressDetail")

        city?.on("change", (val) => {
            if(!val) {
                postcode.set(null)
                return
            }
            
            if(val && !province.get()) {
                province.set(val.province)
            }
        }, "AccountAddressDetail")
    }

    addressTypeColumnRender(data, rowData) {
        const color = {
            Home    : "primary",
            Business: "success",
            Shipping: "info"
        }

        return `<span class="badge bg-${color[data] ?? "secondary"}">${data}</span>`
    }
}