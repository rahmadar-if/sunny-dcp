import ActivityDetail from "../activity/detail";

export default class AccountActivityDetail extends ActivityDetail {
    init() {
        super.init()
    }
}