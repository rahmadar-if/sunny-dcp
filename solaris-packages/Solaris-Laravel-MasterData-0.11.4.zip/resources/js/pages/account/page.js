import Filter from "@core-js/solaris/filter/filter";
import SolarEditPage from "@core-js/solaris/solar/solar-edit-page";
import AccountContactDetail from "./contact-detail";
import AccountAddressDetail from "./address-detail";
import AccountActivityDetail from "./activity-detail";

export default class AccountPage extends SolarEditPage {
    init() {
        this.initProfileContainer()
        this.initForm()

        this.registerDetail("account-contact", AccountContactDetail, "account_id")
        this.registerDetail("account-address", AccountAddressDetail, "account_id")
        this.registerDetail("account-activity", AccountActivityDetail, "account_id")
    }

    initProfileContainer() {
        this.nameDisplay            = document.getElementById('name_display')
        this.emailDisplay           = document.getElementById('email_display')
        this.primaryPhoneDisplay    = document.getElementById('primary_phone_display')
        this.websiteDisplay         = document.getElementById('website_display')
        this.alsoKnownAsDisplay     = document.getElementById('also_known_as_display')
        this.typeBadge              = document.querySelector('.badge-type')
        this.industryBadge          = document.querySelector('.badge-industry')
        this.totalContactDisplay    = document.getElementById('total_contact_display')
        this.totalActivityDisplay   = document.getElementById('total_activity_display')
        this.totalAddressDisplay    = document.getElementById('total_address_display')
        this.primaryContactSection  = document.getElementById('primary_contact_section')
        this.primaryContactLink     = document.getElementById('primary_contact_link')
        this.primaryContactAvatar   = document.getElementById('primary_contact_avatar')
        this.primaryContactInitial  = document.getElementById('primary_contact_initial')
        this.primaryContactName     = document.getElementById('primary_contact_name')
        this.primaryContactJobTitle = document.getElementById('primary_contact_job_title')
    }

    initForm() {
        this.form.exclude(["account-page-created_by_id"])

        const name           = this.form.get("name")
        const email          = this.form.get("email")
        const primaryPhone   = this.form.get("primary_phone")
        const alsoKnownAs    = this.form.get("also_known_as")
        const type           = this.form.get("type_id")
        const industry       = this.form.get("industry_id")
        const website        = this.form.get("website")
        const primaryContact = this.form.get("primary_contact_id")

        name?.on('input', (value) => {
            if(this.nameDisplay) {
                this.nameDisplay.innerText = value
            }
            this.breadcrumbName.innerText = value
        }, "AccountPage")

        email?.on('input', (value) => {
            if(this.emailDisplay) {
                this.emailDisplay.innerText = value || '-'
                if(value) {
                    this.emailDisplay.setAttribute('href', `mailto:${value}`)
                    this.emailDisplay.classList.add('text-decoration-underline')
                } else {
                    this.emailDisplay.removeAttribute('href')
                    this.emailDisplay.classList.remove('text-decoration-underline')
                }
            }
        }, "AccountPage")

        primaryPhone?.on('input', (value) => {
            if(this.primaryPhoneDisplay) {
                this.primaryPhoneDisplay.innerText = value || '-'
                if(value) {
                    const normalized = this.helper.normalizePhoneNumber(value)
                    this.primaryPhoneDisplay.setAttribute('href', `https://wa.me/${normalized}`)
                    this.primaryPhoneDisplay.classList.add('text-decoration-underline')
                } else {
                    this.primaryPhoneDisplay.removeAttribute('href')
                    this.primaryPhoneDisplay.classList.remove('text-decoration-underline')
                }
            }
        }, "AccountPage")

        alsoKnownAs?.on('input', (value) => {
            if(this.alsoKnownAsDisplay) {
                this.alsoKnownAsDisplay.textContent = value
            }
        }, "AccountPage")

        type?.on('change', (value) => {
            if(this.typeBadge) {
                this.typeBadge.textContent = value?.name ?? ''
                this.typeBadge.classList.toggle('d-none', !value)
            }
        }, "AccountPage")

        industry?.on('change', (value) => {
            if(this.industryBadge) {
                this.industryBadge.textContent = value?.name ?? ''
                this.industryBadge.classList.toggle('d-none', !value)
            }
        }, "AccountPage")

        website?.on('input', (value) => {
            if(this.websiteDisplay) {
                this.websiteDisplay.textContent = value ?? '-'
                if(value) {
                    this.websiteDisplay.setAttribute('href', value)
                    this.websiteDisplay.classList.add('text-decoration-underline')
                } else {
                    this.websiteDisplay.removeAttribute('href')
                    this.websiteDisplay.classList.remove('text-decoration-underline')
                }
            }
        }, "AccountPage")

        primaryContact?.init({
            param: (param) => {
                const filter = new Filter()
                filter.andNull("account_id")
                    .or("account_id", this.id)
                param.filter = filter.get()

                return param
            }
        })

        primaryContact?.on('change', (value) => {
            this.updatePrimaryContact(value)
        }, "AccountPage")
    }

    initDetail() {
        this.accountContact
            ?.on("saved", () => this.refresh(false))
            .on("deleted", () => this.refresh(false))

        this.accountAddress
            ?.on("saved", () => this.refresh(false))
            .on("deleted", () => this.refresh(false))

        this.accountActivity
            ?.on("saved", () => this.refresh(false))
            .on("deleted", () => this.refresh(false))
    }

    async onRefreshed(data) {
        const owner = this.form.get("account-page-created_by_id")
        owner?.set(data.created_by.name)

        if(this.breadcrumbName) {
            this.breadcrumbName.textContent = data.name
        }

        this.loadProfileContainer(data)
    }

    loadProfileContainer(data) {
        if(this.nameDisplay) {
            this.nameDisplay.innerText = data.name ?? "-"
        }

        if(this.emailDisplay) {
            const email = data.email
            this.emailDisplay.innerText = email ?? '-'
            if(email) {
                this.emailDisplay.setAttribute('href', `mailto:${email}`)
                this.emailDisplay.classList.add('text-decoration-underline')
            } else {
                this.emailDisplay.removeAttribute('href')
                this.emailDisplay.classList.remove('text-decoration-underline')
            }
        }

        if(this.primaryPhoneDisplay) {
            const phone = data.primary_phone
            this.primaryPhoneDisplay.innerText = phone ?? '-'
            if(phone) {
                const normalized = this.helper.normalizePhoneNumber(phone)
                this.primaryPhoneDisplay.setAttribute('href', `https://wa.me/${normalized}`)
                this.primaryPhoneDisplay.classList.add('text-decoration-underline')
            } else {
                this.primaryPhoneDisplay.removeAttribute('href')
                this.primaryPhoneDisplay.classList.remove('text-decoration-underline')
            }
        }

        if(this.websiteDisplay) {
            const website = data.website
            this.websiteDisplay.textContent = website ?? '-'
            if(website) {
                this.websiteDisplay.setAttribute('href', website)
                this.websiteDisplay.classList.add('text-decoration-underline')
            } else {
                this.websiteDisplay.removeAttribute('href')
                this.websiteDisplay.classList.remove('text-decoration-underline')
            }
        }

        if(this.typeBadge) {
            this.typeBadge.textContent = data.type?.name ?? ''
            this.typeBadge.classList.toggle('d-none', !data.type)
        }

        if(this.industryBadge) {
            this.industryBadge.textContent = data.industry?.name ?? ''
            this.industryBadge.classList.toggle('d-none', !data.industry)
        }

        if(this.totalContactDisplay) {
            this.totalContactDisplay.textContent = data.total_contact
        }

        if(this.totalActivityDisplay) {
            this.totalActivityDisplay.textContent = data.total_activity
        }

        if(this.totalAddressDisplay) {
            this.totalAddressDisplay.textContent = data.total_address
        }

        if(this.alsoKnownAsDisplay) {
            this.alsoKnownAsDisplay.textContent = data.also_known_as
        }

        this.updatePrimaryContact(data.primary_contact)
    }

    /**
     * @param {Object|null} value
     */
    updatePrimaryContact(value) {
        if(this.primaryContactSection) {
            this.primaryContactSection.classList.toggle('d-none', !value)
        }

        if(!value) {
            return
        }

        if(this.primaryContactAvatar && this.primaryContactInitial) {
            if(value.profile_picture_id) {
                this.primaryContactAvatar.src = `${BASE_URL}/core/images/thumbnail/${value.profile_picture_id}`
                this.primaryContactAvatar.classList.remove('d-none')
                this.primaryContactInitial.classList.add('d-none')
            } else {
                this.primaryContactAvatar.classList.add('d-none')
                this.primaryContactInitial.classList.remove('d-none')
            }
        }

        const initialSpan = this.primaryContactInitial?.querySelector('span')
        if(initialSpan) {
            initialSpan.textContent = this.helper.getInitialName(value.name)
        }

        if(this.primaryContactLink) {
            this.primaryContactLink.setAttribute('href', `/master-data/contact/${value.id}`)
        }

        if(this.primaryContactName) {
            this.primaryContactName.textContent = value.name ?? ''
        }

        if(this.primaryContactJobTitle) {
            this.primaryContactJobTitle.textContent = value.job_title ?? ''
            this.primaryContactJobTitle.classList.toggle('d-none', !value.job_title)
        }
    }
}
