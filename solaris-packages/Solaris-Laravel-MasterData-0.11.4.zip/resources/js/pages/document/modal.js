import { DocumentStatus } from "@master-data-js/const"
import Filter from "@core-js/solaris/filter/filter"
import SolarModalPage from "@core-js/solaris/solar/solar-modal-page"

export default class DocumentModal extends SolarModalPage {
    constructor() {
        super("document-modal")
    }

    init() {
        const account = this.form.get("account_id")
        const contact = this.form.get("contact_id")

        contact?.init({
            param: (param) => {
                const filter    = new Filter()
                const accountId = account.get()?.id
                if(accountId) {
                    filter.and("account_id", accountId)
                    param.filter = filter.get()
                }
        
                return param
            }
        })
        
        account?.on("change", (value) => {    
            const contactVal = contact.get()
            if(!value || (contactVal && value && contactVal.account?.id != value.id)) {
                contact.set(null)
            }
        
            if(value && !contactVal && value.primary_contact) {
                contact.set(value.primary_contact)
            }
        }, "DocumentModal")
        
        contact?.on("change", (value) => {
            const accountVal = account.get()
            if(value && value.account && !accountVal) {
                account.set(value.account)
            }
        }, "DocumentModal")

        this.modal.on("show", () => {
            this.form.set('date', new Date())
            this.form.set('status_id', {
                id  : DocumentStatus.Draft,
                name: "Draft"
            })
        }, "DocumentModal")
    }
}