import SolarListPage from "@core-js/solaris/solar/solar-list-page";
import DocumentModal from "./modal";

export default class DocumentListPage extends SolarListPage {
    init() {
        this.documentModal = this.hasModalForm() ? new DocumentModal() : null

        this.columnRender("number", this.numberColumnRender.bind(this))
        this.columnRender("account_id", this.accountColumnRender.bind(this))
        this.columnRender("contact_id", this.contactColumnRender.bind(this))
        this.columnRender("status_id", this.statusColumnRender.bind(this))
    }

    openEditPage(id) {
        this.helper.loadingPage(true)
        window.location = `${BASE_URL}/master-data/document/edit/${id}`
    }

    async edit(row, data) {
        this.openEditPage(data.id)
    }

    rowDoubleClick(row, data) {
        this.openEditPage(data.id)
    }

    numberColumnRender(data, rowData) {
        return `<div class="d-flex flex-column gap-1">
            <a class="fw-medium text-decoration-underline" href="${BASE_URL}/master-data/document/${rowData.id}">${data}</a>
            <span class="text-muted"><i class="ri-calendar-line me-1"></i>${rowData.date}</span>
        </div>`
    }

    accountColumnRender(data, rowData) {
        if(this.helper.isEmpty(data)) {
            return data
        }

        const initialName = this.helper.getInitialName(data)
        return `<div class="d-flex align-items-center gap-2">
            <div class="lh-1">
                <span class="avatar avatar-rounded avatar-sm ${!rowData.account.profile_picture_id ? "bg-secondary" : ""}">
                    ${rowData.account.profile_picture_id ? `<img src="${BASE_URL}/core/images/thumbnail/${rowData.account.profile_picture_id}" alt="">` : initialName}
                </span>
            </div>
            <div>
                <a class="fw-medium text-decoration-underline" href="${BASE_URL}/master-data/account/${rowData.account_id}">${data}</a>
            </div>
        </div>`
    }

    contactColumnRender(data, rowData) {
        if(this.helper.isEmpty(data)) {
            return data
        }

        const initialName = this.helper.getInitialName(data)
        return `<div class="d-flex align-items-center gap-2">
            <div class="lh-1">
                <span class="avatar avatar-rounded avatar-sm ${!rowData.contact.profile_picture_id ? "bg-secondary" : ""}">
                    ${rowData.contact.profile_picture_id ? `<img src="${BASE_URL}/core/images/thumbnail/${rowData.contact.profile_picture_id}" alt="">` : initialName}
                </span>
            </div>
            <div>
                <a class="text-decoration-underline" href="${BASE_URL}/master-data/contact/${rowData.contact_id}">${data}</a>
            </div>
        </div>`
    }

    statusColumnRender(data, rowData) {
        return `<span class="badge bg-${rowData.status.color}">${data}</span>`
    }

}