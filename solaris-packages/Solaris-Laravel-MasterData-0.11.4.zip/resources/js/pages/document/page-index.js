import DocumentPage from "./page";

new DocumentPage()