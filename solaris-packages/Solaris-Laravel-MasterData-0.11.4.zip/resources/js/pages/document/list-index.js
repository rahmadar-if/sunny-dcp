import DocumentListPage from "./list"

new DocumentListPage("document")