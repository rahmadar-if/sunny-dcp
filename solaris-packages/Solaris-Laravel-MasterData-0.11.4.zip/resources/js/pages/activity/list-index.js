import ActivityListPage from "./list"

new ActivityListPage('activity', false)