import Filter from "@core-js/solaris/filter/filter";
import SolarListPage from "@core-js/solaris/solar/solar-list-page";
import ActivityModal from "./modal"
import Calendar from "@core-js/solaris/calendar";

export default class ActivityListPage extends SolarListPage {
    init() {
        this.tableNeedReload = true
        this.activityModal   = this.hasModalForm() ? new ActivityModal(this.modalForm) : null

        this.initCalendar()

        this.columnRender("subject", this.subjectColumnRender.bind(this))
        this.columnCreated("subject", this.subjectColumnCreated.bind(this))

        this.form.on("success", () => {
            this.tableNeedReload = false
            this.calendar.refresh()
        }, "ActivityListPage")
    }

    initCalendar() {
        /** @type { Calendar } */
        this.calendar = this.get(`${this.id}_calendar`)

        this._calendarDateClick     = false
        this._calendarDateClickInfo = null

        this.calendar
            .on("init", this.calendarInit.bind(this), "ActivityListPage")
            .on("fetch", this.calendarFetch.bind(this), "ActivityListPage")
            .on("dateClick", this.calendarDateClick.bind(this), "ActivityListPage")
            .on("eventClick", this.calendarEventClick.bind(this), "ActivityListPage")
            .on("eventDrop", this.calendarEventDrop.bind(this), "ActivityListPage")
            .on("select", this.calendarSelect.bind(this), "ActivityListPage")
            .render()

        if (this.calendar.isInit) {
            const { startDate, endDate } = this.calendar.currentRange
            this.calendarInit(startDate, endDate)
        }

        this.modal?.on("show", () => {
            if(this._calendarDateClick) {
                this.form.get("start_date").set(this._calendarDateClickInfo.date)
                
                this._calendarDateClick     = false
                this._calendarDateClickInfo = null
            }
        }, "ActivityListPage")
    }

    openEditPage(id) {
        this.helper.loadingPage(true)
        window.location = `${BASE_URL}/master-data/activity/edit/${id}`
    }

    subjectColumnRender(data, row) {
        const accountInitialName = row.account ? this.helper.getInitialName(row.account.name) : null
        const contactInitialName = row.contact ? this.helper.getInitialName(row.contact.name) : null
        const formattedDate = this.formatDate(row.start_date, row.end_date)
        const priority = {
            High    : 'text-danger',
            Medium  : 'text-warning',
            Low     : 'text-info'
        }

        return `<div class="d-flex flex-column gap-2">
            <div class="d-flex align-items-center gap-2">
                <div class="d-flex gap-1 align-items-center">
                    <i class="ri-checkbox-blank-circle-fill me-1 ${priority[row.priority.name]}" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="${row.priority.name}"></i>
                    <span class="fw-medium text-nowrap">${formattedDate.date}</span>
                </div>
                <span class="badge bg-light text-default">${formattedDate.time}</span>
            </div>
            <span class="fw-medium fs-13">${data}</span>
            <div class="d-flex justify-content-between">
                <div class="d-flex flex-column justify-content-center gap-2">
                    ${row.account ? `<div class="d-flex align-items-center gap-2">
                        <div class="lh-1">
                            <span class="avatar avatar-rounded avatar-xs ${!row.account.profile_picture_id ? "bg-secondary" : ""}">
                                ${row.account.profile_picture_id ? `<img src="${BASE_URL}/core/images/thumbnail/${row.account.profile_picture_id}" alt="">` : accountInitialName}
                            </span>
                        </div>
                        <div>
                            <a class="text-decoration-underline fs-12" href="${BASE_URL}/master-data/account/${row.account_id}">${row.account.name}</a>
                        </div>
                    </div>` : ""}
                    ${row.contact ? `<div class="d-flex align-items-center gap-2">
                        <div class="lh-1">
                            <span class="avatar avatar-rounded avatar-xs ${!row.contact.profile_picture_id ? "bg-secondary" : ""}">
                                ${row.contact.profile_picture_id ? `<img src="${BASE_URL}/core/images/thumbnail/${row.contact.profile_picture_id}" alt="">` : contactInitialName}
                            </span>
                        </div>
                        <div>
                            <a class="text-decoration-underline fs-12" href="${BASE_URL}/master-data/contact/${row.contact_id}">${row.contact.name}</a>
                        </div>
                    </div>` : ""}
                </div>
                <div class="d-flex align-items-end dropdown">
                    <button type="button" class="btn btn-sm btn-light" data-bs-toggle="dropdown" aria-expanded="false"><i class="ri-more-fill"></i></button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item edit-action" href="javascript:void(0);"><i class="ri-pencil-line me-1"></i>Edit</a></li>
                        <li><a class="dropdown-item delete-action" href="javascript:void(0);"><i class="ri-delete-bin-fill me-1"></i>Delete</a></li>
                    </ul>
                </div>
            </div>
        </div>`
    }

    subjectColumnCreated(row, cell, cellData, RowData) {
        const editAction    = cell.querySelector("div.dropdown ul.dropdown-menu .edit-action")
        const deleteAction  = cell.querySelector("div.dropdown ul.dropdown-menu .delete-action")

        editAction.addEventListener("click", () => this.table.trigger("edit", row, RowData))
        deleteAction.addEventListener("click", async () => await this.table.delete(row, RowData))
    }

    ready(settings, json) {
        const tooltipTriggerList = this.table._wrapper.querySelectorAll('[data-bs-toggle="tooltip"]')
        const tooltipList        = [...tooltipTriggerList].map((tooltipTriggerEl) => new bootstrap.Tooltip(tooltipTriggerEl))
    }

    draw(e, settings) {
        const tooltipTriggerList = this.table._wrapper.querySelectorAll('[data-bs-toggle="tooltip"]')
        const tooltipList        = [...tooltipTriggerList].map((tooltipTriggerEl) => new bootstrap.Tooltip(tooltipTriggerEl))
    }

    async edit(row, data) {
        this.openEditPage(data.id)
    }

    rowDoubleClick(row, data) {
        this.openEditPage(data.id)
    }

    async deleted(data) {
        this.tableNeedReload = false
        this.calendar.refresh()
    }

    //#region calendar event
    
    async calendarInit(startDate, endDate) {
        const filter = new Filter()
        filter.andBetween("start_date", [startDate, endDate])

        await this.table.filter("calendar", filter, false, false)
        await this.table.render()
    }

    calendarFetch(startDate, endDate) {
        const filter = new Filter()
        filter.andBetween("start_date", [startDate, endDate])

        if(this.tableNeedReload) {
            this.table.filter("calendar", filter)
        }

        if(!this.tableNeedReload) {
            this.tableNeedReload = true
        }
    }

    calendarDateClick(info) {
        this._calendarDateClick     = true
        this._calendarDateClickInfo = info
    }

    calendarEventClick(info) {
        this.activityModal?.edit(info.event.id)
    }

    calendarEventDrop(info) {

    }

    calendarSelect(info) {
        
    }

    //#endregion

    /**
     * @param {string|null} startDate - ISO 8601 datetime string (e.g. "2026-05-11T02:18:26.000000Z")
     * @param {string|null} endDate - ISO 8601 datetime string
     * @returns {{ date: string, time: string }}
     */
    formatDate(startDate, endDate) {
        const monthNames = [
            "Jan", "Feb", "Mar", "Apr",
            "May", "Jun", "Jul", "Aug",
            "Sep", "Oct", "Nov", "Dec"
        ];

        const parseDate = (str) => new Date(str);

        const formatTime = (date) => {
            const h = date.getHours();
            const m = date.getMinutes().toString().padStart(2, '0');
            const suffix = h >= 12 ? "PM" : "AM";
            const hour12 = h % 12 || 12;
            return `${hour12}:${m} ${suffix}`;
        };

        const formatDate = (date) => {
            return `${date.getDate()} ${monthNames[date.getMonth()]} ${date.getFullYear()}`;
        };

        if (!startDate) return { date: "-", time: "-" };

        const start = parseDate(startDate);
        const end = endDate ? parseDate(endDate) : null;

        let dateText = "";
        let timeText = "";

        if (!end) {
            dateText = formatDate(start);
            timeText = formatTime(start);
        } else {
            const sameDay =
            start.getDate() === end.getDate() &&
            start.getMonth() === end.getMonth() &&
            start.getFullYear() === end.getFullYear();

            const sameMonth = start.getMonth() === end.getMonth();
            const sameYear = start.getFullYear() === end.getFullYear();

            if (sameDay) {
                dateText = formatDate(start);
                timeText = `${formatTime(start)} to ${formatTime(end)}`;
            } else if (sameMonth && sameYear) {
                dateText = `${start.getDate()} to ${end.getDate()} ${monthNames[start.getMonth()]} ${start.getFullYear()}`;
                timeText = `${formatTime(start)} to ${formatTime(end)}`;
            } else if (!sameMonth && sameYear) {
                dateText = `${start.getDate()} ${monthNames[start.getMonth()]} to ${end.getDate()} ${monthNames[end.getMonth()]} ${end.getFullYear()}`;
                timeText = `${formatTime(start)} to ${formatTime(end)}`;
            } else {
                dateText = `${start.getDate()} ${monthNames[start.getMonth()]} ${start.getFullYear()} to ${end.getDate()} ${monthNames[end.getMonth()]} ${end.getFullYear()}`;
                timeText = `${formatTime(start)} to ${formatTime(end)}`;
            }
        }

        return { date: dateText, time: timeText }
    }
}