import { ActivityStatus } from "@core-js/const";
import { ReminderType } from "../../const";
import Filter from "@core-js/solaris/filter/filter";
import SolarEditPage from "@core-js/solaris/solar/solar-edit-page";

export default class ActivityPage extends SolarEditPage {
    init() {
        this._savedReminders = []
        this._savedRemindTo  = []
        this.displayValueName = "subject"
        this.initForm()
        this.initReminder()
    }

    initForm() {
        const subject = this.form.get("subject")
        const status  = this.form.get("status_id")
        const endDate = this.form.get("end_date")
        
        subject?.on('input',(value) => this.breadcrumbName.innerText = value, "ActivityPage")

        status?.on("change", (value) => {
            if(value && value.id == ActivityStatus.Finish) {
                endDate.required()
            } else {
                endDate.optional()
            }
        }, "ActivityPage")

        const account = this.form.get("account_id")
        const contact = this.form.get("contact_id")

        account?.on("change", (value) => {
            if(!value) {
                contact.set(null)
                return
            }
        
            const contactVal = contact.get()
            if(value.primary_contact && !contactVal) {
                contact.set(value.primary_contact)
            } else if(contactVal && ((contactVal.account && contactVal.account.id != value.id) || !contactVal.account)) {
                contact.set(value.primary_contact ? value.primary_contact : null)
            }
        }, "ActivityPage")

        contact?.init({
            param: (param) => {
                const filter = new Filter()
                const accountVal = account.get()
                if(accountVal) {
                    filter.and("account_id", accountVal.id)
                }
        
                param.filter = filter.get()
        
                return param
            }
        })
        
        contact?.on("change", (value) => {
            if(value && value.account && !account.get()) {
                account.set(value.account)
            }
        }, "ActivityPage")

        this.form.exclude(["owner_id"])
    }

    initReminder() {
        const startDate     = this.form.get("start_date")
        const remindMe      = this.form.get("remind_me")
        const remindTo      = this.form.get("remind_to")
        const reminderTypes = this.form.get("reminder_types")

        startDate?.on("change", (value) => {
            const now = new Date()
            if(!value || (value && value <= now)) {
                if(!remindMe.isDisabled()) {
                    remindMe.set(false)
                    remindMe.disabled()
                }
                return
            } else {
                remindMe.enabled()
            }

            this.reminderTypeCheck(startDate)
        }, "ActivityPage")

        remindMe?.on("change", (value) => {
            if(!value) {
                this._savedRemindTo = remindTo.get() || []
            }

            reminderTypes.reset()
            remindTo.reset()

            if(value) {
                reminderTypes.show()
                remindTo.show()

                if(this._savedReminders.length) {
                    reminderTypes.set(this._savedReminders, true)
                    this.reminderTypeCheck(startDate)
                }

                if(this._savedRemindTo.length) {
                    remindTo.set(this._savedRemindTo)
                }
            } else {
                reminderTypes.hidden()
                remindTo.hidden()
            }
        }, "ActivityPage")

        this.form.addValidation("reminder_types", (value) => {
            const isValid = (remindMe.get() && value ? true : false) || !remindMe.get()
            return {
                success: isValid,
                message: "Reminder type is required",
            }
        })
        .on("submitting", () => this.reminderTypeCheck(startDate), "ActivityPage")
        .on("invalid", () => {
            setTimeout(() => this.reminderTypeCheck(startDate), 0)
        }, "ActivityPage")

        reminderTypes?._plugin._options.forEach(opt => {
            if(!opt.get()) {
                return
            }
            
            const type = this.getReminderType(opt._element.value)
            if(type) {
                this._savedReminders.push({ id: opt._element.value, name: type.name })
            }
        })
    }

    getReminderType(id) {
        for(const key in ReminderType) {
            const type = ReminderType[key]
            if(type.id == id) {
                return type
            }
        }
        return null
    }

    reminderTypeCheck(startDate) {
        const now          = new Date()
        const savedTypeIds = this._savedReminders.map(r => r.id)

        const reminderTypes = this.form.get("reminder_types")
        reminderTypes?._plugin._options.forEach(opt => {
            const minutes       = this.getReminderType(opt._element.value)?.offset_minutes ?? 0
            const offsetMinutes = parseInt(minutes, 10)
            const reminderTime  = new Date(startDate.get().getTime() - offsetMinutes * 60000)

            if(reminderTime <= now) {
                opt.disabled()
            } else {
                opt.enabled()
            }

            if(opt.isDisabled() && !savedTypeIds.includes(opt._element.value)) {
                opt.set(false, true)
            }
        })
    }

    async onRefreshed(data) {
        this.breadcrumbName.innerText = data.subject

        const remindMe      = this.form.get("remind_me")
        const reminderTypes = this.form.get("reminder_types")
        const remindTo      = this.form.get("remind_to")
        const startDate     = this.form.get("start_date")

        if(!data.reminders?.length) {
            this._savedReminders = []
            this._savedRemindTo  = []
            remindMe?.set(false)
            return
        }

        this._savedReminders = data.reminders.map(r => ({ id: r.type_id, name: r.type.name }))
        this._savedRemindTo  = data.remind_users || []

        remindMe?.set(true)
        reminderTypes?.set(this._savedReminders, true)

        if(data.remind_users?.length) {
            remindTo?.set(data.remind_users)
        }

        this.reminderTypeCheck(startDate)
    }
}