import SolarListDetail from "@core-js/solaris/solar/solar-list-detail";
import ActivityModal from "./modal";

export default class ActivityDetail extends SolarListDetail {
    init() {
        /** @type {ActivityModal} */
        this.activityModal = this.hasModalForm() ? new ActivityModal() : null
        this.columnRender("priority_id", this.priotitytColumnRender.bind(this))
    }

    priotitytColumnRender(data, rowData) {
        const priority = {
            High    : 'danger',
            Medium  : 'info',
            Low     : 'success'
        }

        return `<span class="badge bg-${priority[data]}">${data}</span>`
    }

    async view(row, data) {
        this.openEditPage(data.id)
    }

    async edit(row, data) {
        this.activityModal?.edit(data.id)
    }

    rowDoubleClick(row, data) {
        this.openEditPage(data.id)
    }

    openEditPage(id) {
        this.helper.loadingPage(true)
        window.location = `${BASE_URL}/master-data/activity/edit/${id}`
    }
}