import { ReminderType } from "../../const";
import Filter from "@core-js/solaris/filter/filter";
import SolarModalPage from "@core-js/solaris/solar/solar-modal-page";

export default class ActivityModal extends SolarModalPage {
    constructor() {
        super("activity-modal")
    }

    init() {
        this._savedReminders = []
        this._savedRemindTo  = []
        this.initModal()
        this.initForm()
    }

    initModal() {
        this.modal
            ?.on("show", () => {
                if(!this.form.isEdit()) {
                    this.form.set("start_date", new Date())
                }
            }, "ActivityModal")
            .on("hidden", () => {
                this.form.get("reminder_types")?.hidden()
                this.form.get("remind_to")?.hidden()
                this.form.get("remind_me")?.enabled()
                this._savedReminders = []
                this._savedRemindTo  = []
            }, "ActivityModal")
    }

    initForm() {
        const account = this.form.get("account_id")
        const contact = this.form.get("contact_id")

        account?.on("change", (value) => {
            const contactValue = contact.get()
            if(!value || (value && contactValue && contactValue.account?.id != value.id)) {
                contact.set(null)
            }
        }, "ActivityModal")

        contact?.init({
            param: (param) => {
                const filter = new Filter()

                if(account.get()) {
                    filter.and("account_id", account.get().id)
                    param.filter = filter.get()
                }

                return param
            }
        })

        contact?.on("change", (value) => {
            const accountValue = account.get()
            if(value && value.account && !accountValue) {
                account.set(value.account)
            }
        }, "ActivityModal")

        const startDate     = this.form.get("start_date")
        const remindMe      = this.form.get("remind_me")
        const remindTo      = this.form.get("remind_to")
        const reminderTypes = this.form.get("reminder_types")

        startDate?.on("change", (value) => {
            const now = new Date()
            if(!value || (value && value <= now)) {
                if(!remindMe.isDisabled()) {
                    remindMe.set(false)
                    remindMe.disabled()
                }

                return
            } else {
                remindMe.enabled()
            }

            this.reminderTypeCheck(startDate)
        }, "ActivityModal")

        remindMe?.on("change", (value) => {
            if(!value) {
                this._savedRemindTo = remindTo.get() || []
            }

            reminderTypes.reset()
            remindTo.reset()

            if(value) {
                reminderTypes.show()
                remindTo.show()

                if(this._savedReminders.length) {
                    reminderTypes.set(this._savedReminders, true)
                    this.reminderTypeCheck(startDate)
                }

                if(this._savedRemindTo.length) {
                    remindTo.set(this._savedRemindTo)
                }
            } else {
                reminderTypes.hidden()
                remindTo.hidden()
            }
        }, "ActivityModal")

        this.form.addValidation("reminder_types", (value) => {
            const isValid = (remindMe?.get() && value ? true : false) || !remindMe?.get()

            return {
                success: isValid,
                message: "Reminder type is required",
            }
        })
        .on("submitting", () => this.reminderTypeCheck(startDate), "ActivityModal")
        .on("invalid", (validation) => {
            setTimeout(() => {
                this.reminderTypeCheck(startDate)
            }, 0)
        }, "ActivityModal")
    }

    getReminderType(id) {
        for (const key in ReminderType) {
            const type = ReminderType[key]
            if(type.id == id) {
                return type
            }
        }

        return null
    }

    reminderTypeCheck(startDate) {
        const now          = new Date()
        const savedTypeIds = this._savedReminders.map(r => r.id)

        const reminderTypes = this.form.get("reminder_types")
        reminderTypes?._plugin._options.forEach(opt => {
            const minutes       = this.getReminderType(opt._element.value)?.offset_minutes ?? 0
            const offsetMinutes = parseInt(minutes, 10)
            const reminderTime  = new Date(startDate.get().getTime() - offsetMinutes * 60000)

            if(reminderTime <= now) {
                opt.disabled()
            } else {
                opt.enabled()
            }

            if(opt.isDisabled() && !savedTypeIds.includes(opt._element.value)) {
                opt.set(false, true)
            }
        })
    }

    onEdit(form, data) {
        if(!data.reminders?.length) {
            return
        }

        const remindMe      = this.form.get("remind_me")
        const reminderTypes = this.form.get("reminder_types")
        const remindTo      = this.form.get("remind_to")
        const startDate     = this.form.get("start_date")

        this._savedReminders = data.reminders.map(r => ({ id: r.type_id, name: r.type.name }))

        remindMe?.set(true)
        reminderTypes?.set(this._savedReminders, true)

        if(data.remind_users?.length) {
            remindTo?.set(data.remind_users)
        }

        this.reminderTypeCheck(startDate)
    }
}
