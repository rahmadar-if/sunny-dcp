import SolarListPage from "@core-js/solaris/solar/solar-list-page";

export default class KnowledgeBaseListPage extends SolarListPage {
    init() {
        this.columnRender("name", this.nameColumnRender.bind(this))
        this.columnRender("status_id", this.statusColumnRender.bind(this))
    }

    openEditPage(id) {
        this.helper.loadingPage(true)
        window.location = `${BASE_URL}/master-data/knowledge-base/edit/${id}`
    }

    async edit(row, data) {
        this.openEditPage(data.id)
    }

    rowDoubleClick(row, data) {
        this.openEditPage(data.id)
    }

    nameColumnRender(data, rowData) {
        return `<a class="fw-medium text-decoration-underline" href="${BASE_URL}/master-data/knowledge-base/${rowData.id}">${data}</a>`
    }

    statusColumnRender(data, rowData) {
        return `<span class="d-block text-muted fs-11">
            <span class="badge bg-${rowData.status.color}">${data}</span>
        </span>`
    }
}