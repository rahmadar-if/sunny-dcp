import KnowledgeBasePage from "./page"

new KnowledgeBasePage()