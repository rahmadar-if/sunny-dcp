import SolarEditPage from "@core-js/solaris/solar/solar-edit-page";

export default class KnowledgeBasePage extends SolarEditPage {
    init() {
        this.form.exclude(["knowledge-base-page-created_by_id"])

        const name = this.form.get("name") 
        name?.on('input', (value) => this.breadcrumbName.innerText = value, "KnowledgeBasePage")
    }

    async failed(errors, message) {
        if(errors.article) {
            this.helper.toast({message: errors.article, color: "danger"})
        }
    }

    async onRefreshed(data) {
        this.breadcrumbName.innerText = data.name
        this.form.set("created_by_id", data.created_by.name)
    }
}