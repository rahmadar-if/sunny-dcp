import KnowledgeBaseListPage from "./list"

new KnowledgeBaseListPage("knowledge-base")