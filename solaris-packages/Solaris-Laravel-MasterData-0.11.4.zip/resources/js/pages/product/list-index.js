import ProductListPage from "./list"

new ProductListPage("product")