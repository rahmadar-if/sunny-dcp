import SolarEditPage from "@core-js/solaris/solar/solar-edit-page";
import ProductFeatureDetail from "./feature-detail";
import ProductAvailabilityDetail from "./availability-detail";
import ProductPriceHistoryDetail from "./price-history-detail";

export default class ProductPage extends SolarEditPage {
    init() {
        this.totalContactDisplay  = document.getElementById('total_contact_display')
        this.totalActivityDisplay = document.getElementById('total_activity_display')

        this.initForm()

        this.registerDetail("product-feature", ProductFeatureDetail, "product_id")
        this.registerDetail("product-availability", ProductAvailabilityDetail, "product_id")
        this.registerDetail("product-price-history", ProductPriceHistoryDetail, "product_id")
    }

    initDetail() {
        this.productAvailability
            ?.on("saved", (res) => this.refreshForm(), "ProductPage")
            .on("deleting", async (row, data) => await this._onSavingDetail(), "ProductPage")
            .on("deleted", (data) => this.refreshForm(), "ProductPage")
    }

    initForm() {
        const name      = this.form.get("name")
        const type      = this.form.get("type_id")
        const category  = this.form.get("category")
        const brand     = this.form.get("brand")
        const skuNumber = this.form.get("sku_number")

        const nameDisplay          = document.getElementById('name_display')
        const typeDisplay          = document.getElementById('type_display')
        const categoryBrandDisplay = document.getElementById('category_brand_display')
        const skuDisplay           = document.getElementById('sku_number_display')

        name?.on('input', (value) => {
            nameDisplay.innerText           = value
            this.breadcrumbName.innerText   = value
        }, "ProductPage")

        type?.on('change', (value) => {
            if(typeDisplay) {
                typeDisplay.innerText = value?.name ?? ""
            }
        }, "ProductPage")

        category?.on('input', (value) => {
            if(categoryBrandDisplay) {
                categoryBrandDisplay.innerText = `${value} / ${brand.get()}`
            }
        }, "ProductPage")
        
        brand?.on('input', (value) => {
            if(categoryBrandDisplay) {
                categoryBrandDisplay.innerText = `${category.get()} / ${value}`
            }
        }, "ProductPage")
        
        skuNumber?.on('input', (value) => {
            if(skuDisplay) {
                skuDisplay.innerText = value ?? "-"
            }
        }, "ProductPage")
    }

    async success(response) {
        this.productPriceHistory?.refresh()
    }

    async onRefreshed(data) {
        this.breadcrumbName.innerText = data.name

        const nameDisplay          = document.getElementById('name_display')
        const typeDisplay          = document.getElementById('type_display')
        const categoryBrandDisplay = document.getElementById('category_brand_display')
        const skuNumberDisplay     = document.getElementById('sku_number_display')

        if(nameDisplay) {
            nameDisplay.innerText = data.name
        }

        if(typeDisplay) {
            typeDisplay.innerText = data.type?.name ?? ""
        }

        if(categoryBrandDisplay) {
            categoryBrandDisplay.innerText = `${data.category} / ${data.brand}`
        }

        if(skuNumberDisplay) {
            skuNumberDisplay.innerText = data.sku_number ?? "-"
        }
    }
}