import Filter from "@core-js/solaris/filter/filter"
import SolarListDetail from "@core-js/solaris/solar/solar-list-detail"

export default class ProductAvailabilityDetail extends SolarListDetail {
    init() {
        this.initModal()

        this.columnRender("address", this.addressColumnRender.bind(this))
        this.columnCreated("address", this.addressColumnCreated.bind(this))
    }

    initModal() {
        if(!this.hasModalForm()) {
            return
        }
        
        const country  = this.form.get("country_id")
        const province = this.form.get("province_id")
        const city     = this.form.get("city_id")

        province?.init({
            param: (param) => {
                if(country?.get()){
                    const filter = new Filter()
                    filter.and("country_id", country.get().id)
        
                    param.filter = filter.get()
                    return param
                }
        
                return param
            }
        })
        
        city?.init({
            param: (param) => {
                if(province?.get()){
                    const filter = new Filter()
                    filter.and("province_id", province.get().id)
        
                    param.filter = filter.get()
                    return param
                }
        
                return param
            }
        })

        country?.on('change', (value) => {
            if(!value || (province.get() && province.get().country && value && province.get().country.id != value.id)) {
                province?.set(null)
            }
        }, "ProductAvailabilityDetail")

        province?.on('change', (value) => {
            if(value && !country?.get()) {
                country.set(value.country)
            }

            if(!value) {
                city?.set(null)
            }
        }, "ProductAvailabilityDetail")

        city.on('change', (value) => {
            if(value && !province?.get()) {
                province.set(value.province)
            }
        }, "ProductAvailabilityDetail")
    }

    addressColumnRender(data, rowData) {
        return `<span class="d-inline-block text-truncate align-middle" title="Click to expand" style="max-width: 40rem;">${data ?? ""}</span>`
    }

    addressColumnCreated(row, cell, cellData, rowData) {
        const span = cell.children[0]
        span.addEventListener("click", () => {
            span.classList.toggle("d-inline-block")
            span.classList.toggle("text-truncate")
        })
    }
}