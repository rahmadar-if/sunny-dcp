import SolarListDetail from "@core-js/solaris/solar/solar-list-detail";

export default class ProductPriceHistoryDetail extends SolarListDetail {
    init() {
        this.columnRender("price", this.priceColumnRender.bind(this))
    }

    priceColumnRender(data, row) {
        return `Rp ${this.helper.numberToCurrency(data)}`
    }
}