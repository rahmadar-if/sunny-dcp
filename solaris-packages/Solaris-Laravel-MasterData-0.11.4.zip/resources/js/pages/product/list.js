import SolarListPage from "@core-js/solaris/solar/solar-list-page";
import ProfilePicture from "@core-js/solaris/profile-picture";

export default class ProductListPage extends SolarListPage {
    init() {
        this._isProfilePicture = false
        this.initModal()
        
        this.columnRender("name", this.nameColumnRender.bind(this))
        this.columnRender("price", this.priceColumnRender.bind(this))
        this.columnRender("availability", this.availabilityColumnRender.bind(this))
        this.columnRender("active", this.activeColumnRender.bind(this))
    }

    initModal() {
        if(!this.hasModalForm()) {
            return
        }

        /** @type {ProfilePicture} */
        this.profilePicture = this.get("product_picture")
        this.profilePicture?.on("cropped", (res) => {
            this._isProfilePicture = true
            this.form.hiddenSuccessAlert()
        }, "ProductListPage")

        .on("change", (image) => {
            if(!image) {
                this._isProfilePicture = false
                this.form.showSuccessAlert()
            }
        }, "ProductListPage")
        
        .on("success", (res) => {
            this._isProfilePicture = false
            this.form.showSuccessAlert()
        }, "ProductListPage")
        
        this.form
            .off("success", null, "SolarUI.Table")
            .off("success", null, "ModalForm")
            .on("success", this.onFormSuccess.bind(this), "ProductListPage")
    }

    async onFormSuccess(res) {
        if(this._isProfilePicture) {
            await this.profilePicture.upload(`${BASE_URL}/master-data/product/avatar/${res.data.id}`)
            this.profilePicture.emptyPreview()
            
            this.helper.successAlert({ title: this.form._successAlertMessage })
        }

        this.modal?.hide()
        await this.refresh()
    }

    openEditPage(id) {
        this.helper.loadingPage(true)
        window.location = `${BASE_URL}/master-data/product/edit/${id}`
    }

    async edit(row, data) {
        this.openEditPage(data.id)
    }

    rowDoubleClick(row, data) {
        this.openEditPage(data.id)
    }

    nameColumnRender(data, rowData) {
        const initialName = this.helper.getInitialName(data)

        return `<div class="d-flex align-items-center gap-2">
            <div class="lh-1">
                <span class="avatar avatar-rounded avatar-sm ${!rowData.product_picture_id ? "bg-secondary" : ""}">
                    ${rowData.product_picture_id ? `<img src="${BASE_URL}/core/images/thumbnail/${rowData.product_picture_id}" alt="">` : initialName}
                </span>
            </div>
            <a class="fw-medium text-decoration-underline" href="${BASE_URL}/master-data/product/edit/${rowData.id}">${data}</a>
        </div>`
    }

    priceColumnRender(data, rowData) {
        return "Rp "+this.helper.numberToCurrency(data ?? 0)
    }

    availabilityColumnRender(data, rowData) {
        return `${data ?? 0} ${rowData.unit_of_measure}`
    }

    activeColumnRender(data, rowData) {
        const badgeClass = rowData.active ? 'bg-success' : 'bg-danger'
        const label = rowData.active ? 'Active' : 'Not Active'
        
        return `<span class="badge ${badgeClass} fs-10">${label}</span>`
    }
}