import SolarListPage from "@core-js/solaris/solar/solar-list-page";
import ContactModal from "./modal";

export default class ContactListPage extends SolarListPage {
    init() {        
        this.contactModal = this.hasModalForm() ? new ContactModal(this.modalForm) : null
        this.columnRender("name", this.nameColumnRender.bind(this))
        this.columnRender("account_id", this.accountColumnRender.bind(this))
    }

    openEditPage(id) {
        this.helper.loadingPage(true)
        window.location = `${BASE_URL}/master-data/contact/edit/${id}`
    }

    async edit(row, data) {
        this.openEditPage(data.id)
    }

    rowDoubleClick(row, data) {
        this.openEditPage(data.id)
    }

    nameColumnRender(data, rowData) {
        const initialName   = this.helper.getInitialName(data)

        return `<div class="d-flex align-items-center gap-2">
            <div class="lh-1">
                <span class="avatar avatar-rounded avatar-md ${!rowData.profile_picture_id ? "bg-secondary" : ""}">
                    ${rowData.profile_picture_id ? `<img src="${BASE_URL}/core/images/thumbnail/${rowData.profile_picture_id}" alt="">` : initialName}
                </span>
            </div>
            <div class="d-flex flex-column gap-1">
                <a class="fw-medium text-decoration-underline" href="${BASE_URL}/master-data/contact/edit/${rowData.id}">${data}</a>
                <span class="text-muted fs-12"><i class="ri-phone-line me-2"></i>${rowData.primary_mobile_phone ?? '-'}</span>
                <span class="text-muted fs-12"><i class="ri-mail-line me-2"></i>${rowData.email ?? '-'}</span>
            </div>
        </div>`
    }

    accountColumnRender(data, rowData) {
        if(!data) {
            return data
        }
        
        const initialName = this.helper.getInitialName(data)
        return `<div class="d-flex align-items-center gap-2">
            <div class="lh-1">
                <span class="avatar avatar-rounded avatar-md ${!rowData.account.profile_picture_id ? "bg-secondary" : ""}">
                    ${rowData.account.profile_picture_id ? `<img src="${BASE_URL}/core/images/thumbnail/${rowData.account.profile_picture_id}" alt="">` : initialName}
                </span>
            </div>
            <div class="d-flex flex-column gap-1">
                <a class="fw-medium text-decoration-underline" href="${BASE_URL}/master-data/contact/${rowData.account.id}">${data}</a>
                <span class="text-muted fs-12"><i class="ri-smartphone-line me-2"></i>${rowData.account.primary_mobile_phone ?? '-'}</span>
                <span class="text-muted fs-12"><i class="ri-mail-line me-2"></i>${rowData.account.email ?? '-'}</span>
            </div>
        </div>`
    }
}