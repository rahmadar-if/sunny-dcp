import Filter from "@core-js/solaris/filter/filter";
import SolarListDetail from "@core-js/solaris/solar/solar-list-detail";

export default class ContactRelatedContactDetail extends SolarListDetail {
    init() {
        this.initModal()

        this.columnRender("related_contact_id", this.relatedContactColumnRender.bind(this))
    }

    initModal() {
        if(!this.hasModalForm()) {
            return
        }

        const contact = this.form.get("related_contact_id")
        contact.init({
            param: (param) => {
                const filter = new Filter()
                filter.and("id", Filter.OperatorType.NotEqual, this.parentValue.id)
                param.filter = filter.get()
        
                return param
            }
        })
    }

    relatedContactColumnRender(data, rowData) {
        const initialName = this.helper.getInitialName(data)
        return `<div class="d-flex align-items-center gap-2">
            <div class="lh-1">
                <span class="avatar avatar-rounded avatar-sm ${!rowData.profile_picture_id ? "bg-secondary" : ""}">
                    ${rowData.profile_picture_id ? `<img src="${BASE_URL}/core/images/thumbnail/${rowData.profile_picture_id}" alt="">` : initialName}
                </span>
            </div>
            <div class="d-flex flex-wrap">
                <a class="text-decoration-underline" href="${BASE_URL}/master-data/contact/edit/${rowData.id}">${data}</a>
            </div>
        </div>`
    }

    rowDoubleClick(row, data) {
        this.modalForm?.edit(data.id)
    }
}