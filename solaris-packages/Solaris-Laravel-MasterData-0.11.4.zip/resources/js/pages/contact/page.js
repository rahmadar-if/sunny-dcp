import { Gender, Salutation } from "@core-js/const";
import SolarEditPage from "@core-js/solaris/solar/solar-edit-page";
import ContactAddressDetail from "./address-detail";
import ContactHobbyDetail from "./hobby-detail";
import ContactCommunicationDetail from "./communication-detail";
import ContactRelatedContactDetail from "./related-contact-detail";
import ContactActivityDetail from "./activity-detail";

export default class ContactPage extends SolarEditPage {
    /**
     * @returns {void}
     */
    init() {
        this.initProfileContainer()
        this.initForm()

        this.registerDetail("contact-address", ContactAddressDetail, "contact_id")
        this.registerDetail("contact-hobby", ContactHobbyDetail, "contact_id")
        this.registerDetail("contact-communication", ContactCommunicationDetail, "contact_id")
        this.registerDetail("contact-related-contact", ContactRelatedContactDetail, "contact_id")
        this.registerDetail("contact-activity", ContactActivityDetail, "contact_id", {
            id      : this.id,
            name    : this.form.get("name").get(),
            account : this.form.get("account_id")?.get()
        })
    }

    /**
     * @returns {void}
     */
    initProfileContainer() {
        this.nameDisplay               = document.getElementById('name_display')
        this.jobTitleDisplay           = document.getElementById('job_title_display')
        this.emailDisplay              = document.getElementById('email_display')
        this.primaryPhoneDisplay       = document.getElementById('primary_phone_display')
        this.accountSection            = document.getElementById('account_section')
        this.accountLink               = document.getElementById('account_link')
        this.companyName               = document.getElementById('company_name')
        this.accountAvatar             = document.getElementById('account_avatar')
        this.accountInitial            = document.getElementById('account_initial')
        this.accountTypeBadge          = document.getElementById('account_type_badge')
        this.accountIndustryBadge      = document.getElementById('account_industry_badge')
        this.totalActivityDisplay           = document.getElementById('total_activity_display')
        this.totalAddressDisplay            = document.getElementById('total_address_display')
        this.totalCommunicationDisplay      = document.getElementById('total_communication_display')
        this.primaryMobilePhoneDisplay      = document.getElementById('primary_mobile_phone_display')
    }

    /**
     * @returns {void}
     */
    initForm() {
        const name         = this.form.get("name")
        const jobTitle     = this.form.get("job_title")
        const email        = this.form.get("email")
        const primaryPhone = this.form.get("primary_phone")
        const salutation   = this.form.get("salutation_id")
        const gender       = this.form.get("gender_id")
        const age          = this.form.get("age")
        const birthDate    = this.form.get("birth_date")
        const account      = this.form.get("account_id")
        const mobilePhone  = this.form.get("primary_mobile_phone")

        name?.on('input', (value) => {
            this.breadcrumbName.innerText = value
            if(this.nameDisplay) {
                this.nameDisplay.innerText = value
            }
        }, "ContactPage")

        jobTitle?.on('input', (value) => {
            if(this.jobTitleDisplay) {
                this.jobTitleDisplay.innerText = value
            }
        }, "ContactPage")

        email?.on('input', (value) => {
            if(!this.emailDisplay) {
                return
            }
            this.emailDisplay.innerText = value || '-'
            if(value) {
                this.emailDisplay.setAttribute('href', `mailto:${value}`)
                this.emailDisplay.classList.add('text-decoration-underline')
            } else {
                this.emailDisplay.removeAttribute('href')
                this.emailDisplay.classList.remove('text-decoration-underline')
            }
        }, "ContactPage")

        primaryPhone?.on('input', (value) => {
            if(!this.primaryPhoneDisplay) {
                return
            }
            this.primaryPhoneDisplay.innerText = value || '-'
            if(value) {
                const normalized = this.helper.normalizePhoneNumber(value)
                this.primaryPhoneDisplay.setAttribute('href', `https://wa.me/${normalized}`)
                this.primaryPhoneDisplay.classList.add('text-decoration-underline')
            } else {
                this.primaryPhoneDisplay.removeAttribute('href')
                this.primaryPhoneDisplay.classList.remove('text-decoration-underline')
            }
        }, "ContactPage")

        mobilePhone?.on('input', (value) => {
            if(!this.primaryMobilePhoneDisplay) {
                return
            }
            this.primaryMobilePhoneDisplay.innerText = value || '-'
            if(value) {
                const normalized = this.helper.normalizePhoneNumber(value)
                this.primaryMobilePhoneDisplay.setAttribute('href', `https://wa.me/${normalized}`)
                this.primaryMobilePhoneDisplay.classList.add('text-decoration-underline')
            } else {
                this.primaryMobilePhoneDisplay.removeAttribute('href')
                this.primaryMobilePhoneDisplay.classList.remove('text-decoration-underline')
            }
        }, "ContactPage")

        salutation?.on("change", (value) => {
            if(!value) {
                return
            }

            let genderId = null
            switch (value.id) {
                case Salutation.Mr:
                    genderId = Gender.Male
                    break

                case Salutation.Mrs:
                case Salutation.Ms:
                    genderId = Gender.Female
                    break

                default:
                    break;
            }

            gender?.set(genderId, genderId ? false : true)
        }, "ContactPage")

        account?.on('change', (value) => {
            if(this.accountSection) {
                this.accountSection.classList.toggle('d-none', !value)
            }
            if(this.companyName) {
                this.companyName.innerText = value?.name ?? '-'
            }
            if(this.accountLink) {
                this.accountLink.setAttribute('href', value?.id ? `/master-data/account/${value.id}` : '#')
            }
            this.updateAccountAvatar(value)
            if(this.accountTypeBadge) {
                this.accountTypeBadge.textContent = value?.type?.name ?? ''
                this.accountTypeBadge.classList.toggle('d-none', !value?.type)
            }
            if(this.accountIndustryBadge) {
                this.accountIndustryBadge.textContent = value?.industry?.name ?? ''
                this.accountIndustryBadge.classList.toggle('d-none', !value?.industry)
            }
        }, "ContactPage")

        age?.set(this.calculateAge(birthDate.get()), "ContactPage")
        birthDate?.on('change', (value) => age?.set(value ? this.calculateAge(value) : 0), "ContactPage")

        this.form.exclude("age")
    }

    /**
     * @returns {void}
     */
    initDetail() {
        this.contactActivity
            ?.on("saved", () => this.refresh(false))
            .on("deleted", () => this.refresh(false))

        this.contactAddress
            ?.on("saved", () => this.refresh(false))
            .on("deleted", () => this.refresh(false))

        this.contactCommunication
            ?.on("saved", () => this.refresh(false))
            .on("deleted", () => this.refresh(false))
    }

    /**
     * @param {Object} response
     * @returns {Promise<void>}
     */
    async success(response) {
        if(this.contactActivity) {
            this.contactActivity.parentValue = {
                id      : this.id,
                name    : this.form.get("name").get(),
                account : this.form.get("account_id").get()
            }
        }
    }

    /**
     * @param {Object} data
     * @returns {Promise<void>}
     */
    async onRefreshed(data) {
        if(this.breadcrumbName) {
            this.breadcrumbName.textContent = data.name
        }

        const age       = this.form.get("age")
        const birthDate = this.form.get("birth_date")
        age?.set(this.calculateAge(birthDate?.get()))

        this.loadProfileContainer(data)
    }

    /**
     * @param {Object} data
     * @returns {void}
     */
    loadProfileContainer(data) {
        if(this.nameDisplay) {
            this.nameDisplay.innerText = data.name ?? '-'
        }

        if(this.jobTitleDisplay) {
            this.jobTitleDisplay.innerText = data.job_title ?? '-'
        }

        if(this.emailDisplay) {
            const email = data.email
            this.emailDisplay.innerText = email ?? '-'
            if(email) {
                this.emailDisplay.setAttribute('href', `mailto:${email}`)
                this.emailDisplay.classList.add('text-decoration-underline')
            } else {
                this.emailDisplay.removeAttribute('href')
                this.emailDisplay.classList.remove('text-decoration-underline')
            }
        }

        if(this.primaryPhoneDisplay) {
            const phone = data.primary_phone
            this.primaryPhoneDisplay.innerText = phone ?? '-'
            if(phone) {
                const normalized = this.helper.normalizePhoneNumber(phone)
                this.primaryPhoneDisplay.setAttribute('href', `https://wa.me/${normalized}`)
                this.primaryPhoneDisplay.classList.add('text-decoration-underline')
            } else {
                this.primaryPhoneDisplay.removeAttribute('href')
                this.primaryPhoneDisplay.classList.remove('text-decoration-underline')
            }
        }

        if(this.primaryMobilePhoneDisplay) {
            const mobile = data.primary_mobile_phone
            this.primaryMobilePhoneDisplay.innerText = mobile ?? '-'
            if(mobile) {
                const normalized = this.helper.normalizePhoneNumber(mobile)
                this.primaryMobilePhoneDisplay.setAttribute('href', `https://wa.me/${normalized}`)
                this.primaryMobilePhoneDisplay.classList.add('text-decoration-underline')
            } else {
                this.primaryMobilePhoneDisplay.removeAttribute('href')
                this.primaryMobilePhoneDisplay.classList.remove('text-decoration-underline')
            }
        }

        if(this.accountSection) {
            this.accountSection.classList.toggle('d-none', !data.account)
        }

        if(this.companyName) {
            this.companyName.innerText = data.account?.name ?? '-'
        }

        if(this.accountLink) {
            this.accountLink.setAttribute('href', data.account?.id ? `/master-data/account/${data.account.id}` : '#')
        }

        this.updateAccountAvatar(data.account)

        if(this.accountTypeBadge) {
            this.accountTypeBadge.textContent = data.account?.type?.name ?? ''
            this.accountTypeBadge.classList.toggle('d-none', !data.account?.type)
        }

        if(this.accountIndustryBadge) {
            this.accountIndustryBadge.textContent = data.account?.industry?.name ?? ''
            this.accountIndustryBadge.classList.toggle('d-none', !data.account?.industry)
        }

        if(this.totalActivityDisplay) {
            this.totalActivityDisplay.textContent = data.total_activity
        }

        if(this.totalAddressDisplay) {
            this.totalAddressDisplay.textContent = data.total_address
        }

        if(this.totalCommunicationDisplay) {
            this.totalCommunicationDisplay.textContent = data.total_communication
        }
    }

    /**
     * @param {Object|null} account
     * @returns {void}
     */
    updateAccountAvatar(account) {
        if(!this.accountAvatar || !this.accountInitial) {
            return
        }

        if(account?.profile_picture_id) {
            this.accountAvatar.src = `${BASE_URL}/core/images/thumbnail/${account.profile_picture_id}`
            this.accountAvatar.classList.remove('d-none')
            this.accountInitial.classList.add('d-none')
        } else {
            this.accountAvatar.classList.add('d-none')
            this.accountInitial.classList.remove('d-none')
        }

        const initialSpan = this.accountInitial.querySelector('span')
        if(initialSpan) {
            initialSpan.textContent = this.helper.getInitialName(account?.name)
        }
    }

    /**
     * @param {Date|null} birthDate
     * @returns {number}
     */
    calculateAge(birthDate) {
        if(!birthDate) {
            return 0
        }

        const today = new Date()
        let age = today.getFullYear() - birthDate.getFullYear()
        if(today.getMonth() < birthDate.getMonth() || (today.getMonth() === birthDate.getMonth() && today.getDate() < birthDate.getDate())) {
            age--
        }

        return age
    }
}
