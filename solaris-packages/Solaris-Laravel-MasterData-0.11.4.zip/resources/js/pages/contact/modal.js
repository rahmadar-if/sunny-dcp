import SolarModalPage from "@core-js/solaris/solar/solar-modal-page";
import ProfilePicture from "@core-js/solaris/profile-picture";

export default class ContactModal extends SolarModalPage {
    constructor() {
        super("contact-modal")
    }

    init() {
        this.initForm()
    }

    initForm() {
        /** @type {ProfilePicture} */
        const profilePicture = this.get("contact-profile_picture")
        this.form.registerProfilePicture(profilePicture, (res) => `${BASE_URL}/master-data/contact/avatar/${res.data.id}`)
    }
}