import ActivityDetail from "../activity/detail";

export default class ContactActivityDetail extends ActivityDetail {
    init() {
        super.init()

        this.activityModal?.modal.on("show", () => {
            const form    = this.activityModal.form
            const contact = form.get('contact_id')
            const account = form.get('account_id')

            if(contact?.get().account) {
                account?.set(contact.get().account)
                account?.disabled()
            } else {
                account?.enabled()
            }
        }, "ContactActivityDetail")
    }
}