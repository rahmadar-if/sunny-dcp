import AccountAddressDetail from "../account/address-detail";

export default class ContactAddressDetail extends AccountAddressDetail {
    
}