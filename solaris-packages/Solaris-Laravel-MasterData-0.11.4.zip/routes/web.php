<?php

use Illuminate\Support\Facades\Route;
use Solaris\Core\Helpers\Helper;

Route::middleware(['auth', 'menu.access'])->group(function () {

    Route::prefix('master-data')->group(function () {
        Route::prefix('account')->group(function () {
            $accountController = Helper::controller('account');

            Route::get('/', [$accountController, 'index'])
                ->name('master-data.account');
            
            Route::get('/{id}', [$accountController, 'show'])
                ->whereUuid('id')
                ->name('master-data.account.read');
            
            Route::get('/edit/{id}', [$accountController, 'edit'])
                ->whereUuid('id')
                ->name('master-data.account.edit');

            Route::post('/avatar/{id}', [$accountController, 'updateAvatar'])
                ->whereUuid('id')
                ->name('master-data.account.update.avatar');
        });

        Route::prefix('contact')->group(function () {
            $contactController = Helper::controller('contact');

            Route::get('/', [$contactController, 'index'])
                ->name('master-data.contact');
            
            Route::get('/{id}', [$contactController, 'show'])
                ->whereUuid('id')
                ->name('master-data.contact.read');
            
            Route::get('/edit/{id}', [$contactController, 'edit'])
                ->whereUuid('id')
                ->name('master-data.contact.edit');
            
            Route::post('/avatar/{id}', [$contactController, 'updateAvatar'])
                ->whereUuid('id')
                ->name('master-data.contact.update.avatar');
        });

        Route::prefix('product')->group(function () {
            $productController = Helper::controller('product');

            Route::get('/', [$productController, 'index'])
                ->name('master-data.product');
            
            Route::get('/{id}', [$productController, 'show'])
                ->whereUuid('id')
                ->name('master-data.product.read');
            
            Route::get('/edit/{id}', [$productController, 'edit'])
                ->whereUuid('id')
                ->name('master-data.product.edit');

            Route::post('/avatar/{id}', [$productController, 'updateAvatar'])
                ->whereUuid('id')
                ->name('master-data.product.update.avatar');
        });

        Route::prefix('activity')->group(function () {
            $activityController = Helper::controller('activity');

            Route::get('/', [$activityController, 'index'])
                ->name('master-data.activity');
            
            Route::get('/{id}', [$activityController, 'show'])
                ->whereUuid('id')
                ->name('master-data.activity.read');
            
            Route::get('/edit/{id}', [$activityController, 'edit'])
                ->whereUuid('id')
                ->name('master-data.activity.edit');
            
            Route::post('/calendar', [$activityController, 'calendar'])
                ->name('master-data.activity.calendar');
        });

        Route::prefix('knowledge-base')->group(function () {
            $knowledgeBaseController = Helper::controller('knowledge_base');

            Route::get('/', [$knowledgeBaseController, 'index'])
                ->name('master-data.knowledge-base');
            
            Route::get('/{id}', [$knowledgeBaseController, 'show'])
                ->whereUuid('id')
                ->name('master-data.knowledge-base.read');
            
            Route::get('/edit/{id}', [$knowledgeBaseController, 'edit'])
                ->whereUuid('id')
                ->name('master-data.knowledge-base.edit');
        });

        Route::prefix('document')->group(function () {
            $documentController = Helper::controller('document');

            Route::get('/', [$documentController, 'index'])
                ->name('master-data.document');
            
            Route::get('/{id}', [$documentController, 'show'])
                ->whereUuid('id')
                ->name('master-data.document.read');
            
            Route::get('/edit/{id}', [$documentController, 'edit'])
                ->whereUuid('id')
                ->name('master-data.document.edit');
        });
    });
});