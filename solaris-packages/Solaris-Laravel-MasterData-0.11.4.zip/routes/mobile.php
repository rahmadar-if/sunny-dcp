<?php

use Illuminate\Support\Facades\Route;
use Solaris\Core\Helpers\Helper;

Route::prefix('mobile')->group(function () {
    Route::middleware('auth.mobile')->group(function () {
        Route::prefix('home')->group(function() {
            $controller = Helper::mobileController('home');
            Route::get('/all', [$controller, 'index'])
                ->name('mobile.home.all');

            Route::get('/today-activity', [$controller, 'todayActivity'])
                ->name('mobile.home.today-activity');
        });

        Route::prefix('master-data')->group(function() {
            Route::prefix('account')->group(function () {
                $controller = Helper::mobileController('account');
                
                Route::post('/', [$controller, 'store'])
                    ->name('mobile.master-data.account.store');

                Route::put('/{id}', [$controller, 'update'])
                    ->name('mobile.master-data.account.update');

                Route::post('/list', [$controller, 'index'])
                    ->name('mobile.master-data.account');
    
                Route::get('/{id}', [$controller, 'show'])
                    ->whereUuid('id')
                    ->name('mobile.master-data.account.read');

                Route::delete('/{id}', [$controller, 'destroy'])
                    ->whereUuid('id')
                    ->name('mobile.master-data.account.destroy');
    
                Route::post('/avatar/{id}', [$controller, 'updateAvatar'])
                    ->whereUuid('id')
                    ->name('mobile.master-data.account.update.avatar');

                Route::prefix('address')->group(function() {
                    $controller = Helper::mobileController('account_address');

                    Route::post('/', [$controller, 'store'])
                        ->name('mobile.master-data.account-address.store');

                    Route::put('/{id}', [$controller, 'update'])
                        ->name('mobile.master-data.account-address.update');

                    Route::post('/list', [$controller, 'index'])
                        ->name('mobile.master-data.account-address');
        
                    Route::get('/{id}', [$controller, 'show'])
                        ->whereUuid('id')
                        ->name('mobile.master-data.account-address.read');

                    Route::delete('/{id}', [$controller, 'destroy'])
                        ->whereUuid('id')
                        ->name('mobile.master-data.account-address.destroy');
                });
            });

            Route::prefix('contact')->group(function () {
                $controller = Helper::mobileController('contact');

                Route::post('/', [$controller, 'store'])
                    ->name('mobile.master-data.contact.store');

                Route::put('/{id}', [$controller, 'update'])
                    ->name('mobile.master-data.contact.update');

                Route::post('/list', [$controller, 'index'])
                    ->name('mobile.master-data.contact');

                Route::get('/{id}', [$controller, 'show'])
                    ->whereUuid('id')
                    ->name('mobile.master-data.contact.read');

                Route::delete('/{id}', [$controller, 'destroy'])
                    ->whereUuid('id')
                    ->name('mobile.master-data.contact.destroy');

                Route::post('/avatar/{id}', [$controller, 'updateAvatar'])
                    ->whereUuid('id')
                    ->name('mobile.master-data.contact.update.avatar');

                Route::prefix('address')->group(function () {
                    $controller = Helper::mobileController('contact_address');

                    Route::post('/', [$controller, 'store'])
                        ->name('mobile.master-data.contact-address.store');

                    Route::put('/{id}', [$controller, 'update'])
                        ->name('mobile.master-data.contact-address.update');

                    Route::post('/list', [$controller, 'index'])
                        ->name('mobile.master-data.contact-address');

                    Route::get('/{id}', [$controller, 'show'])
                        ->whereUuid('id')
                        ->name('mobile.master-data.contact-address.read');

                    Route::delete('/{id}', [$controller, 'destroy'])
                        ->whereUuid('id')
                        ->name('mobile.master-data.contact-address.destroy');
                });

                Route::prefix('communication')->group(function () {
                    $controller = Helper::mobileController('contact_communication');

                    Route::post('/', [$controller, 'store'])
                        ->name('mobile.master-data.contact-communication.store');

                    Route::put('/{id}', [$controller, 'update'])
                        ->name('mobile.master-data.contact-communication.update');

                    Route::post('/list', [$controller, 'index'])
                        ->name('mobile.master-data.contact-communication');

                    Route::get('/{id}', [$controller, 'show'])
                        ->whereUuid('id')
                        ->name('mobile.master-data.contact-communication.read');

                    Route::delete('/{id}', [$controller, 'destroy'])
                        ->whereUuid('id')
                        ->name('mobile.master-data.contact-communication.destroy');
                });

                Route::prefix('hobby')->group(function () {
                    $controller = Helper::mobileController('contact_hobby');

                    Route::post('/', [$controller, 'store'])
                        ->name('mobile.master-data.contact-hobby.store');

                    Route::put('/{id}', [$controller, 'update'])
                        ->name('mobile.master-data.contact-hobby.update');

                    Route::post('/list', [$controller, 'index'])
                        ->name('mobile.master-data.contact-hobby');

                    Route::get('/{id}', [$controller, 'show'])
                        ->whereUuid('id')
                        ->name('mobile.master-data.contact-hobby.read');

                    Route::delete('/{id}', [$controller, 'destroy'])
                        ->whereUuid('id')
                        ->name('mobile.master-data.contact-hobby.destroy');
                });

                Route::prefix('related-contact')->group(function () {
                    $controller = Helper::mobileController('related_contact');

                    Route::post('/', [$controller, 'store'])
                        ->name('mobile.master-data.related-contact.store');

                    Route::put('/{id}', [$controller, 'update'])
                        ->name('mobile.master-data.related-contact.update');

                    Route::post('/list', [$controller, 'index'])
                        ->name('mobile.master-data.related-contact');

                    Route::get('/{id}', [$controller, 'show'])
                        ->whereUuid('id')
                        ->name('mobile.master-data.related-contact.read');

                    Route::delete('/{id}', [$controller, 'destroy'])
                        ->whereUuid('id')
                        ->name('mobile.master-data.related-contact.destroy');
                });
            });

            Route::prefix('product')->group(function () {
                $controller = Helper::mobileController('product');

                Route::post('/', [$controller, 'store'])
                    ->name('mobile.master-data.product.store');

                Route::put('/{id}', [$controller, 'update'])
                    ->name('mobile.master-data.product.update');

                Route::post('/list', [$controller, 'index'])
                    ->name('mobile.master-data.product');

                Route::get('/{id}', [$controller, 'show'])
                    ->whereUuid('id')
                    ->name('mobile.master-data.product.read');

                Route::delete('/{id}', [$controller, 'destroy'])
                    ->whereUuid('id')
                    ->name('mobile.master-data.product.destroy');

                Route::post('/avatar/{id}', [$controller, 'updateAvatar'])
                    ->whereUuid('id')
                    ->name('mobile.master-data.product.update.avatar');

                Route::prefix('feature')->group(function () {
                    $controller = Helper::mobileController('product_feature');

                    Route::post('/', [$controller, 'store'])
                        ->name('mobile.master-data.product-feature.store');

                    Route::put('/{id}', [$controller, 'update'])
                        ->name('mobile.master-data.product-feature.update');

                    Route::post('/list', [$controller, 'index'])
                        ->name('mobile.master-data.product-feature');

                    Route::get('/{id}', [$controller, 'show'])
                        ->whereUuid('id')
                        ->name('mobile.master-data.product-feature.read');

                    Route::delete('/{id}', [$controller, 'destroy'])
                        ->whereUuid('id')
                        ->name('mobile.master-data.product-feature.destroy');
                });

                Route::prefix('availability')->group(function () {
                    $controller = Helper::mobileController('product_availability');

                    Route::post('/', [$controller, 'store'])
                        ->name('mobile.master-data.product-availability.store');

                    Route::put('/{id}', [$controller, 'update'])
                        ->name('mobile.master-data.product-availability.update');

                    Route::post('/list', [$controller, 'index'])
                        ->name('mobile.master-data.product-availability');

                    Route::get('/{id}', [$controller, 'show'])
                        ->whereUuid('id')
                        ->name('mobile.master-data.product-availability.read');

                    Route::delete('/{id}', [$controller, 'destroy'])
                        ->whereUuid('id')
                        ->name('mobile.master-data.product-availability.destroy');
                });

                Route::prefix('price-history')->group(function () {
                    $controller = Helper::mobileController('product_price_history');

                    Route::post('/list', [$controller, 'index'])
                        ->name('mobile.master-data.product-price-history');

                    Route::get('/{id}', [$controller, 'show'])
                        ->whereUuid('id')
                        ->name('mobile.master-data.product-price-history.read');
                });
            });

            Route::prefix('activity')->group(function () {
                $controller = Helper::mobileController('activity');
                
                Route::post('/', [$controller, 'store'])
                    ->name('mobile.master-data.activity.store');

                Route::put('/{id}', [$controller, 'update'])
                    ->name('mobile.master-data.activity.update');

                Route::post('/list', [$controller, 'index'])
                    ->name('mobile.master-data.activity');
    
                Route::get('/{id}', [$controller, 'show'])
                    ->whereUuid('id')
                    ->name('mobile.master-data.activity.read');

                Route::delete('/{id}', [$controller, 'destroy'])
                    ->whereUuid('id')
                    ->name('mobile.master-data.activity.destroy');

                Route::post('/calendar', [$controller, 'calendar'])
                    ->name('mobile.master-data.activity.calendar');
            });

            Route::prefix('knownledge-base')->group(function () {});

            Route::prefix('document')->group(function () {});
        });
    });
});