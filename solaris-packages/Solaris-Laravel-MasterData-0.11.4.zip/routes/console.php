<?php

use Illuminate\Support\Facades\Schedule;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Jobs\ReminderNotification;

$timezone = Helper::config('scheduler_timezone', 'UTC');

Schedule::job(new ReminderNotification())->everyMinute()->timezone($timezone);