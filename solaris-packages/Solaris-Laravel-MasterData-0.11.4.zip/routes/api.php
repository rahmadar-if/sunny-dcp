<?php

use Illuminate\Support\Facades\Route;
use Solaris\Core\Helpers\Helper;

Route::prefix('v1')
    ->middleware(['api.log', 'auth.api_key', 'throttle:api_key'])
    ->group(function () {
        Route::prefix('accounts')->group(function () {
            $controller = Helper::apiController('account');

            Route::get('/', [$controller, 'index'])
                ->middleware('permission:api.account.view')
                ->name('api.v1.account.index');

            Route::post('/search', [$controller, 'search'])
                ->middleware('permission:api.account.view')
                ->name('api.v1.account.search');

            Route::post('/', [$controller, 'store'])
                ->middleware(['permission:api.account.create', 'api.idempotency'])
                ->name('api.v1.account.store');

            Route::get('/{id}', [$controller, 'show'])
                ->whereUuid('id')
                ->middleware('permission:api.account.view')
                ->name('api.v1.account.show');

            Route::patch('/{id}', [$controller, 'update'])
                ->whereUuid('id')
                ->middleware('permission:api.account.update')
                ->name('api.v1.account.update');

            Route::put('/{id}', [$controller, 'replace'])
                ->whereUuid('id')
                ->middleware('permission:api.account.update')
                ->name('api.v1.account.replace');

            Route::delete('/{id}', [$controller, 'destroy'])
                ->whereUuid('id')
                ->middleware('permission:api.account.delete')
                ->name('api.v1.account.destroy');
        });

        Route::prefix('contacts')->group(function () {
            $controller = Helper::apiController('contact');

            Route::get('/', [$controller, 'index'])
                ->middleware('permission:api.contact.view')
                ->name('api.v1.contact.index');

            Route::post('/search', [$controller, 'search'])
                ->middleware('permission:api.contact.view')
                ->name('api.v1.contact.search');

            Route::post('/', [$controller, 'store'])
                ->middleware(['permission:api.contact.create', 'api.idempotency'])
                ->name('api.v1.contact.store');

            Route::get('/{id}', [$controller, 'show'])
                ->whereUuid('id')
                ->middleware('permission:api.contact.view')
                ->name('api.v1.contact.show');

            Route::patch('/{id}', [$controller, 'update'])
                ->whereUuid('id')
                ->middleware('permission:api.contact.update')
                ->name('api.v1.contact.update');

            Route::put('/{id}', [$controller, 'replace'])
                ->whereUuid('id')
                ->middleware('permission:api.contact.update')
                ->name('api.v1.contact.replace');

            Route::delete('/{id}', [$controller, 'destroy'])
                ->whereUuid('id')
                ->middleware('permission:api.contact.delete')
                ->name('api.v1.contact.destroy');
        });

        Route::prefix('activities')->group(function () {
            $controller = Helper::apiController('activity');

            Route::get('/', [$controller, 'index'])
                ->middleware('permission:api.activity.view')
                ->name('api.v1.activity.index');

            Route::post('/search', [$controller, 'search'])
                ->middleware('permission:api.activity.view')
                ->name('api.v1.activity.search');

            Route::post('/', [$controller, 'store'])
                ->middleware(['permission:api.activity.create', 'api.idempotency'])
                ->name('api.v1.activity.store');

            Route::get('/{id}', [$controller, 'show'])
                ->whereUuid('id')
                ->middleware('permission:api.activity.view')
                ->name('api.v1.activity.show');

            Route::patch('/{id}', [$controller, 'update'])
                ->whereUuid('id')
                ->middleware('permission:api.activity.update')
                ->name('api.v1.activity.update');

            Route::put('/{id}', [$controller, 'replace'])
                ->whereUuid('id')
                ->middleware('permission:api.activity.update')
                ->name('api.v1.activity.replace');

            Route::delete('/{id}', [$controller, 'destroy'])
                ->whereUuid('id')
                ->middleware('permission:api.activity.delete')
                ->name('api.v1.activity.destroy');
        });

        Route::prefix('products')->group(function () {
            $controller = Helper::apiController('product');

            Route::get('/', [$controller, 'index'])
                ->middleware('permission:api.product.view')
                ->name('api.v1.product.index');

            Route::post('/search', [$controller, 'search'])
                ->middleware('permission:api.product.view')
                ->name('api.v1.product.search');

            Route::post('/', [$controller, 'store'])
                ->middleware(['permission:api.product.create', 'api.idempotency'])
                ->name('api.v1.product.store');

            Route::get('/{id}', [$controller, 'show'])
                ->whereUuid('id')
                ->middleware('permission:api.product.view')
                ->name('api.v1.product.show');

            Route::patch('/{id}', [$controller, 'update'])
                ->whereUuid('id')
                ->middleware('permission:api.product.update')
                ->name('api.v1.product.update');

            Route::put('/{id}', [$controller, 'replace'])
                ->whereUuid('id')
                ->middleware('permission:api.product.update')
                ->name('api.v1.product.replace');

            Route::delete('/{id}', [$controller, 'destroy'])
                ->whereUuid('id')
                ->middleware('permission:api.product.delete')
                ->name('api.v1.product.destroy');
        });
    });
