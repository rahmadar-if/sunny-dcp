<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Helper;

return new class extends Migration
{
    private const FULLTEXT = [
        'knowledge_bases' => ['name', 'article_plain'],
        'documents'       => ['notes_plain'],
    ];

    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (config('database.default') !== 'pgsql') {
            return;
        }

        foreach (self::FULLTEXT as $table => $columns) {
            Schema::table($table, function (Blueprint $t) use ($columns) {
                $t->fullText($columns)->language(Helper::fullTextLanguage());
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (config('database.default') !== 'pgsql') {
            return;
        }

        foreach (self::FULLTEXT as $table => $columns) {
            Schema::table($table, function (Blueprint $t) use ($columns) {
                $t->dropFullText($columns);
            });
        }
    }
};
