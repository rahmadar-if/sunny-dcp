<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('product_types', function(Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('products', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('name')->nullable();
            $table->decimal('availability', 10, 2)->default(0);
            $table->string('sku_number')->nullable();
            $table->boolean('active')->default(false);
            $table->string('category')->nullable();
            $table->string('brand')->nullable();
            $table->decimal('price', 19, 2)->default(0);
            $table->string('unit_of_measure')->nullable();
            $table->text('notes')->nullable();
            $table->string('product_description')->nullable();

            $table->foreignUuid('product_picture_id')->nullable()->constrained('attachments')->nullOnDelete();
            $table->foreignUuid('type_id')->nullable()->constrained('product_types')->nullOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['product_picture_id']);
            MigrationHelper::createIndexIfNeeds($table, ['type_id']);
        });

        Schema::create('product_features', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('name')->nullable();
            $table->text('notes')->nullable();
            $table->foreignUuid('product_id')->nullable()->constrained('products')->cascadeOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['product_id']);
        });

        Schema::create('product_availabilities', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('warehouse')->nullable();
            $table->string('address')->nullable();
            $table->unsignedInteger('qty')->default(0);
            $table->string('post_code')->nullable();
            $table->foreignUuid('product_id')->nullable()->constrained('products')->cascadeOnDelete();
            $table->foreignUuid('country_id')->nullable()->constrained('countries')->nullOnDelete();
            $table->foreignUuid('province_id')->nullable()->constrained('provincies')->nullOnDelete();
            $table->foreignUuid('city_id')->nullable()->constrained('cities')->nullOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['product_id']);
            MigrationHelper::createIndexIfNeeds($table, ['country_id']);
            MigrationHelper::createIndexIfNeeds($table, ['province_id']);
            MigrationHelper::createIndexIfNeeds($table, ['city_id']);
        });

        Schema::create('product_price_histories', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->decimal('price', 19, 2)->default(0);
            $table->dateTime('from');
            $table->dateTime('end')->nullable();

            $table->foreignUuid('product_id')->nullable()->constrained('products')->cascadeOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['product_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('product_price_histories');
        Schema::dropIfExists('product_features');
        Schema::dropIfExists('product_availabilities');
        Schema::dropIfExists('products');
        Schema::dropIfExists('product_types');
    }
};
