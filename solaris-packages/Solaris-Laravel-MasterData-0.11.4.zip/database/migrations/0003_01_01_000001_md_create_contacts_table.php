<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('preferred_languages', function (Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('marital_statuses', function (Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('educations', function (Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('contacts', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('name')->nullable();
            $table->string('also_known_as')->nullable();
            $table->string('degree')->nullable();
            $table->string('primary_phone', 50)->nullable();
            $table->string('primary_mobile_phone', 50)->nullable();
            $table->string('email')->nullable();
            $table->string('job_title')->nullable();
            $table->date('birth_date')->nullable();
            $table->text('notes')->nullable();
            $table->text('recipients_name')->nullable();

            $table->foreignUuid('profile_picture_id')->nullable()->constrained('attachments')->nullOnDelete();
            $table->foreignUuid('account_id')->nullable()->constrained('accounts')->nullOnDelete();
            $table->foreignUuid('gender_id')->nullable()->constrained('genders')->nullOnDelete();
            $table->foreignUuid('religion_id')->nullable()->constrained('religions')->nullOnDelete();
            $table->foreignUuid('preferred_language_id')->nullable()->constrained('preferred_languages')->nullOnDelete();
            $table->foreignUuid('marital_status_id')->nullable()->constrained('marital_statuses')->nullOnDelete();
            $table->foreignUuid('salutation_id')->nullable()->constrained('salutations')->nullOnDelete();
            $table->foreignUuid('education_id')->nullable()->constrained('educations')->nullOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['profile_picture_id']);
            MigrationHelper::createIndexIfNeeds($table, ['account_id']);
            MigrationHelper::createIndexIfNeeds($table, ['gender_id']);
            MigrationHelper::createIndexIfNeeds($table, ['religion_id']);
            MigrationHelper::createIndexIfNeeds($table, ['preferred_language_id']);
            MigrationHelper::createIndexIfNeeds($table, ['marital_status_id']);
            MigrationHelper::createIndexIfNeeds($table, ['salutation_id']);
            MigrationHelper::createIndexIfNeeds($table, ['education_id']);
        });

        Schema::table('accounts', function (Blueprint $table) {
            $table->foreignUuid('primary_contact_id')->nullable()->constrained('contacts')->nullOnDelete();
            MigrationHelper::createIndexIfNeeds($table, ['primary_contact_id']);
        });

        Schema::create('contact_addresses', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->text('address')->nullable();
            $table->string('postcode')->nullable();

            $table->foreignUuid('contact_id')->nullable()->constrained('contacts')->cascadeOnDelete();
            $table->foreignUuid('address_type_id')->nullable()->constrained('address_types')->nullOnDelete();
            $table->foreignUuid('country_id')->nullable()->constrained('countries')->nullOnDelete();
            $table->foreignUuid('province_id')->nullable()->constrained('provincies')->nullOnDelete();
            $table->foreignUuid('city_id')->nullable()->constrained('cities')->nullOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['contact_id']);
            MigrationHelper::createIndexIfNeeds($table, ['address_type_id']);
            MigrationHelper::createIndexIfNeeds($table, ['country_id']);
            MigrationHelper::createIndexIfNeeds($table, ['province_id']);
            MigrationHelper::createIndexIfNeeds($table, ['city_id']);
        });

        Schema::create('communication_types', function(Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('contact_communications', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('value')->nullable();

            $table->foreignUuid('contact_id')->nullable()->constrained('contacts')->cascadeOnDelete();
            $table->foreignUuid('type_id')->nullable()->constrained('communication_types')->nullOnDelete();
            
            MigrationHelper::createIndexIfNeeds($table, ['contact_id']);
            MigrationHelper::createIndexIfNeeds($table, ['type_id']);
        });

        Schema::create('contact_hobbies', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('hobby')->nullable();
            $table->foreignUuid('contact_id')->nullable()->constrained('contacts')->cascadeOnDelete();
            
            MigrationHelper::createIndexIfNeeds($table, ['contact_id']);
        });

        Schema::create('related_contact_categories', function(Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('related_contacts', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->foreignUuid('contact_id')->nullable()->constrained('contacts')->cascadeOnDelete();
            $table->foreignUuid('related_contact_id')->nullable()->constrained('contacts')->nullOnDelete();
            $table->foreignUuid('category_id')->nullable()->constrained('related_contact_categories')->nullOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['contact_id']);
            MigrationHelper::createIndexIfNeeds($table, ['related_contact_id']);
            MigrationHelper::createIndexIfNeeds($table, ['category_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('related_contacts');
        Schema::dropIfExists('related_contact_categories');
        Schema::dropIfExists('contact_hobbies');
        Schema::dropIfExists('contact_communications');
        Schema::dropIfExists('communication_types');
        Schema::dropIfExists('contact_addresses');

        Schema::table('accounts', function (Blueprint $table) {
            $table->dropForeign(['primary_contact_id']);

            MigrationHelper::dropIndexIfNeeds($table, ['primary_contact_id']);

            $table->dropColumn('primary_contact_id');
        });

        Schema::dropIfExists('contacts');
        Schema::dropIfExists('preferred_languages');
        Schema::dropIfExists('marital_statuses');
        Schema::dropIfExists('educations');
    }
};
