<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    private const WYSIWYG = [
        'accounts'        => ['notes'],
        'contacts'        => ['notes'],
        'activities'      => ['notes'],
        'documents'       => ['notes'],
        'knowledge_bases' => ['article'],
    ];

    public function up(): void
    {
        foreach (self::WYSIWYG as $table => $columns) {
            Schema::table($table, function (Blueprint $t) use ($columns) {
                foreach ($columns as $column) {
                    $t->text("{$column}_plain")->nullable()->after($column);
                }
            });
        }
    }

    public function down(): void
    {
        foreach (self::WYSIWYG as $table => $columns) {
            Schema::table($table, function (Blueprint $t) use ($columns) {
                foreach ($columns as $column) {
                    $t->dropColumn("{$column}_plain");
                }
            });
        }
    }
};
