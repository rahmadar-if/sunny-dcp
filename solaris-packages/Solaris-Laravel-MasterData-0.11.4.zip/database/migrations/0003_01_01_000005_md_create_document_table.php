<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('document_statuses', function(Blueprint $table) {
            MigrationHelper::baseLookupStage($table);
        });

        Schema::create('document_types', function(Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('documents', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('number')->nullable();
            $table->date('date')->nullable();
            $table->text('notes')->nullable();

            $table->foreignUuid('account_id')->nullable()->constrained('accounts')->nullOnDelete();
            $table->foreignUuid('contact_id')->nullable()->constrained('contacts')->nullOnDelete();
            $table->foreignUuid('status_id')->nullable()->constrained('document_statuses')->nullOnDelete();
            $table->foreignUuid('type_id')->nullable()->constrained('document_types')->nullOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['account_id']);
            MigrationHelper::createIndexIfNeeds($table, ['contact_id']);
            MigrationHelper::createIndexIfNeeds($table, ['status_id']);
            MigrationHelper::createIndexIfNeeds($table, ['type_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('documents');
        Schema::dropIfExists('document_types');
        Schema::dropIfExists('document_statuses');
    }
};
