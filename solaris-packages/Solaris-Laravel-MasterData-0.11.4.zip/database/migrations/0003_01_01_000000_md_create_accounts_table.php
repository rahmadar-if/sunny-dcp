<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('account_types', function(Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('number_of_employees', function(Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('business_entities', function(Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('industries', function(Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('accounts', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('name')->nullable();
            $table->string('website')->nullable();
            $table->string('email')->nullable();
            $table->string('primary_phone', 50)->nullable();
            $table->string('also_known_as')->nullable();
            $table->string('category')->nullable();
            $table->text('notes')->nullable();

            $table->foreignUuid('profile_picture_id')->nullable()->constrained('attachments')->nullOnDelete();
            $table->foreignUuid('type_id')->nullable()->constrained('account_types')->nullOnDelete();
            $table->foreignUuid('number_of_employee_id')->nullable()->constrained('number_of_employees')->nullOnDelete();
            $table->foreignUuid('business_entity_id')->nullable()->constrained('business_entities')->nullOnDelete();
            $table->foreignUuid('industry_id')->nullable()->constrained('industries')->nullOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['profile_picture_id']);
            MigrationHelper::createIndexIfNeeds($table, ['type_id']);
            MigrationHelper::createIndexIfNeeds($table, ['number_of_employee_id']);
            MigrationHelper::createIndexIfNeeds($table, ['business_entity_id']);
            MigrationHelper::createIndexIfNeeds($table, ['industry_id']);
        });

        Schema::create('address_types', function(Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('account_addresses', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->text('address')->nullable();
            $table->string('postcode')->nullable();

            $table->foreignUuid('account_id')->nullable()->constrained('accounts')->cascadeOnDelete();
            $table->foreignUuid('address_type_id')->nullable()->constrained('address_types')->nullOnDelete();
            $table->foreignUuid('country_id')->nullable()->constrained('countries')->nullOnDelete();
            $table->foreignUuid('province_id')->nullable()->constrained('provincies')->nullOnDelete();
            $table->foreignUuid('city_id')->nullable()->constrained('cities')->nullOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['account_id']);
            MigrationHelper::createIndexIfNeeds($table, ['address_type_id']);
            MigrationHelper::createIndexIfNeeds($table, ['country_id']);
            MigrationHelper::createIndexIfNeeds($table, ['province_id']);
            MigrationHelper::createIndexIfNeeds($table, ['city_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('account_addresses');
        Schema::dropIfExists('accounts');
        Schema::dropIfExists('number_of_employees');
        Schema::dropIfExists('business_entities');
        Schema::dropIfExists('industries');
        Schema::dropIfExists('account_types');
        Schema::dropIfExists('address_types');
    }
};
