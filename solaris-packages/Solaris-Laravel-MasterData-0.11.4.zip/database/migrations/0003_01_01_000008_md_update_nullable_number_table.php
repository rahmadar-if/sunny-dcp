<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('products', function (Blueprint $table) {
            $table->decimal('availability', 10, 2)
                ->nullable()
                ->default(null)
                ->change();

            $table->decimal('price', 19, 2)
                ->nullable()
                ->default(null)
                ->change();
        });

        Schema::table('product_availabilities', function (Blueprint $table) {
            $table->unsignedInteger('qty')
                ->nullable()
                ->default(null)
                ->change();
        });

        Schema::table('product_price_histories', function (Blueprint $table) {
            $table->decimal('price', 19, 2)
                ->nullable()
                ->default(null)
                ->change();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('product_price_histories', function (Blueprint $table) {
            $table->decimal('price', 19, 2)
                ->default(0)
                ->nullable(false)
                ->change();
        });

        Schema::table('product_availabilities', function (Blueprint $table) {
            $table->unsignedInteger('qty')
                ->default(0)
                ->nullable(false)
                ->change();
        });

        Schema::table('products', function (Blueprint $table) {
            $table->decimal('availability', 10, 2)
                ->default(0)
                ->nullable(false)
                ->change();

            $table->decimal('price', 19, 2)
                ->default(0)
                ->nullable(false)
                ->change();
        });
    }
};
