<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('activity_reminders', function (Blueprint $table) {
            $table->dropForeign(['type']);
            MigrationHelper::dropIndexIfNeeds($table, ['type']);
            $table->dropColumn('type');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('activity_reminders', function (Blueprint $table) {
            $table->foreignUuid('type')->nullable()->constrained('reminder_types')->nullOnDelete();
            MigrationHelper::createIndexIfNeeds($table, ['type']);
        });
    }
};
