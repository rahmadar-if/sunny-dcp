<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('knowledge_base_statuses', function(Blueprint $table) {
            MigrationHelper::baseLookupStage($table);
        });

        Schema::create('knowledge_base_types', function(Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('knowledge_bases', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('name')->nullable();
            $table->text('article')->nullable();
            $table->foreignUuid('status_id')->nullable()->constrained('knowledge_base_statuses')->nullOnDelete();
            $table->foreignUuid('type_id')->nullable()->constrained('knowledge_base_types')->nullOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['status_id']);
            MigrationHelper::createIndexIfNeeds($table, ['type_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('knowledge_bases');
        Schema::dropIfExists('knowledge_base_statuses');
        Schema::dropIfExists('knowledge_base_types');
    }
};
