<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('activity_priorities', function (Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('activity_categories', function (Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('activity_statuses', function (Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('activities', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('subject')->nullable();
            $table->dateTime('start_date')->nullable();
            $table->dateTime('end_date')->nullable();
            $table->text('notes')->nullable();

            $table->foreignUuid('account_id')->nullable()->constrained('accounts')->nullOnDelete();
            $table->foreignUuid('contact_id')->nullable()->constrained('contacts')->nullOnDelete();
            $table->foreignUuid('priority_id')->nullable()->constrained('activity_priorities')->nullOnDelete();
            $table->foreignUuid('category_id')->nullable()->constrained('activity_categories')->nullOnDelete();
            $table->foreignUuid('status_id')->nullable()->constrained('activity_statuses')->nullOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['account_id']);
            MigrationHelper::createIndexIfNeeds($table, ['contact_id']);
            MigrationHelper::createIndexIfNeeds($table, ['priority_id']);
            MigrationHelper::createIndexIfNeeds($table, ['category_id']);
            MigrationHelper::createIndexIfNeeds($table, ['status_id']);
        });

        Schema::create('reminder_types', function(Blueprint $table) {
            MigrationHelper::baseLookup($table);
            
            $table->integer('value')->default(0);
        });

        Schema::create('activity_reminders', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->foreignUuid('to_id')->nullable()->constrained('users')->cascadeOnDelete();
            $table->foreignUuid('type')->nullable()->constrained('reminder_types')->nullOnDelete();
            $table->foreignUuid('activity_id')->nullable()->constrained('activities')->cascadeOnDelete();

            $table->boolean('is_fail')->default(false);
            $table->boolean('is_remind')->default(false);
            $table->dateTime('remind_at')->nullable();

            $table->foreignUuid('type_id')->nullable()->constrained('reminder_types')->nullOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['to_id']);
            MigrationHelper::createIndexIfNeeds($table, ['type']);
            MigrationHelper::createIndexIfNeeds($table, ['activity_id']);
            MigrationHelper::createIndexIfNeeds($table, ['type_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('activity_reminders');
        Schema::dropIfExists('reminder_types');
        Schema::dropIfExists('activities');
        Schema::dropIfExists('activity_priorities');
        Schema::dropIfExists('activity_categories');
        Schema::dropIfExists('activity_statuses');
    }
};
