<?php

namespace Solaris\MasterData\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Solaris\MasterData\Const\CommunicationTypeConst;
use Solaris\MasterData\Const\EducationConst;
use Solaris\MasterData\Const\MaritalStatusConst;
use Solaris\MasterData\Const\PreferredLanguageConst;
use Solaris\MasterData\Const\RelatedContactCategoryConst;

class ContactSeeder extends Seeder
{
    public function run(): void
    {
        $this->preferred_languages();
        $this->marital_statuses();
        $this->educations();
        $this->communication_types();
        $this->related_contact_categories();
    }

    protected function preferred_languages(): void
    {
       $data = [
            [
                'id'        => PreferredLanguageConst::English,
                'name'      => 'English',
                'position'  => 1
            ],
            [
                'id'        => PreferredLanguageConst::BahasaIndonesia,
                'name'      => 'Bahasa Indonesia',
                'position'  => 2
            ]
        ];
        DB::table('preferred_languages')->insertOrIgnore($data);
    }

    protected function marital_statuses(): void
    {
        $data = [
            [
                'id'        => MaritalStatusConst::Single,
                'name'      => 'Single',
                'position'  => 1
            ],
            [
                'id'        => MaritalStatusConst::Married,
                'name'      => 'Married',
                'position'  => 2
            ]
        ];
        DB::table('marital_statuses')->insertOrIgnore($data);
    }

    protected function educations(): void
    {
        $data = [
            [
                'id'        => EducationConst::SMA_SMK,
                'name'      => 'SMA/SMK',
                'position'  => 1
            ],
            [
                'id'        => EducationConst::D3,
                'name'      => 'D3',
                'position'  => 2
            ],
            [
                'id'        => EducationConst::D4,
                'name'      => 'D4',
                'position'  => 3
            ],
            [
                'id'        => EducationConst::S1,
                'name'      => 'S1',
                'position'  => 4
            ],
            [
                'id'        => EducationConst::S2,
                'name'      => 'S2',
                'position'  => 5
            ],
            [
                'id'        => EducationConst::S3,
                'name'      => 'S3',
                'position'  => 6
            ],
            [
                'id'        => EducationConst::Others,
                'name'      => 'Others',
                'position'  => 7
            ]
        ];
        DB::table('educations')->insertOrIgnore($data);
    }

    protected function communication_types(): void
    {
        $data = [
            [
                'id' => CommunicationTypeConst::PhoneNumber,
                'name' => "Phone Number",
                'position' => 1
            ],
            [
                'id' => CommunicationTypeConst::MobileNumber,
                'name' => "Mobile Number",
                'position' => 2
            ],
            [
                'id' => CommunicationTypeConst::Email,
                'name' => "Email",
                'position' => 3
            ],
            [
                'id' => CommunicationTypeConst::Website,
                'name' => "Website",
                'position' => 4
            ],
            [
                'id' => CommunicationTypeConst::Instagram,
                'name' => "Instagram",
                'position' => 5
            ],
            [
                'id' => CommunicationTypeConst::Facebook,
                'name' => "Facebook",
                'position' => 6
            ],
            [
                'id' => CommunicationTypeConst::Youtube,
                'name' => "Youtube",
                'position' => 7
            ],
            [
                'id' => CommunicationTypeConst::LinkdedIn,
                'name' => "LinkdedIn",
                'position' => 8
            ],
            [
                'id' => CommunicationTypeConst::Twitter,
                'name' => "X (Twitter)",
                'position' => 9
            ],
            [
                'id' => CommunicationTypeConst::Fax,
                'name' => "Fax",
                'position' => 10
            ]
        ];
        DB::table('communication_types')->insertOrIgnore($data);
    }

    protected function related_contact_categories(): void
    {
        $data = [
            [
                'id' => RelatedContactCategoryConst::Spouse,
                'name' => "Spouse",
                'position' => 1
            ],
            [
                'id' => RelatedContactCategoryConst::Child,
                'name' => "Child",
                'position' => 2
            ],
            [
                'id' => RelatedContactCategoryConst::Friend,
                'name' => "Friend",
                'position' => 3
            ]
        ];
        DB::table('related_contact_categories')->insertOrIgnore($data);
    }
}