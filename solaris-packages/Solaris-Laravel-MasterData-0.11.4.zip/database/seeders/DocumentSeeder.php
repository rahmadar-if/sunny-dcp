<?php

namespace Solaris\MasterData\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Solaris\MasterData\Const\DocumentStatusConst;
use Solaris\MasterData\Const\DocumentTypeConst;

class DocumentSeeder extends Seeder
{
    public function run(): void
    {
        $this->document_statuses();
        $this->document_types();
    }

    protected function document_statuses(): void
    {
       $data = [
            [
                'id'                => DocumentStatusConst::Draft,
                'name'              => 'Draft',
                'color'             => 'primary',
                'position'          => 1,
                "group_id"          => null,
                'is_final_stage'    => false
            ],
            [
                'id'                => DocumentStatusConst::Final,
                'name'              => 'Final',
                'color'             => 'success',
                'position'          => 2,
                "group_id"          => null,
                'is_final_stage'    => true
            ],
            [
                'id'                => DocumentStatusConst::Inactive,
                'name'              => 'Inactive',
                'color'             => 'danger',
                'position'          => 3,
                "group_id"          => DocumentStatusConst::Final,
                'is_final_stage'    => true
            ],
        ];
        DB::table('document_statuses')->insertOrIgnore($data);
    }

    protected function document_types(): void
    {
       $data = [
            [
                'id'        => DocumentTypeConst::Regulation,
                'name'      => 'Regulation',
                'position'  => 1,
            ],
            [
                'id'        => DocumentTypeConst::Minutes,
                'name'      => 'Minutes',
                'position'  => 2,
            ],
            [
                'id'        => DocumentTypeConst::IncomingDocument,
                'name'      => 'Incoming Document',
                'position'  => 3,
            ]
        ];
        DB::table('document_types')->insertOrIgnore($data);
    }
}
