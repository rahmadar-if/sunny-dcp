<?php

namespace Solaris\MasterData\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Solaris\MasterData\Const\KnowledgeBaseStatusConst;
use Solaris\MasterData\Const\KnowledgeBaseTypeConst;

class KnowledgeBaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->knowledge_base_statuses();
        $this->knowledge_base_types();
    }

    protected function knowledge_base_statuses(): void
    {
       $data = [
            [
                'id'                => KnowledgeBaseStatusConst::Draft,
                'name'              => 'Draft',
                'position'          => 1,
                'color'             => 'primary',
                "group_id"          => null,
                'is_final_stage'    => false
            ],
            [
                'id'                => KnowledgeBaseStatusConst::Published,
                'name'              => 'Published',
                'position'          => 2,
                'color'             => 'success',
                "group_id"          => null,
                'is_final_stage'    => true
            ],

        ];
        DB::table('knowledge_base_statuses')->insertOrIgnore($data);
    }

    protected function knowledge_base_types(): void
    {
       $data = [
            [
                'id'        => KnowledgeBaseTypeConst::FAQ,
                'name'      => 'FAQ',
                'position'  => 1
            ],
            [
                'id'        => KnowledgeBaseTypeConst::Guide,
                'name'      => 'Guide',
                'position'  => 2
            ],
            [
                'id'        => KnowledgeBaseTypeConst::Documentation,
                'name'      => 'Documentation',
                'position'  => 3
            ]
        ];
        DB::table('knowledge_base_types')->insertOrIgnore($data);
    }
}
