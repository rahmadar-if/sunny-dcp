<?php

namespace Solaris\MasterData\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Solaris\MasterData\Const\AccountTypeConst;
use Solaris\MasterData\Const\AddressTypeConst;
use Solaris\MasterData\Const\BusinessEntityConst;
use Solaris\MasterData\Const\IndustryConst;
use Solaris\MasterData\Const\NumberOfEmployeeConst;

class AccountSeeder extends Seeder
{
    public function run(): void
    {
        $this->account_types();
        $this->number_of_employees();
        $this->business_entities();
        $this->industries();
        $this->address_types();
    }

    protected function account_types(): void
    {
       $data = [
            [
                'id'        => AccountTypeConst::Customer,
                'name'      => 'Customer',
                'position'  => 1
            ],
            [
                'id'        => AccountTypeConst::Partner,
                'name'      => 'Partner',
                'position'  => 2
            ],
            [
                'id'        => AccountTypeConst::Competitor,
                'name'      => 'Competitor',
                'position'  => 3
            ]
        ];
        DB::table('account_types')->insertOrIgnore($data);
    }

    protected function number_of_employees(): void
    {
        $data = [
            [
                'id'        => NumberOfEmployeeConst::OneTo100,
                'name'      => "1-100",
                'position'  => 1
            ],
            [
                'id'        => NumberOfEmployeeConst::HundredOneTo500,
                'name'      => "101-500",
                'position'  => 2
            ],
            [
                'id'        => NumberOfEmployeeConst::FiveHundredOneTo1000,
                'name'      => "501-1.000",
                'position'  => 3
            ],
            [
                'id'        => NumberOfEmployeeConst::ThousandOneTo5000,
                'name'      => "1.001-5.000",
                'position'  => 4
            ],
            [
                'id'        => NumberOfEmployeeConst::FiveThousandOneTo10000,
                'name'      => "5.001-10.000",
                'position'  => 5
            ],
            [
                'id'        => NumberOfEmployeeConst::MoreThan10000,
                'name'      => "> 10.000",
                'position'  => 6
            ],
        ];
        DB::table('number_of_employees')->insertOrIgnore($data);
    }

    protected function business_entities(): void
    {
        $data = [
            [
                'id'        => BusinessEntityConst::PT,
                'name'      => "PT",
                'position'  => 1,
            ],
            [
                'id'        => BusinessEntityConst::CV,
                'name'      => "CV",
                'position'  => 2,
            ],
            [
                'id'        => BusinessEntityConst::UD,
                'name'      => "UD",
                'position'  => 3,
            ],
            [
                'id'        => BusinessEntityConst::Others,
                'name'      => "Others",
                'position'  => 4,
            ]
        ];
        DB::table('business_entities')->insertOrIgnore($data);
    }

    protected function industries(): void
    {
        $data = [
            [
                'id'        => IndustryConst::Pharma,
                'name'      => "Pharma",
                'position'  => 1
            ],
            [
                'id'        => IndustryConst::Telco,
                'name'      => "Telco",
                'position'  => 2
            ],
            [
                'id'        => IndustryConst::Leasing,
                'name'      => "Leasing",
                'position'  => 3
            ],
            [
                'id'        => IndustryConst::Bank,
                'name'      => "Bank",
                'position'  => 4
            ],
            [
                'id'        => IndustryConst::ITTechnology,
                'name'      => "IT / Technology",
                'position'  => 5
            ],
            [
                'id'        => IndustryConst::Construction,
                'name'      => "Construction",
                'position'  => 6
            ],
            [
                'id'        => IndustryConst::Consulting,
                'name'      => "Consulting",
                'position'  => 7
            ],
            [
                'id'        => IndustryConst::Insurance,
                'name'      => "Insurance",
                'position'  => 8
            ],
            [
                'id'        => IndustryConst::FMCG,
                'name'      => "FMCG",
                'position'  => 9
            ],
            [
                'id'        => IndustryConst::Airlane,
                'name'      => "Airlane",
                'position'  => 10
            ],
            [
                'id'        => IndustryConst::FoodBeverages,
                'name'      => "Food & Beverages",
                'position'  => 11
            ],
            [
                'id'        => IndustryConst::Transportation,
                'name'      => "Transportation",
                'position'  => 12
            ],
            [
                'id'        => IndustryConst::Trading,
                'name'      => "Trading",
                'position'  => 13
            ],
            [
                'id'        => IndustryConst::FInancialServices,
                'name'      => "FInancial Services",
                'position'  => 14
            ],
            [
                'id'        => IndustryConst::Retail,
                'name'      => "Retail",
                'position'  => 15
            ],
            [
                'id'        => IndustryConst::FacilityBuilbindManagementServices,
                'name'      => "Facility & Builbind Management Services",
                'position'  => 16
            ],
            [
                'id'        => IndustryConst::PropertyConsultant,
                'name'      => "Property Consultant",
                'position'  => 17
            ],
            [
                'id'        => IndustryConst::Government,
                'name'      => "Government",
                'position'  => 18
            ],
            [
                'id'        => IndustryConst::MediaInformation,
                'name'      => "Media & Information",
                'position'  => 19
            ],
            [
                'id'        => IndustryConst::OilEnergy,
                'name'      => "Oil & Energy",
                'position'  => 20
            ],
            [
                'id'        => IndustryConst::Distribution,
                'name'      => "Distribution",
                'position'  => 21
            ],
            [
                'id'        => IndustryConst::Startup,
                'name'      => "Startup",
                'position'  => 22
            ],
            [
                'id'        => IndustryConst::Aviation,
                'name'      => "Aviation",
                'position'  => 23
            ],
            [
                'id'        => IndustryConst::Logistic,
                'name'      => "Logistic",
                'position'  => 24
            ],
            [
                'id'        => IndustryConst::CommunicationProvider,
                'name'      => "Communication Provider",
                'position'  => 25
            ],
            [
                'id'        => IndustryConst::MechanicalIndustrialEngineering,
                'name'      => "Mechanical / Industrial Engineering",
                'position'  => 26
            ],
            [
                'id'        => IndustryConst::Others,
                'name'      => "Others",
                'position'  => 27
            ]
        ];
        DB::table('industries')->insertOrIgnore($data);
    }

    protected function address_types(): void
    {
        $data = [
            [
                'id'        => AddressTypeConst::Home,
                'name'      => 'Home',
                'position'  => 1
            ],
            [
                'id'        => AddressTypeConst::Business,
                'name'      => 'Business',
                'position'  => 2
            ],
            [
                'id'        => AddressTypeConst::Shipping,
                'name'      => 'Shipping',
                'position'  => 3
            ],
            [
                'id'        => AddressTypeConst::Other,
                'name'      => 'Other',
                'position'  => 4
            ]
        ];
        DB::table('address_types')->insertOrIgnore($data);
    }
}
