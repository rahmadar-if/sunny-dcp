<?php

namespace Solaris\MasterData\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Solaris\MasterData\Const\ActivityCategoryConst;
use Solaris\MasterData\Const\ActivityPriorityConst;
use Solaris\MasterData\Const\ActivityStatusConst;
use Solaris\MasterData\Const\ReminderTypeConst;

class ActivitySeeder extends Seeder
{
    public function run(): void
    {
        $this->activity_priorities();
        $this->activity_categories();
        $this->activity_statuses();
        $this->reminder_types();
    }

    protected function activity_priorities(): void
    {
       $data = [
            [
                'id'        => ActivityPriorityConst::High,
                'name'      => 'High',
                'position'  => 1
            ],
            [
                'id'        => ActivityPriorityConst::Medium,
                'name'      => 'Medium',
                'position'  => 2
            ],
            [
                'id'        => ActivityPriorityConst::Low,
                'name'      => 'Low',
                'position'  => 3
            ]
        ];
        DB::table('activity_priorities')->insertOrIgnore($data);
    }

    protected function activity_categories(): void
    {
       $data = [
            [
                'id'        => ActivityCategoryConst::Call,
                'name'      => 'Call',
                'position'  => 1
            ],
            [
                'id'        => ActivityCategoryConst::Visit,
                'name'      => 'Visit',
                'position'  => 2
            ],
            [
                'id'        => ActivityCategoryConst::Meeting,
                'name'      => 'Meeting',
                'position'  => 3
            ],
            [
                'id'        => ActivityCategoryConst::Email,
                'name'      => 'Email',
                'position'  => 4
            ],
            [
                'id'        => ActivityCategoryConst::ToDo,
                'name'      => 'To Do',
                'position'  => 5
            ],
        ];
        DB::table('activity_categories')->insertOrIgnore($data);
    }

    protected function activity_statuses(): void
    {
       $data = [
            [
                'id'        => ActivityStatusConst::OnSchedule,
                'name'      => 'On-Schedule',
                'position'  => 1
            ],
            [
                'id'        => ActivityStatusConst::InProgress,
                'name'      => 'In-Progress',
                'position'  => 2
            ],
            [
                'id'        => ActivityStatusConst::Finish,
                'name'      => 'Finish',
                'position'  => 3
            ],

        ];
        DB::table('activity_statuses')->insertOrIgnore($data);
    }

    protected function reminder_types(): void
    {
       $data = [
            [
                'id'             => ReminderTypeConst::StartEvent,
                'name'           => 'When event start',
                'position'       => 1,
                'offset_minutes' => 0
            ],
            [
                'id'             => ReminderTypeConst::FifteenMinutes,
                'name'           => '15 minutes before the event',
                'position'       => 2,
                'offset_minutes' => 15
            ],
            [
                'id'             => ReminderTypeConst::ThirtyMinutes,
                'name'           => '30 minutes before the event',
                'position'       => 3,
                'offset_minutes' => 30
            ],
            [
                'id'             => ReminderTypeConst::OneHour,
                'name'           => '1 hour before the event',
                'position'       => 4,
                'offset_minutes' => 60
            ],
            [
                'id'             => ReminderTypeConst::OneDay,
                'name'           => '1 day before the event',
                'position'       => 5,
                'offset_minutes' => 1440
            ],
            
        ];
        DB::table('reminder_types')->insertOrIgnore($data);
    }
}
