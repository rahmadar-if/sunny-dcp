<?php

namespace Solaris\MasterData\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use Solaris\Core\Models\Permission;
use Solaris\Core\Models\Role;

// Without these rows the permission middleware rejects every call, so the API is unreachable
// until they exist. One role per entity — a partner integration is granted "API - Account" etc,
// not individual permissions one by one.
class ApiPermissionSeeder extends Seeder
{
    protected const GROUP = 'integration';

    public function run(): void
    {
        $this->seedEntity('API - Account', [
            'api.account.view'   => 'API — read accounts',
            'api.account.create' => 'API — create accounts',
            'api.account.update' => 'API — update accounts',
            'api.account.delete' => 'API — delete accounts',
        ]);

        $this->seedEntity('API - Contact', [
            'api.contact.view'   => 'API — read contacts',
            'api.contact.create' => 'API — create contacts',
            'api.contact.update' => 'API — update contacts',
            'api.contact.delete' => 'API — delete contacts',
        ]);

        $this->seedEntity('API - Activity', [
            'api.activity.view'   => 'API — read activities',
            'api.activity.create' => 'API — create activities',
            'api.activity.update' => 'API — update activities',
            'api.activity.delete' => 'API — delete activities',
        ]);

        $this->seedEntity('API - Product', [
            'api.product.view'   => 'API — read products',
            'api.product.create' => 'API — create products',
            'api.product.update' => 'API — update products',
            'api.product.delete' => 'API — delete products',
        ]);
    }

    protected function seedEntity(string $roleName, array $permissions): void
    {
        foreach ($permissions as $name => $description) {
            Permission::firstOrCreate(
                ['name' => $name],
                [
                    'id'          => (string) Str::uuid7(),
                    'group_name'  => self::GROUP,
                    'description' => $description,
                ]
            );
        }

        $role = Role::firstOrCreate(
            ['name' => $roleName],
            [
                'id'         => (string) Str::uuid7(),
                'group_name' => self::GROUP,
            ]
        );

        $role->assignPermission(array_keys($permissions));
    }
}
