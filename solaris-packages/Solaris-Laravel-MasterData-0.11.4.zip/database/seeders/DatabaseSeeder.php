<?php

namespace Solaris\MasterData\Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            AccountSeeder::class,
            ContactSeeder::class,
            ProductSeeder::class,
            ActivitySeeder::class,
            KnowledgeBaseSeeder::class,
            DocumentSeeder::class,
            MenuSeeder::class,
            ApiPermissionSeeder::class,
            CodeGeneratorSeeder::class,
            AiRegistrySeeder::class,
            AiScopedToolSeeder::class,
        ]);
    }
}