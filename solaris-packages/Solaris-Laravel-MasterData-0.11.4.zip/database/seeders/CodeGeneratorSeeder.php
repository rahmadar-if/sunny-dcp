<?php

namespace Solaris\MasterData\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CodeGeneratorSeeder extends Seeder
{
    public function run(): void
    {
        $this->document_number();
    }

    protected function document_number(): void
    {
       $code_generators = [
            [
                'id'     => '019d2902-9df1-71fb-9e29-a949a8fb733d',
                'code'   => 'documents',
                'column' => 'number',
                'mask'   => 'DOC-{0:000}',
                'active' => true,
            ],
        ];

        DB::table('code_generators')->insertOrIgnore($code_generators);
    }
}
