<?php

namespace Solaris\MasterData\Database\Seeders;

use Illuminate\Database\Seeder;
use Solaris\Core\Models\AiAgent;
use Solaris\Core\Models\AiTool;
use Solaris\Core\Models\Permission;
use Solaris\Core\Models\Role;

class AiRegistrySeeder extends Seeder
{
    protected array $roles = [
        'AI Agent Customer' => [
            'id'          => '019fa686-6799-7932-936e-de442cfa490c',
            'description' => 'Access to the Customer AI agent — accounts and contacts.',
            'agent'       => 'customer',
            'specialist'  => 'customer_specialist',
        ],
        'AI Agent Activity' => [
            'id'          => '019fad3a-2f5d-72cc-b748-bf9f55a7c93a',
            'description' => 'Access to the Activity AI agent — activities, reminders, participants, and promoted products.',
            'agent'       => 'activity',
            'specialist'  => 'activity_specialist',
        ],
        'AI Agent Catalog' => [
            'id'          => '019fa686-679a-7ac8-968a-abe4fc340850',
            'description' => 'Access to the Catalog AI agent — products, features, availability, and price history.',
            'agent'       => 'catalog',
            'specialist'  => 'catalog_specialist',
        ],
        'AI Agent Content' => [
            'id'          => '019fa686-679a-7ab1-9047-a4bbb7a8d2e1',
            'description' => 'Access to the Content AI agent — knowledge base articles and documents.',
            'agent'       => 'content',
            'specialist'  => 'content_specialist',
        ],
    ];

    protected array $permissions = [
        'AI Tool Account Create' => [
            'id'          => '019fa686-679a-731e-b2ae-cbd45e32ead4',
            'description' => 'Create accounts and their addresses via AI.',
            'tools'       => ['create_account', 'create_account_address'],
        ],
        'AI Tool Account Update' => [
            'id'          => '019fa686-679a-7380-82c3-1a6814a8b191',
            'description' => 'Update accounts and their addresses via AI.',
            'tools'       => ['update_account', 'update_account_address'],
        ],
        'AI Tool Account Delete' => [
            'id'          => '019fa686-679a-77e6-bf8c-dab364760210',
            'description' => 'Delete accounts and their addresses via AI.',
            'tools'       => ['delete_account', 'delete_account_address'],
        ],
        'AI Tool Account Search' => [
            'id'          => '019fa686-679a-73b1-91cd-0f6df771c296',
            'description' => 'Search accounts and their addresses via AI.',
            'tools'       => ['search_account', 'search_account_basic', 'search_account_address'],
        ],
        'AI Tool Contact Create' => [
            'id'          => '019fa686-679a-78d8-94b2-4bd43b7e5d13',
            'description' => 'Create contacts and their addresses, communications, hobbies, and relations via AI.',
            'tools'       => ['create_contact', 'create_contact_address', 'create_contact_communication', 'create_contact_hobby', 'create_related_contact'],
        ],
        'AI Tool Contact Update' => [
            'id'          => '019fa686-679a-7983-9195-50cba3c91ca9',
            'description' => 'Update contacts and their addresses, communications, hobbies, and relations via AI.',
            'tools'       => ['update_contact', 'update_contact_address', 'update_contact_communication', 'update_contact_hobby', 'update_related_contact'],
        ],
        'AI Tool Contact Delete' => [
            'id'          => '019fa686-679a-7dc0-9af8-92c312285da6',
            'description' => 'Delete contacts and their addresses, communications, hobbies, and relations via AI.',
            'tools'       => ['delete_contact', 'delete_contact_address', 'delete_contact_communication', 'delete_contact_hobby', 'delete_related_contact'],
        ],
        'AI Tool Contact Search' => [
            'id'          => '019fa686-679a-7807-8d14-e85a786e8b52',
            'description' => 'Search contacts and their addresses, communications, hobbies, and relations via AI.',
            'tools'       => ['search_contact', 'search_contact_basic', 'search_contact_address', 'search_contact_communication', 'search_contact_hobby', 'search_related_contact'],
        ],
        'AI Tool Activity Create' => [
            'id'          => '019fa686-679a-7bcc-bd7f-8e5d995c0cc2',
            'description' => 'Create activities via AI.',
            'tools'       => ['create_activity'],
        ],
        'AI Tool Activity Update' => [
            'id'          => '019fa686-679a-7854-ba56-756f9ae0221e',
            'description' => 'Update activities via AI.',
            'tools'       => ['update_activity'],
        ],
        'AI Tool Activity Delete' => [
            'id'          => '019fa686-679a-7d2c-a2bb-89c35c5a944f',
            'description' => 'Delete activities via AI.',
            'tools'       => ['delete_activity'],
        ],
        'AI Tool Activity Search' => [
            'id'          => '019fa686-679a-7c3d-8a1e-0e58b11691b5',
            'description' => 'Search activities and their reminders via AI.',
            'tools'       => ['search_activity', 'search_activity_reminder'],
        ],
        'AI Tool Product Create' => [
            'id'          => '019fa686-679a-7c83-bef6-8c4dcf90c316',
            'description' => 'Create products, their features, and availability via AI.',
            'tools'       => ['create_product', 'create_product_feature', 'create_product_availability'],
        ],
        'AI Tool Product Update' => [
            'id'          => '019fa686-679a-7f37-8bc1-e073e6bed3ae',
            'description' => 'Update products, their features, and availability via AI.',
            'tools'       => ['update_product', 'update_product_feature', 'update_product_availability'],
        ],
        'AI Tool Product Delete' => [
            'id'          => '019fa686-679a-7c60-9e5f-82cccf86e3c0',
            'description' => 'Delete products, their features, and availability via AI.',
            'tools'       => ['delete_product', 'delete_product_feature', 'delete_product_availability'],
        ],
        'AI Tool Product Search' => [
            'id'          => '019fa686-679a-7fbb-8b7c-5d9bf98a1058',
            'description' => 'Search products, their features, availability, and price history via AI.',
            'tools'       => ['search_product', 'search_product_basic', 'search_product_feature', 'search_product_availability', 'search_product_price_history'],
        ],
        'AI Tool Knowledge Base Create' => [
            'id'          => '019fa686-679a-7ea5-81a0-3a506184825d',
            'description' => 'Create knowledge base articles via AI.',
            'tools'       => ['create_knowledge_base'],
        ],
        'AI Tool Knowledge Base Update' => [
            'id'          => '019fa686-679a-7007-b160-ae44d92866a7',
            'description' => 'Update knowledge base articles via AI.',
            'tools'       => ['update_knowledge_base'],
        ],
        'AI Tool Knowledge Base Delete' => [
            'id'          => '019fa686-679a-75bf-b050-ac3bf56da871',
            'description' => 'Delete knowledge base articles via AI.',
            'tools'       => ['delete_knowledge_base'],
        ],
        'AI Tool Knowledge Base Search' => [
            'id'          => '019fa686-679a-7fd4-83f3-8697fb551791',
            'description' => 'Search knowledge base articles via AI.',
            'tools'       => ['search_knowledge_base'],
        ],
        'AI Tool Document Create' => [
            'id'          => '019fa686-679a-72ef-9170-8a28352743e9',
            'description' => 'Create documents via AI.',
            'tools'       => ['create_document'],
        ],
        'AI Tool Document Update' => [
            'id'          => '019fa686-679a-73ed-885a-e89544a7c5fb',
            'description' => 'Update documents via AI.',
            'tools'       => ['update_document'],
        ],
        'AI Tool Document Delete' => [
            'id'          => '019fa686-679a-794e-a606-8fafe24a2cf8',
            'description' => 'Delete documents via AI.',
            'tools'       => ['delete_document'],
        ],
        'AI Tool Document Search' => [
            'id'          => '019fa686-679a-77bb-b7c7-f9c170948da2',
            'description' => 'Search documents via AI.',
            'tools'       => ['search_document'],
        ],
        'AI Tool User Search' => [
            'id'          => '36745fc4-56f1-446e-b8c0-36c3631f64ae',
            'description' => 'Search users via AI.',
            'tools'       => ['search_user'],
        ],
    ];

    protected array $rolePermissions = [
        'AI Agent Customer' => [
            'AI Tool Account Create', 'AI Tool Account Update', 'AI Tool Account Delete', 'AI Tool Account Search',
            'AI Tool Contact Create', 'AI Tool Contact Update', 'AI Tool Contact Delete', 'AI Tool Contact Search',
            'AI Tool User Search',
        ],
        'AI Agent Activity' => [
            'AI Tool Activity Create', 'AI Tool Activity Update', 'AI Tool Activity Delete', 'AI Tool Activity Search',
            'AI Tool Account Search', 'AI Tool Contact Search', 'AI Tool Product Search',
            'AI Tool User Search',
        ],
        'AI Agent Catalog' => [
            'AI Tool Product Create', 'AI Tool Product Update', 'AI Tool Product Delete', 'AI Tool Product Search',
            'AI Tool User Search',
        ],
        'AI Agent Content' => [
            'AI Tool Knowledge Base Create', 'AI Tool Knowledge Base Update', 'AI Tool Knowledge Base Delete', 'AI Tool Knowledge Base Search',
            'AI Tool Document Create', 'AI Tool Document Update', 'AI Tool Document Delete', 'AI Tool Document Search',
            'AI Tool Account Search', 'AI Tool Contact Search',
            'AI Tool User Search',
        ],
    ];

    protected array $wiring = [
        'customer' => [
            'extract_images', 'lookup_options', 'lookup_region', 'get_current_datetime',
            'search_account', 'create_account', 'update_account', 'delete_account',
            'search_account_address', 'create_account_address', 'update_account_address', 'delete_account_address',
            'search_contact', 'create_contact', 'update_contact', 'delete_contact',
            'search_contact_address', 'create_contact_address', 'update_contact_address', 'delete_contact_address',
            'search_contact_communication', 'create_contact_communication', 'update_contact_communication', 'delete_contact_communication',
            'search_contact_hobby', 'create_contact_hobby', 'update_contact_hobby', 'delete_contact_hobby',
            'search_related_contact', 'create_related_contact', 'update_related_contact', 'delete_related_contact',
            'search_user',
        ],
        // Account/contact access wired in AiScopedToolSeeder (lookup-shaped variants).
        'activity' => [
            'lookup_options', 'get_current_datetime',
            'search_activity', 'create_activity', 'update_activity', 'delete_activity',
            'search_activity_reminder',
            'search_user',
        ],
        'catalog' => [
            'lookup_options', 'lookup_region', 'get_current_datetime',
            'search_product', 'create_product', 'update_product', 'delete_product',
            'search_product_feature', 'create_product_feature', 'update_product_feature', 'delete_product_feature',
            'search_product_availability', 'create_product_availability', 'update_product_availability', 'delete_product_availability',
            'search_product_price_history',
            'search_user',
        ],
        // Account/contact access for this agent is wired in AiScopedToolSeeder — it references them by
        // name only, so it gets the lookup-shaped variants rather than the full tools.
        'content' => [
            'lookup_options', 'lookup_region', 'get_current_datetime',
            'search_knowledge_base', 'create_knowledge_base', 'update_knowledge_base', 'delete_knowledge_base',
            'search_document', 'create_document', 'update_document', 'delete_document',
            'search_user',
        ],
        'whatsapp' => [
            'customer_specialist', 'activity_specialist', 'catalog_specialist', 'content_specialist',
        ],
    ];

    public function run(): void
    {
        $this->seedRoles();
        $this->seedPermissions();
        $this->assignRolePermissions();
        $this->grantAgentAndSpecialistAccess();
        $this->grantPermissionTools();
        $this->wiring();
    }

    protected function seedRoles(): void
    {
        foreach ($this->roles as $name => $role) {
            Role::firstOrCreate(['id' => $role['id']], [
                'name'        => $name,
                'description' => $role['description'],
            ]);
        }
    }

    protected function seedPermissions(): void
    {
        foreach ($this->permissions as $name => $permission) {
            Permission::firstOrCreate(['id' => $permission['id']], [
                'name'        => $name,
                'description' => $permission['description'],
            ]);
        }
    }

    protected function assignRolePermissions(): void
    {
        foreach ($this->rolePermissions as $roleName => $permissionNames) {
            $role = Role::find($this->roles[$roleName]['id']);

            if ($role === null) {
                continue;
            }

            $role->assignPermission(array_map(fn (string $name) => $this->permissions[$name]['id'], $permissionNames));
        }
    }

    protected function grantAgentAndSpecialistAccess(): void
    {
        foreach ($this->roles as $role) {
            AiAgent::where('slug', $role['agent'])->first()?->assignRole([$role['id']]);
            AiTool::where('slug', $role['specialist'])->first()?->assignRole([$role['id']]);
        }
    }

    protected function grantPermissionTools(): void
    {
        foreach ($this->permissions as $permission) {
            AiTool::whereIn('slug', $permission['tools'])->get()
                ->each(fn (AiTool $tool) => $tool->assignPermission([$permission['id']]));
        }
    }

    protected function wiring(): void
    {
        foreach ($this->wiring as $agentSlug => $toolSlugs) {
            $agent = AiAgent::where('slug', $agentSlug)->first();

            if ($agent === null) {
                continue;
            }

            $agent->attachTools(AiTool::whereIn('slug', $toolSlugs)->pluck('id')->all());
        }
    }
}
