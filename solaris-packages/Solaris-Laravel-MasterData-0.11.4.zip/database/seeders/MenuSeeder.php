<?php

namespace Solaris\MasterData\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Solaris\Core\Models\Menu;

class MenuSeeder extends Seeder
{
    public function run(): void
    {
        $this->master_data();
    }

    protected function master_data(): void
    {
        $categoryId = '019ac821-1851-789c-8969-7e2a8072ebe5';
        $masterDataId = '019ac821-1851-7f78-b916-e7be568c1b19';

        $data = [
            [
                'id' => $categoryId,
                'name' => 'Master Data',
                'position' => 1,
                'url' => null,
                'route_name' => null,
                'icon' => null,
                'is_category' => true,
                'parent_id' => null,
                'category_id' => null,
            ],
            [
                'id' => $masterDataId,
                'name' => 'Master Data',
                'position' => 1,
                'url' => '',
                'route_name' => '',
                'icon' => 'bx bx-lock',
                'is_category' => false,
                'parent_id' => null,
                'category_id' => $categoryId,
            ],
            [
                'id' => '019b0c61-8181-72a5-ac3f-7dc45170fdd0',
                'name' => 'Account',
                'position' => 1,
                'url' => '/master-data/account',
                'route_name' => 'master-data.account',
                'icon' => null,
                'is_category' => false,
                'parent_id' => $masterDataId,
                'category_id' => null,
            ],
            [
                'id' => '019ac821-1851-7ac8-8bc1-8ada6b6d8669',
                'name' => 'Contact',
                'position' => 2,
                'url' => '/master-data/contact',
                'route_name' => 'master-data.contact',
                'icon' => null,
                'is_category' => false,
                'parent_id' => $masterDataId,
                'category_id' => null,
            ],
            [
                'id' => '019ac821-1851-7ce9-98d8-424cdedc01e0',
                'name' => 'Knowledge Base',
                'position' => 3,
                'url' => '/master-data/knowledge-base',
                'route_name' => 'master-data.knowledge-base',
                'icon' => null,
                'is_category' => false,
                'parent_id' => $masterDataId,
                'category_id' => null,
            ],
            [
                'id' => '019ac821-1851-78cc-bacf-897765559a39',
                'name' => 'Document',
                'position' => 4,
                'url' => '/master-data/document',
                'route_name' => 'master-data.document',
                'icon' => null,
                'is_category' => false,
                'parent_id' => $masterDataId,
                'category_id' => null,
            ],
            [
                'id' => '019cdffa-9cc8-7180-bbcf-346c2f2f55d1',
                'name' => 'Product',
                'position' => 5,
                'url' => '/master-data/product',
                'route_name' => 'master-data.product',
                'icon' => null,
                'is_category' => false,
                'parent_id' => $masterDataId,
                'category_id' => null,
            ],
            [
                'id' => '019ac821-1851-7afe-97de-dc54aeffdff8',
                'name' => 'Activity',
                'position' => 6,
                'url' => '/master-data/activity',
                'route_name' => 'master-data.activity',
                'icon' => null,
                'is_category' => false,
                'parent_id' => $masterDataId,
                'category_id' => null,
            ],
        ];

        DB::table('menus')->insertOrIgnore($data);

        $menuAccess = Menu::whereIn('id',
            array_map(
                fn ($item) => $item['id'],
                array_filter($data, fn ($item) => ! $item['is_category'] && ! empty($item['url']))
            )
        )
            ->get();

        foreach ($menuAccess as $menu) {
            $menu->assignRole('User');
        }
    }
}
