<?php

namespace Solaris\MasterData\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Solaris\MasterData\Const\ProductTypeConst;

class ProductSeeder extends Seeder
{
    public function run(): void
    {
        $this->product_types();
    }

    protected function product_types(): void
    {
       $data = [
            [
                'id'        => ProductTypeConst::GoodsAndServices,
                'name'      => 'Goods and services',
                'position'  => 1
            ],
            [
                'id'        => ProductTypeConst::Goods,
                'name'      => 'Goods',
                'position'  => 2
            ],
            [
                'id'        => ProductTypeConst::Services,
                'name'      => 'Services',
                'position'  => 3
            ],
        ];
        DB::table('product_types')->insertOrIgnore($data);
    }
}
