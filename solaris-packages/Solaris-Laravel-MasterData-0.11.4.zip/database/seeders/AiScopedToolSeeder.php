<?php

namespace Solaris\MasterData\Database\Seeders;

use Illuminate\Database\Seeder;
use Solaris\Core\Models\AiAgent;
use Solaris\Core\Models\AiTool;

// Wiring for scoped tool variants, kept out of AiRegistrySeeder on purpose: that one describes what a
// package OWNS, this one describes how much of a resource each agent is allowed to see. The two change
// for different reasons and at different times.
//
// An agent that merely references a resource (picks it by name to fill a foreign key) gets the
// lookup-shaped variant instead of the full search tool — the full one costs ~2K tokens of columns and
// peer relation catalogues on every step, for a capability that agent never uses.
class AiScopedToolSeeder extends Seeder
{
    protected array $grant = [
        'content'  => ['search_account_basic', 'search_contact_basic'],
        'activity' => ['search_account_basic', 'search_contact_basic', 'search_product_basic'],
    ];

    // attachTools() only ever adds, so on an already-seeded database the superseded full tool stays
    // attached and the agent ends up carrying BOTH descriptions — heavier than before the swap, which
    // is the exact opposite of the point. detachTools() only removes unlocked pivots, so essential
    // wiring is never at risk here.
    protected array $revoke = [
        'content'  => ['search_account', 'search_contact'],
        'activity' => ['search_account', 'search_contact', 'search_product'],
    ];

    public function run(): void
    {
        $this->grantScopedTools();
        $this->revokeSupersededTools();
    }

    protected function grantScopedTools(): void
    {
        foreach ($this->grant as $agentSlug => $toolSlugs) {
            AiAgent::where('slug', $agentSlug)->first()
                ?->attachTools(AiTool::whereIn('slug', $toolSlugs)->pluck('id')->all());
        }
    }

    protected function revokeSupersededTools(): void
    {
        foreach ($this->revoke as $agentSlug => $toolSlugs) {
            AiAgent::where('slug', $agentSlug)->first()
                ?->detachTools(AiTool::whereIn('slug', $toolSlugs)->pluck('id')->all());
        }
    }
}
