<?php

use Solaris\MasterData\Tests\TestCase;

uses(TestCase::class)->in(__DIR__);
