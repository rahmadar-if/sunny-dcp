<?php

// config for Solaris/MasterData
return [

    /*
    |--------------------------------------------------------------------------
    | Resources
    |--------------------------------------------------------------------------
    */
    'resource' => [
        'path' => [
            'master-data' => 'vendor/solaris/solaris-laravel-masterdata/resources',
        ],
        'views' => [
            'account' => [
                'list' => 'master-data::pages.account.list',
                'page' => 'master-data::pages.account.page',
            ],
            'contact' => [
                'list' => 'master-data::pages.contact.list',
                'page' => 'master-data::pages.contact.page',
            ],
            'product' => [
                'list' => 'master-data::pages.product.list',
                'page' => 'master-data::pages.product.page',
            ],
            'activity' => [
                'list' => 'master-data::pages.activity.list',
                'page' => 'master-data::pages.activity.page',
            ],
            'knowledge_base' => [
                'list' => 'master-data::pages.knowledge_base.list',
                'page' => 'master-data::pages.knowledge_base.page',
            ],
            'document' => [
                'list' => 'master-data::pages.document.list',
                'page' => 'master-data::pages.document.page',
            ],
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Models
    |--------------------------------------------------------------------------
    */
    'model' => [
        'namespaces' => [
            'Solaris\\MasterData\\Models' => base_path('vendor/solaris/solaris-laravel-masterdata/src/Models'),
        ],
        'models' => [
            'account'             => 'Solaris\\MasterData\\Models\\Account',
            'account_type'        => 'Solaris\\MasterData\\Models\\AccountType',
            'number_of_employee'  => 'Solaris\\MasterData\\Models\\NumberOfEmployee',
            'business_entity'     => 'Solaris\\MasterData\\Models\\BusinessEntity',
            'industry'            => 'Solaris\\MasterData\\Models\\Industry',
            'account_address'     => 'Solaris\\MasterData\\Models\\AccountAddress',
            'address_type'        => 'Solaris\\MasterData\\Models\\AddressType',

            'contact'                  => 'Solaris\\MasterData\\Models\\Contact',
            'preferred_language'       => 'Solaris\\MasterData\\Models\\PreferredLanguage',
            'marital_status'           => 'Solaris\\MasterData\\Models\\MaritalStatus',
            'education'                => 'Solaris\\MasterData\\Models\\Education',
            'contact_address'          => 'Solaris\\MasterData\\Models\\ContactAddress',
            'contact_communication'    => 'Solaris\\MasterData\\Models\\ContactCommunication',
            'communication_type'       => 'Solaris\\MasterData\\Models\\CommunicationType',
            'contact_hobby'            => 'Solaris\\MasterData\\Models\\ContactHobby',
            'related_contact'          => 'Solaris\\MasterData\\Models\\RelatedContact',
            'related_contact_category' => 'Solaris\\MasterData\\Models\\RelatedContactCategory',

            'product'                => 'Solaris\\MasterData\\Models\\Product',
            'product_type'           => 'Solaris\\MasterData\\Models\\ProductType',
            'product_price_history'  => 'Solaris\\MasterData\\Models\\ProductPriceHistory',
            'product_availability'   => 'Solaris\\MasterData\\Models\\ProductAvailability',
            'product_feature'        => 'Solaris\\MasterData\\Models\\ProductFeature',

            'activity'          => 'Solaris\\MasterData\\Models\\Activity',
            'activity_priority' => 'Solaris\\MasterData\\Models\\ActivityPriority',
            'activity_category' => 'Solaris\\MasterData\\Models\\ActivityCategory',
            'activity_status'   => 'Solaris\\MasterData\\Models\\ActivityStatus',
            'activity_reminder' => 'Solaris\\MasterData\\Models\\ActivityReminder',
            'reminder_type'     => 'Solaris\\MasterData\\Models\\ReminderType',

            'document'        => 'Solaris\\MasterData\\Models\\Document',
            'document_status' => 'Solaris\\MasterData\\Models\\DocumentStatus',
            'document_type'   => 'Solaris\\MasterData\\Models\\DocumentType',

            'knowledge_base'        => 'Solaris\\MasterData\\Models\\KnowledgeBase',
            'knowledge_base_status' => 'Solaris\\MasterData\\Models\\KnowledgeBaseStatus',
            'knowledge_base_type'   => 'Solaris\\MasterData\\Models\\KnowledgeBaseType',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Repositories
    |--------------------------------------------------------------------------
    */
    'repositories' => [
        'account'         => 'Solaris\\MasterData\\Repositories\\AccountRepository',
        'account_address' => 'Solaris\\Core\\Repositories\\BaseRepository',

        'contact'               => 'Solaris\\MasterData\\Repositories\\ContactRepository',
        'contact_address'       => 'Solaris\\Core\\Repositories\\BaseRepository',
        'contact_hobby'         => 'Solaris\\Core\\Repositories\\BaseRepository',
        'contact_communication' => 'Solaris\\Core\\Repositories\\BaseRepository',
        'related_contact'       => 'Solaris\\Core\\Repositories\\BaseRepository',

        'product'                => 'Solaris\\MasterData\\Repositories\\ProductRepository',
        'product_feature'        => 'Solaris\\Core\\Repositories\\BaseRepository',
        'product_availability'   => 'Solaris\\Core\\Repositories\\BaseRepository',
        'product_price_history'  => 'Solaris\\Core\\Repositories\\BaseRepository',

        'activity'       => 'Solaris\\MasterData\\Repositories\\ActivityRepository',
        'knowledge_base' => 'Solaris\\Core\\Repositories\\BaseRepository',
        'document'       => 'Solaris\\Core\\Repositories\\BaseRepository',
    ],

    /*
    |--------------------------------------------------------------------------
    | HTTP Layer
    |--------------------------------------------------------------------------
    */
    'controller' => [
        'namespaces' => [
            'Solaris\\MasterData\\Http\\Controllers',
        ],
        'controllers' => [
            'account'         => 'Solaris\\MasterData\\Http\\Controllers\\AccountController',
            'account_address' => 'Solaris\\MasterData\\Http\\Controllers\\AccountAddressController',

            'contact'               => 'Solaris\\MasterData\\Http\\Controllers\\ContactController',
            'contact_address'       => 'Solaris\\MasterData\\Http\\Controllers\\ContactAddressController',
            'contact_hobby'         => 'Solaris\\MasterData\\Http\\Controllers\\ContactHobbyController',
            'contact_communication' => 'Solaris\\MasterData\\Http\\Controllers\\ContactCommunicationController',
            'related_contact'       => 'Solaris\\MasterData\\Http\\Controllers\\RelatedContactController',

            'product'              => 'Solaris\\MasterData\\Http\\Controllers\\ProductController',
            'product_feature'      => 'Solaris\\MasterData\\Http\\Controllers\\ProductFeatureController',
            'product_availability' => 'Solaris\\MasterData\\Http\\Controllers\\ProductAvailabilityController',

            'activity'       => 'Solaris\\MasterData\\Http\\Controllers\\ActivityController',
            'knowledge_base' => 'Solaris\\MasterData\\Http\\Controllers\\KnowledgeBaseController',
            'document'       => 'Solaris\\MasterData\\Http\\Controllers\\DocumentController',
        ],
    ],

    'form_requests' => [
        'account'         => 'Solaris\\MasterData\\Http\\Requests\\AccountRequest',
        'account_address' => 'Solaris\\MasterData\\Http\\Requests\\AccountAddressRequest',

        'contact'               => 'Solaris\\MasterData\\Http\\Requests\\ContactRequest',
        'contact_address'       => 'Solaris\\MasterData\\Http\\Requests\\ContactAddressRequest',
        'contact_hobby'         => 'Solaris\\MasterData\\Http\\Requests\\ContactHobbyRequest',
        'contact_communication' => 'Solaris\\MasterData\\Http\\Requests\\ContactCommunicationRequest',
        'related_contact'       => 'Solaris\\MasterData\\Http\\Requests\\RelatedContactRequest',

        'product'              => 'Solaris\\MasterData\\Http\\Requests\\ProductRequest',
        'product_feature'      => 'Solaris\\MasterData\\Http\\Requests\\ProductFeatureRequest',
        'product_availability' => 'Solaris\\MasterData\\Http\\Requests\\ProductAvailabilityRequest',

        'activity'       => 'Solaris\\MasterData\\Http\\Requests\\ActivityRequest',
        'knowledge_base' => 'Solaris\\MasterData\\Http\\Requests\\KnowledgeBaseRequest',
        'document'       => 'Solaris\\MasterData\\Http\\Requests\\DocumentRequest',
    ],

    /*
    |--------------------------------------------------------------------------
    | 3rd Party API
    |--------------------------------------------------------------------------
    */
    'api' => [
        'controllers' => [
            'account'  => 'Solaris\\MasterData\\Http\\Controllers\\Api\\AccountController',
            'contact'  => 'Solaris\\MasterData\\Http\\Controllers\\Api\\ContactController',
            'activity' => 'Solaris\\MasterData\\Http\\Controllers\\Api\\ActivityController',
            'product'  => 'Solaris\\MasterData\\Http\\Controllers\\Api\\ProductController',
        ],

        'resources' => [
            'account'  => 'Solaris\\MasterData\\Http\\Resources\\Api\\AccountResource',
            'contact'  => 'Solaris\\MasterData\\Http\\Resources\\Api\\ContactResource',
            'activity' => 'Solaris\\MasterData\\Http\\Resources\\Api\\ActivityResource',
            'product'  => 'Solaris\\MasterData\\Http\\Resources\\Api\\ProductResource',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Mobile
    |--------------------------------------------------------------------------
    */
    'mobile' => [
        'controllers' => [
            'account'         => 'Solaris\\MasterData\\Http\\Controllers\\Mobile\\AccountController',
            'account_address' => 'Solaris\\MasterData\\Http\\Controllers\\Mobile\\AccountAddressController',

            'contact'               => 'Solaris\\MasterData\\Http\\Controllers\\Mobile\\ContactController',
            'contact_address'       => 'Solaris\\MasterData\\Http\\Controllers\\Mobile\\ContactAddressController',
            'contact_communication' => 'Solaris\\MasterData\\Http\\Controllers\\Mobile\\ContactCommunicationController',
            'contact_hobby'         => 'Solaris\\MasterData\\Http\\Controllers\\Mobile\\ContactHobbyController',
            'related_contact'       => 'Solaris\\MasterData\\Http\\Controllers\\Mobile\\RelatedContactController',
            'product'               => 'Solaris\\MasterData\\Http\\Controllers\\Mobile\\ProductController',
            'product_feature'       => 'Solaris\\MasterData\\Http\\Controllers\\Mobile\\ProductFeatureController',
            'product_availability'  => 'Solaris\\MasterData\\Http\\Controllers\\Mobile\\ProductAvailabilityController',
            'product_price_history' => 'Solaris\\MasterData\\Http\\Controllers\\Mobile\\ProductPriceHistoryController',
            'activity'              => 'Solaris\\MasterData\\Http\\Controllers\\Mobile\\ActivityController',

            'home' => 'Solaris\\MasterData\\Http\\Controllers\\Mobile\\HomeController',
        ],

        'resources' => [
            'account'         => 'Solaris\\MasterData\\Http\\Resources\\Mobile\\AccountResource',
            'account_address' => 'Solaris\\MasterData\\Http\\Resources\\Mobile\\AccountAddressResource',

            'contact'               => 'Solaris\\MasterData\\Http\\Resources\\Mobile\\ContactResource',
            'contact_address'       => 'Solaris\\MasterData\\Http\\Resources\\Mobile\\ContactAddressResource',
            'contact_communication' => 'Solaris\\MasterData\\Http\\Resources\\Mobile\\ContactCommunicationResource',
            'contact_hobby'         => 'Solaris\\MasterData\\Http\\Resources\\Mobile\\ContactHobbyResource',
            'related_contact'       => 'Solaris\\MasterData\\Http\\Resources\\Mobile\\RelatedContactResource',
            'product'               => 'Solaris\\MasterData\\Http\\Resources\\Mobile\\ProductResource',
            'product_feature'       => 'Solaris\\MasterData\\Http\\Resources\\Mobile\\ProductFeatureResource',
            'product_availability'  => 'Solaris\\MasterData\\Http\\Resources\\Mobile\\ProductAvailabilityResource',
            'product_price_history' => 'Solaris\\MasterData\\Http\\Resources\\Mobile\\ProductPriceHistoryResource',
            'activity'              => 'Solaris\\MasterData\\Http\\Resources\\Mobile\\ActivityResource',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Artificial Intelligence
    |--------------------------------------------------------------------------
    |
    | Own slug=>FQCN registry entries, merged into Core's ai.agents/ai.tools — same declarative pattern as
    | Core (see its config/solaris.php doc comment), read by AiRegistryService::sync(). No imperative
    | boot-time registration here anymore (that was the old AiToolRegistry mechanism).
    |
    | CustomerAgent (Account/Contact/Activity), CatalogAgent (Product + children), and ContentAgent
    | (KnowledgeBase + Document) are all migrated onto the new BaseAiAgent/BaseAiTool standard and
    | registered below. All three domains are now fully covered — no old-pattern tools remain.
    |
    */
    'ai' => [
        'agents' => [
            'customer' => 'Solaris\\MasterData\\Ai\\Agents\\CustomerAgent',
            'catalog'  => 'Solaris\\MasterData\\Ai\\Agents\\CatalogAgent',
            'content'  => 'Solaris\\MasterData\\Ai\\Agents\\ContentAgent',
        ],

        'tools' => [
            'search_account'               => 'Solaris\\MasterData\\Ai\\Tools\\Account\\SearchAccountTool',
            'search_account_address'       => 'Solaris\\MasterData\\Ai\\Tools\\AccountAddress\\SearchAccountAddressTool',
            'search_contact'               => 'Solaris\\MasterData\\Ai\\Tools\\Contact\\SearchContactTool',

            // Name-lookup variants for agents that only need to resolve a reference id (documents,
            // activities) instead of analysing the record. Never grant these alongside their full
            // counterpart — the agent would carry both descriptions.
            'search_account_basic'         => 'Solaris\\MasterData\\Ai\\Tools\\Account\\SearchAccountBasicTool',
            'search_contact_basic'         => 'Solaris\\MasterData\\Ai\\Tools\\Contact\\SearchContactBasicTool',
            'search_product_basic'         => 'Solaris\\MasterData\\Ai\\Tools\\Product\\SearchProductBasicTool',

            'search_contact_address'       => 'Solaris\\MasterData\\Ai\\Tools\\ContactAddress\\SearchContactAddressTool',
            'search_contact_communication' => 'Solaris\\MasterData\\Ai\\Tools\\ContactCommunication\\SearchContactCommunicationTool',
            'search_contact_hobby'         => 'Solaris\\MasterData\\Ai\\Tools\\ContactHobby\\SearchContactHobbyTool',
            'search_related_contact'       => 'Solaris\\MasterData\\Ai\\Tools\\RelatedContact\\SearchRelatedContactTool',
            'create_related_contact'       => 'Solaris\\MasterData\\Ai\\Tools\\RelatedContact\\CreateRelatedContactTool',
            'update_related_contact'       => 'Solaris\\MasterData\\Ai\\Tools\\RelatedContact\\UpdateRelatedContactTool',
            'delete_related_contact'       => 'Solaris\\MasterData\\Ai\\Tools\\RelatedContact\\DeleteRelatedContactTool',
            'search_activity'              => 'Solaris\\MasterData\\Ai\\Tools\\Activity\\SearchActivityTool',
            'search_activity_reminder'     => 'Solaris\\MasterData\\Ai\\Tools\\ActivityReminder\\SearchActivityReminderTool',

            'search_product'               => 'Solaris\\MasterData\\Ai\\Tools\\Product\\SearchProductTool',
            'search_product_feature'       => 'Solaris\\MasterData\\Ai\\Tools\\ProductFeature\\SearchProductFeatureTool',
            'search_product_availability'  => 'Solaris\\MasterData\\Ai\\Tools\\ProductAvailability\\SearchProductAvailabilityTool',
            'search_product_price_history' => 'Solaris\\MasterData\\Ai\\Tools\\ProductPriceHistory\\SearchProductPriceHistoryTool',

            'create_product'              => 'Solaris\\MasterData\\Ai\\Tools\\Product\\CreateProductTool',
            'update_product'              => 'Solaris\\MasterData\\Ai\\Tools\\Product\\UpdateProductTool',
            'delete_product'              => 'Solaris\\MasterData\\Ai\\Tools\\Product\\DeleteProductTool',

            'create_product_feature'      => 'Solaris\\MasterData\\Ai\\Tools\\ProductFeature\\CreateProductFeatureTool',
            'update_product_feature'      => 'Solaris\\MasterData\\Ai\\Tools\\ProductFeature\\UpdateProductFeatureTool',
            'delete_product_feature'      => 'Solaris\\MasterData\\Ai\\Tools\\ProductFeature\\DeleteProductFeatureTool',

            'create_product_availability' => 'Solaris\\MasterData\\Ai\\Tools\\ProductAvailability\\CreateProductAvailabilityTool',
            'update_product_availability' => 'Solaris\\MasterData\\Ai\\Tools\\ProductAvailability\\UpdateProductAvailabilityTool',
            'delete_product_availability' => 'Solaris\\MasterData\\Ai\\Tools\\ProductAvailability\\DeleteProductAvailabilityTool',

            'search_knowledge_base' => 'Solaris\\MasterData\\Ai\\Tools\\KnowledgeBase\\SearchKnowledgeBaseTool',
            'create_knowledge_base' => 'Solaris\\MasterData\\Ai\\Tools\\KnowledgeBase\\CreateKnowledgeBaseTool',
            'update_knowledge_base' => 'Solaris\\MasterData\\Ai\\Tools\\KnowledgeBase\\UpdateKnowledgeBaseTool',
            'delete_knowledge_base' => 'Solaris\\MasterData\\Ai\\Tools\\KnowledgeBase\\DeleteKnowledgeBaseTool',

            'search_document' => 'Solaris\\MasterData\\Ai\\Tools\\Document\\SearchDocumentTool',
            'create_document' => 'Solaris\\MasterData\\Ai\\Tools\\Document\\CreateDocumentTool',
            'update_document' => 'Solaris\\MasterData\\Ai\\Tools\\Document\\UpdateDocumentTool',
            'delete_document' => 'Solaris\\MasterData\\Ai\\Tools\\Document\\DeleteDocumentTool',

            'create_account' => 'Solaris\\MasterData\\Ai\\Tools\\Account\\CreateAccountTool',
            'update_account' => 'Solaris\\MasterData\\Ai\\Tools\\Account\\UpdateAccountTool',
            'delete_account' => 'Solaris\\MasterData\\Ai\\Tools\\Account\\DeleteAccountTool',

            'create_account_address' => 'Solaris\\MasterData\\Ai\\Tools\\AccountAddress\\CreateAccountAddressTool',
            'update_account_address' => 'Solaris\\MasterData\\Ai\\Tools\\AccountAddress\\UpdateAccountAddressTool',
            'delete_account_address' => 'Solaris\\MasterData\\Ai\\Tools\\AccountAddress\\DeleteAccountAddressTool',

            'create_contact' => 'Solaris\\MasterData\\Ai\\Tools\\Contact\\CreateContactTool',
            'update_contact' => 'Solaris\\MasterData\\Ai\\Tools\\Contact\\UpdateContactTool',
            'delete_contact' => 'Solaris\\MasterData\\Ai\\Tools\\Contact\\DeleteContactTool',

            'create_contact_address' => 'Solaris\\MasterData\\Ai\\Tools\\ContactAddress\\CreateContactAddressTool',
            'update_contact_address' => 'Solaris\\MasterData\\Ai\\Tools\\ContactAddress\\UpdateContactAddressTool',
            'delete_contact_address' => 'Solaris\\MasterData\\Ai\\Tools\\ContactAddress\\DeleteContactAddressTool',

            'create_contact_communication' => 'Solaris\\MasterData\\Ai\\Tools\\ContactCommunication\\CreateContactCommunicationTool',
            'update_contact_communication' => 'Solaris\\MasterData\\Ai\\Tools\\ContactCommunication\\UpdateContactCommunicationTool',
            'delete_contact_communication' => 'Solaris\\MasterData\\Ai\\Tools\\ContactCommunication\\DeleteContactCommunicationTool',

            'create_contact_hobby' => 'Solaris\\MasterData\\Ai\\Tools\\ContactHobby\\CreateContactHobbyTool',
            'update_contact_hobby' => 'Solaris\\MasterData\\Ai\\Tools\\ContactHobby\\UpdateContactHobbyTool',
            'delete_contact_hobby' => 'Solaris\\MasterData\\Ai\\Tools\\ContactHobby\\DeleteContactHobbyTool',

            'create_activity' => 'Solaris\\MasterData\\Ai\\Tools\\Activity\\CreateActivityTool',
            'update_activity' => 'Solaris\\MasterData\\Ai\\Tools\\Activity\\UpdateActivityTool',
            'delete_activity' => 'Solaris\\MasterData\\Ai\\Tools\\Activity\\DeleteActivityTool',
        ],

        // Provider/model failover chain for CustomerAgent (see Core's Ai\Concerns\HasProviderFailover) —
        // same shape/key as Core's ai.agent_providers, this package only supplies its own agent's chain.
        'agent_providers' => [
            'customer' => [
                'providers' => [
                    'openrouter' => env('CUSTOMER_AGENT_OPENROUTER_MODEL') ?: 'deepseek/deepseek-v4-pro',
                    'gemini'     => env('CUSTOMER_AGENT_GEMINI_MODEL') ?: 'gemini-3.5-flash-lite',
                    'anthropic'  => env('CUSTOMER_AGENT_ANTHROPIC_MODEL') ?: 'claude-haiku-4-5-20251001',
                    'openai'     => env('CUSTOMER_AGENT_OPENAI_MODEL') ?: 'gpt-5.4-nano',
                ],
            ],
            'catalog' => [
                'providers' => [
                    'openrouter' => env('CATALOG_AGENT_OPENROUTER_MODEL') ?: 'deepseek/deepseek-v4-flash-0731',
                    'gemini'     => env('CATALOG_AGENT_GEMINI_MODEL') ?: 'gemini-3.5-flash-lite',
                    'anthropic'  => env('CATALOG_AGENT_ANTHROPIC_MODEL') ?: 'claude-haiku-4-5-20251001',
                    'openai'     => env('CATALOG_AGENT_OPENAI_MODEL') ?: 'gpt-5.4-nano',
                ],
            ],
            'content' => [
                'providers' => [
                    'openrouter' => env('CONTENT_AGENT_OPENROUTER_MODEL') ?: 'qwen/qwen3.7-flash',
                    'gemini'     => env('CONTENT_AGENT_GEMINI_MODEL') ?: 'gemini-3.5-flash-lite',
                    'anthropic'  => env('CONTENT_AGENT_ANTHROPIC_MODEL') ?: 'claude-haiku-4-5-20251001',
                    'openai'     => env('CONTENT_AGENT_OPENAI_MODEL') ?: 'gpt-5.4-nano',
                ],
            ],
            'activity' => [
                'providers' => [
                    'openrouter' => env('ACTIVITY_AGENT_OPENROUTER_MODEL') ?: 'deepseek/deepseek-v4-flash-0731',
                    'gemini'     => env('ACTIVITY_AGENT_GEMINI_MODEL') ?: 'gemini-3.5-flash-lite',
                    'anthropic'  => env('ACTIVITY_AGENT_ANTHROPIC_MODEL') ?: 'claude-haiku-4-5-20251001',
                    'openai'     => env('ACTIVITY_AGENT_OPENAI_MODEL') ?: 'gpt-5.4-nano',
                ],
            ],
        ],
    ],
];
