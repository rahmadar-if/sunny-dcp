<?php

use Illuminate\Support\Facades\Schedule;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Jobs\UpdateOpportunityDaysInFunnel;

$timezone = Helper::config('scheduler_timezone', 'UTC');
