<?php

use Illuminate\Support\Facades\Route;
use Solaris\Core\Helpers\Helper;

Route::prefix('mobile')->group(function () {
    Route::middleware('auth.mobile')->group(function () {
        
    });
});
