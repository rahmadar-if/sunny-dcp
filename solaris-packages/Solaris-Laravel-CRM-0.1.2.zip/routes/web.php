<?php

use Illuminate\Support\Facades\Route;
use Solaris\Core\Helpers\Helper;

Route::middleware(['auth', 'menu.access'])->group(function () {

    Route::prefix('crm')->group(function () {

    });

});