# Solaris CRM

A Laravel package providing a unified CRM layer — built on top of `solaris/solaris-laravel-sales` and `solaris/solaris-laravel-marketing`.

Bridges the full customer lifecycle from marketing campaigns and lead generation through the complete sales pipeline.

---

## Requirements

- PHP 8.2+
- Laravel 11 or 12
- `solaris/solaris-laravel-sales` v0.4.3+
- `solaris/solaris-laravel-marketing` v0.3.2+

---

## Architecture

All modules follow the same pattern inherited from `solaris-laravel-core`:

- **Models** extend `BaseModel` (UUID primary key, audit fields, soft deletes)
- **Repositories** extend `BaseRepository` (CRUD, batch ops, attachment handling)
- **Controllers** handle list, edit, and batch delete via standard endpoints
- **FormRequests** extend `BaseFormRequest` for consistent validation

Routes are prefixed under `/crm` and protected by `auth` and `menu.access` middleware.

---

## Changelog

Please see [CHANGELOG](CHANGELOG.md) for recent changes.
