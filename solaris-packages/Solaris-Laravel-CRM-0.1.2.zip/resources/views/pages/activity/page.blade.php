<x-core::page.edit
	:id="$data->id"
	title="Activity"
	:breadcrumbs="$breadcrumbs"
	model="Activity"
	package="crm"
	path="activity/page-index"
	profile-position="left">

	<x-slot:profile>
		@include('master-data::pages.activity.sections.profile-container', ["data" => $data])
		@include('master-data::pages.activity.sections.reminder', ["data" => $data])
	</x-slot>

	@php $tabId = "activity-page-tabs"; @endphp

	{{-- CRM UPDATE --}}
	<x-core::tab id="{{ $tabId }}" class="p-0 mb-4">
		<x-slot:nav>
			<x-core::tab-nav id="{{ $tabId }}_info" active>Info</x-core::tab-nav>
			<x-core::tab-nav id="{{ $tabId }}_related_to">Related To</x-core::tab-nav>
			<x-core::tab-nav id="{{ $tabId }}_notes_files">Notes & Files</x-core::tab-nav>
		</x-slot>

		<x-slot:content>
			@include('base-crm::pages.activity.sections.info', ['data' => $data, 'active' => true])
			@include('crm::pages.activity.sections.related-to', ['data' => $data, 'active' => false])
			@include('master-data::pages.activity.sections.notes-files', ['data' => $data, 'active' => false])
		</x-slot>
	</x-core::tab>
	{{-- END CRM UPDATE --}}

</x-core::page.edit>
