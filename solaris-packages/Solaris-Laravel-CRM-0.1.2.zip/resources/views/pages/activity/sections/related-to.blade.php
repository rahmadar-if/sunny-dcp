@php
	$id = "activity-page-tabs_related_to";
@endphp

<x-core::tab-content :id="$id" :active="$active ?? false" class="p-0 border-0">
	<div class="row mb-3">
		<div class="col-md-6">
			{{-- BASE CRM UPDATE --}}
			<x-core::field id="activity-page-lead_id:lead_id" label="Lead" lazy>
				<x-core::lookup
					extend_columns="date,account.primary_contact,contact.account,status"
					placeholder="Choose lead"
					source="Lead"
					:value="json_encode($data->lead)"
					link_url="/sales/lead/{id}"
				/>
			</x-core::field>
			{{-- END BASE CRM UPDATE --}}
		</div>
	</div>

	<div class="row">
		<div class="col-md-6">
			{{-- SALES UPDATE --}}
			<x-core::fieldset label="Sales" />

			<x-core::field id="activity-page-opportunity_id:opportunity_id" label="Opportunity" lazy>
				<x-core::lookup
					placeholder="Choose opportunity"
					extend_columns="date,customer.primary_contact,decision_maker.account,status,lead"
					source="Opportunity"
					:value="json_encode($data->opportunity)"
					link_url="/sales/opportunity/{id}"
				/>
			</x-core::field>

			<x-core::field label="Order" id="activity-page-order_id:order_id" lazy>
				<x-core::lookup
					placeholder="Choose order"
					source="Order"
					:value="json_encode($data->order)"
					link_url="/sales/order/{id}"
				/>
			</x-core::field>

			<x-core::field label="Invoice" id="activity-page-invoice_id:invoice_id" lazy>
				<x-core::lookup
					placeholder="Choose invoice"
					source="Invoice"
					:value="json_encode($data->invoice)"
					link_url="/sales/invoice/{id}"
				/>
			</x-core::field>
			{{-- END SALES UPDATE --}}
		</div>

		<div class="col-md-6">
			{{-- MARKETING UPDATE --}}
			<x-core::fieldset label="Marketing" />

			<x-core::field id="activity-page-email_blast_id:email_blast_id" label="Email Blast">
				<x-core::lookup
					placeholder="Choose email blast campaign"
					source="EmailBlast"
					:value="json_encode($data->email_blast)"
					link_url="/marketing/email-blast/{id}"
				/>
			</x-core::field>

			<x-core::field id="activity-page-wa_blast_id:wa_blast_id" label="WA Blast">
				<x-core::lookup
					placeholder="Choose whatsapp blast campaign"
					source="WaBlast"
					:value="json_encode($data->wa_blast)"
					link_url="/marketing/wa-blast/{id}"
				/>
			</x-core::field>

			<x-core::field id="activity-page-event_id:event_id" label="Event">
				<x-core::lookup
					placeholder="Choose event"
					source="Event"
					:value="json_encode($data->event)"
					link_url="/marketing/event/{id}"
				/>
			</x-core::field>
			{{-- END MARKETING UPDATE --}}
		</div>
	</div>
</x-core::tab-content>
