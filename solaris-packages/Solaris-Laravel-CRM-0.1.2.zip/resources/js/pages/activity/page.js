import BaseActivityPage from "@sales-js/pages/activity/page"

export default class ActivityPage extends BaseActivityPage {
}
