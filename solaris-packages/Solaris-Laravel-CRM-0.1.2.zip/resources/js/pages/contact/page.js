import BaseContactPage from "@sales-js/pages/contact/page"
import EventDetail from "@marketing-js/pages/contact/event-detail"
import EmailBlastDetail from "@marketing-js/pages/contact/email-blast-detail"
import WaBlastDetail from "@marketing-js/pages/contact/wa-blast-detail"

export default class ContactPage extends BaseContactPage {
	init() {
		super.init()
		this.registerDetail("contact-event", EventDetail, "contact_id")
		this.registerDetail("contact-email-blast", EmailBlastDetail, "contact_id")
		this.registerDetail("contact-wa-blast", WaBlastDetail, "contact_id")
	}
}
