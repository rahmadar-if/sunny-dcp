# Changelog

All notable changes to `solaris-laravel-crm` will be documented in this file.

---

## [v0.1.1] — 30 Jun 2026

### Fixed
- Added missing JS entry points `activity/page-index.js` and `contact/page-index.js` that instantiate their respective page classes

---

## [v0.1.0] — 29 Jun 2026

### Added
- Unified CRM layer built on top of `solaris-laravel-sales` and `solaris-laravel-marketing`
- Base service provider, facade, and package scaffolding
- **Contact module** — merged from sales & marketing: `Contact` model, `contact/page.js`
- **Activity module** — merged from sales & marketing: `Activity` model, `ActivityController`, `ActivityRequest`, `activity/page.blade.php`, `activity/sections/related-to.blade.php`, `activity/page.js`
- `MenuSeeder` with full CRM menu structure
- Config registration for models (`contact`, `activity`), controllers (`lead`, `activity`), form requests (`activity`), and view mappings

### Changed
- `config/solaris.php` — replaced `account` model binding with `contact` and `activity`; wired controllers, form requests, and views
- `SolarisCRMServiceProvider` — disabled auto-discovery and auto-run of migrations (opt-in)
- Bumped `solaris-laravel-sales` to `^v0.4.4`
- Bumped `solaris-laravel-marketing` to `^v0.3.4`

### Removed
- `resources/views/pages/account/page.blade.php` — account page view dropped
