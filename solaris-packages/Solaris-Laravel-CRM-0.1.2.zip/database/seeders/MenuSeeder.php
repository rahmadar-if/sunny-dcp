<?php

namespace Solaris\CRM\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Solaris\Core\Models\Menu;

class MenuSeeder extends Seeder
{
    public function run(): void
    {
        $this->dashboard();
    }

    protected function dashboard(): void
    {
        $dashboardId = Menu::select('id')
            ->where('name', 'Dashboard')
            ->whereHas('category', fn($query) => $query->where('name', 'Main'))
            ->first()
            ->id;

        $data = [
            [
                'id'          => "d7df2f71-77d2-40e8-9c84-dae6486130a9",
                'name'        => 'CRM',
                'position'    => 1,
                'url'         => "crm/dashboard",
                'route_name'  => "crm.dashboard",
                'icon'        => null,
                'is_category' => false,
                'parent_id'   => $dashboardId,
                'category_id' => null,
            ]
        ];

        DB::table('menus')->insertOrIgnore($data);
        
        DB::table('menus')
            ->where('id', '019ac81e-bf04-780f-a13f-c1e2a57c076f')
            ->update(['position' => 2]);

        DB::table('menus')
            ->where('id', '7261f70b-a71e-4df2-84e0-382afe4a1416')
            ->update(['position' => 3]);

        $leadMarketing = Menu::find("019c4aa5-0282-7bf6-88ea-eb3c6813741b");
        $leadMarketing?->delete();

        $menu = Menu::find("d7df2f71-77d2-40e8-9c84-dae6486130a9");
        $menu?->assignRole('User');
    }
}
