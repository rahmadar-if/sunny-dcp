<?php

// config for Solaris\CRM
return [

    /*
    |--------------------------------------------------------------------------
    | Resources
    |--------------------------------------------------------------------------
    */
    'resource' => [
        'path' => [
            'crm' => 'vendor/solaris/solaris-laravel-crm/resources',
        ],
        'views' => [
            'contact' => [
                'page' => 'crm::pages.contact.page',
            ],
            'activity' => [
                'page' => 'crm::pages.activity.page',
            ],
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Models
    |--------------------------------------------------------------------------
    */
    'model' => [
        'namespaces' => [
            'Solaris\CRM\Models' => base_path('vendor/solaris/solaris-laravel-crm/src/Models'),
        ],
        'models' => [
            'contact'  => 'Solaris\CRM\Models\Contact',
            'activity' => 'Solaris\CRM\Models\Activity',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Repositories
    |--------------------------------------------------------------------------
    */
    'repositories' => [],

    /*
    |--------------------------------------------------------------------------
    | HTTP Layer
    |--------------------------------------------------------------------------
    */
    'controller' => [
        'namespaces' => [
            'Solaris\CRM\Http\Controllers',
        ],
        'controllers' => [
            'activity' => 'Solaris\CRM\Http\Controllers\ActivityController',
        ],
    ],

    'form_requests' => [
        'activity' => 'Solaris\CRM\Http\Requests\ActivityRequest',
    ],

    /*
    |--------------------------------------------------------------------------
    | 3rd Party API
    |--------------------------------------------------------------------------
    */
    'api' => [
        'controllers' => [],
        'resources'   => [],
    ],

    /*
    |--------------------------------------------------------------------------
    | Mobile
    |--------------------------------------------------------------------------
    */
    'mobile' => [
        'controllers' => [],
        'resources'   => [],
    ],

    /*
    |--------------------------------------------------------------------------
    | AI
    |--------------------------------------------------------------------------
    */
    'ai' => [
        'tools' => [],
    ],
];
