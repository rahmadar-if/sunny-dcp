<?php

namespace Solaris\CRM;

use Illuminate\Support\Facades\Route;
use Spatie\LaravelPackageTools\Package;
use Spatie\LaravelPackageTools\PackageServiceProvider;

class SolarisCRMServiceProvider extends PackageServiceProvider
{
    public function configurePackage(Package $package): void
    {
        $package
            ->name('crm')
            ->hasConfigFile(['solaris'])
            ->hasViews('crm');
            // ->discoversMigrations()
            // ->runsMigrations();
    }

    public function packageBooted()
    {
        Route::middleware('web')
            ->group(__DIR__ . '/../routes/web.php');

        Route::middleware('api')
            ->prefix('api')
            ->group([
                __DIR__.'/../routes/api.php',
                __DIR__.'/../routes/mobile.php',
            ]);
    }
}
