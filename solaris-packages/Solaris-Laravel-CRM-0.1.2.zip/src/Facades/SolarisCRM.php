<?php

namespace Solaris\CRM\Facades;

use Illuminate\Support\Facades\Facade;

class SolarisCRM extends Facade
{
    protected static function getFacadeAccessor(): string
    {
        return \Solaris\CRM\SolarisCRM::class;
    }
}
