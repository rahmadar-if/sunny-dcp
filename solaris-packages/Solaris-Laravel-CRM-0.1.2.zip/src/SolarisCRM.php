<?php

namespace Solaris\CRM;

class SolarisCRM {}
