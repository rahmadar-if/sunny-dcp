<?php

namespace Solaris\CRM\Http\Controllers;

use Solaris\Sales\Http\Controllers\ActivityController as BaseActivityController;

class ActivityController extends BaseActivityController
{
    public function extendColumns(): array
    {
        return array_merge(parent::extendColumns(), [
            "event_id",
            "email_blast_id",
            "wa_blast_id",
        ]);
    }
}
