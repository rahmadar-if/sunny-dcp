<?php

namespace Solaris\CRM\Http\Requests;

use Solaris\Sales\Http\Requests\ActivityRequest as BaseActivityRequest;

class ActivityRequest extends BaseActivityRequest
{
    public static function createRules(): array
    {
        return array_merge(parent::createRules(), [
            'email_blast_id' => 'nullable|uuid',
            'wa_blast_id'    => 'nullable|uuid',
            'event_id'       => 'nullable|uuid',
        ]);
    }

    public static function updateRules(): array
    {
        return array_merge(parent::updateRules(), [
            'email_blast_id' => 'nullable|uuid',
            'wa_blast_id'    => 'nullable|uuid',
            'event_id'       => 'nullable|uuid',
        ]);
    }
}
