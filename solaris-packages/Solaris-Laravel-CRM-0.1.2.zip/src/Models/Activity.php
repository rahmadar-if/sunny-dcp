<?php

namespace Solaris\CRM\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Models\Activity as BaseActivity;

class Activity extends BaseActivity
{
    public function event(): BelongsTo
    {
        return $this->belongsTo(Helper::model('event'), 'event_id', 'id');
    }

    public function email_blast(): BelongsTo
    {
        return $this->belongsTo(Helper::model('email_blast'), 'email_blast_id', 'id');
    }

    public function wa_blast(): BelongsTo
    {
        return $this->belongsTo(Helper::model('wa_blast'), 'wa_blast_id', 'id');
    }

    public function importRules(): array
    {
        return array_merge(parent::importRules(), [
            'email_blast_id' => ['nullable', 'uuid'],
            'wa_blast_id'    => ['nullable', 'uuid'],
            'event_id'       => ['nullable', 'uuid'],
        ]);
    }
}
