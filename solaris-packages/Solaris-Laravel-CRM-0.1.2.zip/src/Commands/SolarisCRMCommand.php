<?php

namespace Solaris\CRM\Commands;

use Illuminate\Console\Command;

class SolarisCRMCommand extends Command
{
    public $signature = 'solaris-laravel-crm';

    public $description = 'My command';

    public function handle(): int
    {
        $this->comment('All done');

        return self::SUCCESS;
    }
}
