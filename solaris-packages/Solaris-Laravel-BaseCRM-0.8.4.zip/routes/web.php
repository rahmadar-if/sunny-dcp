<?php

use Illuminate\Support\Facades\Route;
use Solaris\Core\Helpers\Helper;

Route::middleware(['auth'])->group(function () {

    Route::prefix('crm')->group(function () {
        Route::prefix('lead')->group(function () {
            $leadController = Helper::controller('lead');

            Route::get('/', [$leadController, 'index'])->name('crm.lead');
            Route::get('/{id}', [$leadController, 'show'])->whereUuid('id')->name('crm.lead.read');
            Route::get('/edit/{id}', [$leadController, 'edit'])->whereUuid('id')->name('crm.lead.edit');
            Route::post('/{id}/create-account', [$leadController, 'createAccount'])->whereUuid('id')->name('crm.lead.create-account');
            Route::post('/{id}/create-contact', [$leadController, 'createContact'])->whereUuid('id')->name('crm.lead.create-contact');
        });
    });
});
