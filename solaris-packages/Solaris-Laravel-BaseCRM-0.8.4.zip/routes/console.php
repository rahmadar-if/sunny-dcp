<?php

use Illuminate\Support\Facades\Schedule;
use Solaris\BaseCRM\Jobs\FollowUpReminderNotification;
use Solaris\Core\Helpers\Helper;

$timezone = Helper::config('scheduler_timezone', 'UTC');

Schedule::job(new FollowUpReminderNotification())->everyMinute()->timezone($timezone);
