<?php

use Illuminate\Support\Facades\Route;
use Solaris\Core\Helpers\Helper;

// Only what BaseCRM adds on top of MasterData. The CRUD block stays where it was declared;
// swapping the controller is done through config, not by redeclaring routes.
Route::prefix('v1')
    ->middleware(['api.log', 'auth.api_key', 'throttle:api_key'])
    ->group(function () {
        Route::prefix('accounts')->group(function () {
            $controller = Helper::apiController('account');

            Route::post('/{id}/status', [$controller, 'updateStatus'])
                ->whereUuid('id')
                ->middleware(['permission:api.account.update-status', 'api.idempotency'])
                ->name('api.v1.account.update-status');
        });

        Route::prefix('contacts')->group(function () {
            $controller = Helper::apiController('contact');

            Route::post('/{id}/status', [$controller, 'updateStatus'])
                ->whereUuid('id')
                ->middleware(['permission:api.contact.update-status', 'api.idempotency'])
                ->name('api.v1.contact.update-status');
        });

        // Lead has no MasterData layer, so its CRUD block is declared here rather than extended.
        Route::prefix('leads')->group(function () {
            $controller = Helper::apiController('lead');

            Route::get('/', [$controller, 'index'])
                ->middleware('permission:api.lead.view')
                ->name('api.v1.lead.index');

            Route::post('/search', [$controller, 'search'])
                ->middleware('permission:api.lead.view')
                ->name('api.v1.lead.search');

            Route::post('/', [$controller, 'store'])
                ->middleware(['permission:api.lead.create', 'api.idempotency'])
                ->name('api.v1.lead.store');

            Route::get('/{id}', [$controller, 'show'])
                ->whereUuid('id')
                ->middleware('permission:api.lead.view')
                ->name('api.v1.lead.show');

            Route::patch('/{id}', [$controller, 'update'])
                ->whereUuid('id')
                ->middleware('permission:api.lead.update')
                ->name('api.v1.lead.update');

            Route::put('/{id}', [$controller, 'replace'])
                ->whereUuid('id')
                ->middleware('permission:api.lead.update')
                ->name('api.v1.lead.replace');

            Route::delete('/{id}', [$controller, 'destroy'])
                ->whereUuid('id')
                ->middleware('permission:api.lead.delete')
                ->name('api.v1.lead.destroy');

            Route::post('/{id}/status', [$controller, 'updateStatus'])
                ->whereUuid('id')
                ->middleware(['permission:api.lead.update-status', 'api.idempotency'])
                ->name('api.v1.lead.update-status');

            // No idempotency middleware on the conversions: they already refuse to duplicate an
            // existing near match, and would otherwise have two different meanings for one 409.
            Route::post('/{id}/account', [$controller, 'createAccount'])
                ->whereUuid('id')
                ->middleware('permission:api.lead.convert')
                ->name('api.v1.lead.create-account');

            Route::post('/{id}/contact', [$controller, 'createContact'])
                ->whereUuid('id')
                ->middleware('permission:api.lead.convert')
                ->name('api.v1.lead.create-contact');

            Route::put('/{id}/account', [$controller, 'updateAccount'])
                ->whereUuid('id')
                ->middleware('permission:api.lead.update')
                ->name('api.v1.lead.update-account');

            Route::put('/{id}/contact', [$controller, 'updateContact'])
                ->whereUuid('id')
                ->middleware('permission:api.lead.update')
                ->name('api.v1.lead.update-contact');
        });
    });
