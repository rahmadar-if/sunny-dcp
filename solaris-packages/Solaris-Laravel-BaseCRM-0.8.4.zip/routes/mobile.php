<?php

use Illuminate\Support\Facades\Route;
use Solaris\Core\Helpers\Helper;

Route::prefix('mobile')->group(function () {
    Route::middleware('auth.mobile')->group(function () {

        Route::prefix('master-data')->group(function () {
            Route::prefix('account')->group(function () {

                Route::put('/{id}/stage', [Helper::mobileController('account'), 'update'])
                    ->whereUuid('id')
                    ->name('mobile.master-data.account.update-stage');

                Route::prefix('bank')->group(function () {
                    $controller = Helper::mobileController('account_bank');

                    Route::post('/', [$controller, 'store'])
                        ->name('mobile.master-data.account-bank.store');

                    Route::put('/{id}', [$controller, 'update'])
                        ->name('mobile.master-data.account-bank.update');

                    Route::post('/list', [$controller, 'index'])
                        ->name('mobile.master-data.account-bank');

                    Route::get('/{id}', [$controller, 'show'])
                        ->whereUuid('id')
                        ->name('mobile.master-data.account-bank.read');

                    Route::delete('/{id}', [$controller, 'destroy'])
                        ->whereUuid('id')
                        ->name('mobile.master-data.account-bank.destroy');
                });

                Route::prefix('status-history')->group(function () {
                    $controller = Helper::mobileController('account_status_history');

                    Route::post('/list', [$controller, 'index'])
                        ->name('mobile.master-data.account-status-history');

                    Route::get('/{id}', [$controller, 'show'])
                        ->whereUuid('id')
                        ->name('mobile.master-data.account-status-history.read');
                });

            });

            Route::prefix('contact')->group(function () {

                Route::put('/{id}/stage', [Helper::mobileController('contact'), 'update'])
                    ->whereUuid('id')
                    ->name('mobile.master-data.contact.update-stage');

                Route::prefix('noteworthy-event')->group(function () {
                    $controller = Helper::mobileController('contact_noteworthy_event');

                    Route::post('/', [$controller, 'store'])
                        ->name('mobile.master-data.contact-noteworthy-event.store');

                    Route::put('/{id}', [$controller, 'update'])
                        ->name('mobile.master-data.contact-noteworthy-event.update');

                    Route::post('/list', [$controller, 'index'])
                        ->name('mobile.master-data.contact-noteworthy-event');

                    Route::get('/{id}', [$controller, 'show'])
                        ->whereUuid('id')
                        ->name('mobile.master-data.contact-noteworthy-event.read');

                    Route::delete('/{id}', [$controller, 'destroy'])
                        ->whereUuid('id')
                        ->name('mobile.master-data.contact-noteworthy-event.destroy');
                });

                Route::prefix('previous-company')->group(function () {
                    $controller = Helper::mobileController('contact_previous_company');

                    Route::post('/', [$controller, 'store'])
                        ->name('mobile.master-data.contact-previous-company.store');

                    Route::put('/{id}', [$controller, 'update'])
                        ->name('mobile.master-data.contact-previous-company.update');

                    Route::post('/list', [$controller, 'index'])
                        ->name('mobile.master-data.contact-previous-company');

                    Route::get('/{id}', [$controller, 'show'])
                        ->whereUuid('id')
                        ->name('mobile.master-data.contact-previous-company.read');

                    Route::delete('/{id}', [$controller, 'destroy'])
                        ->whereUuid('id')
                        ->name('mobile.master-data.contact-previous-company.destroy');
                });

                Route::prefix('status-history')->group(function () {
                    $controller = Helper::mobileController('contact_status_history');

                    Route::post('/list', [$controller, 'index'])
                        ->name('mobile.master-data.contact-status-history');

                    Route::get('/{id}', [$controller, 'show'])
                        ->whereUuid('id')
                        ->name('mobile.master-data.contact-status-history.read');
                });

            });

            Route::prefix('activity')->group(function () {

                Route::prefix('participant')->group(function () {
                    $controller = Helper::mobileController('activity_participant');

                    Route::post('/', [$controller, 'store'])
                        ->name('mobile.master-data.activity-participant.store');

                    Route::put('/{id}', [$controller, 'update'])
                        ->name('mobile.master-data.activity-participant.update');

                    Route::post('/list', [$controller, 'index'])
                        ->name('mobile.master-data.activity-participant');

                    Route::get('/{id}', [$controller, 'show'])
                        ->whereUuid('id')
                        ->name('mobile.master-data.activity-participant.read');

                    Route::delete('/{id}', [$controller, 'destroy'])
                        ->whereUuid('id')
                        ->name('mobile.master-data.activity-participant.destroy');
                });

                Route::prefix('promoted-product')->group(function () {
                    $controller = Helper::mobileController('activity_promoted_product');

                    Route::post('/', [$controller, 'store'])
                        ->name('mobile.master-data.activity-promoted-product.store');

                    Route::put('/{id}', [$controller, 'update'])
                        ->name('mobile.master-data.activity-promoted-product.update');

                    Route::post('/list', [$controller, 'index'])
                        ->name('mobile.master-data.activity-promoted-product');

                    Route::get('/{id}', [$controller, 'show'])
                        ->whereUuid('id')
                        ->name('mobile.master-data.activity-promoted-product.read');

                    Route::delete('/{id}', [$controller, 'destroy'])
                        ->whereUuid('id')
                        ->name('mobile.master-data.activity-promoted-product.destroy');
                });

            });
        });

        Route::prefix('crm')->group(function () {
            Route::prefix('lead')->group(function () {
                $controller = Helper::mobileController('lead');

                Route::post('/', [$controller, 'store'])
                    ->name('mobile.crm.lead.store');

                Route::put('/{id}/stage', [$controller, 'update'])
                    ->whereUuid('id')
                    ->name('mobile.crm.lead.update-stage');

                Route::put('/{id}', [$controller, 'update'])
                    ->name('mobile.crm.lead.update');

                Route::post('/list', [$controller, 'index'])
                    ->name('mobile.crm.lead');

                Route::get('/{id}', [$controller, 'show'])
                    ->whereUuid('id')
                    ->name('mobile.crm.lead.read');

                Route::delete('/{id}', [$controller, 'destroy'])
                    ->whereUuid('id')
                    ->name('mobile.crm.lead.destroy');

                Route::post('/{id}/account', [$controller, 'createAccount'])
                    ->whereUuid('id')
                    ->name('mobile.crm.lead.create-account');
                
                Route::post('/{id}/contact', [$controller, 'createContact'])
                    ->whereUuid('id')
                    ->name('mobile.crm.lead.create-contact');

                Route::put('/{id}/account', [$controller, 'updateAccount'])
                    ->whereUuid('id')
                    ->name('mobile.crm.lead.update-account');
                
                Route::put('/{id}/contact', [$controller, 'updateContact'])
                    ->whereUuid('id')
                    ->name('mobile.crm.lead.update-contact');

                Route::put('/{id}/follow-up', [$controller, 'updateFollowUp'])
                    ->whereUuid('id')
                    ->name('mobile.crm.lead.follow-up');

                Route::prefix('status-history')->group(function () {
                    $controller = Helper::mobileController('lead_status_history');

                    Route::post('/list', [$controller, 'index'])
                        ->name('mobile.crm.lead-status-history');

                    Route::get('/{id}', [$controller, 'show'])
                        ->whereUuid('id')
                        ->name('mobile.crm.lead-status-history.read');
                });
            });
        });
    });
});