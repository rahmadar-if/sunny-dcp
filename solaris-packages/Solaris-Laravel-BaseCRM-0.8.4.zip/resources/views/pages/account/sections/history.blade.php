@php
    $id = "account-page-tabs_history";
@endphp

<x-core::tab-content id="{{ $id }}" :active="$active ?? false" class="p-0 border-0">
    <x-core::tab id="{{ $id }}-tabs" variant="tab-style-7" class="scaleX p-0 mb-4">
        <x-slot:nav>
            <x-core::tab-nav id="{{ $id }}-tabs_activity" active>Activity</x-core::tab-nav>
            
            {{-- BASE CRM UPDATE --}}
            <x-core::tab-nav id="{{ $id }}-tabs_account_lead">Lead</x-core::tab-nav>
            <x-core::tab-nav id="{{ $id }}-tabs_status_history">Status History</x-core::tab-nav>
            {{-- END BASE CRM UPDATE --}}
        </x-slot>

        <x-slot:content>
            <x-core::tab-content id="{{ $id }}-tabs_activity" active class="p-0 border-0">
                @include("master-data::pages.account.activity.list", ["id" => $data->id])
            </x-core::tab-content>

            {{-- BASE CRM UPDATE --}}
            <x-core::tab-content id="{{ $id }}-tabs_account_lead" class="p-0 border-0">
                @include("base-crm::pages.account.lead.list", ["id" => $data->id])
            </x-core::tab-content>
            
            <x-core::tab-content id="{{ $id }}-tabs_status_history" class="p-0 border-0">
                @include('base-crm::pages.account.status-history.list', ['id' => $data->id])
            </x-core::tab-content>
            {{-- END BASE CRM UPDATE --}}
        </x-slot>
    </x-core::tab>
</x-core::tab-content>