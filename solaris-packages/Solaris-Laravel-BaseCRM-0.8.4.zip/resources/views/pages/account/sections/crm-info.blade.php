@php
    $id = "account-page-tabs_crm_information";
@endphp

<x-core::tab-content :id="$id" :active="$active ?? false" class="p-0 border-0">

    <x-core::fieldset label="Segmentation" />
    <div class="row">
        <div class="col-md-6">
            <x-core::field label="Customer journey" id="account-page-customer_journey_id:customer_journey_id">
                <x-core::lookup
                    :options="SolarHelper::model('customer_journey')::toSelect()"
                    placeholder="Choose customer journey"
                    :value="json_encode($data->customer_journey)" />
            </x-core::field>
        </div>
        <div class="col-md-6">
            <x-core::field label="Segmentation" id="account-page-segmentation_id:segmentation_id">
                <x-core::lookup
                    :options="SolarHelper::model('segmentation')::toSelect()"
                    placeholder="Specify the market segment"
                    :value="json_encode($data->segmentation)" />
            </x-core::field>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-md-6">
            <x-core::field label="Business size" id="account-page-business_size_id:business_size_id">
                <x-core::lookup
                    :options="SolarHelper::model('business_size')::toSelect()"
                    placeholder="Specify the size of your business"
                    :value="json_encode($data->business_size)" />
            </x-core::field>
        </div>
    </div>

    <x-core::fieldset label="RFM" />
    <div class="row">
        <div class="col-md-6">
            <x-core::field label="Recency" id="account-page-recency_date:recency_date">
                <x-core::date-picker
                    placeholder="Pick the most recent activity date"
                    :value="$data->recency_date" />
            </x-core::field>
        </div>
        <div class="col-md-6">
            <x-core::field label="Frequency type" id="account-page-frequency_type_id:frequency_type_id">
                <x-core::lookup
                    :options="SolarHelper::model('frequency_type')::toSelect()"
                    placeholder="Enter how often this occurs"
                    :value="json_encode($data->frequency_type)" />
            </x-core::field>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <x-core::field label="Monetary" id="account-page-monetary:monetary">
                <x-core::input
                    number
                    prefix="Rp"
                    placeholder="Enter the monetary value"
                    :value="$data->monetary" />
            </x-core::field>
        </div>
        <div class="col-md-6">
            <x-core::field label="Frequency" id="account-page-frequency:frequency">
                <x-core::input
                    number
                    placeholder="Enter how often this occurs"
                    :value="$data->frequency" />
            </x-core::field>
        </div>
    </div>

</x-core::tab-content>
