@php
    $id = "account-page-tabs_general_information";
@endphp

<x-core::tab-content :id="$id" :active="$active ?? false" class="p-0 border-0">

    <x-core::fieldset label="Identity" />
    <div class="row mb-3">
        <div class="col-md-6">
            <x-core::field label="Name" id="account-page-name:name" required>
                <x-core::input
                    placeholder="Type the account name here..."
                    :value="$data->name"/>
            </x-core::field>
        </div>
        <div class="col-md-6">
            <x-core::field label="Also known as" id="account-page-also_known_as:also_known_as">
                <x-core::input
                    placeholder="Enter any alternate names"
                    :value="$data->also_known_as"/>
            </x-core::field>
        </div>
    </div>

    <x-core::fieldset label="Classification" />
    <div class="row mb-3">
        <div class="col-md-6">
            <x-core::field label="Type" id="account-page-type_id:type_id" required>
                <x-core::lookup
                    :options="SolarHelper::model('account_type')::toSelect()"
                    placeholder="Choose account type"
                    :value="json_encode($data->type)"/>
            </x-core::field>

            <x-core::field label="Category" id="account-page-category:category" required>
                <x-core::input
                    placeholder="Type the category here"
                    :value="$data->category"/>
            </x-core::field>

            <x-core::field label="No. of employees" id="account-page-number_of_employee_id:number_of_employee_id">
                <x-core::lookup
                    :options="SolarHelper::model('number_of_employee')::toSelect()"
                    placeholder="Choose total number of employees"
                    :value="json_encode($data->number_of_employee)" />
            </x-core::field>
        </div>
        <div class="col-md-6">
            <x-core::field label="Industry" id="account-page-industry_id:industry_id" required>
                <x-core::lookup
                    :options="SolarHelper::model('industry')::toSelect()"
                    placeholder="Choose industry or sector"
                    :value="json_encode($data->industry)"/>
            </x-core::field>

            <x-core::field label="Business entity" id="account-page-business_entity_id:business_entity_id">
                <x-core::lookup
                    :options="SolarHelper::model('business_entity')::toSelect()"
                    placeholder="Choose business entity"
                    :value="json_encode($data->business_entity)"/>
            </x-core::field>

            {{-- BASE CRM UPDATE --}}
            <x-core::field label="Annual revenue" id="account-page-annual_revenue_id:annual_revenue_id">
                <x-core::lookup
                    placeholder="Choose annual revenue"
                    :options="SolarHelper::model('annual_revenue')::toSelect()"
                    :value="json_encode($data->annual_revenue)"/>
            </x-core::field>
            {{-- END BASE CRM UPDATE --}}
        </div>
    </div>

    <x-core::fieldset label="Contact" />
    <div class="row">
        <div class="col-md-6">
            <x-core::field label="Primary contact" id="account-page-primary_contact_id:primary_contact_id" lazy>
                <x-core::lookup
                    pagination
                    source="Contact"
                    :value="json_encode($data->primary_contact)"
                    placeholder="Choose the primary contact"
                    link_url="/master-data/contact/{id}"
                    extend_columns="job_title" />
            </x-core::field>

            <x-core::field label="Primary phone" id="account-page-primary_phone:primary_phone" required>
                <x-core::input
                    phone="ID"
                    placeholder="Enter the primary phone number"
                    :value="$data->primary_phone"/>
            </x-core::field>

            <x-core::field label="Owner" id="account-page-created_by_id" disabled>
                <x-core::input
                    :value="$data->created_by?->name"/>
            </x-core::field>
        </div>
        <div class="col-md-6">
            <x-core::field label="Email address" id="account-page-email:email" required>
                <x-core::input
                    placeholder="Provide an email address"
                    :value="$data->email"/>
            </x-core::field>

            <x-core::field label="Website" id="account-page-website:website">
                <x-core::input
                    placeholder="Enter the website URL"
                    :value="$data->website"/>
            </x-core::field>
        </div>
    </div>


</x-core::tab-content>
