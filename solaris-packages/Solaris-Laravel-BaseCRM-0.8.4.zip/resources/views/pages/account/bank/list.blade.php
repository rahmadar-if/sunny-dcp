<x-core::table
    id="account-bank_list" 
    class="table-hover"
    model="AccountBank"
    new="@account-bank-modal"
    import export delete_all
    :card_wrapper="false"
    filter="account_id = {{ $id }}">

    <x-slot:column>
        <x-core::table-action-column :view="false"/>

        <x-core::table-column 
            data="bank_name" 
            searchable 
            orderable>
            Name Of Bank
        </x-core::table-column>
        
        <x-core::table-column 
            data="account_number" 
            searchable 
            orderable>
            Account Number
        </x-core::table-column>
        
        <x-core::table-column 
            data="account_name" 
            searchable 
            orderable>
            Account Name
        </x-core::table-column>
        
        <x-core::table-column 
            data="country.name" 
            searchable 
            orderable>
            Country
        </x-core::table-column>
    </x-slot>

</x-core::table>

@push('modal-content')
    @include("base-crm::pages.account.bank.modal")
@endpush