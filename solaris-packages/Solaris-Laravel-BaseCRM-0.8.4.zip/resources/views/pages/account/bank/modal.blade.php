<x-core::modal-form
	id="account-bank-modal"
	title="Account Bank"
    model="AccountBank"
    size="md">

    <x-core::field id="account-bank-modal-bank_name:bank_name" label="Name of bank" required>
        <x-core::input
            placeholder="e.g., BCA, BNI, Mandiri..."
        />
    </x-core::field>
    <x-core::field id="account-bank-modal-account_number:account_number" label="Account number" required>
        <x-core::input
            numeric blocks="255"
            placeholder="Enter account number without space"
        />
    </x-core::field>
    <x-core::field id="account-bank-modal-account_name:account_name" label="Account name" required>
        <x-core::input
            placeholder="Account holder's name as registered"
        />
    </x-core::field>
    <x-core::field id="account-bank-modal-country_id:country_id" label="Country">
        <x-core::lookup
            pagination
            placeholder="Choose the bank's country"
            Source="Country"
        />
    </x-core::field>

</x-core::modal-form>
