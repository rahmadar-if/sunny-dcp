<x-core::page.edit
    :id="$data->id"
    title="Account"
    :breadcrumbs="$breadcrumbs"
    model="Account"
    package="base-crm"
    path="account/page-index">

    {{-- BASE CRM UPDATE --}}
    <x-slot:header>
        <div class="row mb-3">
            <div class="col">
                <x-core::stage-buttons 
                    id="account-page-status_id:status_id" 
                    :stages="SolarHelper::model('account_status')::toStage(confirm: true)"
                    mode="next-prev"
                    final 
                    :value="$data->status_id" />
            </div>
        </div>
    </x-slot>
    {{-- END BASE CRM UPDATE --}}

    @php
        $tabId = "account-page-tabs";
    @endphp

    <x-core::tab id="{{ $tabId }}" class="p-0 mb-4">
        <x-slot:nav>
            <x-core::tab-nav id="{{ $tabId }}_general_information" active>General Information</x-core::tab-nav>
            
            {{-- BASE CRM UPDATE --}}
            <x-core::tab-nav id="{{ $tabId }}_crm_information">CRM Information</x-core::tab-nav>
            {{-- END BASE CRM UPDATE --}}
            
            <x-core::tab-nav id="{{ $tabId }}_detail_information">Detail Information</x-core::tab-nav>
            <x-core::tab-nav id="{{ $tabId }}_history">History</x-core::tab-nav>
            <x-core::tab-nav id="{{ $tabId }}_attachment">Attachment</x-core::tab-nav>
            <x-core::tab-nav id="{{ $tabId }}_notes">Notes</x-core::tab-nav>
        </x-slot>

        <x-slot:content>
            {{-- BASE CRM UPDATE --}}
            @include('base-crm::pages.account.sections.general-info', ["data" => $data, "active" => true])
            @include('base-crm::pages.account.sections.crm-info', ["data" => $data])
            @include('base-crm::pages.account.sections.detail-info', ["data" => $data])
            @include('base-crm::pages.account.sections.history', ["data" => $data])
            {{-- END BASE CRM UPDATE --}}

            <x-core::tab-content id="{{ $tabId }}_attachment" class="p-0 border-0">
                <x-core::attachment id="account-page-attachment" relation="accounts:{{ $data->id }}"/>
            </x-core::tab-content>

            <x-core::tab-content id="{{ $tabId }}_notes" class="p-0 border-0">
                <x-core::notes 
                    id="account-page-notes:notes"
                    model="Account"
                    column="notes"
                    :record_id="$data->id">{!! $data->notes !!}</x-notes>
            </x-core::tab-content>
        </x-slot>

    </x-core::tab>

    <x-slot:profile>
        @include('master-data::pages.account.sections.profile-container', ["data" => $data])
    </x-slot>

</x-core::page.edit>