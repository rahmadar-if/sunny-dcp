<x-core::table
    id="account-status-history_list"
    class="table-hover"
    model="AccountStatusHistory"
    :new="false"
    :import="false"
    export lazy
    :card_wrapper="false"
    filter="account_id = {{ $id }}">

    <x-slot:column>
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="status.name" 
            searchable 
            orderable>
            Status
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="start" 
            searchable 
            orderable
            type="datetime">
            Start
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="end" 
            searchable 
            orderable
            type="datetime">
            End
        </x-core::table-column>
    </x-slot>

</x-core::table>