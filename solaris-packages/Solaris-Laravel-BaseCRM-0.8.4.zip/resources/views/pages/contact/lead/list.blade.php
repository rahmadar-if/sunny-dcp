<x-core::table
    id="contact-lead_list" 
    class="table-hover"
    model="Lead"
    :new="false"
    export lazy delete_all
    extend_columns="date"
    :card_wrapper="false"
    filter="contact_id = {{ $id }}">

    <x-slot:column>
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="name" 
            searchable 
            orderable>
            Name
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="status.name" 
            searchable 
            orderable>
            Status
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="budget_range.name" 
            searchable 
            orderable>
            Budget
        </x-core::table-column>
        
        <x-core::table-column 
            data="customer_need" 
            searchable 
            orderable
            expand>
            Customer Need
        </x-core::table-column>
    </x-slot>

</x-core::table>