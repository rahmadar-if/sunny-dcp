<x-core::table
    id="contact-noteworthy-event_list" 
    class="table-hover"
    model="ContactNoteworthyEvent"
    new="@contact-noteworthy-event-modal"
    import export delete_all
    :card_wrapper="false"
    filter="contact_id = {{ $id }}">

    <x-slot:column>
        <x-core::table-action-column :view="false"/>

        <x-core::table-column 
            name="type_id" 
            data="type.name" 
            searchable 
            orderable>
            Type
        </x-table-column>

        <x-core::table-column 
            data="date" 
            searchable 
            orderable>
            Date
        </x-table-column>
        
        <x-core::table-column 
            data="notes" 
            searchable 
            orderable>
            Notes
        </x-table-column>
    </x-slot>

</x-core::table>

@push('modal-content')
    @include("base-crm::pages.contact.noteworthy-event.modal")
@endpush