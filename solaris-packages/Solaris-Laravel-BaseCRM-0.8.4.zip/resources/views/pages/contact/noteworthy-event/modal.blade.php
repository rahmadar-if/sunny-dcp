<x-core::modal-form
	id="contact-noteworthy-event-modal"
	title="Contact noteworthy event"
    model="ContactNoteworthyEvent"
    size="md">

    <x-core::field label="Type" id="contact-noteworthy-modal-type_id:type_id" required>
        <x-core::lookup
            placeholder="Choose event type"
            :options="SolarHelper::model('noteworthy_event_type')::toSelect()"
        />
    </x-core::field>

    <x-core::field label="Date" id="contact-noteworthy-modal-date:date" required>
        <x-core::date-picker
            placeholder="Pick a date for the event"
        />
    </x-core::field>

    <x-core::field label="Notes" id="contact-noteworthy-modal-notes:notes">
        <x-core::textarea
            label="Notes"
            placeholder="Add any important details or reminders"
        />
    </x-core::field>

</x-core::modal-form>
