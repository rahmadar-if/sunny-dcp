<x-core::table
    id="contact-previous-company_list" 
    class="table-hover"
    model="ContactPreviousCompany"
    new="@contact-previous-company-modal"
    import export lazy delete_all
    :card_wrapper="false"
    filter="contact_id = {{ $id }}">

    <x-slot:column>
        <x-core::table-action-column :view="false"/>

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="account.name" 
            lookup="profile_picture_id" 
            searchable 
            orderable>
            Account
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="role" 
            searchable 
            orderable>
            Role
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="start_date" 
            searchable 
            orderable>
            Start Date
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="end_date" 
            searchable 
            orderable>
            End Date
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="active" 
            searchable 
            orderable>
            Status
        </x-core::table-column>
    </x-slot>

</x-core::table>

@push('modal-content')
    @include("base-crm::pages.contact.previous-company.modal")
@endpush