<x-core::modal-form
	id="contact-previous-company-modal"
	title="Contact Previous Company"
    model="ContactPreviousCompany"
    size="md">

    <x-core::field label="Account" id="contact-previous-company-modal-account_id:account_id" required>
        <x-core::lookup
            placeholder="Choose Account"
            Source="Account"
            pagination
            link_url="/master-data/account/{id}"
        />
    </x-core::field>

    <x-core::field label="Start date" id="contact-previous-company-modal-start_date:start_date" required>
        <x-core::date-picker
            placeholder="Pick a start date"
        />
    </x-core::field>

    <x-core::field label="End date" id="contact-previous-company-modal-end_date:end_date">
        <x-core::date-picker
            placeholder="Pick a end date"
        />
    </x-core::field>

    <x-core::field label="Role" id="contact-previous-company-modal-role:role" required>
        <x-core::input
            placeholder="Position or role within the organization"
        />
    </x-core::field>

    <x-core::field id="contact-previous-company-modal-active:active">
        <x-core::checkbox
            label="Active"
        />
    </x-core::field>

</x-core::modal-form>
