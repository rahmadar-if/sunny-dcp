<x-core::page.list
    id="contact"
    title="Contact"
    class="table-hover"
    :breadcrumbs="$breadcrumbs"
    model="Contact"
    package="base-crm"
    path="contact/list-index"
    new="@contact-modal"
    :order_by="['name:asc', 'account.name:asc']"
    import export folder lazy delete_all
    extend_columns="primary_mobile_phone,email,profile_picture_id">
    
    <x-slot:table-column>
        <x-core::table-action-column :view="false" />
            
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="name" 
            searchable 
            orderable>
            Name
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="account.name" 
            lookup="primary_phone,email,profile_picture_id" 
            searchable 
            orderable>
            Account
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="job_title" 
            searchable 
            orderable>
            Job Title
        </x-core::table-column>

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="status.name" 
            searchable 
            orderable>
            Status
        </x-core::table-column>
    </x-slot>

    @push('modal-content')
        @include("master-data::pages.contact.modal")
    @endpush

</x-core::page.list>