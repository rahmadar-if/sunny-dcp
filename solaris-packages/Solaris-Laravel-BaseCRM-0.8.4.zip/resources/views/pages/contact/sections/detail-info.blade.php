@php
    $id = "contact-page-tabs_detail_info";
@endphp

<x-core::tab-content :id="$id" :active="$active ?? false" class="p-0 border-0">
    <div class="row">
        <div class="col">
            <x-core::tab id="{{ $id }}-tabs" variant="tab-style-7" class="scaleX p-0 mb-4">
                <x-slot:nav>
                    <x-core::tab-nav id="{{ $id }}-tabs_address" active>Address</x-core::tab-nav>
                    <x-core::tab-nav id="{{ $id }}-tabs_communication">Communication</x-core::tab-nav>
                    <x-core::tab-nav id="{{ $id }}-tabs_hobby">Hobby</x-core::tab-nav>

                    {{-- BASE CRM UPDATE --}}
                    <x-core::tab-nav id="{{ $id }}-tabs_noteworthy_event">Noteworthy Event</x-core::tab-nav>
                    <x-core::tab-nav id="{{ $id }}-tabs_related_contact">Related Contact</x-core::tab-nav>
                    <x-core::tab-nav id="{{ $id }}-tabs_previous_company">Previous Company</x-core::tab-nav>
                    {{-- END BASE CRM UPDATE --}}
                </x-slot>

                <x-slot:content>
                    <x-core::tab-content id="{{ $id }}-tabs_address" active class="p-0 border-0">
                        @include('master-data::pages.contact.address.list', ['id' => $data->id])
                    </x-core::tab-content>

                    <x-core::tab-content id="{{ $id }}-tabs_communication" class="p-0 border-0">
                        @include('master-data::pages.contact.communication.list', ['id' => $data->id])
                    </x-core::tab-content>

                    <x-core::tab-content id="{{ $id }}-tabs_hobby" class="p-0 border-0">
                        @include('master-data::pages.contact.hobby.list', ['id' => $data->id])
                    </x-core::tab-content>

                    {{-- BASE CRM UPDATE --}}
                    <x-core::tab-content id="{{ $id }}-tabs_noteworthy_event" class="p-0 border-0">
                        @include("base-crm::pages.contact.noteworthy-event.list", ["id" => $data->id])
                    </x-core::tab-content>

                    <x-core::tab-content id="{{ $id }}-tabs_related_contact" class="p-0 border-0">
                        @include('master-data::pages.contact.related-contact.list', ['id' => $data->id])
                    </x-core::tab-content>

                    <x-core::tab-content id="{{ $id }}-tabs_previous_company" class="p-0 border-0">
                        @include("base-crm::pages.contact.previous-company.list", ["id" => $data->id])
                    </x-core::tab-content>
                    {{-- END BASE CRM UPDATE --}}
                </x-slot>
            </x-core::tab>
        </div>
    </div>
</x-core::tab-content>