<x-core::page.edit
    :id="$data->id"
    title="Contact"
    :breadcrumbs="$breadcrumbs"
    model="Contact"
    package="base-crm"
    path="contact/page-index">

    {{-- BASE CRM UPDATE --}}
    <x-slot:header>
        <div class="row mb-3">
            <div class="col">
                <x-core::stage-buttons 
                    id="contact-page-status_id:status_id" 
                    :stages="SolarHelper::model('contact_status')::toStage(confirm: true)"
                    mode="next-prev"
                    final
                    :value="$data->status_id" />
            </div>
        </div>
    </x-slot>
    {{-- END BASE CRM UPDATE --}}

    @php
        $tabId = "contact-page-tabs";
    @endphp

    <x-core::tab id="{{ $tabId }}" class="p-0 mb-4">
        <x-slot:nav>
            <x-core::tab-nav id="{{ $tabId }}_general_information" active>General Information</x-core::tab-nav>
            <x-core::tab-nav id="{{ $tabId }}_detail_info">Detail Information</x-core::tab-nav>
            <x-core::tab-nav id="{{ $tabId }}_history">History</x-core::tab-nav>
            <x-core::tab-nav id="{{ $tabId }}_attachment">Attachment</x-core::tab-nav>
            <x-core::tab-nav id="{{ $tabId }}_notes">Notes</x-core::tab-nav>
        </x-slot>

        <x-slot:content>
            {{-- BASE CRM UPDATE --}}
            @include('base-crm::pages.contact.sections.general-info', ["data" => $data, "active" => true])
            @include('base-crm::pages.contact.sections.detail-info', ["data" => $data])
            @include('base-crm::pages.contact.sections.history', ["data" => $data])
            {{-- END BASE CRM UPDATE --}}

            <x-core::tab-content id="{{ $tabId }}_attachment" class="p-0 border-0">
                <x-core::attachment id="contact-attachment-table" relation="contacts:{{ $data->id }}"/>
            </x-core::tab-content>

            <x-core::tab-content id="{{ $tabId }}_notes" class="p-0 border-0">
                <x-core::notes 
                    id="contact-notes:notes"
                    model="Contact"
                    column="notes"
                    :record_id="$data->id">{!! $data->notes !!}</x-core::notes>
            </x-core::tab-content>
        </x-slot>
    </x-core::tab>

    <x-slot:profile>
        @include('master-data::pages.contact.sections.profile-container', ["data" => $data])
    </x-slot>

</x-core::page.edit>