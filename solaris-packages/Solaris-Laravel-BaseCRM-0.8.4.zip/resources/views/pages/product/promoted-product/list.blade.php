<x-core::table
    id="promoted-product_list" 
    class="table-hover"
    model="ActivityPromotedProduct"
    :new="false"
    :import="false"
    export lazy delete_all
    filter="product_id = {{ $id }}">

    <x-slot:column>
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="activity.subject" 
            searchable 
            orderable>
            Activity
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="date" 
            searchable 
            orderable>
            Date
        </x-core::table-column>
        
        <x-core::table-column 
            data="status" 
            searchable 
            orderable>
            Status
        </x-core::table-column>
    </x-slot>

</x-table>