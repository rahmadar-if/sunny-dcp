<x-core::page.edit
	:id="$data->id"
	title="Activity"
	:breadcrumbs="$breadcrumbs"
	model="Activity"
	package="base-crm"
	path="activity/page-index"
	profile-position="left">

	<x-slot:profile>
		@include('master-data::pages.activity.sections.profile-container', ["data" => $data])

		{{-- BASE CRM UPDATE --}}
		<x-core::card>
			<x-core::field id="activity-page-lead_id:lead_id" label="Lead" lazy>
				<x-core::lookup
					extend_columns="date,account.primary_contact,contact.account,status"
					placeholder="Choose lead"
					source="Lead"
					:value="json_encode($data->lead)"
				/>
			</x-core::field>
		</x-core::card>
		{{-- END BASE CRM UPDATE --}}

		@include('master-data::pages.activity.sections.reminder', ["data" => $data])
	</x-slot>

	@php $tabId = "activity-page-tabs"; @endphp

	{{-- BASE CRM UPDATE --}}
	<x-core::tab id="{{ $tabId }}" class="p-0 mb-4">
		<x-slot:nav>
			<x-core::tab-nav id="{{ $tabId }}_info" active>Info</x-core::tab-nav>
			<x-core::tab-nav id="{{ $tabId }}_notes_files">Notes & Files</x-core::tab-nav>
		</x-slot>

		<x-slot:content>
			@include('base-crm::pages.activity.sections.info', ['data' => $data, 'active' => true])
			@include('master-data::pages.activity.sections.notes-files', ['data' => $data, 'active' => false])
		</x-slot>
	</x-core::tab>
	{{-- END BASE CRM UPDATE --}}

</x-core::page.edit>
