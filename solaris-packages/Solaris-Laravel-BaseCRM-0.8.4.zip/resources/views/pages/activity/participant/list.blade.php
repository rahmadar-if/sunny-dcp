<x-core::table
    id="activity-participant_list" 
    class="table-hover"
    model="ActivityParticipant"
    new="@activity-participant-modal"
    import export lazy delete_all
    filter="activity_id = {{ $id }}">
    
    <x-slot:column>
        <x-core::table-action-column :view="false"/>

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="name" 
            searchable>
            Name
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="role" 
            searchable>
            Role
        </x-core::table-column>
        
        <x-core::table-column 
            data="notes" 
            searchable>
            Notes
        </x-core::table-column>
    </x-slot>
</x-table>

@push('modal-content')
    @include('base-crm::pages.activity.participant.modal')
@endpush