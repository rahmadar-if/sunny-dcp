<x-core::modal-form
	id="activity-participant-modal"
	title="Participant"
    model="ActivityParticipant"
    size="md">

   <x-core::field label="Name" id="activity-participant-modal-name:name" required>
        <x-core::input
            id="activity-participant-modal-name"
            placeholder="Who's joining? Full name, please"
        />
    </x-core::field>

    <x-core::field label="Role" id="activity-participant-modal-role:role" required>
        <x-core::input
            label="Role"
            id="activity-participant-modal-role"
            placeholder="What's their role in the activity?"
        />
    </x-core::field>

    <x-core::field label="Note" id="activity-participant-modal-notes:notes">
        <x-core::textarea
            label="Note"
            id="activity-participant-modal-notes"
            placeholder="Any additional information"
        />
    </x-core::field>

</x-core::modal-form>