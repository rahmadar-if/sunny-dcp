@php
	$id = "activity-page-tabs_info";
@endphp

<x-core::tab-content :id="$id" :active="$active ?? false" class="p-0 border-0">
	<x-core::tab id="{{ $id }}-tabs" variant="tab-style-7" class="scaleX p-0 mb-4">
		<x-slot:nav>
			<x-core::tab-nav id="activity-page-tabs_general_information" active>General Information</x-core::tab-nav>

			{{-- BASE CRM UPDATE --}}
			<x-core::tab-nav id="activity-page-tabs_detail_information">Detail Information</x-core::tab-nav>
			{{-- END BASE CRM UPDATE --}}
		</x-slot>

		<x-slot:content>
			{{-- BASE CRM UPDATE --}}
			@include('base-crm::pages.activity.sections.general-info', ['data' => $data, 'active' => true])
			@include('base-crm::pages.activity.sections.detail-info', ['data' => $data, 'active' => false])
			{{-- END BASE CRM UPDATE --}}
		</x-slot>
	</x-core::tab>
</x-core::tab-content>
