@php
    $id = "activity-page-tabs_general_information";
@endphp

<x-core::tab-content :id="$id" :active="$active ?? false" class="p-0 border-0">
    <div class="row">
        <div class="col">
            <x-core::field label="Subject" id="activity-page-subject:subject" required>
                <x-core::input
                    placeholder="Subject"
                    :value="$data->subject" />
            </x-core::field>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6">
            <x-core::field label="Priority" id="activity-page-priority_id:priority_id" required>
                <x-core::lookup
                    placeholder="Choose priority"
                    :options="SolarHelper::model('activity_priority')::toSelect()"
                    :value="json_encode($data->priority)" />
            </x-core::field>

            <x-core::field label="Category" id="activity-page-category_id:category_id" required>
                <x-core::lookup
                    placeholder="Choose category"
                    :options="SolarHelper::model('activity_category')::toSelect()"
                    :value="json_encode($data->category)"
                />
            </x-core::field>

            <x-core::field id="activity-page-status_id:status_id" label="Status">
                <x-core::lookup
                    label="Status"
                    placeholder="Choose Status"
                    :options="SolarHelper::model('activity_status')::toSelect()"
                    :value="json_encode($data->status)" />
            </x-core::field>
        </div>
        <div class="col-lg-6">
            <x-core::field label="Start date" id="activity-page-start_date:start_date" required>
                <x-core::date-picker
                    mode="datetime"
                    placeholder="Select start date"
                    :value="$data->start_date?->toJSON()"
                />
            </x-core::field>

            <x-core::field label="End date" id="activity-page-end_date:end_date">
                <x-core::date-picker
                    mode="datetime"
                    placeholder="Select end date"
                    :value="$data->end_date?->toJSON()"
                />
            </x-core::field>

            {{-- BASE CRM UPDATE --}}
            <x-core::field id="activity-page-result_id:result_id" label="Result">
                <x-core::lookup
                    placeholder="Choose Result"
                    :options="SolarHelper::model('activity_result')::toSelect()"
                    :value="json_encode($data->result)" />
            </x-core::field>
            {{-- END BASE CRM UPDATE --}}
        </div>
    </div>

    {{-- BASE CRM UPDATE --}}
    <x-core::field id="activity-page-detail_result:detail_result" label="Detail result">
        <x-core::textarea
            placeholder="Detail Result"
            rows="4"
            :value="$data->detail_result" />
    </x-core::field>
    {{-- END BASE CRM UPDATE --}}
</x-core::tab-content>
