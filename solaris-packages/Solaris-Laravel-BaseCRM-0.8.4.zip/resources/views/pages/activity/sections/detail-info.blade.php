@php
    $id = "activity-page-tabs_detail_information";
@endphp

<x-core::tab-content :id="$id" class="p-0 border-0">
    <x-core::tab id="{{ $id }}-tabs" class="scaleX p-0 mb-4" variant="tab-style-7">
        <x-slot:nav>
            <x-core::tab-nav id="{{ $id }}-tabs_participant" active>Participant</x-tab-nav>
            <x-core::tab-nav id="{{ $id }}-tabs_product">Promoted product</x-tab-nav>
        </x-slot>

        <x-slot:content>
            <x-core::tab-content id="{{ $id }}-tabs_participant" active class="p-0 border-0">
                @include('base-crm::pages.activity.participant.list', ['id' => $data->id])
            </x-core::tab-content>

            <x-core::tab-content id="{{ $id }}-tabs_product" class="p-0 border-0">
                @include('base-crm::pages.activity.promoted-product.list', ['id' => $data->id])
            </x-core::tab-content>
        </x-slot>
    </x-core::tab>
</x-core::tab-content>