<x-core::modal-form
	id="activity-promoted-product-modal"
	title="Promoted Product"
    model="ActivityPromotedProduct"
    size="md">

    <x-core::field label="Product" id="activity-promoted-product-modal-product_id:product_id" required>
        <x-core::lookup
            placeholder="Choose Product"
            source="Product@availableInActivityPromotedProduct({{ $id }})"
            link_url="/master-data/product/{id}"
        />
    </x-core::field>

    <x-core::field label="Date" id="activity-promoted-product-modal-date:date" required>
        <x-core::date-picker placeholder="Select date" />
    </x-core::field>

    <x-core::field label="Status" id="activity-promoted-product-modal-status:status">
        <x-core::textarea
            placeholder="Enter status product"
        />
    </x-core::field>

</x-core::modal-form>
