<x-core::table
    id="activity-promoted-product_list" 
    class="table-hover"
    model="ActivityPromotedProduct"
    new="@activity-promoted-product-modal"
    import export lazy delete_all
    filter="activity_id = {{ $id }}">

    <x-slot:column>
        <x-core::table-action-column :view="false"/>

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="product.name" 
            searchable 
            orderable>
            Product
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="date" 
            searchable 
            orderable>
            Date
        </x-core::table-column>
        
        <x-core::table-column 
            data="status" 
            searchable 
            orderable>
            Status
        </x-core::table-column>
    </x-slot>

</x-table>

@push('modal-content')
    @include('base-crm::pages.activity.promoted-product.modal')
@endpush