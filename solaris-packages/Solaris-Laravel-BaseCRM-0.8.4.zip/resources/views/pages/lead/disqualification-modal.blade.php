<x-core::modal 
    id="disqualification-modal"
    body:class="p-3 p-lg-4" 
    animation="scale" 
    center
    static 
    size="md">
    
    <x-slot:header class="border-0">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </x-slot>

    <div class="text-center mb-3">
        <h4 class="mb-2">Disqualification Reason</h4>
    </div>

    <div class="p-lg-4 p-2">            
        <x-core::field label="Reason" id="disqualification-modal-disqualification_reason_id" required>
            <x-core::lookup
                placeholder="Choose reason"
                :options="SolarHelper::model('disqualification_reason')::toSelect()"
            />
        </x-core::field>

        <x-core::field id="disqualification-modal-disqualification_reason_text" label="Another Reason" hidden>
            <x-core::textarea
                placeholder="Enter another reason" />
        </x-core::field>

        <div class="hstack gap-2 justify-content-center mt-4">
            <x-core::button id="disqualification-modal_save" type="submit">Save</x-core::button>
            <x-core::button data-bs-dismiss="modal" color="light" aria-label="Close">Cancel</x-core::button>
        </div>

    </div>
</x-core::modal>