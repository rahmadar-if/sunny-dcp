<x-core::modal-form
    id="lead-modal"
    title="Lead"
    model="Lead">

    <div class="row">
        <div class="col-lg-6">
            <x-core::field id="lead-modal-date:date" label="Date" required>
                <x-core::date-picker
                    placeholder="Select lead date" />
            </x-core::field>

            <x-core::field id="lead-modal-name:name" label="Name" required>
                <x-core::input
                    placeholder="Enter prospect's name or company name" />
            </x-core::field>
        </div>

        <div class="col-lg-6">
            <x-core::field id="lead-modal-phone:phone" label="Phone Number">
                <x-core::input
                    phone="ID"
                    placeholder="Enter phone number (required if no email)" />
            </x-core::field>

            <x-core::field id="lead-modal-email:email" label="Email">
                <x-core::input
                    placeholder="Enter email address (required if no phone)" />
            </x-core::field>
        </div>
    </div>

    <div class="row">
        <div class="col">
            <x-core::field id="lead-modal-customer_need:customer_need" label="Customer Need" required>
                <x-core::textarea
                    placeholder="Briefly describe the customer's needs or requirements (min 10 characters)" />
            </x-core::field>
        </div>
    </div>
</x-core::modal-form>
