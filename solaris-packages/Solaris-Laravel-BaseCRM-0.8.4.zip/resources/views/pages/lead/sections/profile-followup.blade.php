@php
    $followUpDate   = $data->follow_up_date;
    $remindMe       = !is_null($data->follow_up_remind_at);
    $reminderActive = $followUpDate && $followUpDate->startOfDay() > now()->startOfDay();
@endphp

<x-core::card>

    <x-core::field id="lead-page-follow_up_date:follow_up_date" label="Follow Up Date">
        <x-core::date-picker
            placeholder="Select follow up date"
            :value="$data->follow_up_date" />
    </x-core::field>

    <hr class="my-3">

    <x-core::checkbox
        id="lead-page-remind_me"
        label="Remind me"
        wrap:class="mb-3"
        switch
        :checked="$remindMe"
        :disabled="!$reminderActive" />

    <x-core::date-picker 
        id="lead-page-follow_up_remind_at:follow_up_remind_at"
        mode="datetime"
        :value="$data->follow_up_remind_at?->toJSON()"
        hidden />

    <x-core::field id="lead-page-follow_up_remind_time" label="Remind at" :hidden="!$remindMe">
        <x-core::date-picker
            mode="time"
            :value="$data->follow_up_remind_at?->toJSON()"
            placeholder="Select reminder time" />
    </x-core::field>

    <x-core::checkbox
        id="lead-page-add_to_calendar:add_to_calendar"
        label="Add to calendar"
        switch
        :checked="$data->add_to_calendar ?? false" />

</x-core::card>
