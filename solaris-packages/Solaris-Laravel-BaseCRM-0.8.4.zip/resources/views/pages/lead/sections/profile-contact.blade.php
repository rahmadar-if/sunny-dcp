@php
    use Solaris\BaseCRM\Const\LeadStatusConst;

    $account        = $data->account;
    $contact        = $data->contact;
    $owner          = $data->created_by;
    $ownerPictureId = $owner?->profile_picture_id;
    $accountLinked  = (bool) $data->account_id;
    $contactLinked  = (bool) $data->contact_id;
    $isQualified    = $data->status_id === LeadStatusConst::Qualified;
    $isDisqualified = $data->status_id === LeadStatusConst::Disqualified;
@endphp

<x-core::input id="lead-page-account_id:account_id" type="hidden" :value="$data->account_id" />
<x-core::input id="lead-page-contact_id:contact_id" type="hidden" :value="$data->contact_id" />

<div class="card custom-card">
    <div class="card-body">

        {{-- Account --}}
        <div class="mb-3">

            <div id="lead-account-linked" class="{{ $accountLinked ? '' : 'd-none' }}">
                <div class="d-flex align-items-center justify-content-between mb-2">
                    <p class="fs-11 fw-semibold text-uppercase text-muted mb-0">Account</p>
                    <x-core::button variant="outline" color="danger" size="sm" id="lead-account-unlink-btn" :disabled="$data->is_new_account || $isQualified">
                        <i class="ri-close-line"></i>
                    </x-core::button>
                </div>
                <a id="lead-account-link"
                   href="{{ $accountLinked ? url('master-data/account/' . $account->id) : '#' }}"
                   class="d-flex align-items-center gap-2 text-decoration-none">
                    <div id="lead-account-avatar" class="avatar avatar-sm rounded-circle {{ $accountLinked && $account->profile_picture_id ? '' : 'bg-primary' }} d-flex align-items-center justify-content-center flex-shrink-0 overflow-hidden">
                        @if($accountLinked && $account->profile_picture_id)
                            <img src="{{ url('core/images/thumbnail/' . $account->profile_picture_id) }}" alt="" class="w-100 h-100 object-fit-cover">
                        @else
                            <span class="fs-13 fw-semibold text-white">{{ SolarHelper::getInitialName($account?->name ?? '?') }}</span>
                        @endif
                    </div>
                    <div class="overflow-hidden flex-grow-1">
                        <p id="lead-account-name" class="mb-0 fw-medium fs-13 text-truncate text-dark">{{ $account?->name }}</p>
                        <p id="lead-account-sub" class="mb-0 fs-12 text-muted text-truncate">{{ $account?->industry?->name }}</p>
                    </div>
                </a>
            </div>

            <div id="lead-account-unlinked" class="{{ $accountLinked ? 'd-none' : '' }}">
                <p class="fs-11 fw-semibold text-uppercase text-muted mb-2">Account</p>
                <x-core::field id="lead-page-account_name:account_name" label="Account Name">
                    <x-core::input placeholder="Enter account name" :value="$data->account_name" />
                </x-core::field>
                <div id="lead-account-action-btns" class="d-flex gap-2 {{ $isDisqualified ? 'd-none' : '' }}">
                    <x-core::button variant="outline" color="primary" size="sm" class="flex-fill" id="lead-account-create-btn" :disabled="$isQualified">
                        <i class="ri-add-line me-1"></i> Create New
                    </x-core::button>
                    <x-core::button variant="outline" color="secondary" size="sm" class="flex-fill" id="lead-account-existing-btn" :disabled="$isQualified && $accountLinked">
                        <i class="ri-search-line me-1"></i> Link Existing
                    </x-core::button>
                </div>
            </div>

        </div>

        <hr class="my-3">

        {{-- Contact --}}
        <div class="mb-3">

            <div id="lead-contact-linked" class="{{ $contactLinked ? '' : 'd-none' }}">
                <div class="d-flex align-items-center justify-content-between mb-2">
                    <p class="fs-11 fw-semibold text-uppercase text-muted mb-0">Contact</p>
                    <x-core::button variant="outline" color="danger" size="sm" id="lead-contact-unlink-btn" :disabled="$data->is_new_contact || $isQualified">
                        <i class="ri-close-line"></i>
                    </x-core::button>
                </div>
                <a id="lead-contact-link"
                   href="{{ $contactLinked ? url('master-data/contact/' . $contact->id) : '#' }}"
                   class="d-flex align-items-center gap-2 text-decoration-none">
                    @php $contactPictureId = $contact?->profile_picture_id ?? $contact?->profile_picture?->id @endphp
                    <div id="lead-contact-avatar" class="avatar avatar-sm rounded-circle {{ $contactLinked && $contactPictureId ? '' : 'bg-primary' }} d-flex align-items-center justify-content-center flex-shrink-0 overflow-hidden">
                        @if($contactLinked && $contactPictureId)
                            <img src="{{ url('core/images/thumbnail/' . $contactPictureId) }}" alt="" class="w-100 h-100 object-fit-cover">
                        @else
                            <span class="fs-13 fw-semibold text-white">{{ SolarHelper::getInitialName($contact?->name ?? '?') }}</span>
                        @endif
                    </div>
                    <div class="overflow-hidden flex-grow-1">
                        <p id="lead-contact-name" class="mb-0 fw-medium fs-13 text-truncate text-dark">{{ $contact?->name }}</p>
                        <p id="lead-contact-sub" class="mb-0 fs-12 text-muted text-truncate">{{ $contact?->job_title }}</p>
                    </div>
                </a>
            </div>

            <div id="lead-contact-unlinked" class="{{ $contactLinked ? 'd-none' : '' }}">
                <p class="fs-11 fw-semibold text-uppercase text-muted mb-2">Contact</p>
                <x-core::field id="lead-page-contact_name:contact_name" label="Contact Name">
                    <x-core::input placeholder="Enter contact name" :value="$data->contact_name" />
                </x-core::field>
                <x-core::field id="lead-page-contact_job_title:contact_job_title" label="Job Title">
                    <x-core::input placeholder="Enter job title" :value="$data->contact_job_title" />
                </x-core::field>
                <div id="lead-contact-action-btns" class="d-flex gap-2 {{ $isDisqualified ? 'd-none' : '' }}">
                    <x-core::button variant="outline" color="primary" size="sm" class="flex-fill" id="lead-contact-create-btn" :disabled="$isQualified">
                        <i class="ri-add-line me-1"></i> Create New
                    </x-core::button>
                    <x-core::button variant="outline" color="secondary" size="sm" class="flex-fill" id="lead-contact-existing-btn" :disabled="$isQualified && $contactLinked">
                        <i class="ri-search-line me-1"></i> Link Existing
                    </x-core::button>
                </div>
            </div>

        </div>

        <hr class="my-3">

        {{-- Owner --}}
        <div class="mb-3">
            <p class="fs-11 fw-semibold text-uppercase text-muted mb-2">Owner</p>
            <div class="d-flex align-items-center gap-2">
                <div class="avatar avatar-sm rounded-circle {{ $ownerPictureId ? '' : 'bg-primary' }} d-flex align-items-center justify-content-center flex-shrink-0 overflow-hidden">
                    @if($ownerPictureId)
                        <img src="{{ url('core/images/thumbnail/' . $ownerPictureId) }}" alt="" class="w-100 h-100 object-fit-cover">
                    @else
                        <span class="fs-13 fw-semibold text-white">{{ SolarHelper::getInitialName($owner?->name ?? '?') }}</span>
                    @endif
                </div>
                <div class="overflow-hidden flex-grow-1">
                    <p class="mb-0 fw-medium fs-13 text-truncate text-dark">{{ $owner?->name }}</p>
                    <p class="mb-0 fs-12 text-muted text-truncate">{{ $owner?->email ?? $owner?->username }}</p>
                </div>
            </div>
        </div>

    </div>
</div>

<x-core::table-lookup id="lead-account-lookup" model="Account" title="Choose Account" extend_columns="profile_picture">
    <x-slot:column>
        <x-core::table-column cell_class="text-nowrap" data="name">Name</x-core::table-column>
        <x-core::table-column data="email">Email</x-core::table-column>
        <x-core::table-column data="primary_phone">Primary Phone</x-core::table-column>
        <x-core::table-column data="industry.name">Industry</x-core::table-column>
    </x-slot>
    <x-slot:body>
        <div id="lead-account-duplicate-info" class="alert alert-warning d-none mb-3" role="alert">
            <i class="ri-error-warning-line me-1"></i>
            Similar accounts already exist. Select one to link it to this lead, or click <strong>Create New Anyway</strong> to proceed.
        </div>
    </x-slot>
    <x-slot:footer>
        <x-core::button id="lead-account-create-anyway-btn" variant="outline" color="primary" size="sm" class="me-auto d-none">
            <i class="ri-add-line me-1"></i> Create New Anyway
        </x-core::button>
    </x-slot>
</x-core::table-lookup>

<x-core::table-lookup id="lead-contact-lookup" model="Contact" title="Choose Contact" extend_columns="profile_picture">
    <x-slot:column>
        <x-core::table-column cell_class="text-nowrap" data="name">Name</x-core::table-column>
        <x-core::table-column data="primary_phone">Primary Phone</x-core::table-column>
        <x-core::table-column data="primary_mobile_phone">Mobile Phone</x-core::table-column>
        <x-core::table-column data="email">Email</x-core::table-column>
        <x-core::table-column data="job_title">Job Title</x-core::table-column>
    </x-slot>
    <x-slot:body>
        <div id="lead-contact-duplicate-info" class="alert alert-warning d-none mb-3" role="alert">
            <i class="ri-error-warning-line me-1"></i>
            Similar contacts already exist. Select one to link it to this lead, or click <strong>Create New Anyway</strong> to proceed.
        </div>
    </x-slot>
    <x-slot:footer>
        <x-core::button id="lead-contact-create-anyway-btn" variant="outline" color="primary" size="sm" class="me-auto d-none">
            <i class="ri-add-line me-1"></i> Create New Anyway
        </x-core::button>
    </x-slot>
</x-core::table-lookup>
