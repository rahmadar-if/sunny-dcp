@php
    $id = "lead-page-tabs_lead_info";
@endphp

<x-core::tab-content :id="$id" :active="$active ?? false" class="p-0 border-0">

    <x-core::fieldset label="Lead Info" />
    <div class="row">
        <div class="col-md-6">
            <x-core::field id="lead-page-date:date" label="Date" required>
                <x-core::date-picker placeholder="Select lead date" :value="$data->date" />
            </x-core::field>

            <x-core::field id="lead-page-name:name" label="Name" required>
                <x-core::input placeholder="Enter prospect's name or company name" :value="$data->name" />
            </x-core::field>
        </div>

        <div class="col-md-6">
            <x-core::field id="lead-page-phone:phone" label="Phone Number">
                <x-core::input
                    phone="ID"
                    placeholder="Enter phone number (required if no email)"
                    :value="$data->phone" />
            </x-core::field>

            <x-core::field id="lead-page-email:email" label="Email">
                <x-core::input
                    placeholder="Enter email address (required if no phone)"
                    :value="$data->email" />
            </x-core::field>
        </div>
    </div>

    <div class="row">
        <div class="col">
            <x-core::field id="lead-page-customer_need:customer_need" label="Customer Need" required>
                <x-core::textarea
                    rows="4"
                    placeholder="Describe the customer's needs or requirements"
                    :value="$data->customer_need" />
            </x-core::field>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <x-core::field 
                id="lead-page-disqualification_reason_id:disqualification_reason_id" 
                label="Disqualification Reason"
                :hidden="is_null($data->disqualification_reason)" 
                disabled>
                <x-core::lookup
                    placeholder="Choose disqualification reason"
                    :value="json_encode($data->disqualification_reason)" />
            </x-core::field>
        </div>
    </div>

    <div class="row mb-3">
        <x-core::field 
            id="lead-page-disqualification_reason_text:disqualification_reason_text" 
            label="Another Reason"
            :hidden="empty($data->disqualification_reason_text)" 
            disabled>
            <x-core::textarea rows="3" :value="$data->disqualification_reason_text" />
        </x-core::field>
    </div>

    <x-core::fieldset label="Lead Details" />
    <div class="row mb-3">
        <div class="col-md-6">
            <x-core::field id="lead-page-source_id:source_id" label="Source">
                <x-core::lookup
                    placeholder="Choose lead source"
                    :options="SolarHelper::model('lead_source')::toSelect()"
                    :value="json_encode($data->source)" />
            </x-core::field>

            <x-core::field id="lead-page-registration_method_id:registration_method_id" label="Registration Method">
                <x-core::lookup
                    placeholder="Choose registration method"
                    :options="SolarHelper::model('lead_registration_method')::toSelect()"
                    :value="json_encode($data->registration_method)" />
            </x-core::field>
        </div>

        <div class="col-md-6">
            <x-core::field id="lead-page-budget_range_id:budget_range_id" label="Budget Range">
                <x-core::lookup
                    placeholder="Choose budget range"
                    :options="SolarHelper::model('budget_range')::toSelect()"
                    :value="json_encode($data->budget_range)" />
            </x-core::field>

            <x-core::field id="lead-page-budget:budget" label="Budget">
                <x-core::input
                    number decimal prefix="Rp"
                    :value="$data->budget"
                />
            </x-core::field>
        </div>
    </div>

</x-core::tab-content>
