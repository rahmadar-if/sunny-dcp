@php
    $id          = "lead-page-tabs_account_profile";
    $fromAccount = !is_null($data->account_id);
@endphp

<x-core::tab-content id="lead-page-tabs_account_profile" class="p-0 border-0">
    <div class="row mb-3">
        <div class="col-md-6">
            <x-core::field id="lead-page-industry_id:industry_id" label="Industry" :disabled="$fromAccount">
                <x-core::lookup
                    placeholder="Choose industry or sector"
                    :options="SolarHelper::model('industry')::toSelect()"
                    :value="json_encode($fromAccount ? ($data->account?->industry ?? $data->industry) : $data->industry)" />
            </x-core::field>

            <x-core::field id="lead-page-segmentation_id:segmentation_id" label="Segmentation" :disabled="$fromAccount">
                <x-core::lookup
                    placeholder="Specify the market segment"
                    :options="SolarHelper::model('segmentation')::toSelect()"
                    :value="json_encode($fromAccount ? ($data->account?->segmentation ?? $data->segmentation) : $data->segmentation)" />
            </x-core::field>

            <x-core::field id="lead-page-business_size_id:business_size_id" label="Business Size" :disabled="$fromAccount">
                <x-core::lookup
                    placeholder="Specify the size of the business"
                    :options="SolarHelper::model('business_size')::toSelect()"
                    :value="json_encode($fromAccount ? ($data->account?->business_size ?? $data->business_size) : $data->business_size)" />
            </x-core::field>
        </div>

        <div class="col-md-6">
            <x-core::field id="lead-page-number_of_employee_id:number_of_employee_id" label="No. of Employees" :disabled="$fromAccount">
                <x-core::lookup
                    placeholder="Choose total number of employees"
                    :options="SolarHelper::model('number_of_employee')::toSelect()"
                    :value="json_encode($fromAccount ? ($data->account?->number_of_employee ?? $data->number_of_employee) : $data->number_of_employee)" />
            </x-core::field>

            <x-core::field id="lead-page-annual_revenue_id:annual_revenue_id" label="Annual Revenue" :disabled="$fromAccount">
                <x-core::lookup
                    placeholder="Choose annual revenue"
                    :options="SolarHelper::model('annual_revenue')::toSelect()"
                    :value="json_encode($fromAccount ? ($data->account?->annual_revenue ?? $data->annual_revenue) : $data->annual_revenue)" />
            </x-core::field>
        </div>
    </div>
</x-core::tab-content>
