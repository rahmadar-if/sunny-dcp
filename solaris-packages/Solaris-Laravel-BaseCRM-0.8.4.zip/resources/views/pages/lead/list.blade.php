<x-core::page.list
    id="lead"
    title="Lead"
    class="table-hover"
    :breadcrumbs="$breadcrumbs"
    model="Lead"
    package="base-crm"
    path="lead/list-index"
    new="@lead-modal"
    import export folder lazy delete_all
    extend_columns="created_by,phone,email,date,status,follow_up_date,account_name,contact_name,contact_job_title,account[profile_picture_id],contact[profile_picture_id],budget_range,disqualification_reason,disqualification_reason_text,budget">

    <x-slot:table-column>
        <x-core::table-action-column :view="false"/>

        <x-core::table-column
            cell_class="text-nowrap"
            data="date"
            searchable
            orderable>
            Name / Date
        </x-core::table-column>

        <x-core::table-column
            data="customer_need"
            searchable
            orderable
            expand>
            Customer Need
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="status.name">
            Status / Follow Up
        </x-core::table-column>
        
        <x-core::table-column
            cell_class="text-nowrap"
            data="budget_range.name">
            Budget
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="account.name">
            Account / Contact
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="phone"
            searchable
            orderable>
            Phone / Email
        </x-core::table-column>
    </x-slot>

    @push('modal-content')
        @include("base-crm::pages.lead.modal")
        @include("master-data::pages.activity.modal")
    @endpush

</x-core::page.list>
