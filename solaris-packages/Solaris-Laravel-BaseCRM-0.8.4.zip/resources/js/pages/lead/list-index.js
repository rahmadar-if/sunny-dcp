import LeadListPage from "./list"

new LeadListPage("lead")