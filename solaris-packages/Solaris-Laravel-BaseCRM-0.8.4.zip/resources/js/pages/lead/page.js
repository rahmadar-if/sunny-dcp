import Filter from "@core-js/solaris/filter/filter"
import SolarEditPage from "@core-js/solaris/solar/solar-edit-page"
import TableLookup from "@core-js/solaris/table/table-lookup"
import Button from "@core-js/solaris/button"
import axios from "@core-js/libs/axios"
import LeadActivityDetail from "./activity-detail"
import LeadStatusHistoryDetail from "./status-history-detail"
import Tab from "@core-js/solaris/tab"
import StageButtons from "@core-js/solaris/stage/stage-button"
import { DisqualificationReason, LeadStatus } from "../../const"
import Toast from "@core-js/solaris/toast"
import Modal from "@core-js/solaris/modal"

export default class LeadPage extends SolarEditPage {
	init() {
		this._isNewAccount    = false
		this._isNewContact    = false
		this._isAccountLinked = false
		this._isContactLinked = false
		this._currentStatusId = null

		this.initForm()
		this.initFollowUp()
		this.initDisqualificationReason()

		this.registerDetail("lead-activity", LeadActivityDetail, "lead_id")
		this.registerDetail("lead-status-history", LeadStatusHistoryDetail, "lead_id")

		const statusId = this.form.get('status_id')?.get()?.id
		if (statusId) {
			this._currentStatusId = statusId
			this._isAccountLinked = !!this.form.get('account_id')?.get()
			this._isContactLinked = !!this.form.get('contact_id')?.get()
			this._applyStatusState(statusId)
		}
	}

	// #region Lifecycle

	initForm() {
		/** @type { Tab } */
		this.tab = this.get("lead-page-tabs")

		this.initProfileAccount()
		this.initProfileContact()

		const name = this.form.get("name")
		name?.on('input', (value) => this.breadcrumbName.innerText = value, "LeadPage")

		this.form
			.addValidation("phone", (value) => {
				const email = this.form.getValue("email")
				const valid = !this.helper.isEmpty(value) || !this.helper.isEmpty(email)
				return {
					success: valid,
					message: "Phone or email is required. Please fill at least one."
				}
			})
			.addValidation("email", (value) => {
				const phone = this.form.getValue("phone")
				const valid = !this.helper.isEmpty(value) || !this.helper.isEmpty(phone)
				return {
					success: valid,
					message: "Phone or email is required. Please fill at least one."
				}
			})
			.addValidation("customer_need", (value) => {
				if (this.helper.isEmpty(value)) {
					return {
						success: true,
						message: null
					}
				}

				const valid = value.trim().length >= 10
				return {
					success: valid,
					message: "Customer need must be at least 10 characters."
				}
			})
	}

	initFollowUp() {
		const followUpDate    = this.form.get("follow_up_date")
		const remindMe        = this.form.get("lead-page-remind_me")
		const remindTimeField = this.form.get("lead-page-follow_up_remind_time")
		const remindAtField   = this.form.get("follow_up_remind_at")

		this.form.exclude(["lead-page-remind_me", "lead-page-follow_up_remind_time"])

		const syncRemindAt = () => {
			const date = followUpDate?.get()
			const time = remindTimeField?.get()
			remindAtField?.set(this._buildRemindAt(date, time))
		}

		followUpDate?.on("change", (value) => {
			const today = new Date()
			today.setHours(0, 0, 0, 0)

			if (!value || value <= today) {
				remindMe?.set(false)
				remindMe?.disabled()
			} else {
				remindMe?.enabled()
			}

			syncRemindAt()
		}, "LeadPage")

		remindTimeField?.on("change", (value) => syncRemindAt(), "LeadPage")

		remindMe?.on("change", (value) => {
			if (value) {
				remindTimeField?.show()
			} else {
				remindTimeField?.set(null)
				remindAtField?.set(null)
				remindTimeField?.hidden()
			}
		}, "LeadPage")
	}

	_buildRemindAt(dateValue, timeValue) {
		if (!dateValue || !timeValue) {
			return null
		}

		const result = new Date(dateValue)
		result.setHours(timeValue.getHours(), timeValue.getMinutes(), 0, 0)
		return result
	}

	initProfileAccount() {
		/** @type {TableLookup} */
		const accountLookup = this.get('lead-account-lookup')

		/** @type {Button} */
		const createAnywayBtn = this.get('lead-account-create-anyway-btn')

		this._accountBtns = {
			create:   this.get('lead-account-create-btn'),
			existing: this.get('lead-account-existing-btn'),
			unlink:   this.get('lead-account-unlink-btn'),
		}

		this._pendingAccData = null

		this._accountBtns.create?.on('click', async () => {
			const confirmed = await this.helper.confirm({
				title:   'Create New Account?',
				message: 'A new account will be created and permanently linked to this lead. Once linked, it cannot be unlinked.',
			})
			if (!confirmed) return
			this._submitCreateAccount(false)
		})

		this._accountBtns.existing?.on('click', () => {
			this._hideCreateAnywayBtn('account')

			const contactId = this.form.get('contact_id')?.get()
			if (contactId) {
				const filter = new Filter()
				filter.and('primary_contact_id', contactId)
				accountLookup?.open(filter)
			} else {
				accountLookup?.open()
			}
		})

		this._accountBtns.unlink?.on('click', () => {
			this._syncLinkedField('account', 'account_id', null)
			this._clearAccountFields()
			this._applyStatusState(this._currentStatusId)
		})

		createAnywayBtn?.on('click', () => {
			console.log({pendingAccData: this._pendingAccData})

			if (!this._pendingAccData) {
				return
			}

			accountLookup?.close()
			this._doCreateAccount({ ...this._pendingAccData, force: true })
		})

		accountLookup?.on('choose', (selection, rows) => {
			const chosen = rows[0]
			if (!chosen) {
				return
			}

			this._hideCreateAnywayBtn('account')
			this._syncLinkedField('account', 'account_id', chosen, '/master-data/account', (e) => e.industry?.name)
			this._setAccountFields(chosen)
			this._setUnlinkState('account', false)
			this._applyStatusState(this._currentStatusId)
		})

		accountLookup?.on('close', () => this._hideCreateAnywayBtn('account'))
	}

	initProfileContact() {
		const account = this.form.get("account_id")

		/** @type {TableLookup} */
		const contactLookup = this.get('lead-contact-lookup')

		/** @type {Button} */
		const createAnywayBtn = this.get('lead-contact-create-anyway-btn')

		this._contactBtns = {
			create:   this.get('lead-contact-create-btn'),
			existing: this.get('lead-contact-existing-btn'),
			unlink:   this.get('lead-contact-unlink-btn'),
		}

		this._pendingCntData = null

		this._contactBtns.create?.on('click', async () => {
			const confirmed = await this.helper.confirm({
				title:   'Create New Contact?',
				message: 'A new contact will be created and permanently linked to this lead. Once linked, it cannot be unlinked.',
			})
			if (!confirmed) return
			this._submitCreateContact(false)
		})

		this._contactBtns.existing?.on('click', () => {
			this._hideCreateAnywayBtn('contact')
			const accountId = account?.get()
			if (accountId) {
				const filter = new Filter()
				filter.and("account_id", accountId)
				contactLookup?.open(filter)
			} else {
				contactLookup?.open()
			}
		})

		this._contactBtns.unlink?.on('click', () => {
			this._syncLinkedField('contact', 'contact_id', null)
			this._clearContactFields()
			this._applyStatusState(this._currentStatusId)
		})

		createAnywayBtn?.on('click', () => {
			if (!this._pendingCntData) return
			contactLookup?.close()
			this._doCreateContact({ ...this._pendingCntData, force: true })
		})

		contactLookup?.on('choose', (selection, rows) => {
			const chosen = rows[0]
			if (!chosen) {
				return
			}
			this._hideCreateAnywayBtn('contact')
			this._syncLinkedField('contact', 'contact_id', chosen, '/master-data/contact', (e) => e.job_title)
			this._setContactFields(chosen)
			this._setUnlinkState('contact', false)
			this._applyStatusState(this._currentStatusId)
		})

		contactLookup?.on('close', () => this._hideCreateAnywayBtn('contact'))
	}

	initDisqualificationReason() {
		/** @type { Modal } */
		const disqualificationModal = this.get("disqualification-modal")

		/** @type { Button } */
		const disqualificationSave = this.get("disqualification-modal_save")

		const reasonId 	 = this.get('disqualification-modal-disqualification_reason_id')
		const reasonText = this.get('disqualification-modal-disqualification_reason_text')

		reasonId.on("change", (val) => {
			if(val && val.id == DisqualificationReason.Other) {
				reasonText.show()
				reasonText.required()
			} else {
				reasonText.hidden()
				reasonText.optional()
			}
		}, "LeadPage")

		/** @type { StageButtons } */
		const status = this.form.get("status_id")
		status.on('click', (data) => {
			if(data.id != LeadStatus.Disqualified) {
				this.form.set('disqualification_reason_id', null)
				this.form.set('disqualification_reason_text', null)

				this._currentStatusId = data.id
				this._applyStatusState(data.id)
				return
			}

			return new Promise((resolve, reject) => {
				disqualificationModal.show()

				const onSave = () => {
					if(this.helper.isEmpty(reasonId.get())) {
						this.helper.toast({ message: "Some fields are invalid or incomplete. Please check again.", color: "danger", position: Toast.Position.BottomCenter })
						reasonId.error()
						reasonId.setMessage("Reason is required")
						
						return
					}

					if(reasonId.get().id == DisqualificationReason.Other && this.helper.isEmpty(reasonText.get())) {
						this.helper.toast({ message: "Some fields are invalid or incomplete. Please check again.", color: "danger", position: Toast.Position.BottomCenter })
						reasonText.error()
						reasonText.setMessage("Another Reason is required")

						return
					}

					this.form.set('disqualification_reason_id', reasonId.get())
					this.form.set('disqualification_reason_text', reasonText.get())

					disqualificationSave.off("click")
					disqualificationModal.off("hidden")

					disqualificationModal.hide()
					reasonId.reset(true)
					reasonText.reset(true)

					this._currentStatusId = data.id
					this._applyStatusState(data.id)
					resolve(true)
				}

				disqualificationModal.on("hidden", () => {
					disqualificationSave.off("click")
					disqualificationModal.off("hidden")

					reasonId.reset(true)
					reasonText.reset(true)

					resolve(false)
				})

				disqualificationSave.on("click", onSave)
			})
		}, "LeadPage")
	}
	
	// #endregion

	// #region Events

	async success(response) {
		this.leadStatusHistory?.refresh()
	}

	async onRefreshed(data) {
		this.breadcrumbName.textContent = data.name

		this._isNewAccount    = data.is_new_account
		this._isNewContact    = data.is_new_contact
		this._currentStatusId = data.status_id

		this._syncLinkedField('account', 'account_id', data.account, '/master-data/account', (entity) => entity.industry?.name)
		data.account ? this._setAccountFields(data.account) : this._clearAccountFields()

		this._syncLinkedField('contact', 'contact_id', data.contact, '/master-data/contact', (entity) => entity.job_title)
		data.contact ? this._setContactFields(data.contact) : this._clearContactFields()

		this._applyStatusState(data.status_id)

		const remindTimeField = this.form.get("lead-page-follow_up_remind_time")
		remindTimeField?.set(data.follow_up_remind_at ? new Date(data.follow_up_remind_at) : null)

		const disqualReasonField     = this.form.get("disqualification_reason_id")
		const disqualReasonTextField = this.form.get("disqualification_reason_text")

		if (data.disqualification_reason) {
			disqualReasonField.show()
		} else {
			disqualReasonField.hidden()
		}

		if (!this.helper.isEmpty(data.disqualification_reason_text)) {
			disqualReasonTextField.show()
		} else {
			disqualReasonTextField.hidden()
		}
	}

	// #endregion

	// #region Create Account

	/**
	 * @param {boolean} force
	 * @returns {Promise<void>}
	 */
	async _submitCreateAccount(force) {
		const data = {
			name:                  this.form.getValue('account_name') || null,
			industry_id:           this.form.get('industry_id')?.get()?.id || null,
			phone:                 this.form.getValue('phone') || null,
			email:                 this.form.getValue('email') || null,
			segmentation_id:       this.form.get('segmentation_id')?.get()?.id || null,
			business_size_id:      this.form.get('business_size_id')?.get()?.id || null,
			number_of_employee_id: this.form.get('number_of_employee_id')?.get()?.id || null,
			annual_revenue_id:     this.form.get('annual_revenue_id')?.get()?.id || null,
			force,
		}

		await this._doCreateAccount(data)
	}

	/**
	 * @param {Object} data
	 * @returns {Promise<void>}
	 */
	async _doCreateAccount(data) {
		const response = await axios.post(`/crm/lead/${this.id}/create-account`, data)
		const body     = response.data

		if (!body.success) {
			if(body.errors.industry_id) {
				this.tab.setActive("lead-page-tabs_account_profile")
			}

			this._handleCreateErrors(body.errors ?? {}, {
				name:                  'account_name',
				industry_id:           'industry_id',
				phone:                 'phone',
				email:                 'email',
				segmentation_id:       'segmentation_id',
				business_size_id:      'business_size_id',
				number_of_employee_id: 'number_of_employee_id',
				annual_revenue_id:     'annual_revenue_id',
			})
			return
		}

		const result = body.data

		if (result?.duplicates?.length) {
			this._pendingAccData = data
			this._openDuplicateLookup('account', result.duplicates)
			return
		}

		this._pendingAccData = null
		this._syncLinkedField('account', 'account_id', result, '/master-data/account', (e) => e.industry?.name)
		this._setUnlinkState('account', true)
	}

	// #endregion

	// #region Create Contact

	/**
	 * @param {boolean} force
	 * @returns {Promise<void>}
	 */
	async _submitCreateContact(force) {
		const data = {
			name:      this.form.getValue('contact_name') || null,
			job_title: this.form.getValue('contact_job_title') || null,
			phone:     this.form.getValue('phone') || null,
			email:     this.form.getValue('email') || null,
			force,
		}

		await this._doCreateContact(data)
	}

	/**
	 * @param {Object} data
	 * @returns {Promise<void>}
	 */
	async _doCreateContact(data) {
		const response = await axios.post(`/crm/lead/${this.id}/create-contact`, data)
		const body     = response.data

		if (!body.success) {
			this._handleCreateErrors(body.errors ?? {}, {
				name:      'contact_name',
				job_title: 'contact_job_title',
				phone:     'phone',
				email:     'email',
			})
			return
		}

		const result = body.data

		if (result?.duplicates?.length) {
			this._pendingCntData = data
			this._openDuplicateLookup('contact', result.duplicates)
			return
		}

		this._pendingCntData = null
		this._syncLinkedField('contact', 'contact_id', result, '/master-data/contact', (e) => e.job_title)
		this._setUnlinkState('contact', true)
	}

	// #endregion

	// #region Duplicate Lookup

	/**
	 * @param {'account'|'contact'} type
	 * @param {string[]} ids
	 * @returns {Promise<void>}
	 */
	async _openDuplicateLookup(type, ids) {
		const lookupId = type === 'account' ? 'lead-account-lookup' : 'lead-contact-lookup'

		/** @type {TableLookup} */
		const lookup = this.get(lookupId)
		if (!lookup) {
			return
		}

		const filter = new Filter()
		filter.andIn('id', ids)

		this._showCreateAnywayBtn(type)
		await lookup.open(filter)
	}

	/**
	 * @param {'account'|'contact'} type
	 * @returns {void}
	 */
	_showCreateAnywayBtn(type) {
		document.getElementById(`lead-${type}-create-anyway-btn`)?.classList.remove('d-none')
		document.getElementById(`lead-${type}-duplicate-info`)?.classList.remove('d-none')
	}

	/**
	 * @param {'account'|'contact'} type
	 * @returns {void}
	 */
	_hideCreateAnywayBtn(type) {
		document.getElementById(`lead-${type}-create-anyway-btn`)?.classList.add('d-none')
		document.getElementById(`lead-${type}-duplicate-info`)?.classList.add('d-none')
	}

	// #endregion

	// #region Account & Contact Display

	/**
	 * @param {'account'|'contact'} type
	 * @param {string} fieldKey
	 * @param {Object|null} entity
	 * @param {string|null} [urlBase]
	 * @param {function(Object): string|null} [subTextResolver]
	 * @returns {void}
	 */
	_syncLinkedField(type, fieldKey, entity, urlBase = null, subTextResolver = null) {
		if (type === 'account') this._isAccountLinked = !!entity
		if (type === 'contact') this._isContactLinked = !!entity

		if (!entity) {
			this.form.set(fieldKey, null)
			this._clearLinkedDisplay(type)
			return
		}

		this.form.set(fieldKey, entity.id)
		this._setLinkedDisplay(type, entity, `${BASE_URL}${urlBase}/${entity.id}`, subTextResolver(entity))
	}

	/**
	 * @param {Object} account
	 * @returns {void}
	 */
	_setAccountFields(account) {
		this.form.get("account_name")?.set(account.name)
		this.form.get("industry_id")?.set(account.industry)?.disabled()
		this.form.get("segmentation_id")?.set(account.segmentation)?.disabled()
		this.form.get("number_of_employee_id")?.set(account.number_of_employee)?.disabled()
		this.form.get("annual_revenue_id")?.set(account.annual_revenue)?.disabled()
		this.form.get("business_size_id")?.set(account.business_size)?.disabled()
	}

	/**
	 * @returns {void}
	 */
	_clearAccountFields() {
		this.form.get("account_name")?.set(null)
		this.form.get("industry_id")?.set(null)?.enabled()
		this.form.get("segmentation_id")?.set(null)?.enabled()
		this.form.get("number_of_employee_id")?.set(null)?.enabled()
		this.form.get("annual_revenue_id")?.set(null)?.enabled()
		this.form.get("business_size_id")?.set(null)?.enabled()
	}

	/**
	 * @param {Object} contact
	 * @returns {void}
	 */
	_setContactFields(contact) {
		this.form.get("contact_name")?.set(contact.name)
		this.form.get("contact_job_title")?.set(contact.job_title)
	}

	/**
	 * @returns {void}
	 */
	_clearContactFields() {
		this.form.get("contact_name")?.set(null)
		this.form.get("contact_job_title")?.set(null)
	}

	/**
	 * @param {'account'|'contact'} type
	 * @param {Object} data
	 * @param {string} url
	 * @param {string|null} subText
	 * @returns {void}
	 */
	_setLinkedDisplay(type, data, url, subText) {
		const avatar    = document.getElementById(`lead-${type}-avatar`)
		const pictureId = data.profile_picture_id ?? data.profile_picture?.id

		if (avatar) {
			avatar.classList.remove('bg-primary')
			if (pictureId) {
				avatar.innerHTML = `<img src="${BASE_URL}/core/images/thumbnail/${pictureId}" alt="" class="w-100 h-100 object-fit-cover">`
			} else {
				avatar.classList.add('bg-primary')
				avatar.innerHTML = `<span class="fs-13 fw-semibold text-white">${(data.name ?? '?')[0].toUpperCase()}</span>`
			}
		}

		document.getElementById(`lead-${type}-name`).textContent = data.name ?? ''
		document.getElementById(`lead-${type}-sub`).textContent  = subText ?? ''
		document.getElementById(`lead-${type}-link`).href        = url

		document.getElementById(`lead-${type}-linked`).classList.remove('d-none')
		document.getElementById(`lead-${type}-unlinked`).classList.add('d-none')
	}

	/**
	 * @param {'account'|'contact'} type
	 * @returns {void}
	 */
	_clearLinkedDisplay(type) {
		document.getElementById(`lead-${type}-linked`).classList.add('d-none')
		document.getElementById(`lead-${type}-unlinked`).classList.remove('d-none')
	}

	/**
	 * @param {'account'|'contact'} type
	 * @param {boolean} isNew
	 * @returns {void}
	 */
	_setUnlinkState(type, isNew) {
		const btns = type === 'account' ? this._accountBtns : this._contactBtns
		isNew ? btns?.unlink?.disabled() : btns?.unlink?.enabled()
	}

	/**
	 * @param {string} statusId
	 * @returns {void}
	 */
	_applyStatusState(statusId) {
		const isDisqualified = statusId === LeadStatus.Disqualified
		const isQualified    = statusId === LeadStatus.Qualified
		this._setProfileSectionState('account', isDisqualified, isQualified, this._isNewAccount, this._isAccountLinked)
		this._setProfileSectionState('contact', isDisqualified, isQualified, this._isNewContact, this._isContactLinked)
	}

	/**
	 * @param {'account'|'contact'} type
	 * @param {boolean} isDisqualified
	 * @param {boolean} isQualified
	 * @param {boolean} isNew
	 * @param {boolean} isLinked
	 * @returns {void}
	 */
	_setProfileSectionState(type, isDisqualified, isQualified, isNew, isLinked) {
		const btns       = type === 'account' ? this._accountBtns : this._contactBtns
		const actionBtns = document.getElementById(`lead-${type}-action-btns`)

		actionBtns?.classList.toggle('d-none', isDisqualified)

		if (isQualified) {
			btns?.create?.disabled()
			isLinked ? btns?.existing?.disabled() : btns?.existing?.enabled()
			btns?.unlink?.disabled()
		} else {
			btns?.create?.enabled()
			btns?.existing?.enabled()
			isNew ? btns?.unlink?.disabled() : btns?.unlink?.enabled()
		}
	}

	// #endregion

	// #region Helpers

	/**
	 * @param {Object<string, string|string[]>} errors
	 * @param {Object<string, string>} fieldMap - request field → form field
	 * @returns {void}
	 */
	_handleCreateErrors(errors, fieldMap) {
		Object.entries(errors).forEach(([requestField, msg]) => {
			const formField = fieldMap[requestField] ?? requestField
			const message   = Array.isArray(msg) ? msg[0] : msg
			const field     = this.form.get(formField)

			if (field) {
				field.error()
				field.setMessage(message)
			}
		})

		this.helper.toast({
			title:   'Validation Error',
			message: 'Please check the required fields.',
			color:   'danger',
		})
	}

	// #endregion
}
