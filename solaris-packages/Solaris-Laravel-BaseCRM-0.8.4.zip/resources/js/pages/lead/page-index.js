import LeadPage from "./page"

new LeadPage()