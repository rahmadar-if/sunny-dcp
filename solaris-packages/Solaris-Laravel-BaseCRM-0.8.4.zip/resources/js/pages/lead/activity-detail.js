import ActivityDetail from "@master-data-js/pages/activity/detail";

export default class LeadActivityDetail extends ActivityDetail {
    init() {
        super.init()
    }
}