import SolarListPage from "@core-js/solaris/solar/solar-list-page";
import { DisqualificationReason, LeadRegistrationMethod, LeadStatus } from "@base-crm-js/const";
import ActivityAction from "@base-crm-js/helper/activity-action";
import ActivityModal from "@master-data-js/pages/activity/modal";

export default class LeadListPage extends SolarListPage {
    init() {
        this.initModal()

        this.activityModal = new ActivityModal()
        ActivityAction.getActivityCategory().then(res => this.activityCategories = res)

        this.columnRender("date", this.nameColumnRender.bind(this))
        this.columnRender("phone", this.phoneEmailColumnRender.bind(this))
        this.columnRender("status_id", this.statusColumnRender.bind(this))
        this.columnRender("account_id", this.accountContactColumnRender.bind(this))
        this.columnRender("budget_range_id", this.budgetColumnRender.bind(this))

        this.columnCreated("status_id", this.statusColumnCreated.bind(this))
    }

    initModal() {
        if(!this.hasModalForm()) {
            return
        }

        this.modal?.on("show", () => {
            if(this.form.isEdit()) {
                return
            }

            this.form.set('date', new Date())
        }, "LeadListPage")

        this.form.addData("registration_method_id", LeadRegistrationMethod.ManualEntry)

        this.form.addValidation("phone", (value) => {
            const email = this.form.getValue("email")
            const valid = !this.helper.isEmpty(value) || !this.helper.isEmpty(email)
            return { success: valid, message: "Phone or email is required. Please fill at least one." }
        })

        this.form.addValidation("email", (value) => {
            const phone = this.form.getValue("phone")
            const valid = !this.helper.isEmpty(value) || !this.helper.isEmpty(phone)
            return { success: valid, message: "Phone or email is required. Please fill at least one." }
        })

        this.form.addValidation("customer_need", (value) => {
            if (this.helper.isEmpty(value)) {
                return { success: true, message: null }
            }
            const valid = value.trim().length >= 10
            return { success: valid, message: "Customer need must be at least 10 characters." }
        })
    }

    getEditUrl(id) {
        const segment = window.location.pathname.split('/').filter(Boolean)[0]
        if(segment == 'sales') {
            return `${BASE_URL}/sales/lead/edit/${id}`
        } else if(segment == 'marketing') {
            return `${BASE_URL}/marketing/lead/edit/${id}`
        } else {
            return `${BASE_URL}/crm/lead/edit/${id}`
        }
    }

    openEditPage(id) {
        this.helper.loadingPage(true)
        window.location = this.getEditUrl(id)
    }

    async edit(row, data) {
        this.openEditPage(data.id)
    }

    rowDoubleClick(row, data) {
        this.openEditPage(data.id)
    }

    // #region Column Renders

    /**
     * @param {string} data
     * @param {Object} rowData
     * @returns {string}
     */
    nameColumnRender(data, rowData) {
        return `<div class="d-flex flex-column gap-1">
            <a class="fw-medium text-decoration-underline" href="${this.getEditUrl(rowData.id)}">${rowData.name}</a>
            <span class="text-muted fs-12"><i class="ri-calendar-line me-1"></i>${rowData.date ?? '—'}</span>
            <span class="text-muted fs-12"><i class="ri-edit-line me-1"></i>${rowData.created_by.name}</span>
        </div>`
    }

    phoneEmailColumnRender(data, rowData) {
        return `<div class="d-flex flex-column gap-1">
            <span class="text-muted"><i class="ri-phone-line me-2"></i>${rowData.phone ?? '-'}</span>
            <span class="text-muted"><i class="ri-mail-line me-2"></i>${rowData.email ?? '-'}</span>
        </div>`
    }

    /**
     * @param {string} data
     * @param {Object} rowData
     * @returns {string}
     */
    statusColumnRender(data, rowData) {
        const status      = rowData.status
        const statusBadge = `<span class="badge bg-${status?.color ?? 'secondary'} fs-10">${data ?? '—'}</span>`

        if (rowData.status_id === LeadStatus.Disqualified) {
            const reason     = rowData.disqualification_reason
            const reasonText = reason?.id == DisqualificationReason.Other
                ? (rowData.disqualification_reason_text ?? reason?.name ?? '—')
                : (reason?.name ?? '—')
            const reasonHtml = `<span class="lead-expand fs-12 text-truncate d-inline-block align-middle" title="Click to expand" style="max-width: 160px;">${reasonText}</span>`
            return `<div class="d-flex flex-column align-items-start gap-1">${statusBadge}${reasonHtml}</div>`
        }

        if (!rowData.follow_up_date) {
            return `<div class="d-flex flex-column align-items-start gap-1">${statusBadge}<span class="text-muted fs-12">—</span></div>`
        }

        const followUp = new Date(rowData.follow_up_date)
        const today    = new Date()
        today.setHours(0, 0, 0, 0)
        followUp.setHours(0, 0, 0, 0)

        const diffDays = Math.round((followUp - today) / (1000 * 60 * 60 * 24))

        let followUpHtml
        if (rowData.status_id === LeadStatus.Qualified) {
            followUpHtml = `<span class="text-muted fs-12"><i class="ri-calendar-line me-1"></i>${rowData.follow_up_date}</span>`
        } else if (diffDays === 0) {
            followUpHtml = `<span class="text-warning fs-12"><i class="ri-calendar-line me-1"></i>${rowData.follow_up_date} · hari ini</span>`
        } else if (diffDays > 0) {
            followUpHtml = `<span class="text-muted fs-12"><i class="ri-calendar-line me-1"></i>${rowData.follow_up_date} · ${diffDays} hari lagi</span>`
        } else {
            followUpHtml = `<span class="text-danger fs-12"><i class="ri-alarm-warning-line me-1"></i>${rowData.follow_up_date} · lewat ${Math.abs(diffDays)} hari</span>`
        }

        return `<div class="d-flex flex-column align-items-start gap-1">${statusBadge}${followUpHtml}</div>`
    }

    statusColumnCreated(row, cell, cellData, rowData) {
        const span = cell.querySelector('span.lead-expand')
        span?.addEventListener('click', () => {
            span.classList.toggle('text-truncate')
            span.classList.toggle('d-inline-block')
        })
    }

    /**
     * @param {string} data
     * @param {Object} rowData
     * @returns {string}
     */
    accountContactColumnRender(data, rowData) {
        const accountHtml = this._renderEntity('account', rowData.account, rowData.account_name)
        const contactHtml = this._renderEntity('contact', rowData.contact, rowData.contact_name)

        return `<div class="d-flex flex-column gap-2">${accountHtml}${contactHtml}</div>`
    }

    /**
     * @param {string} data
     * @param {Object} rowData
     * @returns {string}
     */
    budgetColumnRender(data, rowData) {
        return !this.helper.isEmpty(rowData.budget) ? rowData.budget : (data ?? '-')
    }

    // #endregion

    // #region Helpers

    /**
     * @param {'account'|'contact'} type
     * @param {Object|null} linked
     * @param {string|null} tempName
     * @param {string|null} tempJobTitle
     * @returns {string}
     */
    _renderEntity(type, linked, tempName) {
        const icon    = type === 'account'
            ? '<i class="ri-building-2-line"></i>'
            : '<i class="ri-user-3-line"></i>'
        const urlBase = type === 'account' ? 'master-data/account' : 'master-data/contact'

        if(linked) {
            const initial = this.helper.getInitialName(linked.name)
            const avatar  = linked.profile_picture_id
                ? `<img src="${BASE_URL}/core/images/thumbnail/${linked.profile_picture_id}" alt="" class="avatar avatar-xs avatar-rounded">`
                : `<span class="avatar avatar-xs avatar-rounded bg-secondary">${initial}</span>`

            return `<div class="d-flex align-items-center gap-2">
                ${icon}
                ${avatar}
                <a class="fw-medium text-decoration-underline" href="${BASE_URL}/${urlBase}/${linked.id}">${linked.name}</a>
            </div>`
        }

        if(tempName) {
            return `<div class="d-flex align-items-center gap-2">
                ${icon}
                <span class="fw-medium">${tempName}</span>
            </div>`
        }

        return `<div class="d-flex align-items-center gap-2">${icon}<span class="text-muted">—</span></div>`
    }

    // #endregion

    onActionCreated(row, cell, rowData) {
        const actionBtn      = cell.children[0]
        const activityAction = ActivityAction.createAction(
            this.activityCategories,
            (category) => {
                this.activityModal.form.get('account_id').set(rowData.account, true)
                this.activityModal.form.get('contact_id').set(rowData.contact, true)
                this.activityModal.form.get('category_id').set(category)
                this.activityModal.form.addData("lead_id", rowData.id)
                this.activityModal.modalForm.new()
            }
        )

        const wrap     = document.createElement("div")
        wrap.className = "d-flex justify-content-center gap-1"
        wrap.append(activityAction)
        wrap.append(actionBtn)
        cell.prepend(wrap)
    }
}
