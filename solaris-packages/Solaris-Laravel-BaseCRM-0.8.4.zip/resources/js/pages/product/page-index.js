import ProductPage from "./page"

new ProductPage()