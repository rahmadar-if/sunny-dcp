import BaseProductPage from "@master-data-js/pages/product/page";
import PromotedProductDetail from "../activity/promoted-product-detail";

export default class ProductPage extends BaseProductPage {
    init() {
        super.init()
        this.registerDetail("promoted-product", PromotedProductDetail, "product_id")
    }
}