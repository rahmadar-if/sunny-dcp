import BaseAccountListPage from "@master-data-js/pages/account/list";

export default class AccountListPage extends BaseAccountListPage {
    init() {
        super.init()

        this.columnRender("status_id", this.statusColumnRender.bind(this))
    }

    statusColumnRender(data, rowData) {
        return `<span class="badge bg-${rowData.status.color}">${data}</span>`
    }
}