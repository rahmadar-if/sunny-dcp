import SolarListDetail from "@core-js/solaris/solar/solar-list-detail";

export default class AccountLeadDetail extends SolarListDetail {
    init() {
        this.columnRender("name", this.nameColumnRender.bind(this))
        this.columnRender("status_id", this.statusColumnRender.bind(this))
    }
    
    rowDoubleClick(row, data) {
        this.helper.loadingPage(true)
        window.location = `${BASE_URL}/crm/lead/${data.id}`
    }

    nameColumnRender(data, rowData) {

        /**
         * harus ada function untuk check sales/marketing yg di tersedia di package
         */

        return `<div class="d-flex flex-column gap-1">
            <a class="text-decoration-underline" href="${BASE_URL}/crm/lead/${rowData.id}">${data}</a>
            <span class="text-muted">${rowData.date}</span>
        </div>`
    }

    statusColumnRender(data, rowData) {
        return `<span class="badge bg-${rowData.status.color}">${data}</span>`
    }
}