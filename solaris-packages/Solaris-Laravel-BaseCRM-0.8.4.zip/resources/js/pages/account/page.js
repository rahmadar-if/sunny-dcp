import BaseAccountPage from "@master-data-js/pages/account/page";
import AccountBankDetail from "./bank-detail";
import AccountLeadDetail from "./lead-detail";
import AccountStatusHistoryDetail from "./status-history-detail";

export default class AccountPage extends BaseAccountPage {
    init() {
        super.init()
        this.registerDetail("account-bank", AccountBankDetail, "account_id")
        this.registerDetail("account-lead", AccountLeadDetail, "account_id")
        this.registerDetail("account-status-history", AccountStatusHistoryDetail, "account_id")
    }
}
