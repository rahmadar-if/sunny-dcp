import SolarListDetail from "@core-js/solaris/solar/solar-list-detail";

export default class AccountStatusHistoryDetail extends SolarListDetail {
    init() {
        this.columnRender("status_id", this.statusColumnRender.bind(this))
    }

    statusColumnRender(data, rowData) {
        return `<span class="badge bg-${rowData.status.color}">${data}</span>`
    }
}