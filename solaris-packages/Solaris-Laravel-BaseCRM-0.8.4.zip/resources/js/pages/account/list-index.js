import AccountListPage from "./list"

new AccountListPage("account")