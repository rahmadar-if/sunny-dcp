import ContactListPage from "./list"

new ContactListPage("contact")