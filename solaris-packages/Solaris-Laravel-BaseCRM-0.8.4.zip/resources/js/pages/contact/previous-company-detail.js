import SolarListDetail from "@core-js/solaris/solar/solar-list-detail";

export default class PreviousCompanyDetail extends SolarListDetail {
    init() {
        this.columnRender("account_id", this.accountColumnRender.bind(this))
        this.columnRender("active", this.activeColumnRender.bind(this))
    }

    accountColumnRender(data, rowData) {
        const initialName = this.helper.getInitialName(data)
        return `<div class="d-flex align-items-center gap-2">
            <div class="lh-1">
                <span class="avatar avatar-rounded avatar-sm ${!rowData.account.profile_picture_id ? "bg-secondary" : ""}">
                    ${rowData.account.profile_picture_id ? `<img src="${BASE_URL}/core/images/thumbnail/${rowData.account.profile_picture_id}" alt="">` : initialName}
                </span>
            </div>
            <div>
                <a class="text-decoration-underline" href="${BASE_URL}/master-data/account/edit/${rowData.account_id}">${data}</a>
            </div>
        </div>`
    }

    activeColumnRender(data, rowData) {
        return `<span class="badge ${data ? 'bg-primary' : 'bg-danger'}">${data ? 'Active' : 'Not Active'}</span>`
    }
}