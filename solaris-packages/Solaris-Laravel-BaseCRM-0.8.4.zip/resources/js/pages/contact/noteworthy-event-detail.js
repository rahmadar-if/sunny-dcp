import SolarListDetail from "@core-js/solaris/solar/solar-list-detail";

export default class NoteworthyEventDetail extends SolarListDetail {

}