import BaseContactPage from "@master-data-js/pages/contact/page";
import NoteworthyEventDetail from "./noteworthy-event-detail";
import PreviousCompanyDetail from "./previous-company-detail";
import AccountLeadDetail from "../account/lead-detail";
import ContactStatusHistoryDetail from "./status-history-detail";

export default class ContactPage extends BaseContactPage {
    init() {
        super.init()
        this.registerDetail("contact-noteworthy-event", NoteworthyEventDetail, "contact_id")
        this.registerDetail("contact-previous-company", PreviousCompanyDetail, "contact_id")
        this.registerDetail("contact-lead", AccountLeadDetail, "contact_id")
        this.registerDetail("contact-status-history", ContactStatusHistoryDetail, "account_id")
    }
}