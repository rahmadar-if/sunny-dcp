import BaseContactListPage from "@master-data-js/pages/contact/list";

export default class ContactListPage extends BaseContactListPage {
    init() {
        super.init()

        this.columnRender("status_id", this.statusColumnRender.bind(this))
    }

    statusColumnRender(data, rowData) {
        return `<span class="badge bg-${rowData.status.color}">${data}</span>`
    }
}