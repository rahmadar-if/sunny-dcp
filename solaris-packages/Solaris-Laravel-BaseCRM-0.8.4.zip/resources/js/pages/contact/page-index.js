import ContactPage from "./page"

new ContactPage()