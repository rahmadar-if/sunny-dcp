import SolarListDetail from "@core-js/solaris/solar/solar-list-detail";

export default class ActivityParticipantDetail extends SolarListDetail {
    init() {
        this.columnRender("notes", this.notesColumnRender.bind(this))
        this.columnCreated("notes", this.notesColumnCreated.bind(this))
    }

    notesColumnRender(data, rowData) {
       return `<span class="d-inline-block text-truncate align-middle" title="Click to expand" style="max-width: 15rem;">${data ?? ''}</span>`
    }

    notesColumnCreated(row, cell, cellData, rowData) {
        const span = cell.children[0]
        span.addEventListener("click", () => {
            span.classList.toggle("d-inline-block")
            span.classList.toggle("text-truncate")
        })
    }
}