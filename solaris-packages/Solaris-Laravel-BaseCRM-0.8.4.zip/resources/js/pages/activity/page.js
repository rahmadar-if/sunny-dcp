import Filter from "@core-js/solaris/filter/filter";
import BaseActivityPage from "@master-data-js/pages/activity/page";
import ActivityParticipantDetail from "./participant-detail";
import ActivityPromotedProductDetail from "./promoted-product-detail";

export default class ActivityPage extends BaseActivityPage {
    init() {
        super.init()
        this.registerDetail("activity-participant", ActivityParticipantDetail, "activity_id")
        this.registerDetail("activity-promoted-product", ActivityPromotedProductDetail, "activity_id")
    }

    initForm() {
        super.initForm()
        
        const account = this.form.get("account_id")
        const contact = this.form.get("contact_id")
        const lead    = this.form.get("lead_id")
        
        lead?.init({
            param: (param) => {
                const filter = new Filter()
                const accountVal = account?.get()
                if(accountVal) {
                    filter.and("account_id", accountVal.id)
                }

                const contactVal = contact?.get()
                if(contactVal) {
                    filter.and("contact_id", contactVal.id)
                }

                param.filter = filter.get()

                return param
            },
            optionsTemplate: (state) => {
                if(!state.id) {
                    return state.name
                }

                const option = `<div class="d-flex flex-column gap-1">
                    <div class="d-flex justify-content-between">
                        <div class="d-flex gap-1 align-items-center">
                            <span class="fs-12 fw-semibold">${state.name}</span>
                            <span class="fs-10 badge bg-${state.status.color}">${state.status.name}</span>
                        </div>
                        <span class="fs-11">${state.date}</span>
                    </div>
                    ${state.account ? `<span class="fs-11"><i class="ri-building-2-line me-1"></i>${state.account.name}</span>` : ''}
                    ${state.contact ? `<span class="fs-11"><i class="ri-user-3-line me-1"></i>${state.contact.name}</span>` : ''}
                </div>`

                return option
            }
        })

        lead?.on("change", (value) => {
            if(value && value.contact && !contact?.get()) {
                contact.set(value.contact, true)
            }

            if(value && value.account && !account?.get()) {
                account.set(value.account)
            }
        }, "ActivityPage.BaseCRM")
    }
}