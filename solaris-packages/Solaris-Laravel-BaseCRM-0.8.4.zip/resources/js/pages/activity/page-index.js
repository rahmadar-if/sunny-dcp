import ActivityPage from "./page"

new ActivityPage()