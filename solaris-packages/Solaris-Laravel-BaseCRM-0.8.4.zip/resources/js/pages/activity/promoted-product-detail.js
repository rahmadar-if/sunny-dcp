import SolarListDetail from "@core-js/solaris/solar/solar-list-detail";

export default class ActivityPromotedProductDetail extends SolarListDetail {
    init() {
        this.columnRender("status", this.statusColumnRender.bind(this))
        this.columnCreated("status", this.statusColumnCreated.bind(this))
    }

    statusColumnRender(data, rowData) {
       return `<span class="d-inline-block text-truncate align-middle" title="Click to expand" style="max-width: 15rem;">${data ?? ''}</span>`
    }

    statusColumnCreated(row, cell, cellData, rowData) {
        const span = cell.children[0]
        span.addEventListener("click", () => {
            span.classList.toggle("d-inline-block")
            span.classList.toggle("text-truncate")
        })
    }
}