import axios from "@core-js/libs/axios"

export default class ActivityAction {

    /**
     * @returns {Promise<[{id: string, name: string}]>} 
     */
    static async getActivityCategory() {
        return await axios({
            method  : "POST",
            url     : new URL('core/lookup', BASE_URL+"/").href,
            headers : { 'X-Model': "ActivityCategory" }
        }).then(res => res.data)
    }

    /**
     * @param {[{id: string, name: string}]} activityCategories 
     * @param {Function} callback param category 
     * @param {string} label 
     * @param {string} icon 
     * @returns {HTMLElement}
     */
    static createAction(activityCategories, callback, label = "Create new activity", icon = "ri-calendar-event-fill") {
        const dropdown     = document.createElement("div")
        dropdown.className = "dropdown"
        dropdown.setAttribute("data-bs-toggle", "tooltip")
        dropdown.setAttribute("data-bs-placement", "top")
        dropdown.setAttribute("data-bs-original-title", label)
        
        const button     = document.createElement("button")
        button.className = "btn btn-sm btn-light"
        button.innerHTML = `<i class="${icon}"></i>`
        button.setAttribute("data-bs-toggle", "dropdown")
        button.setAttribute("aria-expanded", "false")

        const dropdownItem     = document.createElement("ul")
        dropdownItem.className = "dropdown-menu"

        activityCategories.forEach(category => {
            const li      = document.createElement("li")
            const a       = document.createElement("a")
            a.className   = "dropdown-item"
            a.textContent = category.name
            a.setAttribute("href", "javascript:void(0)")
            a.addEventListener("click", async () => await callback(category))
            li.append(a)
            dropdownItem.append(li)
        })

        dropdown.append(button, dropdownItem)
        return dropdown
    }
}