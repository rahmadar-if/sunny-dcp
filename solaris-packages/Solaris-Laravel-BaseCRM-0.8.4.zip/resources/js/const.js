const LeadRegistrationMethod = {
    ManualEntry : "f1bf6d88-1cbe-4d7f-b331-767e42bd46f5",
    WebForm     : "479d55f2-392c-4ae4-af3c-a27f1a2f8039",
    API         : "0ba4fdc1-a97d-401d-b014-c1b922cd8acb",
    ChatBot     : "39a1b69a-8b6c-44a8-bbc6-d57d55d0a84e",
    ImportExcel : "27b8c840-9ec7-4887-893a-c9f02485acf1",
}

const LeadStatus = {
    New           : "83ade5fc-baad-4570-ad4f-eb7b514de0a1",
    Nurturing     : "064e0f85-688a-42e0-bb77-d4140a498cc7",
    Qualified     : "3596bde8-5bbf-4fe1-b637-2f33ada89f16",
    Disqualified  : "ab3111f1-fd59-4d59-a492-1eefcf88df1d",
}

const DisqualificationReason = {
    NoBudget        : "e1b2f62a-9da3-40d7-a193-bcac7d854a65",
    WrongSegment    : "0c4509a1-4a2c-417b-972f-9fe3037c1491",
    NoResponse      : "5c0b6f40-d0ac-4d69-bd86-9b24cd25ad34",
    ChooseCompetitor: "9d8e284b-9155-429f-b1ea-ee1cbaed581d",
    BadTiming       : "436756be-fcbe-445c-916c-8b194520b005",
    IncompleteInfo  : "895cbb87-a475-4f7c-b848-3454e0849897",
    Other           : "93f0b1bc-a6c1-4dbd-a224-1165e490e9f4",
}

export { 
    LeadRegistrationMethod,
    LeadStatus,
    DisqualificationReason
}