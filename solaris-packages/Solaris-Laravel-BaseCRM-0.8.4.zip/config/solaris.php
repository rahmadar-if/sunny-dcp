<?php

// config for Solaris\BaseCRM
return [

    /*
    |--------------------------------------------------------------------------
    | Resources
    |--------------------------------------------------------------------------
    */
    'resource' => [
        'path' => [
            'base-crm' => 'vendor/solaris/solaris-laravel-basecrm/resources',
        ],
        'views' => [
            'account' => [
                'list' => 'base-crm::pages.account.list',
                'page' => 'base-crm::pages.account.page',
            ],
            'contact' => [
                'list' => 'base-crm::pages.contact.list',
                'page' => 'base-crm::pages.contact.page',
            ],
            'activity' => [
                'page' => 'base-crm::pages.activity.page',
            ],
            'product' => [
                'page' => 'base-crm::pages.product.page',
            ],
            'lead' => [
                'list' => 'base-crm::pages.lead.list',
                'page' => 'base-crm::pages.lead.page',
            ],
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Models
    |--------------------------------------------------------------------------
    */
    'model' => [
        'namespaces' => [
            'Solaris\\BaseCRM\\Models' => base_path('vendor/solaris/solaris-laravel-basecrm/src/Models'),
        ],
        'models' => [
            'account'                => 'Solaris\\BaseCRM\\Models\\Account',
            'account_status'         => 'Solaris\\BaseCRM\\Models\\AccountStatus',
            'annual_revenue'         => 'Solaris\\BaseCRM\\Models\\AnnualRevenue',
            'customer_journey'       => 'Solaris\\BaseCRM\\Models\\CustomerJourney',
            'segmentation'           => 'Solaris\\BaseCRM\\Models\\Segmentation',
            'business_size'          => 'Solaris\\BaseCRM\\Models\\BusinessSize',
            'frequency_type'         => 'Solaris\\BaseCRM\\Models\\FrequencyType',
            'account_bank'           => 'Solaris\\BaseCRM\\Models\\AccountBank',
            'account_status_history' => 'Solaris\\BaseCRM\\Models\\AccountStatusHistory',

            'contact'                   => 'Solaris\\BaseCRM\\Models\\Contact',
            'contact_status'            => 'Solaris\\BaseCRM\\Models\\ContactStatus',
            'contact_noteworthy_event'  => 'Solaris\\BaseCRM\\Models\\ContactNoteworthyEvent',
            'noteworthy_event_type'     => 'Solaris\\BaseCRM\\Models\\NoteworthyEventType',
            'contact_previous_company'  => 'Solaris\\BaseCRM\\Models\\ContactPreviousCompany',
            'contact_status_history'    => 'Solaris\\BaseCRM\\Models\\ContactStatusHistory',

            'activity'                   => 'Solaris\\BaseCRM\\Models\\Activity',
            'activity_result'            => 'Solaris\\BaseCRM\\Models\\ActivityResult',
            'activity_participant'       => 'Solaris\\BaseCRM\\Models\\ActivityParticipant',
            'activity_promoted_product'  => 'Solaris\\BaseCRM\\Models\\ActivityPromotedProduct',

            'product' => 'Solaris\\BaseCRM\\Models\\Product',

            'lead'                      => 'Solaris\\BaseCRM\\Models\\Lead',
            'lead_status'               => 'Solaris\\BaseCRM\\Models\\LeadStatus',
            'lead_source'               => 'Solaris\\BaseCRM\\Models\\LeadSource',
            'lead_registration_method'  => 'Solaris\\BaseCRM\\Models\\LeadRegistrationMethod',
            'lead_status_history'       => 'Solaris\\BaseCRM\\Models\\LeadStatusHistory',
            'budget_range'              => 'Solaris\\BaseCRM\\Models\\BudgetRange',
            'disqualification_reason'   => 'Solaris\\BaseCRM\\Models\\DisqualificationReason',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Repositories
    |--------------------------------------------------------------------------
    */
    'repositories' => [
        'account'                => 'Solaris\\BaseCRM\\Repositories\\AccountRepository',
        'account_bank'           => 'Solaris\\Core\\Repositories\\BaseRepository',
        'account_status_history' => 'Solaris\\Core\\Repositories\\BaseRepository',

        'contact_noteworthy_event' => 'Solaris\\Core\\Repositories\\BaseRepository',
        'contact_previous_company' => 'Solaris\\Core\\Repositories\\BaseRepository',
        'contact_status_history'   => 'Solaris\\Core\\Repositories\\BaseRepository',

        'activity_participant'      => 'Solaris\\Core\\Repositories\\BaseRepository',
        'activity_promoted_product' => 'Solaris\\Core\\Repositories\\BaseRepository',

        'lead'                => 'Solaris\\BaseCRM\\Repositories\\LeadRepository',
        'lead_status_history' => 'Solaris\\Core\\Repositories\\BaseRepository',
    ],

    /*
    |--------------------------------------------------------------------------
    | HTTP Layer
    |--------------------------------------------------------------------------
    */
    'controller' => [
        'namespaces' => [
            'Solaris\\BaseCRM\\Http\\Controllers',
        ],
        'controllers' => [
            'account'      => 'Solaris\\BaseCRM\\Http\\Controllers\\AccountController',
            'account_bank' => 'Solaris\\BaseCRM\\Http\\Controllers\\AccountBankController',

            'contact'                   => 'Solaris\\BaseCRM\\Http\\Controllers\\ContactController',
            'contact_noteworthy_event'  => 'Solaris\\BaseCRM\\Http\\Controllers\\ContactNoteworthyEventController',
            'contact_previous_company'  => 'Solaris\\BaseCRM\\Http\\Controllers\\ContactPreviousCompanyController',

            'activity'                   => 'Solaris\\BaseCRM\\Http\\Controllers\\ActivityController',
            'activity_participant'       => 'Solaris\\BaseCRM\\Http\\Controllers\\ActivityParticipantController',
            'activity_promoted_product'  => 'Solaris\\BaseCRM\\Http\\Controllers\\ActivityPromotedProductController',

            'lead' => 'Solaris\\BaseCRM\\Http\\Controllers\\LeadController',
        ],
    ],

    'form_requests' => [
        'account'      => 'Solaris\\BaseCRM\\Http\\Requests\\AccountRequest',
        'account_bank' => 'Solaris\\BaseCRM\\Http\\Requests\\AccountBankRequest',

        'contact'                  => 'Solaris\\BaseCRM\\Http\\Requests\\ContactRequest',
        'contact_noteworthy_event' => 'Solaris\\BaseCRM\\Http\\Requests\\ContactNoteworthyEventRequest',
        'contact_previous_company' => 'Solaris\\BaseCRM\\Http\\Requests\\ContactPreviousCompanyRequest',

        'activity'                   => 'Solaris\\BaseCRM\\Http\\Requests\\ActivityRequest',
        'activity_participant'       => 'Solaris\\BaseCRM\\Http\\Requests\\ActivityParticipantRequest',
        'activity_promoted_product'  => 'Solaris\\BaseCRM\\Http\\Requests\\ActivityPromotedProductRequest',

        'lead' => 'Solaris\\BaseCRM\\Http\\Requests\\LeadRequest',
    ],

    /*
    |--------------------------------------------------------------------------
    | 3rd Party API
    |--------------------------------------------------------------------------
    */
    'api' => [
        'controllers' => [
            'account'  => 'Solaris\\BaseCRM\\Http\\Controllers\\Api\\AccountController',
            'contact'  => 'Solaris\\BaseCRM\\Http\\Controllers\\Api\\ContactController',
            'activity' => 'Solaris\\BaseCRM\\Http\\Controllers\\Api\\ActivityController',
            'lead'     => 'Solaris\\BaseCRM\\Http\\Controllers\\Api\\LeadController',
        ],

        'resources' => [
            'account'  => 'Solaris\\BaseCRM\\Http\\Resources\\Api\\AccountResource',
            'contact'  => 'Solaris\\BaseCRM\\Http\\Resources\\Api\\ContactResource',
            'activity' => 'Solaris\\BaseCRM\\Http\\Resources\\Api\\ActivityResource',
            'lead'     => 'Solaris\\BaseCRM\\Http\\Resources\\Api\\LeadResource',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Mobile
    |--------------------------------------------------------------------------
    */
    'mobile' => [
        'controllers' => [
            'account'                => 'Solaris\\BaseCRM\\Http\\Controllers\\Mobile\\AccountController',
            'account_bank'           => 'Solaris\\BaseCRM\\Http\\Controllers\\Mobile\\AccountBankController',
            'account_status_history' => 'Solaris\\BaseCRM\\Http\\Controllers\\Mobile\\AccountStatusHistoryController',

            'contact'                   => 'Solaris\\BaseCRM\\Http\\Controllers\\Mobile\\ContactController',
            'contact_noteworthy_event'  => 'Solaris\\BaseCRM\\Http\\Controllers\\Mobile\\ContactNoteworthyEventController',
            'contact_previous_company'  => 'Solaris\\BaseCRM\\Http\\Controllers\\Mobile\\ContactPreviousCompanyController',
            'contact_status_history'    => 'Solaris\\BaseCRM\\Http\\Controllers\\Mobile\\ContactStatusHistoryController',

            'activity'                   => 'Solaris\\BaseCRM\\Http\\Controllers\\Mobile\\ActivityController',
            'activity_participant'       => 'Solaris\\BaseCRM\\Http\\Controllers\\Mobile\\ActivityParticipantController',
            'activity_promoted_product'  => 'Solaris\\BaseCRM\\Http\\Controllers\\Mobile\\ActivityPromotedProductController',

            'lead'                => 'Solaris\\BaseCRM\\Http\\Controllers\\Mobile\\LeadController',
            'lead_status_history' => 'Solaris\\BaseCRM\\Http\\Controllers\\Mobile\\LeadStatusHistoryController',
        ],

        'resources' => [
            'account'                => 'Solaris\\BaseCRM\\Http\\Resources\\Mobile\\AccountResource',
            'account_bank'           => 'Solaris\\BaseCRM\\Http\\Resources\\Mobile\\AccountBankResource',
            'account_status_history' => 'Solaris\\BaseCRM\\Http\\Resources\\Mobile\\AccountStatusHistoryResource',

            'contact'                   => 'Solaris\\BaseCRM\\Http\\Resources\\Mobile\\ContactResource',
            'contact_noteworthy_event'  => 'Solaris\\BaseCRM\\Http\\Resources\\Mobile\\ContactNoteworthyEventResource',
            'contact_previous_company'  => 'Solaris\\BaseCRM\\Http\\Resources\\Mobile\\ContactPreviousCompanyResource',
            'contact_status_history'    => 'Solaris\\BaseCRM\\Http\\Resources\\Mobile\\ContactStatusHistoryResource',

            'activity'                   => 'Solaris\\BaseCRM\\Http\\Resources\\Mobile\\ActivityResource',
            'activity_participant'       => 'Solaris\\BaseCRM\\Http\\Resources\\Mobile\\ActivityParticipantResource',
            'activity_promoted_product'  => 'Solaris\\BaseCRM\\Http\\Resources\\Mobile\\ActivityPromotedProductResource',

            'lead'                => 'Solaris\\BaseCRM\\Http\\Resources\\Mobile\\LeadResource',
            'lead_status_history' => 'Solaris\\BaseCRM\\Http\\Resources\\Mobile\\LeadStatusHistoryResource',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | AI
    |--------------------------------------------------------------------------
    */
    'ai' => [
        'tools' => [
            // Overrides MasterData's create/update/search for account/contact/activity with CRM-extended fields.
            'create_account'  => 'Solaris\\BaseCRM\\Ai\\Tools\\Account\\CreateAccountTool',
            'update_account'  => 'Solaris\\BaseCRM\\Ai\\Tools\\Account\\UpdateAccountTool',
            'search_account'  => 'Solaris\\BaseCRM\\Ai\\Tools\\Account\\SearchAccountTool',

            'create_contact'  => 'Solaris\\BaseCRM\\Ai\\Tools\\Contact\\CreateContactTool',
            'update_contact'  => 'Solaris\\BaseCRM\\Ai\\Tools\\Contact\\UpdateContactTool',
            'search_contact'  => 'Solaris\\BaseCRM\\Ai\\Tools\\Contact\\SearchContactTool',

            'create_activity' => 'Solaris\\BaseCRM\\Ai\\Tools\\Activity\\CreateActivityTool',
            'update_activity' => 'Solaris\\BaseCRM\\Ai\\Tools\\Activity\\UpdateActivityTool',
            'search_activity' => 'Solaris\\BaseCRM\\Ai\\Tools\\Activity\\SearchActivityTool',

            'create_account_bank' => 'Solaris\\BaseCRM\\Ai\\Tools\\AccountBank\\CreateAccountBankTool',
            'update_account_bank' => 'Solaris\\BaseCRM\\Ai\\Tools\\AccountBank\\UpdateAccountBankTool',
            'delete_account_bank' => 'Solaris\\BaseCRM\\Ai\\Tools\\AccountBank\\DeleteAccountBankTool',
            'search_account_bank' => 'Solaris\\BaseCRM\\Ai\\Tools\\AccountBank\\SearchAccountBankTool',
            'search_account_status_history' => 'Solaris\\BaseCRM\\Ai\\Tools\\AccountStatusHistory\\SearchAccountStatusHistoryTool',

            'create_contact_noteworthy_event' => 'Solaris\\BaseCRM\\Ai\\Tools\\ContactNoteworthyEvent\\CreateContactNoteworthyEventTool',
            'update_contact_noteworthy_event' => 'Solaris\\BaseCRM\\Ai\\Tools\\ContactNoteworthyEvent\\UpdateContactNoteworthyEventTool',
            'delete_contact_noteworthy_event' => 'Solaris\\BaseCRM\\Ai\\Tools\\ContactNoteworthyEvent\\DeleteContactNoteworthyEventTool',
            'search_contact_noteworthy_event' => 'Solaris\\BaseCRM\\Ai\\Tools\\ContactNoteworthyEvent\\SearchContactNoteworthyEventTool',

            'create_contact_previous_company' => 'Solaris\\BaseCRM\\Ai\\Tools\\ContactPreviousCompany\\CreateContactPreviousCompanyTool',
            'update_contact_previous_company' => 'Solaris\\BaseCRM\\Ai\\Tools\\ContactPreviousCompany\\UpdateContactPreviousCompanyTool',
            'delete_contact_previous_company' => 'Solaris\\BaseCRM\\Ai\\Tools\\ContactPreviousCompany\\DeleteContactPreviousCompanyTool',
            'search_contact_previous_company' => 'Solaris\\BaseCRM\\Ai\\Tools\\ContactPreviousCompany\\SearchContactPreviousCompanyTool',
            'search_contact_status_history'   => 'Solaris\\BaseCRM\\Ai\\Tools\\ContactStatusHistory\\SearchContactStatusHistoryTool',

            'create_activity_participant'      => 'Solaris\\BaseCRM\\Ai\\Tools\\ActivityParticipant\\CreateActivityParticipantTool',
            'update_activity_participant'      => 'Solaris\\BaseCRM\\Ai\\Tools\\ActivityParticipant\\UpdateActivityParticipantTool',
            'delete_activity_participant'      => 'Solaris\\BaseCRM\\Ai\\Tools\\ActivityParticipant\\DeleteActivityParticipantTool',
            'search_activity_participant'      => 'Solaris\\BaseCRM\\Ai\\Tools\\ActivityParticipant\\SearchActivityParticipantTool',

            'create_activity_promoted_product' => 'Solaris\\BaseCRM\\Ai\\Tools\\ActivityPromotedProduct\\CreateActivityPromotedProductTool',
            'update_activity_promoted_product' => 'Solaris\\BaseCRM\\Ai\\Tools\\ActivityPromotedProduct\\UpdateActivityPromotedProductTool',
            'delete_activity_promoted_product' => 'Solaris\\BaseCRM\\Ai\\Tools\\ActivityPromotedProduct\\DeleteActivityPromotedProductTool',
            'search_activity_promoted_product' => 'Solaris\\BaseCRM\\Ai\\Tools\\ActivityPromotedProduct\\SearchActivityPromotedProductTool',

            'create_lead' => 'Solaris\\BaseCRM\\Ai\\Tools\\Lead\\CreateLeadTool',
            'update_lead' => 'Solaris\\BaseCRM\\Ai\\Tools\\Lead\\UpdateLeadTool',
            'delete_lead' => 'Solaris\\BaseCRM\\Ai\\Tools\\Lead\\DeleteLeadTool',
            'search_lead' => 'Solaris\\BaseCRM\\Ai\\Tools\\Lead\\SearchLeadTool',
            'search_lead_status_history' => 'Solaris\\BaseCRM\\Ai\\Tools\\LeadStatusHistory\\SearchLeadStatusHistoryTool',
        ],
    ],
];
