# Changelog

All notable changes to `Solaris-Laravel-BaseCRM` will be documented in this file.

---

## [v0.8.4] — 18 Aug 2026
- Extended the 3rd-party API with BaseCRM fields and added lead: Account/Contact gain their BaseCRM columns without MasterData declaring any; new `Api\LeadController` + `LeadResource` declare lead in full (no MasterData layer beneath it). Lead's account/contact link fields and disqualification pair are closed to plain updates and get dedicated endpoints instead — the first two carry denormalised copies only the link logic knows how to refresh. Converting a lead answers with the created record or refuses with 409 and near matches, force overrides.
- Moved lead account/contact linking (six denormalised columns copied from the account) out of the mobile controller into `LeadRepository::linkAccount()`/`linkContact()`, so every route that links a lead shares one copy instead of each keeping its own list.
- `ApiPermissionSeeder` reworked to seed one integration `Role` per API permission entity, matching the MasterData/Core pattern.
- Updated masterdata dependency to v0.11.4

## [v0.8.3] — 12 Aug 2026
- Fixed lead list column rendering: bound `nameColumnRender` to date column, updated link to use `rowData.name` while showing date separately (fixes mismatched column rendering/sorting)
- Fixed lead-info budget field id from `lead-page-budget_range_id:budget_range_id` to `lead-page-budget:budget` to match component usage
- Updated masterdata dependency to v0.11.3

## [v0.8.2] — 11 Aug 2026
- Replaced raw `'validation'` error strings with `AiErrorCode::UserError` in Contact create/update AI tools
- Renamed `findRecord(Request $request)` to `findRecordById(string $id)` in Lead and Contact (NoteworthyEvent/PreviousCompany) delete/update AI tools, typed `delete()` to accept `Model`, removed `Laravel\Ai\Tools\Request` dependency
- Reworked `AiRegistrySeeder`: moved lead search tool grant from a standalone role into `grantActivityLeadSearch()` on the existing "AI Agent Activity" role, split `seedLead()` into `seedLeadPermissions()`
- Clarified AI tool help text across Account, AccountBank, Activity, ActivityParticipant, ActivityPromotedProduct, Contact, Lead, and related status-history tools — replaced "Obtain via X first" wording with references to the corresponding search tool
- Added null-safe `Carbon::parse(...)` date formatting to several search tools, removed redundant `created_at`/`updated_at` search columns
- Updated masterdata dependency to v0.11.2

## [v0.8.1] — 30 Jul 2026
- Standardized AI tool error responses: replaced raw `'validation'` strings with `AiErrorCode::UserError` across Account, Activity, and Contact create/update tools
- Renamed `findRecord(Request $request)` to `findRecordById(string $id)` in delete/update AI tools (AccountBank, ActivityParticipant, ActivityPromotedProduct, Contact NoteworthyEvent/PreviousCompany, Lead), type-hinted `delete()` to accept `Model`, removed `Laravel\Ai\Tools\Request` dependency
- Added optional `$transaction` constructor parameter to `AccountRepository` and `LeadRepository`, forwarded to parent
- Reworked `AiRegistrySeeder`: removed standalone "AI Agent Lead" role/creation, split into `seedLeadPermissions()` and `grantActivityLeadSearch()` (grants lead search permission to existing "AI Agent Activity" role), added `search_lead`/`search_product` tools to activity group
- Updated masterdata dependency to v0.11.1

## [v0.8.0] — 28 Jul 2026
- Added AI CRUD tools (create/update/delete) for Account, AccountBank, Activity, ActivityParticipant, ActivityPromotedProduct, Contact, ContactNoteworthyEvent, ContactPreviousCompany, and Lead
- Added `SearchLeadStatusHistoryTool` and `AiRegistrySeeder` (wires AI tools to agents, seeds "AI Agent Lead" role with lead permissions), registered in `DatabaseSeeder`
- Simplified AI tool registration: removed `registerAiTools()` from `SolarisBaseCRMServiceProvider`, now fully driven by `config/solaris.php`
- Refactored search tools to `slug`/`resourceLabel`/`model`/`fields` method naming for consistency with new base class interface
- Split form request validation into static `createRules()`/`updateRules()` across AccountBankRequest, ActivityParticipantRequest, ActivityPromotedProductRequest, ContactNoteworthyEventRequest, ContactPreviousCompanyRequest, AccountRequest, ContactRequest, LeadRequest
- Added lead budget field (UI + backend) and lead owner display in list/profile-contact sections
- Exposed `Lead::activities` relationship, added budget to `LeadRepository` selects
- Updated masterdata dependency to v0.11.0

## [v0.7.0] — 21 Jul 2026
- Added AI search tools for Account, AccountBank, AccountStatusHistory, Activity, ActivityParticipant, ActivityPromotedProduct, Contact, ContactNoteworthyEvent, ContactPreviousCompany, ContactStatusHistory, and Lead
- Registered new AI tools in `SolarisBaseCRMServiceProvider`
- Reorganized `config/solaris.php` structure with improved documentation
- Added `notes_plain` column to leads table, auto-synced from HTML notes for full-text search
- Updated masterdata dependency to v0.10.0
- Fixed `frequency`/`frequency_type_id` validation in `AccountRequest`, moved from inline closures to `withValidator`
- Changed `createRules()`/`updateRules()` to `static` in `ActivityRequest` to match parent package signature
- Refactored `LeadRepository` duplicate matching to use shared `Helper::similaritySql()` instead of local `buildNameMatch()`

## [v0.6.9] — 8 Jul 2026
- Updated masterdata dependency to v0.9.0
- Changed `updateRules()` to `static` in `AccountRequest` and `ContactRequest` to match parent package signature
- Replaced disqualification reason input with lookup component in Lead info section
- Renamed KTP/NPWP labels to ID Number/Tax ID in Contact page
- Removed unused `jsconfig.json` path aliases
- Updated notes component usage (`table_name` → `model` + `column`) across Account, Contact, Lead, Product pages
- Added `LeadStatusSeeder` to `DatabaseSeeder`

## [v0.6.8] — 29 Jun 2026
- Fixed bug in lead disqualification

## [v0.6.7] — 29 Jun 2026
- Updated activity layout and info section

## [v0.6.6] — 26 Jun 2026
- Added `card_wrapper` in table detail view
- Removed `row` param from `importRules` models

## [v0.6.5] — 23 Jun 2026
- Updated masterdata dependency to v0.8.0

## [v0.6.4] — 5 Jun 2026
- Updated Lead module; added handler state for "Create Existing Account/Contact" button

## [v0.6.3] — 4 Jun 2026
- Updated stage flow in Account, Contact, and Lead with default confirm behavior

## [v0.6.2] — 3 Jun 2026
- Lead module improvements including disqualification process
- Contact and Account module updates
- Mobile API updates

## [v0.6.1] — 26 May 2026
- Fixed bug with "Create Anyway" button in Lead
- Fixed Lead detail display inside Contact page

## [v0.6.0] — 25 May 2026
- Major Lead module redesign (v2) with new UI and seeder
- Expanded mobile API for Account, Contact, Activity, and Lead modules
- Added history status detail to Account page
- Improved CRM info layout and customer need section

## [v0.5.0] — 24 Apr 2026
- Renamed `AcitivityModal` to `ActivityModal` and moved default to ActivityDetail
- Notes component improved with new prop support
- Fixed breaking change in return type hint

## [v0.4.6] — 19 Apr 2026
- Fixed breaking change in lookup Blade component; removed `id` from slot field

## [v0.4.5] — 1 Apr 2026
- Fixed Lead lookup selection template in Activity page

## [v0.4.4] — 31 Mar 2026
- Added default import rules to model

## [v0.4.3] — 30 Mar 2026
- Added `ExportAccess` and `ImportAccess` support to model

## [v0.4.2] — 27 Mar 2026
- Documentation update

## [v0.4.1] — 26 Mar 2026
- Removed deprecated `dropdown_parent` prop from select component

## [v0.4.0] — 26 Mar 2026
- Lead module update including Lead source constants

## [v0.3.4] — 11 Mar 2026
- Fixed nullable support for Lead `last_budget` field

## [v0.3.3] — 11 Mar 2026
- Bug fixes and Activity page adjustments

## [v0.3.2] — 16 Feb 2026
- Minor updates

## [v0.3.1] — 16 Feb 2026
- Updated view aliases: `@solar` → `@core`, `@solar-md` → `@master-data`, `@solar-bc` → `@base-crm`
- Service provider updates

## [v0.3.0] — 11 Feb 2026
- Namespace change across the package
- Config, migration, and menu seeder updates

## [v0.2.1] — 29 Jan 2026
- Added "Delete All" action to list pages

## [v0.2.0] — 12 Jan 2026
- Implemented batch delete for list pages
- Added status history for Account and Contact modules
- Lead module and migration improvements

## [v0.1.3.2] — 19 Dec 2025
- Fixed nullable support for Lead budget field

## [v0.1.3.1] — 16 Dec 2025
- Extended column support

## [v0.1.3] — 15 Dec 2025
- Version bump

## [v0.1.2] — 15 Dec 2025
- Account controller updates

## [v0.1.1] — 12 Dec 2025
- Updated master-data dependency to v0.2.1

## [v0.1.0] — 8 Dec 2025
- Major view layer refactor; Blade component concept overhaul

## [v0.0.4] — 3 Dec 2025
- Updated to new response macros
- Added deleting/deleted lifecycle hooks to repository
- New Lead status JS constants

## [v0.0.3] — 28 Nov 2025
- Updated masterdata dependency to v0.1.7

## [v0.0.2] — 28 Nov 2025
- Added menu seeder
- Refactored response and request handling

## [v0.0.1] — 27 Nov 2025
- Initial release
- Lead management feature (CRUD, status history, lead tab in Contact)
- Activity management with ActivityAction helper
- Account-Lead integration and detail view
- Product page with promoted product tab
