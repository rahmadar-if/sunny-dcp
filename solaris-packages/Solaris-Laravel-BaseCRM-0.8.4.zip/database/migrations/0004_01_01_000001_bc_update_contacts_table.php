<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('contact_statuses', function (Blueprint $table) {
            MigrationHelper::baseLookupStage($table);
        });

        Schema::table('contacts', function (Blueprint $table) {
            $table->string('npwp', 16)->nullable();
            $table->string('no_ktp', 16)->nullable();

            $table->foreignUuid('status_id')->nullable()->constrained('contact_statuses')->nullOnDelete();
            $table->foreignUuid('segmentation_id')->nullable()->constrained('segmentations')->nullOnDelete();

            if (config('database.default') == 'pgsql') {
                $table->index(['status_id']);
                $table->index(['segmentation_id']);
            }
        });

        Schema::create('noteworthy_event_types', function (Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('contact_noteworthy_events', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->date('date')->nullable();
            $table->text('notes')->nullable();

            $table->foreignUuid('contact_id')->nullable()->constrained('contacts')->cascadeOnDelete();
            $table->foreignUuid('type_id')->nullable()->constrained('noteworthy_event_types')->nullOnDelete();

            if (config('database.default') == 'pgsql') {
                $table->index(['contact_id']);
                $table->index(['type_id']);
            }
        });

        Schema::create('contact_previous_companies', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->boolean('active')->default(false);
            $table->string('role')->nullable();
            $table->date('start_date')->nullable();
            $table->date('end_date')->nullable();

            $table->foreignUuid('contact_id')->nullable()->constrained('contacts')->cascadeOnDelete();
            $table->foreignUuid('account_id')->nullable()->constrained('accounts')->nullOnDelete();

            if (config('database.default') == 'pgsql') {
                $table->index(['contact_id']);
                $table->index(['account_id']);
            }
        });

        Schema::create('contact_status_histories', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->smallInteger('position');
            $table->timestamp('start')->nullable();
            $table->timestamp('end')->nullable();

            $table->foreignUuid('contact_id')->nullable()->constrained('contacts')->cascadeOnDelete();
            $table->foreignUuid('status_id')->nullable()->constrained('contact_statuses')->cascadeOnDelete();

            if(config('database.default') == 'pgsql') {
                $table->index(['contact_id']);
                $table->index(['status_id']);
            }
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('contact_status_histories');
        Schema::dropIfExists('contact_noteworthy_events');
        Schema::dropIfExists('noteworthy_event_types');
        Schema::dropIfExists('contact_previous_companies');

        Schema::table('contacts', function (Blueprint $table) {
            $table->dropForeign(['status_id']);
            $table->dropForeign(['segmentation_id']);

            if (config('database.default') == 'pgsql') {
                $table->dropIndex(['status_id']);
                $table->dropIndex(['segmentation_id']);
            }

            $table->dropColumn('status_id');
            $table->dropColumn('segmentation_id');
        });

        Schema::dropIfExists('contact_statuses');
    }
};
