<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        if (DB::getDriverName() === 'pgsql') {
            DB::statement('CREATE EXTENSION IF NOT EXISTS pg_trgm');
        }

        Schema::create('budget_ranges', function (Blueprint $table) {
            MigrationHelper::baseLookup($table);
            $table->decimal('min_amount', 19, 2)->nullable();
            $table->decimal('max_amount', 19, 2)->nullable();
        });

        Schema::create('disqualification_reasons', function (Blueprint $table) {
            MigrationHelper::baseLookup($table);
            $table->boolean('require_reason_text')->default(false);
        });

        Schema::table('leads', function (Blueprint $table) {
            $table->dropColumn('budget');
            $table->dropColumn('last_budget');
            $table->dropForeign(['customer_journey_id']);
            $table->dropColumn('customer_journey_id');

            $table->string('account_name')->nullable()->after('name');
            $table->string('contact_name')->nullable()->after('account_name');
            $table->string('contact_job_title', 100)->nullable()->after('contact_name');

            $table->boolean('is_new_account')->default(false)->after('account_id');
            $table->boolean('is_new_contact')->default(false)->after('contact_id');
            $table->boolean('add_to_calendar')->default(false)->after('is_new_contact');

            $table->renameColumn('next_actualization_date', 'follow_up_date');
            $table->dateTime('follow_up_remind_at')->nullable()->after('follow_up_date');
            $table->boolean('is_follow_up_reminded')->default(false)->after('follow_up_remind_at');

            $table->foreignUuid('budget_range_id')->nullable()->constrained('budget_ranges')->nullOnDelete()->after('contact_id');
            $table->foreignUuid('disqualification_reason_id')->nullable()->constrained('disqualification_reasons')->nullOnDelete()->after('status_id');
            $table->text('disqualification_reason_text')->nullable()->after('disqualification_reason_id');

            MigrationHelper::createIndexIfNeeds($table, ['budget_range_id']);
            MigrationHelper::createIndexIfNeeds($table, ['disqualification_reason_id']);
        });
    }

    public function down(): void
    {
        Schema::table('leads', function (Blueprint $table) {
            $table->dropForeign(['budget_range_id']);
            $table->dropForeign(['disqualification_reason_id']);

            MigrationHelper::dropIndexIfNeeds($table, ['budget_range_id']);
            MigrationHelper::dropIndexIfNeeds($table, ['disqualification_reason_id']);

            $table->dropColumn([
                'account_name',
                'contact_name',
                'contact_job_title',
                'is_new_account',
                'is_new_contact',
                'add_to_calendar',
                'follow_up_remind_at',
                'is_follow_up_reminded',
                'budget_range_id',
                'disqualification_reason_id',
                'disqualification_reason_text',
            ]);

            $table->renameColumn('follow_up_date', 'next_actualization_date');

            $table->decimal('budget', 19, 2)->nullable()->default(0);
            $table->decimal('last_budget', 19, 2)->nullable()->default(0);
            $table->foreignUuid('customer_journey_id')->nullable()->constrained('customer_journeys')->nullOnDelete();
        });

        Schema::dropIfExists('disqualification_reasons');
        Schema::dropIfExists('budget_ranges');
    }
};
