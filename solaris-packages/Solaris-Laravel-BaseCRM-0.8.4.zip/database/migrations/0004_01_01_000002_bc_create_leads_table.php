<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('lead_sources', function (Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('lead_registration_methods', function (Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('lead_statuses', function (Blueprint $table) {
            MigrationHelper::baseLookupStage($table);
        });

        Schema::create('leads', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('name')->nullable();
            $table->date('date')->nullable();
            $table->string('phone', 50)->nullable();
            $table->string('email')->nullable();
            $table->decimal('budget', 19, 2)->nullable()->default(0);
            $table->text('customer_need')->nullable();
            $table->text('notes')->nullable();
            $table->decimal('last_budget', 19, 2)->default(0);
            $table->date('next_actualization_date')->nullable();

            $table->foreignUuid('account_id')->nullable()->constrained('accounts')->nullOnDelete();
            $table->foreignUuid('contact_id')->nullable()->constrained('contacts')->nullOnDelete();
            $table->foreignUuid('status_id')->nullable()->constrained('lead_statuses')->nullOnDelete();

            $table->foreignUuid('source_id')->nullable()->constrained('lead_sources')->nullOnDelete();
            $table->foreignUuid('registration_method_id')->nullable()->constrained('lead_registration_methods')->nullOnDelete();
            $table->foreignUuid('segmentation_id')->nullable()->constrained('segmentations')->nullOnDelete();
            $table->foreignUuid('number_of_employee_id')->nullable()->constrained('number_of_employees')->nullOnDelete();
            $table->foreignUuid('annual_revenue_id')->nullable()->constrained('annual_revenues')->nullOnDelete();
            $table->foreignUuid('business_size_id')->nullable()->constrained('business_sizes')->nullOnDelete();
            $table->foreignUuid('customer_journey_id')->nullable()->constrained('customer_journeys')->nullOnDelete();
            $table->foreignUuid('industry_id')->nullable()->constrained('industries')->nullOnDelete();

            if (config('database.default') == 'pgsql') {
                $table->index(['account_id']);
                $table->index(['contact_id']);
                $table->index(['status_id']);

                $table->index(['source_id']);
                $table->index(['registration_method_id']);
                $table->index(['segmentation_id']);
                $table->index(['number_of_employee_id']);
                $table->index(['annual_revenue_id']);
                $table->index(['business_size_id']);
                $table->index(['customer_journey_id']);
                $table->index(['industry_id']);
            }
        });

        Schema::create('lead_status_histories', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->smallInteger('position');
            $table->timestamp('start')->nullable();
            $table->timestamp('end')->nullable();

            $table->foreignUuid('lead_id')->nullable()->constrained('leads')->cascadeOnDelete();
            $table->foreignUuid('status_id')->nullable()->constrained('lead_statuses')->cascadeOnDelete();

            if (config('database.default') == 'pgsql') {
                $table->index(['lead_id']);
                $table->index(['status_id']);
            }
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('lead_status_histories');
        Schema::dropIfExists('leads');
        Schema::dropIfExists('lead_statuses');
        Schema::dropIfExists('lead_registration_methods');
        Schema::dropIfExists('lead_sources');
    }
};
