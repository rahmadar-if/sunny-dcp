<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Helper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('leads', function (Blueprint $table) {
            $table->text('notes_plain')->nullable()->after('notes');
            $table->decimal('budget', 19, 2)->nullable()->default(0)->after('budget_range_id');
        });

        if (config('database.default') === 'pgsql') {
            Schema::table('leads', function (Blueprint $table) {
                $table->fullText(['notes_plain'])->language(Helper::fullTextLanguage());
            });
        }
    }

    public function down(): void
    {
        if (config('database.default') === 'pgsql') {
            Schema::table('leads', function (Blueprint $table) {
                $table->dropFullText(['notes_plain']);
            });
        }

        Schema::table('leads', function (Blueprint $table) {
            $table->dropColumn('notes_plain');
            $table->dropColumn('budget');
        });
    }
};
