<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('activity_participants', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('name')->nullable();
            $table->string('role')->nullable();
            $table->text('notes')->nullable();

            $table->foreignUuid('activity_id')->nullable()->constrained('activities')->cascadeOnDelete();

            if (config('database.default') == 'pgsql') {
                $table->index(['activity_id']);
            }
        });

        Schema::create('activity_promoted_products', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->date('date')->nullable();
            $table->text('status')->nullable();

            $table->foreignUuid('product_id')->nullable()->constrained('products')->cascadeOnDelete();
            $table->foreignUuid('activity_id')->nullable()->constrained('activities')->cascadeOnDelete();

            if (config('database.default') == 'pgsql') {
                $table->index(['product_id']);
                $table->index(['activity_id']);
            }
        });

        Schema::create('activity_results', function (Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::table('activities', function (Blueprint $table) {
            $table->text('detail_result')->nullable();
            $table->foreignUuid('result_id')->nullable()->constrained('activity_results')->nullOnDelete();
            $table->foreignUuid('lead_id')->nullable()->constrained('leads')->nullOnDelete();

            if (config('database.default') == 'pgsql') {
                $table->index(['result_id']);
                $table->index(['lead_id']);
            }
        });
    }

    public function down(): void
    {
        Schema::table('activities', function (Blueprint $table) {
            $table->dropForeign(['result_id']);
            $table->dropForeign(['lead_id']);

            if (config('database.default') == 'pgsql') {
                $table->dropIndex(['result_id']);
                $table->dropIndex(['lead_id']);
            }

            $table->dropColumn('result_id');
            $table->dropColumn('lead_id');
        });

        Schema::dropIfExists('activity_results');
        Schema::dropIfExists('activity_promoted_products');
        Schema::dropIfExists('activity_participants');
    }
};
