<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('account_statuses', function (Blueprint $table) {
            MigrationHelper::baseLookupStage($table);
        });

        Schema::create('annual_revenues', function (Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('customer_journeys', function (Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('segmentations', function (Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('business_sizes', function (Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('frequency_types', function (Blueprint $table) {
            MigrationHelper::baseLookup($table);
        });

        Schema::create('account_banks', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('bank_name')->nullable();
            $table->string('account_number')->nullable();
            $table->string('account_name')->nullable();

            $table->foreignUuid('account_id')->nullable()->constrained('accounts')->cascadeOnDelete();
            $table->foreignUuid('country_id')->nullable()->constrained('countries')->nullOnDelete();

            if (config('database.default') == 'pgsql') {
                $table->index(['account_id']);
                $table->index(['country_id']);
            }
        });

        Schema::table('accounts', function (Blueprint $table) {
            $table->date('recency_date')->nullable();
            $table->decimal('monetary', 19, 2)->default(0);
            $table->unsignedInteger('frequency')->default(0);
            $table->foreignUuid('status_id')->nullable()->constrained('account_statuses')->nullOnDelete();
            $table->foreignUuid('annual_revenue_id')->nullable()->constrained('annual_revenues')->nullOnDelete();
            $table->foreignUuid('customer_journey_id')->nullable()->constrained('customer_journeys')->nullOnDelete();
            $table->foreignUuid('segmentation_id')->nullable()->constrained('segmentations')->nullOnDelete();
            $table->foreignUuid('business_size_id')->nullable()->constrained('business_sizes')->nullOnDelete();
            $table->foreignUuid('frequency_type_id')->nullable()->constrained('frequency_types')->nullOnDelete();

            if (config('database.default') == 'pgsql') {
                $table->index(['status_id']);
                $table->index(['annual_revenue_id']);
                $table->index(['customer_journey_id']);
                $table->index(['segmentation_id']);
                $table->index(['business_size_id']);
                $table->index(['frequency_type_id']);
            }
        });

        Schema::create('account_status_histories', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->smallInteger('position');
            $table->timestamp('start')->nullable();
            $table->timestamp('end')->nullable();

            $table->foreignUuid('account_id')->nullable()->constrained('accounts')->cascadeOnDelete();
            $table->foreignUuid('status_id')->nullable()->constrained('account_statuses')->cascadeOnDelete();

            if(config('database.default') == 'pgsql') {
                $table->index(['account_id']);
                $table->index(['status_id']);
            }
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('account_status_histories');
        Schema::table('accounts', function (Blueprint $table) {
            $table->dropForeign(['status_id']);
            $table->dropForeign(['annual_revenue_id']);
            $table->dropForeign(['customer_journey_id']);
            $table->dropForeign(['segmentation_id']);
            $table->dropForeign(['business_size_id']);
            $table->dropForeign(['frequency_type_id']);

            if (config('database.default') == 'pgsql') {
                $table->dropIndex(['status_id']);
                $table->dropIndex(['annual_revenue_id']);
                $table->dropIndex(['customer_journey_id']);
                $table->dropIndex(['segmentation_id']);
                $table->dropIndex(['business_size_id']);
                $table->dropIndex(['frequency_type_id']);
            }

            $table->dropColumn('status_id');
            $table->dropColumn('annual_revenue_id');
            $table->dropColumn('customer_journey_id');
            $table->dropColumn('segmentation_id');
            $table->dropColumn('business_size_id');
            $table->dropColumn('frequency_type_id');
            $table->dropColumn('frequency');
            $table->dropColumn('monetary');
            $table->dropColumn('recency_date');
        });

        Schema::dropIfExists('account_banks');
        Schema::dropIfExists('account_statuses');
        Schema::dropIfExists('annual_revenues');
        Schema::dropIfExists('customer_journeys');
        Schema::dropIfExists('segmentations');
        Schema::dropIfExists('business_sizes');
        Schema::dropIfExists('frequency_types');
    }
};
