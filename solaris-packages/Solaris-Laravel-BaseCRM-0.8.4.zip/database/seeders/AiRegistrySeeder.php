<?php

namespace Solaris\BaseCRM\Database\Seeders;

use Illuminate\Database\Seeder;
use Solaris\Core\Models\AiAgent;
use Solaris\Core\Models\AiTool;
use Solaris\Core\Models\Permission;
use Solaris\Core\Models\Role;

class AiRegistrySeeder extends Seeder
{
    protected array $wiring = [
        'customer' => [
            'create_account_bank', 'update_account_bank', 'delete_account_bank', 'search_account_bank',
            'search_account_status_history',
            'create_contact_noteworthy_event', 'update_contact_noteworthy_event', 'delete_contact_noteworthy_event', 'search_contact_noteworthy_event',
            'create_contact_previous_company', 'update_contact_previous_company', 'delete_contact_previous_company', 'search_contact_previous_company',
            'search_contact_status_history',
        ],
        'activity' => [
            'create_activity_participant', 'update_activity_participant', 'delete_activity_participant', 'search_activity_participant',
            'create_activity_promoted_product', 'update_activity_promoted_product', 'delete_activity_promoted_product', 'search_activity_promoted_product',
            // search_product access wired in MasterData's AiScopedToolSeeder (scoped variant) — leaving it
            // here would re-attach the full tool on any seed run ordered after that one.
            'search_lead',
        ],
    ];

    protected array $childPermissions = [
        'AI Tool Account Create' => ['create_account_bank'],
        'AI Tool Account Update' => ['update_account_bank'],
        'AI Tool Account Delete' => ['delete_account_bank'],
        'AI Tool Account Search' => ['search_account_bank', 'search_account_status_history'],
        'AI Tool Contact Create' => ['create_contact_noteworthy_event', 'create_contact_previous_company'],
        'AI Tool Contact Update' => ['update_contact_noteworthy_event', 'update_contact_previous_company'],
        'AI Tool Contact Delete' => ['delete_contact_noteworthy_event', 'delete_contact_previous_company'],
        'AI Tool Contact Search' => ['search_contact_noteworthy_event', 'search_contact_previous_company', 'search_contact_status_history'],
        'AI Tool Activity Create' => ['create_activity_participant', 'create_activity_promoted_product'],
        'AI Tool Activity Update' => ['update_activity_participant', 'update_activity_promoted_product'],
        'AI Tool Activity Delete' => ['delete_activity_participant', 'delete_activity_promoted_product'],
        'AI Tool Activity Search' => ['search_activity_participant', 'search_activity_promoted_product'],
    ];

    protected array $leadPermissions = [
        'AI Tool Lead Create' => [
            'id'          => '019fa6c5-f12d-7d4c-ac3c-18fd3390b527',
            'description' => 'Create leads via AI.',
            'tools'       => ['create_lead'],
        ],
        'AI Tool Lead Update' => [
            'id'          => '019fa6c5-f12d-7c3e-962d-8281e6f95177',
            'description' => 'Update leads via AI.',
            'tools'       => ['update_lead'],
        ],
        'AI Tool Lead Delete' => [
            'id'          => '019fa6c5-f12d-763c-853d-3e28c956d6d4',
            'description' => 'Delete leads via AI.',
            'tools'       => ['delete_lead'],
        ],
        'AI Tool Lead Search' => [
            'id'          => '019fa6c5-f12d-7254-b2bb-342170df4cef',
            'description' => 'Search leads and their status history via AI.',
            'tools'       => ['search_lead', 'search_lead_status_history'],
        ],
    ];

    public function run(): void
    {
        $this->wiring();
        $this->attachChildPermissions();
        $this->seedLeadPermissions();
        $this->grantActivityLeadSearch();
    }

    protected function wiring(): void
    {
        foreach ($this->wiring as $agentSlug => $toolSlugs) {
            $agent = AiAgent::where('slug', $agentSlug)->first();

            if ($agent === null) {
                continue;
            }

            $agent->attachTools(AiTool::whereIn('slug', $toolSlugs)->pluck('id')->all());
        }
    }

    protected function attachChildPermissions(): void
    {
        foreach ($this->childPermissions as $permissionName => $toolSlugs) {
            AiTool::whereIn('slug', $toolSlugs)->get()
                ->each(fn (AiTool $tool) => $tool->assignPermission([$permissionName]));
        }
    }

    protected function seedLeadPermissions(): void
    {
        foreach ($this->leadPermissions as $name => $permission) {
            Permission::firstOrCreate(['id' => $permission['id']], [
                'name'        => $name,
                'description' => $permission['description'],
            ]);

            AiTool::whereIn('slug', $permission['tools'])->get()
                ->each(fn (AiTool $tool) => $tool->assignPermission([$permission['id']]));
        }
    }

    protected function grantActivityLeadSearch(): void
    {
        $role = Role::where('name', 'AI Agent Activity')->first();

        if ($role === null) {
            return;
        }

        $role->assignPermission([$this->leadPermissions['AI Tool Lead Search']['id']]);
    }
}
