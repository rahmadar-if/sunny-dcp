<?php

namespace Solaris\BaseCRM\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Solaris\BaseCRM\Const\AccountStatusConst;
use Solaris\BaseCRM\Const\AnnualRevenueConst;
use Solaris\BaseCRM\Const\BusinessSizeConst;
use Solaris\BaseCRM\Const\CustomerJourneyConst;
use Solaris\BaseCRM\Const\FrequencyConst;
use Solaris\BaseCRM\Const\SegmentationConst;

class UpdateAccountSeeder extends Seeder
{
    public function run(): void
    {
        $this->account_statuses();
        $this->annual_revenues();
        $this->customer_journeys();
        $this->segmentations();
        $this->business_sizes();
        $this->frequency_types();
    }

    protected function account_statuses(): void
    {
        $data = [
            [
                'id'             => AccountStatusConst::PersonalInformation,
                'name'           => 'Personal Information',
                'color'          => 'primary',
                'is_final_stage' => false,
                'position'       => 1
            ],
            [
                'id'             => AccountStatusConst::Draft,
                'name'           => 'Draft',
                'color'          => 'secondary',
                'is_final_stage' => false,
                'position'       => 2
            ],
            [
                'id'             => AccountStatusConst::Verification,
                'name'           => 'Verification',
                'color'          => 'info',
                'is_final_stage' => false,
                'position'       => 3
            ],
            [
                'id'             => AccountStatusConst::Approve,
                'name'           => 'Approve',
                'color'          => 'success',
                'is_final_stage' => true,
                'position'       => 4
            ]
        ];
        DB::table('account_statuses')->insertOrIgnore($data);
    }

    protected function annual_revenues(): void
    {
        $data = [
            [
                'id'       => AnnualRevenueConst::ZeroToFiveBillion,
                'name'     => "0 - 5 Billion",
                'position' => 1,
            ],
            [
                'id'       => AnnualRevenueConst::FiveToTenBillion,
                'name'     => "5 - 10 Billion",
                'position' => 2,
            ],
            [
                'id'       => AnnualRevenueConst::TenToOneHundredBillion,
                'name'     => "10 - 100 Billion",
                'position' => 3,
            ],
            [
                'id'       => AnnualRevenueConst::OneHundredToFiveHundredBillion,
                'name'     => "100 - 500 Billion",
                'position' => 4,
            ],
            [
                'id'       => AnnualRevenueConst::FiveHundredBillionToOneTrillion,
                'name'     => "500 - 1 Trillion",
                'position' => 5,
            ],
            [
                'id'       => AnnualRevenueConst::MoreThanOneTrillion,
                'name'     => "> 1 Trillion",
                'position' => 6,
            ],
        ];
        DB::table('annual_revenues')->insertOrIgnore($data);
    }

    protected function customer_journeys(): void
    {
        $data = [
            [
                'id'       => CustomerJourneyConst::NewCustomer,
                'name'     => 'New Customer',
                'position' => 1
            ],
            [
                'id'       => CustomerJourneyConst::Customer,
                'name'     => 'Customer',
                'position' => 2
            ],
            [
                'id'       => CustomerJourneyConst::ValuesAndBeliefs,
                'name'     => 'Values & Beliefs',
                'position' => 3
            ],
            [
                'id'       => CustomerJourneyConst::Loyalty,
                'name'     => 'Loyalty',
                'position' => 4
            ],
            [
                'id'       => CustomerJourneyConst::Advocate,
                'name'     => 'Advocate',
                'position' => 5
            ],
        ];
        DB::table('customer_journeys')->insertOrIgnore($data);
    }

    protected function segmentations(): void
    {
        $data = [
            [
                'id'       => SegmentationConst::VIP,
                'name'     => 'VIP',
                'position' => 1
            ],
            [
                'id'       => SegmentationConst::Gold,
                'name'     => 'Gold',
                'position' => 2
            ],
            [
                'id'       => SegmentationConst::Bronze,
                'name'     => 'Bronze',
                'position' => 3
            ],
            [
                'id'       => SegmentationConst::Silver,
                'name'     => 'Silver',
                'position' => 4
            ]
        ];
        DB::table('segmentations')->insertOrIgnore($data);
    }

    protected function business_sizes(): void
    {
        $data = [
            [
                'id'       => BusinessSizeConst::SMB,
                'name'     => 'SMB',
                'position' => 1
            ],
            [
                'id'       => BusinessSizeConst::LargeEnterprise,
                'name'     => 'Large Enterprise',
                'position' => 2
            ]
        ];
        DB::table('business_sizes')->insertOrIgnore($data);
    }

    protected function frequency_types(): void
    {
        $data = [
            [
                'id'       => FrequencyConst::Days,
                'name'     => 'Days',
                'position' => 1
            ],
            [
                'id'       => FrequencyConst::Weeks,
                'name'     => 'Weeks',
                'position' => 2
            ],
            [
                'id'       => FrequencyConst::Months,
                'name'     => 'Months',
                'position' => 3
            ],
            [
                'id'       => FrequencyConst::Years,
                'name'     => 'Years',
                'position' => 4
            ]
        ];
        DB::table('frequency_types')->insertOrIgnore($data);
    }
}