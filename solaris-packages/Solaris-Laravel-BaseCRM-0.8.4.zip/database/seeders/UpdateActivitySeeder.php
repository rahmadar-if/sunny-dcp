<?php

namespace Solaris\BaseCRM\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Solaris\BaseCRM\Const\ActivityResultConst;

class UpdateActivitySeeder extends Seeder
{
    public function run(): void
    {
        $this->activity_results();
    }

    protected function activity_results(): void
    {
        $data = [
            [
                'id'       => ActivityResultConst::ReSchedule,
                'name'     => 'Re-Schedule',
                'position' => 1
            ],
            [
                'id'       => ActivityResultConst::Completed,
                'name'     => 'Completed',
                'position' => 2
            ],
            [
                'id'       => ActivityResultConst::NeedOurProduct,
                'name'     => 'Need our product',
                'position' => 3
            ],
        ];
        DB::table('activity_results')->insertOrIgnore($data);
    }
}