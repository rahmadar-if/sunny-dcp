<?php

namespace Solaris\BaseCRM\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Solaris\BaseCRM\Const\LeadRegistrationMethodConst;
use Solaris\BaseCRM\Const\LeadSourceConst;

class LeadSeeder extends Seeder
{
    public function run(): void
    {
        $this->lead_sources();
        $this->lead_registration_methods();

        $this->call([
            LeadStatusSeeder::class
        ]);
    }

    protected function lead_sources(): void
    {
        $data = [
            [
                'id'       => LeadSourceConst::Email,
                'name'     => 'Email',
                'position' => 1
            ],
            [
                'id'       => LeadSourceConst::Call,
                'name'     => 'Call',
                'position' => 2
            ],
            [
                'id'       => LeadSourceConst::SocialMedia,
                'name'     => 'Social Media',
                'position' => 3
            ],
            [
                'id'       => LeadSourceConst::Referral,
                'name'     => 'Referral',
                'position' => 4
            ],
            [
                'id'       => LeadSourceConst::Event,
                'name'     => 'Event',
                'position' => 5
            ],
        ];
        DB::table('lead_sources')->insertOrIgnore($data);
    }

    protected function lead_registration_methods(): void
    {
        $data = [
            [
                'id'       => LeadRegistrationMethodConst::ManualEntry,
                'name'     => 'Manual Entry',
                'position' => 1
            ],
            [
                'id'       => LeadRegistrationMethodConst::WebForm,
                'name'     => 'Web Form',
                'position' => 2
            ],
            [
                'id'       => LeadRegistrationMethodConst::API,
                'name'     => 'API',
                'position' => 3
            ],
            [
                'id'       => LeadRegistrationMethodConst::ChatBot,
                'name'     => 'Chat Bot',
                'position' => 4
            ],
            [
                'id'       => LeadRegistrationMethodConst::ImportExcel,
                'name'     => 'Import Excel',
                'position' => 5
            ]
        ];
        DB::table('lead_registration_methods')->insertOrIgnore($data);
    }

}