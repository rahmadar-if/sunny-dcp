<?php

namespace Solaris\BaseCRM\Database\Seeders;

use Illuminate\Database\Seeder;
use Solaris\BaseCRM\Database\Seeders\LeadSeeder;
use Solaris\BaseCRM\Database\Seeders\UpdateAccountSeeder;
use Solaris\BaseCRM\Database\Seeders\UpdateActivitySeeder;
use Solaris\BaseCRM\Database\Seeders\UpdateContactSeeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            UpdateAccountSeeder::class,
            UpdateContactSeeder::class,
            LeadSeeder::class,
            UpdateActivitySeeder::class,
            MenuSeeder::class,
            LeadStatusSeeder::class,
            ApiPermissionSeeder::class,
            AiRegistrySeeder::class,
        ]);
    }
}