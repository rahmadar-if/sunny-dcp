<?php

namespace Solaris\BaseCRM\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Solaris\BaseCRM\Const\BudgetRangeConst;
use Solaris\BaseCRM\Const\DisqualificationReasonConst;
use Solaris\BaseCRM\Const\LeadStatusConst;

class LeadStatusSeeder extends Seeder
{
    public function run(): void
    {
        $this->lead_statuses();
        $this->budget_ranges();
        $this->disqualification_reasons();
    }

    protected function lead_statuses(): void
    {
        // Remove obsolete statuses that no longer exist in the current design
        DB::table('lead_statuses')->whereIn('id', [
            '5712fbfb-b3ba-4dd7-b828-6b35d5d4e979', // AwaitingSales
        ])->delete();

        $data = [
            [
                'id'             => LeadStatusConst::New,
                'name'           => 'New',
                'position'       => 1,
                'color'          => 'secondary',
                'group_id'       => null,
                'is_final_stage' => false,
            ],
            [
                'id'             => LeadStatusConst::Nurturing,
                'name'           => 'Nurturing',
                'position'       => 2,
                'color'          => 'primary',
                'group_id'       => null,
                'is_final_stage' => false,
            ],
            [
                'id'             => LeadStatusConst::Qualified,
                'name'           => 'Qualified',
                'position'       => 3,
                'color'          => 'success',
                'group_id'       => null,
                'is_final_stage' => true,
            ],
            [
                'id'             => LeadStatusConst::Disqualified,
                'name'           => 'Disqualified',
                'position'       => 4,
                'color'          => 'danger',
                'group_id'       => LeadStatusConst::Qualified,
                'is_final_stage' => true,
            ],
        ];

        DB::table('lead_statuses')->upsert($data, ['id'], ['name', 'color', 'position', 'group_id', 'is_final_stage']);
    }

    protected function budget_ranges(): void
    {
        $data = [
            [
                'id'         => BudgetRangeConst::Under10M,
                'name'       => '< Rp 10M',
                'position'   => 1,
                'min_amount' => 0,
                'max_amount' => 10000000,
            ],
            [
                'id'         => BudgetRangeConst::From10MTo50M,
                'name'       => 'Rp 10M – Rp 50M',
                'position'   => 2,
                'min_amount' => 10000000,
                'max_amount' => 50000000,
            ],
            [
                'id'         => BudgetRangeConst::From50MTo100M,
                'name'       => 'Rp 50M – Rp 100M',
                'position'   => 3,
                'min_amount' => 50000000,
                'max_amount' => 100000000,
            ],
            [
                'id'         => BudgetRangeConst::From100MTo500M,
                'name'       => 'Rp 100M – Rp 500M',
                'position'   => 4,
                'min_amount' => 100000000,
                'max_amount' => 500000000,
            ],
            [
                'id'         => BudgetRangeConst::From500MTo1B,
                'name'       => 'Rp 500M – Rp 1B',
                'position'   => 5,
                'min_amount' => 500000000,
                'max_amount' => 1000000000,
            ],
            [
                'id'         => BudgetRangeConst::From1BTo5B,
                'name'       => 'Rp 1B – Rp 5B',
                'position'   => 6,
                'min_amount' => 1000000000,
                'max_amount' => 5000000000,
            ],
            [
                'id'         => BudgetRangeConst::Above5B,
                'name'       => '> Rp 5B',
                'position'   => 7,
                'min_amount' => 5000000000,
                'max_amount' => null,
            ],
        ];

        DB::table('budget_ranges')->upsert($data, ['id'], ['name', 'position', 'min_amount', 'max_amount']);
    }

    protected function disqualification_reasons(): void
    {
        $data = [
            [
                'id'                  => DisqualificationReasonConst::NoBudget,
                'name'                => 'No Budget',
                'position'            => 1,
                'require_reason_text' => false,
            ],
            [
                'id'                  => DisqualificationReasonConst::WrongSegment,
                'name'                => 'Wrong Segment',
                'position'            => 2,
                'require_reason_text' => false,
            ],
            [
                'id'                  => DisqualificationReasonConst::NoResponse,
                'name'                => 'No Response',
                'position'            => 3,
                'require_reason_text' => false,
            ],
            [
                'id'                  => DisqualificationReasonConst::ChooseCompetitor,
                'name'                => 'Chose Competitor',
                'position'            => 4,
                'require_reason_text' => false,
            ],
            [
                'id'                  => DisqualificationReasonConst::BadTiming,
                'name'                => 'Bad Timing',
                'position'            => 5,
                'require_reason_text' => false,
            ],
            [
                'id'                  => DisqualificationReasonConst::IncompleteInfo,
                'name'                => 'Incomplete Information',
                'position'            => 6,
                'require_reason_text' => false,
            ],
            [
                'id'                  => DisqualificationReasonConst::Other,
                'name'                => 'Other',
                'position'            => 7,
                'require_reason_text' => true,
            ],
        ];

        DB::table('disqualification_reasons')->upsert($data, ['id'], ['name', 'position', 'require_reason_text']);
    }
}
