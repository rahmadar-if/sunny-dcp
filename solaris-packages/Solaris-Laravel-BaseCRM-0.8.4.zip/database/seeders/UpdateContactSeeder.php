<?php

namespace Solaris\BaseCRM\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Solaris\BaseCRM\Const\ContactStatusConst;
use Solaris\BaseCRM\Const\NoteworthyEventTypeConst;

class UpdateContactSeeder extends Seeder
{
    public function run(): void
    {
        $this->contact_statuses();
        $this->noteworthy_event_types();
    }

    protected function contact_statuses(): void
    {
        $data = [
            [
                'id'             => ContactStatusConst::PersonalInformation,
                'name'           => 'Personal Information',
                'color'          => 'primary',
                'is_final_stage' => false,
                'position'       => 1
            ],
            [
                'id'             => ContactStatusConst::Draft,
                'name'           => 'Draft',
                'color'          => 'secondary',
                'is_final_stage' => false,
                'position'       => 2
            ],
            [
                'id'             => ContactStatusConst::Verification,
                'name'           => 'Verification',
                'color'          => 'info',
                'is_final_stage' => false,
                'position'       => 3
            ],
            [
                'id'             => ContactStatusConst::Approve,
                'name'           => 'Approve',
                'color'          => 'success',
                'is_final_stage' => true,
                'position'       => 4
            ]
        ];
        DB::table('contact_statuses')->insertOrIgnore($data);
    }

    protected function noteworthy_event_types(): void
    {
        $data = [
            [
                'id'       => NoteworthyEventTypeConst::Birthday,
                'name'     => 'Birthday',
                'position' => 1
            ],
            [
                'id'       => NoteworthyEventTypeConst::Event,
                'name'     => 'Event',
                'position' => 2
            ],
            [
                'id'       => NoteworthyEventTypeConst::Other,
                'name'     => 'Other',
                'position' => 3
            ]
        ];
        DB::table('noteworthy_event_types')->insertOrIgnore($data);
    }
}