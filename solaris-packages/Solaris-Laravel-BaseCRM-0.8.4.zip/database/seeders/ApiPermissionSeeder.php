<?php

namespace Solaris\BaseCRM\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use Solaris\Core\Models\Permission;
use Solaris\Core\Models\Role;

// One role per entity. "API - Account" and "API - Contact" are owned by MasterData's own
// ApiPermissionSeeder — this only adds the CRM-specific action on top, into the same role
// (firstOrCreate by name, safe regardless of which package seeds first).
class ApiPermissionSeeder extends Seeder
{
    protected const GROUP = 'integration';

    public function run(): void
    {
        $this->seedEntity('API - Account', [
            'api.account.update-status' => 'API — change account status',
        ]);

        $this->seedEntity('API - Contact', [
            'api.contact.update-status' => 'API — change contact status',
        ]);

        $this->seedEntity('API - Lead', [
            'api.lead.view'          => 'API — read leads',
            'api.lead.create'        => 'API — create leads',
            'api.lead.update'        => 'API — update leads',
            'api.lead.delete'        => 'API — delete leads',
            'api.lead.update-status' => 'API — change lead status',
            'api.lead.convert'       => 'API — create an account or contact from a lead',
        ]);
    }

    protected function seedEntity(string $roleName, array $permissions): void
    {
        foreach ($permissions as $name => $description) {
            Permission::firstOrCreate(
                ['name' => $name],
                [
                    'id'          => (string) Str::uuid7(),
                    'group_name'  => self::GROUP,
                    'description' => $description,
                ]
            );
        }

        $role = Role::firstOrCreate(
            ['name' => $roleName],
            [
                'id'         => (string) Str::uuid7(),
                'group_name' => self::GROUP,
            ]
        );

        $role->assignPermission(array_keys($permissions));
    }
}
