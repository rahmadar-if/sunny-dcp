<?php

namespace Solaris\BaseCRM\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Solaris\Core\Models\Menu;

class MenuSeeder extends Seeder
{
    public function run(): void
    {
        $this->dashboard();
        $this->crmModule();
    }

    protected function dashboard(): void
    {
        DB::table('menus')
            ->where('name', 'Master Data')
            ->where('is_category', true)
            ->update([
                'position' => 2
            ]);
        
        $categoryId = "019ac822-5320-715a-80b7-29b907d50a53";

        $data = [
            [
                'id'          => $categoryId,
                'name'        => 'Main',
                'position'    => 1,
                'url'         => null,
                'route_name'  => null,
                'icon'        => null,
                'is_category' => true,
                'parent_id'   => null,
                'category_id' => null,
            ],
            [
                'id'          => "019ac822-5320-7a00-9676-a3b8db96de24",
                'name'        => 'Dashboard',
                'position'    => 1,
                'url'         => null,
                'route_name'  => null,
                'icon'        => "bx bx-home",
                'is_category' => false,
                'parent_id'   => null,
                'category_id' => $categoryId,
            ],
        ];

        DB::table('menus')->insertOrIgnore($data);

        $menuAccess = Menu::whereIn('id',
            array_map(
                fn ($item) => $item['id'],
                array_filter($data, fn ($item) => ! $item['is_category'] && ! empty($item['url']))
            )
        )
            ->get();

        foreach ($menuAccess as $menu) {
            $menu->assignRole('User');
        }
    }

    protected function crmModule(): void
    {
        $crmModuleCategoryId = "019ac81e-bf04-7034-883e-4af75966562d";

        $data = [
            [
                'id'          => $crmModuleCategoryId,
                'name'        => 'CRM Module',
                'position'    => 3,
                'url'         => null,
                'route_name'  => null,
                'icon'        => null,
                'is_category' => true,
                'parent_id'   => null,
                'category_id' => null,
            ],
        ];

        DB::table('menus')->insertOrIgnore($data);

        $menuAccess = Menu::whereIn('id',
            array_map(
                fn ($item) => $item['id'],
                array_filter($data, fn ($item) => ! $item['is_category'] && ! empty($item['url']))
            )
        )
            ->get();

        foreach ($menuAccess as $menu) {
            $menu->assignRole('User');
        }
    }
}
