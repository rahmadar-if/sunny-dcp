<?php

namespace Solaris\BaseCRM;

use Illuminate\Support\Facades\Route;
use Spatie\LaravelPackageTools\Package;
use Spatie\LaravelPackageTools\PackageServiceProvider;

class SolarisBaseCRMServiceProvider extends PackageServiceProvider
{
    public function configurePackage(Package $package): void
    {
        /*
         * This class is a Package Service Provider
         *
         * More info: https://github.com/spatie/laravel-package-tools
         */
        $package
            ->name('base-crm')
            ->hasConfigFile(['solaris'])
            ->hasViews('base-crm')
            ->discoversMigrations()
            ->runsMigrations();
    }

    public function packageBooted()
    {
        Route::middleware('web')
            ->group(__DIR__ . '/../routes/web.php');

        Route::middleware('api')
            ->prefix('api')
            ->group([
                __DIR__.'/../routes/api.php',
                __DIR__.'/../routes/mobile.php',
            ]);
    }
}
