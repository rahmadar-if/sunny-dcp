<?php

namespace Solaris\BaseCRM\Http\Requests;

use Solaris\Core\Http\Requests\BaseFormRequest;

class ContactNoteworthyEventRequest extends BaseFormRequest
{
    public function rules(): array
    {
        return match ($this->method()) {
            'POST' => static::createRules(),
            'PUT'  => static::updateRules(),
        };
    }

    public static function createRules(): array
    {
        return array_merge(static::updateRules(), [
            'contact_id' => 'required|uuid',
        ]);
    }

    public static function updateRules(): array
    {
        return [
            'type_id' => 'required|uuid',
            'date'    => 'required|date_format:Y-m-d',
            'notes'   => 'nullable|string',
        ];
    }
}
