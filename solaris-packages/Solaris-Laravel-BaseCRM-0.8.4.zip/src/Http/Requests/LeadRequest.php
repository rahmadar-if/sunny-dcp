<?php

namespace Solaris\BaseCRM\Http\Requests;

use Solaris\BaseCRM\Const\DisqualificationReasonConst;
use Solaris\BaseCRM\Const\LeadStatusConst;
use Solaris\Core\Http\Requests\BaseFormRequest;

class LeadRequest extends BaseFormRequest
{
    public function rules(): array
    {
        if ($this->routeIs('mobile.crm.lead.update-stage', 'api.v1.lead.update-status')) {
            return static::stageRules();
        }

        $isApi = $this->is('api/v1/*');

        return match ($this->method()) {
            // The API has no two-step create, so it opens every writable field at once.
            'POST'  => $isApi ? static::apiCreateRules() : static::createRules(),
            'PUT'   => $isApi ? static::apiUpdateRules() : static::updateRules(),
            'PATCH' => static::patchRules(),
        };
    }

    /**
     * A status change together with the reason that explains it. This is the only route allowed to
     * set either, so it is the only place the pair has to be enforced.
     */
    public static function stageRules(): array
    {
        return [
            'status_id'                    => 'required|uuid',
            'disqualification_reason_id'   => 'required_if:status_id,' . LeadStatusConst::Disqualified . '|nullable|uuid',
            'disqualification_reason_text' => 'required_if:disqualification_reason_id,' . DisqualificationReasonConst::Other . '|nullable|string',
        ];
    }

    public static function createRules(): array
    {
        return [
            'name'                   => 'required|string|max:255',
            'registration_method_id' => 'required|uuid',
            'date'                   => 'required|date_format:Y-m-d',
            'phone'                  => 'required_without:email|nullable|string|max:50',
            'email'                  => 'required_without:phone|nullable|string|email|max:255',
            'customer_need'          => 'required|string|min:10',
        ];
    }

    public static function updateRules(): array
    {
        return array_merge(static::createRules(), [
            'status_id'              => 'required|uuid',
            'source_id'              => 'nullable|uuid',
            'account_id'             => 'nullable|uuid',
            'contact_id'             => 'nullable|uuid',
            'follow_up_date'         => 'nullable|date_format:Y-m-d',
            'follow_up_remind_at'    => 'nullable|date',
            'segmentation_id'        => 'nullable|uuid',
            'number_of_employee_id'  => 'nullable|uuid',
            'annual_revenue_id'      => 'nullable|uuid',
            'business_size_id'       => 'nullable|uuid',
            'industry_id'            => 'nullable|uuid',
            'budget_range_id'        => 'nullable|uuid',
            'budget'                 => 'nullable|decimal:0,2',
            'disqualification_reason_id'   => 'required_if:status_id,' . LeadStatusConst::Disqualified . '|nullable|uuid',
            'disqualification_reason_text' => 'required_if:disqualification_reason_id,' . DisqualificationReasonConst::Other . '|nullable|string',
            'notes'                  => 'nullable|string',
            'account_name'           => 'nullable|string',
            'contact_name'           => 'nullable|string',
            'contact_job_title'      => 'nullable|string',
            'add_to_calendar'        => 'boolean',
        ]);
    }
}
