<?php

namespace Solaris\BaseCRM\Http\Requests;

use Solaris\Core\Http\Requests\BaseFormRequest;

class LeadCreateContactRequest extends BaseFormRequest
{
	public function rules(): array
	{
		return [
			'name'      => 'required|string|max:255',
			'job_title' => 'nullable|string|max:255',
			'phone'     => 'required_without:email|nullable|string|max:50',
			'email'     => 'required_without:phone|nullable|string|email|max:255',
			'force'     => 'boolean',
		];
	}
}
