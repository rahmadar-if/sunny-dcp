<?php

namespace Solaris\BaseCRM\Http\Requests;

use Solaris\MasterData\Http\Requests\ContactRequest as BaseContactRequest;

class ContactRequest extends BaseContactRequest
{
    public function rules(): array
    {
        if($this->routeIs('mobile.master-data.contact.update-stage', 'api.v1.contact.update-status')) {
            return [
                'status_id' => 'required|uuid',
            ];
        }

        return parent::rules();
    }

    public static function createRules(): array
    {
        return array_merge(parent::createRules(), [
            'status_id'       => 'nullable|uuid',
            'segmentation_id' => 'nullable|uuid',
            'npwp'            => 'nullable|string|max:16',
            'no_ktp'          => 'nullable|string|max:16',
        ]);
    }

    public static function updateRules(): array
    {
        return array_merge(parent::updateRules(), [
            'status_id'       => 'required|uuid',
            'segmentation_id' => 'nullable|uuid',
            'npwp'            => 'nullable|string|max:16',
            'no_ktp'          => 'nullable|string|max:16',
        ]);
    }
}