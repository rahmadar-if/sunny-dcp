<?php

namespace Solaris\BaseCRM\Http\Requests;

use Solaris\Core\Http\Requests\BaseFormRequest;

class AccountBankRequest extends BaseFormRequest
{
    public function rules(): array
    {
        return match ($this->method()) {
            'POST' => static::createRules(),
            'PUT'  => static::updateRules(),
        };
    }

    public static function createRules(): array
    {
        return array_merge(static::updateRules(), [
            'account_id' => 'required|uuid',
        ]);
    }

    public static function updateRules(): array
    {
        return [
            'bank_name'      => 'required|string',
            'account_name'   => 'required|string',
            'account_number' => 'required|string',
            'country_id'     => 'nullable|uuid',
        ];
    }
}
