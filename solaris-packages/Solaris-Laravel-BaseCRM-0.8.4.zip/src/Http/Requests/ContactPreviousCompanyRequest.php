<?php

namespace Solaris\BaseCRM\Http\Requests;

use Solaris\Core\Http\Requests\BaseFormRequest;

class ContactPreviousCompanyRequest extends BaseFormRequest
{
    public function rules(): array
    {
        return match ($this->method()) {
            'POST' => static::createRules(),
            'PUT'  => static::updateRules(),
        };
    }

    public static function createRules(): array
    {
        return array_merge(static::updateRules(), [
            'contact_id' => 'required|uuid',
        ]);
    }

    public static function updateRules(): array
    {
        return [
            'account_id' => 'required|uuid',
            'active'     => 'nullable|boolean',
            'role'       => 'nullable|string',
            'start_date' => 'nullable|date',
            'end_date'   => 'nullable|date',
        ];
    }
}
