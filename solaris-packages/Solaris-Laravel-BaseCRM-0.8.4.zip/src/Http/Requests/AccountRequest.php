<?php

namespace Solaris\BaseCRM\Http\Requests;

use Illuminate\Validation\Validator;
use Solaris\MasterData\Http\Requests\AccountRequest as BaseAccountRequest;

class AccountRequest extends BaseAccountRequest
{
    public function rules(): array
    {
        if($this->routeIs('mobile.master-data.account.update-stage', 'api.v1.account.update-status')) {
            return [
                'status_id' => 'required|uuid',
            ];
        }

        return parent::rules();
    }

    public static function createRules(): array
    {
        return array_merge(parent::createRules(), [
            'status_id'           => 'nullable|uuid',
            'annual_revenue_id'   => 'nullable|uuid',
            'customer_journey_id' => 'nullable|uuid',
            'segmentation_id'     => 'nullable|uuid',
            'business_size_id'    => 'nullable|uuid',
            'recency_date'        => 'nullable|date_format:Y-m-d',
            'monetary'            => 'nullable|decimal:0,2',
            'frequency'           => 'nullable|integer',
            'frequency_type_id'   => 'nullable|uuid',
        ]);
    }

    public static function updateRules(): array
    {
        return array_merge(parent::updateRules(), [
            'status_id'           => 'required|uuid',
            'annual_revenue_id'   => 'nullable|uuid',
            'customer_journey_id' => 'nullable|uuid',
            'segmentation_id'     => 'nullable|uuid',
            'business_size_id'    => 'nullable|uuid',
            'recency_date'        => 'nullable|date_format:Y-m-d',
            'monetary'            => 'nullable|decimal:0,2',
            'frequency'           => 'nullable|integer',
            'frequency_type_id'   => 'nullable|uuid',
        ]);
    }

    /**
     * frequency and frequency_type_id are one value split across two columns — "5 per month".
     * Relaxing them independently would let half of it be changed, so PATCH asks for both
     * whenever either is touched.
     */
    public static function patchRules(): array
    {
        return array_merge(parent::patchRules(), [
            'frequency'         => ['sometimes', 'integer', 'min:1', 'required_with:frequency_type_id'],
            'frequency_type_id' => ['sometimes', 'uuid', 'required_with:frequency'],
        ]);
    }

    public static function validateFrequency(Validator $validator): void
    {
        $data          = $validator->getData();
        $frequency     = $data['frequency'] ?? null;
        $frequencyType = $data['frequency_type_id'] ?? null;

        if (!is_null($frequencyType) && (int) $frequency <= 0) {
            $validator->errors()->add('frequency', 'Frequency is required');
        }

        if (is_null($frequencyType) && $frequency > 0) {
            $validator->errors()->add('frequency_type_id', 'Frequency type is required');
        }
    }

    public function withValidator(Validator $validator): void
    {
        // On PATCH the pair is already enforced by patchRules(), and this check would read the
        // absent half of the pair as null and reject a value that was never touched.
        if ($this->isMethod('PATCH')) {
            return;
        }

        $validator->after(fn (Validator $validator) => static::validateFrequency($validator));
    }
}