<?php

namespace Solaris\BaseCRM\Http\Requests;

use Solaris\Core\Http\Requests\BaseFormRequest;

class LeadCreateAccountRequest extends BaseFormRequest
{
	public function rules(): array
	{
		return [
			'name'                  => 'required|string|max:255',
			'industry_id'           => 'required|uuid',
			'phone'                 => 'required_without:email|nullable|string|max:50',
			'email'                 => 'required_without:phone|nullable|string|email|max:255',
			'segmentation_id'       => 'nullable|uuid',
			'business_size_id'      => 'nullable|uuid',
			'number_of_employee_id' => 'nullable|uuid',
			'annual_revenue_id'     => 'nullable|uuid',
			'force'                 => 'boolean',
		];
	}
}
