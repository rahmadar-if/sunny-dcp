<?php

namespace Solaris\BaseCRM\Http\Requests;

use Solaris\Core\Http\Requests\BaseFormRequest;

class ActivityPromotedProductRequest extends BaseFormRequest
{
    public function rules(): array
    {
        return match ($this->method()) {
            'POST' => static::createRules(),
            'PUT'  => static::updateRules(),
        };
    }

    public static function createRules(): array
    {
        return array_merge(static::updateRules(), [
            'activity_id' => 'required|uuid',
        ]);
    }

    public static function updateRules(): array
    {
        return [
            'product_id' => 'required|uuid',
            'date'       => 'nullable|date_format:Y-m-d',
            'status'     => 'nullable|string',
        ];
    }
}
