<?php

namespace Solaris\BaseCRM\Http\Requests;

use Solaris\MasterData\Http\Requests\ActivityRequest as BaseActivityRequest;

class ActivityRequest extends BaseActivityRequest
{
    public static function createRules(): array
    {
        return array_merge(parent::createRules(), [
            'lead_id' => 'nullable|uuid',
        ]);
    }

    public static function updateRules(): array
    {
        return array_merge(parent::updateRules(), [
            'lead_id'       => 'nullable|uuid',
            'result_id'     => 'nullable|uuid',
            'detail_result' => 'nullable|string',
        ]);
    }
}