<?php

namespace Solaris\BaseCRM\Http\Controllers;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Solaris\BaseCRM\Http\Requests\AccountBankRequest;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\Core\Services\ModelBinding\ModelBindingResult;

#[FormAccess()]
class AccountBankController
{
    /** @var BaseRepository */
    protected $repo;

    public function __construct()
    {
        $this->repo = new (Helper::repository('account_bank'))(new (Helper::model('account_bank')));
    }

    public function store(): JsonResponse
    {
        /** @var AccountBankRequest */
        $request = app(Helper::formRequest('account_bank'));
        $data    = $this->repo->create($request->cleanData());

        return SolarResponse::success($data);
    }

    public function show(string $id): JsonResponse
    {
        return response()->json($this->repo->findComplete($id));
    }

    public function update(string $id): JsonResponse
    {
        /** @var AccountBankRequest */
        $request = app(Helper::formRequest('account_bank'));
        $data    = $this->repo->update($id, $request->cleanData());

        return SolarResponse::success($data);
    }

    public function destroy(string $id): JsonResponse
    {
        return SolarResponse::deleted($this->repo->delete($id));
    }

    public function batchDelete(Request $request, ModelBindingResult $modelParsing): JsonResponse
    {
        return SolarResponse::success($this->repo->requestBatchDelete($request, $modelParsing));
    }
}
