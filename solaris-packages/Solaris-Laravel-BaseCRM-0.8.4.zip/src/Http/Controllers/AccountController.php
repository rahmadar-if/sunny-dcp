<?php

namespace Solaris\BaseCRM\Http\Controllers;

use Solaris\MasterData\Http\Controllers\AccountController as BaseAccountController;

class AccountController extends BaseAccountController
{
    public function extendColumns(): array
    {
        return array_merge(parent::extendColumns(), [
            'monetary',
            'recency_date',
            'frequency',
            'status_id',
            'annual_revenue_id',
            'customer_journey_id',
            'segmentation_id',
            'business_size_id',
            'frequency_type_id',
        ]);
    }
}