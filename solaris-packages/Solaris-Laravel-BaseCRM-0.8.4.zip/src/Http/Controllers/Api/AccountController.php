<?php

namespace Solaris\BaseCRM\Http\Controllers\Api;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Solaris\Core\Docs\Api\ApiField;
use Solaris\Core\Docs\Api\ApiOperation;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarApiResponse;
use Solaris\MasterData\Http\Controllers\Api\AccountController as BaseAccountController;

class AccountController extends BaseAccountController
{
    public function columns(): array
    {
        return array_merge(parent::columns(), [
            'status',
            'annual_revenue',
            'customer_journey',
            'segmentation',
            'business_size',
            'recency_date',
            'monetary',
            'frequency',
            'frequency_type',
        ]);
    }

    public function relations(): array
    {
        return array_merge(parent::relations(), [
            'annual_revenue',
            'customer_journey',
            'segmentation',
            'business_size',
            'frequency_type',
        ]);
    }

    /**
     * Status has its own endpoint, so it must not ride along in an ordinary field update — a
     * state change buried in a bulk edit is the kind of thing nobody notices until it matters.
     */
    public function guarded(): array
    {
        return array_merge(parent::guarded(), ['status_id', 'status']);
    }

    public function fieldDocs(): array
    {
        return array_merge(parent::fieldDocs(), [
            'status'           => ApiField::stage('Current lifecycle stage. Changed through its own endpoint, not through update.')->readOnly(),
            'annual_revenue'   => ApiField::lookup('Annual revenue bracket.'),
            'customer_journey' => ApiField::lookup('Where the account sits in the customer journey.'),
            'segmentation'     => ApiField::lookup('Segmentation label.'),
            'business_size'    => ApiField::lookup('Company size bracket.'),
            'recency_date'     => ApiField::date('Date of the most recent transaction.')->example('2026-07-30'),
            'monetary'         => ApiField::decimal('Total transaction value.')->example(15000000),
            'frequency'        => ApiField::integer('Transaction count per frequency type. Must be sent together with frequency_type_id.')->example(5),
            'frequency_type'   => ApiField::lookup('Period the frequency is counted over.'),
        ]);
    }

    public function endpointDocs(): array
    {
        return array_merge(parent::endpointDocs(), [
            'updateStatus' => ApiOperation::make('Change account status')
                ->description("Status is kept out of the update endpoint so a stage change cannot slip in among ordinary field edits. Every change here is recorded in the account's status history."),
        ]);
    }

    public function updateStatus(Request $request, string $id): JsonResponse
    {
        $formRequest = app(Helper::formRequest($this->key()));

        $this->repo->update($id, $formRequest->cleanData());

        return SolarApiResponse::item(new ($this->resource())(
            $this->repo->findComplete($id, $this->columns())
        ));
    }
}
