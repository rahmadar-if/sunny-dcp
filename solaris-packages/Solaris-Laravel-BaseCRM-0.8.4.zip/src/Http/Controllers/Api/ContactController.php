<?php

namespace Solaris\BaseCRM\Http\Controllers\Api;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Solaris\Core\Docs\Api\ApiField;
use Solaris\Core\Docs\Api\ApiOperation;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarApiResponse;
use Solaris\MasterData\Http\Controllers\Api\ContactController as BaseContactController;

class ContactController extends BaseContactController
{
    public function columns(): array
    {
        return array_merge(parent::columns(), [
            'status',
            'segmentation',
            'npwp',
            'no_ktp',
        ]);
    }

    public function relations(): array
    {
        return array_merge(parent::relations(), ['segmentation']);
    }

    /**
     * Status has its own endpoint, so it must not ride along in an ordinary field update — a
     * state change buried in a bulk edit is the kind of thing nobody notices until it matters.
     */
    public function guarded(): array
    {
        return array_merge(parent::guarded(), ['status_id', 'status']);
    }

    public function fieldDocs(): array
    {
        return array_merge(parent::fieldDocs(), [
            'status'       => ApiField::stage('Current lifecycle stage. Changed through its own endpoint, not through update.')->readOnly(),
            'segmentation' => ApiField::lookup('Segmentation label.'),
            'npwp'         => ApiField::string('Indonesian tax number.')->example('091234567890000'),
            'no_ktp'       => ApiField::string('Indonesian national ID number.')->example('3171234567890001'),
        ]);
    }

    public function endpointDocs(): array
    {
        return array_merge(parent::endpointDocs(), [
            'updateStatus' => ApiOperation::make('Change contact status')
                ->description("Status is kept out of the update endpoint so a stage change cannot slip in among ordinary field edits. Every change here is recorded in the contact's status history."),
        ]);
    }

    public function updateStatus(Request $request, string $id): JsonResponse
    {
        $formRequest = app(Helper::formRequest($this->key()));

        $this->repo->update($id, $formRequest->cleanData());

        return SolarApiResponse::item(new ($this->resource())(
            $this->repo->findComplete($id, $this->columns())
        ));
    }
}
