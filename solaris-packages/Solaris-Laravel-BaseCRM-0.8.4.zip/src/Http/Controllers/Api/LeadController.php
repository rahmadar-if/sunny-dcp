<?php

namespace Solaris\BaseCRM\Http\Controllers\Api;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Solaris\BaseCRM\Http\Requests\LeadCreateAccountRequest;
use Solaris\BaseCRM\Http\Requests\LeadCreateContactRequest;
use Solaris\Core\Docs\Api\ApiEntity;
use Solaris\Core\Docs\Api\ApiField;
use Solaris\Core\Docs\Api\ApiOperation;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarApiResponse;
use Solaris\Core\Http\Controllers\Api\BaseApiController;

/**
 * First entity whose base layer is BaseCRM rather than MasterData — there is no Lead upstream, so
 * the CRUD routes are declared here too.
 */
class LeadController extends BaseApiController
{
    public function key(): string
    {
        return 'lead';
    }

    public function columns(): array
    {
        return [
            'id',
            'name',
            'date',
            'source',
            'registration_method',
            'account',
            'account_name',
            'is_new_account',
            'contact',
            'contact_name',
            'contact_job_title',
            'is_new_contact',
            'phone',
            'email',
            'segmentation',
            'industry',
            'business_size',
            'annual_revenue',
            'number_of_employee',
            'budget_range',
            'budget',
            'follow_up_date',
            'follow_up_remind_at',
            'is_follow_up_reminded',
            'add_to_calendar',
            'customer_need',
            'status',
            'disqualification_reason',
            'disqualification_reason_text',
            'notes',
            'created_at',
            'updated_at',
            'created_by',
            'updated_by',
        ];
    }

    public function relations(): array
    {
        return [
            'source',
            'registration_method',
            'account',
            'contact',
            'segmentation',
            'industry',
            'business_size',
            'annual_revenue',
            'number_of_employee',
            'budget_range',
            'disqualification_reason',
        ];
    }

    /**
     * Three groups, each owned by an endpoint of its own.
     *
     * Status carries stage history. Account and contact carry six denormalised columns that only
     * the link endpoints know how to refresh. The disqualification pair is meaningless apart from
     * the status it explains — leaving it open here would let it be set against any status at all,
     * since its required_if can never fire once status_id is out of reach.
     */
    public function guarded(): array
    {
        return [
            'status_id',
            'status',
            'account_id',
            'account',
            'contact_id',
            'contact',
            'disqualification_reason_id',
            'disqualification_reason_text',
        ];
    }

    public function searchColumns(): array
    {
        return ['name', 'account_name', 'contact_name', 'phone', 'email'];
    }

    public function actionRules(): array
    {
        return [
            'updateStatus'  => Helper::formRequest($this->key())::stageRules(),
            'createAccount' => (new LeadCreateAccountRequest())->rules(),
            'createContact' => (new LeadCreateContactRequest())->rules(),
            'updateAccount' => ['account_id' => 'nullable|uuid'],
            'updateContact' => ['contact_id' => 'nullable|uuid'],
        ];
    }

    public function entityDocs(): ApiEntity
    {
        return ApiEntity::make('Lead')
            ->description('Incoming interest, before it becomes an account, a contact or an opportunity.');
    }

    public function fieldDocs(): array
    {
        return [
            'id'                           => ApiField::uuid('Unique identifier.')->readOnly(),
            'name'                         => ApiField::string('What the lead is called.')->example('Permintaan panel surya - PT Sinar Jaya'),
            'date'                         => ApiField::date('Date the lead came in.')->example('2026-08-17'),
            'source'                       => ApiField::lookup('Where the lead came from.'),
            'registration_method'          => ApiField::lookup('How the lead was registered.'),
            'account'                      => ApiField::lookup('Account this lead is attached to. Changed through its own endpoint.')->readOnly(),
            'account_name'                 => ApiField::string('Company name, copied from the account once one is linked.')->readOnly(),
            'is_new_account'               => ApiField::boolean('True when the account was created out of this lead.')->readOnly(),
            'contact'                      => ApiField::lookup('Person this lead is attached to. Changed through its own endpoint.')->readOnly(),
            'contact_name'                 => ApiField::string('Person name, copied from the contact once one is linked.')->readOnly(),
            'contact_job_title'            => ApiField::string('Job title, copied from the contact.')->readOnly(),
            'is_new_contact'               => ApiField::boolean('True when the contact was created out of this lead.')->readOnly(),
            'phone'                        => ApiField::string('Contact number. Required unless an email is given.')->example('+628123456789'),
            'email'                        => ApiField::email('Contact email. Required unless a phone is given.')->example('budi@sinarjaya.co.id'),
            'segmentation'                 => ApiField::lookup('Segmentation label.'),
            'industry'                     => ApiField::lookup('Industry classification.'),
            'business_size'                => ApiField::lookup('Company size bracket.'),
            'annual_revenue'               => ApiField::lookup('Annual revenue bracket.'),
            'number_of_employee'           => ApiField::lookup('Employee count bracket.'),
            'budget_range'                 => ApiField::lookup('Budget bracket the buyer indicated.'),
            'budget'                       => ApiField::decimal('Budget figure the buyer indicated.')->example(250000000),
            'follow_up_date'               => ApiField::date('When to follow this lead up.')->example('2026-08-24'),
            'follow_up_remind_at'          => ApiField::dateTime('When a reminder should fire.')->example('2026-08-24T02:00:00Z'),
            'is_follow_up_reminded'        => ApiField::boolean('True once the reminder has fired.')->readOnly(),
            'add_to_calendar'              => ApiField::boolean('Set true to have a follow-up to-do created.'),
            'customer_need'                => ApiField::text('What the buyer is asking for. At least 10 characters.'),
            'status'                       => ApiField::stage('Current lifecycle stage. Changed through its own endpoint.')->readOnly(),
            'disqualification_reason'      => ApiField::lookup('Why the lead was disqualified. Set through the status endpoint.')->readOnly(),
            'disqualification_reason_text' => ApiField::text('Free text reason, required when the reason is "other".')->readOnly(),
            'notes'                        => ApiField::text('Rich text notes. HTML is accepted.'),
            'created_at'                   => ApiField::dateTime('When the record was created.')->readOnly(),
            'updated_at'                   => ApiField::dateTime('When the record was last changed.')->readOnly(),
            'created_by'                   => ApiField::user('Who created the record.')->readOnly(),
            'updated_by'                   => ApiField::user('Who last changed the record.')->readOnly(),
        ];
    }

    public function endpointDocs(): array
    {
        return [
            'index'  => ApiOperation::make('List leads'),
            'search' => ApiOperation::make('Search leads')
                ->description('Same as the list endpoint, but accepts the full Filter DSL in the body instead of a query string.'),
            'show'   => ApiOperation::make('Get one lead'),
            'store'  => ApiOperation::make('Create a lead')
                ->description("Either a phone or an email must be given. A new lead starts at the first stage; status is not accepted here.\n\nSend an `Idempotency-Key` header so a retried request cannot create a duplicate."),
            'update' => ApiOperation::make('Update a lead')
                ->description("Partial update — only the fields you send are changed. Fields you omit are left untouched.\n\nStatus, account, contact and the disqualification reason are each handled by their own endpoint and are rejected here."),
            'replace' => ApiOperation::make('Update a lead (full)')
                ->description("Same effect as the partial update, but every required field must be present.\n\nFields you omit are still left untouched; this endpoint does not blank them."),
            'destroy' => ApiOperation::make('Delete a lead'),

            'updateStatus' => ApiOperation::make('Change lead status')
                ->description("Every change here is recorded in the lead's status history. Disqualifying a lead requires a reason, and the reason \"other\" requires the free text alongside it."),
            'createAccount' => ApiOperation::make('Create an account from the lead')
                ->description("Creates a new account, links it to the lead and copies its industry and sizing back onto the lead.\n\nExisting accounts are checked for a near match on name, phone and email first. If any are found the request is refused with **409** and the candidates are listed in `error.fields.duplicates` — link one of those instead, or repeat the request with `force: true` to create anyway."),
            'createContact' => ApiOperation::make('Create a contact from the lead')
                ->description("Creates a new contact under the lead's account, links it and copies the name and job title back onto the lead.\n\nNear matches are checked and refused the same way as for accounts; `force: true` overrides."),
            'updateAccount' => ApiOperation::make('Link the lead to an account')
                ->description("Points the lead at an existing account and refreshes the fields the lead keeps its own copy of — company name, industry, segmentation, business size, employee count and annual revenue.\n\nSend `null` to detach, which clears those copies too."),
            'updateContact' => ApiOperation::make('Link the lead to a contact')
                ->description("Points the lead at an existing contact and refreshes the copied name and job title.\n\nSend `null` to detach."),
        ];
    }

    public function updateStatus(Request $request, string $id): JsonResponse
    {
        $formRequest = app(Helper::formRequest($this->key()));

        $this->repo->update($id, $formRequest->cleanData());

        return $this->current($id);
    }

    public function createAccount(string $id): JsonResponse
    {
        $result = $this->repo->createAccount($id, app(LeadCreateAccountRequest::class)->cleanData());

        return $this->converted($result, 'account');
    }

    public function createContact(string $id): JsonResponse
    {
        $result = $this->repo->createContact($id, app(LeadCreateContactRequest::class)->cleanData());

        return $this->converted($result, 'contact');
    }

    public function updateAccount(Request $request, string $id): JsonResponse
    {
        $this->repo->linkAccount($id, $request->input('account_id'));

        return $this->current($id);
    }

    public function updateContact(Request $request, string $id): JsonResponse
    {
        $this->repo->linkContact($id, $request->input('contact_id'));

        return $this->current($id);
    }

    protected function current(string $id): JsonResponse
    {
        return SolarApiResponse::item(new ($this->resource())(
            $this->repo->findComplete($id, $this->columns())
        ));
    }

    /**
     * The repository answers with either the created record or a list of near matches, so the two
     * shapes are separated here rather than handed to the partner as one ambiguous body.
     */
    protected function converted(array|Model $result, string $what): JsonResponse
    {
        if (is_array($result)) {
            return SolarApiResponse::error(
                SolarApiResponse::CONFLICT,
                "An existing {$what} looks like a match. Link one of the candidates, or repeat with force set to true.",
                409,
                ['duplicates' => $result['duplicates'] ?? []]
            );
        }

        return SolarApiResponse::created(['id' => $result->id, 'name' => $result->name]);
    }
}
