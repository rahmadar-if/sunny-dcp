<?php

namespace Solaris\BaseCRM\Http\Controllers\Api;

use Solaris\Core\Docs\Api\ApiField;
use Solaris\MasterData\Http\Controllers\Api\ActivityController as BaseActivityController;

class ActivityController extends BaseActivityController
{
    public function columns(): array
    {
        return array_merge(parent::columns(), [
            'lead',
            'result',
            'detail_result',
        ]);
    }

    public function relations(): array
    {
        return array_merge(parent::relations(), ['lead', 'result']);
    }

    public function fieldDocs(): array
    {
        return array_merge(parent::fieldDocs(), [
            'lead'          => ApiField::lookup('Lead the activity came out of.'),
            'result'        => ApiField::lookup('Outcome of the activity.'),
            'detail_result' => ApiField::text('Free text description of the outcome.'),
        ]);
    }
}
