<?php

namespace Solaris\BaseCRM\Http\Controllers;

use Solaris\MasterData\Http\Controllers\ActivityController as BaseActivityController;

class ActivityController extends BaseActivityController
{
    public function extendColumns(): array
    {
        return array_merge(parent::extendColumns(), [
            'detail_result',
            'result_id',
            'lead_id'
        ]);
    }
}