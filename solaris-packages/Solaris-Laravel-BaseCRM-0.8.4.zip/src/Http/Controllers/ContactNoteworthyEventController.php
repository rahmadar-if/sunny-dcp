<?php

namespace Solaris\BaseCRM\Http\Controllers;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Solaris\BaseCRM\Http\Requests\ContactNoteworthyEventRequest;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\Core\Services\ModelBinding\ModelBindingResult;

#[FormAccess()]
class ContactNoteworthyEventController
{
    /** @var BaseRepository */
    protected $repo;

    public function __construct()
    {
        $this->repo = new (Helper::repository('contact_noteworthy_event'))(new (Helper::model('contact_noteworthy_event')));
    }

    public function store(): JsonResponse
    {
        /** @var ContactNoteworthyEventRequest */
        $request = app(Helper::formRequest('contact_noteworthy_event'));
        $data    = $this->repo->create($request->cleanData());

        return SolarResponse::success($data);
    }

    public function show(string $id): JsonResponse
    {
        return response()->json($this->repo->findComplete($id));
    }

    public function update(string $id): JsonResponse
    {
        /** @var ContactNoteworthyEventRequest */
        $request = app(Helper::formRequest('contact_noteworthy_event'));
        $data    = $this->repo->update($id, $request->cleanData());

        return SolarResponse::success($data);
    }

    public function destroy(string $id): JsonResponse
    {
        return SolarResponse::deleted($this->repo->delete($id));
    }

    public function batchDelete(Request $request, ModelBindingResult $modelParsing): JsonResponse
    {
        return SolarResponse::success($this->repo->requestBatchDelete($request, $modelParsing));
    }
}
