<?php

namespace Solaris\BaseCRM\Http\Controllers;

use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Solaris\BaseCRM\Http\Requests\LeadCreateAccountRequest;
use Solaris\BaseCRM\Http\Requests\LeadCreateContactRequest;
use Solaris\BaseCRM\Http\Requests\LeadRequest;
use Solaris\BaseCRM\Repositories\LeadRepository;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Core\Services\ModelBinding\ModelBindingResult;

#[FormAccess()]
class LeadController
{
    /** @var LeadRepository */
    protected $repo;

    public function __construct()
    {
        $this->repo = new (Helper::repository('lead'))(new (Helper::model('lead')));
    }

    public function index(): View
    {
        $breadcrumbs = [
            ['label' => 'CRM'],
            ['label' => 'Lead'],
        ];

        return view(Helper::view('lead.list'), [
            'breadcrumbs' => $breadcrumbs,
        ]);
    }

    public function store(): JsonResponse
    {
        /** @var LeadRequest */
        $request = app(Helper::formRequest('lead'));
        $data    = $this->repo->create($request->cleanData());

        return SolarResponse::success($data);
    }

    public function show(Request $request, string $id): RedirectResponse|JsonResponse
    {
        if (! $request->expectsJson()) {
            return redirect(route('crm.lead.edit', ['id' => $id]));
        }

        return response()->json($this->repo->findComplete($id, $this->extendColumns()));
    }

    public function edit(string $id): View
    {
        $data = $this->repo->findComplete($id, $this->extendColumns());
        $breadcrumbs = [
            ['label' => 'CRM'],
            ['label' => 'Lead'],
            ['label' => $data->name],
        ];

        return view(Helper::view('lead.page'), [
            'data' => $data,
            'breadcrumbs' => $breadcrumbs,
        ]);
    }

    public function update(string $id): JsonResponse
    {
        /** @var LeadRequest */
        $request = app(Helper::formRequest('lead'));
        $data    = $this->repo->update($id, $request->cleanData());

        return SolarResponse::success($data);
    }

    public function createAccount(string $id): JsonResponse
    {
        /** @var LeadCreateAccountRequest $request */
        $request = app(LeadCreateAccountRequest::class);

        return SolarResponse::success($this->repo->createAccount($id, $request->cleanData()));
    }

    public function createContact(string $id): JsonResponse
    {
        /** @var LeadCreateContactRequest $request */
        $request = app(LeadCreateContactRequest::class);

        return SolarResponse::success($this->repo->createContact($id, $request->cleanData()));
    }

    public function destroy(string $id): JsonResponse
    {
        return SolarResponse::deleted($this->repo->delete($id));
    }

    public function batchDelete(Request $request, ModelBindingResult $modelParsing): JsonResponse
    {
        return SolarResponse::success($this->repo->requestBatchDelete($request, $modelParsing));
    }

    public function extendColumns(): array
    {
        return [];
    }
}
