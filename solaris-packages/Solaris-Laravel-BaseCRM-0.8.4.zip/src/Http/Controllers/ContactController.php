<?php

namespace Solaris\BaseCRM\Http\Controllers;

use Solaris\MasterData\Http\Controllers\ContactController as BaseContactController;

class ContactController extends BaseContactController
{
    public function extendColumns(): array
    {
        return array_merge(parent::extendColumns(), [
            'npwp',
            'no_ktp',
            'status_id',
            'segmentation_id',
        ]);
    }
}