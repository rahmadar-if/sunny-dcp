<?php

namespace Solaris\BaseCRM\Http\Controllers\Mobile;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Solaris\BaseCRM\Http\Requests\ContactNoteworthyEventRequest;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Core\Repositories\BaseRepository;

class ContactNoteworthyEventController
{
	/** @var BaseRepository */
	protected $repo;

	public function __construct()
	{
		$this->repo = new (Helper::repository('contact_noteworthy_event'))(new (Helper::model('contact_noteworthy_event')));
	}

	public function index(Request $request): JsonResponse
	{
		$data = $this->repo->list(
			columns : $this->listColumn(),
			search  : $request->input('search'),
			filter  : $request->input('filter'),
			sort    : $request->input('sort'),
			page    : $request->input('page'),
			length  : $request->input('length'),
		);
		return SolarResponse::list(Helper::mobileResouces('contact_noteworthy_event'), $data);
	}

	public function show(string $id): JsonResponse
	{
		$data = $this->repo->findComplete($id, $this->detailColumns());
		return new (Helper::mobileResouces('contact_noteworthy_event'))($data);
	}

	public function store(): JsonResponse
	{
		/** @var ContactNoteworthyEventRequest */
		$request = app(Helper::formRequest('contact_noteworthy_event'));
		$data    = $this->repo->create($request->cleanData());

		return SolarResponse::success($data);
	}

	public function update(string $id): JsonResponse
	{
		/** @var ContactNoteworthyEventRequest */
		$request = app(Helper::formRequest('contact_noteworthy_event'));
		$data    = $this->repo->update($id, $request->cleanData());

		return SolarResponse::success($data);
	}

	public function destroy(string $id): JsonResponse
	{
		return SolarResponse::deleted($this->repo->delete($id));
	}

	public function listColumn(): array
	{
		return [
			'id',
			'type',
			'date',
			'notes',
		];
	}

	public function detailColumns(): array
	{
		return [
			'id',
			'type',
			'date',
			'notes',
			'contact',
			'created_at',
			'updated_at',
			'created_by',
			'updated_by',
		];
	}
}
