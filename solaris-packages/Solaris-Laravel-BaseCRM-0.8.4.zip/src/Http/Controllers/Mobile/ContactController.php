<?php

namespace Solaris\BaseCRM\Http\Controllers\Mobile;

use Solaris\MasterData\Http\Controllers\Mobile\ContactController as BaseContactController;

class ContactController extends BaseContactController
{
    public function listColumn(): array
    {
        return array_merge(parent::listColumn(), ['status']);
    }
    
    public function detailColumns(): array
    {
        return array_merge(parent::detailColumns(), [
            "npwp",
            "no_ktp",
            "status",
            "segmentation",
        ]);
    }
}
