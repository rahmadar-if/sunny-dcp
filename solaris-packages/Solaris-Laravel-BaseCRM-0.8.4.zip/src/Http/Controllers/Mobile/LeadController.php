<?php

namespace Solaris\BaseCRM\Http\Controllers\Mobile;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Solaris\BaseCRM\Http\Requests\LeadCreateAccountRequest;
use Solaris\BaseCRM\Http\Requests\LeadCreateContactRequest;
use Solaris\BaseCRM\Http\Requests\LeadRequest;
use Solaris\BaseCRM\Http\Resources\Mobile\LeadResource;
use Solaris\BaseCRM\Repositories\LeadRepository;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;

class LeadController
{
	/** @var LeadRepository */
	protected $repo;

	public function __construct()
	{
		$this->repo = new (Helper::repository('lead'))(new (Helper::model('lead')));
	}

	public function index(Request $request): JsonResponse
	{
		$data = $this->repo->list(
			columns : $this->listColumn(),
			search  : $request->input('search'),
			filter  : $request->input('filter'),
			sort    : $request->input('sort'),
			page    : $request->input('page'),
			length  : $request->input('length'),
		);
		return SolarResponse::list(Helper::mobileResouces('lead'), $data);
	}

	public function show(string $id): LeadResource
	{
		$data = $this->repo->findComplete($id, $this->detailColumns());
		return new (Helper::mobileResouces('lead'))($data);
	}

	public function store(): JsonResponse
	{
		/** @var LeadRequest */
		$request = app(Helper::formRequest('lead'));
		$data    = $this->repo->create($request->cleanData());

		return SolarResponse::success($data);
	}

	public function update(string $id): JsonResponse
	{
		/** @var LeadRequest */
		$request = app(Helper::formRequest('lead'));
		$data    = $this->repo->update($id, $request->cleanData());

		return SolarResponse::success($data);
	}

	public function createAccount(string $id): JsonResponse
    {
        /** @var LeadCreateAccountRequest $request */
        $request = app(LeadCreateAccountRequest::class);

        return SolarResponse::success($this->repo->createAccount($id, $request->cleanData()));
    }

    public function createContact(string $id): JsonResponse
    {
        /** @var LeadCreateContactRequest $request */
        $request = app(LeadCreateContactRequest::class);

        return SolarResponse::success($this->repo->createContact($id, $request->cleanData()));
    }

	public function updateAccount(Request $request, string $id): JsonResponse
	{
		$this->repo->linkAccount($id, $request->input('account_id'));

		return SolarResponse::success();
	}

	public function updateContact(Request $request, string $id): JsonResponse
	{
		$this->repo->linkContact($id, $request->input('contact_id'));

		return SolarResponse::success();
	}

	public function updateFollowUp(Request $request, string $id): JsonResponse
	{
		$this->repo->update($id, [
            'follow_up_date'	  => $request->input('follow_up_date'),
            'follow_up_remind_at' => $request->input('follow_up_remind_at'),
			'add_to_calendar' 	  => $request->input('add_to_calendar')
        ]);

		return SolarResponse::success();
	}

	public function destroy(string $id): JsonResponse
	{
		return SolarResponse::deleted($this->repo->delete($id));
	}

	public function listColumn(): array
	{
		return [
			'id',
			'date',
			'name',
			'account',
			'account_name',
			'contact_name',
			'budget_range',
			'customer_need',
			'status',
			'phone',
			'email',
			'contact',
			'source',
		];
	}

	public function detailColumns(): array
	{
		return [
			'id',
			'name',
			'date',
			'source',
			'registration_method',
			'account[segmentation,industry,business_size,annual_revenue,number_of_employee]',
			'account_name',
			'is_new_account',
			'contact',
			'contact_name',
			'contact_job_title',
			'is_new_contact',
			'phone',
			'email',
			'segmentation',
			'industry',
			'business_size',
			'annual_revenue',
			'number_of_employee',
			'budget_range',
			'follow_up_date',
			'follow_up_remind_at',
			'is_follow_up_reminded',
			'add_to_calendar',
			'customer_need',
			'status',
			'disqualification_reason',
			'disqualification_reason_text',
			'notes',
			'created_at',
			'updated_at',
			'created_by',
			'updated_by',
		];
	}
}
