<?php

namespace Solaris\BaseCRM\Http\Controllers\Mobile;

use Solaris\MasterData\Http\Controllers\Mobile\ActivityController as BaseActivityController;

class ActivityController extends BaseActivityController
{
    public function detailColumns(): array
    {
        return array_merge(parent::detailColumns(), [
            "lead_id",
            "result_id",
            "detail_result",
        ]);
    }
}
