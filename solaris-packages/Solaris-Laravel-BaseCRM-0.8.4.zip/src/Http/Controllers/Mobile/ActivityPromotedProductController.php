<?php

namespace Solaris\BaseCRM\Http\Controllers\Mobile;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Solaris\BaseCRM\Http\Requests\ActivityPromotedProductRequest;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Core\Repositories\BaseRepository;

class ActivityPromotedProductController
{
	/** @var BaseRepository */
	protected $repo;

	public function __construct()
	{
		$this->repo = new (Helper::repository('activity_promoted_product'))(new (Helper::model('activity_promoted_product')));
	}

	public function index(Request $request): JsonResponse
	{
		$data = $this->repo->list(
			columns : $this->listColumn(),
			search  : $request->input('search'),
			filter  : $request->input('filter'),
			sort    : $request->input('sort'),
			page    : $request->input('page'),
			length  : $request->input('length'),
		);
		return SolarResponse::list(Helper::mobileResouces('activity_promoted_product'), $data);
	}

	public function show(string $id): JsonResponse
	{
		$data = $this->repo->findComplete($id, $this->detailColumns());
		return new (Helper::mobileResouces('activity_promoted_product'))($data);
	}

	public function store(): JsonResponse
	{
		/** @var ActivityPromotedProductRequest */
		$request = app(Helper::formRequest('activity_promoted_product'));
		$data    = $this->repo->create($request->cleanData());

		return SolarResponse::success($data);
	}

	public function update(string $id): JsonResponse
	{
		/** @var ActivityPromotedProductRequest */
		$request = app(Helper::formRequest('activity_promoted_product'));
		$data    = $this->repo->update($id, $request->cleanData());

		return SolarResponse::success($data);
	}

	public function destroy(string $id): JsonResponse
	{
		return SolarResponse::deleted($this->repo->delete($id));
	}

	public function listColumn(): array
	{
		return [
			'id',
			'product',
			'date',
			'status',
		];
	}

	public function detailColumns(): array
	{
		return [
			'id',
			'product',
			'date',
			'status',
			'activity',
			'created_at',
			'updated_at',
			'created_by',
			'updated_by',
		];
	}
}
