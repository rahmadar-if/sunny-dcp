<?php

namespace Solaris\BaseCRM\Http\Controllers\Mobile;

use Solaris\MasterData\Http\Controllers\Mobile\AccountController as BaseAccountController;

class AccountController extends BaseAccountController
{
    public function listColumn(): array
    {
        return array_merge(parent::listColumn(), ['status']);
    }

    public function detailColumns(): array
    {
        return array_merge(parent::detailColumns(), [
            "status",
            "annual_revenue",
            "customer_journey",
            "segmentation",
            "recency_date",
            "monetary",
            "frequency",
            "frequency_type",
        ]);
    }
}
