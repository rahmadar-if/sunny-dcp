<?php

namespace Solaris\BaseCRM\Http\Controllers\Mobile;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Solaris\BaseCRM\Http\Requests\AccountBankRequest;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Core\Repositories\BaseRepository;

class AccountBankController
{
	/** @var BaseRepository */
	protected $repo;

	public function __construct()
	{
		$this->repo = new (Helper::repository('account_bank'))(new (Helper::model('account_bank')));
	}

	public function index(Request $request): JsonResponse
	{
		$data = $this->repo->list(
			columns : $this->listColumn(),
			search  : $request->input('search'),
			filter  : $request->input('filter'),
			sort    : $request->input('sort'),
			page    : $request->input('page'),
			length  : $request->input('length'),
		);
		return SolarResponse::list(Helper::mobileResouces('account_bank'), $data);
	}

	public function show(string $id): JsonResponse
	{
		$data = $this->repo->findComplete($id, $this->detailColumns());
		return new (Helper::mobileResouces('account_bank'))($data);
	}

	public function store(): JsonResponse
	{
		/** @var AccountBankRequest */
		$request = app(Helper::formRequest('account_bank'));
		$data    = $this->repo->create($request->cleanData());

		return SolarResponse::success($data);
	}

	public function update(string $id): JsonResponse
	{
		/** @var AccountBankRequest */
		$request = app(Helper::formRequest('account_bank'));
		$data    = $this->repo->update($id, $request->cleanData());

		return SolarResponse::success($data);
	}

	public function destroy(string $id): JsonResponse
	{
		return SolarResponse::deleted($this->repo->delete($id));
	}

	public function listColumn(): array
	{
		return [
			'id',
			'bank_name',
			'account_number',
			'account_name',
			'country',
		];
	}

	public function detailColumns(): array
	{
		return [
			'id',
			'bank_name',
			'account_number',
			'account_name',
			'country',
			'account',
			'created_at',
			'updated_at',
			'created_by',
			'updated_by',
		];
	}
}
