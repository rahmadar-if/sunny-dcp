<?php

namespace Solaris\BaseCRM\Http\Resources\Api;

use Illuminate\Http\Request;
use Solaris\Core\Helpers\LookupResource;
use Solaris\MasterData\Http\Resources\Api\AccountResource as BaseAccountResource;

class AccountResource extends BaseAccountResource
{
    protected function fields(Request $request): array
    {
        return array_merge(parent::fields($request), [
            'status'           => LookupResource::lookupStage($this->status),
            'annual_revenue'   => LookupResource::from($this->annual_revenue),
            'customer_journey' => LookupResource::from($this->customer_journey),
            'segmentation'     => LookupResource::from($this->segmentation),
            'business_size'    => LookupResource::from($this->business_size),
            'recency_date'     => $this->recency_date,
            'monetary'         => is_null($this->monetary) ? null : (float) $this->monetary,
            'frequency'        => $this->frequency,
            'frequency_type'   => LookupResource::from($this->frequency_type),
        ]);
    }
}
