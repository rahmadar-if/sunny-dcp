<?php

namespace Solaris\BaseCRM\Http\Resources\Api;

use Illuminate\Http\Request;
use Solaris\Core\Helpers\LookupResource;
use Solaris\MasterData\Http\Resources\Api\ContactResource as BaseContactResource;

class ContactResource extends BaseContactResource
{
    protected function fields(Request $request): array
    {
        return array_merge(parent::fields($request), [
            'status'       => LookupResource::lookupStage($this->status),
            'segmentation' => LookupResource::from($this->segmentation),
            'npwp'         => $this->npwp,
            'no_ktp'       => $this->no_ktp,
        ]);
    }
}
