<?php

namespace Solaris\BaseCRM\Http\Resources\Api;

use Illuminate\Http\Request;
use Solaris\Core\Helpers\LookupResource;
use Solaris\MasterData\Http\Resources\Api\ActivityResource as BaseActivityResource;

class ActivityResource extends BaseActivityResource
{
    protected function fields(Request $request): array
    {
        return array_merge(parent::fields($request), [
            'lead'          => LookupResource::from($this->lead),
            'result'        => LookupResource::from($this->result),
            'detail_result' => $this->detail_result,
        ]);
    }
}
