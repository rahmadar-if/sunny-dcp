<?php

namespace Solaris\BaseCRM\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Helpers\LookupResource;
use Solaris\MasterData\Http\Resources\Mobile\ActivityResource as BaseActivityResource;

class ActivityResource extends BaseActivityResource
{
    protected function detail(Request $request): array
    {
        return array_merge(parent::detail($request), [
            "lead"          => LookupResource::from($this->lead),
            "result"        => LookupResource::from($this->result),
            "detail_result" => $this->detail_result
        ]);
    }
}
