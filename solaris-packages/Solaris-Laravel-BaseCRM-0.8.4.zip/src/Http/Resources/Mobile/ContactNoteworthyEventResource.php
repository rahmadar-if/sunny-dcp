<?php

namespace Solaris\BaseCRM\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Helpers\LookupResource;
use Solaris\Core\Http\Resources\BaseResource;

class ContactNoteworthyEventResource extends BaseResource
{
	protected function list(Request $request): array
	{
		return [
			'id'    => $this->id,
			'type'  => LookupResource::from($this->type),
			'date'  => $this->date,
			'notes' => $this->notes,
		];
	}

	protected function detail(Request $request): array
	{
		return [
			'id'         => $this->id,
			'type'       => LookupResource::from($this->type),
			'date'       => $this->date,
			'notes'      => $this->notes,
			'created_at' => $this->created_at,
			'updated_at' => $this->updated_at,
			'created_by' => LookupResource::user($this->created_by),
			'updated_by' => LookupResource::user($this->updated_by),
		];
	}
}
