<?php

namespace Solaris\BaseCRM\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Helpers\LookupResource;
use Solaris\Core\Http\Resources\BaseResource;

class LeadResource extends BaseResource
{
	protected function list(Request $request): array
	{
		return [
			'id'           => $this->id,
			'date'         => $this->date,
			'name'         => $this->name,
			'account'      => LookupResource::from($this->account),
			'account_name' => $this->account_name,
			'contact_name' => $this->contact_name,
			'budget_range' => LookupResource::from($this->budget_range),
			'customer_need'=> $this->customer_need,
			'status'       => LookupResource::lookupStage($this->status),
			'phone'        => $this->phone,
			'email'        => $this->email,
			'contact'      => LookupResource::from($this->contact),
			'source'       => LookupResource::from($this->source),
		];
	}

	protected function detail(Request $request): array
	{
		return [
			'id'                           => $this->id,
			'name'                         => $this->name,
			'date'                         => $this->date,
			'source'                       => LookupResource::from($this->source),
			'registration_method'          => LookupResource::from($this->registration_method),
			'account'                      => LookupResource::from($this->account, ['segmentation', 'industry', 'business_size', 'annual_revenue', 'number_of_employee']),
			'account_name'                 => $this->account_name,
			'is_new_account'               => $this->is_new_account,
			'contact'                      => LookupResource::from($this->contact, 'job_title'),
			'contact_name'                 => $this->contact_name,
			'contact_job_title'            => $this->contact_job_title,
			'is_new_contact'               => $this->is_new_contact,
			'phone'                        => $this->phone,
			'email'                        => $this->email,
			'segmentation'                 => LookupResource::from($this->segmentation),
			'industry'                     => LookupResource::from($this->industry),
			'business_size'                => LookupResource::from($this->business_size),
			'annual_revenue'               => LookupResource::from($this->annual_revenue),
			'number_of_employee'           => $this->number_of_employee,
			'budget_range'                 => LookupResource::from($this->budget_range),
			'follow_up_date'               => $this->follow_up_date,
			'follow_up_remind_at'          => $this->follow_up_remind_at,
			'is_follow_up_reminded'        => $this->is_follow_up_reminded,
			'add_to_calendar'              => $this->add_to_calendar,
			'customer_need'                => $this->customer_need,
			'status'                       => LookupResource::lookupStage($this->status),
			'disqualification_reason'      => LookupResource::from($this->disqualification_reason),
			'disqualification_reason_text' => $this->disqualification_reason_text,
			'notes'                        => $this->notes,
			'created_at'                   => $this->created_at,
			'updated_at'                   => $this->updated_at,
			'created_by'                   => LookupResource::user($this->created_by),
			'updated_by'                   => LookupResource::user($this->updated_by),
		];
	}
}
