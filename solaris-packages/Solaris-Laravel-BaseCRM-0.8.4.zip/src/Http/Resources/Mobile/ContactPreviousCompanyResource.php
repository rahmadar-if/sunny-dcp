<?php

namespace Solaris\BaseCRM\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Helpers\LookupResource;
use Solaris\Core\Http\Resources\BaseResource;

class ContactPreviousCompanyResource extends BaseResource
{
	protected function list(Request $request): array
	{
		return [
			'id'         => $this->id,
			'account'    => LookupResource::from($this->account),
			'role'       => $this->role,
			'start_date' => $this->start_date,
			'end_date'   => $this->end_date,
			'active'     => $this->active,
		];
	}

	protected function detail(Request $request): array
	{
		return [
			'id'         => $this->id,
			'account'    => LookupResource::from($this->account),
			'role'       => $this->role,
			'start_date' => $this->start_date,
			'end_date'   => $this->end_date,
			'active'     => $this->active,
			'created_at' => $this->created_at,
			'updated_at' => $this->updated_at,
			'created_by' => LookupResource::user($this->created_by),
			'updated_by' => LookupResource::user($this->updated_by),
		];
	}
}
