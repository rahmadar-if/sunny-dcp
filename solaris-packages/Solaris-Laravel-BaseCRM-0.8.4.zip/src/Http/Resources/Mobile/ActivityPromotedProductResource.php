<?php

namespace Solaris\BaseCRM\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Helpers\LookupResource;
use Solaris\Core\Http\Resources\BaseResource;

class ActivityPromotedProductResource extends BaseResource
{
	protected function list(Request $request): array
	{
		return [
			'id'      => $this->id,
			'product' => LookupResource::from($this->product),
			'date'    => $this->date,
			'status'  => $this->status,
		];
	}

	protected function detail(Request $request): array
	{
		return [
			'id'         => $this->id,
			'product'    => LookupResource::from($this->product),
			'date'       => $this->date,
			'status'     => $this->status,
			'created_at' => $this->created_at,
			'updated_at' => $this->updated_at,
			'created_by' => LookupResource::user($this->created_by),
			'updated_by' => LookupResource::user($this->updated_by),
		];
	}
}
