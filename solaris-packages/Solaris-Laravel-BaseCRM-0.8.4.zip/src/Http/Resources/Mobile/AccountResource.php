<?php

namespace Solaris\BaseCRM\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Helpers\LookupResource;
use Solaris\MasterData\Http\Resources\Mobile\AccountResource as BaseAccountResource;

class AccountResource extends BaseAccountResource
{
    protected function list(Request $request): array
    {
        return array_merge(parent::list($request), [
            "status" => LookupResource::lookupStage($this->status),
        ]);
    }

    protected function detail(Request $request): array
    {
        return array_merge(parent::detail($request), [
            "status"           => LookupResource::lookupStage($this->status),
            "annual_revenue"   => LookupResource::from($this->annual_revenue),
            "customer_journey" => LookupResource::from($this->customer_journey),
            "segmentation"     => LookupResource::from($this->segmentation),
            "recency_date"     => $this->recency_date,
            "monetary"         => floatval($this->monetary),
            "frequency"        => $this->frequency,
            "frequency_type"   => LookupResource::from($this->frequency_type),
        ]);
    }
}
