<?php

namespace Solaris\BaseCRM\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Helpers\LookupResource;
use Solaris\MasterData\Http\Resources\Mobile\ContactResource as BaseContactResource;

class ContactResource extends BaseContactResource
{
    protected function list(Request $request): array
    {
        return array_merge(parent::list($request), [
            "status" => LookupResource::lookupStage($this->status),
        ]);
    }

    protected function detail(Request $request): array
    {
        return array_merge(parent::detail($request), [
            "status"       => LookupResource::lookupStage($this->status),
            "segmentation" => LookupResource::from($this->segmentation),
            "npwp"         => $this->npwp,
            "no_ktp"       => $this->no_ktp, 
        ]);
    }
}
