<?php

namespace Solaris\BaseCRM\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Helpers\LookupResource;
use Solaris\Core\Http\Resources\BaseResource;

class ContactStatusHistoryResource extends BaseResource
{
	protected function list(Request $request): array
	{
		return [
			'id'     => $this->id,
			'status' => LookupResource::lookupStage($this->status),
			'start'  => $this->start,
			'end'    => $this->end,
		];
	}

	protected function detail(Request $request): array
	{
		return [
			'id'         => $this->id,
			'status'     => LookupResource::lookupStage($this->status),
			'start'      => $this->start,
			'end'        => $this->end,
			'created_at' => $this->created_at,
			'updated_at' => $this->updated_at,
			'created_by' => LookupResource::user($this->created_by),
			'updated_by' => LookupResource::user($this->updated_by),
		];
	}
}
