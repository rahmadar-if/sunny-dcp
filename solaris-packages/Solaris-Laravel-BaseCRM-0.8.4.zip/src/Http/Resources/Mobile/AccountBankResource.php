<?php

namespace Solaris\BaseCRM\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Helpers\LookupResource;
use Solaris\Core\Http\Resources\BaseResource;

class AccountBankResource extends BaseResource
{
	protected function list(Request $request): array
	{
		return [
			'id'             => $this->id,
			'bank_name'      => $this->bank_name,
			'account_number' => $this->account_number,
			'account_name'   => $this->account_name,
			'country'        => LookupResource::from($this->country),
		];
	}

	protected function detail(Request $request): array
	{
		return [
			'id'             => $this->id,
			'bank_name'      => $this->bank_name,
			'account_number' => $this->account_number,
			'account_name'   => $this->account_name,
			'country'        => LookupResource::from($this->country),
			'created_at'     => $this->created_at,
			'updated_at'     => $this->updated_at,
			'created_by'     => LookupResource::user($this->created_by),
			'updated_by'     => LookupResource::user($this->updated_by),
		];
	}
}
