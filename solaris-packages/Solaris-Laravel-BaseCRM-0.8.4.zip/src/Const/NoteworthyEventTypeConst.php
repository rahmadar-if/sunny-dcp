<?php

namespace Solaris\BaseCRM\Const;

class NoteworthyEventTypeConst
{
    public const Birthday = "2f945ef9-cbb9-4067-8b89-4e315515fa5c";
    public const Event    = "7dfea9c3-8351-4a8f-906e-bd5631f89360";
    public const Other    = "6ac33490-6fea-4df8-8cb5-bc8fc282f19b";
}