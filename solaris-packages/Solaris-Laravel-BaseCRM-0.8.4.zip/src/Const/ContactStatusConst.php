<?php

namespace Solaris\BaseCRM\Const;

class ContactStatusConst
{
    public const PersonalInformation = "d970ab41-c414-4820-c3ab-a2d9f842b277";
    public const Draft               = "0b769386-6d08-b6a0-00b8-9fe138d04b3e";
    public const Verification        = "dcb01b98-7acc-3912-303d-8117a9cc00bb";
    public const Approve             = "ca8723d8-ba8a-49b0-3d34-cb6c9dcb6153";
}