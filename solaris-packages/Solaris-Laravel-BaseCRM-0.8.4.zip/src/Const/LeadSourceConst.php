<?php

namespace Solaris\BaseCRM\Const;

class LeadSourceConst
{
    public const Email       = "a144977a-082b-4306-b15c-b8dc6eeda3eb";
    public const Call        = "21c0491f-ba93-4f9e-a1a1-fe1d58ae4705";
    public const SocialMedia = "07903aa9-18a3-4852-91e5-fbf6ffb2186c";
    public const Referral    = "0483afc3-8ecb-42eb-9ef1-9a9fef93037b";
    public const Website     = "019ce4f3-e976-7c3b-bc27-65d5197b6cc8";
    public const Event       = "019e5e15-96ae-70e7-85ee-aa08cdd58b8b";
}