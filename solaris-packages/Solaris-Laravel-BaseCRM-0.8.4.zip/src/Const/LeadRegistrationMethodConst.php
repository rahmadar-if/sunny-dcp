<?php

namespace Solaris\BaseCRM\Const;

class LeadRegistrationMethodConst
{
    public const ManualEntry = "f1bf6d88-1cbe-4d7f-b331-767e42bd46f5";
    public const WebForm     = "479d55f2-392c-4ae4-af3c-a27f1a2f8039";
    public const API         = "0ba4fdc1-a97d-401d-b014-c1b922cd8acb";
    public const ChatBot     = "39a1b69a-8b6c-44a8-bbc6-d57d55d0a84e";
    public const ImportExcel = "27b8c840-9ec7-4887-893a-c9f02485acf1";
}