<?php

namespace Solaris\BaseCRM\Const;

class DisqualificationReasonConst
{
    public const NoBudget         = "e1b2f62a-9da3-40d7-a193-bcac7d854a65";
    public const WrongSegment     = "0c4509a1-4a2c-417b-972f-9fe3037c1491";
    public const NoResponse       = "5c0b6f40-d0ac-4d69-bd86-9b24cd25ad34";
    public const ChooseCompetitor = "9d8e284b-9155-429f-b1ea-ee1cbaed581d";
    public const BadTiming        = "436756be-fcbe-445c-916c-8b194520b005";
    public const IncompleteInfo   = "895cbb87-a475-4f7c-b848-3454e0849897";
    public const Other            = "93f0b1bc-a6c1-4dbd-a224-1165e490e9f4";
}
