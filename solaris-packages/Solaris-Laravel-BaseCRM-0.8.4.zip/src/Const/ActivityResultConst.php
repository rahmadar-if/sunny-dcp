<?php

namespace Solaris\BaseCRM\Const;

class ActivityResultConst
{
    public const ReSchedule     = "17bd2067-2ab4-42fd-8708-bccda49918d4";
    public const Completed      = "fcb7c1bd-7be6-4920-b29d-6e1085355457";
    public const NeedOurProduct = "8ec7705e-f123-4b6d-b3d9-19b31815fb57";
}