<?php

namespace Solaris\BaseCRM\Const;

class AccountStatusConst
{
    public const PersonalInformation = "e518a061-fc3d-4638-8c75-38cd73519df3";
    public const Draft               = "0cfdd7ba-12a3-4d27-99ad-80b50be5c3c4";
    public const Verification        = "89e52780-72aa-42de-aca5-d526049b452e";
    public const Approve             = "ef9ee585-a1ff-42f6-85a0-8e4a516ecd63";
}