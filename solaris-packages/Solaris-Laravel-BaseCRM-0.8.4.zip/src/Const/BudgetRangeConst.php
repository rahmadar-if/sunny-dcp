<?php

namespace Solaris\BaseCRM\Const;

class BudgetRangeConst
{
    // < Rp 10M
    public const Under10M      = "13e66d28-128e-4fa2-8921-3b2e05f66dc5";

    // Rp 10M – Rp 50M
    public const From10MTo50M  = "53dd6581-156b-4df1-8cb4-1b2fa7b5d92c";

    // Rp 50M – Rp 100M
    public const From50MTo100M = "e2de31b2-8a31-425a-a7d6-6575550691b1";

    // Rp 100M – Rp 500M
    public const From100MTo500M = "b6bd8808-57d5-41b2-baf6-38d91076f959";

    // Rp 500M – Rp 1B
    public const From500MTo1B  = "baac8450-ca09-40ce-99fd-1c72f730fced";

    // Rp 1B – Rp 5B
    public const From1BTo5B    = "ba266711-6bd6-40c4-b90a-082e669a3f41";

    // > Rp 5B
    public const Above5B       = "bbaf4c1a-cae1-4e1c-bf5c-a516d7a8d674";
}
