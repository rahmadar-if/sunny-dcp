<?php

namespace Solaris\BaseCRM\Const;

class LeadStatusConst
{
    // Lead just created, no action taken yet
    public const New          = "83ade5fc-baad-4570-ad4f-eb7b514de0a1";

    // Actively being worked — contacted, warmed up, or in follow-up
    public const Nurturing    = "064e0f85-688a-42e0-bb77-d4140a498cc7";

    // Vetted and ready to be converted to an Opportunity
    public const Qualified    = "3596bde8-5bbf-4fe1-b637-2f33ada89f16";

    // Not viable — disqualification reason required
    public const Disqualified = "ab3111f1-fd59-4d59-a492-1eefcf88df1d";
}
