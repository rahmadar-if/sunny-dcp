<?php

namespace Solaris\BaseCRM\Ai\Tools\ActivityPromotedProduct;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\BaseCRM\Http\Requests\ActivityPromotedProductRequest;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseCreateAiTool;
use Solaris\Core\Helpers\Helper;

class CreateActivityPromotedProductTool extends BaseCreateAiTool
{
	public static function slug(): string
	{
		return 'create_activity_promoted_product';
	}

	protected function resourceLabel(): string
	{
		return 'activity promoted product';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'activity_id' => $schema->string()
				->description('The activity id to add this promoted product to. Obtain it with the activity search tool available to you first.')
				->required(),
			'product_id' => $schema->string()
				->description('The product id being promoted. Obtain it with the product search tool available to you first.')
				->required(),
			'date' => $schema->string()
				->description('Date the product was promoted, in Y-m-d format.'),
			'status' => $schema->string()
				->description('Free-text outcome or status of the promotion.'),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::reference(column: 'activity_id', label: 'activity', modelKey: 'activity'),
			AiColumn::reference(column: 'product_id', label: 'product', modelKey: 'product'),
		];
	}

	protected function rules(): array
	{
		return ActivityPromotedProductRequest::createRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'NATURAL LANGUAGE: If the user asks to add a promoted product to an activity, '
			. 'first locate both the activity and product with the activity search tool available to you and the product search tool if ids are not already known, '
			. 'then confirm the details before calling this tool.';
	}

	protected function create(array $validated, array $raw): array
	{
		$repo   = new (Helper::repository('activity_promoted_product'))(new (Helper::model('activity_promoted_product')));
		$record = $repo->create($validated,
			before: fn ($data)   => $this->beforeCreate($data, $raw),
			after:  fn ($record) => $this->afterCreate($record, $raw),
		);

		return AiResponse::success(
			['id' => $record->id, 'product' => $record->product?->name, 'date' => $record->date?->format('d M Y')],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
