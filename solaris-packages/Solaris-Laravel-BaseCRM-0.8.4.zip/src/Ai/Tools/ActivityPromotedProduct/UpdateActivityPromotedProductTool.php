<?php

namespace Solaris\BaseCRM\Ai\Tools\ActivityPromotedProduct;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\BaseCRM\Http\Requests\ActivityPromotedProductRequest;
use Solaris\BaseCRM\Models\ActivityPromotedProduct;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseUpdateAiTool;
use Solaris\Core\Helpers\Helper;

class UpdateActivityPromotedProductTool extends BaseUpdateAiTool
{
	public static function slug(): string
	{
		return 'update_activity_promoted_product';
	}

	protected function resourceLabel(): string
	{
		return 'activity promoted product';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'id' => $schema->string()
				->description('The promoted product record id. Required.')
				->required(),
			'product_id' => $schema->string()
				->description('New product id. Obtain it with the product search tool available to you first.'),
			'date' => $schema->string()
				->description('New date in Y-m-d format.'),
			'status' => $schema->string()
				->description('New outcome or status.'),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::reference(column: 'product_id', label: 'product', modelKey: 'product'),
		];
	}

	protected function rules(): array
	{
		return ActivityPromotedProductRequest::updateRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'NATURAL LANGUAGE: If the user asks to update a promoted product record, first locate it via '
			. 'the activity promoted product search tool if the id is not already known, '
			. 'then confirm the changes before calling this tool.';
	}

	protected function findRecordById(string $id): ?ActivityPromotedProduct
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('activity_promoted_product'))(new (Helper::model('activity_promoted_product')));

		return $repo->find($id);
	}

	protected function currentData(mixed $record): array
	{
		return [
			'product_id' => $record->product_id,
			'date'       => $record->date?->format('Y-m-d'),
			'status'     => $record->status,
		];
	}

	protected function update(mixed $record, array $validated, array $changes): array
	{
		$repo = new (Helper::repository('activity_promoted_product'))(new (Helper::model('activity_promoted_product')));
		$repo->update($record->id, $validated,
			before: fn ($record, $data) => $this->beforeUpdate($record, $data, $changes),
			after:  fn ($record)        => $this->afterUpdate($record, $changes),
		);

		return AiResponse::success(
			['id' => $record->id, 'updated' => array_keys($changes)],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
