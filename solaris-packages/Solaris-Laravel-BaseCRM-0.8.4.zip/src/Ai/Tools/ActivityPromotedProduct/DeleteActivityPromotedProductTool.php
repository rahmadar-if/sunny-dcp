<?php

namespace Solaris\BaseCRM\Ai\Tools\ActivityPromotedProduct;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseDeleteAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\BaseCRM\Models\ActivityPromotedProduct;

class DeleteActivityPromotedProductTool extends BaseDeleteAiTool
{
	public static function slug(): string
	{
		return 'delete_activity_promoted_product';
	}

	protected function resourceLabel(): string
	{
		return 'activity promoted product';
	}

	protected function findRecordById(string $id): ?ActivityPromotedProduct
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('activity_promoted_product'))(new (Helper::model('activity_promoted_product')));

		return $repo->find($id);
	}

	protected function delete(Model $record): array
	{
		$repo = new (Helper::repository('activity_promoted_product'))(new (Helper::model('activity_promoted_product')));
		$repo->delete($record->id);

		return AiResponse::success(
			['deleted' => ($record->product?->name ?? 'product') . ' — ' . ($record->date?->format('d M Y') ?? 'no date')],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
