<?php

namespace Solaris\BaseCRM\Ai\Tools\ActivityPromotedProduct;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

class SearchActivityPromotedProductTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_activity_promoted_product';
	}

	protected function resourceLabel(): string
	{
		return 'activity promoted products — products pitched or promoted during an activity';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('activity_promoted_product'))();
	}

	protected function fields(): array
	{
		return [
			'activity_id' => AiSearchColumn::reference(
				column: 'activity_id',
				description: 'The activity id this promoted product belongs to. Obtain it with the activity search tool available to you first.',
				modelKey: 'activity',
			),
			'product_id' => AiSearchColumn::reference(
				column: 'product_id',
				description: 'The product id being promoted. Obtain it with the product search tool available to you first.',
				modelKey: 'product',
			),
			'date' => AiSearchColumn::date('date', 'Date the product was promoted'),
			'status' => AiSearchColumn::string(
				column: 'status',
				description: 'Free-text outcome/status of the promotion',
				searchable: true,
			),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'          => $record->id,
			'_activity_id' => $record->activity_id,
			'product'      => $record->product?->name,
			'date'         => $record->date ? Carbon::parse($record->date)->format('d M Y') : null,
			'status'       => $record->status,
		];
	}
}
