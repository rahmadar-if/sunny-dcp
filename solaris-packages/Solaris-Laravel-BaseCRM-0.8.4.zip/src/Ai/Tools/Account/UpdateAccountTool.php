<?php

namespace Solaris\BaseCRM\Ai\Tools\Account;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Support\Arr;
use Laravel\Ai\Tools\Request;
use Solaris\BaseCRM\Ai\Tools\AccountBank\CreateAccountBankTool;
use Solaris\BaseCRM\Http\Requests\AccountBankRequest;
use Solaris\BaseCRM\Http\Requests\AccountRequest;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Ai\Tools\Account\UpdateAccountTool as BaseUpdateAccountTool;

class UpdateAccountTool extends BaseUpdateAccountTool
{
	public static function fields(JsonSchema $schema): array
	{
		$bankFields = Arr::except(CreateAccountBankTool::fields($schema), ['account_id']);

		$detailMeta = [
			'id'     => $schema->string()->description('Existing bank record id. Omit to add a new one.'),
			'delete' => $schema->boolean()->description('Set true (with id) to remove this bank instead of updating it.'),
		];

		return array_merge(parent::fields($schema), [
			'status_id'           => $schema->string()->description('New CRM lifecycle status. Resolve via lookup_options with type: "account_status".'),
			'annual_revenue_id'   => $schema->string()->description('New annual revenue range. Resolve via lookup_options with type: "annual_revenue".'),
			'customer_journey_id' => $schema->string()->description('New customer journey stage. Resolve via lookup_options with type: "customer_journey".'),
			'segmentation_id'     => $schema->string()->description('New account segmentation. Resolve via lookup_options with type: "segmentation".'),
			'business_size_id'    => $schema->string()->description('New business size. Resolve via lookup_options with type: "business_size".'),
			'frequency_type_id'   => $schema->string()->description('New frequency unit. Resolve via lookup_options with type: "frequency_type".'),
			'recency_date'        => $schema->string()->description('New most recent interaction date in Y-m-d format.'),
			'monetary'            => $schema->number()->description('New total monetary value.'),
			'frequency'           => $schema->integer()->description('New count of transactions. Required when frequency_type_id is set.'),
			'detail_account_banks' => $schema->array()
				->items($schema->object(array_merge($detailMeta, $bankFields)))
				->description(
					'Manage bank accounts — omit id to add a new one, pass id with fields to update an existing one, '
						. 'pass id with delete:true to remove one. Supports multiple. Optional.'
				),
		]);
	}

	protected function lookupChecks(): array
	{
		return array_merge(parent::lookupChecks(), [
			AiColumn::lookup(column: 'status_id', label: 'account status', modelKey: 'account_status'),
			AiColumn::lookup(column: 'annual_revenue_id', label: 'annual revenue', modelKey: 'annual_revenue'),
			AiColumn::lookup(column: 'customer_journey_id', label: 'customer journey', modelKey: 'customer_journey'),
			AiColumn::lookup(column: 'segmentation_id', label: 'segmentation', modelKey: 'segmentation'),
			AiColumn::lookup(column: 'business_size_id', label: 'business size', modelKey: 'business_size'),
			AiColumn::lookup(column: 'frequency_type_id', label: 'frequency type', modelKey: 'frequency_type'),
		]);
	}

	protected function rules(): array
	{
		return AccountRequest::updateRules();
	}

	protected function afterValidation(Validator $validator): void
	{
		parent::afterValidation($validator);

		$validator->after(fn (Validator $v) => AccountRequest::validateFrequency($v));
	}

	protected function currentData(mixed $record): array
	{
		return array_merge(parent::currentData($record), [
			'status_id'           => $record->status_id,
			'annual_revenue_id'   => $record->annual_revenue_id,
			'customer_journey_id' => $record->customer_journey_id,
			'segmentation_id'     => $record->segmentation_id,
			'business_size_id'    => $record->business_size_id,
			'recency_date'        => $record->recency_date?->format('Y-m-d'),
			'monetary'            => $record->monetary,
			'frequency'           => $record->frequency,
			'frequency_type_id'   => $record->frequency_type_id,
		]);
	}

	public function validateConfirmation(Request $request): array
	{
		$result = parent::validateConfirmation($request);

		if (isset($result['error'])) {
			return $result;
		}

		$accountId = trim((string) ($request['id'] ?? ''));

		[$banks, $errors] = $this->resolveDetailOperations(
			(array) ($request['detail_account_banks'] ?? []),
			Helper::model('account_bank'),
			AccountBankRequest::createRules(),
			AccountBankRequest::updateRules(),
			'account_id',
			$accountId,
		);
		if (!empty($errors)) {
			return AiResponse::error(AiErrorCode::UserError,'One or more account banks failed validation.', ['messages' => $errors]);
		}

		$result['payload']['changes']['detail_account_banks'] = $banks;

		if (!empty($banks['create']) || !empty($banks['update']) || !empty($banks['delete'])) {
			$result['summary']['detail_account_banks'] = [
				'add'    => count($banks['create']),
				'update' => count($banks['update']),
				'delete' => count($banks['delete']),
			];
		}

		return $result;
	}

	protected function excludedChangeKeys(): array
	{
		return [...parent::excludedChangeKeys(), 'detail_account_banks'];
	}

	protected function afterUpdate(mixed $record, array $changes): void
	{
		parent::afterUpdate($record, $changes);

		$bankOps = $changes['detail_account_banks'] ?? ['create' => [], 'update' => [], 'delete' => []];

		if (!empty($bankOps['create']) || !empty($bankOps['update']) || !empty($bankOps['delete'])) {
			$bankRepo = new (Helper::repository('account_bank'))(new (Helper::model('account_bank')), transaction: false);

			foreach ($bankOps['create'] as $data) {
				$bankRepo->create($data);
			}

			foreach ($bankOps['update'] as $id => $data) {
				$bankRepo->update($id, $data);
			}

			foreach ($bankOps['delete'] as $id) {
				$bankRepo->delete($id);
			}
		}
	}
}
