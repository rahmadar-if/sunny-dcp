<?php

namespace Solaris\BaseCRM\Ai\Tools\Account;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\MasterData\Ai\Tools\Account\SearchAccountTool as BaseSearchAccountTool;

class SearchAccountTool extends BaseSearchAccountTool
{
	protected function resourceLabel(): string
	{
		return parent::resourceLabel() . ' with CRM lifecycle tracking (status, segmentation, RFM scoring, and lead pipeline)';
	}

	protected function fields(): array
	{
		return array_merge(parent::fields(), [
			'status_id' => AiSearchColumn::lookup(
				column: 'status_id',
				description: 'CRM lifecycle stage of the account',
				modelKey: 'account_status',
			),
			'annual_revenue_id' => AiSearchColumn::lookup(
				column: 'annual_revenue_id',
				description: 'Annual revenue range',
				modelKey: 'annual_revenue',
			),
			'customer_journey_id' => AiSearchColumn::lookup(
				column: 'customer_journey_id',
				description: 'Customer journey stage',
				modelKey: 'customer_journey',
			),
			'segmentation_id' => AiSearchColumn::lookup(
				column: 'segmentation_id',
				description: 'Account segmentation',
				modelKey: 'segmentation',
			),
			'business_size_id' => AiSearchColumn::lookup(
				column: 'business_size_id',
				description: 'Business size category',
				modelKey: 'business_size',
			),
			'frequency_type_id' => AiSearchColumn::lookup(
				column: 'frequency_type_id',
				description: 'Purchase/interaction frequency unit (e.g. weekly, monthly)',
				modelKey: 'frequency_type',
			),
			'recency_date' => AiSearchColumn::date(
				'recency_date',
				'Date of the account\'s most recent transaction or interaction (RFM recency)',
			),
			'monetary' => AiSearchColumn::number(
				'monetary',
				'Total monetary value associated with the account (RFM monetary)',
			),
			'frequency' => AiSearchColumn::number(
				'frequency',
				'Count of transactions or interactions (RFM frequency)',
			),
		]);
	}

	protected function formatRecord(Model $record): array
	{
		return array_merge(parent::formatRecord($record), [
			'status'            => $record->status?->name,
			'annual_revenue'    => $record->annual_revenue?->name,
			'customer_journey'  => $record->customer_journey?->name,
			'segmentation'      => $record->segmentation?->name,
			'business_size'     => $record->business_size?->name,
			'frequency_type'    => $record->frequency_type?->name,
			'recency_date'      => $record->recency_date ? Carbon::parse($record->recency_date)->format('d M Y') : null,
			'monetary'          => $record->monetary,
			'frequency'         => $record->frequency,
		]);
	}

	// account_status_history has no relation method on the Account model (auto-managed by
	// HasStageHistory), so it stays a standalone resource filterable by its own account_id column
	// rather than an Account relation-group.
	protected function relations(): array
	{
		return array_merge(parent::relations(), [
			'account_banks' => 'search_account_bank',
			'leads'         => 'search_lead',
		]);
	}
}
