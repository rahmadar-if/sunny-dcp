<?php

namespace Solaris\BaseCRM\Ai\Tools\Account;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Arr;
use Laravel\Ai\Tools\Request;
use Solaris\BaseCRM\Ai\Tools\AccountBank\CreateAccountBankTool;
use Solaris\BaseCRM\Http\Requests\AccountBankRequest;
use Solaris\BaseCRM\Http\Requests\AccountRequest;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Ai\Tools\Account\CreateAccountTool as BaseCreateAccountTool;

class CreateAccountTool extends BaseCreateAccountTool
{
	public static function fields(JsonSchema $schema): array
	{
		$bankFields = Arr::except(CreateAccountBankTool::fields($schema), ['account_id']);

		return array_merge(parent::fields($schema), [
			'status_id'           => $schema->string()->description('CRM lifecycle status. Resolve via lookup_options with type: "account_status".'),
			'annual_revenue_id'   => $schema->string()->description('Annual revenue range. Resolve via lookup_options with type: "annual_revenue".'),
			'customer_journey_id' => $schema->string()->description('Customer journey stage. Resolve via lookup_options with type: "customer_journey".'),
			'segmentation_id'     => $schema->string()->description('Account segmentation. Resolve via lookup_options with type: "segmentation".'),
			'business_size_id'    => $schema->string()->description('Business size. Resolve via lookup_options with type: "business_size".'),
			'frequency_type_id'   => $schema->string()->description('Frequency unit. Resolve via lookup_options with type: "frequency_type".'),
			'recency_date'        => $schema->string()->description('Most recent interaction date in Y-m-d format.'),
			'monetary'            => $schema->number()->description('Total monetary value.'),
			'frequency'           => $schema->integer()->description('Count of transactions. Required when frequency_type_id is set.'),
			'detail_account_banks' => $schema->array()
				->items($schema->object($bankFields))
				->description('Bank accounts to add under this account, each linked automatically. Supports multiple. Optional.'),
		]);
	}

	// Exclude detail_account_banks when embedded in other tools' new_account field.
	public static function coreFields(JsonSchema $schema): array
	{
		return Arr::except(static::fields($schema), [
			'primary_contact_id', 'new_primary_contact',
			'detail_contacts', 'detail_addresses', 'detail_activities', 'detail_account_banks',
		]);
	}

	protected function lookupChecks(): array
	{
		return array_merge(parent::lookupChecks(), [
			AiColumn::lookup(column: 'status_id', label: 'account status', modelKey: 'account_status'),
			AiColumn::lookup(column: 'annual_revenue_id', label: 'annual revenue', modelKey: 'annual_revenue'),
			AiColumn::lookup(column: 'customer_journey_id', label: 'customer journey', modelKey: 'customer_journey'),
			AiColumn::lookup(column: 'segmentation_id', label: 'segmentation', modelKey: 'segmentation'),
			AiColumn::lookup(column: 'business_size_id', label: 'business size', modelKey: 'business_size'),
			AiColumn::lookup(column: 'frequency_type_id', label: 'frequency type', modelKey: 'frequency_type'),
		]);
	}

	protected function rules(): array
	{
		return AccountRequest::createRules();
	}

	protected function afterValidation(Validator $validator): void
	{
		parent::afterValidation($validator);

		$validator->after(fn (Validator $v) => AccountRequest::validateFrequency($v));
	}

	public function validateConfirmation(Request $request): array
	{
		$result = parent::validateConfirmation($request);

		if (isset($result['error'])) {
			return $result;
		}

		$accountId = $result['payload']['raw']['id'];

		[$banks, $errors] = $this->validateDetailList((array) ($request['detail_account_banks'] ?? []), AccountBankRequest::createRules(), 'account_id', $accountId);
		if (!empty($errors)) {
			return AiResponse::error(AiErrorCode::UserError,'One or more account banks failed validation.', ['messages' => $errors]);
		}

		$result['payload']['raw']['detail_account_banks'] = $banks;

		if (!empty($banks)) {
			$result['summary']['detail_account_banks'] = array_map(fn ($b) => $b['bank_name'], $banks);
		}

		return $result;
	}

	protected function afterCreate(Model $record, array $raw): void
	{
		parent::afterCreate($record, $raw);

		$banks = $raw['detail_account_banks'] ?? [];
		if (!empty($banks)) {
			$bankRepo = new (Helper::repository('account_bank'))(new (Helper::model('account_bank')), transaction: false);
			foreach ($banks as $data) {
				$bankRepo->create($data);
			}
		}
	}
}
