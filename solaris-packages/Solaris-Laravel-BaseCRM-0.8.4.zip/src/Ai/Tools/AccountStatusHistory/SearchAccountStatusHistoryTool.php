<?php

namespace Solaris\BaseCRM\Ai\Tools\AccountStatusHistory;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

class SearchAccountStatusHistoryTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_account_status_history';
	}

	protected function resourceLabel(): string
	{
		return 'account status history — history of CRM lifecycle stage changes for an account';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('account_status_history'))();
	}

	protected function fields(): array
	{
		return [
			'account_id' => AiSearchColumn::reference(
				column: 'account_id',
				description: 'The account id this status history belongs to. Obtain it with the account search tool available to you first.',
				modelKey: 'account',
			),
			'status_id' => AiSearchColumn::lookup(
				column: 'status_id',
				description: 'CRM lifecycle stage held during this period',
				modelKey: 'account_status',
			),
			'position' => AiSearchColumn::number(
				column: 'position',
				description: 'Sequence order of this stage within the account\'s history, starting at 1',
			),
			'start' => AiSearchColumn::datetime('start', 'Date and time this stage started'),
			'end'   => AiSearchColumn::datetime('end', 'Date and time this stage ended (empty means still current)'),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'         => $record->id,
			'_account_id' => $record->account_id,
			'status'      => $record->status?->name,
			'position'    => $record->position,
			'start'       => $record->start ? Carbon::parse($record->start)->format('d M Y H:i') : null,
			'end'         => $record->end ? Carbon::parse($record->end)->format('d M Y H:i') : null,
		];
	}
}
