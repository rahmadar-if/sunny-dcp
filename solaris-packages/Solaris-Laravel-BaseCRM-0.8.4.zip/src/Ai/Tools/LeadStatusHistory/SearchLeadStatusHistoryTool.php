<?php

namespace Solaris\BaseCRM\Ai\Tools\LeadStatusHistory;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

class SearchLeadStatusHistoryTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_lead_status_history';
	}

	protected function resourceLabel(): string
	{
		return 'lead status history — history of qualification stage changes for a lead';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('lead_status_history'))();
	}

	protected function fields(): array
	{
		return [
			'lead_id' => AiSearchColumn::reference(
				column: 'lead_id',
				description: 'The lead id this status history belongs to. Obtain it with the lead search tool available to you first.',
				modelKey: 'lead',
			),
			'status_id' => AiSearchColumn::lookup(
				column: 'status_id',
				description: 'Qualification stage held during this period',
				modelKey: 'lead_status',
			),
			'position' => AiSearchColumn::number(
				column: 'position',
				description: 'Sequence order of this stage within the lead\'s history, starting at 1',
			),
			'start' => AiSearchColumn::datetime('start', 'Date and time this stage started'),
			'end'   => AiSearchColumn::datetime('end', 'Date and time this stage ended (empty means still current)'),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'      => $record->id,
			'_lead_id' => $record->lead_id,
			'status'   => $record->status?->name,
			'position' => $record->position,
			'start'    => $record->start ? Carbon::parse($record->start)->format('d M Y H:i') : null,
			'end'      => $record->end ? Carbon::parse($record->end)->format('d M Y H:i') : null,
		];
	}
}
