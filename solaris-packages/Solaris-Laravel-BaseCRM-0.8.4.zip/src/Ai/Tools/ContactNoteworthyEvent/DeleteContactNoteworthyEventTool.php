<?php

namespace Solaris\BaseCRM\Ai\Tools\ContactNoteworthyEvent;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseDeleteAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\BaseCRM\Models\ContactNoteworthyEvent;

class DeleteContactNoteworthyEventTool extends BaseDeleteAiTool
{
	public static function slug(): string
	{
		return 'delete_contact_noteworthy_event';
	}

	protected function resourceLabel(): string
	{
		return 'contact noteworthy event';
	}

	protected function findRecordById(string $id): ?ContactNoteworthyEvent
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('contact_noteworthy_event'))(new (Helper::model('contact_noteworthy_event')));

		return $repo->find($id);
	}

	protected function delete(Model $record): array
	{
		$repo = new (Helper::repository('contact_noteworthy_event'))(new (Helper::model('contact_noteworthy_event')));
		$repo->delete($record->id);

		return AiResponse::success(
			['deleted' => ($record->type?->name ?? 'event') . ' on ' . $record->date?->format('d M Y')],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
