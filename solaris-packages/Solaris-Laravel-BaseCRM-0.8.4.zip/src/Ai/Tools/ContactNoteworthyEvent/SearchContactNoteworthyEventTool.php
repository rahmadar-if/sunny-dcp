<?php

namespace Solaris\BaseCRM\Ai\Tools\ContactNoteworthyEvent;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

class SearchContactNoteworthyEventTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_contact_noteworthy_event';
	}

	protected function resourceLabel(): string
	{
		return 'contact noteworthy events — notable dates/events recorded against a contact (e.g. birthday, anniversary)';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('contact_noteworthy_event'))();
	}

	protected function fields(): array
	{
		return [
			'contact_id' => AiSearchColumn::reference(
				column: 'contact_id',
				description: 'The contact id this event belongs to. Obtain it with the contact search tool available to you first.',
				modelKey: 'contact',
			),
			'type_id' => AiSearchColumn::lookup(
				column: 'type_id',
				description: 'Type of noteworthy event',
				modelKey: 'noteworthy_event_type',
			),
			'date' => AiSearchColumn::date('date', 'Date the event falls on'),
			'notes' => AiSearchColumn::string(
				column: 'notes',
				description: 'Free-text notes about the event',
				searchable: true,
			),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'         => $record->id,
			'_contact_id' => $record->contact_id,
			'type'        => $record->type?->name,
			'date'        => $record->date ? Carbon::parse($record->date)->format('d M Y') : null,
			'notes'       => $record->notes,
		];
	}
}
