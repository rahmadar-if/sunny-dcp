<?php

namespace Solaris\BaseCRM\Ai\Tools\ContactNoteworthyEvent;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\BaseCRM\Http\Requests\ContactNoteworthyEventRequest;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseCreateAiTool;
use Solaris\Core\Helpers\Helper;

class CreateContactNoteworthyEventTool extends BaseCreateAiTool
{
	public static function slug(): string
	{
		return 'create_contact_noteworthy_event';
	}

	protected function resourceLabel(): string
	{
		return 'contact noteworthy event';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'contact_id' => $schema->string()
				->description('The contact id to add this event to. Obtain it with the contact search tool available to you first.')
				->required(),
			'type_id' => $schema->string()
				->description('Event type id. Resolve via lookup_options with type: "noteworthy_event_type".')
				->required(),
			'date' => $schema->string()
				->description('Date of the event in Y-m-d format.')
				->required(),
			'notes' => $schema->string()
				->description('Optional notes about the event.'),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::lookup(column: 'type_id', label: 'event type', modelKey: 'noteworthy_event_type'),
			AiColumn::reference(column: 'contact_id', label: 'contact', modelKey: 'contact'),
		];
	}

	protected function rules(): array
	{
		return ContactNoteworthyEventRequest::createRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'NATURAL LANGUAGE: If the user asks to add a notable date or event to a contact, '
			. 'first locate the contact with the contact search tool available to you if the id is not already known, '
			. 'then confirm the event details before calling this tool.';
	}

	protected function create(array $validated, array $raw): array
	{
		$repo  = new (Helper::repository('contact_noteworthy_event'))(new (Helper::model('contact_noteworthy_event')));
		$event = $repo->create($validated,
			before: fn ($data)   => $this->beforeCreate($data, $raw),
			after:  fn ($record) => $this->afterCreate($record, $raw),
		);

		return AiResponse::success(
			['id' => $event->id, 'type' => $event->type?->name, 'date' => $event->date?->format('d M Y')],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
