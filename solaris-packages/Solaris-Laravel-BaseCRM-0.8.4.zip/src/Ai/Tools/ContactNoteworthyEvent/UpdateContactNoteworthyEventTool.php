<?php

namespace Solaris\BaseCRM\Ai\Tools\ContactNoteworthyEvent;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\BaseCRM\Http\Requests\ContactNoteworthyEventRequest;
use Solaris\BaseCRM\Models\ContactNoteworthyEvent;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseUpdateAiTool;
use Solaris\Core\Helpers\Helper;

class UpdateContactNoteworthyEventTool extends BaseUpdateAiTool
{
	public static function slug(): string
	{
		return 'update_contact_noteworthy_event';
	}

	protected function resourceLabel(): string
	{
		return 'contact noteworthy event';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'id' => $schema->string()
				->description('The noteworthy event id. Required.')
				->required(),
			'type_id' => $schema->string()
				->description('New event type id. Resolve via lookup_options with type: "noteworthy_event_type".'),
			'date' => $schema->string()
				->description('New date in Y-m-d format.'),
			'notes' => $schema->string()
				->description('New notes.'),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::lookup(column: 'type_id', label: 'event type', modelKey: 'noteworthy_event_type'),
		];
	}

	protected function rules(): array
	{
		return ContactNoteworthyEventRequest::updateRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'NATURAL LANGUAGE: If the user asks to edit a noteworthy event, first locate it via '
			. 'the contact noteworthy event search tool if the id is not already known, '
			. 'then confirm the changes before calling this tool.';
	}

	protected function findRecordById(string $id): ?ContactNoteworthyEvent
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('contact_noteworthy_event'))(new (Helper::model('contact_noteworthy_event')));

		return $repo->find($id);
	}

	protected function currentData(mixed $record): array
	{
		return [
			'type_id' => $record->type_id,
			'date'    => $record->date?->format('Y-m-d'),
			'notes'   => $record->notes,
		];
	}

	protected function update(mixed $record, array $validated, array $changes): array
	{
		$repo = new (Helper::repository('contact_noteworthy_event'))(new (Helper::model('contact_noteworthy_event')));
		$repo->update($record->id, $validated,
			before: fn ($record, $data) => $this->beforeUpdate($record, $data, $changes),
			after:  fn ($record)        => $this->afterUpdate($record, $changes),
		);

		return AiResponse::success(
			['id' => $record->id, 'updated' => array_keys($changes)],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
