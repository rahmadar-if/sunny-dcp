<?php

namespace Solaris\BaseCRM\Ai\Tools\ActivityParticipant;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\BaseCRM\Http\Requests\ActivityParticipantRequest;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseCreateAiTool;
use Solaris\Core\Helpers\Helper;

class CreateActivityParticipantTool extends BaseCreateAiTool
{
	public static function slug(): string
	{
		return 'create_activity_participant';
	}

	protected function resourceLabel(): string
	{
		return 'activity participant';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'activity_id' => $schema->string()
				->description('The activity id to add this participant to. Obtain it with the activity search tool available to you first.')
				->required(),
			'name' => $schema->string()
				->description('Name of the participant.')
				->required(),
			'role' => $schema->string()
				->description('Role of the participant in the activity.')
				->required(),
			'notes' => $schema->string()
				->description('Optional notes about this participant.'),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::reference(column: 'activity_id', label: 'activity', modelKey: 'activity'),
		];
	}

	protected function rules(): array
	{
		return ActivityParticipantRequest::createRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'NATURAL LANGUAGE: If the user asks to add a participant to an activity, '
			. 'first locate the activity with the activity search tool available to you if the id is not already known, '
			. 'then confirm the participant details before calling this tool.';
	}

	protected function create(array $validated, array $raw): array
	{
		$repo        = new (Helper::repository('activity_participant'))(new (Helper::model('activity_participant')));
		$participant = $repo->create($validated,
			before: fn ($data)   => $this->beforeCreate($data, $raw),
			after:  fn ($record) => $this->afterCreate($record, $raw),
		);

		return AiResponse::success(
			['id' => $participant->id, 'name' => $participant->name, 'role' => $participant->role],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
