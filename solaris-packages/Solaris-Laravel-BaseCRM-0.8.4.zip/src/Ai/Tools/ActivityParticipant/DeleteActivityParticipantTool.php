<?php

namespace Solaris\BaseCRM\Ai\Tools\ActivityParticipant;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseDeleteAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\BaseCRM\Models\ActivityParticipant;

class DeleteActivityParticipantTool extends BaseDeleteAiTool
{
	public static function slug(): string
	{
		return 'delete_activity_participant';
	}

	protected function resourceLabel(): string
	{
		return 'activity participant';
	}

	protected function findRecordById(string $id): ?ActivityParticipant
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('activity_participant'))(new (Helper::model('activity_participant')));

		return $repo->find($id);
	}

	protected function delete(Model $record): array
	{
		$repo = new (Helper::repository('activity_participant'))(new (Helper::model('activity_participant')));
		$repo->delete($record->id);

		return AiResponse::success(
			['deleted' => $record->name . ' (' . $record->role . ')'],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
