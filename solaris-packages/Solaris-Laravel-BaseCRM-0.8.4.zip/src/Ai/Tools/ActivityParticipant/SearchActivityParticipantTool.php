<?php

namespace Solaris\BaseCRM\Ai\Tools\ActivityParticipant;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

class SearchActivityParticipantTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_activity_participant';
	}

	protected function resourceLabel(): string
	{
		return 'activity participants — people attending or involved in an activity';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('activity_participant'))();
	}

	protected function fields(): array
	{
		return [
			'activity_id' => AiSearchColumn::reference(
				column: 'activity_id',
				description: 'The activity id this participant belongs to. Obtain it with the activity search tool available to you first.',
				modelKey: 'activity',
			),
			'name' => AiSearchColumn::string(
				column: 'name',
				description: 'Name of the participant',
				searchable: true,
			),
			'role' => AiSearchColumn::string(
				column: 'role',
				description: 'Role of the participant in the activity',
				searchable: true,
			),
			'notes' => AiSearchColumn::string(
				column: 'notes',
				description: 'Free-text notes about the participant',
				searchable: true,
			),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'          => $record->id,
			'_activity_id' => $record->activity_id,
			'name'         => $record->name,
			'role'         => $record->role,
			'notes'        => $record->notes,
		];
	}
}
