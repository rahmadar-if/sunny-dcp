<?php

namespace Solaris\BaseCRM\Ai\Tools\ActivityParticipant;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\BaseCRM\Http\Requests\ActivityParticipantRequest;
use Solaris\BaseCRM\Models\ActivityParticipant;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseUpdateAiTool;
use Solaris\Core\Helpers\Helper;

class UpdateActivityParticipantTool extends BaseUpdateAiTool
{
	public static function slug(): string
	{
		return 'update_activity_participant';
	}

	protected function resourceLabel(): string
	{
		return 'activity participant';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'id' => $schema->string()
				->description('The participant id. Required.')
				->required(),
			'name' => $schema->string()
				->description('New name of the participant.'),
			'role' => $schema->string()
				->description('New role of the participant.'),
			'notes' => $schema->string()
				->description('New notes.'),
		];
	}

	protected function lookupChecks(): array
	{
		return [];
	}

	protected function rules(): array
	{
		return ActivityParticipantRequest::updateRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'NATURAL LANGUAGE: If the user asks to update an activity participant, first locate it via '
			. 'the activity participant search tool if the id is not already known, '
			. 'then confirm the changes before calling this tool.';
	}

	protected function findRecordById(string $id): ?ActivityParticipant
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('activity_participant'))(new (Helper::model('activity_participant')));

		return $repo->find($id);
	}

	protected function currentData(mixed $record): array
	{
		return [
			'name'  => $record->name,
			'role'  => $record->role,
			'notes' => $record->notes,
		];
	}

	protected function update(mixed $record, array $validated, array $changes): array
	{
		$repo = new (Helper::repository('activity_participant'))(new (Helper::model('activity_participant')));
		$repo->update($record->id, $validated,
			before: fn ($record, $data) => $this->beforeUpdate($record, $data, $changes),
			after:  fn ($record)        => $this->afterUpdate($record, $changes),
		);

		return AiResponse::success(
			['id' => $record->id, 'updated' => array_keys($changes)],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
