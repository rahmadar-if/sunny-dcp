<?php

namespace Solaris\BaseCRM\Ai\Tools\Lead;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseDeleteAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\BaseCRM\Models\Lead;

class DeleteLeadTool extends BaseDeleteAiTool
{
	public static function slug(): string
	{
		return 'delete_lead';
	}

	protected function resourceLabel(): string
	{
		return 'lead';
	}

	protected function findRecordById(string $id): ?Lead
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('lead'))(new (Helper::model('lead')));

		return $repo->find($id);
	}

	protected function delete(Model $record): array
	{
		$repo = new (Helper::repository('lead'))(new (Helper::model('lead')));
		$repo->delete($record->id);

		return AiResponse::success(
			['deleted' => $record->name],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
