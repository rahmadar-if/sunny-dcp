<?php

namespace Solaris\BaseCRM\Ai\Tools\Lead;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\BaseCRM\Http\Requests\LeadRequest;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseCreateAiTool;
use Solaris\Core\Helpers\Helper;

class CreateLeadTool extends BaseCreateAiTool
{
	public static function slug(): string
	{
		return 'create_lead';
	}

	protected function resourceLabel(): string
	{
		return 'lead';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'name' => $schema->string()
				->description('Full name of the lead.')
				->required(),
			'registration_method_id' => $schema->string()
				->description('How the lead was registered. Resolve via lookup_options with type: "lead_registration_method".')
				->required(),
			'date' => $schema->string()
				->description('Date the lead was captured, in Y-m-d format.')
				->required(),
			'phone' => $schema->string()
				->description('Phone number. Required if email is not provided.'),
			'email' => $schema->string()
				->description('Email address. Required if phone is not provided.'),
			'customer_need' => $schema->string()
				->description('What the lead is looking for — minimum 10 characters.')
				->required(),
			'source_id' => $schema->string()
				->description('Where the lead came from. Resolve via lookup_options with type: "lead_source".'),
			'account_id' => $schema->string()
				->description('Existing account to link. Obtain it with the account search tool available to you first.'),
			'contact_id' => $schema->string()
				->description('Existing contact to link. Obtain it with the contact search tool available to you first.'),
			'account_name' => $schema->string()
				->description('Company name given by the lead, if not linking to an existing account.'),
			'contact_name' => $schema->string()
				->description('Contact person name given by the lead, if not linking to an existing contact.'),
			'contact_job_title' => $schema->string()
				->description('Job title of the lead\'s contact person.'),
			'notes' => $schema->string()
				->description('Free-text notes about the lead.'),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::lookup(column: 'registration_method_id', label: 'registration method', modelKey: 'lead_registration_method'),
			AiColumn::lookup(column: 'source_id', label: 'source', modelKey: 'lead_source'),
			AiColumn::reference(column: 'account_id', label: 'account', modelKey: 'account'),
			AiColumn::reference(column: 'contact_id', label: 'contact', modelKey: 'contact'),
		];
	}

	protected function rules(): array
	{
		return LeadRequest::createRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'NATURAL LANGUAGE: If the user asks to register or add a new lead, '
			. 'collect at minimum: name, date, customer_need, and at least phone or email. '
			. 'Resolve registration_method_id via lookup_options if not already known. '
			. 'Confirm all details with the user before calling this tool.';
	}

	protected function create(array $validated, array $raw): array
	{
		$repo = new (Helper::repository('lead'))(new (Helper::model('lead')));
		$lead = $repo->create($validated,
			before: fn ($data)   => $this->beforeCreate($data, $raw),
			after:  fn ($record) => $this->afterCreate($record, $raw),
		);

		return AiResponse::success(
			['id' => $lead->id, 'name' => $lead->name, 'date' => $lead->date?->format('d M Y')],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
