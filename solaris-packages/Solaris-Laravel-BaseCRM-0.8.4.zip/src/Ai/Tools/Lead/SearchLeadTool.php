<?php

namespace Solaris\BaseCRM\Ai\Tools\Lead;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Services\Filter;

class SearchLeadTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_lead';
	}

	protected function resourceLabel(): string
	{
		return 'leads — sales/marketing leads captured for potential accounts or contacts, tracked through a qualification pipeline';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('lead'))();
	}

	protected function fields(): array
	{
		return [
			'name' => AiSearchColumn::string(
				column: 'name',
				description: 'Name of the lead. For filters, combine SIMILAR OR LIKE in the same OR-group — '
					. 'SIMILAR tolerates typos/reordering/partial/extra wording, LIKE catches plain substring '
					. 'matches SIMILAR can miss.',
				searchable: true,
			),
			'account_name' => AiSearchColumn::string(
				column: 'account_name',
				description: 'Company/organization name given by the lead, before any account record exists for it',
				searchable: true,
			),
			'contact_name' => AiSearchColumn::string(
				column: 'contact_name',
				description: 'Contact person name given by the lead, before any contact record exists for it',
				searchable: true,
			),
			'contact_job_title' => AiSearchColumn::string(
				column: 'contact_job_title',
				description: 'Job title of the lead\'s contact person',
				searchable: true,
			),
			'phone' => AiSearchColumn::string(
				column: 'phone',
				description: 'Phone number',
				searchable: true,
			),
			'email' => AiSearchColumn::string(
				column: 'email',
				description: 'Email address',
				searchable: true,
			),
			'customer_need' => AiSearchColumn::string(
				column: 'customer_need',
				description: 'What the lead is looking for',
				searchable: true,
			),
			'notes_plain' => AiSearchColumn::string(
				column: 'notes_plain',
				description: 'Plain text notes about the lead',
				operators: [Filter::Contains, Filter::FullText],
				searchable: 'FullText',
			),
			'date' => AiSearchColumn::date('date', 'Date the lead was captured'),
			'follow_up_date' => AiSearchColumn::date('follow_up_date', 'Date the lead should be followed up on'),
			'follow_up_remind_at' => AiSearchColumn::datetime('follow_up_remind_at', 'Date and time the follow-up reminder is set for'),
			'is_follow_up_reminded' => AiSearchColumn::boolean('is_follow_up_reminded', 'Whether the follow-up reminder has already been sent'),
			'is_new_account' => AiSearchColumn::boolean('is_new_account', 'Whether this lead should become a new account rather than link to an existing one'),
			'is_new_contact' => AiSearchColumn::boolean('is_new_contact', 'Whether this lead should become a new contact rather than link to an existing one'),
			'add_to_calendar' => AiSearchColumn::boolean('add_to_calendar', 'Whether the follow-up was added to the calendar'),
			'status_id' => AiSearchColumn::lookup(
				column: 'status_id',
				description: 'Qualification stage of the lead',
				modelKey: 'lead_status',
			),
			'source_id' => AiSearchColumn::lookup(
				column: 'source_id',
				description: 'Where the lead came from',
				modelKey: 'lead_source',
			),
			'registration_method_id' => AiSearchColumn::lookup(
				column: 'registration_method_id',
				description: 'How the lead was registered',
				modelKey: 'lead_registration_method',
			),
			'segmentation_id' => AiSearchColumn::lookup(
				column: 'segmentation_id',
				description: 'Lead segmentation',
				modelKey: 'segmentation',
			),
			'number_of_employee_id' => AiSearchColumn::lookup(
				column: 'number_of_employee_id',
				description: 'Employee count range of the lead\'s company',
				modelKey: 'number_of_employee',
			),
			'annual_revenue_id' => AiSearchColumn::lookup(
				column: 'annual_revenue_id',
				description: 'Annual revenue range of the lead\'s company',
				modelKey: 'annual_revenue',
			),
			'business_size_id' => AiSearchColumn::lookup(
				column: 'business_size_id',
				description: 'Business size category of the lead\'s company',
				modelKey: 'business_size',
			),
			'industry_id' => AiSearchColumn::lookup(
				column: 'industry_id',
				description: 'Industry of the lead\'s company',
				modelKey: 'industry',
			),
			'budget_range_id' => AiSearchColumn::lookup(
				column: 'budget_range_id',
				description: 'Budget range of the lead',
				modelKey: 'budget_range',
			),
			'disqualification_reason_id' => AiSearchColumn::lookup(
				column: 'disqualification_reason_id',
				description: 'Reason the lead was disqualified, if applicable',
				modelKey: 'disqualification_reason',
			),
			'disqualification_reason_text' => AiSearchColumn::string(
				column: 'disqualification_reason_text',
				description: 'Free-text detail of the disqualification reason',
				searchable: true,
			),
			'account_id' => AiSearchColumn::reference(
				column: 'account_id',
				description: 'The existing account this lead is linked to, if any. Obtain it with the account search tool available to you first.',
				modelKey: 'account',
			),
			'contact_id' => AiSearchColumn::reference(
				column: 'contact_id',
				description: 'The existing contact this lead is linked to, if any. Obtain it with the contact search tool available to you first.',
				modelKey: 'contact',
			),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'         => $record->id,
			'_account_id' => $record->account_id,
			'_contact_id' => $record->contact_id,
			'name'        => $record->name,
			'account'     => $record->account?->name ?? $record->account_name,
			'contact'     => $record->contact?->name ?? $record->contact_name,
			'phone'       => $record->phone,
			'email'       => $record->email,
			'status'      => $record->status?->name,
			'source'      => $record->source?->name,
			'date'        => $record->date ? Carbon::parse($record->date)->format('d M Y') : null,
		];
	}

	protected function relations(): array
	{
		return [
			'activities'       => 'search_activity',
			'status_histories' => 'search_lead_status_history',
		];
	}
}
