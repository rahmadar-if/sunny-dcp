<?php

namespace Solaris\BaseCRM\Ai\Tools\Lead;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\BaseCRM\Http\Requests\LeadRequest;
use Solaris\BaseCRM\Models\Lead;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseUpdateAiTool;
use Solaris\Core\Helpers\Helper;

class UpdateLeadTool extends BaseUpdateAiTool
{
	public static function slug(): string
	{
		return 'update_lead';
	}

	protected function resourceLabel(): string
	{
		return 'lead';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'id' => $schema->string()
				->description('The lead id. Required.')
				->required(),
			'name' => $schema->string()
				->description('New full name of the lead.'),
			'registration_method_id' => $schema->string()
				->description('New registration method. Resolve via lookup_options with type: "lead_registration_method".'),
			'date' => $schema->string()
				->description('New capture date in Y-m-d format.'),
			'phone' => $schema->string()
				->description('New phone number.'),
			'email' => $schema->string()
				->description('New email address.'),
			'customer_need' => $schema->string()
				->description('Updated customer need description — minimum 10 characters.'),
			'status_id' => $schema->string()
				->description('New qualification status. Resolve via lookup_options with type: "lead_status".'),
			'source_id' => $schema->string()
				->description('New source. Resolve via lookup_options with type: "lead_source".'),
			'account_id' => $schema->string()
				->description('Linked account id. Obtain it with the account search tool available to you first.'),
			'contact_id' => $schema->string()
				->description('Linked contact id. Obtain it with the contact search tool available to you first.'),
			'follow_up_date' => $schema->string()
				->description('Follow-up date in Y-m-d format.'),
			'follow_up_remind_at' => $schema->string()
				->description('Follow-up reminder datetime.'),
			'segmentation_id' => $schema->string()
				->description('Segmentation. Resolve via lookup_options with type: "segmentation".'),
			'number_of_employee_id' => $schema->string()
				->description('Employee count range. Resolve via lookup_options with type: "number_of_employee".'),
			'annual_revenue_id' => $schema->string()
				->description('Annual revenue range. Resolve via lookup_options with type: "annual_revenue".'),
			'business_size_id' => $schema->string()
				->description('Business size. Resolve via lookup_options with type: "business_size".'),
			'industry_id' => $schema->string()
				->description('Industry. Resolve via lookup_options with type: "industry".'),
			'budget_range_id' => $schema->string()
				->description('Budget range. Resolve via lookup_options with type: "budget_range".'),
			'disqualification_reason_id' => $schema->string()
				->description('Disqualification reason — required when status is Disqualified. Resolve via lookup_options with type: "disqualification_reason".'),
			'disqualification_reason_text' => $schema->string()
				->description('Free-text detail for disqualification reason — required when reason is "Other".'),
			'notes' => $schema->string()
				->description('Free-text notes.'),
			'account_name' => $schema->string()
				->description('Company name given by the lead.'),
			'contact_name' => $schema->string()
				->description('Contact person name given by the lead.'),
			'contact_job_title' => $schema->string()
				->description('Job title of the lead\'s contact person.'),
			'add_to_calendar' => $schema->boolean()
				->description('Whether the follow-up should be added to the calendar.'),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::lookup(column: 'status_id', label: 'lead status', modelKey: 'lead_status'),
			AiColumn::lookup(column: 'registration_method_id', label: 'registration method', modelKey: 'lead_registration_method'),
			AiColumn::lookup(column: 'source_id', label: 'source', modelKey: 'lead_source'),
			AiColumn::lookup(column: 'segmentation_id', label: 'segmentation', modelKey: 'segmentation'),
			AiColumn::lookup(column: 'number_of_employee_id', label: 'number of employees', modelKey: 'number_of_employee'),
			AiColumn::lookup(column: 'annual_revenue_id', label: 'annual revenue', modelKey: 'annual_revenue'),
			AiColumn::lookup(column: 'business_size_id', label: 'business size', modelKey: 'business_size'),
			AiColumn::lookup(column: 'industry_id', label: 'industry', modelKey: 'industry'),
			AiColumn::lookup(column: 'budget_range_id', label: 'budget range', modelKey: 'budget_range'),
			AiColumn::lookup(column: 'disqualification_reason_id', label: 'disqualification reason', modelKey: 'disqualification_reason'),
			AiColumn::reference(column: 'account_id', label: 'account', modelKey: 'account'),
			AiColumn::reference(column: 'contact_id', label: 'contact', modelKey: 'contact'),
		];
	}

	protected function rules(): array
	{
		return LeadRequest::updateRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'NATURAL LANGUAGE: If the user asks to update or edit a lead, first locate it via '
			. 'the lead search tool if the id is not already known, then confirm the changes before calling this tool. '
			. 'When disqualifying a lead, resolve status_id and disqualification_reason_id via lookup_options first.';
	}

	protected function findRecordById(string $id): ?Lead
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('lead'))(new (Helper::model('lead')));

		return $repo->find($id);
	}

	protected function currentData(mixed $record): array
	{
		return [
			'name'                         => $record->name,
			'registration_method_id'       => $record->registration_method_id,
			'date'                         => $record->date?->format('Y-m-d'),
			'phone'                        => $record->phone,
			'email'                        => $record->email,
			'customer_need'                => $record->customer_need,
			'status_id'                    => $record->status_id,
			'source_id'                    => $record->source_id,
			'account_id'                   => $record->account_id,
			'contact_id'                   => $record->contact_id,
			'follow_up_date'               => $record->follow_up_date?->format('Y-m-d'),
			'follow_up_remind_at'          => $record->follow_up_remind_at,
			'segmentation_id'              => $record->segmentation_id,
			'number_of_employee_id'        => $record->number_of_employee_id,
			'annual_revenue_id'            => $record->annual_revenue_id,
			'business_size_id'             => $record->business_size_id,
			'industry_id'                  => $record->industry_id,
			'budget_range_id'              => $record->budget_range_id,
			'disqualification_reason_id'   => $record->disqualification_reason_id,
			'disqualification_reason_text' => $record->disqualification_reason_text,
			'notes'                        => $record->notes,
			'account_name'                 => $record->account_name,
			'contact_name'                 => $record->contact_name,
			'contact_job_title'            => $record->contact_job_title,
			'add_to_calendar'              => $record->add_to_calendar,
		];
	}

	protected function update(mixed $record, array $validated, array $changes): array
	{
		$repo = new (Helper::repository('lead'))(new (Helper::model('lead')));
		$repo->update($record->id, $validated,
			before: fn ($record, $data) => $this->beforeUpdate($record, $data, $changes),
			after:  fn ($record)        => $this->afterUpdate($record, $changes),
		);

		return AiResponse::success(
			['id' => $record->id, 'name' => $record->name, 'updated' => array_keys($changes)],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
