<?php

namespace Solaris\BaseCRM\Ai\Tools\Contact;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Arr;
use Laravel\Ai\Tools\Request;
use Solaris\BaseCRM\Ai\Tools\ContactNoteworthyEvent\CreateContactNoteworthyEventTool;
use Solaris\BaseCRM\Ai\Tools\ContactPreviousCompany\CreateContactPreviousCompanyTool;
use Solaris\BaseCRM\Http\Requests\ContactNoteworthyEventRequest;
use Solaris\BaseCRM\Http\Requests\ContactPreviousCompanyRequest;
use Solaris\BaseCRM\Http\Requests\ContactRequest;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Ai\Tools\Contact\CreateContactTool as BaseCreateContactTool;

class CreateContactTool extends BaseCreateContactTool
{
	public static function slug(): string
	{
		return 'create_contact';
	}

	public static function fields(JsonSchema $schema): array
	{
		$eventFields   = Arr::except(CreateContactNoteworthyEventTool::fields($schema), ['contact_id']);
		$companyFields = Arr::except(CreateContactPreviousCompanyTool::fields($schema), ['contact_id']);

		return array_merge(parent::fields($schema), [
			'status_id' => $schema->string()
				->description('CRM contact status at creation. Resolve via lookup_options with type: "contact_status".'),
			'segmentation_id' => $schema->string()
				->description('Contact segmentation. Resolve via lookup_options with type: "segmentation".'),
			'npwp'   => $schema->string()->description('Tax registration number (NPWP), max 16 characters.'),
			'no_ktp' => $schema->string()->description('National ID number (KTP), max 16 characters.'),
			'detail_noteworthy_events' => $schema->array()
				->items($schema->object($eventFields))
				->description('Notable dates or events to add to this contact, each linked automatically. Supports multiple. Optional.'),
			'detail_previous_companies' => $schema->array()
				->items($schema->object($companyFields))
				->description('Work history entries (previous companies) to add to this contact, each linked automatically. Supports multiple. Optional.'),
		]);
	}

	protected function lookupChecks(): array
	{
		return array_merge(parent::lookupChecks(), [
			AiColumn::lookup(column: 'status_id', label: 'contact status', modelKey: 'contact_status'),
			AiColumn::lookup(column: 'segmentation_id', label: 'segmentation', modelKey: 'segmentation'),
		]);
	}

	protected function rules(): array
	{
		return ContactRequest::createRules();
	}

	public function validateConfirmation(Request $request): array
	{
		$result = parent::validateConfirmation($request);

		if (isset($result['error'])) {
			return $result;
		}

		$contactId = $result['payload']['raw']['id'];

		[$events, $errors] = $this->validateDetailList(
			(array) ($request['detail_noteworthy_events'] ?? []),
			ContactNoteworthyEventRequest::createRules(),
			'contact_id',
			$contactId,
		);
		if (!empty($errors)) {
			return AiResponse::error(AiErrorCode::UserError,'One or more noteworthy events failed validation.', ['messages' => $errors]);
		}

		[$companies, $errors] = $this->validateDetailList(
			(array) ($request['detail_previous_companies'] ?? []),
			ContactPreviousCompanyRequest::createRules(),
			'contact_id',
			$contactId,
		);
		if (!empty($errors)) {
			return AiResponse::error(AiErrorCode::UserError,'One or more previous companies failed validation.', ['messages' => $errors]);
		}

		$result['payload']['raw']['detail_noteworthy_events']  = $events;
		$result['payload']['raw']['detail_previous_companies'] = $companies;

		if (!empty($events)) {
			$result['summary']['detail_noteworthy_events'] = count($events) . ' event(s)';
		}

		if (!empty($companies)) {
			$result['summary']['detail_previous_companies'] = count($companies) . ' previous company(ies)';
		}

		return $result;
	}

	protected function afterCreate(Model $record, array $raw): void
	{
		parent::afterCreate($record, $raw);

		$events = $raw['detail_noteworthy_events'] ?? [];
		if (!empty($events)) {
			$eventRepo = new (Helper::repository('contact_noteworthy_event'))(new (Helper::model('contact_noteworthy_event')));
			foreach ($events as $data) {
				$eventRepo->create($data);
			}
		}

		$companies = $raw['detail_previous_companies'] ?? [];
		if (!empty($companies)) {
			$companyRepo = new (Helper::repository('contact_previous_company'))(new (Helper::model('contact_previous_company')));
			foreach ($companies as $data) {
				$companyRepo->create($data);
			}
		}
	}
}
