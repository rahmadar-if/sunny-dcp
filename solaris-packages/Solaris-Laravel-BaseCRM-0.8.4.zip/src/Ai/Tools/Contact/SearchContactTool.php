<?php

namespace Solaris\BaseCRM\Ai\Tools\Contact;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\MasterData\Ai\Tools\Contact\SearchContactTool as BaseSearchContactTool;

class SearchContactTool extends BaseSearchContactTool
{
	protected function resourceLabel(): string
	{
		return parent::resourceLabel() . ' with CRM lifecycle tracking (status, segmentation)';
	}

	protected function fields(): array
	{
		return array_merge(parent::fields(), [
			'status_id' => AiSearchColumn::lookup(
				column: 'status_id',
				description: 'CRM lifecycle stage of the contact',
				modelKey: 'contact_status',
			),
			'segmentation_id' => AiSearchColumn::lookup(
				column: 'segmentation_id',
				description: 'Contact segmentation',
				modelKey: 'segmentation',
			),
			'npwp' => AiSearchColumn::string(
				column: 'npwp',
				description: 'Tax ID number',
				searchable: true,
			),
			'no_ktp' => AiSearchColumn::string(
				column: 'no_ktp',
				description: 'ID number',
				searchable: true,
			),
		]);
	}

	protected function formatRecord(Model $record): array
	{
		return array_merge(parent::formatRecord($record), [
			'status'       => $record->status?->name,
			'segmentation' => $record->segmentation?->name,
			'npwp'         => $record->npwp,
			'no_ktp'       => $record->no_ktp,
		]);
	}

	// contact_status_history has no relation method on the Contact model (auto-managed by
	// HasStageHistory), so it stays a standalone resource filterable by its own contact_id column
	// rather than a Contact relation-group.
	protected function relations(): array
	{
		return array_merge(parent::relations(), [
			'noteworthy_events'  => 'search_contact_noteworthy_event',
			'previous_companies' => 'search_contact_previous_company',
		]);
	}
}
