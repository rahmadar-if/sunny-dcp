<?php

namespace Solaris\BaseCRM\Ai\Tools\Contact;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Support\Arr;
use Laravel\Ai\Tools\Request;
use Solaris\BaseCRM\Ai\Tools\ContactNoteworthyEvent\CreateContactNoteworthyEventTool;
use Solaris\BaseCRM\Ai\Tools\ContactPreviousCompany\CreateContactPreviousCompanyTool;
use Solaris\BaseCRM\Http\Requests\ContactNoteworthyEventRequest;
use Solaris\BaseCRM\Http\Requests\ContactPreviousCompanyRequest;
use Solaris\BaseCRM\Http\Requests\ContactRequest;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Ai\Tools\Contact\UpdateContactTool as BaseUpdateContactTool;

class UpdateContactTool extends BaseUpdateContactTool
{
	public static function slug(): string
	{
		return 'update_contact';
	}

	public static function fields(JsonSchema $schema): array
	{
		$eventFields   = Arr::except(CreateContactNoteworthyEventTool::fields($schema), ['contact_id']);
		$companyFields = Arr::except(CreateContactPreviousCompanyTool::fields($schema), ['contact_id']);

		$detailMeta = [
			'id'     => $schema->string()->description('Existing record id. Omit to create a new one.'),
			'delete' => $schema->boolean()->description('Set true (with id) to remove this record instead of updating it.'),
		];

		return array_merge(parent::fields($schema), [
			'status_id' => $schema->string()
				->description('New CRM contact status. Resolve via lookup_options with type: "contact_status".'),
			'segmentation_id' => $schema->string()
				->description('New contact segmentation. Resolve via lookup_options with type: "segmentation".'),
			'npwp'   => $schema->string()->description('New tax registration number (NPWP), max 16 characters.'),
			'no_ktp' => $schema->string()->description('New national ID number (KTP), max 16 characters.'),
			'detail_noteworthy_events' => $schema->array()
				->items($schema->object(array_merge($detailMeta, $eventFields)))
				->description(
					'Manage noteworthy events — omit id to add a new one, pass id with fields to update an existing one, '
						. 'pass id with delete:true to remove one. Supports multiple. Optional.'
				),
			'detail_previous_companies' => $schema->array()
				->items($schema->object(array_merge($detailMeta, $companyFields)))
				->description(
					'Manage previous company records — omit id to add a new one, pass id with fields to update an existing one, '
						. 'pass id with delete:true to remove one. Supports multiple. Optional.'
				),
		]);
	}

	protected function lookupChecks(): array
	{
		return array_merge(parent::lookupChecks(), [
			AiColumn::lookup(column: 'status_id', label: 'contact status', modelKey: 'contact_status'),
			AiColumn::lookup(column: 'segmentation_id', label: 'segmentation', modelKey: 'segmentation'),
		]);
	}

	protected function rules(): array
	{
		return ContactRequest::updateRules();
	}

	protected function currentData(mixed $record): array
	{
		return array_merge(parent::currentData($record), [
			'status_id'       => $record->status_id,
			'segmentation_id' => $record->segmentation_id,
			'npwp'            => $record->npwp,
			'no_ktp'          => $record->no_ktp,
		]);
	}

	public function validateConfirmation(Request $request): array
	{
		$result = parent::validateConfirmation($request);

		if (isset($result['error'])) {
			return $result;
		}

		$contactId = trim((string) ($request['id'] ?? ''));

		[$events, $eventErrors] = $this->resolveDetailOperations(
			(array) ($request['detail_noteworthy_events'] ?? []),
			Helper::model('contact_noteworthy_event'),
			ContactNoteworthyEventRequest::createRules(),
			ContactNoteworthyEventRequest::updateRules(),
			'contact_id',
			$contactId,
		);
		if (!empty($eventErrors)) {
			return AiResponse::error(AiErrorCode::UserError,'One or more noteworthy events failed validation.', ['messages' => $eventErrors]);
		}

		[$companies, $companyErrors] = $this->resolveDetailOperations(
			(array) ($request['detail_previous_companies'] ?? []),
			Helper::model('contact_previous_company'),
			ContactPreviousCompanyRequest::createRules(),
			ContactPreviousCompanyRequest::updateRules(),
			'contact_id',
			$contactId,
		);
		if (!empty($companyErrors)) {
			return AiResponse::error(AiErrorCode::UserError,'One or more previous companies failed validation.', ['messages' => $companyErrors]);
		}

		$result['payload']['changes']['detail_noteworthy_events']  = $events;
		$result['payload']['changes']['detail_previous_companies'] = $companies;

		foreach ([
			'detail_noteworthy_events'  => $events,
			'detail_previous_companies' => $companies,
		] as $key => $ops) {
			if (!empty($ops['create']) || !empty($ops['update']) || !empty($ops['delete'])) {
				$result['summary'][$key] = [
					'add'    => count($ops['create']),
					'update' => count($ops['update']),
					'delete' => count($ops['delete']),
				];
			}
		}

		return $result;
	}

	protected function excludedChangeKeys(): array
	{
		return [...parent::excludedChangeKeys(), 'detail_noteworthy_events', 'detail_previous_companies'];
	}

	protected function afterUpdate(mixed $record, array $changes): void
	{
		parent::afterUpdate($record, $changes);

		$eventOps = $changes['detail_noteworthy_events'] ?? ['create' => [], 'update' => [], 'delete' => []];
		if (!empty($eventOps['create']) || !empty($eventOps['update']) || !empty($eventOps['delete'])) {
			$eventRepo = new (Helper::repository('contact_noteworthy_event'))(new (Helper::model('contact_noteworthy_event')));

			foreach ($eventOps['create'] as $data) {
				$eventRepo->create($data);
			}

			foreach ($eventOps['update'] as $id => $data) {
				$eventRepo->update($id, $data);
			}

			foreach ($eventOps['delete'] as $id) {
				$eventRepo->delete($id);
			}
		}

		$companyOps = $changes['detail_previous_companies'] ?? ['create' => [], 'update' => [], 'delete' => []];
		if (!empty($companyOps['create']) || !empty($companyOps['update']) || !empty($companyOps['delete'])) {
			$companyRepo = new (Helper::repository('contact_previous_company'))(new (Helper::model('contact_previous_company')));

			foreach ($companyOps['create'] as $data) {
				$companyRepo->create($data);
			}

			foreach ($companyOps['update'] as $id => $data) {
				$companyRepo->update($id, $data);
			}

			foreach ($companyOps['delete'] as $id) {
				$companyRepo->delete($id);
			}
		}
	}
}
