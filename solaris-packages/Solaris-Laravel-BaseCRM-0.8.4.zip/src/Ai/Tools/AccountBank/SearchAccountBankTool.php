<?php

namespace Solaris\BaseCRM\Ai\Tools\AccountBank;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

class SearchAccountBankTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_account_bank';
	}

	protected function resourceLabel(): string
	{
		return 'account bank details — bank accounts registered under an account';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('account_bank'))();
	}

	protected function fields(): array
	{
		return [
			'account_id' => AiSearchColumn::reference(
				column: 'account_id',
				description: 'The account id this bank detail belongs to. Obtain it with the account search tool available to you first.',
				modelKey: 'account',
			),
			'bank_name' => AiSearchColumn::string(
				column: 'bank_name',
				description: 'Name of the bank',
				searchable: true,
			),
			'account_name' => AiSearchColumn::string(
				column: 'account_name',
				description: 'Name on the bank account',
				searchable: true,
			),
			'account_number' => AiSearchColumn::string(
				column: 'account_number',
				description: 'Bank account number',
				searchable: true,
			),
			'country_id' => AiSearchColumn::reference(
				column: 'country_id',
				description: 'Country id of the bank, from lookup_region',
				modelKey: 'country',
			),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'            => $record->id,
			'_account_id'    => $record->account_id,
			'bank_name'      => $record->bank_name,
			'account_name'   => $record->account_name,
			'account_number' => $record->account_number,
			'country'        => $record->country?->name,
		];
	}
}
