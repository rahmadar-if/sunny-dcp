<?php

namespace Solaris\BaseCRM\Ai\Tools\AccountBank;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\BaseCRM\Http\Requests\AccountBankRequest;
use Solaris\BaseCRM\Models\AccountBank;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseUpdateAiTool;
use Solaris\Core\Helpers\Helper;

class UpdateAccountBankTool extends BaseUpdateAiTool
{
	public static function slug(): string
	{
		return 'update_account_bank';
	}

	protected function resourceLabel(): string
	{
		return 'account bank';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'id' => $schema->string()
				->description('The account bank id. Required.')
				->required(),
			'bank_name'      => $schema->string()->description('New bank name.'),
			'account_name'   => $schema->string()->description('New name on the bank account.'),
			'account_number' => $schema->string()->description('New bank account number.'),
			'country_id'     => $schema->string()->description('New country id from lookup_region.'),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::reference(column: 'country_id', label: 'country', modelKey: 'country'),
		];
	}

	protected function rules(): array
	{
		return AccountBankRequest::updateRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/update-account-bank" with no other text, ask which bank account and what to change. '
			. 'If the user sends "/update-account-bank" followed by a description of the changes, '
			. 'extract the fields directly and proceed to confirmation.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to edit or update a bank account, first locate it via '
			. 'the account bank search tool if the id is not already known, then confirm the changes before calling this tool.';
	}

	protected function findRecordById(string $id): ?AccountBank
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('account_bank'))(new (Helper::model('account_bank')));

		return $repo->find($id);
	}

	protected function currentData(mixed $record): array
	{
		return [
			'bank_name'      => $record->bank_name,
			'account_name'   => $record->account_name,
			'account_number' => $record->account_number,
			'country_id'     => $record->country_id,
		];
	}

	protected function update(mixed $record, array $validated, array $changes): array
	{
		$repo = new (Helper::repository('account_bank'))(new (Helper::model('account_bank')));
		$repo->update($record->id, $validated,
			before: fn ($record, $data) => $this->beforeUpdate($record, $data, $changes),
			after:  fn ($record)        => $this->afterUpdate($record, $changes),
		);

		return AiResponse::success(
			['id' => $record->id, 'updated' => array_keys($changes)],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
