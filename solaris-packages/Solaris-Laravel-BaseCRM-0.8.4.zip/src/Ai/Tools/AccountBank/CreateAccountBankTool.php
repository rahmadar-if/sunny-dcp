<?php

namespace Solaris\BaseCRM\Ai\Tools\AccountBank;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\BaseCRM\Http\Requests\AccountBankRequest;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseCreateAiTool;
use Solaris\Core\Helpers\Helper;

class CreateAccountBankTool extends BaseCreateAiTool
{
	public static function slug(): string
	{
		return 'create_account_bank';
	}

	protected function resourceLabel(): string
	{
		return 'account bank';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'account_id' => $schema->string()
				->description('The account id this bank detail belongs to. Obtain it with the account search tool available to you first.')
				->required(),
			'bank_name' => $schema->string()
				->description('Name of the bank.')
				->required(),
			'account_name' => $schema->string()
				->description('Name on the bank account.')
				->required(),
			'account_number' => $schema->string()
				->description('Bank account number.')
				->required(),
			'country_id' => $schema->string()->description('Country id from lookup_region. Optional.'),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::reference(column: 'account_id', label: 'account', modelKey: 'account'),
			AiColumn::reference(column: 'country_id', label: 'country', modelKey: 'country'),
		];
	}

	protected function rules(): array
	{
		return AccountBankRequest::createRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/add-account-bank" with no other text, ask which account and for the bank details. '
			. 'If the user sends "/add-account-bank" followed by the details, extract the fields directly and proceed to confirmation.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to add a bank account to an account, first locate the account via '
			. 'the account search tool if the id is not already known, then confirm the bank details before calling this tool.';
	}

	protected function create(array $validated, array $raw): array
	{
		$repo = new (Helper::repository('account_bank'))(new (Helper::model('account_bank')));
		$bank = $repo->create($validated,
			before: fn ($data)   => $this->beforeCreate($data, $raw),
			after:  fn ($record) => $this->afterCreate($record, $raw),
		);

		return AiResponse::success(
			['id' => $bank->id, 'bank_name' => $bank->bank_name, 'account_number' => $bank->account_number],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
