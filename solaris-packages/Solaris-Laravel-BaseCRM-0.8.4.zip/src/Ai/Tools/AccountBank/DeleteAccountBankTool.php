<?php

namespace Solaris\BaseCRM\Ai\Tools\AccountBank;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseDeleteAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\BaseCRM\Models\AccountBank;

class DeleteAccountBankTool extends BaseDeleteAiTool
{
	public static function slug(): string
	{
		return 'delete_account_bank';
	}

	protected function resourceLabel(): string
	{
		return 'account bank';
	}

	protected function findRecordById(string $id): ?AccountBank
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('account_bank'))(new (Helper::model('account_bank')));

		return $repo->find($id);
	}

	protected function delete(Model $record): array
	{
		$repo = new (Helper::repository('account_bank'))(new (Helper::model('account_bank')));
		$repo->delete($record->id);

		return AiResponse::success(
			['deleted' => $record->bank_name . ' (' . $record->account_number . ')'],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
