<?php

namespace Solaris\BaseCRM\Ai\Tools\ContactStatusHistory;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

class SearchContactStatusHistoryTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_contact_status_history';
	}

	protected function resourceLabel(): string
	{
		return 'contact status history — history of CRM lifecycle stage changes for a contact';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('contact_status_history'))();
	}

	protected function fields(): array
	{
		return [
			'contact_id' => AiSearchColumn::reference(
				column: 'contact_id',
				description: 'The contact id this status history belongs to. Obtain it with the contact search tool available to you first.',
				modelKey: 'contact',
			),
			'status_id' => AiSearchColumn::lookup(
				column: 'status_id',
				description: 'CRM lifecycle stage held during this period',
				modelKey: 'contact_status',
			),
			'position' => AiSearchColumn::number(
				column: 'position',
				description: 'Sequence order of this stage within the contact\'s history, starting at 1',
			),
			'start' => AiSearchColumn::datetime('start', 'Date and time this stage started'),
			'end'   => AiSearchColumn::datetime('end', 'Date and time this stage ended (empty means still current)'),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'         => $record->id,
			'_contact_id' => $record->contact_id,
			'status'      => $record->status?->name,
			'position'    => $record->position,
			'start'       => $record->start ? Carbon::parse($record->start)->format('d M Y H:i') : null,
			'end'         => $record->end ? Carbon::parse($record->end)->format('d M Y H:i') : null,
		];
	}
}
