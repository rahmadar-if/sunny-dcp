<?php

namespace Solaris\BaseCRM\Ai\Tools\ContactPreviousCompany;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\BaseCRM\Http\Requests\ContactPreviousCompanyRequest;
use Solaris\BaseCRM\Models\ContactPreviousCompany;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseUpdateAiTool;
use Solaris\Core\Helpers\Helper;

class UpdateContactPreviousCompanyTool extends BaseUpdateAiTool
{
	public static function slug(): string
	{
		return 'update_contact_previous_company';
	}

	protected function resourceLabel(): string
	{
		return 'contact previous company';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'id' => $schema->string()
				->description('The previous company record id. Required.')
				->required(),
			'account_id' => $schema->string()
				->description('New company/account id. Obtain it with the account search tool available to you first.'),
			'active' => $schema->boolean()
				->description('Whether this affiliation is currently active.'),
			'role' => $schema->string()
				->description('New role or position.'),
			'start_date' => $schema->string()
				->description('New start date in Y-m-d format.'),
			'end_date' => $schema->string()
				->description('New end date in Y-m-d format.'),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::reference(column: 'account_id', label: 'company/account', modelKey: 'account'),
		];
	}

	protected function rules(): array
	{
		return ContactPreviousCompanyRequest::updateRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'NATURAL LANGUAGE: If the user asks to update a work history entry, first locate it via '
			. 'the contact previous company search tool if the id is not already known, '
			. 'then confirm the changes before calling this tool.';
	}

	protected function findRecordById(string $id): ?ContactPreviousCompany
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('contact_previous_company'))(new (Helper::model('contact_previous_company')));

		return $repo->find($id);
	}

	protected function currentData(mixed $record): array
	{
		return [
			'account_id' => $record->account_id,
			'active'     => $record->active,
			'role'       => $record->role,
			'start_date' => $record->start_date?->format('Y-m-d'),
			'end_date'   => $record->end_date?->format('Y-m-d'),
		];
	}

	protected function update(mixed $record, array $validated, array $changes): array
	{
		$repo = new (Helper::repository('contact_previous_company'))(new (Helper::model('contact_previous_company')));
		$repo->update($record->id, $validated,
			before: fn ($record, $data) => $this->beforeUpdate($record, $data, $changes),
			after:  fn ($record)        => $this->afterUpdate($record, $changes),
		);

		return AiResponse::success(
			['id' => $record->id, 'updated' => array_keys($changes)],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
