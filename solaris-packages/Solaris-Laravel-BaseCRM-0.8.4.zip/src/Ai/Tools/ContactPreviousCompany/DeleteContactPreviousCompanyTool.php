<?php

namespace Solaris\BaseCRM\Ai\Tools\ContactPreviousCompany;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseDeleteAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\BaseCRM\Models\ContactPreviousCompany;

class DeleteContactPreviousCompanyTool extends BaseDeleteAiTool
{
	public static function slug(): string
	{
		return 'delete_contact_previous_company';
	}

	protected function resourceLabel(): string
	{
		return 'contact previous company';
	}

	protected function findRecordById(string $id): ?ContactPreviousCompany
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('contact_previous_company'))(new (Helper::model('contact_previous_company')));

		return $repo->find($id);
	}

	protected function delete(Model $record): array
	{
		$repo = new (Helper::repository('contact_previous_company'))(new (Helper::model('contact_previous_company')));
		$repo->delete($record->id);

		return AiResponse::success(
			['deleted' => ($record->account?->name ?? 'company') . ' — ' . ($record->role ?? 'no role')],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
