<?php

namespace Solaris\BaseCRM\Ai\Tools\ContactPreviousCompany;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\BaseCRM\Http\Requests\ContactPreviousCompanyRequest;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseCreateAiTool;
use Solaris\Core\Helpers\Helper;

class CreateContactPreviousCompanyTool extends BaseCreateAiTool
{
	public static function slug(): string
	{
		return 'create_contact_previous_company';
	}

	protected function resourceLabel(): string
	{
		return 'contact previous company';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'contact_id' => $schema->string()
				->description('The contact id to add this work history entry to. Obtain it with the contact search tool available to you first.')
				->required(),
			'account_id' => $schema->string()
				->description('The company/account id. Obtain it with the account search tool available to you first.')
				->required(),
			'active' => $schema->boolean()
				->description('Whether this affiliation is currently active.'),
			'role' => $schema->string()
				->description('Role or position held at the company.'),
			'start_date' => $schema->string()
				->description('Start date in Y-m-d format.'),
			'end_date' => $schema->string()
				->description('End date in Y-m-d format. Omit if currently active.'),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::reference(column: 'contact_id', label: 'contact', modelKey: 'contact'),
			AiColumn::reference(column: 'account_id', label: 'company/account', modelKey: 'account'),
		];
	}

	protected function rules(): array
	{
		return ContactPreviousCompanyRequest::createRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'NATURAL LANGUAGE: If the user asks to add a previous company or work history to a contact, '
			. 'first locate both the contact and company with the contact search tool available to you and the account search tool if ids are not already known, '
			. 'then confirm the details before calling this tool.';
	}

	protected function create(array $validated, array $raw): array
	{
		$repo   = new (Helper::repository('contact_previous_company'))(new (Helper::model('contact_previous_company')));
		$record = $repo->create($validated,
			before: fn ($data)   => $this->beforeCreate($data, $raw),
			after:  fn ($record) => $this->afterCreate($record, $raw),
		);

		return AiResponse::success(
			['id' => $record->id, 'account' => $record->account?->name, 'role' => $record->role],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
