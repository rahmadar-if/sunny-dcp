<?php

namespace Solaris\BaseCRM\Ai\Tools\ContactPreviousCompany;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

class SearchContactPreviousCompanyTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_contact_previous_company';
	}

	protected function resourceLabel(): string
	{
		return 'contact previous companies — work history records of companies/accounts a contact was previously (or currently) affiliated with';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('contact_previous_company'))();
	}

	protected function fields(): array
	{
		return [
			'contact_id' => AiSearchColumn::reference(
				column: 'contact_id',
				description: 'The contact id this record belongs to. Obtain it with the contact search tool available to you first.',
				modelKey: 'contact',
			),
			'account_id' => AiSearchColumn::reference(
				column: 'account_id',
				description: 'The company/account id the contact was affiliated with. Obtain it with the account search tool available to you first.',
				modelKey: 'account',
			),
			'active' => AiSearchColumn::boolean('active', 'Whether this affiliation is currently active'),
			'role' => AiSearchColumn::string(
				column: 'role',
				description: 'Role or position held at the company',
				searchable: true,
			),
			'start_date' => AiSearchColumn::date('start_date', 'Date the affiliation started'),
			'end_date'   => AiSearchColumn::date('end_date', 'Date the affiliation ended'),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'         => $record->id,
			'_contact_id' => $record->contact_id,
			'_account_id' => $record->account_id,
			'account'     => $record->account?->name,
			'role'        => $record->role,
			'active'      => $record->active,
			'start_date'  => $record->start_date ? Carbon::parse($record->start_date)->format('d M Y') : null,
			'end_date'    => $record->end_date ? Carbon::parse($record->end_date)->format('d M Y') : null,
		];
	}
}
