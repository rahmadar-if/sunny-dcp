<?php

namespace Solaris\BaseCRM\Ai\Tools\Activity;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\MasterData\Ai\Tools\Activity\SearchActivityTool as BaseSearchActivityTool;

class SearchActivityTool extends BaseSearchActivityTool
{
	protected function resourceLabel(): string
	{
		return parent::resourceLabel() . ', with CRM result tracking, lead linkage, participants, and promoted products';
	}

	protected function fields(): array
	{
		return array_merge(parent::fields(), [
			'result_id' => AiSearchColumn::lookup(
				column: 'result_id',
				description: 'Result/outcome of the activity',
				modelKey: 'activity_result',
			),
			'lead_id' => AiSearchColumn::reference(
				column: 'lead_id',
				description: 'The lead id this activity relates to. Obtain it with the lead search tool available to you first.',
				modelKey: 'lead',
			),
			'detail_result' => AiSearchColumn::string(
				column: 'detail_result',
				description: 'Detailed result/outcome notes of the activity',
				searchable: true,
			),
		]);
	}

	protected function formatRecord(Model $record): array
	{
		return array_merge(parent::formatRecord($record), [
			'result'        => $record->result?->name,
			'lead'          => $record->lead?->name,
			'detail_result' => $record->detail_result,
		]);
	}

	protected function relations(): array
	{
		return array_merge(parent::relations(), [
			'participants'      => 'search_activity_participant',
			'promoted_products' => 'search_activity_promoted_product',
		]);
	}
}
