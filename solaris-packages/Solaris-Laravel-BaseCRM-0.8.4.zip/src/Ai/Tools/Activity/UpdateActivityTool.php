<?php

namespace Solaris\BaseCRM\Ai\Tools\Activity;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Support\Arr;
use Laravel\Ai\Tools\Request;
use Solaris\BaseCRM\Ai\Tools\ActivityParticipant\CreateActivityParticipantTool;
use Solaris\BaseCRM\Ai\Tools\ActivityPromotedProduct\CreateActivityPromotedProductTool;
use Solaris\BaseCRM\Http\Requests\ActivityParticipantRequest;
use Solaris\BaseCRM\Http\Requests\ActivityPromotedProductRequest;
use Solaris\BaseCRM\Http\Requests\ActivityRequest;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Ai\Tools\Activity\UpdateActivityTool as BaseUpdateActivityTool;

class UpdateActivityTool extends BaseUpdateActivityTool
{
	public static function fields(JsonSchema $schema): array
	{
		$participantFields = Arr::except(CreateActivityParticipantTool::fields($schema), ['activity_id']);
		$productFields     = Arr::except(CreateActivityPromotedProductTool::fields($schema), ['activity_id']);

		$detailMeta = [
			'id'     => $schema->string()->description('Existing record id. Omit to create a new one.'),
			'delete' => $schema->boolean()->description('Set true (with id) to remove this record instead of updating it.'),
		];

		return array_merge(parent::fields($schema), [
			'lead_id' => $schema->string()
				->description('Lead associated with this activity. Obtain it with the lead search tool available to you first.'),
			'result_id' => $schema->string()
				->description('Activity outcome/result. Resolve via lookup_options with type: "activity_result".'),
			'detail_result' => $schema->string()
				->description('Detailed description of the activity result.'),
			'detail_participants' => $schema->array()
				->items($schema->object(array_merge($detailMeta, $participantFields)))
				->description(
					'Manage participants — omit id to add a new one, pass id with fields to update an existing one, '
						. 'pass id with delete:true to remove one. Supports multiple. Optional.'
				),
			'detail_promoted_products' => $schema->array()
				->items($schema->object(array_merge($detailMeta, $productFields)))
				->description(
					'Manage promoted products — omit id to add a new one, pass id with fields to update an existing one, '
						. 'pass id with delete:true to remove one. Supports multiple. Optional.'
				),
		]);
	}

	protected function lookupChecks(): array
	{
		return array_merge(parent::lookupChecks(), [
			AiColumn::reference(column: 'lead_id', label: 'lead', modelKey: 'lead'),
			AiColumn::lookup(column: 'result_id', label: 'activity result', modelKey: 'activity_result'),
		]);
	}

	protected function rules(): array
	{
		$rules = ActivityRequest::updateRules();

		unset(
			$rules['reminder_types'],
			$rules['reminder_types.*.id'],
			$rules['reminder_types.*.checked'],
			$rules['remind_to'],
		);

		return array_merge($rules, [
			'reminder_type_ids'   => 'nullable|array',
			'reminder_type_ids.*' => 'uuid',
		]);
	}

	protected function currentData(mixed $record): array
	{
		return array_merge(parent::currentData($record), [
			'lead_id'       => $record->lead_id,
			'result_id'     => $record->result_id,
			'detail_result' => $record->detail_result,
		]);
	}

	public function validateConfirmation(Request $request): array
	{
		$result = parent::validateConfirmation($request);

		if (isset($result['error'])) {
			return $result;
		}

		$activityId = trim((string) ($request['id'] ?? ''));

		[$participants, $participantErrors] = $this->resolveDetailOperations(
			(array) ($request['detail_participants'] ?? []),
			Helper::model('activity_participant'),
			ActivityParticipantRequest::createRules(),
			ActivityParticipantRequest::updateRules(),
			'activity_id',
			$activityId,
		);
		if (!empty($participantErrors)) {
			return AiResponse::error(AiErrorCode::UserError,'One or more participants failed validation.', ['messages' => $participantErrors]);
		}

		[$products, $productErrors] = $this->resolveDetailOperations(
			(array) ($request['detail_promoted_products'] ?? []),
			Helper::model('activity_promoted_product'),
			ActivityPromotedProductRequest::createRules(),
			ActivityPromotedProductRequest::updateRules(),
			'activity_id',
			$activityId,
		);
		if (!empty($productErrors)) {
			return AiResponse::error(AiErrorCode::UserError,'One or more promoted products failed validation.', ['messages' => $productErrors]);
		}

		$result['payload']['changes']['detail_participants']      = $participants;
		$result['payload']['changes']['detail_promoted_products'] = $products;

		foreach ([
			'detail_participants'      => $participants,
			'detail_promoted_products' => $products,
		] as $key => $ops) {
			if (!empty($ops['create']) || !empty($ops['update']) || !empty($ops['delete'])) {
				$result['summary'][$key] = [
					'add'    => count($ops['create']),
					'update' => count($ops['update']),
					'delete' => count($ops['delete']),
				];
			}
		}

		return $result;
	}

	protected function excludedChangeKeys(): array
	{
		return [...parent::excludedChangeKeys(), 'detail_participants', 'detail_promoted_products'];
	}

	protected function afterUpdate(mixed $record, array $changes): void
	{
		parent::afterUpdate($record, $changes);

		$participantOps = $changes['detail_participants'] ?? ['create' => [], 'update' => [], 'delete' => []];
		if (!empty($participantOps['create']) || !empty($participantOps['update']) || !empty($participantOps['delete'])) {
			$participantRepo = new (Helper::repository('activity_participant'))(new (Helper::model('activity_participant')));

			foreach ($participantOps['create'] as $data) {
				$participantRepo->create($data);
			}

			foreach ($participantOps['update'] as $id => $data) {
				$participantRepo->update($id, $data);
			}

			foreach ($participantOps['delete'] as $id) {
				$participantRepo->delete($id);
			}
		}

		$productOps = $changes['detail_promoted_products'] ?? ['create' => [], 'update' => [], 'delete' => []];
		if (!empty($productOps['create']) || !empty($productOps['update']) || !empty($productOps['delete'])) {
			$productRepo = new (Helper::repository('activity_promoted_product'))(new (Helper::model('activity_promoted_product')));

			foreach ($productOps['create'] as $data) {
				$productRepo->create($data);
			}

			foreach ($productOps['update'] as $id => $data) {
				$productRepo->update($id, $data);
			}

			foreach ($productOps['delete'] as $id) {
				$productRepo->delete($id);
			}
		}
	}
}
