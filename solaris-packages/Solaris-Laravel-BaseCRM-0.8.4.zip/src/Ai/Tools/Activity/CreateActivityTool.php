<?php

namespace Solaris\BaseCRM\Ai\Tools\Activity;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Arr;
use Illuminate\Support\Str;
use Laravel\Ai\Tools\Request;
use Solaris\BaseCRM\Ai\Tools\ActivityParticipant\CreateActivityParticipantTool;
use Solaris\BaseCRM\Ai\Tools\ActivityPromotedProduct\CreateActivityPromotedProductTool;
use Solaris\BaseCRM\Http\Requests\ActivityParticipantRequest;
use Solaris\BaseCRM\Http\Requests\ActivityPromotedProductRequest;
use Solaris\BaseCRM\Http\Requests\ActivityRequest;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Ai\Tools\Activity\CreateActivityTool as BaseCreateActivityTool;

class CreateActivityTool extends BaseCreateActivityTool
{
	public static function fields(JsonSchema $schema): array
	{
		$participantFields = Arr::except(CreateActivityParticipantTool::fields($schema), ['activity_id']);
		$productFields     = Arr::except(CreateActivityPromotedProductTool::fields($schema), ['activity_id']);

		return array_merge(parent::fields($schema), [
			'lead_id' => $schema->string()
				->description('Lead associated with this activity. Obtain it with the lead search tool available to you first. Optional.'),
			'detail_participants' => $schema->array()
				->items($schema->object($participantFields))
				->description('Participants to add to this activity, each linked automatically. Supports multiple. Optional.'),
			'detail_promoted_products' => $schema->array()
				->items($schema->object($productFields))
				->description('Products to promote in this activity, each linked automatically. Supports multiple. Optional.'),
		]);
	}

	protected function lookupChecks(): array
	{
		return array_merge(parent::lookupChecks(), [
			AiColumn::reference(column: 'lead_id', label: 'lead', modelKey: 'lead'),
		]);
	}

	protected function rules(): array
	{
		$rules = ActivityRequest::createRules();

		unset(
			$rules['reminder_types'],
			$rules['reminder_types.*.id'],
			$rules['reminder_types.*.checked'],
			$rules['remind_to'],
		);

		return array_merge($rules, [
			'reminder_type_ids'   => 'nullable|array',
			'reminder_type_ids.*' => 'uuid',
		]);
	}

	public function validateConfirmation(Request $request): array
	{
		$result = parent::validateConfirmation($request);

		if (isset($result['error'])) {
			return $result;
		}

		$activityId = (string) Str::uuid7();

		[$participants, $errors] = $this->validateDetailList(
			(array) ($request['detail_participants'] ?? []),
			ActivityParticipantRequest::createRules(),
			'activity_id',
			$activityId,
		);
		if (!empty($errors)) {
			return AiResponse::error(AiErrorCode::UserError,'One or more participants failed validation.', ['messages' => $errors]);
		}

		[$products, $errors] = $this->validateDetailList(
			(array) ($request['detail_promoted_products'] ?? []),
			ActivityPromotedProductRequest::createRules(),
			'activity_id',
			$activityId,
		);
		if (!empty($errors)) {
			return AiResponse::error(AiErrorCode::UserError,'One or more promoted products failed validation.', ['messages' => $errors]);
		}

		$result['payload']['raw']['id']                        = $activityId;
		$result['payload']['raw']['detail_participants']       = $participants;
		$result['payload']['raw']['detail_promoted_products']  = $products;

		if (!empty($participants)) {
			$result['summary']['detail_participants'] = array_map(fn ($p) => $p['name'], $participants);
		}

		if (!empty($products)) {
			$result['summary']['detail_promoted_products'] = count($products) . ' product(s)';
		}

		return $result;
	}

	protected function beforeCreate(array $data, array $raw): array
	{
		$data = parent::beforeCreate($data, $raw);
		$data['id'] = $raw['id'];
		return $data;
	}

	protected function afterCreate(Model $record, array $raw): void
	{
		parent::afterCreate($record, $raw);

		$participants = $raw['detail_participants'] ?? [];
		if (!empty($participants)) {
			$participantRepo = new (Helper::repository('activity_participant'))(new (Helper::model('activity_participant')));
			foreach ($participants as $data) {
				$participantRepo->create($data);
			}
		}

		$products = $raw['detail_promoted_products'] ?? [];
		if (!empty($products)) {
			$productRepo = new (Helper::repository('activity_promoted_product'))(new (Helper::model('activity_promoted_product')));
			foreach ($products as $data) {
				$productRepo->create($data);
			}
		}
	}
}
