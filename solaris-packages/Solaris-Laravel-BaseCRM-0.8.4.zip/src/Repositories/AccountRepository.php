<?php

namespace Solaris\BaseCRM\Repositories;

use Solaris\BaseCRM\Models\Account;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Repositories\AccountRepository as BaseAccountRepository;

class AccountRepository extends BaseAccountRepository
{
	public function __construct(Account $model, bool $transaction = true)
	{
		parent::__construct($model, $transaction);
	}

	public function findComplete(string $id, array $columns = []): Account
	{
		$data = parent::findComplete($id, $columns);

		$data->total_lead = Helper::model('lead')::where('account_id', $id)->count();

		return $data;
	}
}
