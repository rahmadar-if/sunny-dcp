<?php

namespace Solaris\BaseCRM\Repositories;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Solaris\BaseCRM\Const\LeadStatusConst;
use Solaris\BaseCRM\Models\Lead;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Interfaces\Model\SolarisModel;
use Solaris\Core\Models\Attachment;
use Solaris\Core\Repositories\AttachmentRepository;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\MasterData\Const\ActivityCategoryConst;
use Solaris\MasterData\Const\ActivityPriorityConst;
use Solaris\MasterData\Const\ReminderTypeConst;
use Solaris\MasterData\Repositories\ActivityRepository;

class LeadRepository extends BaseRepository
{
    public function __construct(Lead $model, bool $transaction = true)
    {
        parent::__construct($model, $transaction);
    }

    public function findComplete(string $id, array $columns = []): Lead
    {
        $data = $this->model
            ->prepared(array_merge(static::defaultColumns(), $columns))
            ->where('id', $id)
            ->first();

        return $data;
    }

    public function creating(array $data): array
    {
        if (empty($data['status_id'])) {
            $data['status_id'] = LeadStatusConst::New;
        }

        return $data;
    }

    protected function updating(Model|SolarisModel $record, array $data): array
    {
        if (empty($data['follow_up_remind_at'])) {
            $data['follow_up_remind_at']   = null;
            $data['is_follow_up_reminded'] = false;
        } elseif ($record->follow_up_remind_at?->utc()->format('Y-m-d H:i:s') !== $data['follow_up_remind_at']) {
            $data['is_follow_up_reminded'] = false;
        }

        return [$record, $data];
    }

    protected function updated(Model|SolarisModel $record, array $data, array $rawData): void
    {
        if ($record->wasChanged('add_to_calendar') && $record->add_to_calendar) {
            $this->createFollowUpActivity($record);
        }
    }

    protected function batchDeleted(array $ids): void
    {
        $table          = $this->getModel()->getTable();
        $attachmentRepo = new AttachmentRepository(new Attachment());

        $attachmentRepo->batchDelete(
            user  : null,
            model : $attachmentRepo->getModel()
                ->query()
                ->where('table_name', $table)
                ->whereIn('record_id', $ids)
        );
    }

    private function createFollowUpActivity(Lead $record): void
    {
        $user      = Auth::user();
        $timezone  = $user->profile->timezone ?? 'UTC';
        $hasRemind = !is_null($record->follow_up_remind_at);

        if ($hasRemind) {
            $startDate = $record->follow_up_remind_at;
        } else {
            $startDate = Carbon::parse($record->follow_up_date->format('Y-m-d') . ' 09:00:00', $timezone)->utc();
        }

        ActivityRepository::store([
            'lead_id'     => $record->id,
            'subject'     => 'Follow up ' . $record->name,
            'start_date'  => $startDate->format('Y-m-d H:i:s'),
            'priority_id' => ActivityPriorityConst::Medium,
            'category_id' => ActivityCategoryConst::ToDo,
            'account_id'  => $record->account_id,
            'contact_id'  => $record->contact_id,
        ], $hasRemind ? [ReminderTypeConst::StartEvent] : []);
    }

    /**
     * Point the lead at an existing account and copy the fields it keeps its own copy of.
     *
     * The copies are why this cannot be a plain update of account_id: leave them behind and the
     * lead keeps reporting the previous company's industry and size. Lives here rather than in a
     * controller so the web, mobile and API routes all copy the same set.
     */
    public function linkAccount(string $leadId, ?string $accountId): void
    {
        $account = $accountId
            ? Helper::model('account')::select('name', 'industry_id', 'segmentation_id', 'business_size_id', 'number_of_employee_id', 'annual_revenue_id')
                ->firstWhere('id', $accountId)
            : null;

        $this->model->where('id', $leadId)->update([
            'account_id'            => $accountId,
            'account_name'          => $account?->name,
            'industry_id'           => $account?->industry_id,
            'segmentation_id'       => $account?->segmentation_id,
            'business_size_id'      => $account?->business_size_id,
            'number_of_employee_id' => $account?->number_of_employee_id,
            'annual_revenue_id'     => $account?->annual_revenue_id,
        ]);
    }

    public function linkContact(string $leadId, ?string $contactId): void
    {
        $contact = $contactId
            ? Helper::model('contact')::select('name', 'job_title')->firstWhere('id', $contactId)
            : null;

        $this->model->where('id', $leadId)->update([
            'contact_id'        => $contactId,
            'contact_name'      => $contact?->name,
            'contact_job_title' => $contact?->job_title,
        ]);
    }

    public function createAccount(string $leadId, array $data): array|Model
    {
        if (!($data['force'] ?? false)) {
            $duplicates = $this->findDuplicateAccounts(
                $data['name'],
                $data['phone']                 ?? null,
                $data['email']                 ?? null,
                $data['industry_id']           ?? null,
                $data['segmentation_id']       ?? null,
                $data['business_size_id']      ?? null,
                $data['number_of_employee_id'] ?? null,
                $data['annual_revenue_id']     ?? null,
            );

            if (!empty($duplicates)) {
                return ['duplicates' => $duplicates];
            }
        }

        $accountRepo = new (Helper::repository('account'))(new (Helper::model('account')));

        $account = $accountRepo->create([
            'name'                  => $data['name'],
            'industry_id'           => $data['industry_id'],
            'primary_phone'         => $data['phone'] ?? null,
            'email'                 => $data['email'] ?? null,
            'segmentation_id'       => $data['segmentation_id'] ?? null,
            'business_size_id'      => $data['business_size_id'] ?? null,
            'number_of_employee_id' => $data['number_of_employee_id'] ?? null,
            'annual_revenue_id'     => $data['annual_revenue_id'] ?? null,
        ]);

        $this->model->where('id', $leadId)->update([
            'account_id'            => $account->id,
            'account_name'          => $account->name,
            'industry_id'           => $account->industry_id,
            'segmentation_id'       => $account->segmentation_id,
            'business_size_id'      => $account->business_size_id,
            'number_of_employee_id' => $account->number_of_employee_id,
            'annual_revenue_id'     => $account->annual_revenue_id,
            'is_new_account'        => true,
        ]);

        return $account->load(['industry']);
    }

    public function createContact(string $leadId, array $data): array|Model
    {
        if (!($data['force'] ?? false)) {
            $duplicates = $this->findDuplicateContacts(
                $data['name'],
                $data['phone'] ?? null,
                $data['email'] ?? null
            );

            if (!empty($duplicates)) {
                return ['duplicates' => $duplicates];
            }
        }

        $lead        = $this->model->find($leadId);
        $contactRepo = new (Helper::repository('contact'))(new (Helper::model('contact')));

        $contact = $contactRepo->create([
            'name'          => $data['name'],
            'job_title'     => $data['job_title'] ?? null,
            'primary_phone' => $data['phone'] ?? null,
            'email'         => $data['email'] ?? null,
            'account_id'    => $lead->account_id,
        ]);

        $this->model->where('id', $leadId)->update([
            'contact_id'        => $contact->id,
            'contact_name'      => $contact->name,
            'contact_job_title' => $contact->job_title,
            'is_new_contact'    => true,
        ]);

        return $contact;
    }

    private function findDuplicateAccounts(
        string  $name,
        ?string $phone              = null,
        ?string $email              = null,
        ?string $industryId         = null,
        ?string $segmentationId     = null,
        ?string $businessSizeId     = null,
        ?string $numberOfEmployeeId = null,
        ?string $annualRevenueId    = null,
    ): array {
        $nameSql          = Helper::similaritySql('name', $name);
        $normalizedPhone  = $phone ? preg_replace('/\D/', '', $phone) : null;

        return DB::table('accounts')
            ->where(function ($q) use ($nameSql, $normalizedPhone, $email) {
                $q->orWhereRaw($nameSql['expression'], $nameSql['bindings'])
                    ->when($normalizedPhone, fn($q) => $q->orWhereRaw(
                        "REPLACE(REPLACE(REPLACE(REPLACE(primary_phone, ' ', ''), '-', ''), '(', ''), ')', '') = ?",
                        [$normalizedPhone]
                    ))
                    ->when($email, fn($q) => $q->orWhereRaw('LOWER(email) = ?', [strtolower($email)]));
            })
            ->when($industryId,         fn($q) => $q->where('industry_id', $industryId))
            ->when($segmentationId,     fn($q) => $q->where('segmentation_id', $segmentationId))
            ->when($businessSizeId,     fn($q) => $q->where('business_size_id', $businessSizeId))
            ->when($numberOfEmployeeId, fn($q) => $q->where('number_of_employee_id', $numberOfEmployeeId))
            ->when($annualRevenueId,    fn($q) => $q->where('annual_revenue_id', $annualRevenueId))
            ->pluck('id')
            ->toArray();
    }

    private function findDuplicateContacts(string $name, ?string $phone, ?string $email): array
    {
        $nameSql         = Helper::similaritySql('name', $name);
        $normalizedPhone = $phone ? preg_replace('/\D/', '', $phone) : null;

        return DB::table('contacts')
            ->where(function ($q) use ($nameSql, $normalizedPhone, $email) {
                $q->orWhereRaw($nameSql['expression'], $nameSql['bindings'])
                    ->when($normalizedPhone, fn($q) => $q->orWhereRaw(
                        "REPLACE(REPLACE(REPLACE(REPLACE(primary_phone, ' ', ''), '-', ''), '(', ''), ')', '') = ?",
                        [$normalizedPhone]
                    ))
                    ->when($email, fn($q) => $q->orWhereRaw('LOWER(email) = ?', [strtolower($email)]));
            })
            ->pluck('id')
            ->toArray();
    }

    public static function processFollowUpReminders(): void
    {
        $successIds = [];
        $model      = Helper::model('lead');

        $model::prepared(
            'id',
            'name',
            'follow_up_date',
            'created_by[id, email, is_app_notification, is_push_notification, is_mobile_notification, is_email_notification, profile_picture]'
        )
        ->where('is_follow_up_reminded', false)
        ->whereNotNull('follow_up_remind_at')
        ->where('follow_up_remind_at', '<=', now())
        ->chunk(1000, function ($leads) use (&$successIds) {
            foreach ($leads as $lead) {
                $user = $lead->created_by;
                if (!$user) {
                    continue;
                }

                $title        = "Follow-up Reminder: {$lead->name}";
                $followUpDate = $lead->follow_up_date->format('d M Y');
                $message      = "Follow-up scheduled on {$followUpDate}";
                $url          = url("/crm/lead/{$lead->id}");

                try {
                    $user->sendPreferredNotification($title, $message, $url);
                    $successIds[] = $lead->id;
                } catch (\Throwable $e) {
                    Log::error('FollowUpReminderNotification failed', [
                        'lead_id' => $lead->id,
                        'user_id' => $user->id,
                        'message' => $e->getMessage(),
                    ]);
                }
            }
        });

        if (!empty($successIds)) {
            $model::whereIn('id', $successIds)->update(['is_follow_up_reminded' => true]);
        }
    }

    public static function defaultColumns(): array
    {
        return [
            'id',
            'name',
            'date',
            'phone',
            'email',
            'customer_need',
            'status_id',
            'follow_up_date',
            'account[name,industry.name,profile_picture,email,primary_phone]',
            'contact[name,job_title,profile_picture]',
            'source_id',
            'registration_method_id',
            'account_name',
            'contact_name',
            'contact_job_title',
            'budget_range_id',
            'budget',
            'disqualification_reason_id',
            'disqualification_reason_text',
            'segmentation_id',
            'number_of_employee_id',
            'annual_revenue_id',
            'industry_id',
            'business_size_id',
            'notes',
            'follow_up_remind_at',
            'is_follow_up_reminded',
            'is_new_account',
            'is_new_contact',
            'add_to_calendar',
            'created_by_id',
        ];
    }
}
