<?php

namespace Solaris\BaseCRM\Models;

use Solaris\Core\Models\LookupModel;

class AnnualRevenue extends LookupModel
{
    protected $table = 'annual_revenues';
}
