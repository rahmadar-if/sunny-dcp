<?php

namespace Solaris\BaseCRM\Models;

use Solaris\Core\Models\LookupModel;

class NoteworthyEventType extends LookupModel
{
    protected $table = 'noteworthy_event_types';
}
