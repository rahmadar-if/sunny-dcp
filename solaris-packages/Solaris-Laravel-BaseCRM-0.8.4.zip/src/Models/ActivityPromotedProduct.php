<?php

namespace Solaris\BaseCRM\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\ImportAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

#[FormAccess()]
#[DataTableAccess()]
#[ExportAccess()]
#[ImportAccess()]
class ActivityPromotedProduct extends BaseModel
{
    protected $table                = 'activity_promoted_products';
    protected array $prepareColumns = ['product_id', 'date', 'status', 'activity_id'];

    protected function casts(): array
    {
        return array_merge(parent::casts(), [
            'date' => 'date:d M Y',
        ]);
    }

    public function activity(): BelongsTo
    {
        return $this->belongsTo(Helper::model('activity'), 'activity_id', 'id');
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Helper::model('product'), 'product_id', 'id');
    }

    public function importRules(): array
    {
        return [
            'activity_id' => ['required', 'uuid'],
            'product_id'  => ['required', 'uuid'],
            'date'        => ['nullable', 'date_format:Y-m-d'],
            'status'      => ['nullable', 'string'],
        ];
    }
}
