<?php

namespace Solaris\BaseCRM\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\StageHistoryModel;

class ContactStatusHistory extends StageHistoryModel
{
    protected $table = 'contact_status_histories';

    public function status(): BelongsTo
    {
        return $this->belongsTo(Helper::model('contact_status'), 'status_id', 'id');
    }

    public function contact(): BelongsTo
    {
        return $this->belongsTo(Helper::model('contact'), 'contact_id', 'id');
    }

    protected static function parentModel(): string
    {
        return Helper::model('contact');
    }

    protected static function parentColumn(): string
    {
        return 'contact_id';
    }

    protected static function stageModel(): string
    {
        return Helper::model('contact_status');
    }

    protected static function stageColumn(): string
    {
        return 'status_id';
    }
}
