<?php

namespace Solaris\BaseCRM\Models;

use Solaris\Core\Models\LookupStage;

class LeadStatus extends LookupStage
{
    protected $table = 'lead_statuses';
}
