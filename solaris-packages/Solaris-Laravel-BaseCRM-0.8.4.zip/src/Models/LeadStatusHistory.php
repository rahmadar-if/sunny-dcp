<?php

namespace Solaris\BaseCRM\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\StageHistoryModel;

class LeadStatusHistory extends StageHistoryModel
{
    protected $table = 'lead_status_histories';

    public function status(): BelongsTo
    {
        return $this->belongsTo(Helper::model('lead_status'), 'status_id', 'id');
    }

    public function lead(): BelongsTo
    {
        return $this->belongsTo(Helper::model('lead'), 'lead_id', 'id');
    }

    protected static function parentModel(): string
    {
        return Helper::model('lead');
    }

    protected static function parentColumn(): string
    {
        return 'lead_id';
    }

    protected static function stageModel(): string
    {
        return Helper::model('lead_status');
    }

    protected static function stageColumn(): string
    {
        return 'status_id';
    }
}
