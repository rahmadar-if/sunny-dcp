<?php

namespace Solaris\BaseCRM\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Solaris\BaseCRM\Const\AccountStatusConst;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Traits\Model\HasStageHistory;
use Solaris\MasterData\Models\Account as BaseAccount;

class Account extends BaseAccount
{
    use HasStageHistory;

    protected static function booted()
    {
        parent::booted();

        static::creating(function ($account) {
            $account->status_id = AccountStatusConst::PersonalInformation;
        });
    }

    protected static function stageHistoryModel(): string
    {
        return Helper::model('account_status_history');
    }

    protected static function stageColumn(): string
    {
        return 'status_id';
    }

    public function status(): BelongsTo
    {
        return $this->belongsTo(Helper::model('account_status'), 'status_id', 'id');
    }

    public function annual_revenue(): BelongsTo
    {
        return $this->belongsTo(Helper::model('annual_revenue'), 'annual_revenue_id', 'id');
    }

    public function customer_journey(): BelongsTo
    {
        return $this->belongsTo(Helper::model('customer_journey'), 'customer_journey_id', 'id');
    }

    public function segmentation(): BelongsTo
    {
        return $this->belongsTo(Helper::model('segmentation'), 'segmentation_id', 'id');
    }

    public function business_size(): BelongsTo
    {
        return $this->belongsTo(Helper::model('business_size'), 'business_size_id', 'id');
    }

    public function frequency_type(): BelongsTo
    {
        return $this->belongsTo(Helper::model('frequency_type'), 'frequency_type_id', 'id');
    }

    public function account_banks(): HasMany
    {
        return $this->hasMany(Helper::model('account_bank'), 'account_id', 'id');
    }

    public function leads(): HasMany
    {
        return $this->hasMany(Helper::model('lead'), 'account_id', 'id');
    }

    public function importRules(): array
    {
        return array_merge(parent::importRules(), [
            'status_id'           => ['nullable', 'uuid'],
            'annual_revenue_id'   => ['nullable', 'uuid'],
            'customer_journey_id' => ['nullable', 'uuid'],
            'segmentation_id'     => ['nullable', 'uuid'],
            'business_size_id'    => ['nullable', 'uuid'],
            'recency_date'        => ['nullable', 'date_format:Y-m-d'],
            'monetary'            => ['nullable', 'decimal:0,2'],
            'frequency'           => ['nullable', 'integer'],
            'frequency_type_id'   => ['nullable', 'uuid'],
        ]);
    }
}
