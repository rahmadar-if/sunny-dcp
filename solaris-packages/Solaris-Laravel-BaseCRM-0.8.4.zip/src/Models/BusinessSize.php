<?php

namespace Solaris\BaseCRM\Models;

use Solaris\Core\Models\LookupModel;

class BusinessSize extends LookupModel
{
    protected $table = 'business_sizes';
}
