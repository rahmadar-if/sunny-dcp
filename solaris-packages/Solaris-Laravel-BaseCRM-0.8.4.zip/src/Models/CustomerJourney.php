<?php

namespace Solaris\BaseCRM\Models;

use Solaris\Core\Models\LookupModel;

class CustomerJourney extends LookupModel
{
    protected $table = 'customer_journeys';
}
