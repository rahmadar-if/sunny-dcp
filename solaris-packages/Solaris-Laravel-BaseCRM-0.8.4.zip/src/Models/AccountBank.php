<?php

namespace Solaris\BaseCRM\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\ImportAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

#[FormAccess()]
#[DataTableAccess()]
#[ExportAccess()]
#[ImportAccess()]
class AccountBank extends BaseModel
{
    protected $table                = 'account_banks';
    protected array $prepareColumns = ['id', 'bank_name', 'account_name', 'account_number', 'country_id'];

    public function account(): BelongsTo
    {
        return $this->belongsTo(Helper::model('account'), 'account_id', 'id');
    }

    public function country(): BelongsTo
    {
        return $this->belongsTo(Helper::model('country'), 'country_id', 'id');
    }

    public function importRules(): array
    {
        return [
            'account_id'     => ['required', 'uuid'],
            'bank_name'      => ['required', 'string'],
            'account_name'   => ['required', 'string'],
            'account_number' => ['required', 'string'],
            'country_id'     => ['nullable', 'uuid'],
        ];
    }
}
