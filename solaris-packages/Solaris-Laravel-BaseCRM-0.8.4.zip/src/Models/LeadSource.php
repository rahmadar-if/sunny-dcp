<?php

namespace Solaris\BaseCRM\Models;

use Solaris\Core\Models\LookupModel;

class LeadSource extends LookupModel
{
    protected $table = 'lead_sources';
}
