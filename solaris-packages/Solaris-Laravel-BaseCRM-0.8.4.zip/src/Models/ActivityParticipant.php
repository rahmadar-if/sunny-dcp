<?php

namespace Solaris\BaseCRM\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\ImportAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

#[FormAccess()]
#[DataTableAccess()]
#[ExportAccess()]
#[ImportAccess()]
class ActivityParticipant extends BaseModel
{
    protected $table                = 'activity_participants';
    protected array $prepareColumns = ['id', 'name', 'activity_id', 'role', 'notes'];

    public function activity(): BelongsTo
    {
        return $this->belongsTo(Helper::model('activity'), 'activity_id', 'id');
    }

    public function importRules(): array
    {
        return [
            'activity_id' => ['required', 'uuid'],
            'name'        => ['required', 'string'],
            'role'        => ['required', 'string'],
            'notes'       => ['nullable', 'string'],
        ];
    }
}
