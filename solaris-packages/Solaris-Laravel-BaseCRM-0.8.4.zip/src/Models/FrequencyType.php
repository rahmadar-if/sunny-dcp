<?php

namespace Solaris\BaseCRM\Models;

use Solaris\Core\Models\LookupModel;

class FrequencyType extends LookupModel
{
    protected $table = 'frequency_types';
}
