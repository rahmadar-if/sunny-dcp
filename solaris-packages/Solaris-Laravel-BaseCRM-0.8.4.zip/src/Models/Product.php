<?php

namespace Solaris\BaseCRM\Models;

use Illuminate\Database\Eloquent\Builder;
use Solaris\Core\Attributes\LookupAccess;
use Solaris\MasterData\Models\Product as BaseProduct;

#[LookupAccess(scopes: ['availableInActivityPromotedProduct'], extend: true)]
class Product extends BaseProduct
{
    public function scopeAvailableInActivityPromotedProduct(Builder $query, string $activityId)
    {
        return $query->active()
            ->whereNotIn('id', function ($query) use ($activityId) {
                $query->select('product_id')
                    ->from('activity_promoted_products')
                    ->where('activity_id', $activityId);
            });
    }
}
