<?php

namespace Solaris\BaseCRM\Models;

use Solaris\Core\Models\LookupStage;

class AccountStatus extends LookupStage
{
    protected $table = 'account_statuses';
}
