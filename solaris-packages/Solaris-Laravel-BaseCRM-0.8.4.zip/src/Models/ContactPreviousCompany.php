<?php

namespace Solaris\BaseCRM\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\ImportAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

#[FormAccess()]
#[DataTableAccess()]
#[ExportAccess()]
#[ImportAccess()]
class ContactPreviousCompany extends BaseModel
{
    protected $table                = 'contact_previous_companies';
    protected array $prepareColumns = ['id', 'active', 'role', 'start_date', 'end_date', 'contact_id', 'account_id'];

    protected function casts(): array
    {
        return array_merge(parent::casts(),
            [
                'active'     => 'boolean',
                'start_date' => 'date:d M Y',
                'end_date'   => 'date:d M Y',
            ]);
    }

    public function contact(): BelongsTo
    {
        return $this->belongsTo(Helper::model('contact'), 'contact_id', 'id');
    }

    public function account(): BelongsTo
    {
        return $this->belongsTo(Helper::model('account'), 'account_id', 'id');
    }

    public function importRules(): array
    {
        return [
            'contact_id' => ['required', 'uuid'],
            'account_id' => ['required', 'uuid'],
            'active'     => ['nullable', 'boolean'],
            'role'       => ['nullable', 'string'],
            'start_date' => ['nullable', 'date'],
            'end_date'   => ['nullable', 'date'],
        ];
    }
}
