<?php

namespace Solaris\BaseCRM\Models;

use Solaris\Core\Models\LookupModel;

class ActivityResult extends LookupModel
{
    protected $table = 'activity_results';
}
