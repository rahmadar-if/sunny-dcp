<?php

namespace Solaris\BaseCRM\Models;

use Solaris\Core\Models\LookupModel;

class Segmentation extends LookupModel
{
    protected $table = 'segmentations';
}
