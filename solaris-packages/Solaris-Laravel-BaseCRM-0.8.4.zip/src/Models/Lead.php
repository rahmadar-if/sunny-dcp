<?php

namespace Solaris\BaseCRM\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\LookupAccess;
use Solaris\Core\Attributes\FolderAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\ImportAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Traits\Model\HasStageHistory;

#[FormAccess()]
#[DataTableAccess()]
#[LookupAccess()]
#[FolderAccess()]
#[ExportAccess()]
#[ImportAccess()]
class Lead extends BaseModel
{
    use HasStageHistory;

    protected $table                = 'leads';
    protected ?string $displayValue = 'name';
    protected array   $searchColumns = ['notes_plain' => 'FullText'];

    protected static function booted()
    {
        parent::booted();

        $syncNotes = function ($lead) {
            if ($lead->isDirty('notes') || ($lead->notes && !$lead->notes_plain)) {
                $lead->notes_plain = $lead->notes ? Helper::stripHtml($lead->notes) : null;
            }
        };

        static::creating($syncNotes);
        static::updating($syncNotes);
    }

    protected static function stageHistoryModel(): string
    {
        return Helper::model('lead_status_history');
    }

    protected static function stageColumn(): string
    {
        return 'status_id';
    }

    protected function casts(): array
    {
        return array_merge(parent::casts(), [
            'date'                  => 'date:d M Y',
            'follow_up_date'        => 'date:d M Y',
            'follow_up_remind_at'   => 'datetime',
            'is_follow_up_reminded' => 'boolean',
            'is_new_account'        => 'boolean',
            'is_new_contact'        => 'boolean',
            'add_to_calendar'       => 'boolean',
        ]);
    }

    public function status(): BelongsTo
    {
        return $this->belongsTo(Helper::model('lead_status'), 'status_id', 'id');
    }

    public function source(): BelongsTo
    {
        return $this->belongsTo(Helper::model('lead_source'), 'source_id', 'id');
    }

    public function account(): BelongsTo
    {
        return $this->belongsTo(Helper::model('account'), 'account_id', 'id');
    }

    public function contact(): BelongsTo
    {
        return $this->belongsTo(Helper::model('contact'), 'contact_id', 'id');
    }

    public function registration_method(): BelongsTo
    {
        return $this->belongsTo(Helper::model('lead_registration_method'), 'registration_method_id', 'id');
    }

    public function segmentation(): BelongsTo
    {
        return $this->belongsTo(Helper::model('segmentation'), 'segmentation_id', 'id');
    }

    public function number_of_employee(): BelongsTo
    {
        return $this->belongsTo(Helper::model('number_of_employee'), 'number_of_employee_id', 'id');
    }

    public function annual_revenue(): BelongsTo
    {
        return $this->belongsTo(Helper::model('annual_revenue'), 'annual_revenue_id', 'id');
    }

    public function business_size(): BelongsTo
    {
        return $this->belongsTo(Helper::model('business_size'), 'business_size_id', 'id');
    }

    public function budget_range(): BelongsTo
    {
        return $this->belongsTo(Helper::model('budget_range'), 'budget_range_id', 'id');
    }

    public function disqualification_reason(): BelongsTo
    {
        return $this->belongsTo(Helper::model('disqualification_reason'), 'disqualification_reason_id', 'id');
    }

    public function industry(): BelongsTo
    {
        return $this->belongsTo(Helper::model('industry'), 'industry_id', 'id');
    }

    public function status_histories(): HasMany
    {
        return $this->hasMany(Helper::model('lead_status_history'), 'lead_id', 'id');
    }

    public function activities(): HasMany
    {
        return $this->hasMany(Helper::model('activity'), 'lead_id', 'id');
    }

    public function importRules(): array
    {
        return [
            'name'                   => ['required', 'string', 'max:255'],
            'source_id'              => ['required', 'uuid'],
            'registration_method_id' => ['required', 'uuid'],
            'date'                   => ['required', 'date_format:Y-m-d'],
            'account_id'             => ['nullable', 'uuid'],
            'contact_id'             => ['nullable', 'uuid'],
            'phone'                  => ['nullable', 'string', 'max:50'],
            'email'                  => ['nullable', 'string', 'email', 'max:255'],
            'customer_need'          => ['required', 'string'],
            'budget'                 => ['nullable', 'decimal:0,2'],
        ];
    }
}
