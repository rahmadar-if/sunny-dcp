<?php

namespace Solaris\BaseCRM\Models;

use Solaris\Core\Models\LookupModel;

class BudgetRange extends LookupModel
{
    protected $table = 'budget_ranges';
}
