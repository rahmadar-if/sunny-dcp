<?php

namespace Solaris\BaseCRM\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Models\Activity as BaseActivity;

class Activity extends BaseActivity
{
    public function result(): BelongsTo
    {
        return $this->belongsTo(Helper::model('activity_result'), 'result_id', 'id');
    }

    public function lead(): BelongsTo
    {
        return $this->belongsTo(Helper::model('lead'), 'lead_id', 'id');
    }

    public function participants(): HasMany
    {
        return $this->hasMany(Helper::model('activity_participant'), 'activity_id', 'id');
    }

    public function promoted_products(): HasMany
    {
        return $this->hasMany(Helper::model('activity_promoted_product'), 'activity_id', 'id');
    }

    public function importRules(): array
    {
        return array_merge(parent::importRules(), [
            'lead_id'       => ['nullable', 'uuid'],
            'result_id'     => ['nullable', 'uuid'],
            'detail_result' => ['nullable', 'string'],
        ]);
    }
}
