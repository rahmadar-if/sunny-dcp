<?php

namespace Solaris\BaseCRM\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\StageHistoryModel;

class AccountStatusHistory extends StageHistoryModel
{
    protected $table = 'account_status_histories';

    public function status(): BelongsTo
    {
        return $this->belongsTo(Helper::model('account_status'), 'status_id', 'id');
    }

    public function account(): BelongsTo
    {
        return $this->belongsTo(Helper::model('account'), 'account_id', 'id');
    }

    protected static function parentModel(): string
    {
        return Helper::model('account');
    }

    protected static function parentColumn(): string
    {
        return 'account_id';
    }

    protected static function stageModel(): string
    {
        return Helper::model('account_status');
    }

    protected static function stageColumn(): string
    {
        return 'status_id';
    }
}
