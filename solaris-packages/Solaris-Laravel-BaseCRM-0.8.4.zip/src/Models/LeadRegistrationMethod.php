<?php

namespace Solaris\BaseCRM\Models;

use Solaris\Core\Models\LookupModel;

class LeadRegistrationMethod extends LookupModel
{
    protected $table = 'lead_registration_methods';
}
