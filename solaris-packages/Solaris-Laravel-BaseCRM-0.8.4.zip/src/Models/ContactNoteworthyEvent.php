<?php

namespace Solaris\BaseCRM\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\ImportAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

#[FormAccess()]
#[DataTableAccess()]
#[ExportAccess()]
#[ImportAccess()]
class ContactNoteworthyEvent extends BaseModel
{
    protected $table                = 'contact_noteworthy_events';
    protected array $prepareColumns = ['id', 'date', 'notes', 'type_id'];

    protected function casts(): array
    {
        return array_merge(parent::casts(), [
            'date' => 'date:d M Y',
        ]);
    }

    public function contact(): BelongsTo
    {
        return $this->belongsTo(Helper::model('contact'), 'contact_id', 'id');
    }

    public function type(): BelongsTo
    {
        return $this->belongsTo(Helper::model('noteworthy_event_type'), 'type_id', 'id');
    }

    public function importRules(): array
    {
        return [
            'contact_id' => ['required', 'uuid'],
            'type_id'    => ['required', 'uuid'],
            'date'       => ['required', 'date_format:Y-m-d'],
            'notes'      => ['nullable', 'string'],
        ];
    }
}
