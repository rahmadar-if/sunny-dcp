<?php

namespace Solaris\BaseCRM\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Solaris\BaseCRM\Const\ContactStatusConst;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Traits\Model\HasStageHistory;
use Solaris\MasterData\Models\Contact as BaseContact;

class Contact extends BaseContact
{
    use HasStageHistory;

    protected static function booted()
    {
        parent::booted();

        static::creating(function ($contact) {
            $contact->status_id = ContactStatusConst::PersonalInformation;
        });
    }

    protected static function stageHistoryModel(): string
    {
        return Helper::model('contact_status_history');
    }

    protected static function stageColumn(): string
    {
        return 'status_id';
    }

    public function status(): BelongsTo
    {
        return $this->belongsTo(Helper::model('contact_status'), 'status_id', 'id');
    }

    public function segmentation(): BelongsTo
    {
        return $this->belongsTo(Helper::model('segmentation'), 'segmentation_id', 'id');
    }

    public function noteworthy_events(): HasMany
    {
        return $this->hasMany(Helper::model('contact_noteworthy_event'), 'contact_id', 'id');
    }

    public function previous_companies(): HasMany
    {
        return $this->hasMany(Helper::model('contact_previous_company'), 'contact_id', 'id');
    }

    public function importRules(): array
    {
        return array_merge(parent::importRules(), [
            'status_id'       => ['nullable', 'uuid'],
            'segmentation_id' => ['nullable', 'uuid'],
            'npwp'            => ['nullable', 'string', 'max:16'],
            'no_ktp'          => ['nullable', 'string', 'max:16'],
        ]);
    }
}
