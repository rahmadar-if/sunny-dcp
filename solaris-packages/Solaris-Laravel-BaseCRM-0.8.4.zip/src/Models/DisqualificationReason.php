<?php

namespace Solaris\BaseCRM\Models;

use Solaris\Core\Models\LookupModel;

class DisqualificationReason extends LookupModel
{
    protected $table = 'disqualification_reasons';
}
