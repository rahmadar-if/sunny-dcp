<?php

namespace Solaris\BaseCRM\Models;

use Solaris\Core\Models\LookupStage;

class ContactStatus extends LookupStage
{
    protected $table = 'contact_statuses';
}
