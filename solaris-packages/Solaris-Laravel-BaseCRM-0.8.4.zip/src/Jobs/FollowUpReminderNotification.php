<?php

namespace Solaris\BaseCRM\Jobs;

use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Solaris\BaseCRM\Repositories\LeadRepository;

class FollowUpReminderNotification implements ShouldQueue, ShouldBeUnique
{
    use Queueable;

    public function handle(): void
    {
        LeadRepository::processFollowUpReminders();
    }
}
