<?php

namespace Solaris\BaseCRM;

class SolarisBaseCRM {}
