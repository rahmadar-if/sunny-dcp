<?php

namespace Solaris\BaseCRM\Commands;

use Illuminate\Console\Command;

class SolarisBaseCRMCommand extends Command
{
    public $signature = 'solaris-laravel-basecrm';

    public $description = 'My command';

    public function handle(): int
    {
        $this->comment('All done');

        return self::SUCCESS;
    }
}
