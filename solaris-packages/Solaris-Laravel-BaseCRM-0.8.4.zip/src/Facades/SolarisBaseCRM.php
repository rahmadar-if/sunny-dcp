<?php

namespace Solaris\BaseCRM\Facades;

use Illuminate\Support\Facades\Facade;

/**
 * @see \Solaris\BaseCRM\SolarisLaravelBaseCRM\SolarisLaravelBaseCRM
 */
class SolarisBaseCRM extends Facade
{
    protected static function getFacadeAccessor(): string
    {
        return \Solaris\BaseCRM\SolarisBaseCRM::class;
    }
}
