# Solaris Base CRM

A Laravel package for managing core CRM entities — built on top of `solaris/solaris-laravel-masterdata`.

Covers the full lifecycle of Leads, Accounts, Contacts, and Activities, with stage history tracking, RFM analysis, and granular access control wired in from the start.

---

## Requirements

- PHP 8.2+
- Laravel 11 or 12
- `solaris/solaris-laravel-masterdata` v0.5.2+

---

## Modules

### Lead
Manages sales leads from acquisition to handoff.

- Basic info: name, date, phone, email, budget, customer need, notes
- Relationships: Account, Contact, Lead Source, Registration Method, Segmentation, Industry, Business Size, Annual Revenue, Customer Journey, Number of Employee
- Stage pipeline: `Qualification` → `Nurturing` → `Awaiting Sales` → `Satisfied`
- Auto-links and updates Account when Lead reaches `AwaitingSales` stage
- Full stage history with timestamps per transition

### Account
Extends MasterData Account with CRM-specific fields.

- Status workflow: `PersonalInformation` → `Draft` → `Verification` → `Approve`
- RFM analysis fields: recency date, monetary, frequency, frequency type
- Additional classifications: Annual Revenue, Customer Journey, Segmentation, Business Size
- **Bank Accounts**: multiple bank records per account

### Contact
Extends MasterData Contact with CRM-specific fields.

- Status workflow: `PersonalInformation` → `Draft` → `Verification` → `Approve`
- Indonesia-specific identity fields: NPWP (16 chars), No. KTP (16 chars)
- Segmentation classification
- **Noteworthy Events**: tracks significant life/business events per contact
- **Previous Companies**: employment history with dates and account references

### Activity
Extends MasterData Activity with CRM-specific tracking.

- Result tracking via ActivityResult lookup
- Lead attribution — link activities back to originating leads
- **Participants**: attendees with name, role, and notes
- **Promoted Products**: products presented during activity, with date and status tracking

---

## Architecture

All modules follow the same pattern inherited from `solaris-laravel-core`:

- **Models** extend `BaseModel` (UUID primary key, audit fields, soft deletes)
- **Repositories** extend `BaseRepository` (CRUD, batch ops, attachment handling)
- **Controllers** handle list, edit, avatar upload, and batch delete via standard endpoints
- **FormRequests** extend `BaseFormRequest` for consistent validation

Routes are prefixed under `/crm` and protected by `auth` and `menu.access` middleware.

---

## Lookup / Reference Data

The following reference models are bundled and auto-registered for lookup management:

| Model | Description |
|---|---|
| `AccountStatus` | Account workflow stages |
| `AnnualRevenue` | Company revenue brackets |
| `BusinessSize` | Company size categories |
| `CustomerJourney` | Customer lifecycle stages |
| `FrequencyType` | Frequency classification |
| `Segmentation` | Market segmentation |
| `ContactStatus` | Contact workflow stages |
| `NoteworthyEventType` | Contact event type classification |
| `LeadStatus` | Lead pipeline stages |
| `LeadSource` | Lead acquisition channels |
| `LeadRegistrationMethod` | Lead registration types |
| `ActivityResult` | Activity outcome types |

---

## Changelog

Please see [CHANGELOG](CHANGELOG.md) for recent changes.
