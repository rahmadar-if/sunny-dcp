<?php

use Solaris\Sales\Tests\TestCase;

uses(TestCase::class)->in(__DIR__);
