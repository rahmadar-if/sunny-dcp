<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('activities', function (Blueprint $table) {
            $table->foreignUuid('opportunity_id')->nullable()->constrained('opportunities');
            $table->foreignUuid('order_id')->nullable()->constrained('orders');
            $table->foreignUuid('invoice_id')->nullable()->constrained('invoices');

            if(config('database.default') == 'pgsql') {
                $table->index('opportunity_id', 'activities_opportunity_id_foreign');
                $table->index('order_id', 'activities_order_id_foreign');
                $table->index('invoice_id', 'activities_invoice_id_foreign');
            }
        });
    }

    public function down(): void
    {
        Schema::table('activities', function (Blueprint $table) {
            $table->dropForeign(['opportunity_id']);
            $table->dropForeign(['order_id']);
            $table->dropForeign(['invoice_id']);

            if(config('database.default') == 'pgsql') {
               $table->dropIndex('activities_opportunity_id_foreign');
               $table->dropIndex('activities_order_id_foreign');
               $table->dropIndex('activities_invoice_id_foreign');
            }

            $table->dropColumn('opportunity_id');
            $table->dropColumn('order_id');
            $table->dropColumn('invoice_id');
        });
    }
};