<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('invoices', function (Blueprint $table) {
            $table->renameColumn('date', 'issued_date');
            $table->date('completed_at')->nullable();
            $table->dropColumn("payment_amount");
        });
    }

    public function down(): void
    {
        Schema::table('invoices', function (Blueprint $table) {
            $table->renameColumn('issued_date', 'date');
            $table->dropColumn('completed_at');
            $table->decimal('payment_amount', 19, 2)->default(0);
        });
    }
};