<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        // invoices and invoice_details had no index block at all in the create migration
        Schema::table('invoices', function (Blueprint $table) {
            MigrationHelper::createIndexIfNeeds($table, ['account_id']);
            MigrationHelper::createIndexIfNeeds($table, ['contact_id']);
            MigrationHelper::createIndexIfNeeds($table, ['order_id']);
            MigrationHelper::createIndexIfNeeds($table, ['status_id']);
        });

        Schema::table('invoice_details', function (Blueprint $table) {
            MigrationHelper::createIndexIfNeeds($table, ['product_id']);
            MigrationHelper::createIndexIfNeeds($table, ['invoice_id']);
        });

        Schema::table('invoice_status_histories', function (Blueprint $table) {
            if (config('database.default') === 'pgsql') {
                $table->dropIndex('invoice_status_histories_invoice_id_foreign');
                $table->dropIndex('invoice_status_histories_status_id_foreign');
            }

            MigrationHelper::createIndexIfNeeds($table, ['invoice_id']);
            MigrationHelper::createIndexIfNeeds($table, ['status_id']);
        });
    }

    public function down(): void
    {
        Schema::table('invoice_status_histories', function (Blueprint $table) {
            MigrationHelper::dropIndexIfNeeds($table, ['invoice_id']);
            MigrationHelper::dropIndexIfNeeds($table, ['status_id']);

            if (config('database.default') === 'pgsql') {
                $table->index('invoice_id', 'invoice_status_histories_invoice_id_foreign');
                $table->index('status_id', 'invoice_status_histories_status_id_foreign');
            }
        });

        Schema::table('invoice_details', function (Blueprint $table) {
            MigrationHelper::dropIndexIfNeeds($table, ['product_id']);
            MigrationHelper::dropIndexIfNeeds($table, ['invoice_id']);
        });

        Schema::table('invoices', function (Blueprint $table) {
            MigrationHelper::dropIndexIfNeeds($table, ['account_id']);
            MigrationHelper::dropIndexIfNeeds($table, ['contact_id']);
            MigrationHelper::dropIndexIfNeeds($table, ['order_id']);
            MigrationHelper::dropIndexIfNeeds($table, ['status_id']);
        });
    }
};
