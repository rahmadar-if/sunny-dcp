<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('opportunity_statuses', function (Blueprint $table) {
            MigrationHelper::baseLookupStage($table);

            $table->integer("probability")->nullable();
        });

        Schema::create('opportunities', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('name')->nullable();
            $table->date('date')->nullable();
            $table->boolean('is_new_customer')->default(false);
            $table->string('phone', 50)->nullable();
            $table->string('email')->nullable();
            $table->date('closed_on')->nullable();
            $table->decimal('budget', 19, 2)->nullable()->default(0);
            $table->text('customer_need')->nullable();
            $table->decimal('amount', 19, 2)->nullable()->default(0);
            $table->decimal('probability_percent', 5, 2)->default(0);
            $table->decimal('discount_amount', 19, 2)->nullable()->default(0);
            $table->decimal('discount_percent', 5, 2)->nullable()->default(0);
            $table->decimal('total_amount', 19, 2)->nullable()->default(0);
            $table->string('quotation_number')->nullable();
            $table->text('latest_status')->nullable();
            $table->date('status_date')->nullable();
            $table->text('description')->nullable();
            $table->string('our_weaknesses')->nullable();
            $table->string('our_strengths')->nullable();
            $table->string('sales_tactics')->nullable();
            $table->unsignedInteger('days_in_funnel')->default(0);
            $table->text('notes')->nullable();
            $table->decimal('position')->nullable();

            $table->foreignUuid('source_id')->nullable()->constrained('lead_sources');
            $table->foreignUuid('customer_id')->nullable()->constrained('accounts');
            $table->foreignUuid('decision_maker_id')->nullable()->constrained('contacts');
            $table->foreignUuid('lead_id')->nullable()->constrained('leads');
            $table->foreignUuid('status_id')->nullable()->constrained('opportunity_statuses');

            if(config('database.default') == 'pgsql') {
                $table->index('source_id', 'opportunities_source_id_foreign');
                $table->index('customer_id', 'opportunities_customer_id_foreign');
                $table->index('decision_maker_id', 'opportunities_decision_maker_id_foreign');
                $table->index('lead_id', 'opportunities_lead_id_foreign');
                $table->index('status_id', 'opportunities_status_id_foreign');
            }
        });

        Schema::create('opportunity_products', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->unsignedInteger('qty')->default(0);
            $table->decimal('price', 19, 2)->default(0);
            $table->decimal('disc', 19, 2)->nullable()->default(0);
            $table->decimal('total', 19, 2)->default(0);

            $table->foreignUuid('product_id')->nullable()->constrained('products');
            $table->foreignUuid('opportunity_id')->nullable()->constrained('opportunities');

            if(config('database.default') == 'pgsql') {
                $table->index('product_id', 'opportunity_products_product_id_foreign');
                $table->index('opportunity_id', 'opportunity_products_opportunity_id_foreign');
            }
        });

        Schema::create('opportunity_quotation_histories', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string("number_quotation");
            $table->decimal("total_amount", 19, 2);
            $table->date("date");

            $table->foreignUuid("opportunity_id")->nullable()->constrained("opportunities");
            
            if(config('database.default') == 'pgsql') {
                $table->index('opportunity_id', 'opportunity_quotation_histories_opportunity_id_foreign');
            }
        });

        Schema::create('opportunity_teams', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string("name");
            $table->string("role");

            $table->foreignUuid('opportunity_id')->nullable()->constrained('opportunities');

            if(config('database.default') == 'pgsql') {
                $table->index('opportunity_id', 'opportunity_teams_opportunity_id_foreign');
            }
        });

        Schema::create('opportunity_contacts', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string("role");
            $table->boolean("is_decision_maker");

            $table->foreignUuid("contact_id")->nullable()->constrained("contacts");
            $table->foreignUuid("opportunity_id")->nullable()->constrained("opportunities");

            if(config('database.default') == 'pgsql') {
                $table->index('contact_id', 'opportunity_contacts_contact_id_foreign');
                $table->index('opportunity_id', 'opportunity_contacts_opportunity_id_foreign');
            }
        });

        Schema::create('opportunity_competitors', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string("name")->nullable();
            $table->decimal("total_amount", 19, 2)->nullable();
            $table->tinyText("strength")->nullable();
            $table->tinyText("weakness")->nullable();
            $table->integer("rating")->nullable();

            $table->foreignUuid("opportunity_id")->nullable()->constrained("opportunities");

            if(config('database.default') == 'pgsql') {
                $table->index('opportunity_id', 'opportunity_competitors_opportunity_id_foreign');
            }
        });

        Schema::create('opportunity_status_histories', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->smallInteger('position');
            $table->timestamp('start')->nullable();
            $table->timestamp('end')->nullable();

            $table->foreignUuid('opportunity_id')->nullable()->constrained('opportunities');
            $table->foreignUuid('status_id')->nullable()->constrained('opportunity_statuses');

            if(config('database.default') == 'pgsql') {
                $table->index('opportunity_id', 'opportunity_status_histories_opportunity_id_foreign');
                $table->index('status_id', 'opportunity_status_histories_status_id_foreign');
            }
        });

        Schema::create('opportunity_term_conditions', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->text("subject")->nullable();

            $table->foreignUuid("opportunity_id")->nullable()->constrained("opportunities");

            if(config('database.default') == 'pgsql') {
                $table->index('opportunity_id', 'opportunity_term_conditions_opportunity_id_foreign');
            }
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('opportunity_term_conditions');
        Schema::dropIfExists('opportunity_status_histories');
        Schema::dropIfExists('opportunity_competitors');
        Schema::dropIfExists('opportunity_contacts');
        Schema::dropIfExists('opportunity_teams');
        Schema::dropIfExists('opportunity_quotation_histories');
        Schema::dropIfExists('opportunity_products');
        Schema::dropIfExists('opportunities');
        Schema::dropIfExists('opportunity_statuses');
    }
};