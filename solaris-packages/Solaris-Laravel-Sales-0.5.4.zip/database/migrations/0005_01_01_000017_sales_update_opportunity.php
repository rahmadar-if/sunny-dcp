<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('opportunity_types', function(Blueprint $table) {
            MigrationHelper::baseLookupStage($table);
        });

        Schema::table('opportunities', function (Blueprint $table) {
            $table->foreignUuid('type_id')->nullable()->constrained('opportunity_types')->nullOnDelete();

            MigrationHelper::createIndexIfNeeds($table, ['type_id']);
        });
    }

    public function down(): void
    {
        Schema::table('opportunities', function (Blueprint $table) {
            $table->dropForeign(['type_id']);

            MigrationHelper::dropIndexIfNeeds($table, ['type_id']);
            
            $table->dropColumn(['type_id']);
        });

        Schema::dropIfExists('opportunity_types');
    }
};
