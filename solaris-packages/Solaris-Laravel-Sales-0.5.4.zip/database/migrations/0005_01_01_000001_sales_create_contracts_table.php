<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('contracts', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('number')->nullable();
            $table->string('subject')->nullable();
            $table->date('start_date')->nullable();
            $table->date('end_date')->nullable();
            $table->decimal('amount', 19, 2)->default(0);
            $table->text('notes')->nullable();

            $table->foreignUuid('account_id')->nullable()->constrained('accounts');
            $table->foreignUuid('contact_id')->nullable()->constrained('contacts');

            if(config('database.default') == 'pgsql') {
                $table->index('account_id', 'contracts_account_id_foreign');
                $table->index('contact_id', 'contracts_contact_id_foreign');
            }
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('contracts');
    }
};