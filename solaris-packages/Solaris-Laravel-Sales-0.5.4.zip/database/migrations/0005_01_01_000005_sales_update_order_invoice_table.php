<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('order_status_histories', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->smallInteger('position');
            $table->timestamp('start')->nullable();
            $table->timestamp('end')->nullable();

            $table->foreignUuid('order_id')->nullable()->constrained('orders');
            $table->foreignUuid('status_id')->nullable()->constrained('order_statuses');

            if(config('database.default') == 'pgsql') {
                $table->index('order_id', 'order_status_histories_order_id_foreign');
                $table->index('status_id', 'order_status_histories_status_id_foreign');
            }
        });

        Schema::create('invoice_status_histories', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->smallInteger('position');
            $table->timestamp('start')->nullable();
            $table->timestamp('end')->nullable();

            $table->foreignUuid('invoice_id')->nullable()->constrained('invoices');
            $table->foreignUuid('status_id')->nullable()->constrained('invoice_statuses');

            if(config('database.default') == 'pgsql') {
                $table->index('invoice_id', 'invoice_status_histories_invoice_id_foreign');
                $table->index('status_id', 'invoice_status_histories_status_id_foreign');
            }
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('invoice_status_histories');
        Schema::dropIfExists('order_status_histories');
    }
};