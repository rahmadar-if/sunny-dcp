<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('order_statuses', function(Blueprint $table) {
            MigrationHelper::baseLookupStage($table);
        });

        Schema::create('orders', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('number')->nullable();
            $table->date('date')->nullable();
            $table->decimal('amount', 19, 2)->default(0);
            $table->text('notes')->nullable();

            $table->foreignUuid('account_id')->nullable()->constrained('accounts');
            $table->foreignUuid('contact_id')->nullable()->constrained('contacts');
            $table->foreignUuid('opportunity_id')->nullable()->constrained('opportunities');
            $table->foreignUuid('status_id')->nullable()->constrained('order_statuses');

            if(config('database.default') == 'pgsql') {
                $table->index('account_id', 'orders_account_id_foreign');
                $table->index('contact_id', 'orders_contact_id_foreign');
                $table->index('opportunity_id', 'orders_opportunity_id_foreign');
                $table->index('status_id', 'orders_status_id_foreign');
            }
        });

        Schema::create('order_details', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->decimal('price', 19, 2)->default(0);
            $table->integer('qty')->default(0);
            $table->decimal('discount', 19, 2)->nullable()->default(0);
            $table->decimal('total', 19, 2)->default(0);

            $table->foreignUuid('product_id')->nullable()->constrained('products');
            $table->foreignUuid('order_id')->nullable()->constrained('orders');

            if(config('database.default') == 'pgsql') {
                $table->index('product_id', 'order_details_product_id_foreign');
                $table->index('order_id', 'order_details_order_id_foreign');
            }
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('order_details');
        Schema::dropIfExists('orders');
        Schema::dropIfExists('order_statuses');
    }
};