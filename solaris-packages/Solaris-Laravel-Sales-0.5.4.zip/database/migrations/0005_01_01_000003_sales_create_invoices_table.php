<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('invoice_statuses', function(Blueprint $table) {
            MigrationHelper::baseLookupStage($table);
        });

        Schema::create('invoices', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->string('number')->nullable();
            $table->string('subject')->nullable();
            $table->date('date')->nullable();
            $table->date('due_date')->nullable();
            $table->decimal('amount', 19, 2)->default(0);
            $table->decimal('payment_amount', 19, 2)->default(0);
            $table->text('notes')->nullable();

            $table->foreignUuid('account_id')->nullable()->constrained('accounts');
            $table->foreignUuid('contact_id')->nullable()->constrained('contacts');
            $table->foreignUuid('order_id')->nullable()->constrained('orders');
            $table->foreignUuid('status_id')->nullable()->constrained('invoice_statuses');
        });

        Schema::create('invoice_details', function (Blueprint $table) {
            MigrationHelper::baseTable($table);

            $table->decimal('price', 19, 2)->default(0);
            $table->integer('qty')->default(0);
            $table->decimal('discount', 19, 2)->nullable()->default(0);
            $table->decimal('total', 19, 2)->default(0);

            $table->foreignUuid('product_id')->nullable()->constrained('products');
            $table->foreignUuid('invoice_id')->nullable()->constrained('invoices');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('invoice_details');
        Schema::dropIfExists('invoices');
        Schema::dropIfExists('invoice_statuses');
    }
};