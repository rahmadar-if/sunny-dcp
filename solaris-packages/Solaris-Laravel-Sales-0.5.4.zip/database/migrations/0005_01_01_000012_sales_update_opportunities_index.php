<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('opportunities', function (Blueprint $table) {
            if (config('database.default') === 'pgsql') {
                $table->dropIndex('opportunities_source_id_foreign');
                $table->dropIndex('opportunities_customer_id_foreign');
                $table->dropIndex('opportunities_decision_maker_id_foreign');
                $table->dropIndex('opportunities_lead_id_foreign');
                $table->dropIndex('opportunities_status_id_foreign');
            }

            MigrationHelper::createIndexIfNeeds($table, ['source_id']);
            MigrationHelper::createIndexIfNeeds($table, ['customer_id']);
            MigrationHelper::createIndexIfNeeds($table, ['decision_maker_id']);
            MigrationHelper::createIndexIfNeeds($table, ['lead_id']);
            MigrationHelper::createIndexIfNeeds($table, ['status_id']);
        });

        Schema::table('opportunity_products', function (Blueprint $table) {
            if (config('database.default') === 'pgsql') {
                $table->dropIndex('opportunity_products_product_id_foreign');
                $table->dropIndex('opportunity_products_opportunity_id_foreign');
            }

            MigrationHelper::createIndexIfNeeds($table, ['product_id']);
            MigrationHelper::createIndexIfNeeds($table, ['opportunity_id']);
        });

        Schema::table('opportunity_quotation_histories', function (Blueprint $table) {
            if (config('database.default') === 'pgsql') {
                $table->dropIndex('opportunity_quotation_histories_opportunity_id_foreign');
            }

            MigrationHelper::createIndexIfNeeds($table, ['opportunity_id']);
        });

        Schema::table('opportunity_teams', function (Blueprint $table) {
            if (config('database.default') === 'pgsql') {
                $table->dropIndex('opportunity_teams_opportunity_id_foreign');
            }

            MigrationHelper::createIndexIfNeeds($table, ['opportunity_id']);
        });

        Schema::table('opportunity_contacts', function (Blueprint $table) {
            if (config('database.default') === 'pgsql') {
                $table->dropIndex('opportunity_contacts_contact_id_foreign');
                $table->dropIndex('opportunity_contacts_opportunity_id_foreign');
            }

            MigrationHelper::createIndexIfNeeds($table, ['contact_id']);
            MigrationHelper::createIndexIfNeeds($table, ['opportunity_id']);
        });

        Schema::table('opportunity_competitors', function (Blueprint $table) {
            if (config('database.default') === 'pgsql') {
                $table->dropIndex('opportunity_competitors_opportunity_id_foreign');
            }

            MigrationHelper::createIndexIfNeeds($table, ['opportunity_id']);
        });

        Schema::table('opportunity_status_histories', function (Blueprint $table) {
            if (config('database.default') === 'pgsql') {
                $table->dropIndex('opportunity_status_histories_opportunity_id_foreign');
                $table->dropIndex('opportunity_status_histories_status_id_foreign');
            }

            MigrationHelper::createIndexIfNeeds($table, ['opportunity_id']);
            MigrationHelper::createIndexIfNeeds($table, ['status_id']);
        });

        Schema::table('opportunity_term_conditions', function (Blueprint $table) {
            if (config('database.default') === 'pgsql') {
                $table->dropIndex('opportunity_term_conditions_opportunity_id_foreign');
            }

            MigrationHelper::createIndexIfNeeds($table, ['opportunity_id']);
        });
    }

    public function down(): void
    {
        Schema::table('opportunity_term_conditions', function (Blueprint $table) {
            MigrationHelper::dropIndexIfNeeds($table, ['opportunity_id']);

            if (config('database.default') === 'pgsql') {
                $table->index('opportunity_id', 'opportunity_term_conditions_opportunity_id_foreign');
            }
        });

        Schema::table('opportunity_status_histories', function (Blueprint $table) {
            MigrationHelper::dropIndexIfNeeds($table, ['opportunity_id']);
            MigrationHelper::dropIndexIfNeeds($table, ['status_id']);

            if (config('database.default') === 'pgsql') {
                $table->index('opportunity_id', 'opportunity_status_histories_opportunity_id_foreign');
                $table->index('status_id', 'opportunity_status_histories_status_id_foreign');
            }
        });

        Schema::table('opportunity_competitors', function (Blueprint $table) {
            MigrationHelper::dropIndexIfNeeds($table, ['opportunity_id']);

            if (config('database.default') === 'pgsql') {
                $table->index('opportunity_id', 'opportunity_competitors_opportunity_id_foreign');
            }
        });

        Schema::table('opportunity_contacts', function (Blueprint $table) {
            MigrationHelper::dropIndexIfNeeds($table, ['contact_id']);
            MigrationHelper::dropIndexIfNeeds($table, ['opportunity_id']);

            if (config('database.default') === 'pgsql') {
                $table->index('contact_id', 'opportunity_contacts_contact_id_foreign');
                $table->index('opportunity_id', 'opportunity_contacts_opportunity_id_foreign');
            }
        });

        Schema::table('opportunity_teams', function (Blueprint $table) {
            MigrationHelper::dropIndexIfNeeds($table, ['opportunity_id']);

            if (config('database.default') === 'pgsql') {
                $table->index('opportunity_id', 'opportunity_teams_opportunity_id_foreign');
            }
        });

        Schema::table('opportunity_quotation_histories', function (Blueprint $table) {
            MigrationHelper::dropIndexIfNeeds($table, ['opportunity_id']);

            if (config('database.default') === 'pgsql') {
                $table->index('opportunity_id', 'opportunity_quotation_histories_opportunity_id_foreign');
            }
        });

        Schema::table('opportunity_products', function (Blueprint $table) {
            MigrationHelper::dropIndexIfNeeds($table, ['product_id']);
            MigrationHelper::dropIndexIfNeeds($table, ['opportunity_id']);

            if (config('database.default') === 'pgsql') {
                $table->index('product_id', 'opportunity_products_product_id_foreign');
                $table->index('opportunity_id', 'opportunity_products_opportunity_id_foreign');
            }
        });

        Schema::table('opportunities', function (Blueprint $table) {
            MigrationHelper::dropIndexIfNeeds($table, ['source_id']);
            MigrationHelper::dropIndexIfNeeds($table, ['customer_id']);
            MigrationHelper::dropIndexIfNeeds($table, ['decision_maker_id']);
            MigrationHelper::dropIndexIfNeeds($table, ['lead_id']);
            MigrationHelper::dropIndexIfNeeds($table, ['status_id']);

            if (config('database.default') === 'pgsql') {
                $table->index('source_id', 'opportunities_source_id_foreign');
                $table->index('customer_id', 'opportunities_customer_id_foreign');
                $table->index('decision_maker_id', 'opportunities_decision_maker_id_foreign');
                $table->index('lead_id', 'opportunities_lead_id_foreign');
                $table->index('status_id', 'opportunities_status_id_foreign');
            }
        });
    }
};
