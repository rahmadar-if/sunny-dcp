<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('opportunities', function (Blueprint $table) {
            $table->dropForeign(['source_id']);
            $table->dropForeign(['customer_id']);
            $table->dropForeign(['decision_maker_id']);
            $table->dropForeign(['lead_id']);
            $table->dropForeign(['status_id']);

            $table->foreign('source_id')->references('id')->on('lead_sources')->nullOnDelete();
            $table->foreign('customer_id')->references('id')->on('accounts')->nullOnDelete();
            $table->foreign('decision_maker_id')->references('id')->on('contacts')->nullOnDelete();
            $table->foreign('lead_id')->references('id')->on('leads')->nullOnDelete();
            $table->foreign('status_id')->references('id')->on('opportunity_statuses')->nullOnDelete();
        });

        Schema::table('opportunity_products', function (Blueprint $table) {
            $table->unsignedInteger('qty')->nullable()->default(0)->change();
            $table->decimal('price', 19, 2)->nullable()->default(0)->change();
            $table->decimal('total', 19, 2)->nullable()->default(0)->change();

            $table->dropForeign(['product_id']);
            $table->dropForeign(['opportunity_id']);

            $table->foreign('product_id')->references('id')->on('products')->cascadeOnDelete();
            $table->foreign('opportunity_id')->references('id')->on('opportunities')->cascadeOnDelete();
        });

        Schema::table('opportunity_quotation_histories', function (Blueprint $table) {
            $table->dropForeign(['opportunity_id']);

            $table->foreign('opportunity_id')->references('id')->on('opportunities')->cascadeOnDelete();
        });

        Schema::table('opportunity_teams', function (Blueprint $table) {
            $table->dropForeign(['opportunity_id']);

            $table->foreign('opportunity_id')->references('id')->on('opportunities')->cascadeOnDelete();
        });

        Schema::table('opportunity_contacts', function (Blueprint $table) {
            $table->dropForeign(['contact_id']);
            $table->dropForeign(['opportunity_id']);

            $table->foreign('contact_id')->references('id')->on('contacts')->nullOnDelete();
            $table->foreign('opportunity_id')->references('id')->on('opportunities')->cascadeOnDelete();
        });

        Schema::table('opportunity_competitors', function (Blueprint $table) {
            $table->dropForeign(['opportunity_id']);

            $table->foreign('opportunity_id')->references('id')->on('opportunities')->cascadeOnDelete();
        });

        Schema::table('opportunity_status_histories', function (Blueprint $table) {
            $table->dropForeign(['opportunity_id']);
            $table->dropForeign(['status_id']);

            $table->foreign('opportunity_id')->references('id')->on('opportunities')->cascadeOnDelete();
            $table->foreign('status_id')->references('id')->on('opportunity_statuses')->nullOnDelete();
        });

        Schema::table('opportunity_term_conditions', function (Blueprint $table) {
            $table->dropForeign(['opportunity_id']);

            $table->foreign('opportunity_id')->references('id')->on('opportunities')->cascadeOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('opportunity_term_conditions', function (Blueprint $table) {
            $table->dropForeign(['opportunity_id']);

            $table->foreign('opportunity_id')->references('id')->on('opportunities');
        });

        Schema::table('opportunity_status_histories', function (Blueprint $table) {
            $table->dropForeign(['opportunity_id']);
            $table->dropForeign(['status_id']);

            $table->foreign('opportunity_id')->references('id')->on('opportunities');
            $table->foreign('status_id')->references('id')->on('opportunity_statuses');
        });

        Schema::table('opportunity_competitors', function (Blueprint $table) {
            $table->dropForeign(['opportunity_id']);

            $table->foreign('opportunity_id')->references('id')->on('opportunities');
        });

        Schema::table('opportunity_contacts', function (Blueprint $table) {
            $table->dropForeign(['contact_id']);
            $table->dropForeign(['opportunity_id']);

            $table->foreign('contact_id')->references('id')->on('contacts');
            $table->foreign('opportunity_id')->references('id')->on('opportunities');
        });

        Schema::table('opportunity_teams', function (Blueprint $table) {
            $table->dropForeign(['opportunity_id']);

            $table->foreign('opportunity_id')->references('id')->on('opportunities');
        });

        Schema::table('opportunity_quotation_histories', function (Blueprint $table) {
            $table->dropForeign(['opportunity_id']);

            $table->foreign('opportunity_id')->references('id')->on('opportunities');
        });
        
        Schema::table('opportunity_products', function (Blueprint $table) {
            $table->unsignedInteger('qty')->default(0)->change();
            $table->decimal('price', 19, 2)->default(0)->change();
            $table->decimal('total', 19, 2)->default(0)->change();

            $table->dropForeign(['product_id']);
            $table->dropForeign(['opportunity_id']);

            $table->foreign('product_id')->references('id')->on('products');
            $table->foreign('opportunity_id')->references('id')->on('opportunities');
        });

        Schema::table('opportunities', function (Blueprint $table) {
            $table->dropForeign(['source_id']);
            $table->dropForeign(['customer_id']);
            $table->dropForeign(['decision_maker_id']);
            $table->dropForeign(['lead_id']);
            $table->dropForeign(['status_id']);

            $table->foreign('source_id')->references('id')->on('lead_sources');
            $table->foreign('customer_id')->references('id')->on('accounts');
            $table->foreign('decision_maker_id')->references('id')->on('contacts');
            $table->foreign('lead_id')->references('id')->on('leads');
            $table->foreign('status_id')->references('id')->on('opportunity_statuses');
        });
    }
};