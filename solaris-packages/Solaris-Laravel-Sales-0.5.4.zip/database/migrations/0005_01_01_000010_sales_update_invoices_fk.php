<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('invoices', function (Blueprint $table) {
            $table->decimal('amount', 19, 2)->nullable()->default(0)->change();

            $table->dropForeign(['account_id']);
            $table->dropForeign(['contact_id']);
            $table->dropForeign(['order_id']);
            $table->dropForeign(['status_id']);

            $table->foreign('account_id')->references('id')->on('accounts')->nullOnDelete();
            $table->foreign('contact_id')->references('id')->on('contacts')->nullOnDelete();
            $table->foreign('order_id')->references('id')->on('orders')->nullOnDelete();
            $table->foreign('status_id')->references('id')->on('invoice_statuses')->nullOnDelete();
        });

        Schema::table('invoice_details', function (Blueprint $table) {
            $table->dropForeign(['product_id']);
            $table->dropForeign(['invoice_id']);

            $table->foreign('product_id')->references('id')->on('products')->cascadeOnDelete();
            $table->foreign('invoice_id')->references('id')->on('invoices')->cascadeOnDelete();
        });

        Schema::table('invoice_status_histories', function (Blueprint $table) {
            $table->dropForeign(['invoice_id']);
            $table->dropForeign(['status_id']);

            $table->foreign('invoice_id')->references('id')->on('invoices')->cascadeOnDelete();
            $table->foreign('status_id')->references('id')->on('invoice_statuses')->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('invoice_status_histories', function (Blueprint $table) {
            $table->dropForeign(['invoice_id']);
            $table->dropForeign(['status_id']);

            $table->foreign('invoice_id')->references('id')->on('invoices');
            $table->foreign('status_id')->references('id')->on('invoice_statuses');
        });

        Schema::table('invoice_details', function (Blueprint $table) {
            $table->dropForeign(['product_id']);
            $table->dropForeign(['invoice_id']);

            $table->foreign('product_id')->references('id')->on('products');
            $table->foreign('invoice_id')->references('id')->on('invoices');
        });

        Schema::table('invoices', function (Blueprint $table) {
            $table->decimal('amount', 19, 2)->default(0)->change();

            $table->dropForeign(['account_id']);
            $table->dropForeign(['contact_id']);
            $table->dropForeign(['order_id']);
            $table->dropForeign(['status_id']);

            $table->foreign('account_id')->references('id')->on('accounts');
            $table->foreign('contact_id')->references('id')->on('contacts');
            $table->foreign('order_id')->references('id')->on('orders');
            $table->foreign('status_id')->references('id')->on('invoice_statuses');
        });
    }
};
