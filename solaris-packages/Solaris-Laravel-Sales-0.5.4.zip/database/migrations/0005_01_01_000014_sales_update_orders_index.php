<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('orders', function (Blueprint $table) {
            if (config('database.default') === 'pgsql') {
                $table->dropIndex('orders_account_id_foreign');
                $table->dropIndex('orders_contact_id_foreign');
                $table->dropIndex('orders_opportunity_id_foreign');
                $table->dropIndex('orders_status_id_foreign');
            }

            MigrationHelper::createIndexIfNeeds($table, ['account_id']);
            MigrationHelper::createIndexIfNeeds($table, ['contact_id']);
            MigrationHelper::createIndexIfNeeds($table, ['opportunity_id']);
            MigrationHelper::createIndexIfNeeds($table, ['status_id']);
        });

        Schema::table('order_details', function (Blueprint $table) {
            if (config('database.default') === 'pgsql') {
                $table->dropIndex('order_details_product_id_foreign');
                $table->dropIndex('order_details_order_id_foreign');
            }

            MigrationHelper::createIndexIfNeeds($table, ['product_id']);
            MigrationHelper::createIndexIfNeeds($table, ['order_id']);
        });

        Schema::table('order_status_histories', function (Blueprint $table) {
            if (config('database.default') === 'pgsql') {
                $table->dropIndex('order_status_histories_order_id_foreign');
                $table->dropIndex('order_status_histories_status_id_foreign');
            }

            MigrationHelper::createIndexIfNeeds($table, ['order_id']);
            MigrationHelper::createIndexIfNeeds($table, ['status_id']);
        });
    }

    public function down(): void
    {
        Schema::table('order_status_histories', function (Blueprint $table) {
            MigrationHelper::dropIndexIfNeeds($table, ['order_id']);
            MigrationHelper::dropIndexIfNeeds($table, ['status_id']);

            if (config('database.default') === 'pgsql') {
                $table->index('order_id', 'order_status_histories_order_id_foreign');
                $table->index('status_id', 'order_status_histories_status_id_foreign');
            }
        });

        Schema::table('order_details', function (Blueprint $table) {
            MigrationHelper::dropIndexIfNeeds($table, ['product_id']);
            MigrationHelper::dropIndexIfNeeds($table, ['order_id']);

            if (config('database.default') === 'pgsql') {
                $table->index('product_id', 'order_details_product_id_foreign');
                $table->index('order_id', 'order_details_order_id_foreign');
            }
        });

        Schema::table('orders', function (Blueprint $table) {
            MigrationHelper::dropIndexIfNeeds($table, ['account_id']);
            MigrationHelper::dropIndexIfNeeds($table, ['contact_id']);
            MigrationHelper::dropIndexIfNeeds($table, ['opportunity_id']);
            MigrationHelper::dropIndexIfNeeds($table, ['status_id']);

            if (config('database.default') === 'pgsql') {
                $table->index('account_id', 'orders_account_id_foreign');
                $table->index('contact_id', 'orders_contact_id_foreign');
                $table->index('opportunity_id', 'orders_opportunity_id_foreign');
                $table->index('status_id', 'orders_status_id_foreign');
            }
        });
    }
};
