<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('activities', function (Blueprint $table) {
            $table->dropForeign(['opportunity_id']);
            $table->dropForeign(['order_id']);
            $table->dropForeign(['invoice_id']);

            $table->foreign('opportunity_id')->references('id')->on('opportunities')->nullOnDelete();
            $table->foreign('order_id')->references('id')->on('orders')->nullOnDelete();
            $table->foreign('invoice_id')->references('id')->on('invoices')->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('activities', function (Blueprint $table) {
            $table->dropForeign(['opportunity_id']);
            $table->dropForeign(['order_id']);
            $table->dropForeign(['invoice_id']);

            $table->foreign('opportunity_id')->references('id')->on('opportunities');
            $table->foreign('order_id')->references('id')->on('orders');
            $table->foreign('invoice_id')->references('id')->on('invoices');
        });
    }
};
