<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('activities', function (Blueprint $table) {
            if (config('database.default') === 'pgsql') {
                $table->dropIndex('activities_opportunity_id_foreign');
                $table->dropIndex('activities_order_id_foreign');
                $table->dropIndex('activities_invoice_id_foreign');
            }

            MigrationHelper::createIndexIfNeeds($table, ['opportunity_id']);
            MigrationHelper::createIndexIfNeeds($table, ['order_id']);
            MigrationHelper::createIndexIfNeeds($table, ['invoice_id']);
        });
    }

    public function down(): void
    {
        Schema::table('activities', function (Blueprint $table) {
            MigrationHelper::dropIndexIfNeeds($table, ['opportunity_id']);
            MigrationHelper::dropIndexIfNeeds($table, ['order_id']);
            MigrationHelper::dropIndexIfNeeds($table, ['invoice_id']);

            if (config('database.default') === 'pgsql') {
                $table->index('opportunity_id', 'activities_opportunity_id_foreign');
                $table->index('order_id', 'activities_order_id_foreign');
                $table->index('invoice_id', 'activities_invoice_id_foreign');
            }
        });
    }
};
