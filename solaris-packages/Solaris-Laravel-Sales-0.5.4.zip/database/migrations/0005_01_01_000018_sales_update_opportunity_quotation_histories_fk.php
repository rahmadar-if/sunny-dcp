<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
	public function up(): void
	{
		Schema::table('opportunity_quotation_histories', function (Blueprint $table) {
			$table->foreignUuid('attachment_id')->nullable()->constrained('attachments')->nullOnDelete();

			MigrationHelper::createIndexIfNeeds($table, ['attachment_id']);
		});
	}

	public function down(): void
	{
		Schema::table('opportunity_quotation_histories', function (Blueprint $table) {
			$table->dropForeign(['attachment_id']);

			MigrationHelper::dropIndexIfNeeds($table, ['attachment_id']);

			$table->dropColumn('attachment_id');
		});
	}
};
