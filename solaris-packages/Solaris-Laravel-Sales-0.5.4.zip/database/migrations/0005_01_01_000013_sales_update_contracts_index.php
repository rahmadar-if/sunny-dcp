<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Migration as MigrationHelper;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('contracts', function (Blueprint $table) {
            if (config('database.default') === 'pgsql') {
                $table->dropIndex('contracts_account_id_foreign');
                $table->dropIndex('contracts_contact_id_foreign');
            }

            MigrationHelper::createIndexIfNeeds($table, ['account_id']);
            MigrationHelper::createIndexIfNeeds($table, ['contact_id']);
        });
    }

    public function down(): void
    {
        Schema::table('contracts', function (Blueprint $table) {
            MigrationHelper::dropIndexIfNeeds($table, ['account_id']);
            MigrationHelper::dropIndexIfNeeds($table, ['contact_id']);

            if (config('database.default') === 'pgsql') {
                $table->index('account_id', 'contracts_account_id_foreign');
                $table->index('contact_id', 'contracts_contact_id_foreign');
            }
        });
    }
};
