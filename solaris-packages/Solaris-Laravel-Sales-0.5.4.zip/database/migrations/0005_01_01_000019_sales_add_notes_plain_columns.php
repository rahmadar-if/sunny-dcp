<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Solaris\Core\Helpers\Helper;

return new class extends Migration
{
    private const TABLES = ['opportunities', 'orders', 'invoices', 'contracts'];

    public function up(): void
    {
        foreach (self::TABLES as $table) {
            Schema::table($table, function (Blueprint $t) {
                $t->text('notes_plain')->nullable()->after('notes');
            });
        }

        if (config('database.default') === 'pgsql') {
            foreach (self::TABLES as $table) {
                Schema::table($table, function (Blueprint $t) {
                    $t->fullText(['notes_plain'])->language(Helper::fullTextLanguage());
                });
            }
        }
    }

    public function down(): void
    {
        if (config('database.default') === 'pgsql') {
            foreach (self::TABLES as $table) {
                Schema::table($table, function (Blueprint $t) {
                    $t->dropFullText(['notes_plain']);
                });
            }
        }

        foreach (self::TABLES as $table) {
            Schema::table($table, function (Blueprint $t) {
                $t->dropColumn('notes_plain');
            });
        }
    }
};
