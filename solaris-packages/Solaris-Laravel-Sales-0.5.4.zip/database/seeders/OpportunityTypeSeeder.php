<?php

namespace Solaris\Sales\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Solaris\Sales\Const\OpportunityTypeConst;

class OpportunityTypeSeeder extends Seeder
{
    public function run(): void
    {
        $this->opportunity_types();
    }

    protected function opportunity_types(): void
    {
        $data = [
            [
                'id'       => OpportunityTypeConst::NewBusiness,
                'name'     => 'New Business',
                'position' => 1,
            ],
            [
                'id'       => OpportunityTypeConst::RepeatOrder,
                'name'     => 'Repeat Order',
                'position' => 2,
            ],
            [
                'id'       => OpportunityTypeConst::UpsellCross,
                'name'     => 'Upsell / Cross',
                'position' => 3,
            ],
            [
                'id'       => OpportunityTypeConst::Tender,
                'name'     => 'Tender',
                'position' => 4,
            ]
        ];
        DB::table('opportunity_types')->insertOrIgnore($data);
    }
}