<?php

namespace Solaris\Sales\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Solaris\Sales\Const\InvoiceStatusConst;

class InvoiceSeeder extends Seeder
{
    public function run(): void
    {
        $this->invoice_statuses();
    }

    protected function invoice_statuses(): void
    {
        $data = [
            [
                'id'             => InvoiceStatusConst::Draft,
                'name'           => 'Draft',
                'color'          => 'primary',
                'position'       => 1,
                "group_id"       => null,
                'is_final_stage' => false
            ],
            [
                'id'             => InvoiceStatusConst::Issued,
                'name'           => 'Issued',
                'color'          => 'info',
                'position'       => 2,
                "group_id"       => null,
                'is_final_stage' => false
            ],
            [
                'id'             => InvoiceStatusConst::Completed,
                'name'           => 'Completed',
                'color'          => 'success',
                'position'       => 3,
                "group_id"       => null,
                'is_final_stage' => true
            ],
            [
                'id'             => InvoiceStatusConst::Cancel,
                'name'           => 'Cancel',
                'color'          => 'danger',
                'position'       => 4,
                "group_id"       => InvoiceStatusConst::Completed,
                'is_final_stage' => true
            ],
        ];
        DB::table('invoice_statuses')->insertOrIgnore($data);
    }
}