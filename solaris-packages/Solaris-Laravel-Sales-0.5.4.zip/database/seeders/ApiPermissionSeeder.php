<?php

namespace Solaris\Sales\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use Solaris\Core\Models\Permission;
use Solaris\Core\Models\Role;

// One role per entity. "API - Lead" is owned by BaseCRM's own ApiPermissionSeeder — this only
// adds the pipeline action on top, into the same role (firstOrCreate by name, safe regardless
// of which package seeds first).
class ApiPermissionSeeder extends Seeder
{
    protected const GROUP = 'integration';

    public function run(): void
    {
        $this->seedEntity('API - Lead', [
            'api.lead.prospect' => 'API — promote a lead to an opportunity',
        ]);

        $this->seedEntity('API - Opportunity', [
            'api.opportunity.view'          => 'API — read opportunities',
            'api.opportunity.create'        => 'API — create opportunities',
            'api.opportunity.update'        => 'API — update opportunities',
            'api.opportunity.delete'        => 'API — delete opportunities',
            'api.opportunity.update-status' => 'API — change opportunity stage',
        ]);

        $this->seedEntity('API - Order', [
            'api.order.view'          => 'API — read orders',
            'api.order.create'        => 'API — create orders',
            'api.order.update'        => 'API — update orders',
            'api.order.delete'        => 'API — delete orders',
            'api.order.update-status' => 'API — change order stage',
        ]);

        $this->seedEntity('API - Invoice', [
            'api.invoice.view'          => 'API — read invoices',
            'api.invoice.create'        => 'API — create invoices',
            'api.invoice.update'        => 'API — update invoices',
            'api.invoice.delete'        => 'API — delete invoices',
            'api.invoice.update-status' => 'API — change invoice stage',
        ]);
    }

    protected function seedEntity(string $roleName, array $permissions): void
    {
        foreach ($permissions as $name => $description) {
            Permission::firstOrCreate(
                ['name' => $name],
                [
                    'id'          => (string) Str::uuid7(),
                    'group_name'  => self::GROUP,
                    'description' => $description,
                ]
            );
        }

        $role = Role::firstOrCreate(
            ['name' => $roleName],
            [
                'id'         => (string) Str::uuid7(),
                'group_name' => self::GROUP,
            ]
        );

        $role->assignPermission(array_keys($permissions));
    }
}
