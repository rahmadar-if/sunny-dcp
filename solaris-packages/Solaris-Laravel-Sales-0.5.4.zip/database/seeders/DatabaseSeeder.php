<?php

namespace Solaris\Sales\Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            OpportunitySeeder::class,
            OrderSeeder::class,
            InvoiceSeeder::class,
            MenuSeeder::class,
            CodeGeneratorSeeder::class,
            OpportunityTypeSeeder::class,
            AiRegistrySeeder::class,
            AiScopedToolSeeder::class,
            ApiPermissionSeeder::class,
        ]);
    }
}