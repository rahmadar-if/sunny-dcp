<?php

namespace Solaris\Sales\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Solaris\Core\Models\Menu;

class MenuSeeder extends Seeder
{
    public function run(): void
    {
        $this->dashboard();
        $this->sales();
    }

    protected function dashboard(): void
    {
        $dashboardId = Menu::select('id')
            ->where('name', 'Dashboard')
            ->whereHas('category', fn($query) => $query->where('name', 'Main'))
            ->first()
            ->id;

        $data = [
            [
                'id'          => "019ac81e-bf04-780f-a13f-c1e2a57c076f",
                'name'        => 'Sales',
                'position'    => 1,
                'url'         => "sales/dashboard",
                'route_name'  => "sales.dashboard",
                'icon'        => null,
                'is_category' => false,
                'parent_id'   => $dashboardId,
                'category_id' => null,
            ]
        ];

        DB::table('menus')->insertOrIgnore($data);

        $menu = Menu::find("019ac81e-bf04-780f-a13f-c1e2a57c076f");
        $menu?->assignRole('User');
    }

    protected function sales(): void
    {
        $crmModuleCategoryId = "019ac81e-bf04-7034-883e-4af75966562d";
        $salesId             = "019ac81e-bf04-7d46-93c5-866be0136c31";

        $data = [
            [
                'id'          => $salesId,
                'name'        => 'Sales',
                'position'    => 1,
                'url'         => null,
                'route_name'  => null,
                'icon'        => 'bx bx-lock',
                'is_category' => false,
                'parent_id'   => null,
                'category_id' => $crmModuleCategoryId,
            ],
            [
                'id'          => "019ac81e-bf04-7891-8193-47b6cfc0cc98",
                'name'        => 'Lead',
                'position'    => 1,
                'url'         => '/sales/lead',
                'route_name'  => 'sales.lead',
                'icon'        => null,
                'is_category' => false,
                'parent_id'   => $salesId,
                'category_id' => null,
            ],
            [
                'id'          => "019ac81e-bf04-7511-8c2b-4fe024d6c1f2",
                'name'        => 'Opportunity',
                'position'    => 2,
                'url'         => '/sales/opportunity',
                'route_name'  => 'sales.opportunity',
                'icon'        => null,
                'is_category' => false,
                'parent_id'   => $salesId,
                'category_id' => null,
            ],
            [
                'id'          => "019ac81e-bf04-7528-bd0a-ab696d97204a",
                'name'        => 'Order',
                'position'    => 3,
                'url'         => '/sales/order',
                'route_name'  => 'sales.order',
                'icon'        => null,
                'is_category' => false,
                'parent_id'   => $salesId,
                'category_id' => null,
            ],
            [
                'id'          => "019ac81e-bf04-7d8d-98e8-e009796b0115",
                'name'        => 'Contract',
                'position'    => 4,
                'url'         => '/sales/contract',
                'route_name'  => 'sales.contract',
                'icon'        => null,
                'is_category' => false,
                'parent_id'   => $salesId,
                'category_id' => null,
            ],
            [
                'id'          => "019ac81e-bf04-75c4-9067-7229c4a41711",
                'name'        => 'Invoice',
                'position'    => 5,
                'url'         => '/sales/invoice',
                'route_name'  => 'sales.invoice',
                'icon'        => null,
                'is_category' => false,
                'parent_id'   => $salesId,
                'category_id' => null,
            ]
        ];

        DB::table('menus')->insertOrIgnore($data);

        $menuAccess = Menu::whereIn('id', 
            array_map(
                fn($item) => $item['id'], 
                array_filter($data, fn($item) => !$item['is_category'] && !empty($item['url']))
            )
        )
        ->get();

        foreach($menuAccess as $menu) {
            $menu->assignRole('User');
        }
    }
}
