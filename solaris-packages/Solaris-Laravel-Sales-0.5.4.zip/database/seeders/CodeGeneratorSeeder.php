<?php

namespace Solaris\Sales\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CodeGeneratorSeeder extends Seeder
{
    public function run(): void
    {
        $this->order_invoice_number();
        $this->quotation_number();
    }

    protected function order_invoice_number(): void
    {
       $code_generators = [
            [
                'id'     => '019d2e5f-7e71-72d4-a534-d0db8f86d548',
                'code'   => 'orders',
                'column' => 'number',
                'mask'   => 'ORD-{0:000}',
                'active' => true,
            ],
            [
                'id'     => '019d2e5f-de89-719a-ab93-51814ff08d5e',
                'code'   => 'invoices',
                'column' => 'number',
                'mask'   => 'INV-{0:000}',
                'active' => true,
            ],
        ];

        DB::table('code_generators')->insertOrIgnore($code_generators);
    }

    protected function quotation_number(): void
    {
        $code_generators = [
            [
                'id'     => 'c83cc116-38cb-4f84-8682-741c2be57eb8',
                'code'   => 'opportunity_quotation_histories',
                'column' => 'number_quotation',
                'mask'   => 'QUO-{YYYY}{MM}{0:00000}',
                'active' => true,
            ],
        ];

        DB::table('code_generators')->insertOrIgnore($code_generators);
    }
}
