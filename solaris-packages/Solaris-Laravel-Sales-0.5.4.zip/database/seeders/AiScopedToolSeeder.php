<?php

namespace Solaris\Sales\Database\Seeders;

use Illuminate\Database\Seeder;
use Solaris\Core\Models\AiAgent;
use Solaris\Core\Models\AiTool;

// Scoped tool wiring for the agents this package owns — see the MasterData seeder of the same name for
// the reasoning. Sales and Order both only ever reference an account or contact (to fill a customer_id
// or a decision maker), never analyse one; the customer specialist keeps the full tools.
class AiScopedToolSeeder extends Seeder
{
    // 'activity' is a MasterData agent, but search_opportunity_basic is a Sales tool — wiring lives with
    // whoever owns the TOOL, matching how AiRegistrySeeder here already grants activity its cross-module
    // search access.
    protected array $grant = [
        'sales'    => ['search_account_basic', 'search_contact_basic', 'search_product_basic'],
        'order'    => ['search_account_basic', 'search_contact_basic', 'search_product_basic', 'search_opportunity_basic'],
        'activity' => ['search_opportunity_basic'],
    ];

    protected array $revoke = [
        'sales'    => ['search_account', 'search_contact', 'search_product'],
        'order'    => ['search_account', 'search_contact', 'search_product', 'search_opportunity'],
        'activity' => ['search_opportunity'],
    ];

    public function run(): void
    {
        $this->grantScopedTools();
        $this->revokeSupersededTools();
    }

    protected function grantScopedTools(): void
    {
        foreach ($this->grant as $agentSlug => $toolSlugs) {
            AiAgent::where('slug', $agentSlug)->first()
                ?->attachTools(AiTool::whereIn('slug', $toolSlugs)->pluck('id')->all());
        }
    }

    protected function revokeSupersededTools(): void
    {
        foreach ($this->revoke as $agentSlug => $toolSlugs) {
            AiAgent::where('slug', $agentSlug)->first()
                ?->detachTools(AiTool::whereIn('slug', $toolSlugs)->pluck('id')->all());
        }
    }
}
