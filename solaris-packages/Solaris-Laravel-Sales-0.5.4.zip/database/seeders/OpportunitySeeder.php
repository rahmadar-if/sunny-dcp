<?php

namespace Solaris\Sales\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Solaris\Sales\Const\OpportunityStatusConst;

class OpportunitySeeder extends Seeder
{
    public function run(): void
    {
        $this->opportunity_statuses();
    }

    protected function opportunity_statuses(): void
    {
        $data = [
            [
                'id'             => OpportunityStatusConst::Qualification,
                'name'           => 'Qualification',
                'position'       => 1,
                'color'          => "primary",
                "group_id"       => null,
                "probability"    => 20,
                'is_final_stage' => false
            ],
            [
                'id'             => OpportunityStatusConst::Proposal,
                'name'           => 'Proposal',
                'position'       => 2,
                'color'          => "info",
                "group_id"       => null,
                "probability"    => 45,
                'is_final_stage' => false
            ],
            [
                'id'             => OpportunityStatusConst::Negotiation,
                'name'           => 'Negotiation',
                'position'       => 3,
                'color'          => "warning",
                "group_id"       => null,
                "probability"    => 80,
                'is_final_stage' => false
            ],
            [
                'id'             => OpportunityStatusConst::ClosedWon,
                'name'           => 'Closed Won',
                'position'       => 4,
                'color'          => "success",
                "group_id"       => null,
                "probability"    => 100,
                'is_final_stage' => true
            ],
            [
                'id'             => OpportunityStatusConst::ClosedLost,
                'name'           => 'Closed Lost',
                'position'       => 5,
                'color'          => "danger",
                'is_final_stage' => true,
                "probability"    => 0,
                "group_id"       => OpportunityStatusConst::ClosedWon
            ],
        ];
        DB::table('opportunity_statuses')->insertOrIgnore($data);
    }
}