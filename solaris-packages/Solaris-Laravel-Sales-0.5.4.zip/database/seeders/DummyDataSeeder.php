<?php

namespace Solaris\Sales\Database\Seeders;

use Carbon\Carbon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Auth;
use Solaris\BaseCRM\Const\AccountStatusConst;
use Solaris\BaseCRM\Const\ActivityResultConst;
use Solaris\BaseCRM\Const\AnnualRevenueConst;
use Solaris\BaseCRM\Const\BudgetRangeConst;
use Solaris\BaseCRM\Const\BusinessSizeConst;
use Solaris\BaseCRM\Const\ContactStatusConst;
use Solaris\BaseCRM\Const\CustomerJourneyConst;
use Solaris\BaseCRM\Const\DisqualificationReasonConst;
use Solaris\BaseCRM\Const\FrequencyConst;
use Solaris\BaseCRM\Const\LeadRegistrationMethodConst;
use Solaris\BaseCRM\Const\LeadSourceConst;
use Solaris\BaseCRM\Const\LeadStatusConst;
use Solaris\BaseCRM\Const\NoteworthyEventTypeConst;
use Solaris\BaseCRM\Const\SegmentationConst;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Const\AccountTypeConst;
use Solaris\MasterData\Const\ActivityCategoryConst;
use Solaris\MasterData\Const\ActivityPriorityConst;
use Solaris\MasterData\Const\ActivityStatusConst;
use Solaris\MasterData\Const\AddressTypeConst;
use Solaris\MasterData\Const\BusinessEntityConst;
use Solaris\MasterData\Const\CommunicationTypeConst;
use Solaris\MasterData\Const\EducationConst;
use Solaris\Core\Const\GenderConst;
use Solaris\MasterData\Const\IndustryConst;
use Solaris\MasterData\Const\KnowledgeBaseTypeConst;
use Solaris\MasterData\Const\MaritalStatusConst;
use Solaris\MasterData\Const\NumberOfEmployeeConst;
use Solaris\MasterData\Const\PreferredLanguageConst;
use Solaris\MasterData\Const\ProductTypeConst;
use Solaris\Core\Const\ReligionConst;
use Solaris\MasterData\Const\RelatedContactCategoryConst;
use Solaris\MasterData\Const\ReminderTypeConst;
use Solaris\Core\Const\SalutationConst;
use Solaris\Sales\Const\InvoiceStatusConst;
use Solaris\Sales\Const\OpportunityStatusConst;
use Solaris\Sales\Const\OpportunityTypeConst;
use Solaris\Sales\Const\OrderStatusConst;

// Dummy end-to-end AI-testing dataset — Account/Contact (MasterData/BaseCRM) through
// Lead/Opportunity/Order/Invoice (Sales), with their detail sub-records. Uses each model's own
// Repository (never raw DB inserts / bare Model::create) so every business rule already wired into
// these repos runs for real: BaseCRM's Account/Contact status force-Draft-then-progress history,
// KnowledgeBase's force-Draft, notes_plain HTML-strip sync, and — critically for Sales — Opportunity/
// Order/Invoice's auto amount/total computation and auto detail-row cloning (see OrderRepository::
// created(), InvoiceRepository::created(), OpportunityProductRepository::updateOpportunityAmount()).
// Run with: php artisan db:seed --class="Solaris\\Sales\\Database\\Seeders\\DummyDataSeeder"
// Deliberately NOT wired into Sales' own DatabaseSeeder — this is a large one-off dummy dataset for
// AI testing, not part of the normal lookup-only seed flow that runs on every deploy.
class DummyDataSeeder extends Seeder
{
	private \Faker\Generator $faker;

	private array $users = [];          // active, email-verified users — created_by is randomized from this pool
	private array $accounts = [];       // all created Account models
	private array $accountsWithContact = [];
	private array $contacts = [];       // all created Contact models
	private array $products = [];       // all created Product models
	private array $leads = [];          // all created Lead models
	private array $qualifiedLeads = []; // leads promoted through to Qualified, used to spin up Opportunities
	private array $opportunities = [];  // all created Opportunity models
	private array $wonOpportunities = []; // subset that become Orders
	private array $orders = [];         // all created Order models
	private array $invoicedOrders = []; // subset that become Invoices
	private array $invoices = [];       // all created Invoice models

	private const COMPANY_CORE = [
		'Sumber', 'Karya', 'Mitra', 'Cipta', 'Bumi', 'Cahaya', 'Duta', 'Graha', 'Prima',
		'Global', 'Nusantara', 'Sejahtera', 'Bina', 'Panca', 'Sinar', 'Multi', 'Maju',
		'Andalan', 'Cendana', 'Kencana', 'Wahana', 'Anugerah', 'Sentosa', 'Rimba', 'Buana',
	];

	private const COMPANY_NOUN = [
		'Makmur', 'Jaya', 'Abadi', 'Mandiri', 'Utama', 'Sejati', 'Perkasa', 'Digital',
		'Teknologi', 'Logistik', 'Nusantara', 'Persada', 'Selaras', 'Berkah', 'Kreasi',
		'Solusi', 'Indotama', 'Sentra', 'Niaga', 'Raya', 'Semesta', 'Pratama', 'Prakarsa',
	];

	private const COMPANY_SUFFIX = ['', '', '', ' Group', ' Indonesia', ' Nusantara'];

	private const JOB_TITLES = [
		'Direktur Utama', 'Direktur Operasional', 'General Manager', 'Manager Pembelian',
		'Manager Keuangan', 'Manager Pemasaran', 'Kepala Divisi IT', 'Kepala Gudang',
		'Staff Admin', 'Staff Pembelian', 'Supervisor Operasional', 'Business Development Manager',
		'Procurement Officer', 'Finance Officer', 'Owner', 'Wakil Direktur', 'HR Manager',
		'Account Executive', 'Sales Manager', 'Kepala Cabang',
	];

	private const PRODUCT_BANK = [
		'Barang Elektronik' => ['Laptop Bisnis 14"', 'Printer Laser Kantor', 'Monitor LED 24"', 'UPS 1200VA', 'Access Point WiFi 6'],
		'Perangkat Lunak / Software' => ['Lisensi ERP Modul Keuangan (per user/tahun)', 'Lisensi Antivirus Enterprise', 'Lisensi CRM Cloud (per user/bulan)', 'Aplikasi Payroll'],
		'Jasa Konsultasi' => ['Konsultasi Implementasi Sistem', 'Audit Proses Bisnis', 'Pelatihan Karyawan (per sesi)', 'Jasa Migrasi Data'],
		'Layanan IT' => ['Paket Maintenance Server (bulanan)', 'Layanan Cloud Hosting (tahunan)', 'Layanan Backup & Disaster Recovery', 'Managed Network Service'],
		'Furnitur Kantor' => ['Meja Kerja Kantor', 'Kursi Ergonomis', 'Lemari Arsip Besi', 'Partisi Ruang Kerja'],
		'Peralatan Kantor' => ['Mesin Fotokopi Multifungsi', 'Mesin Absensi Fingerprint', 'Proyektor Ruang Meeting', 'Telepon PABX'],
		'Bahan Baku Industri' => ['Plat Besi Lembaran', 'Pipa Baja Galvanis', 'Kabel Listrik NYY', 'Resin Industri'],
		'Otomotif & Armada' => ['Paket Sewa Kendaraan Operasional (bulanan)', 'Jasa Perawatan Armada', 'GPS Tracker Kendaraan'],
	];

	private const KB_ARTICLES = [
		['FAQ Umum Penggunaan Sistem CRM', KnowledgeBaseTypeConst::FAQ],
		['Cara Reset Password Akun', KnowledgeBaseTypeConst::FAQ],
		['Panduan Input Data Akun Baru', KnowledgeBaseTypeConst::Guide],
		['Panduan Membuat Penawaran (Quotation)', KnowledgeBaseTypeConst::Guide],
		['Panduan Alur Kualifikasi Lead', KnowledgeBaseTypeConst::Guide],
		['Dokumentasi Modul Opportunity', KnowledgeBaseTypeConst::Documentation],
		['Dokumentasi Struktur Data Invoice', KnowledgeBaseTypeConst::Documentation],
		['FAQ Kebijakan Diskon Penjualan', KnowledgeBaseTypeConst::FAQ],
		['Panduan Konversi Lead ke Opportunity', KnowledgeBaseTypeConst::Guide],
		['Dokumentasi Integrasi WhatsApp AI', KnowledgeBaseTypeConst::Documentation],
		['FAQ Status Pembayaran Invoice', KnowledgeBaseTypeConst::FAQ],
		['Panduan Pengelolaan Kontak Perusahaan', KnowledgeBaseTypeConst::Guide],
		['Dokumentasi Modul Order & Pengiriman', KnowledgeBaseTypeConst::Documentation],
		['FAQ Cara Menghubungi Tim Support', KnowledgeBaseTypeConst::FAQ],
		['Panduan Segmentasi Pelanggan', KnowledgeBaseTypeConst::Guide],
		['Dokumentasi Kebijakan Retensi Data', KnowledgeBaseTypeConst::Documentation],
		['FAQ Perubahan Status Lead Disqualified', KnowledgeBaseTypeConst::FAQ],
		['Panduan Penjadwalan Aktivitas Sales', KnowledgeBaseTypeConst::Guide],
		['Dokumentasi API Pencarian Data', KnowledgeBaseTypeConst::Documentation],
		['FAQ Pengaturan Reminder Aktivitas', KnowledgeBaseTypeConst::FAQ],
	];

	// Faker's Lorem provider (realText/sentence/paragraph) is NOT locale-aware — it always emits
	// pseudo-Latin "lorem ipsum"-style filler regardless of the 'id_ID' factory locale. Every
	// user-visible free-text field below is picked from these curated Indonesian banks instead.
	private const CUSTOMER_NEEDS = [
		'Membutuhkan solusi untuk otomatisasi proses pencatatan penjualan yang masih manual.',
		'Ingin upgrade sistem lama yang sudah tidak didukung ke versi terbaru.',
		'Mencari vendor untuk pengadaan perangkat kantor dalam jumlah besar.',
		'Membutuhkan pelatihan tambahan untuk tim setelah implementasi awal.',
		'Tertarik memperluas kapasitas gudang dengan sistem manajemen inventori.',
		'Perlu solusi terintegrasi antara sistem keuangan dan penjualan.',
		'Sedang mengevaluasi beberapa vendor untuk kebutuhan digitalisasi arsip.',
		'Membutuhkan dukungan teknis 24 jam untuk operasional yang berjalan non-stop.',
		'Ingin migrasi data dari sistem lama tanpa mengganggu operasional harian.',
		'Mencari solusi hemat biaya untuk kebutuhan armada kendaraan operasional.',
	];

	private const GENERIC_NOTES = [
		'Klien cukup responsif, follow up berkala disarankan.',
		'Perlu koordinasi lebih lanjut dengan tim internal klien.',
		'Sudah pernah menggunakan produk kompetitor sebelumnya.',
		'Keputusan biasanya diambil oleh level direksi.',
		'Anggaran masih dalam proses persetujuan internal.',
		'Sangat mengutamakan kecepatan respon dan layanan purna jual.',
		'Lokasi cukup jauh, pertimbangkan biaya pengiriman/kunjungan.',
		'Kontak lebih nyaman dihubungi di luar jam kerja.',
	];

	private const KB_PARAGRAPHS = [
		'Dokumen ini menjelaskan alur kerja standar yang berlaku di dalam sistem, mulai dari tahap awal input data hingga proses akhir pelaporan.',
		'Setiap pengguna disarankan untuk memahami peran dan tanggung jawab masing-masing sebelum menjalankan proses terkait di dalam sistem.',
		'Perubahan status akan tercatat secara otomatis pada riwayat data, sehingga tim terkait dapat memantau perkembangan setiap tahapan.',
		'Untuk pertanyaan lebih lanjut, pengguna dapat menghubungi tim internal terkait atau merujuk pada dokumentasi tambahan yang tersedia.',
		'Pastikan seluruh data wajib sudah terisi dengan benar sebelum melanjutkan ke tahap berikutnya agar proses berjalan lancar.',
		'Fitur ini dirancang untuk mempermudah koordinasi antar divisi dalam menangani data pelanggan maupun transaksi penjualan.',
	];

	private const COMPETITOR_STRENGTHS = [
		'Harga penawaran lebih kompetitif', 'Sudah punya hubungan lama dengan klien',
		'Waktu pengiriman lebih cepat', 'Nama besar di industri ini',
	];

	private const COMPETITOR_WEAKNESSES = [
		'Dukungan purna jual kurang responsif', 'Kualitas produk kurang konsisten',
		'Harga lebih mahal dibanding kami', 'Portofolio pengalaman masih terbatas',
	];

	private const ACTIVITY_SUBJECTS = [
		ActivityCategoryConst::Call => ['Follow up telepon kebutuhan produk', 'Konfirmasi jadwal meeting', 'Follow up status penawaran', 'Cek kepuasan pelanggan'],
		ActivityCategoryConst::Visit => ['Kunjungan survey kebutuhan', 'Kunjungan presentasi produk', 'Kunjungan tindak lanjut kontrak', 'Kunjungan after-sales'],
		ActivityCategoryConst::Meeting => ['Meeting presentasi solusi', 'Meeting negosiasi harga', 'Meeting internal review akun', 'Meeting kickoff proyek'],
		ActivityCategoryConst::Email => ['Kirim proposal via email', 'Kirim reminder pembayaran', 'Kirim brosur produk', 'Balas pertanyaan teknis'],
		ActivityCategoryConst::ToDo => ['Siapkan dokumen penawaran', 'Update data akun di sistem', 'Review kontrak sebelum kirim', 'Rekap laporan mingguan'],
	];

	public function run(): void
	{
		$this->faker = \Faker\Factory::create('id_ID');

		$this->collectUsers();
		$this->randomLoginUser();

		$this->fixLeadSourceGap();

		$this->seedAccounts();
		$this->seedContacts();
		$this->seedProducts();
		$this->seedKnowledgeBases();
		$this->seedLeads();
		$this->seedOpportunities();
		$this->seedOrders();
		$this->seedInvoices();
		$this->seedActivities();

		Auth::logout();
	}

	private function repo(string $key)
	{
		$modelClass      = Helper::model($key);
		// activity_reminder has a model key but no repository entry in any package's config — falls
		// back to the same generic BaseRepository every other unregistered detail table already uses.
		$repositoryClass = Helper::repository($key) ?? \Solaris\Core\Repositories\BaseRepository::class;

		return new $repositoryClass(new $modelClass());
	}

	// ---------------------------------------------------------------------
	// created_by attribution — no dedicated admin, every record is attributed
	// to a random pick from the pool of real, already-onboarded users (active +
	// email verified) instead. Re-rolled per record so created_by varies across
	// the whole dataset rather than pinning everything to one account.
	// ---------------------------------------------------------------------
	private function collectUsers(): void
	{
		$userModel = Helper::model('user');

		$this->users = $userModel::where('is_active', true)
			->whereNotNull('email_verified_at')
			->get()
			->all();

		if (empty($this->users)) {
			throw new \RuntimeException('No active, email-verified users found — seed users before running DummyDataSeeder.');
		}
	}

	private function randomLoginUser(): void
	{
		Auth::login($this->users[array_rand($this->users)]);
	}

	// LeadSourceConst::Website exists but BaseCRM's own LeadSeeder never inserts the row — found
	// during research, fixed here rather than silently working around it.
	private function fixLeadSourceGap(): void
	{
		$leadSourceModel = Helper::model('lead_source');

		$leadSourceModel::firstOrCreate(
			['id' => LeadSourceConst::Website],
			['name' => 'Website', 'position' => 6]
		);
	}

	private function randomDateIn2026(string $bucket = 'any'): Carbon
	{
		return match ($bucket) {
			'early'   => Carbon::create(2026, rand(1, 2), rand(1, 28)),
			'current' => Carbon::create(2026, 7, 21)->addDays(rand(-25, 10)),
			'future'  => Carbon::create(2026, rand(9, 12), rand(1, 28)),
			default   => Carbon::create(2026, rand(1, 12), rand(1, 28)),
		};
	}

	private function companyName(): string
	{
		$core   = self::COMPANY_CORE[array_rand(self::COMPANY_CORE)];
		$noun   = self::COMPANY_NOUN[array_rand(self::COMPANY_NOUN)];
		$suffix = self::COMPANY_SUFFIX[array_rand(self::COMPANY_SUFFIX)];

		return "{$core} {$noun}{$suffix}";
	}

	// 3-tier completeness: full/partial/minimal, weighted 35/40/25 — used everywhere to decide how
	// many optional fields get populated on a given record.
	private function completenessTier(): string
	{
		$roll = rand(1, 100);

		return match (true) {
			$roll <= 35 => 'full',
			$roll <= 75 => 'partial',
			default     => 'minimal',
		};
	}

	private function maybe(string $tier, int $fullChance = 100, int $partialChance = 50): bool
	{
		$chance = match ($tier) {
			'full'    => $fullChance,
			'partial' => $partialChance,
			default   => 0,
		};

		return rand(1, 100) <= $chance;
	}

	private function shortHtmlNote(): string
	{
		$picks = collect(self::GENERIC_NOTES)->random(rand(1, 2));

		return '<p>' . $picks->implode(' ') . '</p>';
	}

	// =========================================================================
	// ACCOUNTS (50)
	// =========================================================================
	private function seedAccounts(): void
	{
		$repo              = $this->repo('account');
		$industryIds       = array_values((array) (new \ReflectionClass(IndustryConst::class))->getConstants());
		$typeWeighted = array_merge(
			array_fill(0, 35, AccountTypeConst::Customer),
			array_fill(0, 10, AccountTypeConst::Partner),
			array_fill(0, 5, AccountTypeConst::Competitor),
		);

		// Employee count / annual revenue / business size must move together — a company can't be
		// "1-100 employees" AND "revenue > 1 trillion" at the same time. One weighted size tier (0 =
		// smallest .. 5 = largest, skewed toward smaller companies) drives all three whenever they're
		// populated, instead of rolling each independently.
		$employeeTiers = [
			NumberOfEmployeeConst::OneTo100, NumberOfEmployeeConst::HundredOneTo500,
			NumberOfEmployeeConst::FiveHundredOneTo1000, NumberOfEmployeeConst::ThousandOneTo5000,
			NumberOfEmployeeConst::FiveThousandOneTo10000, NumberOfEmployeeConst::MoreThan10000,
		];
		$revenueTiers = [
			AnnualRevenueConst::ZeroToFiveBillion, AnnualRevenueConst::FiveToTenBillion,
			AnnualRevenueConst::TenToOneHundredBillion, AnnualRevenueConst::OneHundredToFiveHundredBillion,
			AnnualRevenueConst::FiveHundredBillionToOneTrillion, AnnualRevenueConst::MoreThanOneTrillion,
		];
		$sizeTierWeighted = array_merge(
			array_fill(0, 35, 0), array_fill(0, 25, 1), array_fill(0, 15, 2),
			array_fill(0, 12, 3), array_fill(0, 8, 4), array_fill(0, 5, 5),
		);

		for ($i = 0; $i < 50; $i++) {
			$this->randomLoginUser();
			$tier     = $this->completenessTier();
			$name     = $this->companyName();
			$sizeTier = $sizeTierWeighted[array_rand($sizeTierWeighted)];

			$data = [
				'name'          => $name,
				'type_id'       => $typeWeighted[array_rand($typeWeighted)],
				'primary_phone' => $this->faker->numerify('021-####-###'),
				'email'         => 'info@' . \Illuminate\Support\Str::slug($name, '') . '.co.id',
				'industry_id'   => $industryIds[array_rand($industryIds)],
			];

			if ($this->maybe($tier, 90, 60)) {
				$data['website'] = 'https://www.' . \Illuminate\Support\Str::slug($name, '') . '.co.id';
			}
			if ($this->maybe($tier, 80, 40)) {
				$data['category'] = $this->faker->randomElement(['Retail', 'Manufaktur', 'Distributor', 'Jasa Konsultasi', 'Teknologi', 'Konstruksi', 'Trading']);
			}
			if ($this->maybe($tier, 70, 20)) {
				$data['business_entity_id'] = $this->faker->randomElement([BusinessEntityConst::PT, BusinessEntityConst::CV, BusinessEntityConst::UD]);
			}
			if ($this->maybe($tier, 70, 20)) {
				$data['number_of_employee_id'] = $employeeTiers[$sizeTier];
			}
			if ($this->maybe($tier, 60, 20)) {
				$data['notes'] = $this->shortHtmlNote();
			}

			$account = $repo->create($data);

			// BaseCRM's Account::booted() force-sets status_id to PersonalInformation on creating —
			// any other stage has to be reached via a follow-up update() so the stage-history sync
			// (HasStageHistory) fires and records a real transition, not a fabricated initial value.
			$statusRoll = rand(1, 100);
			$updateData = [];
			if ($statusRoll > 85) {
				$updateData['status_id'] = AccountStatusConst::Approve;
			} elseif ($statusRoll > 60) {
				$updateData['status_id'] = AccountStatusConst::Verification;
			} elseif ($statusRoll > 35) {
				$updateData['status_id'] = AccountStatusConst::Draft;
			}

			if ($this->maybe($tier, 70, 30)) {
				$updateData['annual_revenue_id'] = $revenueTiers[$sizeTier];
			}
			if ($this->maybe($tier, 60, 25)) {
				$updateData['segmentation_id'] = $this->faker->randomElement([SegmentationConst::VIP, SegmentationConst::Gold, SegmentationConst::Bronze, SegmentationConst::Silver]);
			}
			if ($this->maybe($tier, 60, 25)) {
				// Tier 0-1 (<=500 employees, <=10B revenue) reads as SMB; tier 2-5 as LargeEnterprise —
				// kept in lockstep with $employeeTiers/$revenueTiers above via the same $sizeTier roll.
				$updateData['business_size_id'] = $sizeTier <= 1 ? BusinessSizeConst::SMB : BusinessSizeConst::LargeEnterprise;
			}
			if ($this->maybe($tier, 50, 20)) {
				$updateData['customer_journey_id'] = $this->faker->randomElement([
					CustomerJourneyConst::NewCustomer, CustomerJourneyConst::Customer,
					CustomerJourneyConst::ValuesAndBeliefs, CustomerJourneyConst::Loyalty, CustomerJourneyConst::Advocate,
				]);
			}
			if ($this->maybe($tier, 40, 15)) {
				$updateData['monetary']    = $this->faker->numberBetween(5_000_000, 500_000_000);
				$updateData['frequency']   = $this->faker->numberBetween(1, 24);
				$updateData['frequency_type_id'] = $this->faker->randomElement([FrequencyConst::Days, FrequencyConst::Weeks, FrequencyConst::Months, FrequencyConst::Years]);
				$updateData['recency_date'] = $this->randomDateIn2026()->format('Y-m-d');
			}

			if (!empty($updateData)) {
				$account = $repo->update($account->id, $updateData);
			}

			// AccountBank (~40%) and AccountAddress (~50%), independent of contact/status variety.
			if (rand(1, 100) <= 40) {
				$bankRepo = $this->repo('account_bank');
				for ($b = 0; $b < rand(1, 2); $b++) {
					$bankRepo->create([
						'account_id'     => $account->id,
						'bank_name'      => $this->faker->randomElement(['BCA', 'Mandiri', 'BNI', 'BRI', 'CIMB Niaga', 'Permata']),
						'account_number' => $this->faker->numerify('##########'),
						'account_name'   => $name,
					]);
				}
			}

			if (rand(1, 100) <= 50) {
				$addressRepo = $this->repo('account_address');
				$addressRepo->create([
					'account_id'      => $account->id,
					'address'         => $this->faker->address(),
					'postcode'        => $this->faker->postcode(),
					'address_type_id' => AddressTypeConst::Business,
				]);
			}

			$this->accounts[] = $account;
		}

		// 70% of accounts get at least one contact, 30% stay orphan (no contact at all).
		$shuffled = $this->accounts;
		shuffle($shuffled);
		$this->accountsWithContact = array_slice($shuffled, 0, 35);
	}

	// =========================================================================
	// CONTACTS (100)
	// =========================================================================
	private function seedContacts(): void
	{
		$repo = $this->repo('contact');

		// Distribute ~85 contacts across the 35 "with contact" accounts, ~15 standalone.
		$accountBuckets = [];
		foreach ($this->accountsWithContact as $account) {
			$accountBuckets[$account->id] = 1; // every account gets at least 1
		}
		$remaining = 85 - count($this->accountsWithContact);
		while ($remaining > 0) {
			$account = $this->accountsWithContact[array_rand($this->accountsWithContact)];
			$accountBuckets[$account->id]++;
			$remaining--;
		}

		$queue = [];
		foreach ($accountBuckets as $accountId => $count) {
			for ($i = 0; $i < $count; $i++) {
				$queue[] = $accountId;
			}
		}
		for ($i = 0; $i < 15; $i++) {
			$queue[] = null; // standalone contact
		}
		shuffle($queue);

		$accountPrimaryCandidate = []; // accountId => [contact ids]

		foreach ($queue as $accountId) {
			$this->randomLoginUser();
			$tier   = $this->completenessTier();
			$gender = $this->faker->randomElement([GenderConst::Male, GenderConst::Female]);
			$name   = $gender === GenderConst::Male ? $this->faker->firstNameMale() . ' ' . $this->faker->lastName() : $this->faker->firstNameFemale() . ' ' . $this->faker->lastName();

			$data = [
				'name'                 => $name,
				// Always set — $gender is already what generated $name above, so gender_id must never
				// be left to a "maybe" skip (a skipped column can fall back to a DB default that
				// contradicts the name, e.g. a female name landing on a Male default).
				'gender_id'            => $gender,
				'primary_phone'        => $this->faker->numerify('021-####-###'),
				'primary_mobile_phone' => $this->faker->numerify('08##########'),
				'account_id'           => $accountId,
			];

			if ($this->maybe($tier, 90, 50)) {
				$data['email'] = \Illuminate\Support\Str::slug($name, '.') . '@' . ($this->faker->boolean(70) ? 'gmail.com' : 'yahoo.com');
			}
			if ($accountId !== null && $this->maybe($tier, 90, 60)) {
				$data['job_title'] = self::JOB_TITLES[array_rand(self::JOB_TITLES)];
			}

			$contact = $repo->create($data);

			// Same force-then-progress technique as Account for ContactStatus variety.
			$statusRoll = rand(1, 100);
			$updateData = [];
			if ($statusRoll > 85) {
				$updateData['status_id'] = ContactStatusConst::Approve;
			} elseif ($statusRoll > 60) {
				$updateData['status_id'] = ContactStatusConst::Verification;
			} elseif ($statusRoll > 35) {
				$updateData['status_id'] = ContactStatusConst::Draft;
			}

			if ($this->maybe($tier, 50, 15)) {
				$updateData['religion_id'] = $this->faker->randomElement([
					ReligionConst::Islam, ReligionConst::Protestan, ReligionConst::Katolik,
					ReligionConst::Hindu, ReligionConst::Buddha, ReligionConst::Khonghucu,
				]);
			}
			if ($this->maybe($tier, 40, 10)) {
				$updateData['marital_status_id'] = $this->faker->randomElement([MaritalStatusConst::Single, MaritalStatusConst::Married]);
			}
			if ($this->maybe($tier, 40, 10)) {
				$updateData['salutation_id'] = $gender === GenderConst::Male
					? $this->faker->randomElement([SalutationConst::Mr, SalutationConst::Dr])
					: $this->faker->randomElement([SalutationConst::Ms, SalutationConst::Mrs, SalutationConst::Dr]);
			}
			if ($this->maybe($tier, 35, 10)) {
				$updateData['education_id'] = $this->faker->randomElement([
					EducationConst::SMA_SMK, EducationConst::D3, EducationConst::D4,
					EducationConst::S1, EducationConst::S2, EducationConst::S3,
				]);
			}
			if ($this->maybe($tier, 30, 10)) {
				$updateData['preferred_language_id'] = $this->faker->randomElement([PreferredLanguageConst::English, PreferredLanguageConst::BahasaIndonesia]);
			}
			if ($this->maybe($tier, 30, 10)) {
				// Real NPWP format (XX.XXX.XXX.X-XXX.XXX) is 20 chars — column is varchar(16), so
				// plain 15-digit numeric (no separators) is used instead to fit.
				$updateData['npwp'] = $this->faker->numerify('###############');
			}
			if ($this->maybe($tier, 30, 10)) {
				$updateData['no_ktp'] = $this->faker->numerify('################');
			}
			if ($this->maybe($tier, 40, 15)) {
				$updateData['segmentation_id'] = $this->faker->randomElement([SegmentationConst::VIP, SegmentationConst::Gold, SegmentationConst::Bronze, SegmentationConst::Silver]);
			}
			if ($this->maybe($tier, 30, 10)) {
				$updateData['birth_date'] = $this->faker->dateTimeBetween('-55 years', '-22 years')->format('Y-m-d');
			}

			if (!empty($updateData)) {
				$contact = $repo->update($contact->id, $updateData);
			}

			if ($accountId !== null) {
				$accountPrimaryCandidate[$accountId][] = $contact->id;

				if (rand(1, 100) <= 30) {
					$this->repo('contact_address')->create([
						'contact_id'      => $contact->id,
						'address'         => $this->faker->address(),
						'postcode'        => $this->faker->postcode(),
						'address_type_id' => AddressTypeConst::Home,
					]);
				}
				if (rand(1, 100) <= 25) {
					$this->repo('contact_communication')->create([
						'contact_id' => $contact->id,
						'type_id'    => $this->faker->randomElement([CommunicationTypeConst::Instagram, CommunicationTypeConst::Facebook, CommunicationTypeConst::Email, CommunicationTypeConst::Website]),
						'value'      => '@' . \Illuminate\Support\Str::slug($name),
					]);
				}
				if (rand(1, 100) <= 15) {
					$this->repo('contact_hobby')->create([
						'contact_id' => $contact->id,
						'hobby'      => $this->faker->randomElement(['Golf', 'Badminton', 'Membaca', 'Fotografi', 'Traveling', 'Kuliner', 'Otomotif']),
					]);
				}
				if (rand(1, 100) <= 10) {
					$this->repo('contact_noteworthy_event')->create([
						'contact_id' => $contact->id,
						'type_id'    => $this->faker->randomElement([NoteworthyEventTypeConst::Birthday, NoteworthyEventTypeConst::Event, NoteworthyEventTypeConst::Other]),
						'date'       => $this->randomDateIn2026()->format('Y-m-d'),
						'notes'      => $this->faker->randomElement(['Perayaan bersama keluarga', 'Acara internal perusahaan', 'Pengingat tahunan', 'Catatan tambahan dari tim sales']),
					]);
				}
				if (rand(1, 100) <= 15 && count($this->accounts) > 1) {
					// "Previous company" has to be an account OTHER than where the contact currently
					// works — pointing it at $accountId itself claimed someone's past employer was
					// their current one, which isn't a real employment history.
					do {
						$previousAccount = $this->accounts[array_rand($this->accounts)];
					} while ($previousAccount->id === $accountId);

					$this->repo('contact_previous_company')->create([
						'contact_id' => $contact->id,
						'account_id' => $previousAccount->id,
						'active'     => false,
						'role'       => self::JOB_TITLES[array_rand(self::JOB_TITLES)],
						'start_date' => $this->faker->dateTimeBetween('-8 years', '-2 years')->format('Y-m-d'),
						'end_date'   => $this->faker->dateTimeBetween('-2 years', '-1 years')->format('Y-m-d'),
					]);
				}
			}

			$this->contacts[] = $contact;
		}

		// Related-contact links (~10 pairs among standalone/family-like contacts).
		$pool = $this->contacts;
		for ($i = 0; $i < 10 && count($pool) > 1; $i++) {
			$a = array_rand($pool);
			$b = array_rand($pool);
			if ($a === $b) {
				continue;
			}
			$this->repo('related_contact')->create([
				'contact_id'         => $pool[$a]->id,
				'related_contact_id' => $pool[$b]->id,
				'category_id'        => $this->faker->randomElement([RelatedContactCategoryConst::Spouse, RelatedContactCategoryConst::Child, RelatedContactCategoryConst::Friend]),
			]);
		}

		// Assign primary_contact_id on ~20 of the accounts-with-contact.
		$withCandidates = array_slice(array_keys($accountPrimaryCandidate), 0, 20);
		foreach ($withCandidates as $accountId) {
			$contactId = $accountPrimaryCandidate[$accountId][0];
			$this->repo('account')->update($accountId, ['primary_contact_id' => $contactId]);
		}
	}

	// =========================================================================
	// PRODUCTS (25)
	// =========================================================================
	private function seedProducts(): void
	{
		$repo = $this->repo('product');
		$pool = [];
		foreach (self::PRODUCT_BANK as $category => $names) {
			foreach ($names as $name) {
				$pool[] = [$category, $name];
			}
		}
		shuffle($pool);
		$pool = array_slice($pool, 0, 25);

		// Top up if the curated bank has fewer than 25 combinations.
		while (count($pool) < 25) {
			$category = array_rand(self::PRODUCT_BANK);
			$name     = self::PRODUCT_BANK[$category][array_rand(self::PRODUCT_BANK[$category])];
			$pool[]   = [$category, $name . ' ' . $this->faker->randomElement(['Varian A', 'Varian B', 'Edisi Baru', 'Model Lanjutan'])];
		}

		foreach ($pool as [$category, $name]) {
			$this->randomLoginUser();
			$tier = $this->completenessTier();

			$isService = str_contains($category, 'Jasa') || str_contains($category, 'Layanan');
			$typeId    = $isService ? ProductTypeConst::Services : $this->faker->randomElement([ProductTypeConst::Goods, ProductTypeConst::GoodsAndServices]);

			$data = [
				'name'            => $name,
				'type_id'         => $typeId,
				'unit_of_measure' => $isService ? $this->faker->randomElement(['paket', 'sesi', 'bulan', 'tahun']) : $this->faker->randomElement(['unit', 'pcs', 'box']),
				'category'        => $category,
				'active'          => rand(1, 100) <= 85,
				'price'           => $this->faker->numberBetween(150_000, 45_000_000),
			];

			if ($this->maybe($tier, 80, 40)) {
				$data['sku_number'] = strtoupper(\Illuminate\Support\Str::random(3)) . '-' . $this->faker->numerify('####');
			}
			if ($this->maybe($tier, 70, 30)) {
				$data['brand'] = $this->faker->randomElement(['Solaris', 'Nexa', 'Meridian', 'Artha', 'Zenith', 'Cakra', null]) ?? $this->faker->company();
			}
			if ($this->maybe($tier, 50, 20)) {
				$data['product_description'] = $this->faker->randomElement([
					'Cocok untuk kebutuhan operasional harian skala kecil hingga menengah.',
					'Dirancang untuk mendukung efisiensi kerja tim dengan biaya perawatan rendah.',
					'Sudah teruji digunakan oleh berbagai perusahaan di berbagai industri.',
					'Termasuk dukungan teknis dasar selama masa garansi berlaku.',
				]);
			}
			if ($this->maybe($tier, 40, 15)) {
				$data['notes'] = $this->shortHtmlNote();
			}

			$product = $repo->create($data);

			if (!$isService && rand(1, 100) <= 40) {
				$this->repo('product_feature')->create([
					'product_id' => $product->id,
					'name'       => $this->faker->randomElement(['Garansi 1 Tahun', 'Gratis Instalasi', 'Support 24/7', 'Termasuk Training']),
				]);
			}
			if (!$isService && rand(1, 100) <= 30) {
				$this->repo('product_availability')->create([
					'product_id' => $product->id,
					'warehouse'  => $this->faker->randomElement(['Gudang Jakarta', 'Gudang Surabaya', 'Gudang Bandung']),
					'qty'        => $this->faker->numberBetween(5, 500),
				]);
			}
			if (rand(1, 100) <= 25) {
				$this->repo('product_price_history')->create([
					'product_id' => $product->id,
					'price'      => $data['price'] * 0.9,
					'from'       => $this->randomDateIn2026('early'),
					'end'        => $this->randomDateIn2026('current'),
				]);
			}

			$this->products[] = $product;
		}
	}

	// =========================================================================
	// KNOWLEDGE BASE (20)
	// =========================================================================
	private function seedKnowledgeBases(): void
	{
		$repo = $this->repo('knowledge_base');

		foreach (self::KB_ARTICLES as [$name, $typeId]) {
			$this->randomLoginUser();
			$paragraphs = collect(self::KB_PARAGRAPHS)->random(rand(2, 3));
			$article    = $paragraphs->map(fn ($p) => "<p>{$p}</p>")->implode('');

			$kb = $repo->create([
				'name'    => $name,
				'type_id' => $typeId,
				'article' => $article,
			]);

			// KnowledgeBase::booted() forces status_id = Draft on creating — publish ~60% via update.
			if (rand(1, 100) <= 60) {
				$repo->update($kb->id, ['status_id' => \Solaris\MasterData\Const\KnowledgeBaseStatusConst::Published]);
			}
		}
	}

	// =========================================================================
	// LEADS (100)
	// =========================================================================
	private function seedLeads(): void
	{
		$repo = $this->repo('lead');

		$sourceIds = [
			LeadSourceConst::Email, LeadSourceConst::Call, LeadSourceConst::SocialMedia,
			LeadSourceConst::Referral, LeadSourceConst::Website, LeadSourceConst::Event,
		];
		$registrationIds = [
			LeadRegistrationMethodConst::ManualEntry, LeadRegistrationMethodConst::WebForm,
			LeadRegistrationMethodConst::API, LeadRegistrationMethodConst::ChatBot, LeadRegistrationMethodConst::ImportExcel,
		];
		$industryIds = array_values((array) (new \ReflectionClass(IndustryConst::class))->getConstants());

		// Status distribution target: New 40, Nurturing 30, Qualified 20, Disqualified 10.
		$statusPlan = array_merge(
			array_fill(0, 40, LeadStatusConst::New),
			array_fill(0, 30, LeadStatusConst::Nurturing),
			array_fill(0, 20, LeadStatusConst::Qualified),
			array_fill(0, 10, LeadStatusConst::Disqualified),
		);
		shuffle($statusPlan);

		for ($i = 0; $i < 100; $i++) {
			$this->randomLoginUser();
			$tier        = $this->completenessTier();
			$targetStatus = $statusPlan[$i];

			// Linkage mix: ~50% existing account+contact, ~30% company-name-only prospect, ~20% brand new individual.
			$linkRoll  = rand(1, 100);
			$account   = null;
			$contact   = null;
			$data      = [
				'name'                   => null,
				'source_id'              => $sourceIds[array_rand($sourceIds)],
				'registration_method_id' => $registrationIds[array_rand($registrationIds)],
				'date'                   => $this->randomDateIn2026()->format('Y-m-d'),
				'customer_need'          => $this->faker->randomElement(self::CUSTOMER_NEEDS),
			];

			if ($linkRoll <= 50) {
				$account = $this->accountsWithContact[array_rand($this->accountsWithContact)];
				// Contact must actually belong to $account — picking from the whole contact pool let a
				// Lead reference an account and a contact that work at entirely different companies.
				$accountContacts = array_values(array_filter($this->contacts, fn ($c) => $c->account_id === $account->id));
				$contact          = $this->faker->randomElement($accountContacts);
				$data['name']         = $contact->name . ' - ' . $account->name;
				$data['account_id']   = $account->id;
				$data['contact_id']   = $contact->id;
				$data['phone']        = $contact->primary_mobile_phone;
				$data['email']        = $contact->email ?? $this->faker->safeEmail();
			} elseif ($linkRoll <= 80) {
				$companyName = $this->companyName();
				$data['name']         = 'Prospek ' . $companyName;
				$data['account_name'] = $companyName;
				$data['is_new_account'] = true;
				$data['phone']        = $this->faker->numerify('08##########');
				$data['email']        = $this->faker->safeEmail();
			} else {
				$personName = $this->faker->name();
				$data['name']          = $personName;
				$data['contact_name']  = $personName;
				$data['contact_job_title'] = self::JOB_TITLES[array_rand(self::JOB_TITLES)];
				$data['is_new_contact'] = true;
				$data['phone']        = $this->faker->numerify('08##########');
				$data['email']        = $this->faker->safeEmail();
			}

			if ($this->maybe($tier, 70, 30)) {
				$data['segmentation_id'] = $this->faker->randomElement([SegmentationConst::VIP, SegmentationConst::Gold, SegmentationConst::Bronze, SegmentationConst::Silver]);
			}
			if ($this->maybe($tier, 60, 25)) {
				$data['industry_id'] = $industryIds[array_rand($industryIds)];
			}
			if ($this->maybe($tier, 50, 20)) {
				$data['budget_range_id'] = $this->faker->randomElement([
					BudgetRangeConst::Under10M, BudgetRangeConst::From10MTo50M, BudgetRangeConst::From50MTo100M,
					BudgetRangeConst::From100MTo500M, BudgetRangeConst::From500MTo1B, BudgetRangeConst::From1BTo5B, BudgetRangeConst::Above5B,
				]);
			}
			if ($this->maybe($tier, 40, 15)) {
				$data['notes'] = $this->shortHtmlNote();
			}

			$lead = $repo->create($data);

			// Progress through the pipeline via sequential updates so each stage leaves a real
			// lead_status_history row instead of faking a single jump. LeadRepository::updating()
			// throws if trying to reach Qualified without an account or contact on file.
			if (in_array($targetStatus, [LeadStatusConst::Nurturing, LeadStatusConst::Qualified, LeadStatusConst::Disqualified], true)) {
				$repo->update($lead->id, ['status_id' => LeadStatusConst::Nurturing]);
			}

			if ($targetStatus === LeadStatusConst::Qualified) {
				if (empty($lead->account_id) && empty($lead->contact_id)) {
					// Can't reach Qualified without a linked party — attach an existing account.
					$fallback = $this->accountsWithContact[array_rand($this->accountsWithContact)];
					$lead     = $repo->update($lead->id, ['account_id' => $fallback->id]);
				}
				$lead = $repo->update($lead->id, ['status_id' => LeadStatusConst::Qualified]);
				$this->qualifiedLeads[] = $lead;
			} elseif ($targetStatus === LeadStatusConst::Disqualified) {
				$lead = $repo->update($lead->id, [
					'status_id'                    => LeadStatusConst::Disqualified,
					'disqualification_reason_id'   => $this->faker->randomElement([
						DisqualificationReasonConst::NoBudget, DisqualificationReasonConst::WrongSegment,
						DisqualificationReasonConst::NoResponse, DisqualificationReasonConst::ChooseCompetitor,
						DisqualificationReasonConst::BadTiming, DisqualificationReasonConst::IncompleteInfo,
					]),
				]);
			}

			$this->leads[] = $lead;
		}
	}

	// =========================================================================
	// OPPORTUNITIES (50) — ~35 converted from a Qualified Lead, ~15 direct
	// =========================================================================
	private function seedOpportunities(): void
	{
		$repo = $this->repo('opportunity');

		// Status distribution: Qualification 12, Proposal 8, Negotiation 5, ClosedWon 20, ClosedLost 5.
		$statusPlan = array_merge(
			array_fill(0, 12, OpportunityStatusConst::Qualification),
			array_fill(0, 8, OpportunityStatusConst::Proposal),
			array_fill(0, 5, OpportunityStatusConst::Negotiation),
			array_fill(0, 20, OpportunityStatusConst::ClosedWon),
			array_fill(0, 5, OpportunityStatusConst::ClosedLost),
		);
		shuffle($statusPlan);

		$leadPool = $this->qualifiedLeads;
		shuffle($leadPool);

		for ($i = 0; $i < 50; $i++) {
			$this->randomLoginUser();
			$tier         = $this->completenessTier();
			$targetStatus = $statusPlan[$i];
			$fromLead     = $i < 35 && !empty($leadPool);

			if ($fromLead) {
				$lead = array_pop($leadPool);
				$account = !empty($lead->account_id)
					? collect($this->accounts)->firstWhere('id', $lead->account_id)
					: $this->accountsWithContact[array_rand($this->accountsWithContact)];
				$contact = !empty($lead->contact_id) ? collect($this->contacts)->firstWhere('id', $lead->contact_id) : null;

				$data = [
					'name'          => 'Deal ' . $account->name,
					'date'          => Carbon::parse($lead->date)->addDays(rand(1, 10))->format('Y-m-d'),
					'customer_id'   => $account->id,
					'customer_need' => $lead->customer_need,
					'source_id'     => $lead->source_id,
					'lead_id'       => $lead->id,
					'phone'         => $lead->phone,
					'email'         => $lead->email,
				];
				if ($contact) {
					$data['decision_maker_id'] = $contact->id;
				}
			} else {
				$account = $this->accountsWithContact[array_rand($this->accountsWithContact)];
				$accountContacts = array_values(array_filter($this->contacts, fn ($c) => $c->account_id === $account->id));
				$contact = !empty($accountContacts) ? $this->faker->randomElement($accountContacts) : null;
				$data = [
					'name'          => 'Deal ' . $account->name,
					'date'          => $this->randomDateIn2026()->format('Y-m-d'),
					'customer_id'   => $account->id,
					'decision_maker_id' => $contact?->id,
					'customer_need' => $this->faker->randomElement(self::CUSTOMER_NEEDS),
					'source_id'     => $this->faker->randomElement([LeadSourceConst::Referral, LeadSourceConst::Website, LeadSourceConst::Event]),
					'phone'         => $account->primary_phone,
					'email'         => $account->email,
				];
			}

			if ($this->maybe($tier, 70, 30)) {
				$data['type_id'] = $this->faker->randomElement([
					OpportunityTypeConst::NewBusiness, OpportunityTypeConst::RepeatOrder,
					OpportunityTypeConst::UpsellCross, OpportunityTypeConst::Tender,
				]);
			}
			if ($this->maybe($tier, 60, 25)) {
				$data['budget'] = $this->faker->numberBetween(5_000_000, 300_000_000);
			}
			if ($this->maybe($tier, 40, 15)) {
				$data['description'] = collect(self::GENERIC_NOTES)->random(rand(1, 2))->implode(' ');
			}

			$opportunity = $repo->create($data);

			// 1-5 product lines from the catalog — repo auto-recomputes opportunity amount/total.
			$lineCount   = rand(1, 5);
			$productRepo = $this->repo('opportunity_product');
			$chosen      = (array) array_rand($this->products, min($lineCount, count($this->products)));
			foreach ((array) $chosen as $idx) {
				$product = $this->products[$idx];
				$qty     = rand(1, 20);
				$productRepo->create([
					'opportunity_id' => $opportunity->id,
					'product_id'     => $product->id,
					'qty'            => $qty,
					'price'          => $product->price,
					'disc'           => rand(1, 100) <= 30 ? round($product->price * $qty * 0.05, 2) : 0,
				]);
			}

			if ($this->maybe($tier, 60, 25)) {
				$this->repo('opportunity_team')->create([
					'opportunity_id' => $opportunity->id,
					'name'           => $this->faker->name(),
					'role'           => $this->faker->randomElement(['Account Manager', 'Sales Support', 'Presales Engineer']),
				]);
			}
			if (rand(1, 100) <= 30) {
				$this->repo('opportunity_competitor')->create([
					'opportunity_id' => $opportunity->id,
					'name'           => $this->companyName(),
					'total_amount'   => $this->faker->numberBetween(5_000_000, 200_000_000),
					'strength'       => $this->faker->randomElement(self::COMPETITOR_STRENGTHS),
					'weakness'       => $this->faker->randomElement(self::COMPETITOR_WEAKNESSES),
					'rating'         => rand(1, 5),
				]);
			}
			if (rand(1, 100) <= 20) {
				$this->repo('opportunity_term_condition')->create([
					'opportunity_id' => $opportunity->id,
					'subject'        => 'Pembayaran 50% di muka, 50% setelah barang/jasa diterima.',
				]);
			}

			// Progress status (Qualification is already the create-time default).
			if ($targetStatus !== OpportunityStatusConst::Qualification) {
				$opportunity = $repo->update($opportunity->id, ['status_id' => $targetStatus]);

				// OpportunityRepository::updating() auto-stamps closed_on = now() the moment status
				// flips to a final stage (ClosedWon/ClosedLost) — but "now()" is today's real date,
				// unrelated to this opportunity's fictional 2026 timeline. Backdate it close to the
				// opportunity's own date instead, same trick as Invoice's issued_date/completed_at
				// below: the hook only overrides closed_on when status_id is in the SAME call, so a
				// follow-up call without status_id lets this custom value stick. Kept to +1/+2 days so
				// it always lands before Order's date (opportunity date + 3-21 days) once Orders are
				// derived from ClosedWon opportunities.
				if (in_array($targetStatus, [OpportunityStatusConst::ClosedWon, OpportunityStatusConst::ClosedLost], true)) {
					$opportunity = $repo->update($opportunity->id, [
						'closed_on' => Carbon::parse($opportunity->date)->addDays(rand(1, 2))->format('Y-m-d'),
					]);
				}
			}

			// ~60% of non-Qualification opportunities get a printed quotation history logged.
			if ($targetStatus !== OpportunityStatusConst::Qualification && rand(1, 100) <= 60) {
				$this->repo('opportunity_quotation_history')->create([
					'opportunity_id'   => $opportunity->id,
					'number_quotation' => 'QUO-' . $this->faker->numerify('####'),
					'total_amount'     => $opportunity->fresh()->total_amount,
					'date'             => $opportunity->date,
				]);
			}

			$this->opportunities[] = $opportunity->fresh();

			if ($targetStatus === OpportunityStatusConst::ClosedWon) {
				$this->wonOpportunities[] = $opportunity;
			}
		}
	}

	// =========================================================================
	// ORDERS (30) — from ClosedWon opportunities (OrderRepository does almost
	// everything automatically: status, date, account/contact/amount derivation,
	// and cloning opportunity_products into order_details).
	// =========================================================================
	private function seedOrders(): void
	{
		$repo = $this->repo('order');
		$pool = $this->wonOpportunities;
		shuffle($pool);
		$pool = array_slice($pool, 0, 30);

		// Status distribution across the 30 orders: Draft 6, Confirmation 12, Completed 10, Cancel 2.
		$statusPlan = array_merge(
			array_fill(0, 6, OrderStatusConst::Draft),
			array_fill(0, 12, OrderStatusConst::Confirmation),
			array_fill(0, 10, OrderStatusConst::Completed),
			array_fill(0, 2, OrderStatusConst::Cancel),
		);
		shuffle($statusPlan);

		foreach ($pool as $i => $opportunity) {
			$this->randomLoginUser();
			$order = $repo->create(['opportunity_id' => $opportunity->id]);

			// Backdate to a realistic date shortly after the opportunity closed, then progress status.
			$order = $repo->update($order->id, ['date' => Carbon::parse($opportunity->date)->addDays(rand(3, 21))->format('Y-m-d')]);

			$targetStatus = $statusPlan[$i] ?? OrderStatusConst::Draft;
			if ($targetStatus !== OrderStatusConst::Draft) {
				$order = $repo->update($order->id, ['status_id' => $targetStatus]);
			}

			$this->orders[] = $order->fresh();

			if (in_array($targetStatus, [OrderStatusConst::Confirmation, OrderStatusConst::Completed], true)) {
				$this->invoicedOrders[] = $order;
			}
		}
	}

	// =========================================================================
	// INVOICES (20) — from Confirmation/Completed orders (InvoiceRepository
	// again auto-derives account/contact/amount and clones order_details).
	// =========================================================================
	private function seedInvoices(): void
	{
		$repo = $this->repo('invoice');
		$pool = $this->invoicedOrders;
		shuffle($pool);
		$pool = array_slice($pool, 0, 20);

		// Status distribution across the 20 invoices: Draft 4, Issued 8, Completed 6, Cancel 2.
		$statusPlan = array_merge(
			array_fill(0, 4, InvoiceStatusConst::Draft),
			array_fill(0, 8, InvoiceStatusConst::Issued),
			array_fill(0, 6, InvoiceStatusConst::Completed),
			array_fill(0, 2, InvoiceStatusConst::Cancel),
		);
		shuffle($statusPlan);

		foreach ($pool as $i => $order) {
			$this->randomLoginUser();
			$invoice = $repo->create([
				'subject'  => 'Invoice untuk Order ' . $order->number,
				'order_id' => $order->id,
			]);

			$invoice = $repo->update($invoice->id, ['due_date' => Carbon::parse($order->date)->addDays(30)->format('Y-m-d')]);

			$targetStatus = $statusPlan[$i] ?? InvoiceStatusConst::Draft;
			if ($targetStatus !== InvoiceStatusConst::Draft) {
				$invoice = $repo->update($invoice->id, ['status_id' => $targetStatus]);

				// Backdate issued_date/completed_at to something plausible instead of the repo's
				// automatic now() (InvoiceRepository::updating() only sets these when status_id is
				// ALSO present in the same call, so a follow-up call without status_id lets a custom
				// value stick).
				if ($targetStatus === InvoiceStatusConst::Issued) {
					$invoice = $repo->update($invoice->id, ['issued_date' => Carbon::parse($order->date)->addDays(rand(1, 5))->format('Y-m-d')]);
				} elseif ($targetStatus === InvoiceStatusConst::Completed) {
					$invoice = $repo->update($invoice->id, [
						'issued_date'  => Carbon::parse($order->date)->addDays(rand(1, 5))->format('Y-m-d'),
						'completed_at' => Carbon::parse($order->date)->addDays(rand(6, 25))->format('Y-m-d'),
					]);
				}
			}

			$this->invoices[] = $invoice->fresh();
		}
	}

	// =========================================================================
	// ACTIVITIES (100) — seeded LAST so it can freely mix in Lead/Opportunity/
	// Order/Invoice references alongside plain Account/Contact ones.
	// =========================================================================
	private function seedActivities(): void
	{
		$repo = $this->repo('activity');

		// Relation mix: account-only 20, account+contact 20, lead 15, opportunity 15, order 10,
		// invoice 5, none (standalone personal to-do) 15.
		$plan = array_merge(
			array_fill(0, 20, 'account'),
			array_fill(0, 20, 'account_contact'),
			array_fill(0, 15, 'lead'),
			array_fill(0, 15, 'opportunity'),
			array_fill(0, 10, 'order'),
			array_fill(0, 5, 'invoice'),
			array_fill(0, 15, 'none'),
		);
		shuffle($plan);

		// Date spread across all of 2026: ~20 early year, ~30 around "now", ~30 general spread, ~20 later in the year.
		$dateBuckets = array_merge(
			array_fill(0, 20, 'early'),
			array_fill(0, 30, 'current'),
			array_fill(0, 30, 'any'),
			array_fill(0, 20, 'future'),
		);
		shuffle($dateBuckets);

		foreach ($plan as $i => $kind) {
			$this->randomLoginUser();
			$tier     = $this->completenessTier();
			$category = array_rand(self::ACTIVITY_SUBJECTS);
			$subject  = self::ACTIVITY_SUBJECTS[$category][array_rand(self::ACTIVITY_SUBJECTS[$category])];
			$start    = $this->randomDateIn2026($dateBuckets[$i] ?? 'any')->setTime(rand(8, 16), [0, 15, 30, 45][array_rand([0, 15, 30, 45])]);

			$data = [
				'subject'     => $subject,
				'start_date'  => $start->format('Y-m-d H:i:s'),
				'category_id' => $category,
				'priority_id' => $this->faker->randomElement([ActivityPriorityConst::High, ActivityPriorityConst::Medium, ActivityPriorityConst::Low]),
			];

			match ($kind) {
				'account' => $data['account_id'] = $this->accounts[array_rand($this->accounts)]->id,
				'account_contact' => (function () use (&$data) {
					$contact = $this->contacts[array_rand($this->contacts)];
					$data['account_id'] = $contact->account_id;
					$data['contact_id'] = $contact->id;
				})(),
				'lead' => $data['lead_id'] = $this->leads[array_rand($this->leads)]->id,
				'opportunity' => $data['opportunity_id'] = $this->opportunities[array_rand($this->opportunities)]->id,
				'order' => $data['order_id'] = !empty($this->orders) ? $this->orders[array_rand($this->orders)]->id : null,
				'invoice' => $data['invoice_id'] = !empty($this->invoices) ? $this->invoices[array_rand($this->invoices)]->id : null,
				default => null,
			};

			// Whether the activity is already finished, in progress, or still upcoming, based on its date
			// relative to "today" (2026-07-21) — not random, so it stays internally consistent.
			$today = Carbon::create(2026, 7, 21);
			if ($start->lt($today)) {
				$data['status_id'] = ActivityStatusConst::Finish;
				$data['end_date']  = $start->copy()->addMinutes(rand(15, 90))->format('Y-m-d H:i:s');
				$data['result_id'] = $this->faker->randomElement([ActivityResultConst::Completed, ActivityResultConst::ReSchedule, ActivityResultConst::NeedOurProduct]);
				if ($this->maybe($tier, 60, 25)) {
					$data['detail_result'] = $this->faker->randomElement(self::GENERIC_NOTES);
				}
			} elseif ($start->isSameDay($today)) {
				$data['status_id'] = ActivityStatusConst::InProgress;
			} else {
				$data['status_id'] = ActivityStatusConst::OnSchedule;
			}

			if ($this->maybe($tier, 50, 20)) {
				$data['notes'] = $this->shortHtmlNote();
			}

			$activity = $repo->create($data);

			if (rand(1, 100) <= 40) {
				$this->repo('activity_participant')->create([
					'activity_id' => $activity->id,
					'name'        => $this->faker->name(),
					'role'        => $this->faker->randomElement(['Peserta', 'Notulen', 'Pengambil Keputusan']),
				]);
			}
			if ($category === ActivityCategoryConst::Meeting && rand(1, 100) <= 40 && !empty($this->products)) {
				$product = $this->products[array_rand($this->products)];
				$this->repo('activity_promoted_product')->create([
					'activity_id' => $activity->id,
					'product_id'  => $product->id,
					'date'        => $start->format('Y-m-d'),
					'status'      => $this->faker->randomElement(['Tertarik', 'Menunggu Persetujuan', 'Ditolak']),
				]);
			}
			if ($start->gt($today) && rand(1, 100) <= 30) {
				$this->repo('activity_reminder')->create([
					'activity_id' => $activity->id,
					'type_id'     => $this->faker->randomElement([ReminderTypeConst::FifteenMinutes, ReminderTypeConst::ThirtyMinutes, ReminderTypeConst::OneHour, ReminderTypeConst::OneDay]),
				]);
			}
		}
	}
}
