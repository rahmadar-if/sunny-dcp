<?php

namespace Solaris\Sales\Database\Seeders;

use Illuminate\Database\Seeder;
use Solaris\Core\Models\AiAgent;
use Solaris\Core\Models\AiTool;
use Solaris\Core\Models\Permission;
use Solaris\Core\Models\Role;

class AiRegistrySeeder extends Seeder
{
    protected array $roles = [
        'AI Agent Sales' => [
            'id'          => '019fa6cd-3c7f-73a5-b24a-41746004e26c',
            'description' => 'Access to the Sales AI agent — leads and opportunities/deals.',
            'agent'       => 'sales',
            'specialist'  => 'sales_specialist',
        ],
        'AI Agent Order' => [
            'id'          => '019fa6cd-3c7f-73fb-b9f1-78b5b41063ef',
            'description' => 'Access to the Order AI agent — orders, invoices, and contracts.',
            'agent'       => 'order',
            'specialist'  => 'order_specialist',
        ],
    ];

    protected array $permissions = [
        'AI Tool Opportunity Create' => [
            'id'          => '019fa6cd-3c7f-768f-8d53-ac89ece2b4d4',
            'description' => 'Create opportunities and their line items, team, contacts, competitors, and terms via AI.',
            'tools'       => ['create_opportunity', 'create_opportunity_product', 'create_opportunity_team', 'create_opportunity_contact', 'create_opportunity_competitor', 'create_opportunity_term_condition'],
        ],
        'AI Tool Opportunity Update' => [
            'id'          => '019fa6cd-3c7f-7a14-950c-2e5a8e7d9f18',
            'description' => 'Update opportunities and their line items, team, contacts, competitors, and terms via AI.',
            'tools'       => ['update_opportunity', 'update_opportunity_product', 'update_opportunity_team', 'update_opportunity_contact', 'update_opportunity_competitor', 'update_opportunity_term_condition'],
        ],
        'AI Tool Opportunity Delete' => [
            'id'          => '019fa6cd-3c7f-7a36-84b0-147704556bdc',
            'description' => 'Delete opportunities and their line items, team, contacts, competitors, and terms via AI.',
            'tools'       => ['delete_opportunity', 'delete_opportunity_product', 'delete_opportunity_team', 'delete_opportunity_contact', 'delete_opportunity_competitor', 'delete_opportunity_term_condition'],
        ],
        'AI Tool Opportunity Search' => [
            'id'          => '019fa6cd-3c7f-7dce-ba9c-6f0baa00dc70',
            'description' => 'Search opportunities, their details, quotation history, and status history via AI.',
            'tools'       => ['search_opportunity', 'search_opportunity_basic', 'search_opportunity_product', 'search_opportunity_team', 'search_opportunity_contact', 'search_opportunity_competitor', 'search_opportunity_term_condition', 'search_opportunity_quotation_history', 'search_opportunity_status_history'],
        ],
        'AI Tool Print Quotation' => [
            'id'          => '019fa6cd-3c7f-7ecb-aca4-fd00564b4d07',
            'description' => 'Generate/print an opportunity quotation via AI.',
            'tools'       => ['print_quotation'],
        ],
        'AI Tool Order Create' => [
            'id'          => '019fa6cd-3c7f-7437-b211-bf9c2a879d09',
            'description' => 'Create orders and their line items via AI.',
            'tools'       => ['create_order', 'create_order_detail'],
        ],
        'AI Tool Order Update' => [
            'id'          => '019fa6cd-3c7f-7c8d-b433-270ccbf3f2dc',
            'description' => 'Update orders and their line items via AI.',
            'tools'       => ['update_order', 'update_order_detail'],
        ],
        'AI Tool Order Delete' => [
            'id'          => '019fa6cd-3c7f-723c-8c84-1ef64078095a',
            'description' => 'Delete orders and their line items via AI.',
            'tools'       => ['delete_order', 'delete_order_detail'],
        ],
        'AI Tool Order Search' => [
            'id'          => '019fa6cd-3c7f-7516-80f9-1a9c6e7b442b',
            'description' => 'Search orders, their line items, and status history via AI.',
            'tools'       => ['search_order', 'search_order_detail', 'search_order_status_history'],
        ],
        'AI Tool Invoice Create' => [
            'id'          => '019fa6cd-3c7f-7160-822c-dd5d99839cd9',
            'description' => 'Create invoices and their line items via AI.',
            'tools'       => ['create_invoice', 'create_invoice_detail'],
        ],
        'AI Tool Invoice Update' => [
            'id'          => '019fa6cd-3c7f-7670-9012-41d951f0e9f3',
            'description' => 'Update invoices and their line items via AI.',
            'tools'       => ['update_invoice', 'update_invoice_detail'],
        ],
        'AI Tool Invoice Delete' => [
            'id'          => '019fa6cd-3c7f-75a2-9906-2738d1069354',
            'description' => 'Delete invoices and their line items via AI.',
            'tools'       => ['delete_invoice', 'delete_invoice_detail'],
        ],
        'AI Tool Invoice Search' => [
            'id'          => '019fa6cd-3c7f-77ac-9e03-18a553bb7861',
            'description' => 'Search invoices, their line items, and status history via AI.',
            'tools'       => ['search_invoice', 'search_invoice_detail', 'search_invoice_status_history'],
        ],
        'AI Tool Contract Create' => [
            'id'          => '019fa6cd-3c7f-7303-aef3-7e79cebaa4c9',
            'description' => 'Create contracts via AI.',
            'tools'       => ['create_contract'],
        ],
        'AI Tool Contract Update' => [
            'id'          => '019fa6cd-3c7f-7a13-a2ca-b6b859ace67a',
            'description' => 'Update contracts and their body via AI.',
            'tools'       => ['update_contract'],
        ],
        'AI Tool Contract Delete' => [
            'id'          => '019fa6cd-3c7f-77f7-9a4f-08593b2a53dd',
            'description' => 'Delete contracts via AI.',
            'tools'       => ['delete_contract'],
        ],
        'AI Tool Contract Search' => [
            'id'          => '019fa6cd-3c7f-77d7-8242-bc9459efe013',
            'description' => 'Search contracts via AI.',
            'tools'       => ['search_contract'],
        ],

        'AI Tool Hot Lead' => [
            'id'          => '019fa6cd-3c7f-7df2-9aab-1ded63d984dc',
            'description' => 'Identify hot leads via AI.',
            'tools'       => ['hot_lead'],
        ],
        'AI Tool User Search' => [
            'id'          => '8b4264c9-ae8c-43d5-b190-f4a0e44e6951',
            'description' => 'Search users via AI.',
            'tools'       => ['search_user'],
        ],
    ];

    protected array $rolePermissions = [
        'AI Agent Sales' => [
            'AI Tool Opportunity Create', 'AI Tool Opportunity Update', 'AI Tool Opportunity Delete', 'AI Tool Opportunity Search',
            'AI Tool Print Quotation', 'AI Tool Hot Lead',
            'AI Tool Lead Create', 'AI Tool Lead Update', 'AI Tool Lead Delete', 'AI Tool Lead Search',
            'AI Tool Account Search', 'AI Tool Contact Search', 'AI Tool Product Search',
            'AI Tool User Search',
        ],
        'AI Agent Order' => [
            'AI Tool Order Create', 'AI Tool Order Update', 'AI Tool Order Delete', 'AI Tool Order Search',
            'AI Tool Invoice Create', 'AI Tool Invoice Update', 'AI Tool Invoice Delete', 'AI Tool Invoice Search',
            'AI Tool Contract Create', 'AI Tool Contract Update', 'AI Tool Contract Delete', 'AI Tool Contract Search',
            'AI Tool Opportunity Search',
            'AI Tool Account Search', 'AI Tool Contact Search', 'AI Tool Product Search',
            'AI Tool User Search',
        ],
    ];

    protected array $wiring = [
        // Account/contact/product access wired in AiScopedToolSeeder (scoped variants).
        'sales' => [
            'lookup_options', 'lookup_region', 'get_current_datetime',
            'create_lead', 'update_lead', 'delete_lead', 'search_lead', 'hot_lead',
            'create_opportunity', 'update_opportunity', 'delete_opportunity', 'search_opportunity', 'print_quotation',
            'create_opportunity_product', 'update_opportunity_product', 'delete_opportunity_product', 'search_opportunity_product',
            'create_opportunity_team', 'update_opportunity_team', 'delete_opportunity_team', 'search_opportunity_team',
            'create_opportunity_contact', 'update_opportunity_contact', 'delete_opportunity_contact', 'search_opportunity_contact',
            'create_opportunity_competitor', 'update_opportunity_competitor', 'delete_opportunity_competitor', 'search_opportunity_competitor',
            'create_opportunity_term_condition', 'update_opportunity_term_condition', 'delete_opportunity_term_condition', 'search_opportunity_term_condition',
            'search_opportunity_quotation_history', 'search_opportunity_status_history',
            'search_user',
        ],
        'order' => [
            'lookup_options', 'lookup_region', 'get_current_datetime',
            'create_order', 'update_order', 'delete_order', 'search_order',
            'create_order_detail', 'update_order_detail', 'delete_order_detail', 'search_order_detail',
            'search_order_status_history',
            'create_invoice', 'update_invoice', 'delete_invoice', 'search_invoice',
            'create_invoice_detail', 'update_invoice_detail', 'delete_invoice_detail', 'search_invoice_detail',
            'search_invoice_status_history',
            'create_contract', 'update_contract', 'delete_contract', 'search_contract',
            'search_user',
        ],
        // Opportunity access wired in AiScopedToolSeeder (reference-shaped variant).
        'activity' => [
            'search_order', 'search_invoice',
        ],
        'whatsapp' => [
            'sales_specialist', 'order_specialist',
        ],
    ];

    public function run(): void
    {
        $this->seedRoles();
        $this->seedPermissions();
        $this->assignRolePermissions();
        $this->grantAgentAndSpecialistAccess();
        $this->grantActivityCrossSearch();
        $this->grantPermissionTools();
        $this->wiring();
    }

    protected function seedRoles(): void
    {
        foreach ($this->roles as $name => $role) {
            Role::firstOrCreate(['id' => $role['id']], [
                'name'        => $name,
                'description' => $role['description'],
            ]);
        }
    }

    protected function seedPermissions(): void
    {
        foreach ($this->permissions as $name => $permission) {
            Permission::firstOrCreate(['id' => $permission['id']], [
                'name'        => $name,
                'description' => $permission['description'],
            ]);
        }
    }

    protected function assignRolePermissions(): void
    {
        foreach ($this->rolePermissions as $roleName => $permissionNames) {
            $role = Role::find($this->roles[$roleName]['id']);

            if ($role === null) {
                continue;
            }

            $role->assignPermission($permissionNames);
        }
    }

    protected function grantAgentAndSpecialistAccess(): void
    {
        foreach ($this->roles as $role) {
            AiAgent::where('slug', $role['agent'])->first()?->assignRole([$role['id']]);
            AiTool::where('slug', $role['specialist'])->first()?->assignRole([$role['id']]);
        }
    }

    protected function grantActivityCrossSearch(): void
    {
        $role = Role::where('name', 'AI Agent Activity')->first();

        if ($role === null) {
            return;
        }

        $role->assignPermission([
            'AI Tool Opportunity Search',
            'AI Tool Order Search',
            'AI Tool Invoice Search',
        ]);
    }

    protected function grantPermissionTools(): void
    {
        foreach ($this->permissions as $permission) {
            AiTool::whereIn('slug', $permission['tools'])->get()
                ->each(fn (AiTool $tool) => $tool->assignPermission([$permission['id']]));
        }
    }

    protected function wiring(): void
    {
        foreach ($this->wiring as $agentSlug => $toolSlugs) {
            $agent = AiAgent::where('slug', $agentSlug)->first();

            if ($agent === null) {
                continue;
            }

            $agent->attachTools(AiTool::whereIn('slug', $toolSlugs)->pluck('id')->all());
        }
    }
}
