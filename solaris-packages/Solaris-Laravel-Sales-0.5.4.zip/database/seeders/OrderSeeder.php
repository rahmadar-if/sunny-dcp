<?php

namespace Solaris\Sales\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Solaris\Sales\Const\OrderStatusConst;

class OrderSeeder extends Seeder
{
    public function run(): void
    {
        $this->order_statuses();
    }

    protected function order_statuses(): void
    {
        $data = [
            [
                'id'             => OrderStatusConst::Draft,
                'name'           => 'Draft',
                'color'          => 'primary',
                'position'       => 1,
                "group_id"       => null,
                'is_final_stage' => false
            ],
            [
                'id'             => OrderStatusConst::Confirmation,
                'name'           => 'Confirmation',
                'color'          => 'info',
                'position'       => 2,
                "group_id"       => null,
                'is_final_stage' => false
            ],
            [
                'id'             => OrderStatusConst::Completed,
                'name'           => 'Completed',
                'color'          => 'success',
                'position'       => 3,
                "group_id"       => null,
                'is_final_stage' => true
            ],
            [
                'id'             => OrderStatusConst::Cancel,
                'name'           => 'Cancel',
                'color'          => 'danger',
                'position'       => 4,
                "group_id"       => OrderStatusConst::Completed,
                'is_final_stage' => true
            ],
        ];
        DB::table('order_statuses')->insertOrIgnore($data);
    }
}