@props([
    "id",
    "model",
    "new"            => true,
    "import"         => false,
    "export"         => false,
    "folder"         => false,
    "lazy"           => false,
    "search"         => true,
    "title"          => "Opportunity",
    "extend_columns" => null,
    "breadcrumbs"    => [],
    "package"        => null,
    "path"           => null,
])

@php
    $tableAttrs = new \Illuminate\View\ComponentAttributeBag(
        collect($attributes->whereStartsWith('table:')->all())
            ->mapWithKeys(fn($value, $key) => [Str::after($key, 'table:') => $value])
            ->all()
    );
    $tableAttrs = $tableAttrs->merge([
        "id"     => $id."_list",
        "model"  => $model,
        "import" => $import,
        "export" => $export,
        "search" => $search,
        "new"    => $new,
        "folder" => $folder,
        "lazy"   => $lazy,
        "extend_columns" => $extend_columns
    ]);

    $kanbanAttrs = new \Illuminate\View\ComponentAttributeBag(
        collect($attributes->whereStartsWith('kanban:')->all())
            ->mapWithKeys(fn($value, $key) => [Str::after($key, 'kanban:') => $value])
            ->all()
    );
    $kanbanAttrs = $kanbanAttrs->merge([
        "id"     => $id."_kanban",
        "model"  => $model,
        "import" => $import,
        "export" => $export,
        "search" => $search,
        "new"    => $new,
        "folder" => $folder,
        "lazy"   => $lazy
    ]);

    $navId = $id."_nav";
@endphp

<x-core::page.base 
    :title="$title"
    :breadcrumbs="$breadcrumbs"
    :package="$package" 
    :path="$path">

    <x-slot:buttons>
        <ul 
            class="nav nav-tabs justify-content-end nav-tabs-header mb-0 tab-style-6" 
            id="{{ $navId }}" 
            role="tablist"
            style="background-color: transparent;">

            <x-core::tab-nav id="{{ $navId }}-tabs_table" active>List view</x-core::tab-nav>
            <x-core::tab-nav id="{{ $navId }}-tabs_kanban">Kanban view</x-core::tab-nav>
        </ul>
    </x-slot>

    @if (isset($header))
        {{ $header }}
    @endif

    <div class="tab-content" id="{{ $navId }}_content">
        <x-core::tab-content id="{{ $navId }}-tabs_table" active class="p-0 border-0">
            
            @if (isset($listHeader))
                {{ $listHeader }}
            @endif

            <x-core::table :attributes="$tableAttrs">

                @if (isset($tableHeader))
                    <x-slot:header>
                        {{ $tableHeader }}
                    </x-slot>
                @endif

                @if (isset($tablePreLeftAction))
                    <x-slot:pre-left-action>
                        {{ $tablePreLeftAction }}
                    </x-slot>
                @endif

                @if (isset($tableLeftAction))
                    <x-slot:left-action>
                        {{ $tableLeftAction }}
                    </x-slot>
                @endif

                @if (isset($tablePreRightAction))
                    <x-slot:pre-right-action>
                        {{ $tablePreRightAction }}
                    </x-slot>
                @endif

                @if (isset($tableRightAction))
                    <x-slot:right-action>
                        {{ $tableRightAction }}
                    </x-slot>
                @endif

                @if (isset($tableColumn))
                    <x-slot:column :attributes="$tableColumn->attributes">
                        {{ $tableColumn }}
                    </x-slot>
                @endif

                @if (isset($tableBody))
                    <x-slot:body :attributes="$tableBody->attributes">
                        {{ $tableBody }}
                    </x-slot>
                @endif
            </x-core::table>

        </x-core::tab-content>

        <x-core::tab-content id="{{ $navId }}-tabs_kanban" class="p-0 border-0">
            @if (isset($kanbanHeader))
                {{ $kanbanHeader }}
            @endif

            <x-core::kanban :attributes="$kanbanAttrs" />
        </x-core::tab-content>
    </div>

    {{ $slot }}

</x-core::page.base>