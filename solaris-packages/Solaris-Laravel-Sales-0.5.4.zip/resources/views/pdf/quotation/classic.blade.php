<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        @page {
            size: A4;
            margin: 20mm 15mm;
        }
        body {
            font-family: Poppins, DejaVu Sans, sans-serif;
            font-size: 13px;
            line-height: 1.42;
            color: #2b2b2b;
            margin: 0;
            padding: 0;
        }
        .header {
            border-bottom: 2px solid #1b2a4a;
            padding-bottom: 16px;
            margin-bottom: 24px;
            page-break-inside: avoid;
        }
        .header table {
            width: 100%;
            border-collapse: collapse;
        }
        .header td {
            vertical-align: top;
        }
        .header .company-col {
            width: 60%;
        }
        .header .meta-col {
            width: 40%;
            text-align: right;
        }
        .header .name {
            font-size: 18px;
            font-weight: bold;
            color: #1b2a4a;
        }
        .header .title {
            font-size: 16px;
            font-weight: bold;
            color: #1b2a4a;
        }
        .section {
            margin-bottom: 24px;
        }
        .section .label {
            font-size: 10px;
            text-transform: uppercase;
            color: #888;
            margin-bottom: 4px;
        }
        table.items {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 24px;
        }
        table.items th {
            background: #1b2a4a;
            color: #fff;
            text-align: left;
            padding: 8px;
            font-size: 12px;
        }
        table.items td {
            padding: 8px;
            border-bottom: 1px solid #e0e0e0;
            font-size: 12px;
        }
        table.items td.number,
        table.items th.number {
            text-align: right;
        }
        .totals {
            page-break-inside: avoid;
        }
        .totals table {
            width: 100%;
            border-collapse: collapse;
        }
        .totals .spacer-col {
            width: 60%;
        }
        .totals .row-label,
        .totals .row-amount {
            padding: 4px 8px;
            font-size: 12px;
            color: #666;
        }
        .totals .row-amount {
            text-align: right;
        }
        .totals .total-label,
        .totals .total-amount {
            border-top: 2px solid #1b2a4a;
            font-weight: bold;
            font-size: 14px;
            padding: 6px 8px;
        }
        .totals .total-amount {
            text-align: right;
        }
        .footer {
            margin-top: 40px;
            padding-top: 12px;
            border-top: 1px solid #e0e0e0;
            font-size: 11px;
            color: #888;
        }
    </style>
</head>
<body>
    <div class="header">
        <table>
            <tr>
                <td class="company-col">
                    <div class="name">{{ config('app.name', 'Your Company Name') }}</div>
                    <div>Company address placeholder</div>
                    <div>Company phone / email placeholder</div>
                </td>
                <td class="meta-col">
                    <div class="title">QUOTATION</div>
                    <div>No: {{ $history->number_quotation }}</div>
                    <div>Date: {{ $history->date->format('d M Y') }}</div>
                </td>
            </tr>
        </table>
    </div>

    <div class="section">
        <div class="label">Bill To</div>
        <div>{{ $opportunity->customer?->name }}</div>
        @if ($address)
            <div>
                {{ collect([$address->address, $address->city?->name, $address->province?->name, $address->postcode])->filter()->implode(', ') }}
            </div>
        @endif
        <div>{{ $opportunity->email }}</div>
        <div>{{ $opportunity->phone }}</div>
    </div>

    <table class="items">
        <thead>
            <tr>
                <th>Product</th>
                <th class="number">Qty</th>
                <th class="number">Price</th>
                <th class="number">Discount</th>
                <th class="number">Total</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($opportunity->products as $item)
                <tr>
                    <td>{{ $item->product?->name }}</td>
                    <td class="number">{{ number_format($item->qty, 0, ',', '.') }}</td>
                    <td class="number">Rp {{ number_format($item->price, 2, ',', '.') }}</td>
                    <td class="number">Rp {{ number_format($item->disc, 2, ',', '.') }}</td>
                    <td class="number">Rp {{ number_format($item->total, 2, ',', '.') }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>

    @php
        $subtotal = $opportunity->products->sum(fn($item) => $item->qty * $item->price);
        $totalDiscount = $opportunity->products->sum('disc');
    @endphp

    <div class="totals">
        <table>
            <tr>
                <td class="spacer-col" rowspan="3"></td>
                <td class="row-label">Subtotal</td>
                <td class="row-amount">Rp {{ number_format($subtotal, 2, ',', '.') }}</td>
            </tr>
            <tr>
                <td class="row-label">Discount</td>
                <td class="row-amount">Rp {{ number_format($totalDiscount, 2, ',', '.') }}</td>
            </tr>
            <tr>
                <td class="total-label">Grand Total</td>
                <td class="total-amount">Rp {{ number_format($opportunity->total_amount, 2, ',', '.') }}</td>
            </tr>
        </table>
    </div>

    <div class="footer">
        This quotation is generated automatically and is valid as stated by the issuing company's terms.
    </div>
</body>
</html>
