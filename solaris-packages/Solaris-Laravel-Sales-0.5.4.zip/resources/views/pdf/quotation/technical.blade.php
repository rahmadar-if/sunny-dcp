<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        @page {
            size: A4;
            margin: 15mm;
        }
        body {
            font-family: Arial, DejaVu Sans, sans-serif;
            font-size: 12px;
            line-height: 1.4;
            color: #3c4858;
            margin: 0;
            padding: 0;
        }
        .mono {
            font-family: 'Courier New', DejaVu Sans Mono, monospace;
        }
        .header {
            margin-bottom: 16px;
            page-break-inside: avoid;
        }
        .header table {
            width: 100%;
            border-collapse: collapse;
        }
        .header td {
            vertical-align: top;
        }
        .header .company-col {
            width: 55%;
        }
        .header .title-col {
            width: 45%;
            text-align: right;
        }
        .header .name {
            font-size: 15px;
            font-weight: bold;
            color: #3c4858;
        }
        .header .title {
            font-size: 18px;
            font-weight: bold;
            letter-spacing: 1px;
        }
        table.meta-grid {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 16px;
            border: 1px solid #d7dce1;
        }
        table.meta-grid th {
            background: #f2f4f6;
            text-align: left;
            padding: 6px 8px;
            font-size: 10px;
            text-transform: uppercase;
            color: #6b7684;
            border: 1px solid #d7dce1;
        }
        table.meta-grid td {
            padding: 6px 8px;
            border: 1px solid #d7dce1;
        }
        .section {
            margin-bottom: 16px;
        }
        .label {
            font-size: 10px;
            text-transform: uppercase;
            color: #6b7684;
            margin-bottom: 4px;
        }
        table.items {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 16px;
            border: 1px solid #d7dce1;
        }
        table.items th {
            background: #3c4858;
            color: #fff;
            text-align: left;
            padding: 8px;
            font-size: 11px;
            border: 1px solid #3c4858;
        }
        table.items td {
            padding: 8px;
            font-size: 11px;
            border: 1px solid #d7dce1;
        }
        table.items td.number,
        table.items th.number {
            text-align: right;
        }
        .totals {
            margin-bottom: 24px;
            page-break-inside: avoid;
        }
        .totals table {
            width: 100%;
            border-collapse: collapse;
        }
        .totals .spacer-col {
            width: 60%;
        }
        .totals .row-label,
        .totals .row-amount {
            border: 1px solid #d7dce1;
            padding: 6px 8px;
            font-size: 11px;
            color: #6b7684;
        }
        .totals .row-amount {
            text-align: right;
        }
        .totals .total-label,
        .totals .total-amount {
            border: 1px solid #d7dce1;
            font-weight: bold;
            background: #f2f4f6;
            padding: 6px 8px;
        }
        .totals .total-amount {
            text-align: right;
        }
        .highlight {
            color: #e8871e;
            font-weight: bold;
        }
        .footer {
            padding-top: 12px;
            border-top: 1px solid #d7dce1;
            font-size: 10px;
            color: #6b7684;
        }
        .footer ol {
            margin: 0;
            padding-left: 16px;
        }
    </style>
</head>
<body>
    <div class="header">
        <table>
            <tr>
                <td class="company-col">
                    <div class="name">{{ config('app.name', 'Your Company Name') }}</div>
                    <div>Company address placeholder</div>
                    <div>Company phone / email placeholder</div>
                </td>
                <td class="title-col">
                    <div class="title">QUOTATION</div>
                </td>
            </tr>
        </table>
    </div>

    <table class="meta-grid">
        <tr>
            <th>No.</th>
            <th>Date</th>
            <th>Validity</th>
        </tr>
        <tr>
            <td class="mono">{{ $history->number_quotation }}</td>
            <td>{{ $history->date->format('d M Y') }}</td>
            <td class="highlight">{{ $history->date->copy()->addDays(14)->format('d M Y') }}</td>
        </tr>
    </table>

    <div class="section">
        <div class="label">Bill To</div>
        <div>{{ $opportunity->customer?->name }}</div>
        <div>{{ $opportunity->customer?->email }}</div>
        <div>{{ $opportunity->customer?->primary_phone }}</div>
    </div>

    <table class="items">
        <thead>
            <tr>
                <th>Product</th>
                <th class="number">Qty</th>
                <th class="number">Price</th>
                <th class="number">Discount</th>
                <th class="number">Total</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($opportunity->products as $item)
                <tr>
                    <td>{{ $item->product?->name }}</td>
                    <td class="number mono">{{ number_format($item->qty, 0, ',', '.') }}</td>
                    <td class="number mono">Rp {{ number_format($item->price, 2, ',', '.') }}</td>
                    <td class="number mono">Rp {{ number_format($item->disc, 2, ',', '.') }}</td>
                    <td class="number mono">Rp {{ number_format($item->total, 2, ',', '.') }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>

    @php
        $subtotal = $opportunity->products->sum(fn($item) => $item->qty * $item->price);
        $totalDiscount = $opportunity->products->sum('disc');
    @endphp

    <div class="totals">
        <table>
            <tr>
                <td class="spacer-col" rowspan="3"></td>
                <td class="row-label">Subtotal</td>
                <td class="row-amount mono">Rp {{ number_format($subtotal, 2, ',', '.') }}</td>
            </tr>
            <tr>
                <td class="row-label">Discount</td>
                <td class="row-amount mono">Rp {{ number_format($totalDiscount, 2, ',', '.') }}</td>
            </tr>
            <tr>
                <td class="total-label">Grand Total</td>
                <td class="total-amount mono">Rp {{ number_format($opportunity->total_amount, 2, ',', '.') }}</td>
            </tr>
        </table>
    </div>

    <div class="footer">
        <ol>
            <li>This quotation is generated automatically based on the opportunity's current data.</li>
            <li>Valid until the date stated above unless otherwise agreed.</li>
        </ol>
    </div>
</body>
</html>
