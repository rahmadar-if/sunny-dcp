<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        @page {
            size: A4;
            margin: 15mm;
        }
        body {
            font-family: Arial, DejaVu Sans, sans-serif;
            font-size: 13px;
            line-height: 1.42;
            color: #111318;
            margin: 0;
            padding: 0;
        }
        .header {
            margin-bottom: 24px;
            page-break-inside: avoid;
        }
        .header table {
            width: 100%;
            border-collapse: collapse;
        }
        .header td {
            vertical-align: top;
            background: #111318;
            color: #fff;
            padding: 20px 24px;
        }
        .header .company-col {
            width: 55%;
        }
        .header .meta-col {
            width: 45%;
            text-align: right;
        }
        .header .name {
            font-family: Poppins, Arial, sans-serif;
            font-size: 15px;
            font-weight: bold;
        }
        .header .title {
            font-family: Poppins, Arial, sans-serif;
            font-size: 20px;
            font-weight: bold;
            color: #2f6fed;
        }
        .header .meta-col div {
            color: #cfd3db;
        }
        .section {
            margin-bottom: 24px;
        }
        .section .label {
            font-size: 10px;
            text-transform: uppercase;
            color: #888;
            margin-bottom: 4px;
        }
        table.items {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 24px;
        }
        table.items th {
            background: #2f6fed;
            color: #fff;
            text-align: left;
            padding: 8px;
            font-size: 12px;
        }
        table.items td {
            padding: 8px;
            font-size: 12px;
        }
        table.items tr.odd td {
            background: #eef1f4;
        }
        table.items td.number,
        table.items th.number {
            text-align: right;
        }
        .totals {
            page-break-inside: avoid;
            margin-bottom: 24px;
        }
        .totals table {
            width: 100%;
            border-collapse: collapse;
        }
        .totals .spacer-col {
            width: 60%;
        }
        .totals .badge-col {
            width: 40%;
            background: #2f6fed;
            color: #fff;
            padding: 12px 16px;
            text-align: right;
        }
        .totals .row {
            font-size: 11px;
            color: #cfd3db;
            margin-bottom: 4px;
        }
        .totals .label {
            font-size: 10px;
            text-transform: uppercase;
            color: #cfd3db;
            margin-top: 8px;
        }
        .totals .amount {
            font-family: Poppins, Arial, sans-serif;
            font-size: 18px;
            font-weight: bold;
        }
        .footer {
            margin-top: 40px;
            padding-top: 12px;
            border-top: 1px solid #eef1f4;
            font-size: 11px;
            color: #888;
        }
    </style>
</head>
<body>
    <div class="header">
        <table>
            <tr>
                <td class="company-col">
                    <div class="name">{{ config('app.name', 'Your Company Name') }}</div>
                    <div>Company address placeholder</div>
                    <div>Company phone / email placeholder</div>
                </td>
                <td class="meta-col">
                    <div class="title">QUOTATION</div>
                    <div>No: {{ $history->number_quotation }}</div>
                    <div>Date: {{ $history->date->format('d M Y') }}</div>
                </td>
            </tr>
        </table>
    </div>

    <div class="section">
        <div class="label">Bill To</div>
        <div>{{ $opportunity->customer?->name }}</div>
        <div>{{ $opportunity->customer?->email }}</div>
        <div>{{ $opportunity->customer?->primary_phone }}</div>
    </div>

    <table class="items">
        <thead>
            <tr>
                <th>Product</th>
                <th class="number">Qty</th>
                <th class="number">Price</th>
                <th class="number">Discount</th>
                <th class="number">Total</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($opportunity->products as $index => $item)
                <tr class="{{ $index % 2 === 1 ? 'odd' : '' }}">
                    <td>{{ $item->product?->name }}</td>
                    <td class="number">{{ number_format($item->qty, 0, ',', '.') }}</td>
                    <td class="number">Rp {{ number_format($item->price, 2, ',', '.') }}</td>
                    <td class="number">Rp {{ number_format($item->disc, 2, ',', '.') }}</td>
                    <td class="number">Rp {{ number_format($item->total, 2, ',', '.') }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>

    @php
        $subtotal = $opportunity->products->sum(fn($item) => $item->qty * $item->price);
        $totalDiscount = $opportunity->products->sum('disc');
    @endphp

    <div class="totals">
        <table>
            <tr>
                <td class="spacer-col"></td>
                <td class="badge-col">
                    <div class="row">Subtotal — Rp {{ number_format($subtotal, 2, ',', '.') }}</div>
                    <div class="row">Discount — Rp {{ number_format($totalDiscount, 2, ',', '.') }}</div>
                    <div class="label">Grand Total</div>
                    <div class="amount">Rp {{ number_format($opportunity->total_amount, 2, ',', '.') }}</div>
                </td>
            </tr>
        </table>
    </div>

    <div class="footer">
        This quotation is generated automatically and is valid as stated by the issuing company's terms.
    </div>
</body>
</html>
