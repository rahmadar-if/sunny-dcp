<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        @page {
            size: A4;
            margin: 12mm;
        }
        body {
            font-family: Calibri, DejaVu Sans, sans-serif;
            font-size: 13px;
            line-height: 1.5;
            color: #2b2b2b;
            background: #f7f4ef;
            margin: 0;
            padding: 0;
        }
        .page {
            padding: 32px 40px;
        }
        .eyebrow {
            font-family: Georgia, DejaVu Serif, serif;
            font-style: italic;
            font-size: 12px;
            color: #6b2737;
            margin-bottom: 4px;
        }
        .header {
            border-bottom: 1px solid #c4a265;
            padding-bottom: 20px;
            margin-bottom: 24px;
            page-break-inside: avoid;
        }
        .header table {
            width: 100%;
            border-collapse: collapse;
        }
        .header td {
            vertical-align: top;
        }
        .header .company-col {
            width: 60%;
        }
        .header .meta-col {
            width: 40%;
            text-align: right;
        }
        .header .name {
            font-family: Georgia, DejaVu Serif, serif;
            font-size: 17px;
        }
        .section {
            margin-bottom: 24px;
        }
        table.items {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 24px;
        }
        table.items th {
            text-align: right;
            padding: 8px 4px;
            font-size: 11px;
            text-transform: uppercase;
            color: #8a7a6a;
            border-bottom: 1px solid #c4a265;
            font-weight: normal;
        }
        table.items th:first-child {
            text-align: left;
        }
        table.items td {
            padding: 10px 4px;
            font-size: 12px;
            text-align: right;
            border-bottom: 1px solid #e8e0d4;
        }
        table.items td:first-child {
            text-align: left;
        }
        .totals {
            page-break-inside: avoid;
        }
        .totals table {
            width: 100%;
            border-collapse: collapse;
        }
        .totals .spacer-col {
            width: 60%;
        }
        .totals .tint-col {
            width: 40%;
            background: #efe4e1;
            padding: 14px 16px;
            text-align: right;
        }
        .totals .row {
            font-size: 11px;
            color: #8a7a6a;
            margin-bottom: 4px;
        }
        .totals .label {
            font-family: Georgia, DejaVu Serif, serif;
            font-style: italic;
            font-size: 11px;
            color: #6b2737;
            margin-top: 8px;
        }
        .totals .amount {
            font-size: 18px;
            font-weight: bold;
            color: #6b2737;
        }
        .footer {
            margin-top: 40px;
            padding-top: 12px;
            border-top: 1px solid #c4a265;
            font-size: 11px;
            color: #8a7a6a;
        }
    </style>
</head>
<body>
    <div class="page">
        <div class="header">
            <table>
                <tr>
                    <td class="company-col">
                        <div class="eyebrow">Prepared for {{ $opportunity->customer?->name }}</div>
                        <div class="name">{{ config('app.name', 'Your Company Name') }}</div>
                    </td>
                    <td class="meta-col">
                        <div class="eyebrow">Quotation No.</div>
                        <div>{{ $history->number_quotation }}</div>
                        <div>{{ $history->date->format('d M Y') }}</div>
                    </td>
                </tr>
            </table>
        </div>

        <div class="section">
            <div class="eyebrow">Bill To</div>
            <div>{{ $opportunity->customer?->name }}</div>
            <div>{{ $opportunity->customer?->email }}</div>
            <div>{{ $opportunity->customer?->primary_phone }}</div>
        </div>

        <table class="items">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Qty</th>
                    <th>Price</th>
                    <th>Discount</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($opportunity->products as $item)
                    <tr>
                        <td>{{ $item->product?->name }}</td>
                        <td>{{ number_format($item->qty, 0, ',', '.') }}</td>
                        <td>Rp {{ number_format($item->price, 2, ',', '.') }}</td>
                        <td>Rp {{ number_format($item->disc, 2, ',', '.') }}</td>
                        <td>Rp {{ number_format($item->total, 2, ',', '.') }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>

        @php
            $subtotal = $opportunity->products->sum(fn($item) => $item->qty * $item->price);
            $totalDiscount = $opportunity->products->sum('disc');
        @endphp

        <div class="totals">
            <table>
                <tr>
                    <td class="spacer-col"></td>
                    <td class="tint-col">
                        <div class="row">Subtotal — Rp {{ number_format($subtotal, 2, ',', '.') }}</div>
                        <div class="row">Discount — Rp {{ number_format($totalDiscount, 2, ',', '.') }}</div>
                        <div class="label">Grand Total</div>
                        <div class="amount">Rp {{ number_format($opportunity->total_amount, 2, ',', '.') }}</div>
                    </td>
                </tr>
            </table>
        </div>

        <div class="footer">
            This quotation is generated automatically and is valid as stated by the issuing company's terms.
        </div>
    </div>
</body>
</html>
