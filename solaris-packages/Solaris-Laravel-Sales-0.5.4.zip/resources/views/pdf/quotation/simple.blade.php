<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        @page {
            size: A4;
            margin: 22mm 20mm;
        }
        body {
            font-family: Calibri, DejaVu Sans, sans-serif;
            font-size: 13px;
            line-height: 1.5;
            color: #1a1a1a;
            margin: 0;
            padding: 0;
        }
        .eyebrow {
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #999;
            margin-bottom: 4px;
        }
        .header {
            margin-bottom: 32px;
            page-break-inside: avoid;
        }
        .header .name {
            font-size: 16px;
            font-weight: bold;
        }
        .header .meta {
            margin-top: 12px;
            color: #555;
        }
        .section {
            margin-bottom: 32px;
        }
        table.items {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 32px;
        }
        table.items th {
            text-align: left;
            padding: 6px 4px 10px 4px;
            font-size: 11px;
            text-transform: uppercase;
            color: #999;
            border-bottom: 1px solid #dadada;
            font-weight: normal;
        }
        table.items td {
            padding: 10px 4px;
            font-size: 13px;
        }
        table.items td.number,
        table.items th.number {
            text-align: right;
        }
        .totals {
            text-align: right;
            page-break-inside: avoid;
        }
        .totals .row {
            font-size: 12px;
            color: #666;
            margin-bottom: 4px;
        }
        .totals .label {
            font-size: 11px;
            text-transform: uppercase;
            color: #999;
            margin-top: 8px;
        }
        .totals .amount {
            font-size: 26px;
            font-weight: bold;
            color: #7c9885;
        }
        .footer {
            margin-top: 48px;
            padding-top: 12px;
            border-top: 1px solid #dadada;
            font-size: 11px;
            color: #999;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="eyebrow">Quotation {{ $history->number_quotation }} — {{ $history->date->format('d M Y') }}</div>
        <div class="name">{{ config('app.name', 'Your Company Name') }}</div>
        <div class="meta">
            {{ $opportunity->customer?->name }}<br>
            {{ $opportunity->customer?->email }}<br>
            {{ $opportunity->customer?->primary_phone }}
        </div>
    </div>

    <table class="items">
        <thead>
            <tr>
                <th>Product</th>
                <th class="number">Qty</th>
                <th class="number">Price</th>
                <th class="number">Discount</th>
                <th class="number">Total</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($opportunity->products as $item)
                <tr>
                    <td>{{ $item->product?->name }}</td>
                    <td class="number">{{ number_format($item->qty, 0, ',', '.') }}</td>
                    <td class="number">Rp {{ number_format($item->price, 2, ',', '.') }}</td>
                    <td class="number">Rp {{ number_format($item->disc, 2, ',', '.') }}</td>
                    <td class="number">Rp {{ number_format($item->total, 2, ',', '.') }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>

    @php
        $subtotal = $opportunity->products->sum(fn($item) => $item->qty * $item->price);
        $totalDiscount = $opportunity->products->sum('disc');
    @endphp

    <div class="totals">
        <div class="row">Subtotal — Rp {{ number_format($subtotal, 2, ',', '.') }}</div>
        <div class="row">Discount — Rp {{ number_format($totalDiscount, 2, ',', '.') }}</div>
        <div class="label">Grand Total</div>
        <div class="amount">Rp {{ number_format($opportunity->total_amount, 2, ',', '.') }}</div>
    </div>

    <div class="footer">
        This quotation is generated automatically and is valid as stated by the issuing company's terms.
    </div>
</body>
</html>
