<x-core::modal-form
    id="order-modal"
    title="Order"
    size="md"
    model="Order">

    <x-core::field id="order-modal-opportunity_id:opportunity_id" label="Opportunity" required lazy>
        <x-core::lookup
            pagination
            placeholder="Link to an existing opportunity"
            extend_search="created_by[name,email,username],customer.name,decision_maker.name"
            extend_columns="created_by,date,customer,decision_maker,status,total_amount"
            source="Opportunity"
            link_url="/sales/opportunity/{id}" />
    </x-core::field>

</x-core::modal-form>
