<div class="card custom-card">
    <div class="card-body">
        <x-core::field label="Number" id="order-page-number:number" disabled>
            <x-core::input
                placeholder="Type a unique order reference"
                :value="$data->number"/>
        </x-core::field>

        <x-core::field label="Opportunity" id="order-page-opportunity_id:opportunity_id" disabled>
            <x-core::lookup
                pagination
                source="Opportunity"
                placeholder="Link to an existing opportunity"
                :value="json_encode($data->opportunity)"
                link_url="/sales/opportunity/{id}" />
        </x-core::field>

        <x-core::field label="Account" id="order-page-account_id:account_id" required>
            <x-core::lookup
                pagination
                source="Account"
                placeholder="Choose the customer account"
                :value="json_encode($data->account)"
                link_url="/master-data/account/{id}"/>
        </x-core::field>

        <x-core::field label="Contact" id="order-page-contact_id:contact_id" lazy>
            <x-core::lookup
                pagination
                source="Contact"
                placeholder="Choose the contact person"
                :value="json_encode($data->contact)"
                link_url="/master-data/contact/{id}" />
        </x-core::field>

        <x-core::field label="Registration date" id="order-page-date:date">
            <x-core::date-picker
                placeholder="Choose when this order was registered"
                :value="$data->date"/>
        </x-core::field>

        <x-core::field label="Amount" id="order-page-amount:amount" disabled>
            <x-core::input
                number decimal
                prefix="Rp"
                placeholder="Enter total order amount"
                :value="$data->amount"/>
        </x-core::field>
    </div>
</div>
