<x-core::table
    id="order-activity_list" 
    class="table-hover"
    model="Activity"
    new="@activity-modal"
    export lazy
    filter="order_id = {{ $id }}">

    <x-slot:column>
        <x-core::table-action-column />

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="subject" 
            searchable 
            orderable>
            Subject
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="priority.name" 
            searchable 
            orderable>
            Priority
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="start_date" 
            searchable 
            orderable>
            Start Date
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="end_date" 
            searchable 
            orderable>
            End Date
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="category.name" 
            searchable 
            orderable>
            Category
        </x-core::table-column>
    </x-slot>

</x-core::table>

@push('modal-content')
    @include("master-data::pages.activity.modal")
@endpush
