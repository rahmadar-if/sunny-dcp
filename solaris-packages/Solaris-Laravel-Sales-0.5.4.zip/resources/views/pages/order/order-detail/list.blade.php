<x-core::table
    id="order-detail_list" 
    class="table-hover"
    model="OrderDetail"
    new="@order-detail-modal"
    import export lazy
    filter="order_id = {{ $id }}">

    <x-slot:column>
        <x-core::table-action-column :view="false"/>

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="product.name" 
            lookup="product_picture_id" 
            searchable 
            orderable>
            Product
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="price" 
            orderable>
            Price
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="qty" 
            orderable>
            Quantity
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="discount" 
            orderable>
            Discount
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="total" 
            orderable>
            Total
        </x-core::table-column>
    </x-slot>

</x-core::table>

@push('modal-content')
    @include("sales::pages.order.order-detail.modal", ['id' => $id])
@endpush