<x-core::modal-form
    id="order-detail-modal"
    title="Product"
    model="OrderDetail">

    <div class="row">
        <div class="col-lg-6">
            <x-core::field id="order-detail-modal-product_id:product_id" label="Product" required lazy>
                <x-core::lookup
                    pagination
                    placeholder="Choose product to add to order"
                    extend_columns="price"
                    source="Product@availableInOrderDetail({{ $id }})"
                    link_url="/master-data/product/{id}"/>
            </x-core::field>

            <x-core::field label="Price" id="order-detail-modal-price:price" required>
                <x-core::input
                    number decimal
                    prefix="Rp "
                    placeholder="Price per item"/>
            </x-core::field>

            <x-core::field label="Quantity" id="order-detail-modal-qty:qty" required>
                <x-core::input
                    number
                    placeholder="Enter quantity"/>
            </x-core::field>
        </div>
        <div class="col-lg-6">
            <x-core::field label="Amount" id="order-detail-modal-amount:amount" disabled>
                <x-core::input
                    number decimal
                    prefix="Rp "
                    placeholder="Will be calculated automatically"/>
            </x-core::field>

            <x-core::field label="Discount" id="order-detail-modal-discount:discount">
                <x-core::input
                    number decimal
                    prefix="Rp "
                    placeholder="Enter discount amount"/>
            </x-core::field>

            <x-core::field label="Total" id="order-detail-modal-total:total" disabled>
                <x-core::input
                    number decimal
                    prefix="Rp "
                    placeholder="Will be calculated automatically"/>
            </x-core::field>
        </div>
    </div>

</x-core::modal-form>
