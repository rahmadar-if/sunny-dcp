@php
    use Solaris\Sales\Const\OpportunityTypeConst;
@endphp

<x-core::modal-form
	id="opportunity-modal"
	title="Opportunity"
    model="Opportunity">

    <div class="row">
        <div class="col-lg-6">
            <x-core::field id="opportunity-modal-date:date" label="Date" required>
                <x-core::date-picker placeholder="Select opportunity date"/>
            </x-core::field>

            <x-core::field id="opportunity-modal-name:name" label="Name" required>
                <x-core::input placeholder="Enter opportunity name"/>
            </x-core::field>

            <x-core::field id="opportunity-modal-type_id:type_id" label="Type" required>
                <x-core::lookup
                    placeholder="Choose type"
                    :value="json_encode(['id' => OpportunityTypeConst::NewBusiness, 'name' => 'New Business'])"
                    :options="SolarHelper::model('opportunity_type')::toSelect()" />
            </x-core::field>

            <x-core::field id="opportunity-modal-source_id:source_id" label="Source" required>
                <x-core::lookup
                    placeholder="Choose source"
                    :options="SolarHelper::model('lead_source')::toSelect()" />
            </x-core::field>

            <x-core::field id="opportunity-modal-budget:budget" label="Budget">
                <x-core::input number decimal prefix="Rp" />
            </x-core::field>
        </div>

        <div class="col-lg-6">
            <x-core::field id="opportunity-modal-customer_id:customer_id" label="Customer (Account)" required>
                <x-core::lookup
                    pagination
                    extend_columns="email,primary_phone,primary_contact"
                    placeholder="Choose an associated account"
                    source="Account"
                    link_url="/master-data/account/{id}" />
            </x-core::field>

            <x-core::field id="opportunity-modal-decision_maker_id:decision_maker_id" label="Decision maker (Contact)" lazy>
                <x-core::lookup
                    pagination
                    placeholder="Choose a contact person"
                    source="Contact"
                    link_url="/master-data/contact/{id}" />
            </x-core::field>

            <x-core::field id="opportunity-modal-phone:phone" label="Phone number">
                <x-core::input
                    phone="ID"
                    placeholder="Enter opportunity phone number"
                />
            </x-core::field>

            <x-core::field id="opportunity-modal-email:email" label="Email">
                <x-core::input
                    placeholder="Enter opportunity email address"
                />
            </x-core::field>
        </div>
    </div>

    <div class="row">
        <div class="col">
            <x-core::field id="opportunity-modal-customer_need:customer_need" label="Customer need" required>
                <x-core::textarea
                    placeholder="Describe the customer's needs or requirements"
                />
            </x-core::field>
        </div>
    </div>

</x-core::modal-form>
