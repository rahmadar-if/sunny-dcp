<x-core::modal-form
    id="opportunity-update-status-modal"
    title="Update Status"
    method="PUT"
    model="Opportunity"
    :action="route('sales.opportunity.update-status')"
    size="md">

    <x-core::field id="opportunity-update-status-modal-status_date:status_date" label="Status Date">
        <x-core::date-picker placeholder="Select status date"/>
    </x-core::field>

    <x-core::field id="opportunity-update-status-modal-latest_status:latest_status" label="Latest Status">
        <x-core::input placeholder="Enter latest status update"/>
    </x-core::field>

</x-core::modal-form>
