<x-core::table
    id="opportunity-product_list"
    class="table-hover"
    model="OpportunityProduct"
    new="@opportunity-product-modal"
    import export lazy
    :card_wrapper="false"
    filter="opportunity_id = {{ $id }}">

    <x-slot:column>
        <x-core::table-action-column :view="false"/>

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="product.name" 
            lookup="product_picture"
            searchable 
            orderable>
            Product
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="price" 
            searchable 
            orderable>
            Price
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="qty" 
            searchable 
            orderable>
            Quantity
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="disc" 
            searchable 
            orderable>
            Discount
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="total" 
            searchable 
            orderable>
            Total
        </x-core::table-column>
    </x-slot>

</x-core::table>

@push('modal-content')
    @include("sales::pages.opportunity.product.modal", ["id" => $data->id])
@endpush