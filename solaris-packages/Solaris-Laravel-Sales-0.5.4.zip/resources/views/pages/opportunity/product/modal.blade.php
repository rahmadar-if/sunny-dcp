<x-core::modal-form
    id="opportunity-product-modal"
    title="Product"
    model="OpportunityProduct">

    <div class="row">
        <div class="col-lg-6">
            <x-core::field id="opportunity-product-modal-product_id:product_id" label="Product" required lazy>
                <x-core::lookup
                    pagination
                    placeholder="Choose product to add to order"
                    extend_columns="price,availability,category,brand,product_picture_id,unit_of_measure"
                    source="Product@availableInOpportunityProduct({{ $id }})"
                    link_url="/master-data/product/{id}" />
            </x-core::field>

            <div class="row g-2">
                <div class="col">
                    <x-core::field label="Price" id="opportunity-product-modal-price:price" required>
                        <x-core::input
                            number decimal
                            prefix="Rp "
                            placeholder="Price per item"/>
                    </x-core::field>
                </div>
                <div class="col-5">
                    <x-core::field label="Unit" id="opportunity-product-modal-unit_of_measure:unit_of_measure">
                        <x-core::input disabled placeholder="Unit of measure"/>
                    </x-core::field>
                </div>
            </div>

            <x-core::field label="Quantity" id="opportunity-product-modal-qty:qty" required>
                <x-core::input
                    number
                    placeholder="Enter quantity"/>
            </x-core::field>
        </div>
        <div class="col-lg-6">
            <x-core::field label="Amount" id="opportunity-product-modal-amount:amount" disabled>
                <x-core::input
                    number decimal
                    prefix="Rp "
                    placeholder="Will be calculated automatically"/>
            </x-core::field>

            <div class="row g-2">
                <div class="col">
                    <x-core::field label="Discount" id="opportunity-product-modal-disc:disc">
                        <x-core::input
                            number decimal
                            prefix="Rp "
                            placeholder="0"/>
                    </x-core::field>
                </div>
                <div class="col-5">
                    <x-core::field label="Disc %" id="opportunity-product-modal-disc_percent:disc_percent">
                        <x-core::input
                            number decimal
                            placeholder="0"/>
                    </x-core::field>
                </div>
            </div>

            <x-core::field label="Total" id="opportunity-product-modal-total:total" disabled>
                <x-core::input
                    number decimal
                    prefix="Rp "
                    placeholder="Will be calculated automatically"/>
            </x-core::field>
        </div>
    </div>

</x-core::modal-form>
