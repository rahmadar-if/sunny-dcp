<x-core::modal-form 
    id="opportunity-team-modal" 
    title="Team" 
    size="md"
    model="OpportunityTeam">

    <x-core::field id="opportunity-team-modal-name:name" label="Name" required>
        <x-core::input
            id="opportunity-team-modal-name"
            placeholder="Enter Name"
        />
    </x-core::field>

    <x-core::field id="opportunity-team-modal-role:role" label="Role" required>
        <x-core::input
            id="opportunity-team-modal-role"
            placeholder="Enter role"
        />
    </x-core::field>

</x-core::modal>
