<x-core::table
    id="opportunity-team_list" 
    class="table-hover"
    model="OpportunityTeam"
    new="@opportunity-team-modal"
    import export
    :card_wrapper="false"
    filter="opportunity_id = {{ $id }}">
    
    <x-slot:column>
        <x-core::table-action-column :view="false"/>

        <x-core::table-column 
            data="name" 
            searchable 
            orderable>
            Name
        </x-core::table-column>
        
        <x-core::table-column 
            data="role" 
            searchable 
            orderable>
            Role
        </x-core::table-column>
    </x-slot>

</x-core::table>

@push('modal-content')
    @include("sales::pages.opportunity.team.modal")
@endpush