<x-core::table
    id="opportunity-quotation-history_list"
    class="table-hover"
    model="OpportunityQuotationHistory"
    :new="false"
    import export lazy
    :card_wrapper="false"
    filter="opportunity_id = {{ $id }}">

    <x-slot:column>
        <x-core::table-action-column :view="false" :edit="false"/>

        <x-core::table-column
            cell_class="text-nowrap"
            data="date"
            searchable
            orderable>
            Date
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="number_quotation"
            searchable
            orderable>
            Quotation Number
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="total_amount"
            searchable
            orderable
            type="number"
            format="currency">
            Total Amount
        </x-core::table-column>
    </x-slot>

</x-core::table>
