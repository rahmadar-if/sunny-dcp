<x-core::table
    id="opportunity-term-condition_list" 
    class="table-hover"
    model="OpportunityTermCondition"
    new="@opportunity-term-condition-modal"
    import export lazy
    :card_wrapper="false"
    filter="opportunity_id = {{ $id }}">

    <x-slot:column>
        <x-core::table-action-column :view="false"/>

        <x-core::table-column
            data="subject" 
            searchable 
            orderable>
            Subject
        </x-core::table-column>
    </x-slot>
    
</x-core::table>

@push('modal-content')
    @include("sales::pages.opportunity.term-condition.modal")
@endpush