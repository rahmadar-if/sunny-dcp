<x-core::modal-form
	id="opportunity-term-condition-modal"
	title="Term & Condition" 
    size="md"
    model="OpportunityTermCondition">

    <x-core::field id="opportunity-term-condition-modal-subject:subject" label="Subject">
        <x-core::textarea
            id="opportunity-term-condition-modal-subject"
            placeholder="Enter subject"
            rows="3"
        />
    </x-core::field>

</x-core::modal>
