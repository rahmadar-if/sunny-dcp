<x-core::table
    id="opportunity-order_list"
    class="table-hover"
    model="Order"
    :new="false"
    :import="false"
    export lazy
    :card_wrapper="false"
    filter="opportunity_id = {{ $id }}">

    <x-slot:column>
        <x-core::table-action-column :view="false"/>

        <x-core::table-column
            cell_class="text-nowrap"
            data="number"
            searchable
            orderable>
            Order No
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="date"
            searchable
            orderable>
            Date
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="status.name"
            searchable
            orderable>
            Status
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="amount"
            searchable
            orderable>
            Amount
        </x-core::table-column>
    </x-slot>

</x-core::table>
