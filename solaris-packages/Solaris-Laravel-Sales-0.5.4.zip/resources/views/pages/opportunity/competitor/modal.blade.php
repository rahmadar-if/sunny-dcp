<x-core::modal-form
	id="opportunity-competitor-modal"
	title="Competitor"
    model="OpportunityCompetitor">

    <div class="row">
        <div class="col-lg-6">
            <x-core::field id="opportunity-competitor-modal-name:name" label="Name" required>
                <x-core::input
                    id="opportunity-competitor-modal-name"
                    placeholder="What is their name?"
                />
            </x-core::field>

            <x-core::field id="opportunity-competitor-modal-total_amount:total_amount" label="Total Amount">
                <x-core::input
                    number
                    id="opportunity-competitor-modal-total_amount"
                    placeholder="Total Amount"
                />
            </x-core::field>

            <x-core::field id="opportunity-competitor-modal-rating:rating" label="Rating">
                <x-core::input
                    number
                    id="opportunity-competitor-modal-rating"
                    placeholder="Give them score"
                />
            </x-core::field>
        </div>

        <div class="col-lg-6">
            <x-core::field id="opportunity-competitor-modal-strength:strength" label="Strength">
                <x-core::textarea
                    id="opportunity-competitor-modal-strength"
                    placeholder="What their strength"
                    rows="3"
                />
            </x-core::field>

            <x-core::field id="opportunity-competitor-modal-weakness:weakness" label="Weakness">
                <x-core::textarea
                    id="opportunity-competitor-modal-weakness"
                    placeholder="What their weakness"
                    rows="3"
                />
            </x-core::field>
        </div>
    </div>

</x-core::modal>
