<x-core::table
    id="opportunity-competitor_list"
    class="table-hover"
    model="OpportunityCompetitor"
    new="@opportunity-competitor-modal"
    import export lazy
    :card_wrapper="false"
    filter="opportunity_id = {{ $id }}">

    <x-slot:column>
        <x-core::table-action-column :view="false"/>

        <x-core::table-column
            cell_class="text-nowrap"
            data="name"
            searchable
            orderable>
            Name
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="total_amount"
            searchable
            orderable>
            Total Amount
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="rating"
            searchable
            orderable>
            Rating
        </x-core::table-column>

        <x-core::table-column
            data="strength"
            searchable
            orderable>
            Strength
        </x-core::table-column>

        <x-core::table-column
            data="weakness"
            searchable
            orderable>
            Weakness
        </x-core::table-column>
    </x-slot>

</x-core::table>

@push('modal-content')
    @include("sales::pages.opportunity.competitor.modal")
@endpush
