<x-core::table
    id="opportunity-contact_list" 
    class="table-hover"
    model="OpportunityContact"
    new="@opportunity-contact-modal"
    import export lazy
    :card_wrapper="false"
    filter="opportunity_id = {{ $id }}">

    <x-slot:column>
        <x-core::table-action-column :view="false"/>

        <x-core::table-column
            data="contact.name" 
            lookup="profile_picture_id" 
            searchable 
            orderable>
            Contact
        </x-core::table-column>
        
        <x-core::table-column 
            data="role" 
            searchable
            orderable>
            Role
        </x-core::table-column>
        
        <x-core::table-column 
            data="is_decision_maker"
            type="bool"
            format="badge@Yes|No">
            Decision maker
        </x-core::table-column>
    </x-slot>

</x-core::table>

@push('modal-content')
    @include("sales::pages.opportunity.contact.modal", ["id" => $data->id])
@endpush