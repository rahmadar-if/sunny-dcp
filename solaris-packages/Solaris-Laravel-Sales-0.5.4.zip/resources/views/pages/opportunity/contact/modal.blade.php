<x-core::modal-form
	id="opportunity-contact-modal"
	title="Contact"
	size="md"
    model="OpportunityContact">

    <x-core::field label="Contact" id="opportunity-contact-modal-contact_id:contact_id" required>
        <x-core::lookup
            pagination
            placeholder="Choose contact"
            Source="Contact@availableInOpportunityContact({{ $id }})"
            link_url="/master-data/contact/{id}"
        />
    </x-core::field>

    <x-core::field id="opportunity-contact-modal-role:role" label="Role" required>
        <x-core::input
            placeholder="Enter role"
        />
    </x-core::field>

    <x-core::field id="opportunity-contact-modal-is_decision_maker:is_decision_maker">
        <x-core::checkbox
            label="Decision maker"
        />
    </x-core::field>

</x-core::modal>
