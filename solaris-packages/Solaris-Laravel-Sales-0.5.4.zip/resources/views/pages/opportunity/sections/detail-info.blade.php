@php
    $id = "opportunity-page-tabs_detail_info";
@endphp

<x-core::tab-content :id="$id" :active="$active ?? false" class="p-0 border-0">
    <x-core::tab id="{{ $id }}-tabs" variant="tab-style-7" class="scaleX p-0 mb-4">
        <x-slot:nav>
            <x-core::tab-nav id="{{ $id }}-tabs_team" active>Team</x-core::tab-nav>
            <x-core::tab-nav id="{{ $id }}-tabs_contact">Contacts</x-core::tab-nav>
            <x-core::tab-nav id="{{ $id }}-tabs_competitors">Competitors</x-core::tab-nav>
            <x-core::tab-nav id="{{ $id }}-tabs_terms">Terms & Conditions</x-core::tab-nav>
        </x-slot>

        <x-slot:content>
            <x-core::tab-content id="{{ $id }}-tabs_team" active class="p-0 border-0">
                @include('sales::pages.opportunity.team.list', ['id' => $data->id])
            </x-core::tab-content>

            <x-core::tab-content id="{{ $id }}-tabs_contact" class="p-0 border-0">
                @include('sales::pages.opportunity.contact.list', ['id' => $data->id])
            </x-core::tab-content>

            <x-core::tab-content id="{{ $id }}-tabs_competitors" class="p-0 border-0">
                @include('sales::pages.opportunity.sections.competitor', ['data' => $data])
            </x-core::tab-content>

            <x-core::tab-content id="{{ $id }}-tabs_terms" class="p-0 border-0">
                @include('sales::pages.opportunity.term-condition.list', ['id' => $data->id])
            </x-core::tab-content>
        </x-slot>
    </x-core::tab>
</x-core::tab-content>