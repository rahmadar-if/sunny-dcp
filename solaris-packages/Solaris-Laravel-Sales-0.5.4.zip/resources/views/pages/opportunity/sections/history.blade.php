@php
    $id = "opportunity-page-tabs_history";
@endphp

<x-core::tab-content :id="$id" :active="$active ?? false" class="p-0 border-0">
    <x-core::tab id="{{ $id }}-tabs" variant="tab-style-7" class="scaleX p-0 mb-4">
        <x-slot:nav>
            <x-core::tab-nav id="{{ $id }}-tabs_activity" active>Activity</x-core::tab-nav>
            <x-core::tab-nav id="{{ $id }}-tabs_order">Order</x-core::tab-nav>
            <x-core::tab-nav id="{{ $id }}-tabs_status">Status History</x-core::tab-nav>
        </x-slot>

        <x-slot:content>
            <x-core::tab-content id="{{ $id }}-tabs_activity" active class="p-0 border-0">
                @include('sales::pages.opportunity.activity.list', ['id' => $data->id])
            </x-core::tab-content>

            <x-core::tab-content id="{{ $id }}-tabs_order" class="p-0 border-0">
                @include('sales::pages.opportunity.order.list', ['id' => $data->id])
            </x-core::tab-content>

            <x-core::tab-content id="{{ $id }}-tabs_status" class="p-0 border-0">
                @include('sales::pages.opportunity.status-history.list', ['id' => $data->id])
            </x-core::tab-content>
        </x-slot>
    </x-core::tab>
</x-core::tab-content>
