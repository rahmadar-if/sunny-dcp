@php
    $id = "opportunity-page-tabs_quotation";
@endphp

<x-core::tab-content :id="$id" :active="$active ?? false" class="p-0 border-0">
    @include('sales::pages.opportunity.quotation-history.list', ['id' => $data->id])
</x-core::tab-content>
