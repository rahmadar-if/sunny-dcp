@php
    $id = "opportunity-page-tabs_product";
@endphp

<x-core::tab-content :id="$id" :active="$active ?? false" class="p-0 border-0">    
    <div class="row">
        <div class="col-md-6">        
            <x-core::field id="opportunity-page-amount:amount" label="Amount" disabled>
                <x-core::input
                    id="opportunity-page-amount"
                    number decimal prefix="Rp"
                    :value="$data->amount"
                />
            </x-core::field>
            
            <div class="row g-2">
                <div class="col">
                    <x-core::field id="opportunity-page-discount_amount:discount_amount" label="Discount" disabled>
                        <x-core::input
                            id="opportunity-page-discount_amount"
                            number decimal prefix="Rp"
                            :value="$data->discount_amount"
                        />
                    </x-core::field>
                </div>

                <div class="col-5">
                    <x-core::field label="Disc %" id="opportunity-page-discount_percent:discount_percent" disabled>
                        <x-core::input
                            number decimal
                            :value="$data->discount_percent" />
                    </x-core::field>
                </div>
            </div>
        </div>

        <div class="col-md-6 d-flex align-items-end">        
            <x-core::field id="opportunity-page-total_amount:total_amount" label="Total Amount" field:class="w-100" disabled>
                <x-core::input
                    id="opportunity-page-total_amount"
                    number decimal prefix="Rp"
                    :value="$data->total_amount"
                />
            </x-core::field>

        </div>
    </div>

    @include('sales::pages.opportunity.product.list', ['id' => $data->id])
</x-core::tab-content>