<div class="row">
    <div class="col-md-6">
        <x-core::field id="opportunity-page-our_weaknesses:our_weaknesses" label="Our Weakness">
            <x-core::textarea
                id="opportunity-page-our_weaknesses"
                placeholder="What is our weakness"
                :value="$data->our_weaknesses"
            />
        </x-core::field>

        <x-core::field id="opportunity-page-our_strengths:our_strengths" label="Our Strengths">
            <x-core::textarea
                id="opportunity-page-our_strengths"
                placeholder="What is our strengths"
                :value="$data->our_strengths"
            />
        </x-core::field>
    </div>

    <div class="col-md-6">
        <x-core::field id="opportunity-page-sales_tactics:sales_tactics" field:class="w-100" label="Sales Tactics">
            <x-core::textarea
                id="opportunity-page-sales_tactics"
                placeholder="What is our tactics"
                :value="$data->sales_tactics"
            />
        </x-core::field>
    </div>
</div>

@include('sales::pages.opportunity.competitor.list', ["id" => $data->id])