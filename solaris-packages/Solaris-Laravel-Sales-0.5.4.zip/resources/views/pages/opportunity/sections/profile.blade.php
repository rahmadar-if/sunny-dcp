@php
    $customer       = $data->customer;
    $decisionMaker  = $data->decision_maker;
    $lead           = $data->lead;
    $owner          = $data->owner ?? $data->created_by;
    $ownerPictureId = $owner?->profile_picture_id;
    $customerLinked = (bool) $data->customer_id;
    $dmLinked       = (bool) $data->decision_maker_id;
    $probability    = $data->status?->probability ?? 0;
    $statusColor    = $data->status?->color;
    $isNewCustomerLocked = $data->lead_id && ($data->lead?->is_new_contact || $data->lead?->is_new_account);

    $daysInFunnel = $data->status?->is_final_stage
        ? $data->days_in_funnel
        : max(0, $data->date?->copy()->startOfDay()->diffInDays(now()->startOfDay(), false) ?? 0);
@endphp

<x-core::input id="opportunity-page-customer_id:customer_id" type="hidden" :value="$data->customer_id" />
<x-core::input id="opportunity-page-decision_maker_id:decision_maker_id" type="hidden" :value="$data->decision_maker_id" />

{{-- Customer Info --}}
<div class="card custom-card">
    <div class="card-body">

        {{-- Account --}}
        <div id="opportunity-customer-section" class="mb-3">
            <div class="d-flex align-items-center justify-content-between mb-2">
                <p id="opportunity-customer-label" class="fs-11 fw-semibold text-uppercase text-muted mb-0">Customer</p>
                <div class="d-flex gap-1">
                    <x-core::button variant="outline" color="secondary" size="sm" id="opportunity-customer-change-btn">
                        <i class="ri-edit-line"></i>
                    </x-core::button>
                    <x-core::button variant="outline" color="danger" size="sm" id="opportunity-customer-clear-btn" :disabled="!$customerLinked">
                        <i class="ri-close-line"></i>
                    </x-core::button>
                </div>
            </div>
            <a id="opportunity-customer-link"
               href="{{ $customerLinked ? url('master-data/account/' . $customer->id) : '#' }}"
               class="d-flex align-items-center gap-2 text-decoration-none">
                <div id="opportunity-customer-avatar" class="avatar avatar-sm rounded-circle {{ $customerLinked && $customer->profile_picture_id ? '' : 'bg-primary' }} d-flex align-items-center justify-content-center flex-shrink-0 overflow-hidden">
                    @if($customerLinked && $customer->profile_picture_id)
                        <img src="{{ url('core/images/thumbnail/' . $customer->profile_picture_id) }}" alt="" class="w-100 h-100 object-fit-cover">
                    @else
                        <span class="fs-13 fw-semibold text-white">{{ $customerLinked ? strtoupper(substr($customer->name, 0, 1)) : '?' }}</span>
                    @endif
                </div>
                <div class="overflow-hidden flex-grow-1">
                    <p id="opportunity-customer-name" class="mb-0 fw-medium fs-13 text-truncate {{ $customerLinked ? 'text-dark' : 'text-muted' }}">{{ $customer?->name ?? '—' }}</p>
                    <p id="opportunity-customer-sub" class="mb-0 fs-12 text-muted text-truncate">{{ $customer?->industry?->name ?? '' }}</p>
                </div>
            </a>
            <p id="opportunity-customer-error" class="text-danger fs-12 mb-0 mt-2 d-none">Customer is required.</p>
        </div>

        <hr class="my-3">

        {{-- Decision Maker --}}
        <div class="mb-3">
            <div class="d-flex align-items-center justify-content-between mb-2">
                <p class="fs-11 fw-semibold text-uppercase text-muted mb-0">Decision Maker</p>
                <div class="d-flex gap-1">
                    <x-core::button variant="outline" color="secondary" size="sm" id="opportunity-dm-change-btn">
                        <i class="ri-edit-line"></i>
                    </x-core::button>
                    <x-core::button variant="outline" color="danger" size="sm" id="opportunity-dm-clear-btn" :disabled="!$dmLinked">
                        <i class="ri-close-line"></i>
                    </x-core::button>
                </div>
            </div>
            <a id="opportunity-dm-link"
               href="{{ $dmLinked ? url('master-data/contact/' . $decisionMaker->id) : '#' }}"
               class="d-flex align-items-center gap-2 text-decoration-none">
                @php $dmPictureId = $decisionMaker?->profile_picture_id ?? $decisionMaker?->profile_picture?->id @endphp
                <div id="opportunity-dm-avatar" class="avatar avatar-sm rounded-circle {{ $dmLinked && $dmPictureId ? '' : 'bg-info' }} d-flex align-items-center justify-content-center flex-shrink-0 overflow-hidden">
                    @if($dmLinked && $dmPictureId)
                        <img src="{{ url('core/images/thumbnail/' . $dmPictureId) }}" alt="" class="w-100 h-100 object-fit-cover">
                    @else
                        <span class="fs-13 fw-semibold text-white">{{ $dmLinked ? strtoupper(substr($decisionMaker->name, 0, 1)) : '?' }}</span>
                    @endif
                </div>
                <div class="overflow-hidden flex-grow-1">
                    <p id="opportunity-dm-name" class="mb-0 fw-medium fs-13 text-truncate {{ $dmLinked ? 'text-dark' : 'text-muted' }}">{{ $decisionMaker?->name ?? '—' }}</p>
                    <p id="opportunity-dm-sub" class="mb-0 fs-12 text-muted text-truncate">{{ $decisionMaker?->job_title ?? '' }}</p>
                </div>
            </a>
        </div>

        <hr class="mb-3">

        {{-- New Customer --}}
        <x-core::checkbox 
            id="opportunity-page-is_new_customer:is_new_customer" 
            label="New Customer" 
            switch 
            :checked="$data->is_new_customer" 
            :disabled="$isNewCustomerLocked" />

        @if($lead)
        <hr class="my-3">

        {{-- Lead --}}
        <div class="mb-3">
            <p class="fs-11 fw-semibold text-uppercase text-muted mb-2">Lead</p>
            <a href="{{ url('sales/lead/' . $lead->id) }}" class="d-flex flex-column gap-1 text-decoration-none">
                <span class="fw-medium fs-13 text-dark">{{ $lead->name }}</span>
                <span class="fs-12 text-muted"><i class="ri-calendar-line me-1"></i>{{ $lead->date?->format('d M Y') ?? '' }}</span>
                <span class="fs-12 text-muted"><i class="ri-money-dollar-circle-line me-1"></i>{{ $lead->budget ? 'Rp ' . SolarNumber::readableNumber($lead->budget) : ($lead->budget_range?->name ?? '—') }}</span>
            </a>
        </div>
        @endif

        <hr class="my-3">

        {{-- Owner --}}
        <div class="mb-3">
            <p class="fs-11 fw-semibold text-uppercase text-muted mb-2">Owner</p>
            <div class="d-flex align-items-center gap-2">
                <div class="avatar avatar-sm rounded-circle {{ $ownerPictureId ? '' : 'bg-primary' }} d-flex align-items-center justify-content-center flex-shrink-0 overflow-hidden">
                    @if($ownerPictureId)
                        <img src="{{ url('core/images/thumbnail/' . $ownerPictureId) }}" alt="" class="w-100 h-100 object-fit-cover">
                    @else
                        <span class="fs-13 fw-semibold text-white">{{ SolarHelper::getInitialName($owner?->name ?? '?') }}</span>
                    @endif
                </div>
                <div class="overflow-hidden flex-grow-1">
                    <p class="mb-0 fw-medium fs-13 text-truncate text-dark">{{ $owner?->name }}</p>
                    <p class="mb-0 fs-12 text-muted text-truncate">{{ $owner?->email ?? $owner?->username }}</p>
                </div>
            </div>
        </div>

    </div>
</div>

{{-- Status --}}
<div class="card custom-card">
    <div class="card-body">

        <p class="fs-11 fw-semibold text-uppercase text-muted mb-3">Status</p>

        <x-core::field id="opportunity-page-status_date:status_date" label="Status Date">
            <x-core::date-picker placeholder="Select date" :value="$data->status_date" />
        </x-core::field>

        <x-core::field id="opportunity-page-latest_status:latest_status" label="Latest Status">
            <x-core::input placeholder="Enter latest status" :value="$data->latest_status" />
        </x-core::field>

    </div>
</div>

{{-- Funnel --}}
<div class="card custom-card">
    <div class="card-body">

        <p class="fs-11 fw-semibold text-uppercase text-muted mb-3">Funnel</p>

        <x-core::field id="opportunity-page-closed_on:closed_on" label="Closed On" disabled>
            <x-core::date-picker placeholder="—" :value="$data->closed_on" />
        </x-core::field>

        <x-core::field id="opportunity-page-days_in_funnel:days_in_funnel" label="Days in Funnel" disabled>
            <x-core::input :value="$daysInFunnel" />
        </x-core::field>

        <div>
            <x-core::label>Probability</x-core::label>
            <div class="d-flex align-items-center gap-2">
                <div class="progress flex-grow-1" style="height: 8px;">
                    <div id="opportunity-probability-fill"
                         class="progress-bar bg-{{ $statusColor }}"
                         style="width: {{ $probability }}%">
                    </div>
                </div>
                <span id="opportunity-probability-text" class="fs-12 fw-medium text-nowrap">{{ $probability }}%</span>
            </div>
        </div>

    </div>
</div>

{{-- Table Lookups --}}
<x-core::table-lookup id="opportunity-customer-lookup" model="Account" title="Choose Account">
    <x-slot:column>
        <x-core::table-column cell_class="text-nowrap" data="name">Name</x-core::table-column>
        <x-core::table-column data="email">Email</x-core::table-column>
        <x-core::table-column data="primary_phone">Primary Phone</x-core::table-column>
        <x-core::table-column data="industry.name">Industry</x-core::table-column>
    </x-slot>
</x-core::table-lookup>

<x-core::table-lookup id="opportunity-dm-lookup" model="Contact" title="Choose Decision Maker">
    <x-slot:column>
        <x-core::table-column cell_class="text-nowrap" data="name">Name</x-core::table-column>
        <x-core::table-column data="primary_phone">Primary Phone</x-core::table-column>
        <x-core::table-column data="email">Email</x-core::table-column>
        <x-core::table-column data="job_title">Job Title</x-core::table-column>
    </x-slot>
</x-core::table-lookup>
