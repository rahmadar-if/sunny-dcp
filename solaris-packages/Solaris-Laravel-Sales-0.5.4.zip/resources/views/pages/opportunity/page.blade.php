@php
    use Solaris\Sales\Const\OpportunityStatusConst;
@endphp

<x-core::page.edit
    :id="$data->id"
    title="Opportunity"
    :breadcrumbs="$breadcrumbs"
    model="Opportunity"
    package="sales"
    path="opportunity/page-index"
    profile-position="left">

    <x-slot:header>
        <div class="mb-3">
            <x-core::stage-buttons 
                id="opportunity-page-status_id:status_id" 
                :stages="SolarHelper::model('opportunity_status')::toStage(confirm: true, next: [
                    OpportunityStatusConst::Qualification => [OpportunityStatusConst::Proposal, OpportunityStatusConst::ClosedLost],
                    OpportunityStatusConst::Proposal => [OpportunityStatusConst::Qualification, OpportunityStatusConst::Negotiation, OpportunityStatusConst::ClosedLost],
                    OpportunityStatusConst::Negotiation => [OpportunityStatusConst::Proposal, OpportunityStatusConst::ClosedWon, OpportunityStatusConst::ClosedLost]
                ])"
                :value="$data->status_id" />
        </div>
    </x-slot>

    <x-slot:pre-buttons>
        <x-core::button id="opportunity-print-quotation-btn" color="primary" variant="outline">
            <i class="ri-printer-line me-1"></i> Print Quotation
        </x-core::button>

        <x-core::button id="opportunity-create-order-btn" color="success" variant="outline" :disabled="$data->status_id != OpportunityStatusConst::ClosedWon">
            <i class="ri-shopping-cart-line me-1"></i> Create Order
        </x-core::button>
    </x-slot:pre-buttons>

    <x-slot:profile>
        @include('sales::pages.opportunity.sections.profile', ["data" => $data])
    </x-slot>

    <x-core::fieldset label="General" class="mb-3" />
    <div class="row mb-3">
        <div class="col-md-6">
            <x-core::field id="opportunity-page-name:name" label="Name" required>
                <x-core::input placeholder="Enter opportunity name" :value="$data->name" />
            </x-core::field>

            <x-core::field id="opportunity-page-date:date" label="Date" required>
                <x-core::date-picker placeholder="Select opportunity date" :value="$data->date" />
            </x-core::field>

            <x-core::field id="opportunity-page-source_id:source_id" label="Source">
                <x-core::lookup
                    placeholder="Choose source"
                    :options="SolarHelper::model('lead_source')::toSelect()"
                    :value="json_encode($data->source)" />
            </x-core::field>

            <x-core::field id="opportunity-page-type_id:type_id" label="Type" required>
                <x-core::lookup
                    placeholder="Choose type"
                    :options="SolarHelper::model('opportunity_type')::toSelect()"
                    :value="json_encode($data->type)" />
            </x-core::field>
        </div>
        <div class="col-md-6">
            <x-core::field id="opportunity-page-budget:budget" label="Budget">
                <x-core::input number decimal prefix="Rp" :value="$data->budget" />
            </x-core::field>

            <x-core::field id="opportunity-page-quotation_number:quotation_number" label="No. Quotation">
                <x-core::input placeholder="Enter quotation number" :value="$data->quotation_number" />
            </x-core::field>

            <x-core::field id="opportunity-page-phone:phone" label="Phone">
                <x-core::input placeholder="Enter phone number" :value="$data->phone" />
            </x-core::field>

            <x-core::field id="opportunity-page-email:email" label="Email">
                <x-core::input placeholder="Enter email address" :value="$data->email" />
            </x-core::field>
        </div>
    </div>

    <x-core::fieldset label="Notes" />
    <div class="row">
        <div class="col-md-6">
            <x-core::field id="opportunity-page-customer_need:customer_need" label="Customer Needs" required>
                <x-core::textarea rows="4" placeholder="Describe the customer's needs or requirements" :value="$data->customer_need" />
            </x-core::field>
        </div>
        <div class="col-md-6">
            <x-core::field id="opportunity-page-description:description" label="Description">
                <x-core::textarea placeholder="Tell us a story" rows="4" :value="$data->description" />
            </x-core::field>
        </div>
    </div>

    <x-slot:footer>

        @php
            $tabId = "opportunity-page-tabs";
        @endphp

        <div class="card custom-card">
            <div class="card-body">
                <x-core::tab id="{{ $tabId }}" class="p-0 mb-4">
                    <x-slot:nav>
                        <x-core::tab-nav id="{{ $tabId }}_product" active>Product</x-core::tab-nav>
                        <x-core::tab-nav id="{{ $tabId }}_detail_info">Detail Info</x-core::tab-nav>
                        <x-core::tab-nav id="{{ $tabId }}_quotation">Quotation</x-core::tab-nav>
                        <x-core::tab-nav id="{{ $tabId }}_history">History</x-core::tab-nav>
                        <x-core::tab-nav id="{{ $tabId }}_attachment">Attachment</x-core::tab-nav>
                        <x-core::tab-nav id="{{ $tabId }}_notes">Notes</x-core::tab-nav>
                    </x-slot>

                    <x-slot:content>
                        @include('sales::pages.opportunity.sections.product', ["data" => $data, "active" => true])
                        @include('sales::pages.opportunity.sections.detail-info', ["data" => $data])
                        @include('sales::pages.opportunity.sections.quotation', ["data" => $data])
                        @include('sales::pages.opportunity.sections.history', ["data" => $data])

                        <x-core::tab-content id="{{ $tabId }}_attachment" class="p-0 border-0">
                            <x-core::attachment id="opportunity-page-attachment" relation="opportunities:{{ $data->id }}"/>
                        </x-core::tab-content>

                        <x-core::tab-content id="{{ $tabId }}_notes" class="p-0 border-0">
                            <x-core::notes
                                id="opportunity-page-notes:notes"
                                model="Opportunity"
                                column="notes"
                                :record_id="$data->id">{!! $data->notes !!}</x-core::notes>
                        </x-core::tab-content>
                    </x-slot>
                </x-core::tab>
            </div>
        </div>

    </x-slot>

    @push('scripts')
    <script>
        const OPPORTUNITY_STATUS = {{ Js::from(SolarHelper::model('opportunity_status')::toLookup()) }}
    </script>
    @endpush

</x-core::page.edit>
