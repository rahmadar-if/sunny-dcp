@php
    use Solaris\Sales\Const\OpportunityStatusConst;
@endphp

<x-sales::opportunity.list
    id="opportunity"
    model="Opportunity"
    package="sales"
    path="opportunity/list-index"
    :breadcrumbs="$breadcrumbs"
    new="@opportunity-modal"
    table:class="table-hover"
    extend_columns="created_by,phone,email,date,status,status_date,latest_status,amount,discount_percent,discount_amount,type,decision_maker[profile_picture]"
    :kanban:view="false"
    kanban:columns="created_by,date,name,status,source,customer[name,profile_picture],budget,total_amount,customer_need,decision_maker[name,profile_picture]"
    :kanban:newExcept="json_encode([OpportunityStatusConst::ClosedWon, OpportunityStatusConst::ClosedLost])"
    :kanban:noDragBoards="json_encode([OpportunityStatusConst::ClosedWon, OpportunityStatusConst::ClosedLost])"
    import export folder lazy>

    <x-slot:listHeader>
        <div class="row row-cols-1 row-cols-sm-2 row-cols-xl-5 g-3">
            <div class="col">
                <x-core::metric
                    id="opportunity_total_metric"
                    variant="simple"
                    title="Total Opportunity"
                    tooltip="Number of opportunities matching the current filter and search."
                    :decimal="0"
                    numeral
                    lazy />
            </div>

            <div class="col">
                <x-core::metric
                    id="opportunity_amount_metric"
                    variant="simple"
                    title="Total Amount"
                    tooltip="Total amount of all opportunities except Closed Lost, matching the current filter and search."
                    prefix="Rp"
                    numeral
                    lazy />
            </div>

            <div class="col">
                <x-core::metric
                    id="opportunity_closed_won_metric"
                    variant="simple"
                    title="Closed Won"
                    tooltip="Number of opportunities with Closed Won status, matching the current filter and search."
                    :decimal="0"
                    numeral
                    lazy />
            </div>

            <div class="col">
                <x-core::metric
                    id="opportunity_closed_won_amount_metric"
                    variant="simple"
                    title="Closed Won Amount"
                    tooltip="Total amount of opportunities with Closed Won status, matching the current filter and search."
                    prefix="Rp"
                    numeral
                    lazy />
            </div>

            <div class="col">
                <x-core::metric
                    id="opportunity_progress_metric"
                    variant="simple"
                    title="In Progress"
                    tooltip="Number of opportunities that are still open — excludes Closed Won and Closed Lost."
                    :decimal="0"
                    numeral
                    lazy />
            </div>
        </div>
    </x-slot:listHeader>

    <x-slot:table-pre-right-action>
        <x-core::lookup
            id="opportunity_owner_filter"
            placeholder="Choose sales"
            size="sm"
            source="user"
            wrapper_style="width: 250px"
            :copy="false"
            disabled
            ignore />

        <x-core::lookup
            id="opportunity_status_filter"
            placeholder="Choose status" 
            size="sm"
            multiple
            :options="SolarHelper::model('opportunity_status')::toSelect()"
            wrapper_style="width: 350px"
            :copy="false"
            disabled
            ignore />
    </x-slot:table-pre-right-action>

    <x-slot:table-column>
        <x-core::table-action-column :view="false"/>

        <x-core::table-column
            cell_class="text-nowrap"
            data="date"
            searchable
            orderable>
            Name / Date
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="status.name">
            Status / Update
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="total_amount"
            searchable
            orderable>
            Amount / Total
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="type.name"
            searchable
            orderable>
            Type
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="customer.name"
            lookup="profile_picture"
            searchable
            orderable>
            Account / Contact
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="phone"
            searchable
            orderable>
            Phone / Email
        </x-core::table-column>

        <x-core::table-column
            data="customer_need"
            searchable
            orderable>
            Customer Need
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="lead.name"
            lookup="date,budget_range"
            searchable
            orderable>
            Lead
        </x-core::table-column>
    </x-slot>

    @push('modal-content')
        @include("sales::pages.opportunity.modal")
        @include("sales::pages.opportunity.modal-update-status")
        @include("master-data::pages.activity.modal")
    @endpush

</x-sales::opportunity.list>
