<x-core::table
    id="account-order_list"
    class="table-hover"
    model="Order"
    :new="false"
    export lazy delete_all
    extend_columns="date,status,amount"
    :card_wrapper="false"
    filter="account_id = {{ $id }}">

    <x-slot:column>
        <x-core::table-column
            cell_class="text-nowrap"
            data="number"
            searchable
            orderable>
            Number
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="date"
            searchable
            orderable>
            Date
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="status.name"
            searchable
            orderable>
            Status
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="amount"
            searchable
            orderable>
            Total
        </x-core::table-column>
    </x-slot>

</x-core::table>
