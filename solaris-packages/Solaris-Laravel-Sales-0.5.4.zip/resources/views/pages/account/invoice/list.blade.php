<x-core::table
    id="account-invoice_list"
    class="table-hover"
    model="Invoice"
    :new="false"
    export lazy delete_all
    extend_columns="due_date,status,amount"
    :card_wrapper="false"
    filter="account_id = {{ $id }}">

    <x-slot:column>
        <x-core::table-column
            cell_class="text-nowrap"
            data="number"
            searchable
            orderable>
            Number
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="subject"
            searchable
            orderable>
            Subject
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="due_date"
            searchable
            orderable>
            Due Date
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="status.name"
            searchable
            orderable>
            Status
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="amount"
            searchable
            orderable>
            Total
        </x-core::table-column>
    </x-slot>

</x-core::table>
