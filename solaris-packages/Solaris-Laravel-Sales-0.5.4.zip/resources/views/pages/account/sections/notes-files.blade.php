@php
	$id = "account-page-tabs_notes_files";
@endphp

<x-core::tab-content :id="$id" :active="$active ?? false" class="p-0 border-0">
	<x-core::tab id="{{ $id }}-tabs" variant="tab-style-7" class="scaleX p-0 mb-4">
		<x-slot:nav>
			{{-- BASE CRM UPDATE --}}
			<x-core::tab-nav id="{{ $id }}-tabs_status_history" active>Status History</x-core::tab-nav>
			{{-- END BASE CRM UPDATE --}}

			<x-core::tab-nav id="{{ $id }}-tabs_attachment">Attachment</x-core::tab-nav>
			<x-core::tab-nav id="{{ $id }}-tabs_notes">Notes</x-core::tab-nav>
		</x-slot>

		<x-slot:content>
			{{-- BASE CRM UPDATE --}}
			<x-core::tab-content id="{{ $id }}-tabs_status_history" active class="p-0 border-0">
				@include('base-crm::pages.account.status-history.list', ['id' => $data->id])
			</x-core::tab-content>
			{{-- END BASE CRM UPDATE --}}

			<x-core::tab-content id="{{ $id }}-tabs_attachment" class="p-0 border-0">
				<x-core::attachment id="account-page-attachment" relation="accounts:{{ $data->id }}" />
			</x-core::tab-content>

			<x-core::tab-content id="{{ $id }}-tabs_notes" class="p-0 border-0">
				<x-core::notes
					id="account-page-notes:notes"
					model="Account"
					column="notes"
					:record_id="$data->id">{!! $data->notes !!}</x-core::notes>
			</x-core::tab-content>
		</x-slot>
	</x-core::tab>
</x-core::tab-content>
