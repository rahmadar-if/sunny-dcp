@php
    $id = "account-page-tabs_history";
@endphp

<x-core::tab-content id="{{ $id }}" :active="$active ?? false" class="p-0 border-0">
    <x-core::tab id="{{ $id }}-tabs" variant="tab-style-7" class="scaleX p-0 mb-4">
        <x-slot:nav>
            <x-core::tab-nav id="{{ $id }}-tabs_activity" active>Activity</x-core::tab-nav>
            <x-core::tab-nav id="{{ $id }}-tabs_account_lead">Lead</x-core::tab-nav>

            {{-- SALES UPDATE --}}
            <x-core::tab-nav id="{{ $id }}-tabs_account_opportunity">Opportunity</x-core::tab-nav>
            <x-core::tab-nav id="{{ $id }}-tabs_account_order">Order</x-core::tab-nav>
            <x-core::tab-nav id="{{ $id }}-tabs_account_invoice">Invoice</x-core::tab-nav>
            {{-- END SALES UPDATE --}}

            <x-core::tab-nav id="{{ $id }}-tabs_status_history">Status History</x-core::tab-nav>
        </x-slot>

        <x-slot:content>
            <x-core::tab-content id="{{ $id }}-tabs_activity" active class="p-0 border-0">
                @include("master-data::pages.account.activity.list", ["id" => $data->id])
            </x-core::tab-content>

            <x-core::tab-content id="{{ $id }}-tabs_account_lead" class="p-0 border-0">
                @include("base-crm::pages.account.lead.list", ["id" => $data->id])
            </x-core::tab-content>

            {{-- SALES UPDATE --}}
            <x-core::tab-content id="{{ $id }}-tabs_account_opportunity" class="p-0 border-0">
                @include("sales::pages.account.opportunity.list", ["id" => $data->id])
            </x-core::tab-content>

            <x-core::tab-content id="{{ $id }}-tabs_account_order" class="p-0 border-0">
                @include("sales::pages.account.order.list", ["id" => $data->id])
            </x-core::tab-content>

            <x-core::tab-content id="{{ $id }}-tabs_account_invoice" class="p-0 border-0">
                @include("sales::pages.account.invoice.list", ["id" => $data->id])
            </x-core::tab-content>
            {{-- END SALES UPDATE --}}

            <x-core::tab-content id="{{ $id }}-tabs_status_history" class="p-0 border-0">
                @include('base-crm::pages.account.status-history.list', ['id' => $data->id])
            </x-core::tab-content>
        </x-slot>
    </x-core::tab>
</x-core::tab-content>
