<div class="row mt-3">
    <div class="col-lg-3 col-md-6">

        {{-- Total Payment Amount Invoice with Status Completed --}}
        <x-core::metric
            id="total-revenue"
            variant="compact"
            title="Total Revenue"
            tooltip="Money already collected from fully paid invoices in this period."
            :value="$data['total_revenue']->value"
            numeral
            prefix="Rp "
            icon="ri-money-dollar-circle-line"
            color="success"
            :change-type="$data['total_revenue']->change->type"
            :change-title="$data['total_revenue']->change->title"
            :change-value="$data['total_revenue']->change->value"
            lazy />
    </div>

    <div class="col-lg-3 col-md-6">

        {{-- Total Payment Amount - Total Amount in Invoice --}}
        <x-core::metric
            id="outstanding-invoice"
            variant="compact"
            title="Outstanding Invoice"
            tooltip="Invoices that have been sent to customers but haven't been paid yet."
            :value="$data['outstanding_invoice']->value"
            numeral
            prefix="Rp "
            color="danger"
            icon="ri-file-warning-line"
            :change-type="$data['outstanding_invoice']->change->type"
            :change-title="$data['outstanding_invoice']->change->title"
            :change-value="$data['outstanding_invoice']->change->value"
            lazy />
    </div>

    <div class="col-lg-3 col-md-6">

        {{-- Total Amount in Order with Status Completed --}}
        <x-core::metric
            id="total-sales"
            variant="compact"
            title="Total Sales"
            tooltip="Total value of orders placed in this period, including ones still being confirmed."
            :value="$data['total_sales']->value"
            numeral
            prefix="Rp "
            icon="ri-wallet-2-line"
            color="info"
            :change-type="$data['total_sales']->change->type"
            :change-title="$data['total_sales']->change->title"
            :change-value="$data['total_sales']->change->value"
            lazy />
    </div>

    <div class="col-lg-3 col-md-6">

        {{-- SUM Opportunity total_amount, status Closed Won --}}
        <x-core::metric
            id="opportunity-closed-won"
            variant="compact"
            title="Opportunity Closed Won"
            tooltip="Total value of deals you've successfully won in this period."
            :value="$data['opportunity_closed_won']->value"
            numeral
            prefix="Rp "
            icon="ri-trophy-line"
            color="success"
            :change-type="$data['opportunity_closed_won']->change->type"
            :change-title="$data['opportunity_closed_won']->change->title"
            :change-value="$data['opportunity_closed_won']->change->value"
            lazy />
    </div>
</div>

<div class="row">
    <div class="col-xxl-3 col-lg-4">

        {{-- opportunity pipeline --}}
        <div class="row">
            <div class="col-lg-12 col-md-6">
                <x-core::card>
                    <x-slot:header class="d-flex justify-content-between">
                        <div class="card-title">Opportunity Pipeline</div>
                        <x-core::refresh-button id="opportunity-pipeline-refresh" size="sm" color="light" />
                    </x-slot:header>

                    <x-core::funnel-chart id="opportunity-pipeline" :data="$data['opportunity_pipeline']" />
                </x-core::card>
            </div>

            <div class="col-lg-12 col-md-6">
                <x-core::card>
                    <x-slot:header class="d-flex justify-content-between">
                        <div class="card-title">Activity</div>
                        <x-core::refresh-button id="activity-refresh" size="sm" color="light" />
                    </x-slot:header>

                    <x-core::tab id="activity-tab" variant="tab-style-7">
                        <x-slot:nav>
                            <x-core::tab-nav id="activity-tab-upcoming" active>Upcoming</x-core::tab-nav>
                            <x-core::tab-nav id="activity-tab-todo">To Do</x-core::tab-nav>
                            <x-core::tab-nav id="activity-tab-recent">Recent</x-core::tab-nav>
                        </x-slot:nav>

                        <x-slot:content>
                            {{-- activity upcoming --}}
                            <x-core::tab-content id="activity-tab-upcoming" active class="p-0 border-0">
                                <ul class="list-unstyled mt-3 mb-0 ecommerce-recent-activity" id="activity-upcoming">
                                    @foreach ($data['activity']['upcoming'] as $activity)
                                        <li class="ecommerce-recent-activity-content">
                                            <div class="d-flex align-items-top">
                                                <div class="me-3">
                                                    <span class="avatar avatar-sm bg-{{ $activity->color}} avatar-rounded">
                                                        <i class="{{ $activity->icon }}"></i>
                                                    </span>
                                                </div>
                                                <div class="activity-content">
                                                    <span class="d-block fw-medium">{{ $activity->subject }}</span>
                                                    <span class="d-block fs-12 text-muted">{{ $activity->category->name }} ({{ $activity->priority->name }})</span>
                                                </div>
                                                <div class="flex-fill text-end">
                                                    <span class="d-block text-muted fs-11 op-7">{{ $activity->recent }}</span>
                                                </div>
                                            </div>
                                        </li>
                                    @endforeach
                                </ul>
                            </x-core::tab-content>

                            {{-- activity to do --}}
                            <x-core::tab-content id="activity-tab-todo" class="p-0 border-0">
                                <ul class="list-unstyled mt-3 mb-0 ecommerce-recent-activity" id="activity-todo">
                                    @foreach ($data['activity']['todo'] as $activity)
                                        <li class="ecommerce-recent-activity-content">
                                            <div class="d-flex align-items-top">
                                                <div class="me-3">
                                                    <span class="avatar avatar-sm bg-{{ $activity->color}} avatar-rounded">
                                                        <i class="{{ $activity->icon }}"></i>
                                                    </span>
                                                </div>
                                                <div class="activity-content">
                                                    <span class="d-block fw-medium">{{ $activity->subject }}</span>
                                                    <span class="d-block fs-12 text-muted">{{ $activity->category->name }} ({{ $activity->priority->name }})</span>
                                                </div>
                                                <div class="flex-fill text-end">
                                                    <span class="d-block text-muted fs-11 op-7">{{ $activity->recent }}</span>
                                                </div>
                                            </div>
                                        </li>
                                    @endforeach
                                </ul>
                            </x-core::tab-content>

                            {{-- activity recent --}}
                            <x-core::tab-content id="activity-tab-recent" class="p-0 border-0">
                                <ul class="list-unstyled mt-3 mb-0 ecommerce-recent-activity" id="activity-recent">
                                    @foreach ($data['activity']['recent'] as $activity)
                                        <li class="ecommerce-recent-activity-content">
                                            <div class="d-flex align-items-top">
                                                <div class="me-3">
                                                    <span class="avatar avatar-sm bg-{{ $activity->color}} avatar-rounded">
                                                        <i class="{{ $activity->icon }}"></i>
                                                    </span>
                                                </div>
                                                <div class="activity-content">
                                                    <span class="d-block fw-medium">{{ $activity->subject }}</span>
                                                    <span class="d-block fs-12 text-muted">{{ $activity->category->name }} ({{ $activity->priority->name }})</span>
                                                </div>
                                                <div class="flex-fill text-end">
                                                    <span class="d-block text-muted fs-11 op-7">{{ $activity->recent }}</span>
                                                </div>
                                            </div>
                                        </li>
                                    @endforeach
                                </ul>
                            </x-core::tab-content>

                        </x-slot:content>
                    </x-core::tab>
                </x-core::card>
            </div>
        </div>

        {{-- activity --}}
        {{-- <div class="row">

        </div> --}}
    </div>

    <div class="col-xxl-9 col-lg-8">
        <div class="row">
            <div class="col-lg-4 col-md-6">

                {{-- Lead conversion: Total Lead Opportunity / Total Lead * 100 --}}
                <x-core::metric
                    id="lead-conversion"
                    variant="simple"
                    title="Lead Conversion"
                    tooltip="Share of leads that turned into real sales opportunities."
                    :value="$data['lead_conversion']->value"
                    :change-type="$data['lead_conversion']->change->type"
                    :change-title="$data['lead_conversion']->change->title"
                    :change-value="$data['lead_conversion']->change->value"
                    lazy />
            </div>
            <div class="col-lg-4 col-md-6">

                {{-- Win Rate: Total Opportunity Closed Won / Total Opportunity * 100 --}}
                <x-core::metric
                    id="win-rate"
                    variant="simple"
                    title="Win Rate"
                    tooltip="Share of opportunities that ended in a win."
                    :value="$data['win_rate']->value"
                    :change-type="$data['win_rate']->change->type"
                    :change-title="$data['win_rate']->change->title"
                    :change-value="$data['win_rate']->change->value"
                    lazy />
            </div>
            <div class="col-lg-4">

                {{-- SUM Opportunity amount * probility --}}
                <x-core::metric
                    id="pipeline-forecast"
                    variant="simple"
                    title="Pipeline Forecast"
                    tooltip="Expected revenue from deals still in progress, weighted by how likely each one is to close."
                    :value="$data['pipeline_forecast']->value"
                    numeral
                    prefix="Rp "
                    decimal="1"
                    :change-type="$data['pipeline_forecast']->change->type"
                    :change-title="$data['pipeline_forecast']->change->title"
                    :change-value="$data['pipeline_forecast']->change->value"
                    lazy />
            </div>
        </div>

        {{-- Sales Analytic --}}
        <div class="row">
            <div class="col-lg-12">
                <x-core::card style="min-height: 400px">
                    <x-slot:header class="d-flex justify-content-between">
                        <div class="card-title">Sales Analytics</div>
                        <x-core::refresh-button id="sales-analytic-refresh" size="sm" color="light" />
                    </x-slot:header>

                    <div id="sales-analytic"></div>
                </x-core::card>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-6">
                <x-core::card class="overflow-hidden" body:class="p-0">
                    <x-slot:header class="d-flex justify-content-between">
                        <div class="card-title">Top Performer</div>
                        <x-core::refresh-button id="top-sales-refresh" size="sm" color="light" />
                    </x-slot:header>

                    <ul class="list-group list-group-flush" id="top-sales">
                        @foreach ($data['top_sales'] as $sales)
                        <li class="list-group-item">
                            <div class="d-flex align-items-center gap-2">
                                <div class="lh-1">
                                    <span class="avatar avatar-md avatar-rounded {{ $sales->avatar ? "" : "bg-secondary" }}">
                                        @if ($sales->avatar)
                                        <img src="{{ route('core.images.thumbnail', ['id' => $sales->avatar]) }}" alt="">
                                        @else
                                        {{ SolarHelper::getInitialName($sales->user_name) }}
                                        @endif
                                    </span>
                                </div>
                                <div class="flex-fill">
                                    <span class="d-block fw-medium">{{ $sales->user_name }}</span>
                                    <span class="fs-12 text-muted">{{ $sales->user_email }}</span>
                                </div>
                                <div class="d-flex flex-column align-items-end gap-1">
                                    <div class="fw-medium">
                                        <x-core::numeral id="top-sales-{{ $sales->user_id }}-amount" size-class="" prefix="Rp " :value="$sales->total_opportunity_amount" />
                                    </div>
                                    <span class="fs-12 text-muted">{{ $sales->total_opportunity }} closed won</span>
                                </div>
                            </div>
                        </li>
                        @endforeach
                    </ul>
                </x-core::card>
            </div>

            <div class="col-lg-6">
                <x-core::card class="overflow-hidden" body:class="p-0">
                    <x-slot:header class="d-flex justify-content-between">
                        <div class="card-title">Top Customer</div>
                        <x-core::refresh-button id="top-customer-refresh" size="sm" color="light" />
                    </x-slot:header>

                    <ul class="list-group list-group-flush stocks-activity" id="top-customer">
                        @foreach ($data['top_customer'] as $customer)
                        <li class="list-group-item">
                            <div class="d-flex align-items-center gap-2">
                                <div class="lh-1">
                                    <span class="avatar avatar-md avatar-rounded {{ $customer->avatar ? "" : "bg-secondary" }}">
                                        @if ($customer->avatar)
                                        <img src="{{ route('core.images.thumbnail', ['id' => $customer->avatar]) }}" alt="">
                                        @else
                                        {{ SolarHelper::getInitialName($customer->account_name) }}
                                        @endif
                                    </span>
                                </div>
                                <div class="flex-fill">
                                    <span class="d-block fw-medium">{{ $customer->account_name }}</span>
                                    <span class="fs-12 text-muted">{{ $customer->primary_contact }}</span>
                                </div>
                                <div class="d-flex flex-column align-items-end">
                                    <div class="fw-medium">
                                        <x-core::numeral id="top-customer-{{ $customer->account_id }}-amount" size-class="" prefix="Rp " :value="$customer->total_invoice_amount" />
                                    </div>
                                    <span class="fs-12 text-muted">{{ $customer->total_invoice }} invoice</span>
                                </div>
                            </div>
                        </li>
                        @endforeach

                    </ul>
                </x-core::card>
            </div>
        </div>

    </div>
</div>

@push('scripts')
    <script>
        const SUMMARY_METRIC_CHART = {{ Js::from([
            'total_revenue'          => $data['total_revenue']->chart,
            'outstanding_invoice'    => $data['outstanding_invoice']->chart,
            'total_sales'            => $data['total_sales']->chart,
            'opportunity_closed_won' => $data['opportunity_closed_won']->chart
        ]) }}
        const SALES_ANALYTIC = {{ Js::from($data['sales_analytic']) }}
    </script>
@endpush
