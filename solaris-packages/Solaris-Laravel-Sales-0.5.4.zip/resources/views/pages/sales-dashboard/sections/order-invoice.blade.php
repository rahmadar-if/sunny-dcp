<div class="row mt-3">
    <div class="col-xxl-3">
        <div class="row">
            <div class="col-xxl-12 col-lg-4">
                <x-core::metric
                    id="total-revenue-2"
                    variant="detail"
                    title="Total Revenue"
                    tooltip="Money already collected from fully paid invoices in this period."
                    :value="$data['total_revenue']->value"
                    numeral
                    prefix="Rp "
                    icon="ri-money-dollar-circle-line"
                    color="success"
                    :change-type="$data['total_revenue']->change->type"
                    :change-title="$data['total_revenue']->change->title"
                    :change-value="$data['total_revenue']->change->value"
                    lazy />
            </div>

            <div class="col-xxl-12 col-lg-4">
                <x-core::metric
                    id="outstanding-invoice-2"
                    variant="detail"
                    title="Outstanding Invoice"
                    tooltip="Invoices that have been sent to customers but haven't been paid yet."
                    :value="$data['outstanding_invoice']->value"
                    numeral
                    prefix="Rp "
                    icon="ri-file-warning-line"
                    color="danger"
                    :change-type="$data['outstanding_invoice']->change->type"
                    :change-title="$data['outstanding_invoice']->change->title"
                    :change-value="$data['outstanding_invoice']->change->value"
                    lazy />
            </div>

            <div class="col-xxl-12 col-lg-4">
                <x-core::metric
                    id="avg-payment-time"
                    variant="detail"
                    title="Avg Payment Time"
                    tooltip="Average time it takes for a customer to pay an invoice in full."
                    :value="$data['avg_payment_time']->value"
                    icon="ri-time-line"
                    color="info"
                    :change-type="$data['avg_payment_time']->change->type"
                    :change-title="$data['avg_payment_time']->change->title"
                    :change-value="$data['avg_payment_time']->change->value"
                    lazy />
            </div>
        </div>
    </div>

    <div class="col-xxl-6">
        <x-core::card style="min-height: 400px">
            <x-slot:header class="d-flex justify-content-between">
                <div class="card-title">Revenue Analytics</div>
                <x-core::refresh-button id="revenue-analytic-refresh" size="sm" color="light" />
            </x-slot:header>

            <div id="revenue-analytic"></div>
        </x-core::card>
    </div>

    <div class="col-xxl-3">
        <div class="row">
            <div class="col-xxl-12 col-lg-4">
                <x-core::metric
                    id="total-sales-2"
                    variant="detail"
                    title="Total Sales"
                    tooltip="Total value of orders placed in this period, including ones still being confirmed."
                    :value="$data['total_sales']->value"
                    numeral
                    prefix="Rp "
                    icon="ri-wallet-2-line"
                    color="info"
                    :change-type="$data['total_sales']->change->type"
                    :change-title="$data['total_sales']->change->title"
                    :change-value="$data['total_sales']->change->value"
                    lazy />
            </div>

            <div class="col-xxl-12 col-lg-4">
                <x-core::metric
                    id="total-order"
                    variant="detail"
                    title="Total Order"
                    tooltip="Total number of orders placed in this period."
                    :value="$data['total_order']->value"
                    icon="ri-bill-line"
                    color="secondary"
                    :change-type="$data['total_order']->change->type"
                    :change-title="$data['total_order']->change->title"
                    :change-value="$data['total_order']->change->value"
                    lazy />
            </div>

            <div class="col-xxl-12 col-lg-4">
                <x-core::metric
                    id="total-invoice"
                    variant="detail"
                    title="Total Invoice"
                    tooltip="Total number of invoices issued in this period."
                    :value="$data['total_invoice']->value"
                    icon="ri-file-list-3-line"
                    color="success"
                    :change-type="$data['total_invoice']->change->type"
                    :change-title="$data['total_invoice']->change->title"
                    :change-value="$data['total_invoice']->change->value"
                    lazy />
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-xxl-4">
        <x-core::card class="overflow-hidden" body:class="p-0">
            <x-slot:header class="d-flex justify-content-between">
                <div class="card-title">Recent Order</div>
                <x-core::refresh-button id="recent-order-refresh" size="sm" color="light" />
            </x-slot:header>

            <ul class="list-group list-group-flush" id="recent-order">
                @foreach ($data['recent_order'] as $order)
                <li class="list-group-item">
                    <div class="d-flex align-items-center gap-2">
                        <div class="lh-1">
                            <span class="avatar avatar-md avatar-rounded {{ $order->account?->profile_picture_id ? "" : "bg-secondary" }}">
                                @if ($order->account?->profile_picture_id)
                                <img src="{{ route('core.images.thumbnail', ['id' => $order->account->profile_picture_id]) }}" alt="">
                                @else
                                {{ SolarHelper::getInitialName($order->account?->name ?? "") }}
                                @endif
                            </span>
                        </div>
                        <div class="flex-fill">
                            <div class="d-flex align-items-center gap-1">
                                <span class="d-block fw-medium">{{ $order->number }}</span>
                                <span class="badge bg-{{ $order->status->color }}">{{ $order->status->name }}</span>
                            </div>
                            <span class="fs-12 text-muted">{{ $order->account->name }}</span>
                        </div>
                        <div class="d-flex flex-column align-items-end gap-1">
                            <span class="d-block text-muted fs-11 op-7">{{ $order->recent }}</span>
                            <div class="fw-medium">
                                <x-core::numeral id="recent-order-{{ $order->id }}-amount" size-class="" prefix="Rp " :value="$order->amount" />
                            </div>
                        </div>
                    </div>
                </li>
                @endforeach
            </ul>
        </x-core::card>
    </div>

    <div class="col-xxl-4">
        <x-core::card class="overflow-hidden" body:class="p-0">
            <x-slot:header class="d-flex justify-content-between">
                <div class="card-title">Top Order</div>
                <x-core::refresh-button id="top-order-refresh" size="sm" color="light" />
            </x-slot:header>

            <ul class="list-group list-group-flush" id="top-order">
                @foreach ($data['top_order'] as $order)
                <li class="list-group-item">
                    <div class="d-flex align-items-center gap-2">
                        <div class="lh-1">
                            <span class="avatar avatar-md avatar-rounded {{ $order->account?->profile_picture_id ? "" : "bg-secondary" }}">
                                @if ($order->account?->profile_picture_id)
                                <img src="{{ route('core.images.thumbnail', ['id' => $order->account->profile_picture_id]) }}" alt="">
                                @else
                                {{ SolarHelper::getInitialName($order->account?->name ?? "") }}
                                @endif
                            </span>
                        </div>
                        <div class="flex-fill">
                            <div class="d-flex align-items-center gap-1">
                                <span class="d-block fw-medium">{{ $order->number }}</span>
                                <span class="badge bg-{{ $order->status->color }}">{{ $order->status->name }}</span>
                            </div>
                            <span class="fs-12 text-muted">{{ $order->account->name }}</span>
                        </div>
                        <div class="fw-medium">
                            <x-core::numeral id="top-order-{{ $order->id }}-amount" size-class="" prefix="Rp " :value="$order->amount" />
                        </div>
                    </div>
                </li>
                @endforeach
            </ul>
        </x-core::card>
    </div>

    <div class="col-xxl-4">
        <x-core::card class="overflow-hidden" body:class="p-0">
            <x-slot:header class="d-flex justify-content-between">
                <div class="card-title">Top Product Ordered</div>
                <x-core::refresh-button id="top-product-order-refresh" size="sm" color="light" />
            </x-slot:header>

            <ul class="list-group list-group-flush" id="top-product-order">
                @foreach ($data['top_product_ordered'] as $product)
                <li class="list-group-item">
                    <div class="d-flex align-items-center gap-2">
                        <div class="lh-1">
                            <span class="avatar avatar-md avatar-rounded {{ $product->avatar ? "" : "bg-secondary" }}">
                                @if ($product->avatar)
                                <img src="{{ route('core.images.thumbnail', ['id' => $product->avatar]) }}" alt="">
                                @else
                                {{ SolarHelper::getInitialName($product->product_name ?? "") }}
                                @endif
                            </span>
                        </div>
                        <div class="flex-fill">
                            <span class="d-block fw-medium">{{ $product->product_name }}</span>
                            <span class="fs-12 text-muted">{{ $product->order_count }} ordered</span>
                        </div>
                        <div class="d-flex flex-column align-items-end gap-1">
                            <div class="fw-medium">
                                <x-core::numeral id="top-product-{{ $product->product_id }}-amount" size-class="" prefix="Rp " :value="$product->total_amount" />
                            </div>
                            <span class="d-block text-muted fs-11 op-7">{{ $product->total_qty }} qty</span>
                        </div>
                    </div>
                </li>
                @endforeach
            </ul>
        </x-core::card>
    </div>
</div>

@push('scripts')
    <script>
        const ORDER_INV_METRIC_CHART = {{ Js::from([
            'total_revenue'       => $data['total_revenue']->chart,
            'outstanding_invoice' => $data['outstanding_invoice']->chart,
            'avg_payment_time'    => $data['avg_payment_time']->chart,
            'total_sales'         => $data['total_sales']->chart,
            'total_order'         => $data['total_order']->chart,
            'total_invoice'       => $data['total_invoice']->chart
        ]) }}
        const REVENUE_ANALYTIC = {{ Js::from($data['revenue_analytic']) }}
    </script>
@endpush
