<div class="row mt-3">
    <div class="col-xxl-9 col-xl-8 col-lg-7">
        <div class="row">

            {{-- Total Lead --}}
            <div class="col-xxl-3 col-lg-4 col-md-6">
                <x-core::metric
                    id="total-lead"
                    variant="summary"
                    title="Total Lead"
                    tooltip="Total number of leads captured in this period."
                    :value="$data['total_lead']->value"
                    color="primary"
                    icon="ri-group-fill"
                    :change-type="$data['total_lead']->change->type"
                    :change-title="$data['total_lead']->change->title"
                    :change-value="$data['total_lead']->change->value"
                    lazy />
            </div>

            {{-- Qualified Lead --}}
            <div class="col-xxl-3 col-lg-4 col-md-6">
                <x-core::metric
                    id="qualified-lead"
                    variant="summary"
                    title="Qualified Lead"
                    tooltip="Leads that have progressed into a sales opportunity."
                    :value="$data['qualified_lead']->value"
                    color="success"
                    icon="ri-group-fill"
                    :change-type="$data['qualified_lead']->change->type"
                    :change-title="$data['qualified_lead']->change->title"
                    :change-value="$data['qualified_lead']->change->value"
                    lazy />
            </div>

            {{-- Lead Conversion --}}
            <div class="col-xxl-3 col-lg-4 col-md-6">
                <x-core::metric
                    id="lead-conversion-2"
                    variant="summary"
                    title="Lead Conversion"
                    tooltip="Share of leads that turned into real sales opportunities."
                    :value="$data['lead_conversion']->value"
                    color="info"
                    icon="ri-exchange-2-line"
                    :change-type="$data['lead_conversion']->change->type"
                    :change-title="$data['lead_conversion']->change->title"
                    :change-value="$data['lead_conversion']->change->value"
                    lazy />
            </div>

            {{-- Total Opportunity --}}
            <div class="col-xxl-3 col-lg-4 col-md-6">
                <x-core::metric
                    id="total-opportunity"
                    variant="summary"
                    title="Total Opportunity"
                    tooltip="Total number of sales opportunities open in this period."
                    :value="$data['total_opportunity']->value"
                    color="secondary"
                    icon="ri-shake-hands-line"
                    :change-type="$data['total_opportunity']->change->type"
                    :change-title="$data['total_opportunity']->change->title"
                    :change-value="$data['total_opportunity']->change->value"
                    lazy />
            </div>

            {{-- Opportunity Amount --}}
            <div class="col-xxl-3 col-lg-4 col-md-6">
                <x-core::metric
                    id="opportunity-amount-2"
                    variant="compact"
                    title="Opportunity Amount"
                    tooltip="Total value of opportunities in this period, not including lost deals."
                    :value="$data['opportunity_amount']->value"
                    numeral
                    prefix="Rp "
                    color="primary"
                    icon="ri-wallet-2-line"
                    :change-type="$data['opportunity_amount']->change->type"
                    :change-title="$data['opportunity_amount']->change->title"
                    :change-value="$data['opportunity_amount']->change->value"
                    lazy />
            </div>

            {{-- Pipeline Forecast --}}
            <div class="col-xxl-3 col-lg-4 col-md-6">
                <x-core::metric
                    id="pipeline-forecast-2"
                    variant="compact"
                    title="Pipeline Forecast"
                    tooltip="Expected revenue from deals still in progress, weighted by how likely each one is to close."
                    :value="$data['pipeline_forecast']->value"
                    numeral
                    prefix="Rp "
                    decimal="1"
                    color="secondary"
                    icon="ri-line-chart-line"
                    :change-type="$data['pipeline_forecast']->change->type"
                    :change-title="$data['pipeline_forecast']->change->title"
                    :change-value="$data['pipeline_forecast']->change->value"
                    lazy />
            </div>

            {{-- Win Rate --}}
            <div class="col-xxl-3 col-lg-6 col-md-6">
                <x-core::metric
                    id="win-rate-2"
                    variant="compact"
                    title="Win Rate"
                    tooltip="Share of opportunities that ended in a win."
                    :value="$data['win_rate']->value"
                    color="success"
                    icon="ri-trophy-line"
                    :change-type="$data['win_rate']->change->type"
                    :change-title="$data['win_rate']->change->title"
                    :change-value="$data['win_rate']->change->value"
                    lazy />
            </div>

            {{-- Average Sales Cycle --}}
            <div class="col-xxl-3 col-lg-6 col-md-6">
                <x-core::metric
                    id="avg-sales-cycle"
                    variant="compact"
                    title="Avg Sales Cycle"
                    tooltip="Average time it takes to turn an opportunity into a closed deal."
                    :value="$data['avg_sales_cycle']->value"
                    color="info"
                    icon="ri-timer-flash-line"
                    :change-type="$data['avg_sales_cycle']->change->type"
                    :change-title="$data['avg_sales_cycle']->change->title"
                    :change-value="$data['avg_sales_cycle']->change->value"
                    lazy />
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <x-core::card class="overflow-hidden" body:style="min-height: 300px">
                    <x-slot:header class="d-flex justify-content-between">
                        <div class="card-title">Prospects by Source</div>
                        <x-core::refresh-button id="prospect-source-refresh" size="sm" color="light" />
                    </x-slot:header>

                    <div id="prospect-source"></div>

                    <x-slot:footer>
                        <div class="row gy-4" id="prospect-source-detail">
                            @foreach ($data['prospect_by_source']['detail'] as $item)
                            <div class="col-6">
                                <div class="d-flex align-items-center gap-3 flex-wrap">
                                    <div class="lh-1">
                                        <span class="avatar avatar-rounded avatar-md bg-{{ $item->color }}-transparent">
                                            <i class="{{ $item->icon }} fs-20"></i>
                                        </span>
                                    </div>
                                    <div>
                                        <span class="d-block fs-12 text-muted fw-medium">{{ $item->name }}</span>
                                        <div class="d-flex align-items-center gap-2">
                                            <h6 class="fw-medium mb-0">{{ $item->total }}</h6>
                                            <span class="text-{{ $item->changeColor }} fs-12 fw-medium">
                                                @if ($item->changeIcon)
                                                <i class="{{ $item->changeIcon }}"></i>
                                                @endif
                                                {{ $item->change }}
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </x-slot:footer>
                </x-core::card>
            </div>

            <div class="col-md-6">

                <x-core::card class="overflow-hidden" body:class="p-0">
                    <x-slot:header class="d-flex justify-content-between">
                        <div class="card-title">Opportunity Overview</div>
                        <x-core::refresh-button id="opportunity-overview-refresh" size="sm" color="light" />
                    </x-slot:header>

                    <div class="px-4 py-3 border-bottom">
                        <div class="d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center gap-2">
                                <h5 class="mb-0" id="opportunity-overview-total">{{ $data['opportunity_overview']['total'] }}</h5>
                                <span class="d-block fs-12 text-muted">Opportunity</span>
                            </div>
                            <div class="d-flex align-items-center gap-2">
                                <h5 class="mb-0" id="opportunity-overview-total-amount">
                                    <x-core::numeral id="opportunity-overview-total-amount-value" ignore size-class="" prefix="Rp " :value="$data['opportunity_overview']['total_amount']" />
                                </h5>
                            </div>
                        </div>
                        <div class="progress-stacked progress-animate bg-transparent progress-sm mt-2 mb-1" id="opportunity-overview-percent">
                            @foreach ($data['opportunity_overview']['detail'] as $item)
                            <div class="progress-bar progress-bar-striped bg-{{ $item->color }}" role="progressbar"
                                style="width: {{ $item->percent }}%" aria-valuenow="{{ $item->percent }}" aria-valuemin="0" aria-valuemax="100">
                            </div>
                            @endforeach
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table text-nowrap">
                            <tbody id="opportunity-overview-detail">
                                @foreach ($data['opportunity_overview']['detail'] as $item)
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="lh-1">
                                                <span
                                        class="avatar avatar-md border border-{{ $item->color }} border-{{ $item->color }} border-opacity-25 avatar-rounded">
                                        <span
                                            class="avatar avatar-sm bg-{{ $item->color }}-transparent avatar-rounded">
                                            <i class="{{ $item->icon }} fs-20"></i>
                                        </span>
                                    </span>
                                            </div>
                                            <div>
                                                <span class="fw-medium d-block">{{ $item->name }}</span>
                                                <span class="d-block text-muted fs-12">{{ $item->total }} Opportunity</span> </div>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="text-{{ $item->changeColor }} badge bg-{{ $item->changeColor }}-transparent fw-medium">
                                            @if ($item->changeIcon)
                                            <i class="{{ $item->changeIcon }}"></i>
                                            @endif
                                            {{ $item->change }}
                                        </span>
                                    </td>
                                    <td class="text-end">
                                        <div>
                                            <span class="d-block fw-medium mb-0">
                                                <x-core::numeral id="opportunity-overview-{{ $item->id }}-amount" size-class="" prefix="Rp " :value="$item->total_amount" />
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </x-core::card>
            </div>
        </div>
    </div>

    <div class="col-xxl-3 col-xl-4 col-lg-5">
        <div class="row">
            <div class="col-lg-12 col-md-6">
                <x-core::card>
                    <x-slot:header class="d-flex justify-content-between">
                        <div class="card-title">Opportunity Pipeline</div>
                        <x-core::refresh-button id="opportunity-pipeline-refresh-2" size="sm" color="light" />
                    </x-slot:header>

                    <x-core::funnel-chart id="opportunity-pipeline-2" :data="$data['opportunity_pipeline']" />
                </x-core::card>
            </div>
            <div class="col-lg-12 col-md-6">
                <x-core::card class="overflow-hidden" body:class="p-0">
                    <x-slot:header class="d-flex justify-content-between">
                        <div class="card-title">Top Opportunity</div>
                        <x-core::refresh-button id="top-opportunity-refresh" size="sm" color="light" />
                    </x-slot:header>

                    <ul class="list-group list-group-flush" id="top-opportunity">
                        @foreach ($data['top_opportunity'] as $opportunity)
                        <li class="list-group-item">
                            <div class="d-flex align-items-center gap-2">
                                <div class="lh-1">
                                    <span class="avatar avatar-md avatar-rounded {{ $opportunity->customer?->profile_picture_id ? "" : "bg-secondary" }}">
                                        @if ($opportunity->customer?->profile_picture_id)
                                        <img src="{{ route('core.images.thumbnail', ['id' => $opportunity->customer->profile_picture_id]) }}" alt="">
                                        @else
                                        {{ SolarHelper::getInitialName($opportunity->customer?->name ?? "") }}
                                        @endif
                                    </span>
                                </div>
                                <div class="flex-fill">
                                    <span class="d-block fw-medium">{{ $opportunity->name }}</span>
                                    <span class="fs-12 text-muted">{{ $opportunity->customer?->name }}</span>
                                </div>
                                <div class="d-flex flex-column align-items-end gap-1">
                                    <div class="fw-medium">
                                        <x-core::numeral id="top-opportunity-{{ $opportunity->id }}-amount" size-class="" prefix="Rp " :value="$opportunity->total_amount" />
                                    </div>
                                    <span class="badge bg-{{ $opportunity->status->color }}">{{ $opportunity->status->name }}</span>
                                </div>
                            </div>
                        </li>
                        @endforeach
                    </ul>
                </x-core::card>
            </div>
        </div>
    </div>
</div>

@push('scripts')
    <script>
        const LEAD_OPP_METRIC_CHART = {{ Js::from([
            'total_lead'         => $data['total_lead']->chart,
            'qualified_lead'     => $data['qualified_lead']->chart,
            'lead_conversion'    => $data['lead_conversion']->chart,
            'total_opportunity'  => $data['total_opportunity']->chart,
            'opportunity_amount' => $data['opportunity_amount']->chart,
            'pipeline_forecast'  => $data['pipeline_forecast']->chart,
            'win_rate'           => $data['win_rate']->chart,
            'avg_sales_cycle'    => $data['avg_sales_cycle']->chart,
        ]) }}
        const PROSPECT_BY_SOURCE = {{ Js::from($data['prospect_by_source']) }}
    </script>
@endpush
