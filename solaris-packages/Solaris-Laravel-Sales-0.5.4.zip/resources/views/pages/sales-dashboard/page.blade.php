<x-core::page.base 
    title="Sales Dashboard"
    :breadcrumbs="$breadcrumbs"
    package="sales" 
    path="sales-dashboard/index">

    <x-slot:buttons>
        <x-core::period-filter id="period-filter" />
        <x-core::refresh-button id="refresh" />
    </x-slot:buttons>

    <x-core::tab id="dashboard-tab" style="background-color: transparent;">
        <x-slot:nav>
            <x-core::tab-nav id="dashboard-tab-summary" active>Summary</x-core::tab-nav>
            <x-core::tab-nav id="dashboard-tab-lead-opportunity">Lead - Opportunity</x-core::tab-nav>
            <x-core::tab-nav id="dashboard-tab-order-invoice">Order - Invoice</x-core::tab-nav>
        </x-slot:nav>

        <x-slot:content>
            <x-core::tab-content id="dashboard-tab-summary" active class="p-0 border-0">
                @include('sales::pages.sales-dashboard.sections.summary', ['data' => $data['summary']])
            </x-core::tab-content>

            <x-core::tab-content id="dashboard-tab-lead-opportunity" class="p-0 border-0">
                @include('sales::pages.sales-dashboard.sections.lead-opportunity', ['data' => $data['lead_opportunity']])
            </x-core::tab-content>

            <x-core::tab-content id="dashboard-tab-order-invoice" class="p-0 border-0">
                @include('sales::pages.sales-dashboard.sections.order-invoice', ['data' => $data['order_invoice']])
            </x-core::tab-content>
        </x-slot:content>
    </x-core::tab>

</x-core::page.base>