<x-core::modal-form
    id="invoice-modal"
    title="Invoice"
    model="Invoice"
    size="md">

    <x-core::field label="Subject" id="invoice-page-subject:subject" required>
        <x-core::input
            placeholder="Invoice subject or reference"/>
    </x-core::field>

    <x-core::field id="invoice-modal-order_id:order_id" label="Order" required lazy>
        <x-core::lookup
            pagination
            placeholder="Link to an existing order"
            extend_search="created_by[name,email,username],account.name,contact.name"
            extend_columns="created_by,date,account,contact,status,amount"
            source="Order@invoiceable"
            link_url="/sales/order/{id}" />
    </x-core::field>

    <x-core::field id="invoice-modal-account_id:account_id" label="Account" disabled>
        <x-core::lookup
            pagination
            placeholder="Choose the customer account"
            source="Account"
            link_url="/master-data/account/{id}" />
    </x-core::field>

</x-core::modal-form>
