<x-core::page.edit
    :id="$data->id"
    title="Invoice"
    :breadcrumbs="$breadcrumbs"
    model="Invoice"
    package="sales"
    path="invoice/page-index"
    profile-position="left">

    <x-slot:header>
        <div class="row mb-3">
            <div class="col">
                <x-core::stage-buttons 
                    id="invoice-page-status_id:status_id" 
                    :stages="SolarHelper::model('invoice_status')::toStage(confirm: true)" 
                    :value="$data->status_id" />
            </div>
        </div>
    </x-slot>

    <x-slot:profile>
        @include('sales::pages.invoice.sections.profile', ["data" => $data])
    </x-slot>

    @php
        $tabId = "invoice-page-tabs";
    @endphp

    <x-core::tab id="{{ $tabId }}" class="p-0 mb-4">
        <x-slot:nav>
            <x-core::tab-nav id="{{ $tabId }}_product" active>Product</x-core::tab-nav>
            <x-core::tab-nav id="{{ $tabId }}_history">History</x-core::tab-nav>
            <x-core::tab-nav id="{{ $tabId }}_attachment">Attachment</x-core::tab-nav>
            <x-core::tab-nav id="{{ $tabId }}_notes">Notes</x-core::tab-nav>
        </x-slot>

        <x-slot:content>
            <x-core::tab-content id="{{ $tabId }}_product" active class="p-0 border-0">
                @include("sales::pages.invoice.invoice-detail.list", ["id" => $data->id])
            </x-core::tab-content>

            <x-core::tab-content id="{{ $tabId }}_history" class="p-0 border-0">

                <x-core::tab id="{{ $tabId }}_history_tab" class="p-0 mb-4" variant="tab-style-7">
                    <x-slot:nav>
                        <x-core::tab-nav id="{{ $tabId }}_history_tab_activity" active>Activity</x-core::tab-nav>
                        <x-core::tab-nav id="{{ $tabId }}_history_tab_status">Status history</x-core::tab-nav>
                    </x-slot>

                    <x-slot:content>

                        <x-core::tab-content id="{{ $tabId }}_history_tab_activity" active class="p-0 border-0">
                            @include("sales::pages.invoice.activity.list", ["id" => $data->id])
                        </x-core::tab-content>

                        <x-core::tab-content id="{{ $tabId }}_history_tab_status" class="p-0 border-0">
                            @include('sales::pages.invoice.status-history.list', ['id' => $data->id])
                        </x-core::tab-content>

                    </x-slot>
                </x-core::tab>

            </x-core::tab-content>

            <x-core::tab-content id="{{ $tabId }}_attachment" class="p-0 border-0">
                <x-core::attachment id="invoice-page-attachment" relation="'invoice':{{ $data->id }}"/>
            </x-core::tab-content>

            <x-core::tab-content id="{{ $tabId }}_notes" class="p-0 border-0">
                <x-core::notes 
                    id="invoice-page-notes:notes"
                    model="Invoice"
                    column="notes"
                    :record_id="$data->id">{!! $data->notes !!}</x-core::notes>
            </x-core::tab-content>
        </x-slot>
    </x-core::tab>

</x-core::page.edit>