<x-core::page.list
    id="invoice"
    title="Invoice"
    class="table-hover"
    :breadcrumbs="$breadcrumbs"
    model="Invoice"
    package="sales"
    path="invoice/list-index"
    new="@invoice-modal"
    import export folder lazy>

    <x-slot:table-column>
        <x-core::table-action-column :view="false"/>

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="number" 
            searchable 
            orderable>
            Number
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="subject" 
            searchable 
            orderable>
            Subject
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="account.name" 
            lookup="profile_picture" 
            searchable 
            orderable>
            Account
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="contact.name" 
            lookup="profile_picture" 
            searchable 
            orderable>
            Contact
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="due_date" 
            searchable 
            orderable>
            Due Date
        </x-core::table-column>

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="status.name" 
            searchable 
            orderable>
            Status
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="amount" 
            searchable 
            orderable>
            Total
        </x-core::table-column>
    </x-slot>

    @push('modal-content')
        @include("sales::pages.invoice.modal")
    @endpush

</x-core::page.list>