<div class="card custom-card">
    <div class="card-body">
        <x-core::field label="Number" id="invoice-page-number:number" disabled>
            <x-core::input
                placeholder="Type a unique invoice reference"
                :value="$data->number"/>
        </x-core::field>

        <x-core::field label="Order" id="invoice-page-order_id:order_id" disabled>
            <x-core::lookup
                pagination
                source="Order"
                placeholder="Link to an existing order"
                :value="json_encode($data->order)"
                link_url="/sales/order/{id}" />
        </x-core::field>

        <x-core::field label="Account" id="invoice-page-account_id:account_id" required>
            <x-core::lookup
                pagination
                source="Account"
                placeholder="Choose the customer account"
                :value="json_encode($data->account)"
                link_url="/master-data/account/{id}" />
        </x-core::field>

        <x-core::field label="Contact" id="invoice-page-contact_id:contact_id" lazy>
            <x-core::lookup
                pagination
                source="Contact"
                placeholder="Choose the contact person"
                :value="json_encode($data->contact)"
                link_url="/master-data/contact/{id}" />
        </x-core::field>

        <x-core::field label="Issued date" id="invoice-page-issued_date:issued_date" disabled>
            <x-core::date-picker
                placeholder="Choose when this invoice was issued"
                :value="$data->date"/>
        </x-core::field>

        <x-core::field label="Due date" id="invoice-page-due_date:due_date" required>
            <x-core::date-picker
                placeholder="Choose when payment is due"
                :value="$data->due_date"/>
        </x-core::field>

        <x-core::field label="Due date" id="invoice-page-completed_at:completed_at" disabled>
            <x-core::date-picker
                placeholder="Choose when payment is completed"
                :value="$data->due_date"/>
        </x-core::field>

        <x-core::field label="Amount" id="invoice-page-amount:amount" disabled>
            <x-core::input
                number decimal
                prefix="Rp"
                placeholder="Enter total invoice amount"
                :value="$data->amount"/>
        </x-core::field>
    </div>
</div>
