<x-core::modal-form
    id="invoice-detail-modal"
    title="Product"
    model="InvoiceDetail">

    <div class="row">
        <div class="col-lg-6">
            <x-core::field id="invoice-detail-modal-product_id:product_id" label="Product" required lazy>
                <x-core::lookup
                    pagination
                    placeholder="Choose product to add to order"
                    extend_columns="price"
                    source="Product@availableInInvoiceDetail({{ $id }})"
                    link_url="/master-data/product/{id}" />
            </x-core::field>

            <x-core::field label="Price" id="invoice-detail-modal-price:price" required>
                <x-core::input
                    number decimal
                    prefix="Rp "
                    placeholder="Price per item"/>
            </x-core::field>

            <x-core::field label="Quantity" id="invoice-detail-modal-qty:qty" required>
                <x-core::input
                    number
                    placeholder="Enter quantity"/>
            </x-core::field>
        </div>
        <div class="col-lg-6">
            <x-core::field label="Amount" id="invoice-detail-modal-amount:amount" disabled>
                <x-core::input
                    number decimal
                    prefix="Rp "
                    placeholder="Will be calculated automatically"/>
            </x-core::field>

            <x-core::field label="Discount" id="invoice-detail-modal-discount:discount">
                <x-core::input
                    number decimal
                    prefix="Rp "
                    placeholder="Enter discount amount"/>
            </x-core::field>

            <x-core::field label="Total" id="invoice-detail-modal-total:total" disabled>
                <x-core::input
                    number decimal
                    prefix="Rp "
                    placeholder="Will be calculated automatically"/>
            </x-core::field>
        </div>
    </div>

</x-core::modal-form>
