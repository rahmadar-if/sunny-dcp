<x-core::page.edit
	:id="$data->id"
	title="Activity"
	:breadcrumbs="$breadcrumbs"
	model="Activity"
	package="sales"
	path="activity/page-index"
	profile-position="left">

	<x-slot:profile>
		@include('master-data::pages.activity.sections.profile-container', ["data" => $data])

		<x-core::card>
			<x-core::field id="activity-page-lead_id:lead_id" label="Lead" lazy>
				<x-core::lookup
					extend_columns="date,account.primary_contact,contact.account,status"
					placeholder="Choose lead"
					source="Lead"
					:value="json_encode($data->lead)"
					link_url="/sales/lead/{id}"
				/>
			</x-core::field>

			{{-- SALES UPDATE --}}
			<x-core::field id="activity-page-opportunity_id:opportunity_id" label="Opportunity" lazy>
				<x-core::lookup
					placeholder="Choose opportunity"
					extend_columns="date,customer.primary_contact,decision_maker.account,status,lead"
					source="Opportunity"
					:value="json_encode($data->opportunity)"
					link_url="/sales/opportunity/{id}"
				/>
			</x-core::field>

			<x-core::field label="Order" id="activity-page-order_id:order_id" lazy>
				<x-core::lookup
					placeholder="Choose order"
					source="Order"
					:value="json_encode($data->order)"
					link_url="/sales/order/{id}"
				/>
			</x-core::field>

			<x-core::field label="Invoice" id="activity-page-invoice_id:invoice_id" lazy>
				<x-core::lookup
					placeholder="Choose invoice"
					source="Invoice"
					:value="json_encode($data->invoice)"
					link_url="/sales/invoice/{id}"
				/>
			</x-core::field>
			{{-- END SALES UPDATE --}}
		</x-core::card>

		@include('master-data::pages.activity.sections.reminder', ["data" => $data])
	</x-slot>

	@php $tabId = "activity-page-tabs"; @endphp

	{{-- SALES UPDATE --}}
	<x-core::tab id="{{ $tabId }}" class="p-0 mb-4">
		<x-slot:nav>
			<x-core::tab-nav id="{{ $tabId }}_info" active>Info</x-core::tab-nav>
			<x-core::tab-nav id="{{ $tabId }}_notes_files">Notes & Files</x-core::tab-nav>
		</x-slot>

		<x-slot:content>
			@include('base-crm::pages.activity.sections.info', ['data' => $data, 'active' => true])
			@include('master-data::pages.activity.sections.notes-files', ['data' => $data, 'active' => false])
		</x-slot>
	</x-core::tab>
	{{-- END SALES UPDATE --}}

</x-core::page.edit>
