<x-core::page.list
    id="lead"
    title="Lead"
    class="table-hover"
    :breadcrumbs="$breadcrumbs"
    model="Lead"
    package="sales"
    path="lead/list-index"
    new="@lead-modal"
    import export folder lazy delete_all
    extend_columns="created_by,phone,email,date,status,follow_up_date,account_name,contact_name,contact_job_title,account[profile_picture_id],contact[profile_picture_id],budget_range,disqualification_reason,disqualification_reason_text">

    <x-slot:header>
        <div class="row row-cols-1 row-cols-sm-2 row-cols-xl-5 g-3">
            <div class="col">
                <x-core::metric
                    id="lead_total_metric"
                    variant="simple"
                    title="Total Lead"
                    tooltip="Number of leads matching the current filter and search."
                    :decimal="0"
                    numeral
                    lazy />
            </div>

            <div class="col">
                <x-core::metric
                    id="lead_cold_metric"
                    variant="simple"
                    title="Cold"
                    tooltip="Leads still in New status — not yet worked on."
                    :decimal="0"
                    numeral
                    lazy />
            </div>

            <div class="col">
                <x-core::metric
                    id="lead_warm_metric"
                    variant="simple"
                    title="Warm"
                    tooltip="Leads being nurtured, plus qualified leads that have not been converted into an opportunity."
                    :decimal="0"
                    numeral
                    lazy />
            </div>

            <div class="col">
                <x-core::metric
                    id="lead_hot_metric"
                    variant="simple"
                    title="Hot"
                    tooltip="Qualified leads that already have an opportunity."
                    :decimal="0"
                    numeral
                    lazy />
            </div>

            <div class="col">
                <x-core::metric
                    id="lead_budget_metric"
                    variant="simple"
                    title="Total Budget"
                    tooltip="Total budget of all leads except Disqualified, matching the current filter and search."
                    prefix="Rp"
                    numeral
                    lazy />
            </div>
        </div>
    </x-slot:header>

    <x-slot:table-pre-right-action>
        <x-core::lookup
            id="lead_owner_filter"
            placeholder="Choose sales"
            size="sm"
            source="user"
            wrapper_style="width: 250px"
            :copy="false"
            disabled
            ignore />
            
        <x-core::lookup
            id="lead_status_filter"
            placeholder="Choose status"
            size="sm"
            multiple
            :options="SolarHelper::model('lead_status')::toSelect()"
            wrapper_style="width: 350px"
            :copy="false"
            disabled
            ignore />
    </x-slot:table-pre-right-action>

    <x-slot:table-column>
        <x-core::table-action-column :view="false"/>

        <x-core::table-column
            cell_class="text-nowrap"
            data="date"
            searchable
            orderable>
            Name / Date
        </x-core::table-column>

        <x-core::table-column
            data="customer_need"
            searchable
            orderable
            expand>
            Customer Need
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="status.name">
            Status / Follow Up
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="budget_range.name">
            Budget
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="account.name">
            Account / Contact
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="phone"
            searchable
            orderable>
            Phone / Email
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="opportunity.name"
            lookup="date,status,total_amount"
            searchable>
            Opportunity
        </x-core::table-column>
    </x-slot>

    @push('modal-content')
        @include("base-crm::pages.lead.modal")
        @include("master-data::pages.activity.modal")
    @endpush

</x-core::page.list>
