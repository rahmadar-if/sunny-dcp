@php
    use Solaris\BaseCRM\Const\LeadStatusConst;
    $canConvert = in_array($data->status_id, [LeadStatusConst::Nurturing, LeadStatusConst::Qualified]) && is_null($data->opportunity?->id);
@endphp

<x-core::page.edit
    :id="$data->id"
    title="Lead"
    :breadcrumbs="$breadcrumbs"
    model="Lead"
    package="sales"
    path="lead/page-index"
    profile-position="left">

    <x-slot:preButtons>
        <x-core::button 
            id="hot_lead" 
            color="danger" 
            variant="outline" 
            title="Send to Opportunity"
            :disabled="!$canConvert">
            <i class="ri-fire-fill me-1"></i>Hot Lead
        </x-core::button>
    </x-slot>

    <x-slot:header>
        <div class="row mb-3">
            <div class="col">
                <x-core::stage-buttons
                    id="lead-page-status_id:status_id"
                    :stages="SolarHelper::model('lead_status')::toStage(confirm: true, next: [
                        LeadStatusConst::New => [LeadStatusConst::Nurturing, LeadStatusConst::Disqualified],
                        LeadStatusConst::Nurturing => [LeadStatusConst::New, LeadStatusConst::Qualified, LeadStatusConst::Disqualified]
                    ])"
                    :value="$data->status_id" />
            </div>
        </div>
    </x-slot>

    <x-slot:profile>
        @include('sales::pages.lead.sections.profile-contact', ["data" => $data])
        @include('base-crm::pages.lead.sections.profile-followup', ["data" => $data])
    </x-slot>

    @php
        $tabId = "lead-page-tabs";
    @endphp

    <x-core::tab id="{{ $tabId }}" class="p-0 mb-4">
        <x-slot:nav>
            <x-core::tab-nav id="{{ $tabId }}_lead_info" active>Lead info</x-core::tab-nav>
            <x-core::tab-nav id="{{ $tabId }}_account_profile">Market Profile</x-core::tab-nav>
            <x-core::tab-nav id="{{ $tabId }}_history">History</x-core::tab-nav>
            <x-core::tab-nav id="{{ $tabId }}_attachment">Attachment</x-core::tab-nav>
            <x-core::tab-nav id="{{ $tabId }}_notes">Notes</x-core::tab-nav>
        </x-slot>

        <x-slot:content>
            @include('base-crm::pages.lead.sections.lead-info', ["data" => $data, "active" => true])
            @include('base-crm::pages.lead.sections.account-profile', ["data" => $data])
            @include('base-crm::pages.lead.sections.history', ["data" => $data])

            <x-core::tab-content id="{{ $tabId }}_attachment" class="p-0 border-0">
                <x-core::attachment id="lead-page-attachment" relation="leads:{{ $data->id }}"/>
            </x-core::tab-content>

            <x-core::tab-content id="{{ $tabId }}_notes" class="p-0 border-0">
                <x-core::notes
                    id="lead-page-notes:notes"
                    model="Lead"
                    column="notes"
                    :record_id="$data->id">{!! $data->notes !!}</x-notes>
            </x-core::tab-content>

        </x-slot>
    </x-core::tab>

    @push('modal-content')
        @include("base-crm::pages.lead.disqualification-modal")
    @endpush

</x-core::page.edit>
