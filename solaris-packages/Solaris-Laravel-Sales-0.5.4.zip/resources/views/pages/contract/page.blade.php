<x-core::page.edit
    :id="$data->id"
    title="Contract"
    :breadcrumbs="$breadcrumbs"
    model="Contract"
    package="sales"
    path="contract/page-index">

    <div class="row">
        <div class="col-lg-4 col-md-6">
            <x-core::field label="Number" id="contract-page-number:number" required>
                <x-core::input
                    placeholder="Type a unique contract reference"
                    :value="$data->number"/>
            </x-core::field>

            <x-core::field label="Start date" id="contract-page-start_date:start_date" required>
                <x-core::date-picker
                    placeholder="Choose when this contract was registered"
                    :value="$data->start_date"/>
            </x-core::field>

            <x-core::field label="End date" id="contract-page-end_date:end_date" required>
                <x-core::date-picker
                    placeholder="Select end date"
                    :value="$data->end_date"/>
            </x-core::field>
        </div>

        <div class="col-lg-4 col-md-6">
            <x-core::field label="Subject" id="contract-page-subject:subject" required>
                <x-core::input
                    placeholder="Contract subject or reference"
                    :value="$data->subject"/>
            </x-core::field>

            <x-core::field label="Account" id="contract-page-account_id:account_id" required>
                <x-core::lookup
                    pagination
                    source="Account"
                    placeholder="Choose the customer account"
                    :value="json_encode($data->account)"
                    link_url="/master-data/account/{id}" />
            </x-core::field>

            <x-core::field label="Contact" id="contract-page-contact_id:contact_id" lazy>
                <x-core::lookup
                    pagination
                    source="Contact"
                    placeholder="Choose the contact person"
                    :value="json_encode($data->contact)"
                    link_url="/master-data/contact/{id}" />
            </x-core::field>
        </div>

        <div class="col-lg-4 col-md-6 d-flex align-items-end">
            <x-core::field label="Amount" id="contract-page-amount:amount" field:class="w-100" required>
                <x-core::input
                    number decimal
                    prefix="Rp"
                    placeholder="Enter total contract amount"
                    :value="$data->amount"/>
            </x-core::field>
        </div>
    </div>

    <x-slot:footer>
        <x-core::document-editor id="contract-page-notes:notes">{!! $data->notes !!}</x-document-editor>
    </x-slot:footer>

</x-core::page.edit>
