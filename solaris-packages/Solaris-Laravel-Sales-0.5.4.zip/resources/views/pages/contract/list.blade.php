<x-core::page.list
    id="contract"
    title="Contract"
    class="table-hover"
    :breadcrumbs="$breadcrumbs"
    model="Contract"
    package="sales"
    path="contract/list-index"
    new="@contract-modal"
    import export folder lazy>

    <x-slot:table-column>
        <x-core::table-action-column :view="false"/>

        <x-core::table-column 
            cell_class="text-nowrap" 
            data="number" 
            searchable 
            orderable>
            Number
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="subject" 
            searchable 
            orderable>
            Subject
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="account.name" 
            lookup="profile_picture" 
            searchable 
            orderable>
            Account
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="contact.name" 
            lookup="profile_picture" 
            searchable 
            orderable>
            Contact
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="start_date" 
            searchable 
            orderable>
            Start date
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="end_date" 
            searchable 
            orderable>
            End date
        </x-core::table-column>
        
        <x-core::table-column 
            cell_class="text-nowrap" 
            data="amount" 
            searchable 
            orderable>
            Total
        </x-core::table-column>
    </x-slot>

    @push('modal-content')
        @include('sales::pages.contract.modal')
    @endpush

</x-core::page.list>