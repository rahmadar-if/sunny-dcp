<x-core::modal-form
    id="contract-modal"
    title="Contract"
    model="Contract">

    <div class="row">
        <div class="col-6">
            <x-core::field id="contract-modal-number:number" label="Number" required>
                <x-core::input placeholder="Type a unique contract reference"/>
            </x-core::field>

            <x-core::field label="Start date" id="contract-page-start_date:start_date" required>
                <x-core::date-picker
                    placeholder="Choose when this contract was registered"/>
            </x-core::field>

            <x-core::field label="End date" id="contract-page-end_date:end_date">
                <x-core::date-picker
                    placeholder="Select end date"/>
            </x-core::field>
        </div>

        <div class="col-6">
            <x-core::field id="contract-modal-subject:subject" label="Subject" required>
                <x-core::input placeholder="Contract subject or reference"/>
            </x-core::field>

            <x-core::field id="contract-modal-account_id:account_id" label="Account" required>
                <x-core::lookup
                    pagination
                    placeholder="Choose the customer account"
                    extend_columns="primary_contact"
                    source="Account"
                    link_url="/master-data/account/{id}" />
            </x-core::field>

            <x-core::field id="contract-modal-contact_id:contact_id" label="Contact" lazy>
                <x-core::lookup
                    pagination
                    placeholder="Choose a contact person"
                    source="Contact"
                    link_url="/master-data/contact/{id}" />
            </x-core::field>
        </div>
    </div>
</x-core::modal-form>
