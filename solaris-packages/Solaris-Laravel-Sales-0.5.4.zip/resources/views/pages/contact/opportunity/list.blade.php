<x-core::table
    id="contact-opportunity_list"
    class="table-hover"
    model="Opportunity"
    :new="false"
    export lazy delete_all
    extend_columns="date"
    :card_wrapper="false"
    filter="decision_maker_id = {{ $id }}">

    <x-slot:column>
        <x-core::table-column
            cell_class="text-nowrap"
            data="name"
            searchable
            orderable>
            Name
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="status.name"
            searchable
            orderable>
            Status
        </x-core::table-column>

        <x-core::table-column
            cell_class="text-nowrap"
            data="total_amount"
            searchable
            orderable
            type="number"
            format="currency">
            Total Amount
        </x-core::table-column>

        <x-core::table-column
            data="customer_need"
            searchable
            orderable
            expand>
            Customer Need
        </x-core::table-column>
    </x-slot>

</x-core::table>
