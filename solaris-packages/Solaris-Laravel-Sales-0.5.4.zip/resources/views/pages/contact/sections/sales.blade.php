@php
	$id = "contact-page-tabs_sales";
@endphp

<x-core::tab-content :id="$id" :active="$active ?? false" class="p-0 border-0">
	<x-core::tab id="{{ $id }}-tabs" variant="tab-style-7" class="scaleX p-0 mb-4">
		<x-slot:nav>
			{{-- BASE CRM UPDATE --}}
			<x-core::tab-nav id="{{ $id }}-tabs_lead" active>Lead</x-core::tab-nav>
			{{-- END BASE CRM UPDATE --}}

			{{-- SALES UPDATE --}}
			<x-core::tab-nav id="{{ $id }}-tabs_opportunity">Opportunity</x-core::tab-nav>
			<x-core::tab-nav id="{{ $id }}-tabs_order">Order</x-core::tab-nav>
			<x-core::tab-nav id="{{ $id }}-tabs_invoice">Invoice</x-core::tab-nav>
			{{-- END SALES UPDATE --}}
		</x-slot>

		<x-slot:content>
			{{-- BASE CRM UPDATE --}}
			<x-core::tab-content id="{{ $id }}-tabs_lead" active class="p-0 border-0">
				@include('base-crm::pages.contact.lead.list', ['id' => $data->id])
			</x-core::tab-content>
			{{-- END BASE CRM UPDATE --}}

			{{-- SALES UPDATE --}}
			<x-core::tab-content id="{{ $id }}-tabs_opportunity" class="p-0 border-0">
				@include('sales::pages.contact.opportunity.list', ['id' => $data->id])
			</x-core::tab-content>

			<x-core::tab-content id="{{ $id }}-tabs_order" class="p-0 border-0">
				@include('sales::pages.contact.order.list', ['id' => $data->id])
			</x-core::tab-content>

			<x-core::tab-content id="{{ $id }}-tabs_invoice" class="p-0 border-0">
				@include('sales::pages.contact.invoice.list', ['id' => $data->id])
			</x-core::tab-content>
			{{-- END SALES UPDATE --}}
		</x-slot>
	</x-core::tab>
</x-core::tab-content>
