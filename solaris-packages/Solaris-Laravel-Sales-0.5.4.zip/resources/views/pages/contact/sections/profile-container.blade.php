<div class="card custom-card overflow-hidden border">
    <div class="card-body pb-3">

        <div class="text-center mb-4">
            <x-core::profile-picture
                id="profile_picture"
                :source="$data->profile_picture_id"
                :preview_width="$data->profile_picture?->image_width"
                :preview_height="$data->profile_picture?->image_height"
                :upload_to="route('master-data.contact.update.avatar', ['id' => $data->id])"
                size="lg"/>

            <h5 class="fw-medium mb-1 mt-2" id="name_display">{{ $data->name }}</h5>
            <span class="d-block fw-medium text-muted mb-2" id="job_title_display">{{ $data->job_title }}</span>
        </div>

        @php
            $wa_phone = null;
            if ($data->primary_phone) {
                $digits = preg_replace('/\D/', '', $data->primary_phone);
                if (str_starts_with($digits, '00')) {
                    $digits = substr($digits, 2);
                } elseif (str_starts_with($digits, '0')) {
                    $digits = '62' . substr($digits, 1);
                }
                $wa_phone = $digits;
            }
            $wa_mobile = null;
            if ($data->primary_mobile_phone) {
                $digits = preg_replace('/\D/', '', $data->primary_mobile_phone);
                if (str_starts_with($digits, '00')) {
                    $digits = substr($digits, 2);
                } elseif (str_starts_with($digits, '0')) {
                    $digits = '62' . substr($digits, 1);
                }
                $wa_mobile = $digits;
            }
        @endphp
        <div class="mb-4 text-center">
            <p class="fs-12 mb-0 text-muted">
                <span class="d-block mb-1">
                    <i class="ti ti-mail me-1 align-middle"></i>
                    <a id="email_display"
                       @if($data->email) href="mailto:{{ $data->email }}" @endif
                       class="text-muted {{ $data->email ? 'text-decoration-underline' : '' }}">{{ $data->email ?? '-' }}</a>
                </span>
                <span class="d-block mb-1">
                    <i class="ti ti-phone me-1 align-middle"></i>
                    <a id="primary_phone_display"
                       @if($wa_phone) href="https://wa.me/{{ $wa_phone }}" target="_blank" rel="noopener noreferrer" @endif
                       class="text-muted {{ $wa_phone ? 'text-decoration-underline' : '' }}">{{ $data->primary_phone ?? '-' }}</a>
                </span>
                <span class="d-block">
                    <i class="ti ti-device-mobile me-1 align-middle"></i>
                    <a id="primary_mobile_phone_display"
                       @if($wa_mobile) href="https://wa.me/{{ $wa_mobile }}" target="_blank" rel="noopener noreferrer" @endif
                       class="text-muted {{ $wa_mobile ? 'text-decoration-underline' : '' }}">{{ $data->primary_mobile_phone ?? '-' }}</a>
                </span>
            </p>
        </div>

        <div id="account_section" class="{{ $data->account ? '' : 'd-none' }}">
            <p class="fs-11 fw-semibold text-uppercase text-muted mb-2">Account</p>
            <a id="account_link" href="{{ $data->account ? '/master-data/account/' . $data->account->id : '#' }}" class="d-flex align-items-center gap-2 text-decoration-none mb-2">
                <div class="flex-shrink-0">
                    @if($data->account?->profile_picture_id)
                        <img id="account_avatar"
                            src="{{ route('core.images.thumbnail', ['id' => $data->account->profile_picture_id]) }}"
                            class="avatar avatar-sm rounded-circle object-fit-cover"
                            alt="{{ $data->account?->name }}">
                        <div id="account_initial" class="avatar avatar-sm rounded-circle bg-primary d-flex align-items-center justify-content-center d-none">
                            <span class="fs-13 fw-semibold text-white">{{ strtoupper(substr($data->account?->name ?? '-', 0, 1)) }}</span>
                        </div>
                    @else
                        <img id="account_avatar" src="" class="avatar avatar-sm rounded-circle object-fit-cover d-none" alt="">
                        <div id="account_initial" class="avatar avatar-sm rounded-circle bg-primary d-flex align-items-center justify-content-center">
                            <span class="fs-13 fw-semibold text-white">{{ strtoupper(substr($data->account?->name ?? '-', 0, 1)) }}</span>
                        </div>
                    @endif
                </div>
                <div class="overflow-hidden flex-grow-1">
                    <p id="company_name" class="mb-0 fw-medium fs-13 text-dark text-truncate">{{ $data->account?->name ?? '-' }}</p>
                </div>
            </a>
            <div class="d-flex gap-1 flex-wrap">
                <span id="account_type_badge" class="badge bg-primary fs-11 {{ $data->account?->type ? '' : 'd-none' }}">{{ $data->account?->type?->name }}</span>
                <span id="account_industry_badge" class="badge bg-primary fs-11 {{ $data->account?->industry ? '' : 'd-none' }}">{{ $data->account?->industry?->name }}</span>
            </div>
        </div>

    </div>

    <div class="d-flex mb-0 border-top border-block-start-dashed">
        <div class="text-center flex-fill py-3 px-2 border-end border-dashed">
            <p id="total_activity_display" class="fw-semibold fs-18 mb-0 text-primary">{{ $data->total_activity }}</p>
            <p class="fs-11 text-muted mb-0">Activity</p>
        </div>
        <div class="text-center flex-fill py-3 px-2 border-end border-dashed">
            <p id="total_address_display" class="fw-semibold fs-18 mb-0 text-secondary">{{ $data->total_address }}</p>
            <p class="fs-11 text-muted mb-0">Address</p>
        </div>
        <div class="text-center flex-fill py-3 px-2">
            <p id="total_communication_display" class="fw-semibold fs-18 mb-0 text-warning">{{ $data->total_communication }}</p>
            <p class="fs-11 text-muted mb-0">Communication</p>
        </div>
    </div>

    {{-- SALES UPDATE --}}
    <div class="border-top border-block-start-dashed px-3 py-3">
        <p class="fs-11 fw-semibold text-uppercase text-muted mb-3">Sales Summary</p>

        <div class="d-flex justify-content-between align-items-center mb-3">
            <div class="d-flex align-items-center gap-2">
                <span class="avatar avatar-sm bg-success-transparent rounded">
                    <i class="ri-money-dollar-circle-line fs-14 text-success"></i>
                </span>
                <span class="fs-12 text-muted">Total Revenue</span>
            </div>
            <x-core::numeral id="sales_total_revenue_display" :value="$data->sales_total_revenue" prefix="Rp" class="fw-semibold" />
        </div>

        <div class="d-flex justify-content-between align-items-center mb-3">
            <div class="d-flex align-items-center gap-2">
                <span class="avatar avatar-sm bg-info-transparent rounded">
                    <i class="ri-wallet-2-line fs-14 text-info"></i>
                </span>
                <span class="fs-12 text-muted">Total Sales</span>
            </div>
            <x-core::numeral id="sales_total_sales_display" :value="$data->sales_total_sales" prefix="Rp" class="fw-semibold" />
        </div>

        <div class="d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center gap-2">
                <span class="avatar avatar-sm bg-danger-transparent rounded">
                    <i class="ri-line-chart-line fs-14 text-danger"></i>
                </span>
                <span class="fs-12 text-muted">Outstanding</span>
            </div>
            <x-core::numeral id="sales_outstanding_invoice_display" :value="$data->sales_outstanding_invoice" prefix="Rp" class="fw-semibold" />
        </div>
    </div>

    <div id="latest_lead_section" class="border-top border-block-start-dashed px-3 py-3 {{ $data->latest_lead ? '' : 'd-none' }}">
        <p class="fs-11 fw-semibold text-uppercase text-muted mb-2">Latest Lead</p>
        <a id="latest_lead_link"
            href="{{ $data->latest_lead ? route('crm.lead.edit', ['id' => $data->latest_lead->id]) : '#' }}"
            class="text-decoration-none">
            <div class="d-flex align-items-center justify-content-between gap-2">
                <span id="latest_lead_name" class="fs-13 fw-medium text-dark text-truncate">{{ $data->latest_lead?->name }}</span>
                <span id="latest_lead_status" class="badge bg-info-transparent text-info fs-11 flex-shrink-0">{{ $data->latest_lead?->status?->name }}</span>
            </div>
            <p id="latest_lead_date" class="fs-11 text-muted mb-0 mt-1">{{ $data->latest_lead?->date->format('d M Y') }}</p>
        </a>
    </div>

    <div id="latest_opportunity_section" class="border-top border-block-start-dashed px-3 py-3 {{ $data->latest_opportunity ? '' : 'd-none' }}">
        <p class="fs-11 fw-semibold text-uppercase text-muted mb-2">Latest Opportunity</p>
        <a id="latest_opportunity_link"
            href="{{ $data->latest_opportunity ? route('sales.opportunity.edit', ['id' => $data->latest_opportunity->id]) : '#' }}"
            class="text-decoration-none">
            <div class="d-flex align-items-center justify-content-between gap-2">
                <span id="latest_opportunity_name" class="fs-13 fw-medium text-dark text-truncate">{{ $data->latest_opportunity?->name }}</span>
                <span id="latest_opportunity_status" class="badge bg-warning-transparent text-warning fs-11 flex-shrink-0">{{ $data->latest_opportunity?->status?->name }}</span>
            </div>
        </a>
        <div class="d-flex align-items-center justify-content-between mt-1">
            <p id="latest_opportunity_date" class="fs-11 text-muted mb-0">{{ $data->latest_opportunity?->date->format('d M Y') }}</p>
            <x-core::numeral id="latest_opportunity_amount" size-class="fs-11" class="fw-semibold text-success mb-0" prefix="Rp" :value="$data->latest_opportunity?->total_amount" />
        </div>
    </div>
    {{-- END SALES UPDATE --}}

</div>
