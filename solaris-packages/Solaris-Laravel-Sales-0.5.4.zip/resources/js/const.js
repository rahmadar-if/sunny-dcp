const OpportunityStatus = {
    Qualification: "994d1a68-3027-4df3-bcf1-9e27341127a5",
    Proposal     : "b832eb7b-cc2c-4737-8551-f5f23158fede",
    Negotiation  : "80f4e99f-7adc-4213-b487-f28d0848f5dd",
    ClosedWon    : "847cc858-86f1-4874-9fdd-baff94561531",
    ClosedLost   : "4c9acd2e-1be9-40c1-9ac8-b618a62148f9",
}

const OrderStatus = {
    Draft       : "95e8938c-caee-4828-b283-1043a96983a5",
    Confirmation: "f293dcad-5517-4405-8ca3-49bd575f83b8",
    Completed   : "2168e416-a678-43db-bb65-e0f02c2b3ead",
    Cancel      : "0e62a1fa-e9dd-4c26-b0ba-5765911bc558",
}

const InvoiceStatus = {
    Draft       : "9f146cd7-033d-48d1-acdc-bc71b5f1a5eb",
    Confirmation: "1338739f-0f90-40eb-86a6-5a2d146e2328",
    Completed   : "81c1308c-8492-4cba-86cc-f99061b2fdb3",
    Cancel      : "7658bef0-3f7d-44f6-a0d3-52649d54c609",
}

export { 
    OpportunityStatus,
    OrderStatus,
    InvoiceStatus
}