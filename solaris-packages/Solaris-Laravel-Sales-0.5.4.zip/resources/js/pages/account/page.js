import BaseAccountPage from "@base-crm-js/pages/account/page";
import AccountOpportunityDetail from "./opportunity-detail";
import AccountOrderDetail from "./order-detail";
import AccountInvoiceDetail from "./invoice-detail";
import Numeral from "@core-js/solaris/numeral";

export default class AccountPage extends BaseAccountPage {
    init() {
        super.init()
        this.registerDetail("account-opportunity", AccountOpportunityDetail, "customer_id")
        this.registerDetail("account-order", AccountOrderDetail, "customer_id")
        this.registerDetail("account-invoice", AccountInvoiceDetail, "customer_id")
    }

    initProfileContainer() {
        super.initProfileContainer()
        
        /** @type { Numeral } */
        this.salesTotalRevenueDisplay = this.get('sales_total_revenue_display')
        
        /** @type { Numeral } */
        this.salesTotalSalesDisplay = this.get('sales_total_sales_display')
        
        /** @type { Numeral } */
        this.salesOutstandingInvoiceDisplay = this.get('sales_outstanding_invoice_display')

        this.latestLeadSection              = document.getElementById('latest_lead_section')
        this.latestLeadLink                 = document.getElementById('latest_lead_link')
        this.latestLeadName                 = document.getElementById('latest_lead_name')
        this.latestLeadStatus               = document.getElementById('latest_lead_status')
        this.latestLeadDate                 = document.getElementById('latest_lead_date')
        this.latestOpportunitySection       = document.getElementById('latest_opportunity_section')
        this.latestOpportunityLink          = document.getElementById('latest_opportunity_link')
        this.latestOpportunityName          = document.getElementById('latest_opportunity_name')
        this.latestOpportunityStatus        = document.getElementById('latest_opportunity_status')
        this.latestOpportunityDate          = document.getElementById('latest_opportunity_date')
        
        /** @type { Numeral } */
        this.latestOpportunityAmount = this.get('latest_opportunity_amount')
    }

    loadProfileContainer(data) {
        super.loadProfileContainer(data)

        this.salesTotalRevenueDisplay?.set(data.sales_total_revenue)
        this.salesTotalSalesDisplay?.set(data.sales_total_sales)
        this.salesOutstandingInvoiceDisplay?.set(data.sales_outstanding_invoice)

        this.updateLatestLead(data.latest_lead)
        this.updateLatestOpportunity(data.latest_opportunity)
    }

    /**
     * @param {Object|null} lead
     */
    updateLatestLead(lead) {
        if(this.latestLeadSection) {
            this.latestLeadSection.classList.toggle('d-none', !lead)
        }

        if(!lead) {
            return
        }

        if(this.latestLeadLink) {
            this.latestLeadLink.href = `${BASE_URL}/crm/lead/${lead.id}`
        }
        if(this.latestLeadName) {
            this.latestLeadName.textContent = lead.name ?? ''
        }

        if(this.latestLeadStatus) {
            this.latestLeadStatus.textContent = lead.status?.name ?? ''
        }

        if(this.latestLeadDate) {
            this.latestLeadDate.textContent = lead.date ?? ''
        }
    }

    /**
     * @param {Object|null} opportunity
     */
    updateLatestOpportunity(opportunity) {
        if(this.latestOpportunitySection) {
            this.latestOpportunitySection.classList.toggle('d-none', !opportunity)
        }

        if(!opportunity) {
            return
        }

        if(this.latestOpportunityLink) {
            this.latestOpportunityLink.href = `${BASE_URL}/sales/opportunity/${opportunity.id}`
        }

        if(this.latestOpportunityName) {
            this.latestOpportunityName.textContent = opportunity.name ?? ''
        }

        if(this.latestOpportunityStatus) {
            this.latestOpportunityStatus.textContent = opportunity.status?.name ?? ''
        } 
        
        if(this.latestOpportunityDate) {
            this.latestOpportunityDate.textContent = opportunity.date ?? ''
        }
        
        this.latestOpportunityAmount?.set(opportunity.total_amount)
    }
}
