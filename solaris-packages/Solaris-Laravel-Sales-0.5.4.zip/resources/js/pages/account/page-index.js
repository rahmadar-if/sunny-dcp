import AccountPage from "./page"

new AccountPage()
