import Filter from "@core-js/solaris/filter/filter";
import SolarListPage from "@core-js/solaris/solar/solar-list-page";
import { OpportunityStatus } from "@sales-js/const";

export default class OrderListPage extends SolarListPage {
    
    init() {
        this.initModal()

        this.columnRender("account_id", this.accountColumnRender.bind(this))
        this.columnRender("contact_id", this.contactColumnRender.bind(this))
        this.columnRender("status_id", this.statusColumnRender.bind(this))
        this.columnRender("amount", this.amountColumnRender.bind(this))
    }

    initModal() {
        if(!this.hasModalForm()) {
            return
        }

        const opportunity = this.form.get("opportunity_id")
        opportunity.init({
            param: (param) => {
                const filter = new Filter()
                filter.and("status_id", OpportunityStatus.ClosedWon)

                param.filter = filter.get()
                return param
            },
            optionsTemplate: (state) => {
                if(!state.id) {
                    return state.name
                }

                const option = `<div class="d-flex flex-column gap-1">
                    <div class="d-flex justify-content-between">
                        <div class="d-flex gap-1 align-items-center">
                            <span class="fs-12 fw-semibold">${state.name}</span>
                            <span class="fs-10 badge bg-${state.status.color}">${state.status.name}</span>
                        </div>
                        <span class="fs-11">${state.date}</span>
                    </div>
                    ${state.customer ? `<span class="fs-11"><i class="ri-building-2-line me-1"></i>${state.customer.name}</span>` : ''}
                    ${state.decision_maker ? `<span class="fs-11"><i class="ri-user-3-line me-1"></i>${state.decision_maker.name}</span>` : ''}
                    ${state.total_amount != null ? `
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="fs-11"><i class="ri-edit-line"></i>${state.created_by.name}</span>
                            <span class="fs-12 fw-semibold">Rp ${this.helper.numberToCurrency(state.total_amount)}</span>
                        </div>` : ''}
                </div>`

                return option
            }
        })
    }

    openEditPage(id) {
        this.helper.loadingPage(true)
        window.location = `${BASE_URL}/sales/order/edit/${id}`
    }

    async edit(row, data) {
        this.openEditPage(data.id)
    }

    rowDoubleClick(row, data) {
        this.openEditPage(data.id)
    }

    accountColumnRender(data, rowData) {
        if(!data) {
            return data
        }

        const initialName = this.helper.getInitialName(data)
        return `<div class="d-flex align-items-center gap-2">
            <div class="lh-1">
                <span class="avatar avatar-rounded avatar-sm ${!rowData.account.profile_picture_id ? "bg-secondary" : ""}">
                    ${rowData.account.profile_picture_id ? `<img src="${BASE_URL}/core/images/thumbnail/${rowData.account.profile_picture_id}" alt="">` : initialName}
                </span>
            </div>
            <div>
                <a class="text-decoration-underline" href="${BASE_URL}/master-data/account/${rowData.account_id}">${data}</a>
            </div>
        </div>`
    }

    contactColumnRender(data, rowData) {
        if(!data) {
            return data
        }

        const initialName = this.helper.getInitialName(data)
        return `<div class="d-flex align-items-center gap-2">
            <div class="lh-1">
                <span class="avatar avatar-rounded avatar-sm ${!rowData.contact.profile_picture_id ? "bg-secondary" : ""}">
                    ${rowData.contact.profile_picture_id ? `<img src="${BASE_URL}/core/images/thumbnail/${rowData.contact.profile_picture_id}" alt="">` : initialName}
                </span>
            </div>
            <div>
                <a class="text-decoration-underline" href="${BASE_URL}/master-data/contact/${rowData.contact_id}">${data}</a>
            </div>
        </div>`
    }

    statusColumnRender(data, rowData) {
        return `<span class="badge bg-${rowData.status.color}">${data}</span>`
    }

    amountColumnRender(data, rowData) {
        return `Rp ${this.helper.numberToCurrency(data ?? 0)}`
    }
}