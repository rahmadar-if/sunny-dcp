import OrderListPage from "./list"

new OrderListPage("order")