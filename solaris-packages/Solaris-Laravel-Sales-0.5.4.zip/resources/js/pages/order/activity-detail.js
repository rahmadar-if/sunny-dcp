import ActivityDetail from "@master-data-js/pages/activity/detail";

export default class OrderActivityDetail extends ActivityDetail {
    init() {
        super.init()
    }
}