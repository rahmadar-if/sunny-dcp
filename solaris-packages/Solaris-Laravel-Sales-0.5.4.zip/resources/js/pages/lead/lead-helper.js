import Helper from "@core-js/solaris/helper"
import axios from "@core-js/libs/axios"

export default class LeadHelper {

	// #region Static

	/**
	 * @param {*} account - account_id string or account object (truthy = has account)
	 * @param {*} contact - contact_id string or contact object (truthy = has contact)
	 * @returns {boolean}
	 */
	static validateQualified(account, contact) {
		if (account || contact) {
			return true
		}

		Helper.toast({
			title:   "Validation Error",
			message: "Lead must have at least an Account or Contact before this action.",
			color:   "danger"
		})
		return false
	}

	/**
	 * @param {string} id
	 * @param {*} account - account_id string or account object
	 * @param {*} contact - contact_id string or contact object
	 * @param {Function} [onSuccess]
	 * @returns {Promise<void>}
	 */
	static async prospect(id, account, contact, onSuccess) {
		if (!LeadHelper.validateQualified(account, contact)) {
			return
		}

		if (!await Helper.confirm({ title: "Are you sure?", message: "This Lead will be sent to Opportunity." })) {
			return
		}

		Helper.loadingPage(true)
		try {
			const req = await axios({
				method: "POST",
				url   : `${BASE_URL}/sales/lead/prospect/${id}`
			})
			const res = req.data
			if (!res.success) {
				throw res.message
			}

			Helper.successAlert({ title: "Sent to Opportunity successfully" })
			onSuccess?.()
		} catch (error) {
			console.error({ error })
			if (!error?.response) {
				Helper.errorAlert({ title: "Oops! There was an error", message: error })
			}
		} finally {
			Helper.loadingPage(false)
		}
	}

	// #endregion
}
