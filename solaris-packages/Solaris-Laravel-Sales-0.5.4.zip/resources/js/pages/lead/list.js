import BaseListPage from "@base-crm-js/pages/lead/list";
import { LeadStatus } from "@base-crm-js/const";
import Filter from "@core-js/solaris/filter/filter";
import LookupInput from "@core-js/solaris/form/lookup-input";
import axios from "@core-js/libs/axios";
import LeadHelper from "./lead-helper";

export default class LeadListPage extends BaseListPage {

	init() {
		super.init()

		this.initMetric()
		this.initQuickFilter()

		this.columnRender("opportunity_id", this.opportunityColumnRender.bind(this))
	}

	initMetric() {
		this.metrics = {
			total_lead:   this.get("lead_total_metric"),
			total_cold:   this.get("lead_cold_metric"),
			total_warm:   this.get("lead_warm_metric"),
			total_hot:    this.get("lead_hot_metric"),
			total_budget: this.get("lead_budget_metric"),
		}

		Object.values(this.metrics).forEach(metric => metric?.load())
	}

	initQuickFilter() {
		/** @type { LookupInput } */
		this.statusFilter = new LookupInput("div[solar-id='lead_status_filter']")

		/** @type { LookupInput } */
		this.ownerFilter = new LookupInput("div[solar-id='lead_owner_filter']")
	}

	/**
	 * Metric values follow the table filter, so they are refreshed on every draw.
	 * @returns {Promise<void>}
	 */
	async refreshMetric() {
		try {
			const req = await axios({
				method: "POST",
				url: `${BASE_URL}/sales/lead/list-summary`,
				data: this.table.getParamData()
			})

			Object.entries(this.metrics).forEach(([key, metric]) => {
				if (!metric) {
					return
				}

				metric.setValue(req.data[key] ?? 0)
				metric.unload()
			})
		} catch (error) {
			console.error("Failed to fetch lead list summary.", { error })
		}
	}

	async draw(e, settings) {
		await this.refreshMetric()
	}

	async ready(settings, json) {
		this.statusFilter?.enabled()
		this.ownerFilter?.enabled()

		this.statusFilter?.on("change", (val) => {
			this.table.filter("status", val ? new Filter().andIn("status_id", val.map(i => i.id)) : null)
		})

		this.ownerFilter?.on("change", (val) => {
			this.table.filter("created_by", val ? new Filter().and("created_by_id", val.id) : null)
		})

		await this.refreshMetric()
	}

	opportunityColumnRender(data, rowData) {
		if (!rowData.opportunity) {
			return data
		}

		return `<div class="d-flex flex-column gap-1">
            <div class="d-flex align-items-center gap-2">
                <a class="text-decoration-underline" href="${BASE_URL}/sales/opportunity/${rowData.opportunity.id}">${data}</a>
                <span class="badge bg-${rowData.opportunity.status.color} fs-10">${rowData.opportunity.status.name}</span>
            </div>
            <span class="text-muted fs-12"><i class="ri-calendar-line me-2"></i>${rowData.opportunity.date}</span>
            <span class="text-muted fs-12">Rp ${this.helper.readableNumber(rowData.opportunity.total_amount)}</span>
        </div>`
	}

	onActionCreated(row, cell, rowData) {
		super.onActionCreated(row, cell, rowData)

		this.actionBefore(row, "delete-action", {
			selector: "hot-action",
			label:    "Hot Lead",
			icon:     "ri-fire-fill",
			color:    "danger",
			callback: async () => await LeadHelper.prospect(
				rowData.id,
				rowData.account,
				rowData.contact,
				() => this.refresh()
			)
		})

		const allowedStatuses = [LeadStatus.Nurturing, LeadStatus.Qualified]
		const canConvert      = allowedStatuses.includes(rowData.status_id) && !rowData.opportunity && (rowData.account || rowData.contact)
		if (!canConvert) {
			cell.querySelector(".hot-action")?.classList.add("disabled")
		}
	}
}
