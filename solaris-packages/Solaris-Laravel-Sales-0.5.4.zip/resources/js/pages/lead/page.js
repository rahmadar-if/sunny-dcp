import BaseLeadPage from "@base-crm-js/pages/lead/page";
import { LeadStatus } from "@base-crm-js/const";
import LeadHelper from "./lead-helper";
import StageButtons from "@core-js/solaris/stage/stage-button";

export default class LeadPage extends BaseLeadPage {

	initForm() {
		super.initForm()

		/** @type { StageButtons } */
		const status = this.form.get("status_id")
		status?.on("click", async (data) => {
			if (data.id != LeadStatus.Qualified) {
				return
			}

			const accountId = this.form.getValue("account_id")
			const contactId = this.form.getValue("contact_id")

			if (!LeadHelper.validateQualified(accountId, contactId)) {
				return false
			}

			const conf = await this.helper.confirm({ title: "Do you want to send this lead to Opportunity?" })
			this.form.addData("send_to_opportunity", conf ?? false)
		}, "LeadPage.Sales")

		const hotLeadBtn = this.get("hot_lead")
		hotLeadBtn?.on("click", async () => {
			const accountId = this.form.getValue("account_id")
			const contactId = this.form.getValue("contact_id")
			await LeadHelper.prospect(this.id, accountId, contactId, () => this.refresh())
		})

		this.form.exclude("opportunity")
	}

	// #region Events

	async success(response) {
		await super.success(response)

		const hotLeadBtn = this.get("hot_lead")
		if (!hotLeadBtn) {
			return
		}

		const statusId        = this.form.get("status_id")?.get()?.id
		const allowedStatuses = [LeadStatus.Nurturing, LeadStatus.Qualified]
		const canConvert      = allowedStatuses.includes(statusId) && !this.data?.opportunity

		canConvert ? hotLeadBtn.enabled() : hotLeadBtn.disabled()
	}

	// #endregion
}
