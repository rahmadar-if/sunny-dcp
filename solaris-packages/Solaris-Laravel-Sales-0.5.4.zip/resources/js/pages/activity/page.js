import Filter from "@core-js/solaris/filter/filter";
import BaseActivityPage from "@base-crm-js/pages/activity/page";

export default class ActivityPage extends BaseActivityPage {
    initForm() {
        super.initForm()
        
        const contact     = this.form.get("contact_id")
        const account     = this.form.get("account_id")
        const lead        = this.form.get("lead_id")
        const opportunity = this.form.get("opportunity_id")
        const order       = this.form.get("order_id")
        const invoice     = this.form.get("invoice_id")

        lead?.on("change", (value) => {
            if(!value && opportunity?.get()) {
                opportunity.set(null)

                return
            }

            const opporValue = opportunity?.get()
            if(value && value.opportunity && (!opporValue || (opporValue && opporValue.id != value.opportunity.id))) {
                opportunity.set(value.opportunity)
            }
        }, "ActivityPage.Sales")

        opportunity?.init({
            param: (param) => {
                const filter     = new Filter()
                const accountVal = account?.get()
                if(accountVal) {
                    filter.and("customer_id", accountVal.id)
                }

                const contactVal = contact?.get()
                if(contactVal) {
                    filter.and("decision_maker_id", contactVal.id)
                }

                const leadVal = lead?.get()
                if(leadVal) {
                    filter.and("lead_id", leadVal.id)
                }

                param.filter = filter.get()

                return param
            },
            optionsTemplate: (state) => {
                if(!state.id) {
                    return state.name
                }

                const option = `<div class="d-flex flex-column gap-1">
                    <div class="d-flex justify-content-between">
                        <div class="d-flex gap-1 align-items-center">
                            <span class="fs-12 fw-semibold">${state.name}</span>
                            <span class="fs-10 badge bg-${state.status.color}">${state.status.name}</span>
                        </div>
                        <span class="fs-11">${state.date}</span>
                    </div>
                    ${state.customer ? `<span class="fs-11"><i class="ri-building-2-line me-1"></i>${state.customer.name}</span>` : ''}
                    ${state.decision_maker ? `<span class="fs-11"><i class="ri-user-3-line me-1"></i>${state.decision_maker.name}</span>` : ''}
                </div>`

                return option
            }
        })

        opportunity?.on("change", (value) => {
            const accountVal = account?.get()

            if(value && value.lead) {
                lead.set(value.lead, true)
            }
            
            if(value && value.customer && (!accountVal || (accountVal && accountVal.id != value.customer.id))) {
                account.set(value.customer)
            }
        }, "ActivityPage.Sales")

        order?.init({
            param: (param) => {
                const filter     = new Filter()
                const accountVal = account?.get()
                if(accountVal) {
                    filter.and("account_id", accountVal.id)
                }

                const contactVal = contact?.get()
                if(contactVal) {
                    filter.and("contact_id", contactVal.id)
                }

                const opporVal = opportunity?.get()
                if(opporVal) {
                    filter.and("opportunity_id", opporVal.id)
                }

                param.filter = filter.get()

                return param
            },
            optionsTemplate: (state) => {
                if(!state.id) {
                    return state.name
                }

                const option = `<div class="d-flex flex-column gap-1">
                    <div class="d-flex justify-content-between">
                        <div class="d-flex gap-1 align-items-center">
                            <span class="fs-12 fw-semibold">${state.number}</span>
                            <span class="fs-10 badge bg-${state.status.color}">${state.status.name}</span>
                        </div>
                        <span class="fs-11">${state.date}</span>
                    </div>
                    ${state.account ? `<span class="fs-11"><i class="ri-building-2-line me-1"></i>${state.account.name}</span>` : ''}
                    ${state.contact ? `<span class="fs-11"><i class="ri-user-3-line me-1"></i>${state.contact.name}</span>` : ''}
                </div>`

                return option
            }
        })

        order?.on("change", (value) => {
            if (!value && invoice?.get()) {
                invoice.set(null)
                return
            }

            if (value && value.opportunity && !opportunity?.get()) {
                opportunity.set(value.opportunity)
            }

            if (value && value.account && !account?.get()) {
                account.set(value.account)
            }
        }, "ActivityPage.Sales")

        invoice?.init({
            param: (param) => {
                const filter     = new Filter()
                const accountVal = account?.get()
                if(accountVal) {
                    filter.and("account_id", accountVal.id)
                }

                const contactVal = contact?.get()
                if(contactVal) {
                    filter.and("contact_id", contactVal.id)
                }

                const orderVal = order?.get()
                if(orderVal) {
                    filter.and("order_id", orderVal.id)
                }

                param.filter = filter.get()

                return param
            },
            optionsTemplate: (state) => {
                if(!state.id) {
                    return state.name
                }

                const option = `<div class="d-flex flex-column gap-1">
                    <div class="d-flex justify-content-between">
                        <div class="d-flex gap-1 align-items-center">
                            <span class="fs-12 fw-semibold">${state.number}</span>
                            <span class="fs-10 badge bg-${state.status.color}">${state.status.name}</span>
                        </div>
                        <span class="fs-11">${state.date}</span>
                    </div>
                    <span class="fs-12 text-muted fw-semibold">${state.subject}</span>
                    ${state.account ? `<span class="fs-11"><i class="ri-building-2-line me-1"></i>${state.account.name}</span>` : ''}
                    ${state.contact ? `<span class="fs-11"><i class="ri-user-3-line me-1"></i>${state.contact.name}</span>` : ''}
                </div>`

                return option
            }
        })

        invoice?.on("change", (value) => {
            if (!value) return

            if (value.order && !order?.get()) {
                order.set(value.order)
            }

            if (value.account && !account?.get()) {
                account.set(value.account)
            }
        }, "ActivityPage.Sales")
    }
}