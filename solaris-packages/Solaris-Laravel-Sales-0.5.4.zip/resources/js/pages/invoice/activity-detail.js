import ActivityDetail from "@master-data-js/pages/activity/detail";

export default class InvoiceActivityDetail extends ActivityDetail {
    init() {
        super.init()
    }
}