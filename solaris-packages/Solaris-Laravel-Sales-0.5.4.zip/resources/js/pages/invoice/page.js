import Filter from "@core-js/solaris/filter/filter";
import SolarEditPage from "@core-js/solaris/solar/solar-edit-page";
import InvoiceDetail from "./invoice-detail";
import InvoiceActivityDetail from "./activity-detail";
import InvoiceStatusHistoryDetail from "./status-history-detail";

export default class OrderPage extends SolarEditPage {
    init() {
        this.displayValueName = "number"

        this.initForm()

        this.registerDetail("invoice-detail", InvoiceDetail, "invoice_id")
        this.registerDetail("invoice-activity", InvoiceActivityDetail, "invoice_id")
        this.registerDetail("invoice-status-history", InvoiceStatusHistoryDetail, "invoice_id")
    }

    initDetail() {
        this.invoiceDetail
            ?.on("saved", (res) => this.refreshForm(), "OrderPage")
            .on("deleting", async (row, data) => await this._onSavingDetail(), "OrderPage")
            .on("deleted", (data) => this.refreshForm(), "OrderPage")
    }

    initForm() {
        const account = this.form.get("account_id")
        const contact = this.form.get("contact_id")
        contact?.init({
            param: (param) => {
                const filter    = new Filter()
                const accountId = account?.get()?.id
                if(accountId) {
                    filter.and("account_id", accountId)
                    param.filter = filter.get()
                }

                return param
            }
        })
    }

    async success(response) {
        this.invoiceStatusHistory?.refresh()
    }

    async onRefreshed(data) {
        this.breadcrumbName.textContent = data.number
    }
}