import InvoiceListPage from "./list"

new InvoiceListPage("invoice")