import Filter from "@core-js/solaris/filter/filter";
import SolarListDetail from "@core-js/solaris/solar/solar-list-detail";

export default class InvoiceDetail extends SolarListDetail {
    init() {
        this.initModal()

        this.columnRender("product_id", this.productColumnRender.bind(this))
        this.columnRender("price", this.priceColumnRender.bind(this))
        this.columnRender("discount", this.discountColumnRender.bind(this))
        this.columnRender("total", this.totalColumnRender.bind(this))
    }

    initModal() {
        if(!this.hasModalForm()) {
            return
        }

        const product = this.form.get("product_id")
        product?.init({
            param: (param) => {
                const filter = new Filter()
                filter.and("active", true)
                param.filter = filter.get()

                return param
            }
        })

        const price    = this.form.get("price") 
        const qty      = this.form.get("qty") 
        const amount   = this.form.get("amount") 
        const discount = this.form.get("discount") 
        const total    = this.form.get("total")

        const calculateAmount = () => {
            const priceVal    = price?.get() ?? 0
            const qtyVal      = qty?.get() ?? 0
            const discountVal = discount?.get() ?? 0

            amount.set(priceVal * qtyVal)
            total.set(amount?.get() - discountVal)
        }

        product?.on("change", (value) => price.set(value ? value.price : 0), "InvoiceDetail")

        price?.on("input", this.helper.debounce((value) => calculateAmount(), 300), "InvoiceDetail")

        qty?.on("input", this.helper.debounce((value) => calculateAmount(), 300), "InvoiceDetail")

        amount?.on("input", this.helper.debounce((value) => calculateAmount(), 300), "InvoiceDetail")

        discount?.on("input", this.helper.debounce((value) => calculateAmount(), 300), "InvoiceDetail")

        this.modal.on("show", () => {
            if(this.form.isEdit()) {
                calculateAmount()
            }
        }, "InvoiceDetail")

        this.form.exclude(["amount"])
    }

    productColumnRender(data, rowData) {
       const initialName = this.helper.getInitialName(data)
        return `<div class="d-flex align-items-center gap-2">
            <div class="lh-1">
                <span class="avatar avatar-rounded avatar-sm ${!rowData.product.product_picture_id ? "bg-secondary" : ""}">
                    ${rowData.product.product_picture_id ? `<img src="${BASE_URL}/core/images/thumbnail/${rowData.product.product_picture_id}" alt="">` : initialName}
                </span>
            </div>
            <div>
                <a class="text-decoration-underline" href="${BASE_URL}/master-data/product/${rowData.product_id}">${data}</a>
            </div>
        </div>`
    }

    priceColumnRender(data, rowData) {
       return `Rp ${this.helper.numberToCurrency(data ?? 0)}`
    }

    discountColumnRender(data, rowData) {
       return `Rp ${this.helper.numberToCurrency(data ?? 0)}`
    }

    totalColumnRender(data, rowData) {
       return `Rp ${this.helper.numberToCurrency(data ?? 0)}`
    }
}