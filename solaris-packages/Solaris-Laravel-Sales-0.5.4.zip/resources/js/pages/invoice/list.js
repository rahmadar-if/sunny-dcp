import Filter from "@core-js/solaris/filter/filter";
import SolarListPage from "@core-js/solaris/solar/solar-list-page";
import { OrderStatus } from "@sales-js/const";

export default class InvoiceListPage extends SolarListPage {
    
    init() {
        this.initModal()

        this.columnRender("account_id", this.accountColumnRender.bind(this))
        this.columnRender("contact_id", this.contactColumnRender.bind(this))
        this.columnRender("status_id", this.statusColumnRender.bind(this))
        this.columnRender("amount", this.amountColumnRender.bind(this))
    }

    initModal() {
        if(!this.hasModalForm()) {
            return
        }

        const account = this.form.get("account_id")
        const order   = this.form.get("order_id")
        order?.init({
            optionsTemplate: (state) => {
                if(!state.id) {
                    return state.number
                }

                const option = `<div class="d-flex flex-column gap-1">
                    <div class="d-flex justify-content-between">
                        <div class="d-flex gap-1 align-items-center">
                            <span class="fs-12 fw-semibold">${state.number}</span>
                            <span class="fs-10 badge bg-${state.status.color}">${state.status.name}</span>
                        </div>
                        <span class="fs-11">${state.date}</span>
                    </div>
                    ${state.account_id ? `<span class="fs-11"><i class="ri-building-2-line me-1"></i>${state.account.name}</span>` : ''}
                    ${state.contact_id ? `<span class="fs-11"><i class="ri-user-3-line me-1"></i>${state.contact.name}</span>` : ''}
                    ${state.amount != null ? `
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="fs-11"><i class="ri-edit-line"></i>${state.created_by.name}</span>
                            <span class="fs-12 fw-semibold">Rp ${this.helper.numberToCurrency(state.amount)}</span>
                        </div>` : ''}
                </div>`

                return option
            }
        })

        order?.on("change", (value) => {
            account?.set(value ? value.account : null)
        }, "InvoiceListPage")
    }

    openEditPage(id) {
        this.helper.loadingPage(true)
        window.location = `${BASE_URL}/sales/invoice/edit/${id}`
    }

    async edit(row, data) {
        this.openEditPage(data.id)
    }

    rowDoubleClick(row, data) {
        this.openEditPage(data.id)
    }

    accountColumnRender(data, rowData) {
        if(!data) {
            return data
        }

        const initialName = this.helper.getInitialName(data)
        return `<div class="d-flex align-items-center gap-2">
            <div class="lh-1">
                <span class="avatar avatar-rounded avatar-sm ${!rowData.account.profile_picture_id ? "bg-secondary" : ""}">
                    ${rowData.account.profile_picture_id ? `<img src="${BASE_URL}/core/images/thumbnail/${rowData.account.profile_picture_id}" alt="">` : initialName}
                </span>
            </div>
            <div>
                <a class="text-decoration-underline" href="${BASE_URL}/master-data/account/${rowData.account_id}">${data}</a>
            </div>
        </div>`
    }

    contactColumnRender(data, rowData) {
        if(!data) {
            return data
        }

        const initialName = this.helper.getInitialName(data)
        return `<div class="d-flex align-items-center gap-2">
            <div class="lh-1">
                <span class="avatar avatar-rounded avatar-sm ${!rowData.contact.profile_picture_id ? "bg-secondary" : ""}">
                    ${rowData.contact.profile_picture_id ? `<img src="${BASE_URL}/core/images/thumbnail/${rowData.contact.profile_picture_id}" alt="">` : initialName}
                </span>
            </div>
            <div>
                <a class="text-decoration-underline" href="${BASE_URL}/master-data/contact/${rowData.contact_id}">${data}</a>
            </div>
        </div>`
    }

    statusColumnRender(data, rowData) {
        return `<span class="badge bg-${rowData.status.color}">${data}</span>`
    }

    amountColumnRender(data, rowData) {
        return `Rp ${this.helper.numberToCurrency(data ?? 0)}`
    }
}