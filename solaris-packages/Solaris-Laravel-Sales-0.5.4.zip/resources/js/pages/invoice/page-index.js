import OrderPage from "./page"

new OrderPage()