import SolarPage from "@core-js/solaris/solar/solar-page"
import Numeral from "@core-js/solaris/numeral"

export default class SalesDashboardLeadOpportunity extends SolarPage {
    
    /**
     * @param {*} metricData 
     * @param {*} prospectBySourceData 
     * @param {string} period 
     */
    constructor(metricData, prospectBySourceData, period) {
        super(false)

        this.metricData           = metricData
        this.prospectBySourceData = prospectBySourceData
        this._period              = period

        this.init()
    }

    init() {
        this.initMetric()
        this.initOpportunityPipeline()
        this.initProspectBySource()
        this.initOpportunityOverview()
        this.initTopOpportunity()
    }

    updatePeriod(period) {
        this._period = period
    }

    initMetric() {
        const initMetric = (metric, chart) => {
            metric?.init()
            metric?.setChart(chart)
        }

        this.totalLead         = this.get("total-lead")
        this.qualifiedLead     = this.get("qualified-lead") 
        this.leadConversion    = this.get("lead-conversion-2")
        this.totalOpportunity  = this.get("total-opportunity")
        this.opportunityAmount = this.get("opportunity-amount-2")
        this.pipelineForecast  = this.get("pipeline-forecast-2")
        this.winRate           = this.get("win-rate-2")
        this.avgSalesCycle     = this.get("avg-sales-cycle")

        initMetric(this.totalLead, this.metricData.total_lead)
        initMetric(this.qualifiedLead, this.metricData.qualified_lead)
        initMetric(this.leadConversion, this.metricData.lead_conversion)
        initMetric(this.totalOpportunity, this.metricData.total_opportunity)
        initMetric(this.opportunityAmount, this.metricData.opportunity_amount)
        initMetric(this.pipelineForecast, this.metricData.pipeline_forecast)
        initMetric(this.winRate, this.metricData.win_rate)
        initMetric(this.avgSalesCycle, this.metricData.avg_sales_cycle)
    }

    initOpportunityPipeline() {
        this._refreshOpportunityPipeline = this.get("opportunity-pipeline-refresh-2")
        this._refreshOpportunityPipeline?.on("click", () => this.pipelineOpportunityRefresh(), "SalesDashboardLeadOpportunity")

        this.opportunityPipeline = this.get("opportunity-pipeline-2")
    }

    initProspectBySource() {
        this._refreshProspectSource = this.get("prospect-source-refresh")
        this._refreshProspectSource?.on("click", () => this.prospectSourceRefresh(), "SalesDashboardLeadOpportunity")

        this.prospectSourceDetail = document.querySelector("#prospect-source-detail")

        const chart = this.prospectBySourceData.chart
        const options = {
            series: chart.series,
            labels: chart.label,
            chart: {
                height: 224,
                type: 'donut',
            },
            dataLabels: {
                enabled: false,
            },
            legend: {
                show: true,
                position: 'bottom',
                markers: {
                    size: 4,
                    shape: 'circle',
                },
            },
            stroke: {
                show: true,
                curve: 'smooth',
                lineCap: 'round',
                colors: ["#fff"],
                width: 0,
                dashArray: 0,
            },
            plotOptions: {
                pie: {
                    expandOnClick: false,
                    donut: {
                        size: '86%',
                        background: 'transparent',
                        labels: {
                            show: true,
                            name: {
                                show: true,
                                fontSize: '20px',
                                color: '#495057',
                                fontFamily: "Poppins, sans-serif",
                                offsetY: -5
                            },
                            value: {
                                show: true,
                                fontSize: '22px',
                                color: undefined,
                                offsetY: 5,
                                fontWeight: 600,
                                fontFamily: "Poppins, sans-serif",
                                formatter: (val, {config, globals}) => {
                                    const total = config.series.reduce((a, b) => a + b, 0)
                                    return (parseInt(val)/total*100).toFixed(2) + "%"
                                }
                            },
                            total: {
                                show: true,
                                showAlways: true,
                                label: 'Total Leads',
                                fontFamily: "Poppins, sans-serif",
                                fontSize: '14px',
                                fontWeight: 400,
                                color: '#495057',
                            }
                        }
                    }
                }
            },
            colors: chart.colors
        }

        this.prospectSource = new ApexCharts(document.querySelector("#prospect-source"), options)
        this.prospectSource.render()
    }

    initOpportunityOverview() {
        this._refreshOpportunityOverview = this.get("opportunity-overview-refresh")
        this._refreshOpportunityOverview?.on("click", () => this.opportunityOverviewRefresh(), "SalesDashboardLeadOpportunity")

        this.opportunityOverviewTotal        = document.querySelector("#opportunity-overview-total")
        this.opportunityOverviewTotalAmount  = document.querySelector("#opportunity-overview-total-amount")
        this.opportunityOverviewTotalAmountNumeral = this.opportunityOverviewTotalAmount ? new Numeral(this.opportunityOverviewTotalAmount) : null
        this.opportunityOverviewPercent      = document.querySelector("#opportunity-overview-percent")
        this.opportunityOverviewDetail       = document.querySelector("#opportunity-overview-detail")
    }

    initTopOpportunity() {
        this._refreshTopOpportunity = this.get("top-opportunity-refresh")
        this._refreshTopOpportunity?.on("click", () => this.topOpportunityRefresh(), "SalesDashboardLeadOpportunity")

        this.topOpportunity = document.querySelector("#top-opportunity")
    }

    /**
     * @param {*} data
     */
    async refresh(data) {
        await Promise.all([
            this._refreshMetric(this.totalLead, data.total_lead),
            this._refreshMetric(this.qualifiedLead, data.qualified_lead),
            this._refreshMetric(this.leadConversion, data.lead_conversion),
            this._refreshMetric(this.totalOpportunity, data.total_opportunity),
            this._refreshMetric(this.opportunityAmount, data.opportunity_amount),
            this._refreshMetric(this.pipelineForecast, data.pipeline_forecast),
            this._refreshMetric(this.winRate, data.win_rate),
            this._refreshMetric(this.avgSalesCycle, data.avg_sales_cycle),
            this.pipelineOpportunityRefresh(data.opportunity_pipeline),
            this.prospectSourceRefresh(data.prospect_by_source),
            this.opportunityOverviewRefresh(data.opportunity_overview),
            this.topOpportunityRefresh(data.top_opportunity)
        ])
    }

    /**
     * @param {import("@core-js/solaris/metric-dashboard").default} metric
     * @param {{value: string, change: {value: string, type: string|null, title: string}, chart: Array}|null} data
     */
    _refreshMetric(metric, data) {
        if (!metric || !data) return null
        metric.setValue(data.value)
        metric.setChange(data.change)
        return metric.setChart(data.chart)
    }

    /**
     * @param {[{name: string, color: string, value: number}]} data 
     */
    async pipelineOpportunityRefresh(data = null) {
        if(!data) {
            const req = await this.axios({
                method: "POST",
                url   : `${BASE_URL}/sales/dashboard/opportunity-pipeline`,
                data  : {
                    period: this._period
                }
            })

            data = req.data
        }

        this.opportunityPipeline?.updateData(data)
    }

    /**
     * @param {{chart: {series: [number], label: [string], color: [string]}, detail: [{name: string, total: string, icon: string, color: string, change: string, changeIcon: string, changeColor: string}]}} data 
     */
    async prospectSourceRefresh(data = null) {
        if(!data) {
            const req = await this.axios({
                method: "POST",
                url   : `${BASE_URL}/sales/dashboard/prospect-by-source`,
                data  : {
                    period: this._period
                }
            })

            data = req.data
        }

        const chart = data.chart

        this.prospectSource?.updateSeries(chart.series)
        this.prospectSource?.updateOptions({
            label : chart.label,
            colors: chart.colors 
        })

        let detail = ""
        data.detail.forEach(item => detail += this._renderProspectBySource(
            item.name, 
            item.total, 
            item.icon, 
            item.color, 
            item.change, 
            item.changeIcon, 
            item.changeColor
        ))
        
        this.prospectSourceDetail.innerHTML = detail
    }

    /**
     * @param {{total: number, total_amount: number, detail: [{id: string, name: string, total: number, total_amount: number, percent: number, icon: string, color: string, change: string, changeIcon: ?string, changeColor: string}]}} data
     */
    async opportunityOverviewRefresh(data = null) {
        if(!data) {
            const req = await this.axios({
                method: "POST",
                url   : `${BASE_URL}/sales/dashboard/opportunity-overview`,
                data  : {
                    period: this._period
                }
            })

            data = req.data
        }

        if(this.opportunityOverviewTotal) {
            this.opportunityOverviewTotal.innerText = data.total
        }

        this.opportunityOverviewTotalAmountNumeral?.set(data.total_amount)

        let percent = ''
        let detail  = ''

        data.detail.forEach(item => {
            percent += this._renderOpportunityOverviewPercent(item.percent, item.color)
            detail  += this._renderOpportunityOverviewDetail(
                item.id,
                item.name,
                item.total,
                item.total_amount,
                item.icon,
                item.color,
                item.change,
                item.changeIcon,
                item.changeColor
            )
        })

        if(this.opportunityOverviewPercent) {
            this.opportunityOverviewPercent.innerHTML = percent
        }

        if(this.opportunityOverviewDetail) {
            this.opportunityOverviewDetail.innerHTML = detail
            this.opportunityOverviewDetail.querySelectorAll('[solar-ui="numeral"]').forEach(el => new Numeral(el))
        }
    }

    /**
     * @param {*} data 
     */
    async topOpportunityRefresh(data = null) {
        if(!data) {
            const req = await this.axios({
                method: "POST",
                url   : `${BASE_URL}/sales/dashboard/top-opportunity`,
                data  : {
                    period: this._period
                }
            })

            data = req.data
        }

        let topOpportunity = ''
        data.forEach(item => topOpportunity += this._renderTopOpportunity(
            item.id,
            item.name,
            item.customer?.name,
            item.customer?.profile_picture_id,
            item.total_amount,
            item.status.name,
            item.status.color
        ))

        if(this.topOpportunity) {
            this.topOpportunity.innerHTML = topOpportunity
            this.topOpportunity.querySelectorAll('[solar-ui="numeral"]').forEach(el => new Numeral(el))
        }
    }

    /**
     * @param {string} id
     * @param {number} amount
     * @param {string} prefix
     * @returns {string}
     */
    _renderNumeral(id, amount, prefix = 'Rp ') {
        const readable = this.helper.readableNumber(amount)
        const full     = this.helper.readableNumber(amount, 2, ',', '.', false)

        return `<span id="${id}" solar-ui="numeral" decimals="2" decimal-separator="," thousand-separator=".">
            <span class="numeral-prefix">${prefix}</span>
            <span class="numeral-readable">${readable}</span>
            <span class="numeral-full d-none">${full}</span>
        </span>`
    }

    /**
     * @param {string} name 
     * @param {string} total 
     * @param {string} icon 
     * @param {string} color 
     * @param {string} change 
     * @param {?string} changeIcon 
     * @param {string} changeColor 
     * @returns {string}
     */
    _renderProspectBySource(name, total, icon, color, change, changeIcon, changeColor) {
        return `<div class="col-6">
            <div class="d-flex align-items-center gap-3 flex-wrap">
                <div class="lh-1">
                    <span class="avatar avatar-rounded avatar-md bg-${color}-transparent">
                        <i class="${icon} fs-20"></i>
                    </span>
                </div>
                <div>
                    <span class="d-block fs-12 text-muted fw-medium">${name}</span>
                    <div class="d-flex align-items-center gap-2">
                        <h6 class="fw-medium mb-0">${total}</h6>
                        <span class="text-${changeColor} fs-12 fw-medium">
                            ${changeIcon ? `<i class="${changeIcon}"></i>` : ''}${change}
                        </span>
                    </div>
                </div>
            </div>
        </div>`
    }

    /**
     * @param {number} percent 
     * @param {string} color 
     * @returns {string}
     */
    _renderOpportunityOverviewPercent(percent, color) {
        return `<div class="progress-bar progress-bar-striped bg-${color}" role="progressbar"
            style="width: ${percent}%" aria-valuenow="${percent}" aria-valuemin="0" aria-valuemax="100">
        </div>`
    }

    /**
     * @param {string} id
     * @param {string} name
     * @param {string} total
     * @param {number} totalAmount
     * @param {string} icon
     * @param {string} color
     * @param {string} change
     * @param {?string} changeIcon
     * @param {string} changeColor
     * @returns {string}
     */
    _renderOpportunityOverviewDetail(id, name, total, totalAmount, icon, color, change, changeIcon, changeColor) {
        return `<tr>
            <td>
                <div class="d-flex align-items-center gap-2">
                    <div class="lh-1">
                        <span
                class="avatar avatar-md border border-${color} border-${color} border-opacity-25 avatar-rounded">
                <span
                    class="avatar avatar-sm bg-${color}-transparent avatar-rounded">
                    <i class="${icon} fs-20"></i>
                </span>
            </span>
                    </div>
                    <div>
                        <span class="fw-medium d-block">${name}</span>
                        <span class="d-block text-muted fs-12">${total} Opportunity</span> </div>
                </div>
            </td>
            <td>
                <span class="text-${changeColor} badge bg-${changeColor}-transparent fw-medium">
                    ${changeIcon ? `<i class="${changeIcon}"></i>` : ''}${change}
                </span>
            </td>
            <td class="text-end">
                <div>
                    <span class="d-block fw-medium mb-0">${this._renderNumeral(`opportunity-overview-${id}-amount`, totalAmount)}</span>
                </div>
            </td>
        </tr>`
    }

    /**
     * @param {string} id
     * @param {string} name
     * @param {?string} customer
     * @param {?string} avatar
     * @param {number} totalAmount
     * @param {string} status
     * @param {string} statusColor
     * @returns {string}
     */
    _renderTopOpportunity(id, name, customer, avatar, totalAmount, status, statusColor) {
        return `<li class="list-group-item">
            <div class="d-flex align-items-center gap-2">
                <div class="lh-1">
                    <span class="avatar avatar-md avatar-rounded ${avatar ? "" : "bg-secondary"}">
                        ${avatar ? `<img src="${BASE_URL}/core/images/thumbnail/${avatar}" alt="">` : this.helper.getInitialName(customer ?? "")}
                    </span>
                </div>
                <div class="flex-fill">
                    <span class="d-block fw-medium">${name}</span>
                    <span class="fs-12 text-muted">${customer ?? ""}</span>
                </div>
                <div class="d-flex flex-column align-items-end gap-1">
                    <div class="fw-medium">${this._renderNumeral(`top-opportunity-${id}-amount`, totalAmount)}</div>
                    <span class="badge bg-${statusColor}">${status}</span>
                </div>
            </div>
        </li>`
    }
}