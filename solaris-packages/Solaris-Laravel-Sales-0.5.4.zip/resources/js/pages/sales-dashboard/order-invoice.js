import SolarPage from "@core-js/solaris/solar/solar-page";
import Numeral from "@core-js/solaris/numeral"

export default class SalesDashboardOrderInvoice extends SolarPage {
    
    /**
     * @param {*} metricData 
     * @param {*} revenueAnalyticData 
     * @param {string} period 
     */
    constructor(metricData, revenueAnalyticData, period) {
        super(false)

        this.metricData          = metricData
        this.revenueAnalyticData = revenueAnalyticData
        this._period             = period

        this.init()
    }

    init() {
        this.initMetric()
        this.initRevenueAnalytic()
        this.initRecentOrder()
        this.initTopOrder()
        this.initTopProductOrdered()
    }

    updatePeriod(period) {
        this._period = period
    }

    initMetric() {
        const initMetric = (metric, chart = null) => {
            metric?.init()
            if(chart) {
                metric?.setChart(chart)
            }
        }

        this.totalRevenue       = this.get("total-revenue-2")
        this.outstandingInvoice = this.get("outstanding-invoice-2")
        this.avgPaymentTime     = this.get("avg-payment-time")
        this.totalSales         = this.get("total-sales-2")
        this.totalOrder         = this.get("total-order")
        this.totalInvoice       = this.get("total-invoice")

        initMetric(this.totalRevenue, this.metricData.total_revenue)
        initMetric(this.outstandingInvoice, this.metricData.outstanding_invoice)
        initMetric(this.avgPaymentTime, this.metricData.avg_payment_time)
        initMetric(this.totalSales, this.metricData.total_sales)
        initMetric(this.totalOrder, this.metricData.total_order)
        initMetric(this.totalInvoice, this.metricData.total_invoice)
    }

    initRevenueAnalytic() {
        this._refreshRevenueAnalytic = this.get("revenue-analytic-refresh")
        this._refreshRevenueAnalytic?.on("click", () => this.revenueAnalyticRefresh(), "SalesDashboardOrderInvoice")

        const options = {
            series: this.revenueAnalyticData.series,
            chart: {
                height: 290,
                animations: {
                    speed: 500
                },
                zoom: {
                    enabled: true,
                    type: 'x',
                    autoScaleYaxis: true
                },
                toolbar: {
                    tools: {
                        download: true,
                        selection: true,
                        zoom: true,
                        zoomin: false,
                        zoomout: false,
                        pan: true,
                        reset: true
                    },
                }
            },
            colors: this.revenueAnalyticData.colors,
            dataLabels: {
                enabled: false
            },
            grid: {
                borderColor: '#f1f1f1',
                strokeDashArray: 3
            },
            stroke: {
                curve: 'smooth',
                width: [2, 2, 2],
                dashArray: [0, 0, 5]
            },
            xaxis: {
                axisTicks: {
                    show: false,
                },
                categories: this.revenueAnalyticData.categories
            },
            yaxis: {
                labels: {
                    formatter: (value) => "Rp" + this.helper.readableNumber(value)
                },
            },
            tooltip: {
                y: [
                    {
                        formatter: (value) => "Rp" + this.helper.readableNumber(value)
                    }, 
                    {
                        formatter: (value) => "Rp" + this.helper.readableNumber(value)
                    }, 
                    {
                        formatter: (value) => "Rp" + this.helper.readableNumber(value)
                    }
                ]
            },
            legend: {
                show: true,
                position: "bottom",
                offsetX: 0,
                offsetY: 8,
                markers: {
                    size: 4,
                    strokeWidth: 0,
                    strokeColor: '#fff',
                },
            },
            title: {
                align: 'left',
                style: {
                    fontFamily: "Poppins, sans-serif",
                    fontSize: '.8125rem',
                    fontWeight: 'semibold',
                    color: '#8c9097'
                },
            },
            markers: {
                hover: {
                    sizeOffset: 5
                }
            }
        }

        this.revenueAnalytic = new ApexCharts(document.querySelector("#revenue-analytic"), options)
        this.revenueAnalytic.render()
    }

    initRecentOrder() {
        this._refreshRecentOrder = this.get("recent-order-refresh")
        this._refreshRecentOrder?.on("click", () => this.recentOrderRefresh(), "SalesDashboardOrderInvoice")

        this.recentOrder = document.querySelector('#recent-order')
    }

    initTopOrder() {
        this._refreshTopOrder = this.get("top-order-refresh")
        this._refreshTopOrder?.on("click", () => this.topOrderRefresh(), "SalesDashboardOrderInvoice")

        this.topOrder = document.querySelector('#top-order')
    }

    initTopProductOrdered() {
        this._refreshTopProductOrdered = this.get("top-product-order-refresh")
        this._refreshTopProductOrdered?.on("click", () => this.topProductOrderedRefresh(), "SalesDashboardOrderInvoice")

        this.topProductOrdered = document.querySelector('#top-product-order')
    }

    /**
     * @param {*} data
     */
    async refresh(data) {
        await Promise.all([
            this._refreshMetric(this.totalRevenue, data.total_revenue),
            this._refreshMetric(this.outstandingInvoice, data.outstanding_invoice),
            this._refreshMetric(this.avgPaymentTime, data.avg_payment_time),
            this._refreshMetric(this.totalSales, data.total_sales),
            this._refreshMetric(this.totalOrder, data.total_order),
            this._refreshMetric(this.totalInvoice, data.total_invoice),
            this.revenueAnalyticRefresh(data.revenue_analytic),
            this.recentOrderRefresh(data.recent_order),
            this.topOrderRefresh(data.top_order),
            this.topProductOrderedRefresh(data.top_product_ordered)
        ])
    }

    /**
     * @param {import("@core-js/solaris/metric-dashboard").default} metric
     * @param {{value: string, change: {value: string, type: string|null, title: string}, chart: Array}|null} data
     */
    _refreshMetric(metric, data) {
        if (!metric || !data) return null
        metric.setValue(data.value)
        metric.setChange(data.change)
        return metric.setChart(data.chart)
    }

    /**
     * @param {{series: [{name: string, data: [number]}], categories: [string], colors: [string]} data 
     */
    async revenueAnalyticRefresh(data = null) {
        if(!data) {
            const req = await this.axios({
                method: "POST",
                url   : `${BASE_URL}/sales/dashboard/revenue-analytic`,
                data  : {
                    period: this._period
                }
            })

            data = req.data
        }

        this.revenueAnalytic?.updateSeries(data.series)
        this.revenueAnalytic?.updateOptions({
            xaxis: {
                categories: data.categories,
                colors    : data.colors
            }
        })
    }

    /**
     * @param {*} data 
     */
    async recentOrderRefresh(data = null) {
        if(!data) {
            const req = await this.axios({
                method: "POST",
                url   : `${BASE_URL}/sales/dashboard/recent-order`
            })

            data = req.data
        }

        let recent = ""
        data.forEach(item => recent += this._renderRecentOrder(
            item.id,
            item.number,
            item.status,
            item.account.name,
            item.account?.profile_picture_id,
            item.recent,
            item.amount
        ))

        if(this.recentOrder) {
            this.recentOrder.innerHTML = recent
            this.recentOrder.querySelectorAll('[solar-ui="numeral"]').forEach(el => new Numeral(el))
        }
    }

    /**
     * @param {*} data 
     */
    async topOrderRefresh(data = null) {
        if(!data) {
            const req = await this.axios({
                method: "POST",
                url   : `${BASE_URL}/sales/dashboard/top-order`,
                data  : {
                    period: this._period
                }
            })

            data = req.data
        }

        let topOrder = ""
        data.forEach(item => topOrder += this._renderTopOrder(
            item.id,
            item.number,
            item.status,
            item.account.name,
            item.account?.profile_picture_id,
            item.amount
        ))

        if(this.topOrder) {
            this.topOrder.innerHTML = topOrder
            this.topOrder.querySelectorAll('[solar-ui="numeral"]').forEach(el => new Numeral(el))
        }
    }

    /**
     * @param {*} data 
     */
    async topProductOrderedRefresh(data = null) {
        if(!data) {
            const req = await this.axios({
                method: "POST",
                url   : `${BASE_URL}/sales/dashboard/top-product-ordered`,
                data  : {
                    period: this._period
                }
            })

            data = req.data
        }

        let topProduct = ""
        data.forEach(item => topProduct += this._renderTopProductOrdered(
            item.product_id,
            item.product_name,
            item.avatar,
            item.order_count,
            item.total_amount,
            item.total_qty
        ))

        if(this.topProductOrdered) {
            this.topProductOrdered.innerHTML = topProduct
            this.topProductOrdered.querySelectorAll('[solar-ui="numeral"]').forEach(el => new Numeral(el))
        }
    }

    /**
     * @param {string} id
     * @param {number} amount
     * @param {string} prefix
     * @returns {string}
     */
    _renderNumeral(id, amount, prefix = 'Rp ') {
        const readable = this.helper.readableNumber(amount)
        const full     = this.helper.readableNumber(amount, 2, ',', '.', false)

        return `<span id="${id}" solar-ui="numeral" decimals="2" decimal-separator="," thousand-separator=".">
            <span class="numeral-prefix">${prefix}</span>
            <span class="numeral-readable">${readable}</span>
            <span class="numeral-full d-none">${full}</span>
        </span>`
    }

    /**
     * @param {string} id
     * @param {string} number
     * @param {{name: string, color: string}} status
     * @param {string} account
     * @param {?string} avatar
     * @param {string} recent
     * @param {number} amount
     * @returns {string}
     */
    _renderRecentOrder(id, number, status, account, avatar, recent, amount) {
        return `<li class="list-group-item">
            <div class="d-flex align-items-center gap-2">
                <div class="lh-1">
                    <span class="avatar avatar-md avatar-rounded ${avatar ? "" : "bg-secondary"}">
                        ${avatar ? `<img src="${BASE_URL}/core/images/thumbnail/${avatar}">` : this.helper.getInitialName(account)}
                    </span>
                </div>
                <div class="flex-fill">
                    <div class="d-flex align-items-center gap-1">
                        <span class="d-block fw-medium">${number}</span>
                        <span class="badge bg-${status.color}">${status.name}</span>
                    </div>
                    <span class="fs-12 text-muted">${account}</span>
                </div>
                <div class="d-flex flex-column align-items-end gap-1">
                    <span class="d-block text-muted fs-11 op-7">${recent}</span>
                    <div class="fw-medium">${this._renderNumeral(`recent-order-${id}-amount`, amount)}</div>
                </div>
            </div>
        </li>`
    }

    /**
     * @param {string} id
     * @param {string} number
     * @param {string} status
     * @param {string} account
     * @param {?string} avatar
     * @param {number} amount
     * @returns {string}
     */
    _renderTopOrder(id, number, status, account, avatar, amount) {
        return `<li class="list-group-item">
            <div class="d-flex align-items-center gap-2">
                <div class="lh-1">
                    <span class="avatar avatar-md avatar-rounded ${avatar ? "" : "bg-secondary"}">
                        ${avatar ? `<img src="${BASE_URL}/core/images/thumbnail/${avatar}">` : this.helper.getInitialName(account)}
                    </span>
                </div>
                <div class="flex-fill">
                    <div class="d-flex align-items-center gap-1">
                        <span class="d-block fw-medium">${number}</span>
                        <span class="badge bg-${status.color}">${status.name}</span>
                    </div>
                    <span class="fs-12 text-muted">${account}</span>
                </div>
                <div class="fw-medium">${this._renderNumeral(`top-order-${id}-amount`, amount)}</div>
            </div>
        </li>`
    }

    /**
     * @param {string} productId
     * @param {string} product
     * @param {?string} avatar
     * @param {int} orderCount
     * @param {number} totalAmount
     * @param {int} totalQty
     * @returns {string}
     */
    _renderTopProductOrdered(productId, product, avatar, orderCount, totalAmount, totalQty) {
        return `<li class="list-group-item">
            <div class="d-flex align-items-center gap-2">
                <div class="lh-1">
                    <span class="avatar avatar-md avatar-rounded ${avatar ? "" : "bg-secondary"}">
                        ${avatar ? `<img src="${BASE_URL}/core/images/thumbnail/${avatar}">` : this.helper.getInitialName(product)}
                    </span>
                </div>
                <div class="flex-fill">
                    <span class="d-block fw-medium">${product}</span>
                    <span class="fs-12 text-muted">${orderCount} ordered</span>
                </div>
                <div class="d-flex flex-column align-items-end gap-1">
                    <div class="fw-medium">${this._renderNumeral(`top-product-${productId}-amount`, totalAmount)}</div>
                    <span class="d-block text-muted fs-11 op-7">${totalQty} qty</span>
                </div>
            </div>
        </li>`
    }
}