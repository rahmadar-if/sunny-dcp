import SolarPage from "@core-js/solaris/solar/solar-page";
import SalesDashboardSummary from "./summary";
import SalesDashboardLeadOpportunity from "./lead-opportunity";
import SalesDashboardOrderInvoice from "./order-invoice";

export default class SalesDashboardPage extends SolarPage {
    init() {
        this._refreshBtn = this.get("refresh")
        this._refreshBtn?.on("click", this.refresh.bind(this), "SalesDashboardPage")

        this._periodFilter = this.get("period-filter")
        this._period       = this._periodFilter?.toString() ?? ""

        this._periodFilter?.on("change", async (value, valueStr) => {
            this._period = valueStr
            
            this.summary.updatePeriod(this._period)
            this.leadOpportunity.updatePeriod(this._period)
            this.orderInvoice.updatePeriod(this._period)

            await this.refresh()
        }, "SalesDashboardPage")

        this.summary         = new SalesDashboardSummary(SUMMARY_METRIC_CHART, SALES_ANALYTIC, this._period)
        this.leadOpportunity = new SalesDashboardLeadOpportunity(LEAD_OPP_METRIC_CHART, PROSPECT_BY_SOURCE, this._period)
        this.orderInvoice    = new SalesDashboardOrderInvoice(ORDER_INV_METRIC_CHART, REVENUE_ANALYTIC, this._period)
    }

    async refresh() {
        try {
            this.helper.loadingPage(true)
            const data = await this._fetchData()
            
            await Promise.all([
                this.summary?.refresh(data.summary),
                this.leadOpportunity?.refresh(data.lead_opportunity),
                this.orderInvoice?.refresh(data.order_invoice),
            ])
        } catch (error) {
            console.error({error})
        } finally {
            this.helper.loadingPage(false)
        }
    }

    async _fetchData() {
        const req = await this.axios({
            method: "POST",
            url   : `${BASE_URL}/sales/dashboard/all`,
            data  : {
                period: this._period
            }
        })

        return req.data
    }
}