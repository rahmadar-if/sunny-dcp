import SolarPage from "@core-js/solaris/solar/solar-page"
import Numeral from "@core-js/solaris/numeral"

export default class SalesDashboardSummary extends SolarPage {
    
    /**
     * @param {*} metricData 
     * @param {*} salesAnalyticData 
     * @param {string} period 
     */
    constructor(metricData, salesAnalyticData, period) {
        super(false)

        this.metricData        = metricData
        this.salesAnalyticData = salesAnalyticData
        this._period           = period

        this.init()
    }

    init() {
        this.initMetric()
        this.initOpportunityPipeline()
        this.initSalesAnalytic()
        this.initActivity()
        this.initTopSales()
        this.initTopCustomer()
    }

    updatePeriod(period) {
        this._period = period
    }

    initMetric() {
        const initMetric = (metric, chart = null) => {
            metric?.init()
            if(chart) {
                metric?.setChart(chart)
            }
        }

        this.totalRevenue         = this.get("total-revenue")
        this.outstandingInvoice   = this.get("outstanding-invoice")
        this.totalSales           = this.get("total-sales")
        this.opportunityClosedWon = this.get("opportunity-closed-won")
        this.leadConversion       = this.get("lead-conversion")
        this.winRate              = this.get("win-rate")
        this.pipelineForecast     = this.get("pipeline-forecast")

        initMetric(this.totalRevenue, this.metricData.total_revenue)
        initMetric(this.outstandingInvoice, this.metricData.outstanding_invoice)
        initMetric(this.totalSales, this.metricData.total_sales)
        initMetric(this.opportunityClosedWon, this.metricData.opportunity_closed_won)
        initMetric(this.leadConversion)
        initMetric(this.winRate)
        initMetric(this.pipelineForecast)
    }

    initOpportunityPipeline() {
        this._refreshOpportunityPipeline = this.get("opportunity-pipeline-refresh")
        this._refreshOpportunityPipeline?.on("click", () => this.pipelineOpportunityRefresh(), "SalesDashboardSummary")

        this.opportunityPipeline = this.get("opportunity-pipeline")
    }

    initSalesAnalytic() {
        this._refreshSalesAnalytic = this.get("sales-analytic-refresh")
        this._refreshSalesAnalytic.on("click", () => this.salesAnalyticRefresh(), "SalesDashboardSummary")

        const options = {
            series: this.salesAnalyticData.series,
            chart: {
                height: 290,
                animations: {
                    speed: 500
                },
                zoom: {
                    enabled: true,
                    type: 'x',
                    autoScaleYaxis: true
                },
                toolbar: {
                    tools: {
                        download: true,
                        selection: true,
                        zoom: true,
                        zoomin: false,
                        zoomout: false,
                        pan: true,
                        reset: true
                    },
                }
            },
            colors: this.salesAnalyticData.colors,
            dataLabels: {
                enabled: false
            },
            grid: {
                borderColor: '#f1f1f1',
                strokeDashArray: 3
            },
            stroke: {
                curve: 'smooth',
                width: [2, 2, 2],
                dashArray: [0, 0, 5]
            },
            xaxis: {
                axisTicks: {
                    show: false,
                },
                categories: this.salesAnalyticData.categories
            },
            yaxis: {
                labels: {
                    formatter: (value) => "Rp" + this.helper.readableNumber(value)
                },
            },
            tooltip: {
                y: [
                    {
                        formatter: (value) => "Rp" + this.helper.readableNumber(value)
                    }, 
                    {
                        formatter: (value) => "Rp" + this.helper.readableNumber(value)
                    }, 
                    {
                        formatter: (value) => "Rp" + this.helper.readableNumber(value)
                    }
                ]
            },
            legend: {
                show: true,
                position: "bottom",
                offsetX: 0,
                offsetY: 8,
                markers: {
                    size: 4,
                    strokeWidth: 0,
                    strokeColor: '#fff',
                },
            },
            title: {
                align: 'left',
                style: {
                    fontFamily: "Poppins, sans-serif",
                    fontSize: '.8125rem',
                    fontWeight: 'semibold',
                    color: '#8c9097'
                },
            },
            markers: {
                hover: {
                    sizeOffset: 5
                }
            }
        }

        this.salesAnalytic = new ApexCharts(document.querySelector("#sales-analytic"), options)
        this.salesAnalytic.render()
    }

    initActivity() {
        this._refreshActivity = this.get("activity-refresh")
        this._refreshActivity?.on("click", () => this.activityRefresh(), "SalesDashboardSummary")

        this.activiyUpcoming = document.querySelector('#activity-upcoming')
        this.activiyTodo     = document.querySelector('#activity-todo')
        this.activiyRecent   = document.querySelector('#activity-recent')
    }

    initTopSales() {
        this._refreshTopSales = this.get("top-sales-refresh")
        this._refreshTopSales?.on("click", () => this.topSalesRefresh(), "SalesDashboardSummary")

        this.topSales = document.querySelector("#top-sales")
    }

    initTopCustomer() {
        this._refreshTopCustomer = this.get("top-customer-refresh")
        this._refreshTopCustomer?.on("click", () => this.topCustomerRefresh(), "SalesDashboardSummary")

        this.topCustomer = document.querySelector("#top-customer")
    }

    /**
     * @param {*} data
     */
    async refresh(data) {
        await Promise.all([
            this._refreshMetric(this.totalRevenue, data.total_revenue),
            this._refreshMetric(this.outstandingInvoice, data.outstanding_invoice),
            this._refreshMetric(this.totalSales, data.total_sales),
            this._refreshMetric(this.opportunityClosedWon, data.opportunity_closed_won),
            this._refreshMetric(this.leadConversion, data.lead_conversion),
            this._refreshMetric(this.winRate, data.win_rate),
            this._refreshMetric(this.pipelineForecast, data.pipeline_forecast),
            this.salesAnalyticRefresh(data.sales_analytic),
            this.pipelineOpportunityRefresh(data.opportunity_pipeline),
            this.activityRefresh(data.activity),
            this.topSalesRefresh(data.top_sales),
            this.topCustomerRefresh(data.top_customer)
        ])
    }

    /**
     * @param {import("@core-js/solaris/metric-dashboard").default} metric
     * @param {{value: string, change: {value: string, type: string|null, title: string}, chart: Array}|null} data
     */
    _refreshMetric(metric, data) {
        if (!metric || !data) return null
        metric.setValue(data.value)
        metric.setChange(data.change)
        return metric.setChart(data.chart)
    }

    /**
     * @param {[{name: string, color: string, value: number}]} data 
     */
    async pipelineOpportunityRefresh(data = null) {
        if(!data) {
            const req = await this.axios({
                method: "POST",
                url   : `${BASE_URL}/sales/dashboard/opportunity-pipeline`,
                data  : {
                    period: this._period
                }
            })

            data = req.data
        }

        this.opportunityPipeline?.updateData(data)
    }

    /**
     * @param {{series: [{name: string, data: [number]}], categories: [string], colors: [string]} data 
     */
    async salesAnalyticRefresh(data = null) {
        if(!data) {
            const req = await this.axios({
                method: "POST",
                url   : `${BASE_URL}/sales/dashboard/sales-analytic`,
                data  : {
                    period: this._period
                }
            })

            data = req.data
        }

        this.salesAnalytic?.updateSeries(data.series)
        this.salesAnalytic?.updateOptions({
            xaxis: {
                categories: data.categories,
                colors    : data.colors
            }
        })
    }

    /**
     * @param {{upcoming: [], todo: [], recent: []}} data 
     */
    async activityRefresh(data = null) {
        if(!data) {
            const req = await this.axios({
                method: "POST",
                url   : `${BASE_URL}/sales/dashboard/activity`
            })

            data = req.data
        }

        let upcoming = ""
        let todo     = ""
        let recent   = ""

        data.upcoming.forEach(item => upcoming += this._renderActivity(
            item.subject, 
            item.category.name, 
            item.priority.name, 
            item.recent, 
            item.color, 
            item.icon
        ))
        
        data.todo.forEach(item => todo += this._renderActivity(
            item.subject, 
            item.category.name, 
            item.priority.name, 
            item.recent, 
            item.color, 
            item.icon
        ))
        
        data.recent.forEach(item => recent += this._renderActivity(
            item.subject, 
            item.category.name, 
            item.priority.name, 
            item.recent, 
            item.color, 
            item.icon
        ))

        if(this.activiyUpcoming) {
            this.activiyUpcoming.innerHTML = upcoming
        }

        if(this.activiyTodo) {
            this.activiyTodo.innerHTML = todo
        }

        if(this.activiyRecent) {
            this.activiyRecent.innerHTML = recent
        }
    }

    /**
     * @param {{user_id: string, user_name: string, user_email: string, avatar: ?string, total_opportunity_amount: number, total_opportunity: string}} data
     */
    async topSalesRefresh(data = null) {
        if(!data) {
            const req = await this.axios({
                method: "POST",
                url   : `${BASE_URL}/sales/dashboard/top-sales`,
                data  : {
                    period: this._period
                }
            })

            data = req.data
        }

        let topSales = ""
        data.forEach(item => topSales += this._renderTopSales(
            item.user_id,
            item.user_name,
            item.user_email,
            item.avatar,
            item.total_opportunity_amount,
            item.total_opportunity
        ))

        if(this.topSales) {
            this.topSales.innerHTML = topSales
            this.topSales.querySelectorAll('[solar-ui="numeral"]').forEach(el => new Numeral(el))
        }
    }

    /**
     * @param {{account_id: string, account_name: string, primary_contact: string, avatar: ?string, total_invoice_amount: number, total_invoice: string}} data
     */
    async topCustomerRefresh(data = null) {
        if(!data) {
            const req = await this.axios({
                method: "POST",
                url   : `${BASE_URL}/sales/dashboard/top-customer`,
                data  : {
                    period: this._period
                }
            })

            data = req.data
        }

        let topCustomer = ""
        data.forEach(item => topCustomer += this._renderTopCustomer(
            item.account_id,
            item.account_name,
            item.primary_contact,
            item.avatar,
            item.total_invoice_amount,
            item.total_invoice
        ))

        if(this.topCustomer) {
            this.topCustomer.innerHTML = topCustomer
            this.topCustomer.querySelectorAll('[solar-ui="numeral"]').forEach(el => new Numeral(el))
        }
    }

    /**
     * @param {string} subject 
     * @param {string} category 
     * @param {string} priority 
     * @param {string} recent 
     * @param {string} color 
     * @param {string} icon 
     * @returns {string}
     */
    _renderActivity(subject, category, priority, recent, color, icon) {
        return `<li class="ecommerce-recent-activity-content">
            <div class="d-flex align-items-top">
                <div class="me-3">
                    <span class="avatar avatar-sm bg-${color} avatar-rounded">
                        <i class="${icon}"></i>
                    </span>
                </div>
                <div class="activity-content">
                    <span class="d-block fw-medium">${subject}</span>
                    <span class="d-block fs-12 text-muted">${category} (${priority})</span>
                </div>
                <div class="flex-fill text-end">
                    <span class="d-block text-muted fs-11 op-7">${recent}</span>
                </div>
            </div>
        </li>`
    }

    /**
     * @param {string} id
     * @param {number} amount
     * @param {string} prefix
     * @returns {string}
     */
    _renderNumeral(id, amount, prefix = 'Rp ') {
        const readable = this.helper.readableNumber(amount)
        const full     = this.helper.readableNumber(amount, 2, ',', '.', false)

        return `<span id="${id}" solar-ui="numeral" decimals="2" decimal-separator="," thousand-separator=".">
            <span class="numeral-prefix">${prefix}</span>
            <span class="numeral-readable">${readable}</span>
            <span class="numeral-full d-none">${full}</span>
        </span>`
    }

    /**
     * @param {string} userId
     * @param {string} name
     * @param {string} email
     * @param {?string} avatar
     * @param {number} opportunityAmount
     * @param {string} totalOpportunity
     * @returns {string}
     */
    _renderTopSales(userId, name, email, avatar, opportunityAmount, totalOpportunity) {
        return `<li class="list-group-item">
            <div class="d-flex align-items-center gap-2">
                <div class="lh-1">
                    <span class="avatar avatar-md avatar-rounded ${avatar ? "" : "bg-secondary"}">
                        ${avatar ? `<img src="${BASE_URL}/core/images/thumbnail/${avatar}">` : this.helper.getInitialName(name)}
                    </span>
                </div>
                <div class="flex-fill">
                    <span class="d-block fw-medium">${name}</span>
                    <span class="fs-12 text-muted">${email}</span>
                </div>
                <div class="d-flex flex-column align-items-end gap-1">
                    <div class="fw-medium">${this._renderNumeral(`top-sales-${userId}-amount`, opportunityAmount)}</div>
                    <span class="fs-12 text-muted">${totalOpportunity} closed won</span>
                </div>
            </div>
        </li>`
    }

    /**
     * @param {string} accountId
     * @param {string} name
     * @param {string} primaryContact
     * @param {?string} avatar
     * @param {number} totalInvoiceAmount
     * @param {string} totalInvoice
     * @returns {string}
     */
    _renderTopCustomer(accountId, name, primaryContact, avatar, totalInvoiceAmount, totalInvoice) {
        return `<li class="list-group-item">
            <div class="d-flex align-items-center gap-2">
                <div class="lh-1">
                    <span class="avatar avatar-md avatar-rounded ${avatar ? "" : "bg-secondary"}">
                        ${avatar ? `<img src="${BASE_URL}/core/images/thumbnail/${avatar}">` : this.helper.getInitialName(name)}
                    </span>
                </div>
                <div class="flex-fill">
                    <span class="d-block fw-medium">${name}</span>
                    <span class="fs-12 text-muted">${primaryContact}</span>
                </div>
                <div class="d-flex flex-column align-items-end gap-1">
                    <div class="fw-medium">${this._renderNumeral(`top-customer-${accountId}-amount`, totalInvoiceAmount)}</div>
                    <span class="fs-12 text-muted">${totalInvoice} closed won</span>
                </div>
            </div>
        </li>`
    }
}