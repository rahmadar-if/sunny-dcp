import SalesDashboardPage from "./page"

export default new SalesDashboardPage()