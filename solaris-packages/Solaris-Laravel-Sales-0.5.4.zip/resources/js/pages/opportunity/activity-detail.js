import ActivityDetail from "@master-data-js/pages/activity/detail";

export default class OpportunityActivityDetail extends ActivityDetail {
    init() {
        super.init()
    }
}