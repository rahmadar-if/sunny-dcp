import SolarListDetail from "@core-js/solaris/solar/solar-list-detail";

export default class OpportunityOrderDetail extends SolarListDetail {
    init() {
        super.init()
    }
}
