import Filter from "@core-js/solaris/filter/filter"
import SolarEditPage from "@core-js/solaris/solar/solar-edit-page"
import OpportunityHelper from "./opportunity-helper"
import OpportunityProductDetail from "./product-detail"
import OpportunityActivityDetail from "./activity-detail"
import OpportunityStatusHistoryDetail from "./status-history-detail"
import OpportunityTeamDetail from "./team-detail"
import OpportunityContactDetail from "./contact-detail"
import OpportunityCompetitorDetail from "./competitor-detail"
import OpportunityTermConditionDetail from "./term-condition-detail"
import OpportunityQuotationHistoryDetail from "./quotation-history-detail"
import OpportunityOrderDetail from "./order-detail"
import FileHelper from "@core-js/solaris/file-helper"
import { OpportunityStatus } from "@sales-js/const"

export default class OpportunityPage extends SolarEditPage {
    init() {
        this.initForm()
        this.initProfileCustomer()
        this.initProfileDecisionMaker()
        this.initPrintQuotation()
        this.initCreateOrder()

        this.registerDetail("opportunity-product", OpportunityProductDetail, "opportunity_id")
        this.registerDetail("opportunity-activity", OpportunityActivityDetail, "opportunity_id")
        this.registerDetail("opportunity-status-history", OpportunityStatusHistoryDetail, "opportunity_id")
        this.registerDetail("opportunity-team", OpportunityTeamDetail, "opportunity_id")
        this.registerDetail("opportunity-contact", OpportunityContactDetail, "opportunity_id")
        this.registerDetail("opportunity-competitor", OpportunityCompetitorDetail, "opportunity_id")
        this.registerDetail("opportunity-term-condition", OpportunityTermConditionDetail, "opportunity_id")
        this.registerDetail("opportunity-quotation-history", OpportunityQuotationHistoryDetail, "opportunity_id")
        this.registerDetail("opportunity-order", OpportunityOrderDetail, "opportunity_id")
    }

    // #region Lifecycle

    initForm() {
        const name = this.form.get("name")
        name?.on('input', (value) => this.breadcrumbName.innerText = value, "OpportunityPage")

        this.form.get("status_id")?.on("change", (value) => {
            const statusId = value?.id ?? value
            const status   = OPPORTUNITY_STATUS.find(status => status.id == statusId)
            if (status) {
                this._updateProbability(status.probability ?? 0, status.color)
            }
        }, "OpportunityPage")

        this.form.exclude("days_in_funnel")

        this.form.addValidation("customer_id", (value) => {
            const hasValue = !this.helper.isEmpty(value)
            const labelEl  = document.getElementById('opportunity-customer-label')
            const errorEl  = document.getElementById('opportunity-customer-error')

            labelEl?.classList.toggle('text-muted', hasValue)
            labelEl?.classList.toggle('text-danger', !hasValue)
            errorEl?.classList.toggle('d-none', hasValue)

            return { success: hasValue, message: "Customer is required." }
        })
    }

    initDetail() {
        this.opportunityProduct
            ?.on("saved", () => this.refreshForm(), "OpportunityPage")
            .on("deleting", async (row, data) => await this._onSavingDetail(), "OpportunityPage")
            .on("deleted", () => this.refreshForm(), "OpportunityPage")
    }

    // #endregion

    // #region Profile — Customer

    initProfileCustomer() {
        const lookup = this.get('opportunity-customer-lookup')

        this.get('opportunity-customer-change-btn')?.on('click', () => lookup?.open())

        this.get('opportunity-customer-clear-btn')?.on('click', () => {
            this.form.set("customer_id", null)
            this._setEntityDisplay('customer', null, '#', '')
        })

        lookup?.on('choose', (selection, rows) => {
            const chosen = rows[0]
            if (!chosen) return

            this.form.set("customer_id", chosen.id)
            this._setEntityDisplay('customer', chosen, `${BASE_URL}/master-data/account/${chosen.id}`, chosen.industry?.name ?? '')

            this.form.get("phone")?.set(chosen.primary_phone ?? '')
            this.form.get("email")?.set(chosen.email ?? '')

            document.getElementById('opportunity-customer-label')?.classList.replace('text-danger', 'text-muted')
            document.getElementById('opportunity-customer-error')?.classList.add('d-none')
        })
    }

    // #endregion

    // #region Profile — Decision Maker

    initProfileDecisionMaker() {
        const lookup = this.get('opportunity-dm-lookup')

        this.get('opportunity-dm-change-btn')?.on('click', () => {
            const customerId = this.form.get("customer_id")?.get()
            if (customerId) {
                const filter = new Filter()
                filter.and("account_id", customerId)
                lookup?.open(filter)
            } else {
                lookup?.open()
            }
        })

        this.get('opportunity-dm-clear-btn')?.on('click', () => {
            this.form.set("decision_maker_id", null)
            this._setEntityDisplay('dm', null, '#', '')
        })

        lookup?.on('choose', (selection, rows) => {
            const chosen = rows[0]
            if (!chosen) return

            this.form.set("decision_maker_id", chosen.id)
            this._setEntityDisplay('dm', chosen, `${BASE_URL}/master-data/contact/${chosen.id}`, chosen.job_title ?? '')
        })
    }

    // #endregion

    // #region Print Quotation

    initPrintQuotation() {
        this.printQuotationBtn = this.get('opportunity-print-quotation-btn')
        this.printQuotationBtn?.on('click', () => this._printQuotation())
    }

    /**
     * @returns {Promise<void>}
     */
    async _printQuotation() {
        this.printQuotationBtn?.disabled()
        this.helper.loadingPage(true)

        try {
            await FileHelper.downloadFile(`${BASE_URL}/sales/opportunity/print-quotation/${this.id}`, "POST", {
                headers: { Accept: "application/pdf" }
            })
            this.opportunityQuotationHistory?.refresh()
        } catch (error) {
            if (!error?.response) {
                this.helper.errorAlert({ title: "Print failed", message: error })
            }
        } finally {
            this.helper.loadingPage(false)
            this.printQuotationBtn?.enabled()
        }
    }

    // #endregion

    // #region Create Order

    initCreateOrder() {
        this.createOrderBtn = this.get('opportunity-create-order-btn')
        this.createOrderBtn?.on('click', async () => {
            this.createOrderBtn?.disabled()
            await OpportunityHelper.createOrder(this.id)
            this.createOrderBtn?.enabled()
        })
    }

    // #endregion

    // #region Events

    async success(response) {
        this.opportunityStatusHistory?.refresh()

        const status = this.form.get("status_id")
        if(status.get()?.id == OpportunityStatus.ClosedWon) {
            this.createOrderBtn.enabled()
        } else {
            this.createOrderBtn.disabled()
        }
    }

    async onRefreshed(data) {
        this.breadcrumbName.textContent = data.name

        this._setEntityDisplay(
            'customer',
            data.customer,
            data.customer ? `${BASE_URL}/master-data/account/${data.customer.id}` : '#',
            data.customer?.industry?.name ?? ''
        )

        this._setEntityDisplay(
            'dm',
            data.decision_maker,
            data.decision_maker ? `${BASE_URL}/master-data/contact/${data.decision_maker.id}` : '#',
            data.decision_maker?.job_title ?? ''
        )

        this._updateProbability(data.status?.probability ?? 0, data.status?.color)

        const daysInFunnel = data.status?.is_final_stage
            ? data.days_in_funnel
            : this._calcDaysInFunnel(this.form.get("date")?.get())
        this.form.get("days_in_funnel")?.set(daysInFunnel)

        if (data.status?.id == OpportunityStatus.ClosedWon) {
            this.createOrderBtn?.enabled()
        } else {
            this.createOrderBtn?.disabled()
        }
    }

    // #endregion

    // #region Helpers

    /**
     * @param {'customer'|'dm'} type
     * @param {Object|null} entity
     * @param {string} url
     * @param {string} subText
     */
    _setEntityDisplay(type, entity, url, subText) {
        const avatar   = document.getElementById(`opportunity-${type}-avatar`)
        const link     = document.getElementById(`opportunity-${type}-link`)
        const name     = document.getElementById(`opportunity-${type}-name`)
        const sub      = document.getElementById(`opportunity-${type}-sub`)
        const clearBtn = document.getElementById(`opportunity-${type}-clear-btn`)

        if (avatar) {
            const pictureId = entity?.profile_picture_id ?? entity?.profile_picture?.id
            const bgColor   = type === 'customer' ? 'bg-primary' : 'bg-info'

            avatar.classList.remove('bg-primary', 'bg-info', 'bg-secondary')

            if (pictureId) {
                avatar.innerHTML = `<img src="${BASE_URL}/core/images/thumbnail/${pictureId}" alt="" class="w-100 h-100 object-fit-cover">`
            } else {
                avatar.classList.add(entity ? bgColor : 'bg-secondary')
                avatar.innerHTML = `<span class="fs-13 fw-semibold text-white">${(entity?.name ?? '?')[0].toUpperCase()}</span>`
            }
        }

        if (name) {
            name.textContent = entity?.name ?? '—'
            name.classList.toggle('text-dark', !!entity)
            name.classList.toggle('text-muted', !entity)
        }

        if (sub) {
            sub.textContent = entity ? subText : ''
        }

        if (link) {
            link.href = entity ? url : '#'
        }

        if (clearBtn) {
            if (entity) {
                clearBtn.removeAttribute('disabled')
            } else {
                clearBtn.setAttribute('disabled', 'true')
            }
        }
    }

    /**
     * @param {Date} date
     * @returns {number}
     */
    _calcDaysInFunnel(date) {
        if (!date) {
            return 0
        }

        const start = new Date(date.getTime())
        start.setHours(0, 0, 0, 0)

        const today = new Date()
        today.setHours(0, 0, 0, 0)

        return Math.max(0, Math.round((today - start) / 86400000))
    }

    /**
     * @param {number} probability
     * @param {string|null} color
     */
    _updateProbability(probability, color) {
        const fill = document.getElementById('opportunity-probability-fill')
        const text = document.getElementById('opportunity-probability-text')

        if (fill) {
            fill.style.width = `${probability}%`
            fill.className = `progress-bar bg-${color}`
        }

        if (text) {
            text.textContent = `${probability}%`
        }
    }

    // #endregion
}
