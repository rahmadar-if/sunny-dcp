import Helper from "@core-js/solaris/helper"
import axios from "@core-js/libs/axios"

export default class OpportunityHelper {

	// #region Static

	/**
	 * @param {string} id
	 * @param {Function} [onSuccess]
	 * @returns {Promise<void>}
	 */
	static async createOrder(id, onSuccess) {
		if (!await Helper.confirm({ title: "Are you sure?", message: "This Opportunity will be converted into an Order." })) {
			return
		}

		Helper.loadingPage(true)
		try {
			const req = await axios({
				method: "POST",
				url   : `${BASE_URL}/sales/opportunity/create-order/${id}`
			})
			const res = req.data
			if (!res.success) {
				throw res.message
			}

			const openOrder = await Helper.confirm({ title: "Order created successfully", message: "Do you want to open the Order page?" })
			if (openOrder) {
				window.location = `${BASE_URL}/sales/order/edit/${res.data.id}`
			}

			onSuccess?.()
		} catch (error) {
			console.error({ error })
			if (!error?.response) {
				Helper.errorAlert({ title: "Oops! There was an error", message: error })
			}
		} finally {
			Helper.loadingPage(false)
		}
	}

	// #endregion
}
