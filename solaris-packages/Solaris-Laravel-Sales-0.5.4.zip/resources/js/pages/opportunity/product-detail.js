import Filter from "@core-js/solaris/filter/filter";
import SolarListDetail from "@core-js/solaris/solar/solar-list-detail";

export default class OpportunityProductDetail extends SolarListDetail {
    init() {
        this.initModal()

        this.columnRender("product_id", this.productColumnRender.bind(this))
        this.columnRender("price", this.priceColumnRender.bind(this))
        this.columnRender("disc", this.discColumnRender.bind(this))
        this.columnRender("total", this.totalColumnRender.bind(this))
    }

    initModal() {
        const product       = this.form.get("product_id")
        const price         = this.form.get("price")
        const qty           = this.form.get("qty")
        const amount        = this.form.get("amount")
        const discount      = this.form.get("disc")
        const discPercent   = this.form.get("disc_percent")
        const total         = this.form.get("total")
        const unitOfMeasure = this.form.get("unit_of_measure")

        product?.init({
            param: (param) => {
                const filter = new Filter()
                filter.and("active", true)
                param.filter = filter.get()
                return param
            },
            optionsTemplate: (item) => {
                const initials   = item.name.split(' ').slice(0, 2).map(w => w[0]).join('').toUpperCase()
                const avatarHtml = item.product_picture_id
                    ? `<img src="${BASE_URL}/core/images/thumbnail/${item.product_picture_id}" alt="">`
                    : initials
                const avatarBg   = item.product_picture_id ? '' : 'bg-secondary'
                const stockClass = item.availability > 0 ? 'success' : 'danger'
                const meta       = [item.category, item.brand, `Rp ${this.helper.numberToCurrency(item.price ?? 0)}`].filter(Boolean).join(' · ')

                return `<div class="d-flex align-items-center gap-2 py-1">
                    <span class="avatar avatar-sm avatar-rounded ${avatarBg}">${avatarHtml}</span>
                    <div class="flex-grow-1 lh-1">
                        <div class="fw-semibold">${item.name}</div>
                        <small class="text-muted">${meta}</small>
                    </div>
                    <span class="badge bg-${stockClass}-transparent text-${stockClass}">Stock: ${item.availability ?? 0}</span>
                </div>`
            },
            selectionTemplate: (item) => {
                const initials   = item.name.split(' ').slice(0, 2).map(w => w[0]).join('').toUpperCase()
                const avatarHtml = item.product_picture_id
                    ? `<img src="${BASE_URL}/core/images/thumbnail/${item.product_picture_id}" alt="">`
                    : initials
                const avatarBg   = item.product_picture_id ? '' : 'bg-secondary'
                const meta       = [item.category, item.brand].filter(Boolean).join(' · ')

                return `<div class="d-flex align-items-center gap-2">
                    <span class="avatar avatar-sm avatar-rounded ${avatarBg}">${avatarHtml}</span>
                    <div class="lh-1">
                        <div class="fw-semibold">${item.name}</div>
                        ${meta ? `<small class="text-muted">${meta}</small>` : ''}
                    </div>
                </div>`
            }
        })

        const getAmount = () => (price?.get() ?? 0) * (qty?.get() ?? 0)

        const calculateAmount = () => {
            const amountVal = getAmount()
            
            amount?.set(amountVal)
            total?.set(amountVal - (discount?.get() ?? 0))
        }

        product?.on("change", (value) => {
            price?.set(value ? value.price : 0)
            unitOfMeasure?.set(value ? (value.unit_of_measure ?? '') : '')
        }, "OpportunityProductDetail")

        price?.on("input", this.helper.debounce(() => calculateAmount(), 300), "OpportunityProductDetail")
        qty?.on("input",   this.helper.debounce(() => calculateAmount(), 300), "OpportunityProductDetail")

        discount?.on("input", this.helper.debounce(() => {
            const amountVal = getAmount()
            const discVal   = discount?.get() ?? 0
            discPercent?.set(amountVal > 0 ? Math.round(discVal / amountVal * 100 * 100) / 100 : 0)
            calculateAmount()
        }, 300), "OpportunityProductDetail")

        discPercent?.on("input", this.helper.debounce(() => {
            const amountVal = getAmount()
            const pct       = discPercent?.get() ?? 0
            discount?.set(Math.round(amountVal * pct / 100 * 100) / 100)
            calculateAmount()
        }, 300), "OpportunityProductDetail")

        this.modal.on("show", () => {
            if (this.form.isEdit()) {
                const amountVal = getAmount()
                const discVal   = discount?.get() ?? 0
                discPercent?.set(amountVal > 0 ? Math.round(discVal / amountVal * 100 * 100) / 100 : 0)
                calculateAmount()

                console.log(product?.get())

                unitOfMeasure?.set(product?.get()?.unit_of_measure ?? '')
            } else {
                discPercent?.set(null, false)
                unitOfMeasure?.set(null, false)
            }
        }, "OpportunityProductDetail")

        this.form.exclude(["amount", "disc_percent", "unit_of_measure"])
    }

    productColumnRender(data, rowData) {
        const initialName = this.helper.getInitialName(data)
        return `<div class="d-flex align-items-center gap-2">
            <div class="lh-1">
                <span class="avatar avatar-rounded avatar-sm ${!rowData.product.product_picture_id ? "bg-secondary" : ""}">
                    ${rowData.product.product_picture_id ? `<img src="${BASE_URL}/core/images/thumbnail/${rowData.product.product_picture_id}" alt="">` : initialName}
                </span>
            </div>
            <div>
                <a class="text-decoration-underline" href="${BASE_URL}/master-data/product/${rowData.product_id}">${data}</a>
            </div>
        </div>`
    }

    priceColumnRender(data, rowData) {
        return `Rp ${this.helper.numberToCurrency(data ?? 0)}`
    }

    discColumnRender(data, rowData) {
        const amount  = (rowData.price ?? 0) * (rowData.qty ?? 0)
        const discPct = amount > 0 ? Math.round((data ?? 0) / amount * 100 * 100) / 100 : 0

        if (discPct > 0) {
            return `<div class="d-flex align-items-center gap-2">
                <span>Rp ${this.helper.numberToCurrency(data ?? 0)}</span>
                <span class="badge bg-danger-transparent text-danger">- ${discPct}%</span>
            </div>`
        }
        return `Rp ${this.helper.numberToCurrency(data ?? 0)}`
    }

    totalColumnRender(data, rowData) {
        return `Rp ${this.helper.numberToCurrency(data ?? 0)}`
    }
}
