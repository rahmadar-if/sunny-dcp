import SolarListDetail from "@core-js/solaris/solar/solar-list-detail";

export default class OpportunityCompetitorDetail extends SolarListDetail {
    init() {
        this.columnRender("total_amount", this.totalAmountColumnRender.bind(this))
        
        this.columnRender("strength", this.strengthColumnRender.bind(this))
        this.columnCreated("strength", this.strengthColumnCreated.bind(this))

        this.columnRender("weakness", this.weaknessColumnRender.bind(this))
        this.columnCreated("weakness", this.weaknessColumnCreated.bind(this))
    }

    totalAmountColumnRender(data, rowData) {
        return `Rp ${this.helper.numberToCurrency(data ?? 0)}`
    }

    strengthColumnRender(data, rowData) {
       return `<span class="d-inline-block text-truncate align-middle" title="Click to expand" style="max-width: 15rem;">${data ?? ''}</span>`
    }

    strengthColumnCreated(row, cell, cellData, rowData) {
        const span = cell.children[0]
        span.addEventListener("click", () => {
            span.classList.toggle("d-inline-block")
            span.classList.toggle("text-truncate")
        })
    }

    weaknessColumnRender(data, rowData) {
       return `<span class="d-inline-block text-truncate align-middle" title="Click to expand" style="max-width: 15rem;">${data ?? ''}</span>`
    }

    weaknessColumnCreated(row, cell, cellData, rowData) {
        const span = cell.children[0]
        span.addEventListener("click", () => {
            span.classList.toggle("d-inline-block")
            span.classList.toggle("text-truncate")
        })
    }
}