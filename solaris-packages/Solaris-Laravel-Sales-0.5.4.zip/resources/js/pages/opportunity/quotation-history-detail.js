import SolarListDetail from "@core-js/solaris/solar/solar-list-detail";
import Helper from "@core-js/solaris/helper";

export default class OpportunityQuotationHistoryDetail extends SolarListDetail {
    init() {
    }

    // #region Table Actions

    /**
     * @param {HTMLTableRowElement} row
     * @param {HTMLTableCellElement} cell
     * @param {Object} rowData
     * @returns {void}
     */
    onActionCreated(row, cell, rowData) {
        if (!rowData.attachment_id) {
            return
        }

        this.actionPrepend(row, {
            selector: "download-action",
            label: "Download",
            icon: "ri-download-2-line",
            callback: () => this.download(rowData.attachment_id)
        })
    }

    // #endregion

    // #region Helpers

    /**
     * @param {string} attachmentId
     * @returns {Promise<void>}
     */
    async download(attachmentId) {
        await Helper.downloadFile(`${BASE_URL}/core/attachment/download/${attachmentId}`)
    }

    // #endregion
}
