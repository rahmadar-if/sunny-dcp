import Filter from "@core-js/solaris/filter/filter";
import SolarListPage from "@core-js/solaris/solar/solar-list-page";
import ActivityAction from "@base-crm-js/helper/activity-action";
import AcitivityModal from "@master-data-js/pages/activity/modal";
import DateHelper from "@core-js/solaris/date-helper";
import { OpportunityStatus } from "../../const";
import LookupInput from "@core-js/solaris/form/lookup-input";
import Numeral from "@core-js/solaris/numeral";
import axios from "@core-js/libs/axios";
import OpportunityHelper from "./opportunity-helper";

export default class OpportunityListPage extends SolarListPage {
    init() {
        this.initModal()
        this.initKanban()
        this.initMetric()
        this.initQuickFilter()
        this.initTab()

        this.activityModal     = new AcitivityModal()
        this.updateStatusModal = this.get("opportunity-update-status-modal_ModalForm")
        this.updateStatusModal.form.on("success", () => this.refresh())

        ActivityAction.getActivityCategory().then(res => this.activityCategories = res)

        this.columnRender("date", this.nameColumnRender.bind(this))
        this.columnRender("phone", this.phoneEmailColumnRender.bind(this))
        this.columnRender("status_id", this.statusColumnRender.bind(this))
        this.columnRender("customer_id", this.customerColumnRender.bind(this))
        this.columnRender("total_amount", this.amountColumnRender.bind(this))
        this.columnRender("lead_id", this.leadColumnRender.bind(this))
        this.columnRender("customer_need", this.customerNeedColumnRender.bind(this))
        this.columnCreated("customer_need", this.customerNeedColumnCreated.bind(this))
    }

    initModal() {
        if(!this.hasModalForm()) {
            return
        }

        const account = this.form.get("customer_id")
        const contact = this.form.get("decision_maker_id")
        contact?.init({
            param: (param) => {
                const filter    = new Filter()
                const accountId = account?.get()?.id
                if(accountId) {
                    filter.and("account_id", accountId)
                    param.filter = filter.get()
                }

                return param
            }
        })

        this.modal?.on("show", () => {
            if(this.form.isEdit()) {
                return
            }

            this.form.set('date', new Date())
        }, "OpportunityListPage")

        account?.on("change", (value) => {
            const contactVal = contact?.get()
            if(!value || (contactVal && value && contactVal.account?.id != value.id)) {
                contact.set(null)
            }

            if(value && !contactVal) {
                this.form.set("phone", value.primary_phone)
                this.form.set("email", value.email)

                if(value.primary_contact) {
                    contact?.set(value.primary_contact)
                }
            }
        }, "OpportunityListPage")

        contact?.on("change", (value) => {
            const accountVal = account?.get()
            if(value && value.account && !accountVal) {
                account.set(value.account)
            }
        }, "OpportunityListPage")

        this.form.addValidation("phone", (value) => {
            const email = this.form.getValue("email")
            const valid = !this.helper.isEmpty(value) || !this.helper.isEmpty(email)
            return { success: valid, message: "Phone or email is required. Please fill at least one." }
        })

        this.form.addValidation("email", (value) => {
            const phone = this.form.getValue("phone")
            const valid = !this.helper.isEmpty(value) || !this.helper.isEmpty(phone)
            return { success: valid, message: "Phone or email is required. Please fill at least one." }
        })

        this.form.addValidation("customer_need", (value) => {
            if (this.helper.isEmpty(value)) {
                return { success: true, message: null }
            }
            const valid = value.trim().length >= 10
            return { success: valid, message: "Customer need must be at least 10 characters." }
        })
    }

    initKanban() {
        this._refreshTimer  = null
        this._resizeTimer   = null
        this._kanbanSummary = {}

        this.kanban = this.get(`${this.id}_kanban`)
        this.kanban
            ?.off("edit", null, "SolarUI")
            .on("edit", this.kanbanEdit.bind(this), "OpportunityListPage")
            .on("card render", this.kanbanCardRender.bind(this), "OpportunityListPage")
            .on("card moved", this.kanbanCardMoved.bind(this), "OpportunityListPage")
            .on("before-move", (card, data, boardIds) => this._beforeKanbanMove(card, data, boardIds), "OpportunityListPage")
            .on("ready", () => this._adjustKanbanHeight(), "OpportunityListPage")
            .on("fetching", this.kanbanFetchSummary.bind(this), "OpportunityListPage")
            .on("board created", (boardId) => this.kanbanApplySummary(boardId), "OpportunityListPage")
            .on("board updated", (boardId) => this.kanbanApplySummary(boardId), "OpportunityListPage")
            .on("deleted", this.kanbanDeleted.bind(this), "OpportunityListPage")

        this.modalForm?.form.on("success", this.kanbanFormSuccess.bind(this), "OpportunityListPage")

        window.addEventListener('resize', () => {
            clearTimeout(this._resizeTimer)
            this._resizeTimer = setTimeout(() => this._adjustKanbanHeight(), 100)
        })
    }

    initMetric() {
        this.metrics = {
            total_opportunity:       this.get("opportunity_total_metric"),
            total_amount:            this.get("opportunity_amount_metric"),
            total_closed_won:        this.get("opportunity_closed_won_metric"),
            total_closed_won_amount: this.get("opportunity_closed_won_amount_metric"),
            total_progress:          this.get("opportunity_progress_metric"),
        }

        Object.values(this.metrics).forEach(metric => metric?.load())
    }

    initQuickFilter() {
        /** @type { LookupInput } */
        this.statusFilter = new LookupInput("div[solar-id='opportunity_status_filter']")

        /** @type { LookupInput } */
        this.ownerFilter = new LookupInput("div[solar-id='opportunity_owner_filter']")
    }

    /**
     * Metric values follow the table filter, so they are refreshed on every draw.
     * @returns {Promise<void>}
     */
    async refreshMetric() {
        try {
            const req = await axios({
                method: "POST",
                url: `${BASE_URL}/sales/opportunity/list-summary`,
                data: this.table.getParamData()
            })

            Object.entries(this.metrics).forEach(([key, metric]) => {
                if (!metric) {
                    return
                }

                metric.setValue(req.data[key] ?? 0)
                metric.unload()
            })
        } catch (error) {
            console.error("Failed to fetch opportunity list summary.", { error })
        }
    }

    initTab() {
        const key    = `${this.id}_active_tab`
        const cached = localStorage.getItem(key)

        document.querySelectorAll(`#${this.id}_nav button.nav-link`).forEach(btn => {
            const target = btn.getAttribute("data-bs-target")?.replace(/^#/, "")
            if (!target) {
                return
            }

            if (cached === target) {
                if (typeof bootstrap !== "undefined" && bootstrap.Tab) {
                    bootstrap.Tab.getOrCreateInstance(btn).show()
                } else {
                    btn.click()
                }
            }

            btn.addEventListener("click", () => localStorage.setItem(key, target))
        })
    }

    rendering() {
        this.kanban?.render()
    }

    async draw(e, settings) {
        await this.refreshMetric()
    }

    async ready(settings, json) {
        this.statusFilter?.enabled()
        this.ownerFilter?.enabled()

        this.statusFilter?.on("change", (val) => {
            this.table.filter("status", val ? new Filter().andIn("status_id", val.map(i => i.id)) : null)
        })

        this.ownerFilter?.on("change", (val) => {
            this.table.filter("created_by", val ? new Filter().and("created_by_id", val.id) : null)
        })

        await this.refreshMetric()
    }

    async deleted(data) {
        this.kanban?.refresh(data.status_id, true)
    }

    openEditPage(id) {
        this.helper.loadingPage(true)
        window.location = `${BASE_URL}/sales/opportunity/edit/${id}`
    }

    async edit(row, data) {
        this.openEditPage(data.id)
    }

    rowDoubleClick(row, data) {
        this.openEditPage(data.id)
    }

    // #region Column Renders

    /**
     * @param {string} data
     * @param {Object} rowData
     * @returns {string}
     */
    nameColumnRender(data, rowData) {
        return `<div class="d-flex flex-column gap-1">
            <a class="fw-medium text-decoration-underline" href="${BASE_URL}/sales/opportunity/${rowData.id}">${rowData.name}</a>
            <span class="text-muted fs-12"><i class="ri-calendar-line me-1"></i>${rowData.date ?? '—'}</span>
            <span class="text-muted fs-12"><i class="ri-edit-line me-1"></i>${rowData.created_by.name}</span>
        </div>`
    }

    /**
     * @param {string} data
     * @param {Object} rowData
     * @returns {string}
     */
    phoneEmailColumnRender(data, rowData) {
        return `<div class="d-flex flex-column gap-1">
            <span class="text-muted"><i class="ri-phone-line me-2"></i>${rowData.phone ?? '-'}</span>
            <span class="text-muted"><i class="ri-mail-line me-2"></i>${rowData.email ?? '-'}</span>
        </div>`
    }

    /**
     * @param {string} data
     * @param {Object} rowData
     * @returns {string}
     */
    statusColumnRender(data, rowData) {
        const status       = rowData.status
        const statusBadge  = `<span class="badge bg-${status?.color ?? 'secondary'} fs-10">${data ?? '—'}</span>`
        const statusDate   = rowData.status_date
            ? `<span class="text-muted fs-12"><i class="ri-calendar-line me-1"></i>${DateHelper.formatDate(rowData.status_date, "dd MMM yyyy")}</span>`
            : `<span class="text-muted fs-12">—</span>`
        const latestStatus = rowData.latest_status
            ? `<span class="text-muted fs-12">${rowData.latest_status}</span>`
            : ''

        return `<div class="d-flex flex-column align-items-start gap-1">${statusBadge}${statusDate}${latestStatus}</div>`
    }

    /**
     * @param {string} data
     * @param {Object} rowData
     * @returns {string}
     */
    customerColumnRender(data, rowData) {
        const initialAccount = rowData.customer ? this.helper.getInitialName(rowData.customer.name) : ""
        const initialContact = rowData.decision_maker ? this.helper.getInitialName(rowData.decision_maker.name) : ""

        const content = (type, prop, initialName) => {
            let icon = type == "account" ? '<i class="ri-building-2-line fs-16 me-1"></i>' : '<i class="ri-user-3-line fs-16 me-1"></i>'

            return `<div class="d-flex align-items-center gap-2">
                ${icon}
                ${prop ?
                    `<div class="lh-1">
                        <span class="avatar avatar-rounded avatar-sm ${!prop.profile_picture_id ? "bg-secondary" : ""}">
                            ${prop.profile_picture_id ? `<img src="${BASE_URL}/core/images/thumbnail/${prop.profile_picture_id}" alt="">` : initialName}
                        </span>
                    </div>
                    <a class="fw-medium text-decoration-underline" href="${BASE_URL}/master-data/${type}/${prop.id}">${prop.name}</a>` : '-'
                }
            </div>`
        }

        return `<div class="d-flex flex-column gap-2">
            ${content("account", rowData.customer, initialAccount)}
            ${content("contact", rowData.decision_maker, initialContact)}
        </div>`
    }

    /**
     * @param {string|number} data
     * @param {Object} rowData
     * @returns {string}
     */
    amountColumnRender(data, rowData) {
        const discountHtml = (rowData.discount_percent > 0 || rowData.discount_amount > 0)
            ? `<span class="fs-12 text-danger">- ${rowData.discount_percent ?? 0}% · Rp ${this.helper.numberToCurrency(rowData.discount_amount ?? 0)}</span>`
            : ''

        return `<div class="d-flex flex-column gap-1">
            <span class="fs-12 text-muted">Rp ${this.helper.numberToCurrency(rowData.amount ?? 0)}</span>
            ${discountHtml}
            <span class="fw-medium">Rp ${this.helper.numberToCurrency(data ?? 0)}</span>
        </div>`
    }

    /**
     * @param {string} data
     * @param {Object} rowData
     * @returns {string}
     */
    leadColumnRender(data, rowData) {
        if(!rowData.lead) {
            return data ?? '—'
        }

        return `<div class="d-flex flex-column gap-1">
            <a class="fw-medium text-decoration-underline" href="${BASE_URL}/sales/lead/${rowData.lead.id}">${data}</a>
            <span class="text-muted fs-12"><i class="ri-calendar-line me-2"></i>${rowData.lead.date}</span>
            <span class="text-muted fs-12"><i class="ri-money-dollar-circle-line me-2"></i>${rowData.lead.budget_range?.name ?? '—'}</span>
        </div>`
    }

    /**
     * @param {string} data
     * @param {Object} rowData
     * @returns {string}
     */
    customerNeedColumnRender(data, rowData) {
        return `<span class="d-inline-block text-truncate align-middle" title="Click to expand" style="max-width: 15rem;">${data ?? ''}</span>`
    }

    // #endregion

    customerNeedColumnCreated(row, cell, cellData, rowData) {
        const span = cell.children[0]
        span.addEventListener("click", () => {
            span.classList.toggle("d-inline-block")
            span.classList.toggle("text-truncate")
        })
    }

    onActionCreated(row, cell, rowData) {
        const actionBtn      = cell.children[0]
        const activityAction = ActivityAction.createAction(
            this.activityCategories,
            (category) => {
                this.activityModal.form.get('account_id').set(rowData.customer, true)
                this.activityModal.form.get('contact_id').set(rowData.decision_maker, true)
                this.activityModal.form.get('category_id').set(category)
                this.activityModal.form.addData("opportunity_id", rowData.id)
                this.activityModal.modalForm.new()
            }
        )

        const wrap     = document.createElement("div")
        wrap.className = "d-flex justify-content-center gap-1"
        wrap.append(activityAction)
        wrap.append(actionBtn)
        cell.prepend(wrap)

        this.table._handleDropdown(wrap.firstElementChild, row.closest('.dt-scroll-body'))

        this.actionBefore(row, "delete-action", {
            selector: "create-order-action",
            label:    "Create Order",
            icon:     "ri-shopping-cart-line",
            color:    "success",
            callback: async () => await OpportunityHelper.createOrder(
                rowData.id,
                () => this.refresh()
            )
        })

        this.actionBefore(row, "create-order-action", {
            selector: "update-status-action",
            label:    "Update Status",
            icon:     "ri-git-commit-line",
            color:    "secondary",
            callback: () => this.updateStatusModal.edit(rowData, (form) => form.addData("id", rowData.id))
        })

		if (rowData.status_id != OpportunityStatus.ClosedWon) {
			cell.querySelector(".create-order-action")?.classList.add("disabled")
		}
    }

    // #region Kanban

    /**
     * @param {Object} data
     * @returns {{ label: string, body: string, footer: string }}
     */
    kanbanCardRender(data) {
        const initialAccount = data.customer ? this.helper.getInitialName(data.customer.name) : ""
        const initialContact = data.decision_maker ? this.helper.getInitialName(data.decision_maker.name) : ""

        const avatarRow = (type, prop, initial) => {
            if (!prop) {
                return ''
            }

            const avatar = prop.profile_picture_id
                ? `<img src="${BASE_URL}/core/images/thumbnail/${prop.profile_picture_id}" alt="">`
                : initial

            return `<div class="d-flex align-items-center gap-2">
                <span class="avatar avatar-rounded avatar-sm ${!prop.profile_picture_id ? "bg-secondary" : ""}">
                    ${avatar}
                </span>
                <a class="fs-13 lh-1 text-truncate" href="${BASE_URL}/master-data/${type}/${prop.id}" style="max-width: 160px;">${prop.name}</a>
            </div>`
        }

        const label = `<div class="d-flex flex-column gap-1 lh-sm">
            <span class="fw-semibold fs-14">${data.name}</span>
            <div class="d-flex align-items-center gap-1 text-muted fs-12">
                <i class="ri-calendar-line"></i>
                <span>${data.date ?? '—'}</span>
                <span class="mx-1">·</span>
                <span>${data.source?.name ?? '—'}</span>
            </div>
            <span class="text-muted fs-12"><i class="ri-edit-line me-1"></i>${data.created_by?.name}</span>
        </div>`

        const body = `<div class="d-flex flex-column gap-2">
            ${avatarRow("account", data.customer, initialAccount)}
            ${avatarRow("contact", data.decision_maker, initialContact)}
        </div>`

        const probability = data.status?.probability ?? 0
        const color       = data.status?.color ?? 'secondary'
        const footer      = `<div class="d-flex align-items-center justify-content-between">
            <span class="fw-semibold fs-13">Rp ${this.helper.numberToCurrency(data.total_amount ?? 0)}</span>
            <div class="d-flex align-items-center gap-2">
                <div class="progress rounded-pill" style="width: 48px; height: 5px;">
                    <div class="progress-bar bg-${color}" style="width: ${probability}%;"></div>
                </div>
                <span class="fs-11 text-muted">${probability}%</span>
            </div>
        </div>`

        return { label, body, footer }
    }

    /**
     * @param {HTMLElement} card
     * @param {Object} data
     * @param {{ old: string, new: string }} boardIds
     * @returns {Promise<void>}
     */
    async kanbanCardMoved(card, data, boardIds) {
        clearTimeout(this._refreshTimer)
        this._refreshTimer = setTimeout(async () => await this.refresh(), 1000)

        await this.kanbanFetchSummary()
        this.kanbanApplySummary(boardIds.old)
        this.kanbanApplySummary(boardIds.new)
    }

    /**
     * @param {Object} data
     * @param {string} boardId
     * @returns {Promise<void>}
     */
    async kanbanDeleted(data, boardId) {
        await this.kanbanFetchSummary()
        this.kanbanApplySummary(boardId)
    }

    /**
     * @param {Object} res
     * @returns {Promise<void>}
     */
    async kanbanFormSuccess(res) {
        if (!this.kanban) {
            return
        }

        await this.kanbanFetchSummary()
        this.kanbanApplySummary(res.data?.[this.kanban.getBoardColumn()])
    }

    /**
     * @param {Object|null} params
     * @returns {Promise<void>}
     */
    async kanbanFetchSummary(params = null) {
        try {
            const req = await axios({
                method: "POST",
                url: `${BASE_URL}/sales/opportunity/kanban-summary`,
                data: params ?? this.kanban.getParamData()
            })

            this._kanbanSummary = req.data ?? {}
        } catch (error) {
            console.error("Failed to fetch opportunity kanban summary.", { error })
        }
    }

    /**
     * @param {string} boardId
     * @returns {void}
     */
    kanbanApplySummary(boardId) {
        const summaryElement = this.kanban?.getBoardElement(boardId)?.querySelector(".board-summary")
        if (!summaryElement) {
            return
        }

        const amount = this._kanbanSummary[boardId]?.total_amount
        if (amount === undefined || amount === null) {
            summaryElement.classList.add("d-none")
            summaryElement.innerHTML = ""
            return
        }

        summaryElement.innerHTML = `<span class="board-summary-item" title="Total amount">
            <i class="ri-money-dollar-circle-line"></i>
            ${Numeral.render({ value: Number(amount), prefix: "Rp", class: "fw-semibold fs-12" })}
        </span>`
        summaryElement.classList.remove("d-none")

        new Numeral(summaryElement.querySelector('span[solar-ui="numeral"]'))
    }

    kanbanEdit(data) {
        this.openEditPage(data.id)
    }

    /**
     * @returns {void}
     */
    _adjustKanbanHeight() {
        if (!this.kanban) return

        const board      = this.kanban._element
        const firstTasks = board.querySelector('.kanban-tasks.board-content')
        if (!firstTasks) return

        const footer       = document.querySelector('footer.footer')
        const tasksTop     = firstTasks.getBoundingClientRect().top
        const footerHeight = footer ? footer.offsetHeight : 0

        board.style.setProperty('--kanban-overhead', `${tasksTop + footerHeight + 16}px`)
    }

    /**
     * @param {HTMLElement} card
     * @param {Object} data
     * @param {{ old: string, new: string }} boardIds
     * @returns {Promise<false|undefined>}
     */
    async _beforeKanbanMove(card, data, boardIds) {
        const isClosedWon  = boardIds.new === OpportunityStatus.ClosedWon
        const isClosedLost = boardIds.new === OpportunityStatus.ClosedLost

        if (!isClosedWon && !isClosedLost) {
            return
        }

        const boardName = isClosedWon ? 'Closed Won' : 'Closed Lost'
        const result    = await this.helper.confirm({
            title:   `Move to ${boardName}?`,
            message: `Opportunity "${data.name}" will be marked as ${boardName}.`
        })

        return result === true ? undefined : false
    }

    // #endregion
}
