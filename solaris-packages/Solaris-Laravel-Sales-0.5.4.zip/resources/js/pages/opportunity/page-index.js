import OpportunityPage from "./page"

new OpportunityPage()