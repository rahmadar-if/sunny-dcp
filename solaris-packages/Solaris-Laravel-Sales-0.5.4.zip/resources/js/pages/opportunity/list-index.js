import OpportunityListPage from "./list"

new OpportunityListPage("opportunity")