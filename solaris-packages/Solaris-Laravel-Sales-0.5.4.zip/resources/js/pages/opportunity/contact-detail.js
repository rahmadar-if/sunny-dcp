import SolarListDetail from "@core-js/solaris/solar/solar-list-detail";

export default class OpportunityContactDetail extends SolarListDetail {
    init() {
        this.columnRender("contact_id", this.contactColumnRender.bind(this))
    }

    contactColumnRender(data, rowData) {
        const initialName = this.helper.getInitialName(data)
        return `<div class="d-flex align-items-center gap-2">
            <div class="lh-1">
                <span class="avatar avatar-rounded avatar-sm ${!rowData.contact.profile_picture_id ? "bg-secondary" : ""}">
                    ${rowData.contact.profile_picture_id ? `<img src="${BASE_URL}/core/images/thumbnail/${rowData.contact.profile_picture_id}" alt="">` : initialName}
                </span>
            </div>
            <div>
                <a class="text-decoration-underline" href="${BASE_URL}/master-data/contact/edit/${rowData.contact_id}">${data}</a>
            </div>
        </div>`
    }
}