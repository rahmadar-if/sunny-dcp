import Filter from "@core-js/solaris/filter/filter";
import SolarListPage from "@core-js/solaris/solar/solar-list-page";

export default class ContractListPage extends SolarListPage {
    init() {
        this.initModal()

        this.columnRender("account_id", this.accountColumnRender.bind(this))
        this.columnRender("contact_id", this.contactColumnRender.bind(this))
        this.columnRender("amount", this.amountColumnRender.bind(this))
    }

    initModal() {
        if(!this.hasModalForm()) {
            return
        }

        const account = this.form.get("account_id")
        const contact = this.form.get("contact_id")
        contact?.init({
            param: (param) => {
                const filter    = new Filter()
                const accountId = account?.get()?.id
                if(accountId) {
                    filter.and("account_id", accountId)
                    param.filter = filter.get()
                }

                return param
            }
        })

        this.modal.on("show", () => {
            this.form.set('start_date', new Date())
        }, "ContractListPage")

        account?.on("change", (value) => {
            const contactVal = contact?.get()
            if(!value || (contactVal && value && contactVal.account?.id != value.id)) {
                contact.set(null)
            }

            if(value && !contactVal && value.primary_contact) {
                contact.set(value.primary_contact)
            }
        }, "ContractListPage")

        contact?.on("change", (value) => {
            const accountVal = account?.get()
            if(value && value.account && !accountVal) {
                account.set(value.account)
            }
        }, "ContractListPage")
    }

    openEditPage(id) {
        this.helper.loadingPage(true)
        window.location = `${BASE_URL}/sales/contract/edit/${id}`
    }

    async edit(row, data) {
        this.openEditPage(data.id)
    }

    rowDoubleClick(row, data) {
        this.openEditPage(data.id)
    }

    accountColumnRender(data, rowData) {
        if(!data) {
            return data
        }

        const initialName = this.helper.getInitialName(data)
        return `<div class="d-flex align-items-center gap-2">
            <div class="lh-1">
                <span class="avatar avatar-rounded avatar-sm ${!rowData.account.profile_picture_id ? "bg-secondary" : ""}">
                    ${rowData.account.profile_picture_id ? `<img src="${BASE_URL}/core/images/thumbnail/${rowData.account.profile_picture_id}" alt="">` : initialName}
                </span>
            </div>
            <div>
                <a class="text-decoration-underline" href="${BASE_URL}/master-data/account/${rowData.account_id}">${data}</a>
            </div>
        </div>`
    }

    contactColumnRender(data, rowData) {
        if(!data) {
            return data
        }

        const initialName = this.helper.getInitialName(data)
        return `<div class="d-flex align-items-center gap-2">
            <div class="lh-1">
                <span class="avatar avatar-rounded avatar-sm ${!rowData.contact.profile_picture_id ? "bg-secondary" : ""}">
                    ${rowData.contact.profile_picture_id ? `<img src="${BASE_URL}/core/images/thumbnail/${rowData.contact.profile_picture_id}" alt="">` : initialName}
                </span>
            </div>
            <div>
                <a class="text-decoration-underline" href="${BASE_URL}/master-data/contact/${rowData.contact_id}">${data}</a>
            </div>
        </div>`
    }

    amountColumnRender(data, rowData) {
        return `Rp ${this.helper.numberToCurrency(data ?? 0)}`
    }
}