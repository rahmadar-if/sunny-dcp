import ContractListPage from "./list"

new ContractListPage("contract")