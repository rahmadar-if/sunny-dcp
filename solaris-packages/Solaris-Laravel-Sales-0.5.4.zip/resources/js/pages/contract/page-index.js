import ContractPage from "./page"

new ContractPage()