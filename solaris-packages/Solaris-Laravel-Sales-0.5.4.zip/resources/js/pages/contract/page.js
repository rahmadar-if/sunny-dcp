import Filter from "@core-js/solaris/filter/filter";
import SolarEditPage from "@core-js/solaris/solar/solar-edit-page";

export default class ContractPage extends SolarEditPage {
    init() {
        this.initForm()
    }

    initForm() {
        const account = this.form.get("account_id")
        const contact = this.form.get("contact_id")

        contact?.init({
            param: (param) => {
                const filter     = new Filter()
                const accountVal = account?.get()
                if(accountVal) {
                    filter.and("account_id", accountVal.id)
                    param.filter = filter.get()
                }
        
                return param
            }
        })

        contact?.on("change", (value) => {
            const accountVal = account?.get()
            if(value && value.account && !accountVal) {
                account.set(value.account)
            }
        }, "ContractPage")
        
        account?.on("change", (value) => {
            if(!value) {
                contact?.set(null)
                return    
            }
            
            if(value && value.primary_contact) {
                contact?.set(value.primary_contact)
            }
        }, "ContractPage")
    }

    async failed(errors, message) {
        if(errors.notes) {
            this.helper.toast({message: errors.notes, color: "danger"})
        }
    }

    async onRefreshed(data) {
        this.breadcrumbName.innerText = data.number
    }
}