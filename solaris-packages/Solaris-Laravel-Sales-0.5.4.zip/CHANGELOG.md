# Changelog

All notable changes to `solaris-laravel-sales` will be documented in this file.

---

## [v0.5.4] — 18 Aug 2026

- Exposed the sales pipeline over the 3rd-party API — Account/Contact/Activity/Lead pick up their Sales fields; new `Api\{Opportunity,Order,Invoice}Controller` + matching `Api\*Resource` add opportunity, order and invoice. Promoting a lead to an opportunity gets its own endpoint, refusing with 409 when the lead already has one or has neither an account nor a contact. Derived values (deal totals from opportunity products, invoice stamps from its stage) are read-only, not accepted and ignored. Order/invoice create endpoints take only the parent reference, since the record is raised from what's above it, not filled from a form. All three rule sets gain a PATCH branch — order and invoice previously fell through to the full update rules, failing every partial update.
- Added an owner quick filter (by `created_by`) to the lead and opportunity lists, next to the existing status filter; both filters now set up together and guarded so a page rendered without them no longer breaks on `ready()`.
- `ApiPermissionSeeder` reworked to seed one integration `Role` per API permission entity, matching the BaseCRM/MasterData/Core pattern.
- `OrderAgent`/`SalesAgent` descriptions now state they resolve their own referenced entities (account, contact, product, opportunity/source) themselves, so the orchestrator stops pre-resolving them.
- Bumped `solaris/solaris-laravel-basecrm` dependency to `^v0.8.4`

---

## [v0.5.3] — 12 Aug 2026

- Added list/kanban metrics + summary endpoints for Lead/Opportunity — routes `sales.lead.list-summary`, `sales.opportunity.list-summary`, `sales.opportunity.kanban-summary`; `LeadController::listSummary`, `OpportunityController::listSummary`/`kanbanSummary` return aggregated counts/sums scoped to current table filters; wired into `list.js` metric cards + status Lookup filters, kanban summaries applied on draw
- Added `$listHeader`/`$kanbanHeader` optional slots to `<x-*::opportunity.list>` component (table + kanban tab content) to host the new metric blocks
- Added `OpportunityHelper.createOrder` centralizing create-order call/logic; wired into opportunity list row action and page create-order button, both enabled only when status is `Closed Won`; added opportunity list tab persistence and status lookup filter; fixed disabled-state propagation on profile field wrappers
- `SalesDashboard` now returns raw numeric amounts on desktop with client-side `Numeral` rendering via `<x-core::numeral>` (lead-opportunity, order-invoice, summary sections); added `opportunityClosedWon` metric; mobile keeps preformatted strings
- Switched account/contact profile `<x-core::numeral>` from `size` to `size-class` prop to match component API
- Moved `opportunity/list.docs.json` under `components/docs/`
- Bumped `solaris/solaris-laravel-basecrm` dependency to `^v0.8.3`

---

## [v0.5.2] — 11 Aug 2026

- Added `search_opportunity_basic`, reference-shaped variant of `search_opportunity` for agents that only point at a deal (order creation, activity linking) rather than work on one
- Added `AiScopedToolSeeder` — grants scoped `search_*_basic` tools (account/contact/product/opportunity) to `sales`/`order`/`activity` agents and revokes their full-tool counterparts
- Added `search_user` AI tool, wired to `sales`/`order` agents via new "AI Tool User Search" permission
- Added OpenRouter provider and default models (`gemini-3.5-flash-lite`, `claude-haiku-4-5-20251001`, `gpt-5.4-nano`, `deepseek/deepseek-v4-pro`) for `sales`/`order` agent providers in `config/solaris.php`
- Standardized AI tool instruction text to direct agents toward the available search tools; switched remaining raw date formatting to Carbon
- Added `OpportunityController::createOrder` (requires `Closed Won` status) and `sales.opportunity.create-order` route, creating an `Order` from an `Opportunity` via `OrderRepository`
- Wired create-order button/handler in opportunity `page.js`, with confirm dialogs and redirect to the created order
- Bumped `solaris/solaris-laravel-basecrm` dependency to `^v0.8.2`

---

## [v0.5.1] — 30 Jul 2026

- Added `bool $transaction = true` param to repository constructors, forwarded to `parent::__construct`, to control transactional behavior per repo (`AccountRepository`, `ContactRepository`, `InvoiceDetailRepository`, `InvoiceRepository`, `OpportunityContactRepository`, `OpportunityProductRepository`, `OrderDetailRepository`, `OrderRepository`)
- `OpportunityRepository` now sets `closed_on` when `status_id` equals `OpportunityStatusConst::ClosedWon`, replacing the previous `is_final_stage` check
- Refactored Contract/Invoice/Order/OrderDetail/Opportunity* AI tools: `findRecord(Request)` → `findRecordById(string $id)`, `delete()` type-hinted to `Model`, validation errors standardized to `AiErrorCode::UserError`
- `OrderAgent`/`SalesAgent` prompts updated — agents keep own chat memory and privately retain `confirmation_tokens`, never surfacing them to the orchestrator; clarified multi-entity confirmation summaries and required a concise factual summary at end of every run
- Updated `AiRegistrySeeder` and `DummyDataSeeder`
- `SalesDashboard` top-products query capped to top 5 (`take(5)`)
- Fixed null-safe access on `$opportunity->date` in lead profile-contact section
- Bumped `solaris/solaris-laravel-basecrm` dependency to `^v0.8.1`

---

## [v0.5.0] — 28 Jul 2026

- Added dedicated `SalesAgent` for sales mutations (opportunities, products, quotations, orders, invoices, contracts) with own `search_*` tools, separate from shared `SearchAgent`; refactored to extend `BaseAiAgent`, implement `CanActAsTool`, and handle `WaConversation` via `HasWaConversation`/`NeedsWaConversation`
- Added `OrderAgent` with own provider, instructions, and conversation limits
- Added full CRUD + search AI tools for opportunity sub-resources — products, contacts, teams, competitors, term & conditions — plus opportunity status/quotation history search
- Added full CRUD + search AI tools for orders, invoices, contracts, order/invoice details, and their status-history; nested `detail_*`/activity payloads, `validateConfirmation`, and before/after hooks to persist child rows
- Added `HotLeadTool`; centralized Hot Lead eligibility checks in `LeadRepository::hotLeadValidationError`
- Enhanced `print_quotation` tool with history mode
- Removed `SalesDelegateTool`, superseded by `SalesAgent`/`OrderAgent`
- Added declarative AI registry in `config/solaris.php` (`ai.agents`, `ai.tools`, `agent_providers`) and `AiRegistrySeeder` (roles, permissions, agent-tool wiring); removed imperative `registerAiTools()` from the service provider in favor of config-driven registration
- Added `DummyDataSeeder` — end-to-end dummy dataset (Account/Contact → Lead → Opportunity → Order → Invoice) for AI testing
- Added search overrides for Activity, Lead, Account, Contact tools to include sales-linked relations
- Refactored `config/solaris.php` with organized sections and comments
- Added `notes_plain` columns to sales models for full-text search, synced from rich-text `notes` via model `booted` hooks
- Updated AI tool responses to use new `AiResponse` class
- Refactored form requests (`Contract`, `Invoice`/`InvoiceDetail`, `Opportunity*`, `Order`/`OrderDetail`) into `createRules()`/`updateRules()` static methods; totals now server-computed, product line items non-updatable, added `product_id` existence checks
- Made `ActivityRequest` rule methods `public static`
- Added `activities` relations to `Invoice` and `Order`; added `Order::scopeInvoiceable`
- Fixed `days_in_funnel` calculation (client-side and stored SQL expression, adjusted per DB driver) on opportunities
- Added owner/creator display on opportunity lists, kanban, and page; enabled New Customer checkbox
- Improved order/invoice lookup templates (creator, date, account/contact, status, amounts) with `extend_search`/`extend_columns`
- Updated lead list/profile — reordered columns, show Budget, fixed initials via `SolarHelper::getInitialName`, added Owner block
- Bumped `solaris/solaris-laravel-basecrm` dependency to `^v0.8.0`

---

## [v0.4.7] — 10 Jul 2026

- Added `status_id` field to `UpdateOpportunityTool` — status changes now recompute `probability_percent`, set `closed_on` on final stages, and log stage history automatically, same as the pipeline board
- Added `quotation_number`, `latest_status`, `status_date`, `is_new_customer`, `closed_on` fields to `UpdateOpportunityTool`
- Added stage transition guard to `UpdateOpportunityTool` — enforces the same Qualification/Proposal/Negotiation/Closed Won/Closed Lost move map as the detail page's stage buttons, and locks the stage once Closed Won or Closed Lost

---

## [v0.4.6] — 10 Jul 2026

- Added AI tools for opportunity products — create, update, delete, search
- Added `guardDelete` to `DeleteOpportunityTool` — blocks deleting Closed Won opportunities
- `CreateOpportunityTool` now derives missing customer/decision maker from each other, and falls back to the customer account's phone/email when omitted
- `CreateOpportunityTool` now supports adding products in the same request via `create_opportunity_product`
- Changed `customer_id`/`decision_maker_id` field type from `lookup` to `reference` in `CreateOpportunityTool`
- Registered new `opportunity_product` AI tools in `config/solaris.php` and service provider

---

## [v0.4.5] — 09 Jul 2026

- Added AI tool support for opportunity module — create, update, delete, search opportunity, print quotation, search quotation history
- Added print quotation feature with 5 templates (classic, elegant, modern, simple, technical)
- Added `quotation_history` FK migration and related code generator seeder entries
- Updated notes component prop across account, contact, invoice, lead, order pages
- Updated JS import alias across opportunity and sales-dashboard pages, removed unused `jsconfig.json` paths
- Bumped `solaris/solaris-laravel-basecrm` dependency to `^v0.6.9`

---

## [v0.4.4] — 29 Jun 2026

- Fixed decimal null bug in `calculateTotal` across invoice detail, opportunity product, and order detail repositories
- Removed `row` param from `importRules` across all sales models
- Updated account layout — page, info, notes-files, and sales sections
- Updated contact layout tabs — page, info, notes-files, and sales sections
- Updated AccountRepository
- Updated activity page view and JS
- Updated opportunity profile section view
- Updated MenuSeeder

---

## [v0.4.3] — 11 Jun 2026

- Extended sales dashboard with full mobile API support — new mobile controller and resources for recent orders, top customers, top orders, top products, and top sales
- Added `UpdateOpportunityDaysInFunnel` job with console route registration
- Updated opportunity mobile controller and resource
- Fixed top opportunity query in repository
- Fixed bug in Invoice model
- Updated lead profile-contact view
- Major opportunity module update — enhanced product detail JS, updated activity/contact/product/quotation/status-history views and modals
- Added `OpportunityContactRepository`; updated `OpportunityProductRepository` and `OpportunityRepository`
- Updated `OpportunityContactController` and `OpportunityProductController`
- Fixed `Contact::scopeAvailableInOpportunityContact` to also filter by opportunity's customer account
- Set default `type_id` to `NewBusiness` when converting lead to opportunity

---

## [v0.4.2] — 04 Jun 2026

- Added mobile API support for lead module
- Added new mobile dashboard
- Updated stage management and default confirmation behavior
- Fixed pie chart rendering bug

---

## [v0.4.1] — 26 May 2026

- Updated profile contact view
- Updated database seeder

---

## [v0.4.0] — 26 May 2026

- Major update across all sales modules — account, contact, opportunity, invoice, order, and dashboard
- Introduced Lead v2 with hot lead process
- Added proper type hints across controllers, repositories, and models
- Fixed broken database indexes

---

## [v0.3.5] — 21 Apr 2026

- Fixed blade component lookup breaking change from core
- Added blade component documentation for Solar UI VSCode extension

---

## [v0.3.4] — 01 Apr 2026

- Minor updates and dependency adjustments

---

## [v0.3.3] — 31 Mar 2026

- Added default `importRules` to models

---

## [v0.3.2] — 30 Mar 2026

- Added import access attributes to models
- Moved business event logic from controllers into the repository layer
- Updated migrations to add cascade/set-null behavior on foreign key deletes
- Refactored StageHistory model inheritance

---

## [v0.3.1] — 27 Mar 2026

- Updated CodeGeneratorSeeder
- Updated README

---

## [v0.3.0] — 27 Mar 2026

- Internal updates and refactoring

---

## [v0.2.2] — 12 Mar 2026

- Fixed bug on opportunity detail list page

---

## [v0.2.1] — 11 Mar 2026

- Fixed bug on opportunity list page

---

## [v0.2.0] — 11 Mar 2026

- **Breaking changes** — major internal restructuring
- Updated invoice page and menu seeder
- Opportunity model improvements

---

## [v0.1.1] — 22 Dec 2025

- Added period filter to sales dashboard
- Added per-component refresh to sales dashboard

---

## [v0.1.0] — 19 Dec 2025

- Sales dashboard enhancements — period filter and component-level refresh support
- Migration and seeder updates

---

## [v0.0.5.1] — 16 Dec 2025

- Sales dashboard improvements
- Updated config file

---

## [v0.0.5] — 15 Dec 2025

- Hotfixes and config update

---

## [v0.0.4] — 15 Dec 2025

- Version bump and minor updates

---

## [v0.0.3] — 12 Dec 2025

- Minor updates and fixes

---

## [v0.0.2] — 08 Dec 2025

- Added sales dashboard
- Minor updates

---

## [v0.0.1] — 28 Nov 2025

- Initial release
- Core sales modules: opportunity, lead, order, invoice, contract, activity, and account
- Extended models from the core package for the sales context
- Basic config, routes, and migrations in place
