<?php

namespace Solaris\Sales\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Solaris\Sales\Repositories\OpportunityRepository;

class UpdateOpportunityDaysInFunnel implements ShouldQueue
{
	use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

	public function handle(): void
	{
		OpportunityRepository::bulkUpdateDaysInFunnel();
	}
}
