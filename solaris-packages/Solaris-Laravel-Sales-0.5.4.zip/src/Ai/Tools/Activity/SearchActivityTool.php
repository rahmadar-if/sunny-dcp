<?php

namespace Solaris\Sales\Ai\Tools\Activity;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\BaseCRM\Ai\Tools\Activity\SearchActivityTool as BaseSearchActivityTool;

class SearchActivityTool extends BaseSearchActivityTool
{
	protected function resourceLabel(): string
	{
		return parent::resourceLabel() . ', optionally linked to a sales opportunity, order, or invoice';
	}

	protected function fields(): array
	{
		return array_merge(parent::fields(), [
			'opportunity_id' => AiSearchColumn::reference(
				column: 'opportunity_id',
				description: 'The sales opportunity id this activity relates to. Obtain it with the opportunity search tool available to you first.',
				modelKey: 'opportunity',
			),
			'order_id' => AiSearchColumn::reference(
				column: 'order_id',
				description: 'The order id this activity relates to',
				modelKey: 'order',
			),
			'invoice_id' => AiSearchColumn::reference(
				column: 'invoice_id',
				description: 'The invoice id this activity relates to',
				modelKey: 'invoice',
			),
		]);
	}

	protected function formatRecord(Model $record): array
	{
		return array_merge(parent::formatRecord($record), [
			'opportunity' => $record->opportunity?->name,
			'order'       => $record->order?->number,
			'invoice'     => $record->invoice?->number,
		]);
	}
}
