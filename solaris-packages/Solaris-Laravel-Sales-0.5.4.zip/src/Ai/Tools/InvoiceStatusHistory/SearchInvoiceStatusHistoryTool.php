<?php

namespace Solaris\Sales\Ai\Tools\InvoiceStatusHistory;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

class SearchInvoiceStatusHistoryTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_invoice_status_history';
	}

	protected function resourceLabel(): string
	{
		return 'invoice status history — history of status changes for an invoice';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('invoice_status_history'))();
	}

	protected function fields(): array
	{
		return [
			'invoice_id' => AiSearchColumn::reference(
				column: 'invoice_id',
				description: 'The invoice id this status history belongs to. Obtain it with the invoice search tool available to you first.',
				modelKey: 'invoice',
			),
			'status_id' => AiSearchColumn::lookup(
				column: 'status_id',
				description: 'Status held during this period',
				modelKey: 'invoice_status',
			),
			'position' => AiSearchColumn::number(
				column: 'position',
				description: 'Sequence order of this status within the invoice\'s history, starting at 1',
			),
			'start' => AiSearchColumn::datetime('start', 'Date and time this status started'),
			'end'   => AiSearchColumn::datetime('end', 'Date and time this status ended (empty means still current)'),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'         => $record->id,
			'_invoice_id' => $record->invoice_id,
			'status'      => $record->status?->name,
			'position'    => $record->position,
			'start'       => $record->start ? Carbon::parse($record->start)->format('d M Y H:i') : null,
			'end'         => $record->end ? Carbon::parse($record->end)->format('d M Y H:i') : null,
		];
	}
}
