<?php

namespace Solaris\Sales\Ai\Tools\Account;

use Solaris\BaseCRM\Ai\Tools\Account\SearchAccountTool as BaseSearchAccountTool;

class SearchAccountTool extends BaseSearchAccountTool
{
	// orders/invoices/contracts relations added once search_order/search_invoice/search_contract exist.
	protected function relations(): array
	{
		return array_merge(parent::relations(), [
			'opportunities' => 'search_opportunity',
		]);
	}
}
