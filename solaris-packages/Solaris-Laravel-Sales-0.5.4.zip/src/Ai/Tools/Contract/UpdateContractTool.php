<?php

namespace Solaris\Sales\Ai\Tools\Contract;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseUpdateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Http\Requests\ContractRequest;
use Solaris\Sales\Models\Contract;

class UpdateContractTool extends BaseUpdateAiTool
{
	public static function slug(): string
	{
		return 'update_contract';
	}

	protected function resourceLabel(): string
	{
		return 'contract';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'id' => $schema->string()
				->description('The contract id. Required.')
				->required(),
			'number'     => $schema->string()->description('New contract number/reference.'),
			'subject'    => $schema->string()->description('New subject/title of the contract.'),
			'account_id' => $schema->string()->description('New account this contract is with. Obtain it with the account search tool available to you first.'),
			'contact_id' => $schema->string()->description('New contact this contract is with. Obtain it with the contact search tool available to you first.'),
			'start_date' => $schema->string()->description('New start date in Y-m-d format.'),
			'end_date'   => $schema->string()->description('New end date in Y-m-d format.'),
			'amount'     => $schema->string()->description('Contract value as a plain number.'),
			'notes'      => $schema->string()->description(
				'The contract body/terms document. Write it in WhatsApp-style formatting (*bold*, "- " bullets, '
					. 'numbered lists, line breaks) — it is converted to rich text/HTML automatically. Pass the full '
					. 'body you want the document to have; it replaces the existing content.'
			),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::reference(column: 'account_id', label: 'account', modelKey: 'account'),
			AiColumn::reference(column: 'contact_id', label: 'contact', modelKey: 'contact'),
		];
	}

	protected function rules(): array
	{
		return ContractRequest::updateRules();
	}

	// The contract body is a rich-text/CKEditor field — the model expects HTML. The AI supplies it as
	// WhatsApp-style plain text, converted here before it is written.
	protected function beforeUpdate(Model $record, array $data, array $raw): array
	{
		if (array_key_exists('notes', $data) && $data['notes'] !== null) {
			$data['notes'] = $this->waToHtml($data['notes']);
		}

		return $data;
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/update-contract" with no other text, ask which contract and what to change. '
			. 'If followed by a description of the changes, extract the fields directly and proceed to confirmation — '
			. 'skip clarifying questions unless a field is ambiguous.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to edit a contract or write/redraft its body/terms, first locate it '
			. 'with the contract search tool available to you if the id is not already known, then confirm the changes before calling this tool.'
			. "\n\n"
			. 'CONTRACT BODY: The notes field is the contract\'s document body. When the user asks to draft, write, or '
			. 'revise the contract text, put the full intended body in notes using WhatsApp-style formatting — it '
			. 'becomes the formatted document. It replaces the existing body, so include everything that should '
			. 'remain, not just the change.';
	}

	protected function findRecordById(string $id): ?Contract
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('contract'))(new (Helper::model('contract')));

		return $repo->find($id);
	}

	protected function currentData(mixed $record): array
	{
		return [
			'number'     => $record->number,
			'subject'    => $record->subject,
			'account_id' => $record->account_id,
			'contact_id' => $record->contact_id,
			'start_date' => $record->start_date?->format('Y-m-d'),
			'end_date'   => $record->end_date?->format('Y-m-d'),
			'amount'     => $record->amount,
			'notes'      => $record->notes,
		];
	}

	protected function update(mixed $record, array $validated, array $changes): array
	{
		$repo = new (Helper::repository('contract'))(new (Helper::model('contract')));
		$repo->update($record->id, $validated,
			before: fn ($record, $data) => $this->beforeUpdate($record, $data, $changes),
			after:  fn ($record)        => $this->afterUpdate($record, $changes),
		);

		return AiResponse::success(
			[
				'id'      => $record->id,
				'number'  => $record->number,
				'updated' => array_keys($changes),
			],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
