<?php

namespace Solaris\Sales\Ai\Tools\Contract;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseCreateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Http\Requests\ContractRequest;

class CreateContractTool extends BaseCreateAiTool
{
	public static function slug(): string
	{
		return 'create_contract';
	}

	protected function resourceLabel(): string
	{
		return 'contract';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'number' => $schema->string()
				->description('Contract number/reference.')
				->required(),
			'subject' => $schema->string()
				->description('Subject/title of the contract.')
				->required(),
			'account_id' => $schema->string()
				->description('The account this contract is with. Obtain it with the account search tool available to you first.')
				->required(),
			'contact_id' => $schema->string()
				->description('The contact this contract is with. Obtain it with the contact search tool available to you first. Optional.'),
			'start_date' => $schema->string()
				->description('Contract start date in Y-m-d format.')
				->required(),
			'end_date' => $schema->string()
				->description('Contract end date in Y-m-d format. Optional.'),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::reference(column: 'account_id', label: 'account', modelKey: 'account'),
			AiColumn::reference(column: 'contact_id', label: 'contact', modelKey: 'contact'),
		];
	}

	protected function rules(): array
	{
		return ContractRequest::createRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/add-contract" with no other text, ask for the required fields. '
			. 'If followed by details, extract them and proceed to confirmation — skip clarifying questions unless '
			. 'a field is ambiguous.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to create/register a new contract, locate the account (and contact '
			. 'if given) with the account search tool available to you / the contact search tool first, then confirm before calling this tool.'
			. "\n\n"
			. 'The contract body/terms document is not set here — create the contract first, then write its body via '
			. 'update_contract.';
	}

	protected function create(array $validated, array $raw): array
	{
		$repo     = new (Helper::repository('contract'))(new (Helper::model('contract')));
		$contract = $repo->create($validated,
			before: fn ($data)   => $this->beforeCreate($data, $raw),
			after:  fn ($record) => $this->afterCreate($record, $raw),
		);

		return AiResponse::success(
			['id' => $contract->id, 'number' => $contract->number, 'subject' => $contract->subject],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
