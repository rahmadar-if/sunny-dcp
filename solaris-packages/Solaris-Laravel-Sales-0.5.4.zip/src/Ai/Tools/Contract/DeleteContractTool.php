<?php

namespace Solaris\Sales\Ai\Tools\Contract;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseDeleteAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Models\Contract;

class DeleteContractTool extends BaseDeleteAiTool
{
	public static function slug(): string
	{
		return 'delete_contract';
	}

	protected function resourceLabel(): string
	{
		return 'contract';
	}

	protected function findRecordById(string $id): ?Contract
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('contract'))(new (Helper::model('contract')));

		return $repo->find($id);
	}

	protected function delete(Model $record): array
	{
		$repo = new (Helper::repository('contract'))(new (Helper::model('contract')));
		$repo->delete($record->id);

		return AiResponse::success(
			['deleted' => $record->number],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
