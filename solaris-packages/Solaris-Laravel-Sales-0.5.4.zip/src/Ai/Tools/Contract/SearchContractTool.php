<?php

namespace Solaris\Sales\Ai\Tools\Contract;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Services\Filter;

class SearchContractTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_contract';
	}

	protected function resourceLabel(): string
	{
		return 'contracts — signed agreements with an account';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('contract'))();
	}

	protected function fields(): array
	{
		return [
			'number' => AiSearchColumn::string(
				column: 'number',
				description: 'Contract number',
				searchable: true,
			),
			'subject' => AiSearchColumn::string(
				column: 'subject',
				description: 'Subject of the contract',
				searchable: true,
			),
			'notes_plain' => AiSearchColumn::string(
				column: 'notes_plain',
				description: 'Plain text notes about the contract',
				operators: [Filter::Contains, Filter::FullText],
				searchable: 'FullText',
			),
			'start_date' => AiSearchColumn::date('start_date', 'Date the contract starts'),
			'end_date' => AiSearchColumn::date('end_date', 'Date the contract ends'),
			'amount' => AiSearchColumn::number('amount', 'Contract amount'),
			'account_id' => AiSearchColumn::reference(
				column: 'account_id',
				description: 'The account this contract is with. Obtain it with the account search tool available to you first.',
				modelKey: 'account',
			),
			'contact_id' => AiSearchColumn::reference(
				column: 'contact_id',
				description: 'The contact this contract is with. Obtain it with the contact search tool available to you first.',
				modelKey: 'contact',
			),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'         => $record->id,
			'_account_id' => $record->account_id,
			'_contact_id' => $record->contact_id,
			'number'      => $record->number,
			'subject'     => $record->subject,
			'account'     => $record->account?->name,
			'contact'     => $record->contact?->name,
			'start_date'  => $record->start_date ? Carbon::parse($record->start_date)->format('d M Y') : null,
			'end_date'    => $record->end_date ? Carbon::parse($record->end_date)->format('d M Y') : null,
			'amount'      => $record->amount,
		];
	}
}
