<?php

namespace Solaris\Sales\Ai\Tools\OpportunityCompetitor;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseDeleteAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Models\OpportunityCompetitor;

class DeleteOpportunityCompetitorTool extends BaseDeleteAiTool
{
	public static function slug(): string
	{
		return 'delete_opportunity_competitor';
	}

	protected function resourceLabel(): string
	{
		return 'opportunity competitor';
	}

	protected function descriptionExtra(): ?string
	{
		return 'Obtain the id with the opportunity competitor search tool available to you first.';
	}

	protected function findRecordById(string $id): ?OpportunityCompetitor
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('opportunity_competitor'))(new (Helper::model('opportunity_competitor')));

		return $repo->find($id);
	}

	protected function delete(Model $record): array
	{
		$repo = new (Helper::repository('opportunity_competitor'))(new (Helper::model('opportunity_competitor')));
		$name = $record->name;
		$repo->delete($record->id);

		return AiResponse::success(
			['deleted' => $name],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
