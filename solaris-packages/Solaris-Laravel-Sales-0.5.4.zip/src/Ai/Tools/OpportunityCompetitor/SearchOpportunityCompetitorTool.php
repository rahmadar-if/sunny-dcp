<?php

namespace Solaris\Sales\Ai\Tools\OpportunityCompetitor;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Services\Filter;

class SearchOpportunityCompetitorTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_opportunity_competitor';
	}

	protected function resourceLabel(): string
	{
		return 'opportunity competitors — rival vendors competing for a sales opportunity, with their quoted '
			. 'amount, strengths, weaknesses, and a threat rating';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('opportunity_competitor'))();
	}

	protected function fields(): array
	{
		return [
			'opportunity_id' => AiSearchColumn::reference(
				column: 'opportunity_id',
				description: 'The opportunity id this competitor is competing on. Obtain it with the opportunity search tool available to you first.',
				modelKey: 'opportunity',
			),
			'name' => AiSearchColumn::string(
				column: 'name',
				description: 'Name of the competitor',
				searchable: true,
			),
			'total_amount' => AiSearchColumn::number(
				column: 'total_amount',
				description: 'The competitor\'s quoted total amount',
				operators: [Filter::Equal, Filter::Greater, Filter::Less, Filter::Between],
			),
			'strength' => AiSearchColumn::string(
				column: 'strength',
				description: 'The competitor\'s strengths against us on this deal',
				searchable: true,
			),
			'weakness' => AiSearchColumn::string(
				column: 'weakness',
				description: 'The competitor\'s weaknesses against us on this deal',
				searchable: true,
			),
			'rating' => AiSearchColumn::number(
				column: 'rating',
				description: 'Competitive threat rating',
			),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'             => $record->id,
			'_opportunity_id' => $record->opportunity_id,
			'name'            => $record->name,
			'total_amount'    => $record->total_amount,
			'strength'        => $record->strength,
			'weakness'        => $record->weakness,
			'rating'          => $record->rating,
		];
	}
}
