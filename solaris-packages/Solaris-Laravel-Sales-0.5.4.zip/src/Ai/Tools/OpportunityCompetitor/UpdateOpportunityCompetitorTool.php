<?php

namespace Solaris\Sales\Ai\Tools\OpportunityCompetitor;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseUpdateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Http\Requests\OpportunityCompetitorRequest;
use Solaris\Sales\Models\OpportunityCompetitor;

class UpdateOpportunityCompetitorTool extends BaseUpdateAiTool
{
	public static function slug(): string
	{
		return 'update_opportunity_competitor';
	}

	protected function resourceLabel(): string
	{
		return 'opportunity competitor';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'id' => $schema->string()
				->description('The opportunity competitor id. Required. Obtain with the opportunity competitor search tool available to you.')
				->required(),
			'name' => $schema->string()->description('New name of the competitor.'),
			'total_amount' => $schema->string()->description('New quoted total amount, as a plain number.'),
			'strength' => $schema->string()->description('New strengths description.'),
			'weakness' => $schema->string()->description('New weaknesses description.'),
			'rating' => $schema->string()->description('New competitive threat rating, as a plain integer.'),
		];
	}

	protected function rules(): array
	{
		return OpportunityCompetitorRequest::updateRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/update-opportunity-competitor" with no other text, ask which competitor and '
			. 'what to change. If followed by a description of the changes, extract the fields directly and '
			. 'proceed to confirmation — skip clarifying questions unless a field is ambiguous.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to update a competitor\'s details, first locate the record via '
			. 'the opportunity competitor search tool if its id is not already known, then confirm the changes before '
			. 'calling this tool.';
	}

	protected function findRecordById(string $id): ?OpportunityCompetitor
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('opportunity_competitor'))(new (Helper::model('opportunity_competitor')));

		return $repo->find($id);
	}

	protected function currentData(mixed $record): array
	{
		return [
			'name'         => $record->name,
			'total_amount' => $record->total_amount,
			'strength'     => $record->strength,
			'weakness'     => $record->weakness,
			'rating'       => $record->rating,
		];
	}

	protected function update(mixed $record, array $validated, array $changes): array
	{
		$repo       = new (Helper::repository('opportunity_competitor'))(new (Helper::model('opportunity_competitor')));
		$competitor = $repo->update($record->id, $validated,
			before: fn ($record, $data) => $this->beforeUpdate($record, $data, $changes),
			after:  fn ($record)        => $this->afterUpdate($record, $changes),
		);

		return AiResponse::success(
			[
				'id'           => $competitor->id,
				'name'         => $competitor->name,
				'total_amount' => $competitor->total_amount,
				'rating'       => $competitor->rating,
				'updated'      => array_keys($changes),
			],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
