<?php

namespace Solaris\Sales\Ai\Tools\OpportunityCompetitor;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseCreateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Http\Requests\OpportunityCompetitorRequest;

class CreateOpportunityCompetitorTool extends BaseCreateAiTool
{
	public static function slug(): string
	{
		return 'create_opportunity_competitor';
	}

	protected function resourceLabel(): string
	{
		return 'opportunity competitor';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'opportunity_id' => $schema->string()
				->description('The opportunity id this competitor is competing on. Obtain it with the opportunity search tool available to you first.')
				->required(),
			'name' => $schema->string()
				->description('Name of the competitor.')
				->required(),
			'total_amount' => $schema->string()->description('The competitor\'s quoted total amount, as a plain number.'),
			'strength' => $schema->string()->description('The competitor\'s strengths against us on this deal.'),
			'weakness' => $schema->string()->description('The competitor\'s weaknesses against us on this deal.'),
			'rating' => $schema->string()->description('A rating of the competitive threat, as a plain integer.'),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::reference(column: 'opportunity_id', label: 'opportunity', modelKey: 'opportunity'),
		];
	}

	protected function rules(): array
	{
		return OpportunityCompetitorRequest::createRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/add-opportunity-competitor" with no other text, ask which opportunity and for '
			. 'the competitor\'s name. If followed by details, extract the fields directly and proceed to '
			. 'confirmation — skip clarifying questions unless a field is ambiguous.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to log a competitor on an opportunity, first locate the '
			. 'opportunity with the opportunity search tool available to you if its id is not already known, then confirm the competitor\'s '
			. 'details before calling this tool.';
	}

	protected function create(array $validated, array $raw): array
	{
		$repo       = new (Helper::repository('opportunity_competitor'))(new (Helper::model('opportunity_competitor')));
		$competitor = $repo->create($validated,
			before: fn ($data)   => $this->beforeCreate($data, $raw),
			after:  fn ($record) => $this->afterCreate($record, $raw),
		);

		return AiResponse::success(
			[
				'id'           => $competitor->id,
				'name'         => $competitor->name,
				'total_amount' => $competitor->total_amount,
				'rating'       => $competitor->rating,
			],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
