<?php

namespace Solaris\Sales\Ai\Tools\OpportunityTermCondition;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseDeleteAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Models\OpportunityTermCondition;

class DeleteOpportunityTermConditionTool extends BaseDeleteAiTool
{
	public static function slug(): string
	{
		return 'delete_opportunity_term_condition';
	}

	protected function resourceLabel(): string
	{
		return 'opportunity term & condition';
	}

	protected function descriptionExtra(): ?string
	{
		return 'Obtain the id with the opportunity term condition search tool available to you first.';
	}

	protected function findRecordById(string $id): ?OpportunityTermCondition
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('opportunity_term_condition'))(new (Helper::model('opportunity_term_condition')));

		return $repo->find($id);
	}

	protected function delete(Model $record): array
	{
		$repo    = new (Helper::repository('opportunity_term_condition'))(new (Helper::model('opportunity_term_condition')));
		$subject = $record->subject;
		$repo->delete($record->id);

		return AiResponse::success(
			['deleted' => $subject],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
