<?php

namespace Solaris\Sales\Ai\Tools\OpportunityTermCondition;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseCreateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Http\Requests\OpportunityTermConditionRequest;

class CreateOpportunityTermConditionTool extends BaseCreateAiTool
{
	public static function slug(): string
	{
		return 'create_opportunity_term_condition';
	}

	protected function resourceLabel(): string
	{
		return 'opportunity term & condition';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'opportunity_id' => $schema->string()
				->description('The opportunity id to attach this term to. Obtain it with the opportunity search tool available to you first.')
				->required(),
			'subject' => $schema->string()
				->description('Text of the term/condition.')
				->required(),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::reference(column: 'opportunity_id', label: 'opportunity', modelKey: 'opportunity'),
		];
	}

	protected function rules(): array
	{
		return OpportunityTermConditionRequest::createRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/add-opportunity-term" with no other text, ask which opportunity and for the '
			. 'term text. If followed by details, extract the fields directly and proceed to confirmation — skip '
			. 'clarifying questions unless a field is ambiguous.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to add a term or condition to an opportunity, first locate the '
			. 'opportunity with the opportunity search tool available to you if its id is not already known, then confirm the term text before '
			. 'calling this tool.';
	}

	protected function create(array $validated, array $raw): array
	{
		$repo = new (Helper::repository('opportunity_term_condition'))(new (Helper::model('opportunity_term_condition')));
		$term = $repo->create($validated,
			before: fn ($data)   => $this->beforeCreate($data, $raw),
			after:  fn ($record) => $this->afterCreate($record, $raw),
		);

		return AiResponse::success(
			['id' => $term->id, 'subject' => $term->subject],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
