<?php

namespace Solaris\Sales\Ai\Tools\OpportunityTermCondition;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

class SearchOpportunityTermConditionTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_opportunity_term_condition';
	}

	protected function resourceLabel(): string
	{
		return 'opportunity terms & conditions — free-text terms and conditions attached to a sales opportunity';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('opportunity_term_condition'))();
	}

	protected function fields(): array
	{
		return [
			'opportunity_id' => AiSearchColumn::reference(
				column: 'opportunity_id',
				description: 'The opportunity id this term is attached to. Obtain it with the opportunity search tool available to you first.',
				modelKey: 'opportunity',
			),
			'subject' => AiSearchColumn::string(
				column: 'subject',
				description: 'Text of the term/condition',
				searchable: true,
			),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'             => $record->id,
			'_opportunity_id' => $record->opportunity_id,
			'subject'         => $record->subject,
		];
	}
}
