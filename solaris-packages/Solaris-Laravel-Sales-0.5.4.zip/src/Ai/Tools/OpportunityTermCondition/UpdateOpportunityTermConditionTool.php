<?php

namespace Solaris\Sales\Ai\Tools\OpportunityTermCondition;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseUpdateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Http\Requests\OpportunityTermConditionRequest;
use Solaris\Sales\Models\OpportunityTermCondition;

class UpdateOpportunityTermConditionTool extends BaseUpdateAiTool
{
	public static function slug(): string
	{
		return 'update_opportunity_term_condition';
	}

	protected function resourceLabel(): string
	{
		return 'opportunity term & condition';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'id' => $schema->string()
				->description('The opportunity term id. Required. Obtain with the opportunity term condition search tool available to you.')
				->required(),
			'subject' => $schema->string()->description('New text of the term/condition.'),
		];
	}

	protected function rules(): array
	{
		return OpportunityTermConditionRequest::updateRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/update-opportunity-term" with no other text, ask which term and what to change. '
			. 'If followed by a description of the change, extract the field directly and proceed to confirmation.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to change a term/condition, first locate it via '
			. 'the opportunity term condition search tool if its id is not already known, then confirm the new text before '
			. 'calling this tool.';
	}

	protected function findRecordById(string $id): ?OpportunityTermCondition
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('opportunity_term_condition'))(new (Helper::model('opportunity_term_condition')));

		return $repo->find($id);
	}

	protected function currentData(mixed $record): array
	{
		return [
			'subject' => $record->subject,
		];
	}

	protected function update(mixed $record, array $validated, array $changes): array
	{
		$repo = new (Helper::repository('opportunity_term_condition'))(new (Helper::model('opportunity_term_condition')));
		$term = $repo->update($record->id, $validated,
			before: fn ($record, $data) => $this->beforeUpdate($record, $data, $changes),
			after:  fn ($record)        => $this->afterUpdate($record, $changes),
		);

		return AiResponse::success(
			['id' => $term->id, 'subject' => $term->subject, 'updated' => array_keys($changes)],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
