<?php

namespace Solaris\Sales\Ai\Tools\InvoiceDetail;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseDeleteAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Models\InvoiceDetail;

class DeleteInvoiceDetailTool extends BaseDeleteAiTool
{
	public static function slug(): string
	{
		return 'delete_invoice_detail';
	}

	protected function resourceLabel(): string
	{
		return 'invoice line item';
	}

	protected function findRecordById(string $id): ?InvoiceDetail
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('invoice_detail'))(new (Helper::model('invoice_detail')));

		return $repo->find($id);
	}

	protected function delete(Model $record): array
	{
		$repo    = new (Helper::repository('invoice_detail'))(new (Helper::model('invoice_detail')));
		$product = $record->product?->name;
		$repo->delete($record->id);

		return AiResponse::success(
			['deleted' => $product ?? $record->id],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
