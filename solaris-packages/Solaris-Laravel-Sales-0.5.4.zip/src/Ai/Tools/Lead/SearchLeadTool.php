<?php

namespace Solaris\Sales\Ai\Tools\Lead;

use Solaris\BaseCRM\Ai\Tools\Lead\SearchLeadTool as BaseSearchLeadTool;

class SearchLeadTool extends BaseSearchLeadTool
{
	protected function relations(): array
	{
		return array_merge(parent::relations(), [
			'opportunity' => 'search_opportunity',
		]);
	}
}
