<?php

namespace Solaris\Sales\Ai\Tools\Lead;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Laravel\Ai\Tools\Request;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseConfirmAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Repositories\LeadRepository;
use Stringable;

class HotLeadTool extends BaseConfirmAiTool
{
	public static function slug(): string
	{
		return 'hot_lead';
	}

	public function description(): Stringable|string
	{
		return 'Qualify a lead and convert it into a sales opportunity ("hot lead"). '
			. 'Requires the lead id — obtain it first with the lead search tool available to you. Only allowed when the lead is in '
			. 'Nurturing or Qualified status, has no opportunity yet, and is linked to at least an account '
			. 'or a contact. '
			. 'Call this tool NOW as soon as the lead to convert is known — do NOT wait for approval before '
			. 'calling it, and do NOT compose a confirmation message yourself without calling it first. '
			. 'Requires confirmation before converting — see the confirmation protocol (pass the same '
			. 'lead_id again on every subsequent call). '
			. 'Present the lead name and current status to the user and ask them to confirm the conversion.';
	}

	public function schema(JsonSchema $schema): array
	{
		return array_merge([
			'lead_id' => $schema->string()
				->description('The lead id to convert into an opportunity. Required.')
				->required(),
		], $this->confirmationSchema($schema));
	}

	public function validateConfirmation(Request $request): array
	{
		$id = trim((string) ($request['lead_id'] ?? ''));

		if ($id === '') {
			return AiResponse::error(AiErrorCode::UserError, 'lead_id is required.');
		}

		$lead = (new (Helper::repository('lead'))(new (Helper::model('lead'))))->find($id);

		if ($lead === null) {
			return AiResponse::error(AiErrorCode::NotFound, 'Lead not found.');
		}

		$error = LeadRepository::hotLeadValidationError($lead);

		if ($error !== null) {
			return AiResponse::error(AiErrorCode::BusinessRule, $error);
		}

		return [
			'payload' => ['lead_id' => $lead->id],
			'summary' => [
				'lead'           => $lead->name,
				'current_status' => $lead->status?->name,
				'action'         => 'create opportunity',
			],
		];
	}

	public function executeConfirmed(Request $request, array $payload): array
	{
		try {
			$opportunity = (new (Helper::repository('lead'))(new (Helper::model('lead'))))
				->hotLead($payload['lead_id']);
		} catch (\Exception $e) {
			return AiResponse::error(AiErrorCode::SystemError, 'The lead could not be converted due to a system issue.', debug: $e->getMessage());
		}

		return AiResponse::success(
			['opportunity_id' => $opportunity->id, 'opportunity_name' => $opportunity->name],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language that the lead '
				. 'was qualified and a new opportunity was created.',
		);
	}
}
