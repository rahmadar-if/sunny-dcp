<?php

namespace Solaris\Sales\Ai\Tools\Invoice;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseDeleteAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Models\Invoice;

class DeleteInvoiceTool extends BaseDeleteAiTool
{
	public static function slug(): string
	{
		return 'delete_invoice';
	}

	protected function resourceLabel(): string
	{
		return 'invoice';
	}

	protected function findRecordById(string $id): ?Invoice
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('invoice'))(new (Helper::model('invoice')));

		return $repo->find($id);
	}

	protected function delete(Model $record): array
	{
		$repo = new (Helper::repository('invoice'))(new (Helper::model('invoice')));
		$repo->delete($record->id);

		return AiResponse::success(
			['deleted' => $record->number],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
