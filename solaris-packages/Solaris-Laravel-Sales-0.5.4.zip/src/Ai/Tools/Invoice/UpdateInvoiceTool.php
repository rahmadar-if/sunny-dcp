<?php

namespace Solaris\Sales\Ai\Tools\Invoice;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Support\Arr;
use Laravel\Ai\Tools\Request;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseUpdateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Ai\Tools\Activity\CreateActivityTool;
use Solaris\Sales\Ai\Tools\InvoiceDetail\CreateInvoiceDetailTool;
use Solaris\Sales\Http\Requests\ActivityRequest;
use Solaris\Sales\Http\Requests\InvoiceDetailRequest;
use Solaris\Sales\Http\Requests\InvoiceRequest;
use Solaris\Sales\Models\Invoice;

class UpdateInvoiceTool extends BaseUpdateAiTool
{
	public static function slug(): string
	{
		return 'update_invoice';
	}

	protected function resourceLabel(): string
	{
		return 'invoice';
	}

	public static function fields(JsonSchema $schema): array
	{
		$detailFields   = Arr::except(CreateInvoiceDetailTool::fields($schema), ['invoice_id']);
		$activityFields = CreateActivityTool::fields($schema);

		$detailMeta = [
			'id'     => $schema->string()->description('Existing record id. Omit to create a new one.'),
			'delete' => $schema->boolean()->description('Set true (with id) to remove this record instead of updating it.'),
		];

		return [
			'id' => $schema->string()
				->description('The invoice id. Required.')
				->required(),
			'due_date'   => $schema->string()->description('New due date in Y-m-d format.'),
			'account_id' => $schema->string()->description('New account this invoice is for. Obtain it with the account search tool available to you first.'),
			'contact_id' => $schema->string()->description('New contact this invoice is for. Obtain it with the contact search tool available to you first.'),
			'status_id'  => $schema->string()->description('New invoice status. Resolve via lookup_options with type: "invoice_status".'),
			'notes'      => $schema->string()->description('Free-text notes about the invoice.'),
			'detail_invoice_details' => $schema->array()->items($schema->object(array_merge($detailMeta, $detailFields)))->description(
				'Manage product line items in the same confirmation — omit id to add a new one (resolve the '
					. 'product with the product search tool available to you active=true first), pass id with qty/price/discount to update an '
					. 'existing one, pass id with delete:true to remove one. Supports multiple. Optional.'
			),
			'detail_activities' => $schema->array()->items($schema->object(array_merge($detailMeta, $activityFields)))->description(
				'Manage activities under this invoice — omit id to add a new one, pass id with fields to update, '
					. 'pass id with delete:true to remove. Supports multiple. Optional.'
			),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::reference(column: 'account_id', label: 'account', modelKey: 'account'),
			AiColumn::reference(column: 'contact_id', label: 'contact', modelKey: 'contact'),
			AiColumn::lookup(column: 'status_id', label: 'invoice status', modelKey: 'invoice_status'),
		];
	}

	protected function rules(): array
	{
		return InvoiceRequest::updateRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/update-invoice" with no other text, ask which invoice and what to change. '
			. 'If followed by a description of the changes, extract the fields directly and proceed to confirmation — '
			. 'skip clarifying questions unless a field is ambiguous.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to edit or update an invoice, first locate it with the invoice search tool available to you if '
			. 'the id is not already known, then confirm the changes before calling this tool. To change the status '
			. '(e.g. mark issued or completed), resolve the target status by name via lookup_options and pass it as '
			. 'status_id — the issued/completed date is set automatically.'
			. "\n\n"
			. 'DETAILS: If the user also wants to add, change, or remove line items or activities under this invoice '
			. 'in the same request, pass them via detail_invoice_details/detail_activities instead of calling their '
			. 'own tools — everything is applied together in this same confirmation. Omit id to add, pass id with '
			. 'fields to change one, pass id with delete:true to remove one. Resolve each new product via '
			. 'the product search tool (active=true) first, and get existing line ids with the invoice detail search tool available to you. Line totals '
			. 'and the invoice amount are computed automatically — never set them.';
	}

	protected function findRecordById(string $id): ?Invoice
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('invoice'))(new (Helper::model('invoice')));

		return $repo->find($id);
	}

	protected function currentData(mixed $record): array
	{
		return [
			'due_date'   => $record->due_date?->format('Y-m-d'),
			'amount'     => $record->amount,
			'account_id' => $record->account_id,
			'contact_id' => $record->contact_id,
			'status_id'  => $record->status_id,
			'notes'      => $record->notes,
		];
	}

	public function validateConfirmation(Request $request): array
	{
		$result = parent::validateConfirmation($request);

		if (isset($result['error'])) {
			return $result;
		}

		$invoiceId = trim((string) ($request['id'] ?? ''));

		$specs = [
			'detail_invoice_details' => [Helper::model('invoice_detail'), InvoiceDetailRequest::createRules(), InvoiceDetailRequest::updateRules(), 'line items'],
			'detail_activities'      => [Helper::model('activity'),       ActivityRequest::createRules(),      ActivityRequest::updateRules(),      'activities'],
		];

		foreach ($specs as $key => [$model, $createRules, $updateRules, $label]) {
			[$ops, $errors] = $this->resolveDetailOperations(
				(array) ($request[$key] ?? []), $model, $createRules, $updateRules, 'invoice_id', $invoiceId,
			);

			if (!empty($errors)) {
				return AiResponse::error(AiErrorCode::UserError, "One or more {$label} failed validation.", ['messages' => $errors]);
			}

			$result['payload']['changes'][$key] = $ops;

			if (!empty($ops['create']) || !empty($ops['update']) || !empty($ops['delete'])) {
				$result['summary'][$key] = [
					'add'    => count($ops['create']),
					'update' => count($ops['update']),
					'delete' => count($ops['delete']),
				];
			}
		}

		return $result;
	}

	protected function excludedChangeKeys(): array
	{
		return ['detail_invoice_details', 'detail_activities'];
	}

	protected function afterUpdate(mixed $record, array $changes): void
	{
		$groups = [
			'invoice_detail' => $changes['detail_invoice_details'] ?? null,
			'activity'       => $changes['detail_activities'] ?? null,
		];

		foreach ($groups as $modelKey => $ops) {
			$ops = $ops ?? ['create' => [], 'update' => [], 'delete' => []];

			if (empty($ops['create']) && empty($ops['update']) && empty($ops['delete'])) {
				continue;
			}

			$repo = new (Helper::repository($modelKey))(new (Helper::model($modelKey)), transaction: false);

			foreach ($ops['create'] as $data) {
				$repo->create($data);
			}

			foreach ($ops['update'] as $id => $data) {
				$repo->update($id, $data);
			}

			foreach ($ops['delete'] as $id) {
				$repo->delete($id);
			}
		}
	}

	protected function update(mixed $record, array $validated, array $changes): array
	{
		$repo = new (Helper::repository('invoice'))(new (Helper::model('invoice')));
		$repo->update($record->id, $validated,
			before: fn ($record, $data) => $this->beforeUpdate($record, $data, $changes),
			after:  fn ($record)        => $this->afterUpdate($record, $changes),
		);

		$fieldChanges = collect($changes)->except($this->excludedChangeKeys())->all();

		return AiResponse::success(
			[
				'id'      => $record->id,
				'number'  => $record->number,
				'updated' => array_keys($fieldChanges),
			],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
