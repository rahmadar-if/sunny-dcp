<?php

namespace Solaris\Sales\Ai\Tools\Invoice;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Arr;
use Illuminate\Support\Str;
use Laravel\Ai\Tools\Request;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseCreateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Ai\Tools\Activity\CreateActivityTool;
use Solaris\Sales\Ai\Tools\InvoiceDetail\CreateInvoiceDetailTool;
use Solaris\Sales\Http\Requests\ActivityRequest;
use Solaris\Sales\Http\Requests\InvoiceDetailRequest;
use Solaris\Sales\Http\Requests\InvoiceRequest;

class CreateInvoiceTool extends BaseCreateAiTool
{
	public static function slug(): string
	{
		return 'create_invoice';
	}

	protected function resourceLabel(): string
	{
		return 'invoice';
	}

	public static function fields(JsonSchema $schema): array
	{
		$detailFields   = Arr::except(CreateInvoiceDetailTool::fields($schema), ['invoice_id']);
		$activityFields = CreateActivityTool::fields($schema);

		return [
			'subject' => $schema->string()
				->description('Subject/title of the invoice.')
				->required(),
			'order_id' => $schema->string()
				->description(
					'The order this invoice is billed against. Obtain it with the order search tool available to you first. The invoice '
						. 'number, customer, contact, amount and its initial line items are all copied automatically '
						. 'from this order.'
				)
				->required(),
			'notes' => $schema->string()->description('Free-text notes about the invoice.'),
			'detail_invoice_details' => $schema->array()->items($schema->object($detailFields))->description(
				'EXTRA product line items to add on top of the ones copied from the order, each linked '
					. 'automatically. Resolve each product with the product search tool available to you (active=true) first. Only pass this if '
					. 'the user wants line items beyond what the order already carries. Supports multiple. Optional.'
			),
			'detail_activities' => $schema->array()->items($schema->object($activityFields))->description(
				'Activities/tasks to schedule under this invoice, each linked automatically. Supports multiple. Optional.'
			),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::reference(column: 'order_id', label: 'order', modelKey: 'order'),
		];
	}

	protected function rules(): array
	{
		return InvoiceRequest::createRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/add-invoice" with no other text, ask which order to bill and the invoice subject. '
			. 'If followed by details, extract them and proceed to confirmation — skip clarifying questions unless '
			. 'something is ambiguous.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to create/issue an invoice for an order, locate the order via '
			. 'the order search tool first, then confirm before calling this tool. The customer, contact, amount and line '
			. 'items are derived from the order — never ask the user to re-enter those.'
			. "\n\n"
			. 'DETAILS: Only pass detail_invoice_details if the user wants EXTRA line items beyond those copied from '
			. 'the order. Pass detail_activities to schedule activities under the invoice in the same request, '
			. 'instead of calling their own tools. Line totals and the invoice amount are computed automatically — '
			. 'never set them.';
	}

	public function validateConfirmation(Request $request): array
	{
		$result = parent::validateConfirmation($request);

		if (isset($result['error'])) {
			return $result;
		}

		// Self-generated ahead of insert — BaseModel uses HasUuids, which respects an id already set on the
		// data array. Knowing it up front lets detail_* rows (which require invoice_id) validate for real.
		$invoiceId = (string) Str::uuid7();

		[$details, $errors] = $this->validateDetailList((array) ($request['detail_invoice_details'] ?? []), InvoiceDetailRequest::createRules(), 'invoice_id', $invoiceId);
		if (!empty($errors)) {
			return AiResponse::error(AiErrorCode::UserError,'One or more invoice line items failed validation.', ['messages' => $errors]);
		}

		[$activities, $errors] = $this->validateDetailList((array) ($request['detail_activities'] ?? []), ActivityRequest::createRules(), 'invoice_id', $invoiceId);
		if (!empty($errors)) {
			return AiResponse::error(AiErrorCode::UserError,'One or more activities failed validation.', ['messages' => $errors]);
		}

		$result['payload']['raw']['id']                     = $invoiceId;
		$result['payload']['raw']['detail_invoice_details'] = $details;
		$result['payload']['raw']['detail_activities']      = $activities;

		if (!empty($details)) {
			$result['summary']['detail_invoice_details'] = count($details) . ' extra line item(s)';
		}

		if (!empty($activities)) {
			$result['summary']['detail_activities'] = array_map(fn ($a) => $a['subject'], $activities);
		}

		return $result;
	}

	protected function afterCreate(Model $record, array $raw): void
	{
		$groups = [
			'invoice_detail' => $raw['detail_invoice_details'] ?? [],
			'activity'       => $raw['detail_activities'] ?? [],
		];

		foreach ($groups as $modelKey => $rows) {
			if (empty($rows)) {
				continue;
			}

			$repo = new (Helper::repository($modelKey))(new (Helper::model($modelKey)), transaction: false);

			foreach ($rows as $data) {
				$repo->create($data);
			}
		}
	}

	protected function create(array $validated, array $raw): array
	{
		$validated['id'] = $raw['id'] ?? (string) Str::uuid7();

		$repo    = new (Helper::repository('invoice'))(new (Helper::model('invoice')));
		$invoice = $repo->create($validated,
			before: fn ($data)   => $this->beforeCreate($data, $raw),
			after:  fn ($record) => $this->afterCreate($record, $raw),
		);

		return AiResponse::success(
			['id' => $invoice->id, 'number' => $invoice->number, 'subject' => $invoice->subject],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
