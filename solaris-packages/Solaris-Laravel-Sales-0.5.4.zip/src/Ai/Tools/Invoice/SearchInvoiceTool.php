<?php

namespace Solaris\Sales\Ai\Tools\Invoice;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Services\Filter;

class SearchInvoiceTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_invoice';
	}

	protected function resourceLabel(): string
	{
		return 'invoices — billing documents issued against an order';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('invoice'))();
	}

	protected function fields(): array
	{
		return [
			'number' => AiSearchColumn::string(
				column: 'number',
				description: 'Invoice number',
				searchable: true,
			),
			'subject' => AiSearchColumn::string(
				column: 'subject',
				description: 'Subject of the invoice',
				searchable: true,
			),
			'notes_plain' => AiSearchColumn::string(
				column: 'notes_plain',
				description: 'Plain text notes about the invoice',
				operators: [Filter::Contains, Filter::FullText],
				searchable: 'FullText',
			),
			'issued_date' => AiSearchColumn::date('issued_date', 'Date the invoice was issued'),
			'due_date' => AiSearchColumn::date('due_date', 'Date the invoice payment is due'),
			'completed_at' => AiSearchColumn::date('completed_at', 'Date the invoice was paid/completed'),
			'amount' => AiSearchColumn::number('amount', 'Invoice amount'),
			'status_id' => AiSearchColumn::lookup(
				column: 'status_id',
				description: 'Current status of the invoice',
				modelKey: 'invoice_status',
			),
			'account_id' => AiSearchColumn::reference(
				column: 'account_id',
				description: 'The account this invoice is for. Obtain it with the account search tool available to you first.',
				modelKey: 'account',
			),
			'contact_id' => AiSearchColumn::reference(
				column: 'contact_id',
				description: 'The contact this invoice is for. Obtain it with the contact search tool available to you first.',
				modelKey: 'contact',
			),
			'order_id' => AiSearchColumn::reference(
				column: 'order_id',
				description: 'The order this invoice was issued against. Obtain it with the order search tool available to you first.',
				modelKey: 'order',
			),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'         => $record->id,
			'_account_id' => $record->account_id,
			'_contact_id' => $record->contact_id,
			'_order_id'   => $record->order_id,
			'number'      => $record->number,
			'subject'     => $record->subject,
			'account'     => $record->account?->name,
			'contact'     => $record->contact?->name,
			'order'       => $record->order?->number,
			'status'      => $record->status?->name,
			'issued_date' => $record->issued_date ? Carbon::parse($record->issued_date)->format('d M Y') : null,
			'due_date'    => $record->due_date ? Carbon::parse($record->due_date)->format('d M Y') : null,
			'amount'      => $record->amount,
		];
	}

	protected function relations(): array
	{
		return [
			'detail'         => 'search_invoice_detail',
			'status_history' => 'search_invoice_status_history',
			'activities'     => 'search_activity',
		];
	}
}
