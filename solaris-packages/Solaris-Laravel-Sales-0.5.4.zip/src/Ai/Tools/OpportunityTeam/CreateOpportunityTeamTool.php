<?php

namespace Solaris\Sales\Ai\Tools\OpportunityTeam;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseCreateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Http\Requests\OpportunityTeamRequest;

class CreateOpportunityTeamTool extends BaseCreateAiTool
{
	public static function slug(): string
	{
		return 'create_opportunity_team';
	}

	protected function resourceLabel(): string
	{
		return 'opportunity team member';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'opportunity_id' => $schema->string()
				->description('The opportunity id to add this team member to. Obtain it with the opportunity search tool available to you first.')
				->required(),
			'name' => $schema->string()
				->description('Name of the team member.')
				->required(),
			'role' => $schema->string()
				->description('Role of this team member on the opportunity (e.g. Account Manager, Presales).')
				->required(),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::reference(column: 'opportunity_id', label: 'opportunity', modelKey: 'opportunity'),
		];
	}

	protected function rules(): array
	{
		return OpportunityTeamRequest::createRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/add-opportunity-team" with no other text, ask which opportunity and for the '
			. 'team member\'s name and role. If followed by details, extract the fields directly and proceed to '
			. 'confirmation — skip clarifying questions unless a field is ambiguous.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to add someone to the deal team, first locate the opportunity via '
			. 'the opportunity search tool if its id is not already known, then confirm the name and role before calling '
			. 'this tool.';
	}

	protected function create(array $validated, array $raw): array
	{
		$repo   = new (Helper::repository('opportunity_team'))(new (Helper::model('opportunity_team')));
		$member = $repo->create($validated,
			before: fn ($data)   => $this->beforeCreate($data, $raw),
			after:  fn ($record) => $this->afterCreate($record, $raw),
		);

		return AiResponse::success(
			['id' => $member->id, 'name' => $member->name, 'role' => $member->role],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
