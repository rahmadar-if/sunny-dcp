<?php

namespace Solaris\Sales\Ai\Tools\OpportunityTeam;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

class SearchOpportunityTeamTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_opportunity_team';
	}

	protected function resourceLabel(): string
	{
		return 'opportunity team members — the internal people working a sales opportunity, with their role on the deal';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('opportunity_team'))();
	}

	protected function fields(): array
	{
		return [
			'opportunity_id' => AiSearchColumn::reference(
				column: 'opportunity_id',
				description: 'The opportunity id this team member belongs to. Obtain it with the opportunity search tool available to you first.',
				modelKey: 'opportunity',
			),
			'name' => AiSearchColumn::string(
				column: 'name',
				description: 'Name of the team member',
				searchable: true,
			),
			'role' => AiSearchColumn::string(
				column: 'role',
				description: 'Role of this team member on the opportunity',
				searchable: true,
			),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'             => $record->id,
			'_opportunity_id' => $record->opportunity_id,
			'name'            => $record->name,
			'role'            => $record->role,
		];
	}
}
