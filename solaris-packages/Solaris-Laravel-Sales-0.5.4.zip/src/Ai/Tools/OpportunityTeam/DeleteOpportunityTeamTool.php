<?php

namespace Solaris\Sales\Ai\Tools\OpportunityTeam;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseDeleteAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Models\OpportunityTeam;

class DeleteOpportunityTeamTool extends BaseDeleteAiTool
{
	public static function slug(): string
	{
		return 'delete_opportunity_team';
	}

	protected function resourceLabel(): string
	{
		return 'opportunity team member';
	}

	protected function descriptionExtra(): ?string
	{
		return 'Obtain the id with the opportunity team search tool available to you first.';
	}

	protected function findRecordById(string $id): ?OpportunityTeam
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('opportunity_team'))(new (Helper::model('opportunity_team')));

		return $repo->find($id);
	}

	protected function delete(Model $record): array
	{
		$repo = new (Helper::repository('opportunity_team'))(new (Helper::model('opportunity_team')));
		$name = $record->name;
		$repo->delete($record->id);

		return AiResponse::success(
			['deleted' => $name],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
