<?php

namespace Solaris\Sales\Ai\Tools\OpportunityTeam;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseUpdateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Http\Requests\OpportunityTeamRequest;
use Solaris\Sales\Models\OpportunityTeam;

class UpdateOpportunityTeamTool extends BaseUpdateAiTool
{
	public static function slug(): string
	{
		return 'update_opportunity_team';
	}

	protected function resourceLabel(): string
	{
		return 'opportunity team member';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'id' => $schema->string()
				->description('The opportunity team member id. Required. Obtain with the opportunity team search tool available to you.')
				->required(),
			'name' => $schema->string()->description('New name of the team member.'),
			'role' => $schema->string()->description('New role of this team member on the opportunity.'),
		];
	}

	protected function rules(): array
	{
		return OpportunityTeamRequest::updateRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/update-opportunity-team" with no other text, ask which team member and what to '
			. 'change. If followed by a description of the changes, extract the fields directly and proceed to '
			. 'confirmation — skip clarifying questions unless a field is ambiguous.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to change a deal team member\'s name or role, first locate the '
			. 'record with the opportunity team search tool available to you if its id is not already known, then confirm the changes before '
			. 'calling this tool.';
	}

	protected function findRecordById(string $id): ?OpportunityTeam
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('opportunity_team'))(new (Helper::model('opportunity_team')));

		return $repo->find($id);
	}

	protected function currentData(mixed $record): array
	{
		return [
			'name' => $record->name,
			'role' => $record->role,
		];
	}

	protected function update(mixed $record, array $validated, array $changes): array
	{
		$repo   = new (Helper::repository('opportunity_team'))(new (Helper::model('opportunity_team')));
		$member = $repo->update($record->id, $validated,
			before: fn ($record, $data) => $this->beforeUpdate($record, $data, $changes),
			after:  fn ($record)        => $this->afterUpdate($record, $changes),
		);

		return AiResponse::success(
			['id' => $member->id, 'name' => $member->name, 'role' => $member->role, 'updated' => array_keys($changes)],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
