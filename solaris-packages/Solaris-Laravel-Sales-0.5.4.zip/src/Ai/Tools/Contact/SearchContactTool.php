<?php

namespace Solaris\Sales\Ai\Tools\Contact;

use Solaris\BaseCRM\Ai\Tools\Contact\SearchContactTool as BaseSearchContactTool;

class SearchContactTool extends BaseSearchContactTool
{
	// orders/invoices/contracts/opportunity_contacts relations added once search_order/search_invoice/
	// search_contract/search_opportunity_contact exist.
	protected function relations(): array
	{
		return array_merge(parent::relations(), [
			'opportunities' => 'search_opportunity',
		]);
	}
}
