<?php

namespace Solaris\Sales\Ai\Tools\OpportunityContact;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseDeleteAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Models\OpportunityContact;

class DeleteOpportunityContactTool extends BaseDeleteAiTool
{
	public static function slug(): string
	{
		return 'delete_opportunity_contact';
	}

	protected function resourceLabel(): string
	{
		return 'opportunity contact';
	}

	protected function descriptionExtra(): ?string
	{
		return 'Obtain the id with the opportunity contact search tool available to you first. This only removes the link between the '
			. 'contact and the opportunity — it does not delete the contact record itself.';
	}

	protected function findRecordById(string $id): ?OpportunityContact
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('opportunity_contact'))(new (Helper::model('opportunity_contact')));

		return $repo->find($id);
	}

	protected function delete(Model $record): array
	{
		$repo = new (Helper::repository('opportunity_contact'))(new (Helper::model('opportunity_contact')));
		$name = $record->contact?->name;
		$repo->delete($record->id);

		return AiResponse::success(
			['deleted' => $name],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
