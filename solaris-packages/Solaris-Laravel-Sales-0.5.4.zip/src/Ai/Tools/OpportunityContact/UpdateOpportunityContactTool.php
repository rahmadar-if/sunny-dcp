<?php

namespace Solaris\Sales\Ai\Tools\OpportunityContact;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseUpdateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Http\Requests\OpportunityContactRequest;
use Solaris\Sales\Models\OpportunityContact;

class UpdateOpportunityContactTool extends BaseUpdateAiTool
{
	public static function slug(): string
	{
		return 'update_opportunity_contact';
	}

	protected function resourceLabel(): string
	{
		return 'opportunity contact';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'id' => $schema->string()
				->description('The opportunity contact id. Required. Obtain with the opportunity contact search tool available to you.')
				->required(),
			'contact_id' => $schema->string()->description('New contact id to link. Obtain with the contact search tool available to you.'),
			'role' => $schema->string()->description('New role for this contact on the opportunity.'),
			'is_decision_maker' => $schema->boolean()->description('Whether this contact is the decision maker.'),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::reference(column: 'contact_id', label: 'contact', modelKey: 'contact'),
		];
	}

	protected function rules(): array
	{
		return OpportunityContactRequest::updateRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/update-opportunity-contact" with no other text, ask which contact link and what '
			. 'to change. If followed by a description of the changes, extract the fields directly and proceed to '
			. 'confirmation — skip clarifying questions unless a field is ambiguous.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to change a linked contact\'s role or decision-maker status, first '
			. 'locate the record with the opportunity contact search tool available to you if its id is not already known, then confirm the '
			. 'changes before calling this tool.'
			. "\n\n"
			. 'DECISION MAKER: Setting is_decision_maker=true automatically demotes any other contact currently '
			. 'marked as decision maker on the same opportunity, and updates the opportunity\'s own decision maker '
			. 'field to this contact — never call update_opportunity separately for that.';
	}

	protected function findRecordById(string $id): ?OpportunityContact
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('opportunity_contact'))(new (Helper::model('opportunity_contact')));

		return $repo->find($id);
	}

	protected function currentData(mixed $record): array
	{
		return [
			'contact_id'        => $record->contact_id,
			'role'              => $record->role,
			'is_decision_maker' => $record->is_decision_maker,
		];
	}

	protected function update(mixed $record, array $validated, array $changes): array
	{
		$repo    = new (Helper::repository('opportunity_contact'))(new (Helper::model('opportunity_contact')));
		$contact = $repo->update($record->id, $validated,
			before: fn ($record, $data) => $this->beforeUpdate($record, $data, $changes),
			after:  fn ($record)        => $this->afterUpdate($record, $changes),
		);

		return AiResponse::success(
			[
				'id'                => $contact->id,
				'contact'           => $contact->contact?->name,
				'role'              => $contact->role,
				'is_decision_maker' => $contact->is_decision_maker,
				'updated'           => array_keys($changes),
			],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
