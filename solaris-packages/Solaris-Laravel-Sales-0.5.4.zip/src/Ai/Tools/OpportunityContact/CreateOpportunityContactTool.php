<?php

namespace Solaris\Sales\Ai\Tools\OpportunityContact;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseCreateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Http\Requests\OpportunityContactRequest;

class CreateOpportunityContactTool extends BaseCreateAiTool
{
	public static function slug(): string
	{
		return 'create_opportunity_contact';
	}

	protected function resourceLabel(): string
	{
		return 'opportunity contact';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'opportunity_id' => $schema->string()
				->description('The opportunity id to link this contact to. Obtain it with the opportunity search tool available to you first.')
				->required(),
			'contact_id' => $schema->string()
				->description('The contact id to link. Obtain it with the contact search tool available to you first.')
				->required(),
			'role' => $schema->string()
				->description('This person\'s role in relation to the opportunity (e.g. Procurement, Finance).')
				->required(),
			'is_decision_maker' => $schema->boolean()
				->description('Whether this contact is the decision maker for the opportunity. Defaults to false.'),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::reference(column: 'opportunity_id', label: 'opportunity', modelKey: 'opportunity'),
			AiColumn::reference(column: 'contact_id', label: 'contact', modelKey: 'contact'),
		];
	}

	protected function rules(): array
	{
		return OpportunityContactRequest::createRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/add-opportunity-contact" with no other text, ask which opportunity and which '
			. 'contact to link. If followed by details, extract the fields directly and proceed to confirmation — '
			. 'skip clarifying questions unless a field is ambiguous.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to link a contact to an opportunity, first locate the opportunity '
			. 'with the opportunity search tool available to you and the contact with the contact search tool available to you if their ids are not already known, then '
			. 'confirm the role (and whether they are the decision maker) before calling this tool.'
			. "\n\n"
			. 'DECISION MAKER: Setting is_decision_maker=true automatically demotes any other contact currently '
			. 'marked as decision maker on the same opportunity, and updates the opportunity\'s own decision maker '
			. 'field to this contact — never call update_opportunity separately for that.';
	}

	protected function create(array $validated, array $raw): array
	{
		$repo    = new (Helper::repository('opportunity_contact'))(new (Helper::model('opportunity_contact')));
		$contact = $repo->create($validated,
			before: fn ($data)   => $this->beforeCreate($data, $raw),
			after:  fn ($record) => $this->afterCreate($record, $raw),
		);

		return AiResponse::success(
			[
				'id'                => $contact->id,
				'contact'           => $contact->contact?->name,
				'role'              => $contact->role,
				'is_decision_maker' => $contact->is_decision_maker,
			],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
