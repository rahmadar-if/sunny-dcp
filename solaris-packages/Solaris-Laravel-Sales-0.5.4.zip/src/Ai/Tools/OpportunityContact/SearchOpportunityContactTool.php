<?php

namespace Solaris\Sales\Ai\Tools\OpportunityContact;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

class SearchOpportunityContactTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_opportunity_contact';
	}

	protected function resourceLabel(): string
	{
		return 'opportunity contacts — contacts linked to a sales opportunity, with their role and whether they '
			. 'are the decision maker';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('opportunity_contact'))();
	}

	protected function fields(): array
	{
		return [
			'opportunity_id' => AiSearchColumn::reference(
				column: 'opportunity_id',
				description: 'The opportunity id this contact is linked to. Obtain it with the opportunity search tool available to you first.',
				modelKey: 'opportunity',
			),
			'contact_id' => AiSearchColumn::reference(
				column: 'contact_id',
				description: 'The linked contact. Obtain it with the contact search tool available to you first.',
				modelKey: 'contact',
			),
			'role' => AiSearchColumn::string(
				column: 'role',
				description: 'This person\'s role in relation to the opportunity',
				searchable: true,
			),
			'is_decision_maker' => AiSearchColumn::boolean('is_decision_maker', 'Whether this contact is the decision maker for the opportunity'),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'               => $record->id,
			'_opportunity_id'   => $record->opportunity_id,
			'_contact_id'       => $record->contact_id,
			'contact'           => $record->contact?->name,
			'role'              => $record->role,
			'is_decision_maker' => $record->is_decision_maker,
		];
	}
}
