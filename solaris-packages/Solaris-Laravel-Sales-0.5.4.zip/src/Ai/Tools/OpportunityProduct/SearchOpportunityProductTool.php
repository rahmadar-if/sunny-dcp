<?php

namespace Solaris\Sales\Ai\Tools\OpportunityProduct;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Services\Filter;

class SearchOpportunityProductTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_opportunity_product';
	}

	protected function resourceLabel(): string
	{
		return 'opportunity product line items — the products/services quoted within a sales opportunity, '
			. 'each with quantity, unit price, discount, and line total';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('opportunity_product'))();
	}

	protected function fields(): array
	{
		return [
			'opportunity_id' => AiSearchColumn::reference(
				column: 'opportunity_id',
				description: 'The opportunity id this line item belongs to. Obtain it with the opportunity search tool available to you first.',
				modelKey: 'opportunity',
				operators: [Filter::Equal],
			),
			'product_id' => AiSearchColumn::reference(
				column: 'product_id',
				description: 'The product this line item refers to. Obtain it with the product search tool available to you first.',
				modelKey: 'product',
				operators: [Filter::Equal, Filter::In],
			),
			'qty' => AiSearchColumn::string(
				column: 'qty',
				description: 'Quantity',
				operators: [Filter::Equal, Filter::Greater, Filter::Less],
			),
			'price' => AiSearchColumn::string(
				column: 'price',
				description: 'Unit price',
				operators: [Filter::Equal, Filter::Greater, Filter::Less, Filter::Between],
			),
			'disc' => AiSearchColumn::string(
				column: 'disc',
				description: 'Discount amount for this line item',
				operators: [Filter::Equal, Filter::Greater, Filter::Less],
			),
			'total' => AiSearchColumn::string(
				column: 'total',
				description: 'Line total after discount',
				operators: [Filter::Equal, Filter::Greater, Filter::Less, Filter::Between],
			),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'     => $record->id,
			'product' => $record->product?->name,
			'qty'     => $record->qty,
			'price'   => $record->price,
			'disc'    => $record->disc,
			'total'   => $record->total,
		];
	}
}
