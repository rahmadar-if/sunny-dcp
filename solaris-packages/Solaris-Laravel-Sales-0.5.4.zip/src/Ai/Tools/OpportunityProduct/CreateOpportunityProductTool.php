<?php

namespace Solaris\Sales\Ai\Tools\OpportunityProduct;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseCreateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Http\Requests\OpportunityProductRequest;

class CreateOpportunityProductTool extends BaseCreateAiTool
{
	public static function slug(): string
	{
		return 'create_opportunity_product';
	}

	protected function resourceLabel(): string
	{
		return 'opportunity product';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'opportunity_id' => $schema->string()
				->description('The opportunity id to add this product to. Obtain it with the opportunity search tool available to you first.')
				->required(),
			'product_id' => $schema->string()
				->description(
					'The product id to add. Obtain it with the product search tool available to you first, filtered to active=true — '
						. 'inactive products cannot be added.'
				)
				->required(),
			'qty' => $schema->string()
				->description('Quantity as a plain integer.')
				->required(),
			'price' => $schema->string()
				->description(
					'Unit price as a plain number. Use the product\'s listed price from the product search tool '
						. 'unless the user gives a different price.'
				)
				->required(),
			'disc' => $schema->string()->description('Discount amount for this line item as a plain number.'),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::reference(column: 'opportunity_id', label: 'opportunity', modelKey: 'opportunity'),
		];
	}

	protected function rules(): array
	{
		return OpportunityProductRequest::createRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/add-opportunity-product" with no other text, ask which opportunity and which '
			. 'product to add. If followed by details, extract the fields directly and proceed to confirmation — '
			. 'skip clarifying questions unless a field is ambiguous.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to add a product/line item to an opportunity, first locate the '
			. 'opportunity with the opportunity search tool available to you and the product with the product search tool available to you if their ids are not already '
			. 'known, then confirm the line item (product, quantity, price, discount) before calling this tool. '
			. 'When calling the product search tool for this purpose, always filter active=true — inactive products cannot '
			. 'be sold, and this tool will reject the product if it is not active.'
			. "\n\n"
			. 'The line total and the opportunity\'s overall amount/total_amount are recalculated automatically — '
			. 'never ask the user for them or set them directly.';
	}

	protected function create(array $validated, array $raw): array
	{
		$repo    = new (Helper::repository('opportunity_product'))(new (Helper::model('opportunity_product')));
		$product = $repo->create($validated,
			before: fn ($data)   => $this->beforeCreate($data, $raw),
			after:  fn ($record) => $this->afterCreate($record, $raw),
		);

		return AiResponse::success(
			[
				'id'      => $product->id,
				'product' => $product->product?->name,
				'qty'     => $product->qty,
				'price'   => $product->price,
				'disc'    => $product->disc,
				'total'   => $product->total,
			],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
