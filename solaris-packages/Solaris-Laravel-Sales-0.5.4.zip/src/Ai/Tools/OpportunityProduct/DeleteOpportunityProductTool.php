<?php

namespace Solaris\Sales\Ai\Tools\OpportunityProduct;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseDeleteAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Models\OpportunityProduct;

class DeleteOpportunityProductTool extends BaseDeleteAiTool
{
	public static function slug(): string
	{
		return 'delete_opportunity_product';
	}

	protected function resourceLabel(): string
	{
		return 'opportunity product';
	}

	protected function descriptionExtra(): ?string
	{
		return 'Obtain the id with the opportunity product search tool available to you first.';
	}

	protected function findRecordById(string $id): ?OpportunityProduct
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('opportunity_product'))(new (Helper::model('opportunity_product')));

		return $repo->find($id);
	}

	protected function delete(Model $record): array
	{
		$repo = new (Helper::repository('opportunity_product'))(new (Helper::model('opportunity_product')));
		$name = $record->product?->name;
		$repo->delete($record->id);

		return AiResponse::success(
			['deleted' => $name],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language. Also mention '
				. 'that the opportunity\'s total amount was recalculated.',
		);
	}
}
