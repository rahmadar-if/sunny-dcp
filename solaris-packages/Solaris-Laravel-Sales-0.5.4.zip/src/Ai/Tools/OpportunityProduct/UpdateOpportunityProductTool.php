<?php

namespace Solaris\Sales\Ai\Tools\OpportunityProduct;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseUpdateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Http\Requests\OpportunityProductRequest;
use Solaris\Sales\Models\OpportunityProduct;

class UpdateOpportunityProductTool extends BaseUpdateAiTool
{
	public static function slug(): string
	{
		return 'update_opportunity_product';
	}

	protected function resourceLabel(): string
	{
		return 'opportunity product';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'id' => $schema->string()
				->description('The opportunity product (line item) id. Required. Obtain with the opportunity product search tool available to you.')
				->required(),
			'qty' => $schema->string()->description('New quantity as a plain integer.'),
			'price' => $schema->string()->description('New unit price as a plain number.'),
			'disc' => $schema->string()->description('New discount amount for this line item as a plain number.'),
		];
	}

	protected function rules(): array
	{
		return OpportunityProductRequest::updateRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/update-opportunity-product" with no other text, ask which line item and what to '
			. 'change. If followed by a description of the changes, extract the fields directly and proceed to '
			. 'confirmation — skip clarifying questions unless a field is ambiguous.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to change the quantity, price, or discount of a product already '
			. 'on an opportunity, first locate the line item with the opportunity product search tool available to you if its id is not '
			. 'already known, then confirm the changes before calling this tool. To change which product a line '
			. 'refers to, delete this line item and add a new one instead — the product itself cannot be swapped '
			. 'here.'
			. "\n\n"
			. 'The line total and the opportunity\'s overall amount/total_amount are recalculated automatically — '
			. 'never ask the user for them or set them directly.';
	}

	protected function findRecordById(string $id): ?OpportunityProduct
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('opportunity_product'))(new (Helper::model('opportunity_product')));

		return $repo->find($id);
	}

	protected function currentData(mixed $record): array
	{
		return [
			'qty'   => $record->qty,
			'price' => $record->price,
			'disc'  => $record->disc,
		];
	}

	protected function update(mixed $record, array $validated, array $changes): array
	{
		$repo    = new (Helper::repository('opportunity_product'))(new (Helper::model('opportunity_product')));
		$product = $repo->update($record->id, $validated,
			before: fn ($record, $data) => $this->beforeUpdate($record, $data, $changes),
			after:  fn ($record)        => $this->afterUpdate($record, $changes),
		);

		return AiResponse::success(
			[
				'id'      => $product->id,
				'product' => $product->product?->name,
				'total'   => $product->total,
				'updated' => array_keys($changes),
			],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
