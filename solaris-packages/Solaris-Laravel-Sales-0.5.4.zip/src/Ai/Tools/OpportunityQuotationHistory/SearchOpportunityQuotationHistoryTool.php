<?php

namespace Solaris\Sales\Ai\Tools\OpportunityQuotationHistory;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Services\Filter;

class SearchOpportunityQuotationHistoryTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_opportunity_quotation_history';
	}

	protected function resourceLabel(): string
	{
		return 'quotation history — every quotation PDF ever generated for an opportunity, newest first. '
			. 'Read-only: use print_quotation with the returned id (as history_id) to actually send one to the user.';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('opportunity_quotation_history'))();
	}

	protected function fields(): array
	{
		return [
			'opportunity_id' => AiSearchColumn::string(
				column: 'opportunity_id',
				description: 'The opportunity id this quotation belongs to. Obtain it with the opportunity search tool available to you first.',
				operators: [Filter::Equal],
			),
			'number_quotation' => AiSearchColumn::string(
				column: 'number_quotation',
				description: 'Quotation number',
				operators: [Filter::Equal, Filter::Contains],
				searchable: true,
			),
			'date' => AiSearchColumn::datetime(
				column: 'date',
				description: 'When this quotation was generated',
				operators: [Filter::Greater, Filter::Less, Filter::Between, Filter::IsToday, Filter::IsThisWeek, Filter::IsThisMonth, Filter::IsThisYear],
			),
			'total_amount' => AiSearchColumn::string(
				column: 'total_amount',
				description: 'Total quoted amount at the time this quotation was generated',
				operators: [Filter::Equal, Filter::Greater, Filter::Less, Filter::Between],
			),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'              => $record->id,
			'number_quotation' => $record->number_quotation,
			'date'             => $record->date ? Carbon::parse($record->date)->format('d M Y') : null,
			'total_amount'     => $record->total_amount,
		];
	}
}
