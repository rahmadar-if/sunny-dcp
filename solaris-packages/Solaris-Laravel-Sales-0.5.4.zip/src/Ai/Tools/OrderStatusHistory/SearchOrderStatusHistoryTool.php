<?php

namespace Solaris\Sales\Ai\Tools\OrderStatusHistory;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

class SearchOrderStatusHistoryTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_order_status_history';
	}

	protected function resourceLabel(): string
	{
		return 'order status history — history of status changes for a sales order';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('order_status_history'))();
	}

	protected function fields(): array
	{
		return [
			'order_id' => AiSearchColumn::reference(
				column: 'order_id',
				description: 'The order id this status history belongs to. Obtain it with the order search tool available to you first.',
				modelKey: 'order',
			),
			'status_id' => AiSearchColumn::lookup(
				column: 'status_id',
				description: 'Status held during this period',
				modelKey: 'order_status',
			),
			'position' => AiSearchColumn::number(
				column: 'position',
				description: 'Sequence order of this status within the order\'s history, starting at 1',
			),
			'start' => AiSearchColumn::datetime('start', 'Date and time this status started'),
			'end'   => AiSearchColumn::datetime('end', 'Date and time this status ended (empty means still current)'),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'      => $record->id,
			'_order_id' => $record->order_id,
			'status'   => $record->status?->name,
			'position' => $record->position,
			'start'    => $record->start ? Carbon::parse($record->start)->format('d M Y H:i') : null,
			'end'      => $record->end ? Carbon::parse($record->end)->format('d M Y H:i') : null,
		];
	}
}
