<?php

namespace Solaris\Sales\Ai\Tools\OpportunityStatusHistory;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

class SearchOpportunityStatusHistoryTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_opportunity_status_history';
	}

	protected function resourceLabel(): string
	{
		return 'opportunity status history — history of pipeline stage changes for a sales opportunity';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('opportunity_status_history'))();
	}

	protected function fields(): array
	{
		return [
			'opportunity_id' => AiSearchColumn::reference(
				column: 'opportunity_id',
				description: 'The opportunity id this status history belongs to. Obtain it with the opportunity search tool available to you first.',
				modelKey: 'opportunity',
			),
			'status_id' => AiSearchColumn::lookup(
				column: 'status_id',
				description: 'Pipeline stage held during this period',
				modelKey: 'opportunity_status',
			),
			'position' => AiSearchColumn::number(
				column: 'position',
				description: 'Sequence order of this stage within the opportunity\'s history, starting at 1',
			),
			'start' => AiSearchColumn::datetime('start', 'Date and time this stage started'),
			'end'   => AiSearchColumn::datetime('end', 'Date and time this stage ended (empty means still current)'),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'             => $record->id,
			'_opportunity_id' => $record->opportunity_id,
			'status'          => $record->status?->name,
			'position'        => $record->position,
			'start'           => $record->start ? Carbon::parse($record->start)->format('d M Y H:i') : null,
			'end'             => $record->end ? Carbon::parse($record->end)->format('d M Y H:i') : null,
		];
	}
}
