<?php

namespace Solaris\Sales\Ai\Tools\Opportunity;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Support\Arr;
use Laravel\Ai\Tools\Request;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseUpdateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Ai\Tools\OpportunityCompetitor\CreateOpportunityCompetitorTool;
use Solaris\Sales\Ai\Tools\OpportunityContact\CreateOpportunityContactTool;
use Solaris\Sales\Ai\Tools\OpportunityProduct\CreateOpportunityProductTool;
use Solaris\Sales\Ai\Tools\OpportunityTeam\CreateOpportunityTeamTool;
use Solaris\Sales\Ai\Tools\OpportunityTermCondition\CreateOpportunityTermConditionTool;
use Solaris\Sales\Const\OpportunityStatusConst;
use Solaris\Sales\Http\Requests\OpportunityCompetitorRequest;
use Solaris\Sales\Http\Requests\OpportunityContactRequest;
use Solaris\Sales\Http\Requests\OpportunityProductRequest;
use Solaris\Sales\Http\Requests\OpportunityRequest;
use Solaris\Sales\Http\Requests\OpportunityTeamRequest;
use Solaris\Sales\Http\Requests\OpportunityTermConditionRequest;
use Solaris\Sales\Models\Opportunity;

class UpdateOpportunityTool extends BaseUpdateAiTool
{
	private const STAGE_TRANSITIONS = [
		OpportunityStatusConst::Qualification => [OpportunityStatusConst::Proposal, OpportunityStatusConst::ClosedLost],
		OpportunityStatusConst::Proposal      => [OpportunityStatusConst::Qualification, OpportunityStatusConst::Negotiation, OpportunityStatusConst::ClosedLost],
		OpportunityStatusConst::Negotiation   => [OpportunityStatusConst::Proposal, OpportunityStatusConst::ClosedWon, OpportunityStatusConst::ClosedLost],
	];

	protected mixed $updatingRecord = null;

	public static function slug(): string
	{
		return 'update_opportunity';
	}

	protected function resourceLabel(): string
	{
		return 'opportunity';
	}

	public static function fields(JsonSchema $schema): array
	{
		$productFields    = Arr::except(CreateOpportunityProductTool::fields($schema), ['opportunity_id']);
		$teamFields       = Arr::except(CreateOpportunityTeamTool::fields($schema), ['opportunity_id']);
		$contactFields    = Arr::except(CreateOpportunityContactTool::fields($schema), ['opportunity_id']);
		$competitorFields = Arr::except(CreateOpportunityCompetitorTool::fields($schema), ['opportunity_id']);
		$termFields       = Arr::except(CreateOpportunityTermConditionTool::fields($schema), ['opportunity_id']);

		$detailMeta = [
			'id'     => $schema->string()->description('Existing record id. Omit to create a new one.'),
			'delete' => $schema->boolean()->description('Set true (with id) to remove this record instead of updating it.'),
		];

		return [
			'id' => $schema->string()
				->description('The opportunity id. Required.')
				->required(),
			'name' => $schema->string()->description('New name of the opportunity/deal.'),
			'date' => $schema->string()->description('New opportunity date in Y-m-d format.'),
			'customer_id' => $schema->string()->description(
				'New customer account this opportunity is for. Obtain it with the account search tool available to you first. If only '
					. 'decision_maker_id is being changed, this is derived automatically from the new decision '
					. 'maker\'s account — pass this explicitly only when the customer itself is changing.'
			),
			'decision_maker_id' => $schema->string()->description(
				'New contact who is the decision maker for this opportunity. Obtain it with the contact search tool available to you first. '
					. 'If only customer_id is being changed, this is derived automatically from the new '
					. 'customer\'s primary contact — pass this explicitly only when the decision maker itself is changing.'
			),
			'customer_need' => $schema->string()->description('New description of what the customer needs.'),
			'budget' => $schema->string()->description('New customer budget as a plain number.'),
			'source_id' => $schema->string()->description(
				'New lead source. Resolve via lookup_options with type: "lead_source".'
			),
			'type_id' => $schema->string()->description(
				'New opportunity type. Resolve via lookup_options with type: "opportunity_type".'
			),
			'status_id' => $schema->string()->description(
				'New pipeline stage/status. Resolve via lookup_options with type: "opportunity_status". '
					. 'Changing this automatically recomputes probability_percent from the new status, sets '
					. 'closed_on when the new status is a final stage, and logs a stage history entry — no need to '
					. 'set those manually just for a status change.'
			),
			'phone' => $schema->string()->description('New contact phone number.'),
			'email' => $schema->string()->description('New contact email.'),
			'description' => $schema->string()->description('Free-text opportunity description.'),
			'our_strengths' => $schema->string()->description('Our strengths for winning this opportunity.'),
			'our_weaknesses' => $schema->string()->description('Our weaknesses for this opportunity.'),
			'sales_tactics' => $schema->string()->description('Sales tactics planned for this opportunity.'),
			'notes' => $schema->string()->description('Free-text notes about the opportunity.'),
			'quotation_number' => $schema->string()->description('New quotation number reference.'),
			'latest_status' => $schema->string()->description(
				'Free-text note describing the latest status update. Distinct from the status/stage itself '
					. '(see status_id field).'
			),
			'status_date' => $schema->string()->description('New date of the latest status update, in Y-m-d format.'),
			'is_new_customer' => $schema->boolean()->description('Whether the customer is new.'),
			'closed_on' => $schema->string()->description(
				'New closed date in Y-m-d format. Normally set automatically when status changes to a final '
					. 'stage — pass this only if the user explicitly wants to override the closed date itself.'
			),
			'detail_products' => $schema->array()->items($schema->object(array_merge($detailMeta, $productFields)))->description(
				'Manage product line items in the same confirmation — omit id to add a new one (resolve the '
					. 'product with the product search tool available to you active=true first), pass id with qty/price/disc to update an existing '
					. 'one, pass id with delete:true to remove one. Supports multiple. Optional.'
			),
			'detail_teams' => $schema->array()->items($schema->object(array_merge($detailMeta, $teamFields)))->description(
				'Manage deal-team members — omit id to add a new one, pass id with fields to update, pass id with '
					. 'delete:true to remove. Supports multiple. Optional.'
			),
			'detail_contacts' => $schema->array()->items($schema->object(array_merge($detailMeta, $contactFields)))->description(
				'Manage linked contacts — omit id to add a new one (resolve the contact with the contact search tool available to you first), '
					. 'pass id with fields to update, pass id with delete:true to remove. Supports multiple. Optional.'
			),
			'detail_competitors' => $schema->array()->items($schema->object(array_merge($detailMeta, $competitorFields)))->description(
				'Manage competitors — omit id to add a new one, pass id with fields to update, pass id with '
					. 'delete:true to remove. Supports multiple. Optional.'
			),
			'detail_term_conditions' => $schema->array()->items($schema->object(array_merge($detailMeta, $termFields)))->description(
				'Manage terms & conditions — omit id to add a new one, pass id with fields to update, pass id with '
					. 'delete:true to remove. Supports multiple. Optional.'
			),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::reference(column: 'customer_id', label: 'customer', modelKey: 'account'),
			AiColumn::reference(column: 'decision_maker_id', label: 'decision maker', modelKey: 'contact'),
			AiColumn::lookup(column: 'source_id', label: 'lead source', modelKey: 'lead_source'),
			AiColumn::lookup(column: 'type_id', label: 'opportunity type', modelKey: 'opportunity_type'),
			AiColumn::lookup(column: 'status_id', label: 'status', modelKey: 'opportunity_status'),
		];
	}

	protected function rules(): array
	{
		return array_merge(OpportunityRequest::updateRules(), [
			'status_id' => ['nullable', 'uuid', $this->stageTransitionRule()],
		]);
	}

	// Mirrors the stage-buttons transition map on the opportunity detail page — kanban isn't gated yet,
	// but the AI channel has no board to restrict the move, so it's validated here instead.
	private function stageTransitionRule(): \Closure
	{
		return function (string $attribute, mixed $value, \Closure $fail) {
			$record = $this->updatingRecord;

			if (!$record || $value === $record->status_id) {
				return;
			}

			$statuses    = Helper::model('opportunity_status')::getCache();
			$currentName = $statuses->get($record->status_id)?->name ?? $record->status_id;

			if (in_array($record->status_id, [OpportunityStatusConst::ClosedWon, OpportunityStatusConst::ClosedLost], true)) {
				$fail("This opportunity is already {$currentName} — its stage can no longer be changed.");

				return;
			}

			$allowed = self::STAGE_TRANSITIONS[$record->status_id] ?? [];

			if (!in_array($value, $allowed, true)) {
				$allowedNames = implode(', ', array_map(
					fn ($id) => $statuses->get($id)?->name ?? $id,
					$allowed,
				));

				$fail("Invalid stage transition from {$currentName} — allowed next stages: {$allowedNames}.");
			}
		};
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/update-opportunity" with no other text, ask which opportunity and what to change. '
			. 'If followed by a description of the changes, extract the fields directly and proceed to confirmation — '
			. 'skip clarifying questions unless a field is ambiguous.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to edit or update an opportunity, first locate it via '
			. 'the opportunity search tool if the id is not already known, then confirm the changes before calling this tool. '
			. 'To change the status/stage, resolve the target status by name and pass it as the status field — '
			. 'probability_percent, closed_on (if the new status is a final stage), and stage history are recomputed '
			. 'automatically, same as the pipeline board.'
			. "\n\n"
			. 'STAGE TRANSITIONS: Only these moves are allowed — Qualification -> Proposal or Closed Lost; '
			. 'Proposal -> Qualification, Negotiation, or Closed Lost; Negotiation -> Proposal, Closed Won, or '
			. 'Closed Lost. Once Closed Won or Closed Lost, the stage can never change again. Do not propose or '
			. 'confirm a stage change outside this map — the tool will reject it anyway; tell the user directly '
			. 'which stages are reachable from the current one instead.'
			. "\n\n"
			. 'CUSTOMER / DECISION MAKER: These stay in sync automatically — changing only one derives the other '
			. '(new decision maker\'s account, or new customer\'s primary contact) unless the user gives both '
			. 'explicitly. Resolve whichever the user names with the account search tool available to you / the contact search tool first to confirm it '
			. 'exists and disambiguate multiple matches; if not found, gather details and create_account / '
			. 'create_contact first, then use the returned id here.'
			. "\n\n"
			. 'DETAILS: If the user also wants to add, change, or remove products, deal-team members, contacts, '
			. 'competitors, or terms & conditions under this opportunity in the same request, pass them via '
			. 'detail_products/detail_teams/detail_contacts/detail_competitors/detail_term_conditions instead of '
			. 'calling their own tools — everything is applied together in this same confirmation. Omit id to add, '
			. 'pass id with fields to change one, pass id with delete:true to remove one. Resolve each new product '
			. 'with the product search tool available to you (active=true) and each new contact with the contact search tool available to you first, and get existing '
			. 'line ids via the matching search_opportunity_* tool. Line totals and the opportunity\'s overall '
			. 'amount are computed automatically — never set them.';
	}

	protected function findRecordById(string $id): ?Opportunity
	{
		if ($id === '') {
			return null;
		}

		$repo   = new (Helper::repository('opportunity'))(new (Helper::model('opportunity')));
		$record = $repo->find($id);

		// Cached here (rather than a dedicated hook) because findRecordById() is the earliest point in
		// validateConfirmation() where the record is available — rules() (and its stageTransitionRule
		// closure) runs right after and needs it.
		$this->updatingRecord = $record;

		return $record;
	}

	protected function currentData(mixed $record): array
	{
		return [
			'name'              => $record->name,
			'date'              => $record->date?->format('Y-m-d'),
			'customer_id'       => $record->customer_id,
			'decision_maker_id' => $record->decision_maker_id,
			'customer_need'     => $record->customer_need,
			'budget'            => $record->budget,
			'source_id'         => $record->source_id,
			'type_id'           => $record->type_id,
			'status_id'         => $record->status_id,
			'phone'             => $record->phone,
			'email'             => $record->email,
			'description'       => $record->description,
			'our_strengths'     => $record->our_strengths,
			'our_weaknesses'    => $record->our_weaknesses,
			'sales_tactics'     => $record->sales_tactics,
			'notes'             => $record->notes,
			'quotation_number'  => $record->quotation_number,
			'latest_status'     => $record->latest_status,
			'status_date'       => $record->status_date,
			'is_new_customer'   => $record->is_new_customer,
			'closed_on'         => $record->closed_on,
		];
	}

	public function validateConfirmation(Request $request): array
	{
		$result = parent::validateConfirmation($request);

		if (isset($result['error'])) {
			return $result;
		}

		$opportunityId = trim((string) ($request['id'] ?? ''));

		$specs = [
			'detail_products'        => [Helper::model('opportunity_product'),        OpportunityProductRequest::createRules(),       OpportunityProductRequest::updateRules(),       'products'],
			'detail_teams'           => [Helper::model('opportunity_team'),           OpportunityTeamRequest::createRules(),          OpportunityTeamRequest::updateRules(),          'team members'],
			'detail_contacts'        => [Helper::model('opportunity_contact'),        OpportunityContactRequest::createRules(),       OpportunityContactRequest::updateRules(),       'contacts'],
			'detail_competitors'     => [Helper::model('opportunity_competitor'),     OpportunityCompetitorRequest::createRules(),    OpportunityCompetitorRequest::updateRules(),    'competitors'],
			'detail_term_conditions' => [Helper::model('opportunity_term_condition'), OpportunityTermConditionRequest::createRules(), OpportunityTermConditionRequest::updateRules(), 'terms & conditions'],
		];

		foreach ($specs as $key => [$model, $createRules, $updateRules, $label]) {
			[$ops, $errors] = $this->resolveDetailOperations(
				(array) ($request[$key] ?? []), $model, $createRules, $updateRules, 'opportunity_id', $opportunityId,
			);

			if (!empty($errors)) {
				return AiResponse::error(AiErrorCode::UserError, "One or more {$label} failed validation.", ['messages' => $errors]);
			}

			$result['payload']['changes'][$key] = $ops;

			if (!empty($ops['create']) || !empty($ops['update']) || !empty($ops['delete'])) {
				$result['summary'][$key] = [
					'add'    => count($ops['create']),
					'update' => count($ops['update']),
					'delete' => count($ops['delete']),
				];
			}
		}

		return $result;
	}

	/**
	 * Mirrors the customer<->decision_maker cross-fill in CreateOpportunityTool — changing only one side
	 * derives the other from the Account/Contact relation, unless the user gave both explicitly.
	 */
	private function crossFillCustomerDecisionMaker(mixed $record, array $validated, array $changes): array
	{
		if (!empty($changes['decision_maker_id']) && empty($changes['customer_id'])) {
			$contact = Helper::model('contact')::find($changes['decision_maker_id']);

			if ($contact?->account_id && $contact->account_id !== $record->customer_id) {
				$validated['customer_id'] = $contact->account_id;
			}
		} elseif (!empty($changes['customer_id']) && empty($changes['decision_maker_id'])) {
			$account = Helper::model('account')::find($changes['customer_id']);

			if ($account?->primary_contact_id && $account->primary_contact_id !== $record->decision_maker_id) {
				$validated['decision_maker_id'] = $account->primary_contact_id;
			}
		}

		return $validated;
	}

	protected function excludedChangeKeys(): array
	{
		return ['detail_products', 'detail_teams', 'detail_contacts', 'detail_competitors', 'detail_term_conditions'];
	}

	protected function afterUpdate(mixed $record, array $changes): void
	{
		$groups = [
			'opportunity_product'        => $changes['detail_products'] ?? null,
			'opportunity_team'           => $changes['detail_teams'] ?? null,
			'opportunity_contact'        => $changes['detail_contacts'] ?? null,
			'opportunity_competitor'     => $changes['detail_competitors'] ?? null,
			'opportunity_term_condition' => $changes['detail_term_conditions'] ?? null,
		];

		foreach ($groups as $modelKey => $ops) {
			$ops = $ops ?? ['create' => [], 'update' => [], 'delete' => []];

			if (empty($ops['create']) && empty($ops['update']) && empty($ops['delete'])) {
				continue;
			}

			$repo = new (Helper::repository($modelKey))(new (Helper::model($modelKey)), transaction: false);

			foreach ($ops['create'] as $data) {
				$repo->create($data);
			}

			foreach ($ops['update'] as $id => $data) {
				$repo->update($id, $data);
			}

			foreach ($ops['delete'] as $id) {
				$repo->delete($id);
			}
		}
	}

	protected function update(mixed $record, array $validated, array $changes): array
	{
		$validated = $this->crossFillCustomerDecisionMaker($record, $validated, $changes);

		$repo = new (Helper::repository('opportunity'))(new (Helper::model('opportunity')));
		$repo->update($record->id, $validated,
			after: fn ($record) => $this->afterUpdate($record, $changes),
		);

		$fieldChanges = collect($changes)->except($this->excludedChangeKeys())->all();

		return AiResponse::success(
			[
				'id'      => $record->id,
				'name'    => $fieldChanges['name'] ?? $record->name,
				'updated' => array_keys($fieldChanges),
			],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
