<?php

namespace Solaris\Sales\Ai\Tools\Opportunity;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Arr;
use Illuminate\Support\Str;
use Laravel\Ai\Tools\Request;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseCreateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Ai\Tools\OpportunityCompetitor\CreateOpportunityCompetitorTool;
use Solaris\Sales\Ai\Tools\OpportunityContact\CreateOpportunityContactTool;
use Solaris\Sales\Ai\Tools\OpportunityProduct\CreateOpportunityProductTool;
use Solaris\Sales\Ai\Tools\OpportunityTeam\CreateOpportunityTeamTool;
use Solaris\Sales\Ai\Tools\OpportunityTermCondition\CreateOpportunityTermConditionTool;
use Solaris\Sales\Http\Requests\OpportunityCompetitorRequest;
use Solaris\Sales\Http\Requests\OpportunityContactRequest;
use Solaris\Sales\Http\Requests\OpportunityProductRequest;
use Solaris\Sales\Http\Requests\OpportunityRequest;
use Solaris\Sales\Http\Requests\OpportunityTeamRequest;
use Solaris\Sales\Http\Requests\OpportunityTermConditionRequest;

class CreateOpportunityTool extends BaseCreateAiTool
{
	public static function slug(): string
	{
		return 'create_opportunity';
	}

	protected function resourceLabel(): string
	{
		return 'opportunity';
	}

	// Source of truth for each detail_* stays on the child resource's own create tool — reusing its
	// fields() keeps the nested schema in sync automatically instead of retyping it here.
	public static function fields(JsonSchema $schema): array
	{
		$productFields    = Arr::except(CreateOpportunityProductTool::fields($schema), ['opportunity_id']);
		$teamFields       = Arr::except(CreateOpportunityTeamTool::fields($schema), ['opportunity_id']);
		$contactFields    = Arr::except(CreateOpportunityContactTool::fields($schema), ['opportunity_id']);
		$competitorFields = Arr::except(CreateOpportunityCompetitorTool::fields($schema), ['opportunity_id']);
		$termFields       = Arr::except(CreateOpportunityTermConditionTool::fields($schema), ['opportunity_id']);

		return [
			'name' => $schema->string()
				->description('Name of the opportunity/deal.')
				->required(),
			'date' => $schema->string()
				->description(
					'Opportunity date in Y-m-d format. Defaults to today (see CURRENT DATE & TIME in '
						. 'context) if the user does not mention a date.'
				)
				->required(),
			'customer_id' => $schema->string()->description(
				'The customer account this opportunity is for. Obtain it with the account search tool available to you first. Either '
					. 'customer_id or decision_maker_id must be given — whichever is missing is derived '
					. 'automatically from the other. Not required if decision_maker_id is given.'
			),
			'decision_maker_id' => $schema->string()->description(
				'The contact who is the decision maker for this opportunity. Obtain with the contact search tool available to you '
					. 'first. Either customer_id or decision_maker_id must be given — whichever is missing is '
					. 'derived automatically from the other.'
			),
			'customer_need' => $schema->string()
				->description('What the customer needs — at least a short description.')
				->required(),
			'budget' => $schema->string()->description('Customer budget as a plain number.'),
			'source_id' => $schema->string()
				->description('Where this opportunity came from. Resolve via lookup_options with type: "lead_source".')
				->required(),
			'type_id' => $schema->string()->description(
				'Type of opportunity. Resolve via lookup_options with type: "opportunity_type".'
			),
			'phone' => $schema->string()->description(
				'Contact phone number. Falls back to the customer account\'s phone on file if '
					. 'neither this nor email is given.'
			),
			'email' => $schema->string()->description(
				'Contact email. Falls back to the customer account\'s email on file if neither '
					. 'this nor phone is given.'
			),
			'detail_products' => $schema->array()->items($schema->object($productFields))->description(
				'Product line items to add to this opportunity, each linked automatically. Resolve each '
					. 'product with the product search tool available to you (active=true) first. Supports multiple. Optional.'
			),
			'detail_teams' => $schema->array()->items($schema->object($teamFields))->description(
				'Deal-team members to add to this opportunity, each linked automatically. Supports multiple. Optional.'
			),
			'detail_contacts' => $schema->array()->items($schema->object($contactFields))->description(
				'Contacts to link to this opportunity, each linked automatically. Resolve each contact via '
					. 'the contact search tool first. Supports multiple. Optional.'
			),
			'detail_competitors' => $schema->array()->items($schema->object($competitorFields))->description(
				'Competitors to log on this opportunity, each linked automatically. Supports multiple. Optional.'
			),
			'detail_term_conditions' => $schema->array()->items($schema->object($termFields))->description(
				'Terms & conditions to attach to this opportunity, each linked automatically. Supports multiple. Optional.'
			),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::reference(column: 'customer_id', label: 'customer', modelKey: 'account'),
			AiColumn::reference(column: 'decision_maker_id', label: 'decision maker', modelKey: 'contact'),
			AiColumn::lookup(column: 'source_id', label: 'lead source', modelKey: 'lead_source'),
			AiColumn::lookup(column: 'type_id', label: 'opportunity type', modelKey: 'opportunity_type'),
		];
	}

	protected function rules(): array
	{
		return OpportunityRequest::createRules();
	}

	/**
	 * The missing side of customer/decision_maker (and phone/email) is derived here from the
	 * Account/Contact relation so OpportunityRequest's normal "required" rules still pass without the
	 * user restating what was already established with search_account/search_contact.
	 */
	protected function beforeCreate(array $data, array $raw): array
	{
		if (empty($data['customer_id']) && !empty($data['decision_maker_id'])) {
			$contact = Helper::model('contact')::find($data['decision_maker_id']);

			if ($contact?->account_id) {
				$data['customer_id'] = $contact->account_id;
			}
		}

		if (empty($data['customer_id'])) {
			return $data;
		}

		$phoneOrEmailMissing = empty($data['phone']) && empty($data['email']);

		if (empty($data['decision_maker_id']) || $phoneOrEmailMissing) {
			$account = Helper::model('account')::find($data['customer_id']);

			if (empty($data['decision_maker_id']) && $account?->primary_contact_id) {
				$data['decision_maker_id'] = $account->primary_contact_id;
			}

			if ($phoneOrEmailMissing) {
				$data['phone'] = $account?->primary_phone;
				$data['email'] = $account?->email;
			}
		}

		return $data;
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/add-opportunity" with no other text, ask for the required fields. '
			. 'If the user sends "/add-opportunity" followed by details, extract the fields directly and proceed to '
			. 'confirmation — skip clarifying questions unless a field is ambiguous.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to add or create a new opportunity/deal, gather the required fields '
			. 'and confirm before calling this tool.'
			. "\n\n"
			. 'CUSTOMER / DECISION MAKER: At least one of customer or decision_maker must be given — pass whichever '
			. 'the user mentions, the other is derived automatically (decision_maker\'s account, or the customer\'s '
			. 'primary contact) and does not need to be looked up separately for that purpose. If the user names '
			. 'one, resolve it first with the account search tool available to you / the contact search tool to confirm it exists and disambiguate '
			. 'multiple matches — never guess an id. If search finds nothing, the record may need to be created '
			. 'first: gather the missing account/contact details from the user, confirm, call create_account or '
			. 'create_contact, then use the returned id here.'
			. "\n\n"
			. 'CUSTOMER NEED: If the user does not state this explicitly, write a short summary yourself from the '
			. 'opportunity name and whatever context is available — do not leave it blank or ask unless there is '
			. 'truly nothing to summarize.'
			. "\n\n"
			. 'PHONE / EMAIL: Only ask the user for these if the resolved customer account has neither on file.'
			. "\n\n"
			. 'Status defaults automatically to the initial stage — never ask the user for it here.'
			. "\n\n"
			. 'DETAILS: If the user also wants products, deal-team members, contacts, competitors, or terms & '
			. 'conditions added under this opportunity in the same request, pass them via '
			. 'detail_products/detail_teams/detail_contacts/detail_competitors/detail_term_conditions instead of '
			. 'calling their own create tools — everything is created together in this same confirmation. Resolve '
			. 'each product with the product search tool available to you (active=true) and each contact with the contact search tool available to you first, then pass '
			. 'their ids in the matching detail_* array. Line totals and the opportunity\'s overall amount are '
			. 'computed automatically — never set them.';
	}

	public function validateConfirmation(Request $request): array
	{
		$result = parent::validateConfirmation($request);

		if (isset($result['error'])) {
			return $result;
		}

		// Self-generated ahead of insert — BaseModel uses HasUuids, which respects an id already set on the
		// data array instead of generating its own. Knowing it up front lets detail_* rows (which require
		// opportunity_id) validate for real before any confirmation is shown, instead of faking the check.
		$opportunityId = (string) Str::uuid7();

		$details = [
			'detail_products'        => [OpportunityProductRequest::createRules(),        'products'],
			'detail_teams'           => [OpportunityTeamRequest::createRules(),           'team members'],
			'detail_contacts'        => [OpportunityContactRequest::createRules(),        'contacts'],
			'detail_competitors'     => [OpportunityCompetitorRequest::createRules(),     'competitors'],
			'detail_term_conditions' => [OpportunityTermConditionRequest::createRules(),  'terms & conditions'],
		];

		$validatedDetails = [];

		foreach ($details as $key => [$rules, $label]) {
			[$rows, $errors] = $this->validateDetailList((array) ($request[$key] ?? []), $rules, 'opportunity_id', $opportunityId);

			if (!empty($errors)) {
				return AiResponse::error(AiErrorCode::UserError, "One or more {$label} failed validation.", ['messages' => $errors]);
			}

			$validatedDetails[$key]         = $rows;
			$result['payload']['raw'][$key] = $rows;
		}

		$result['payload']['raw']['id'] = $opportunityId;

		$this->summariseDetails($result['summary'], $validatedDetails);

		return $result;
	}

	// Readable where a name/subject column exists, a plain count otherwise (product/contact carry only ids).
	private function summariseDetails(array &$summary, array $details): void
	{
		if (!empty($details['detail_products'])) {
			$summary['detail_products'] = count($details['detail_products']) . ' product(s)';
		}

		if (!empty($details['detail_teams'])) {
			$summary['detail_teams'] = array_map(fn ($t) => $t['name'], $details['detail_teams']);
		}

		if (!empty($details['detail_contacts'])) {
			$summary['detail_contacts'] = count($details['detail_contacts']) . ' contact(s)';
		}

		if (!empty($details['detail_competitors'])) {
			$summary['detail_competitors'] = array_map(fn ($c) => $c['name'], $details['detail_competitors']);
		}

		if (!empty($details['detail_term_conditions'])) {
			$summary['detail_term_conditions'] = array_map(fn ($t) => $t['subject'], $details['detail_term_conditions']);
		}
	}

	protected function afterCreate(Model $record, array $raw): void
	{
		$groups = [
			'opportunity_product'        => $raw['detail_products'] ?? [],
			'opportunity_team'           => $raw['detail_teams'] ?? [],
			'opportunity_contact'        => $raw['detail_contacts'] ?? [],
			'opportunity_competitor'     => $raw['detail_competitors'] ?? [],
			'opportunity_term_condition' => $raw['detail_term_conditions'] ?? [],
		];

		foreach ($groups as $modelKey => $rows) {
			if (empty($rows)) {
				continue;
			}

			$repo = new (Helper::repository($modelKey))(new (Helper::model($modelKey)), transaction: false);

			foreach ($rows as $data) {
				$repo->create($data);
			}
		}
	}

	protected function create(array $validated, array $raw): array
	{
		$validated['id'] = $raw['id'] ?? (string) Str::uuid7();

		$repo        = new (Helper::repository('opportunity'))(new (Helper::model('opportunity')));
		$opportunity = $repo->create($validated,
			before: fn ($data)   => $this->beforeCreate($data, $raw),
			after:  fn ($record) => $this->afterCreate($record, $raw),
		);

		return AiResponse::success(
			['id' => $opportunity->id, 'name' => $opportunity->name],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
