<?php

namespace Solaris\Sales\Ai\Tools\Opportunity;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Services\Filter;

class SearchOpportunityTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_opportunity';
	}

	protected function resourceLabel(): string
	{
		return 'sales opportunities/deals — a customer\'s potential purchase moving through the sales pipeline';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('opportunity'))();
	}

	protected function fields(): array
	{
		return [
			'name' => AiSearchColumn::string(
				column: 'name',
				description: 'Name of the opportunity/deal. For filters, combine SIMILAR OR LIKE in the same '
					. 'OR-group — SIMILAR tolerates typos/reordering/partial/extra wording, LIKE catches plain '
					. 'substring matches SIMILAR can miss.',
				searchable: true,
			),
			'customer_need' => AiSearchColumn::string(
				column: 'customer_need',
				description: 'What the customer needs',
				searchable: true,
			),
			'phone' => AiSearchColumn::string(
				column: 'phone',
				description: 'Contact phone number for this opportunity',
				searchable: true,
			),
			'email' => AiSearchColumn::string(
				column: 'email',
				description: 'Contact email for this opportunity',
				searchable: true,
			),
			'quotation_number' => AiSearchColumn::string(
				column: 'quotation_number',
				description: 'Quotation number issued for this opportunity',
				searchable: true,
			),
			'latest_status' => AiSearchColumn::string(
				column: 'latest_status',
				description: 'Free-text note on the latest status update',
				searchable: true,
			),
			'description' => AiSearchColumn::string(
				column: 'description',
				description: 'Description of the opportunity',
				searchable: true,
			),
			'our_strengths' => AiSearchColumn::string(
				column: 'our_strengths',
				description: 'Our strengths in pursuing this opportunity',
				searchable: true,
			),
			'our_weaknesses' => AiSearchColumn::string(
				column: 'our_weaknesses',
				description: 'Our weaknesses in pursuing this opportunity',
				searchable: true,
			),
			'sales_tactics' => AiSearchColumn::string(
				column: 'sales_tactics',
				description: 'Sales tactics planned for this opportunity',
				searchable: true,
			),
			'notes_plain' => AiSearchColumn::string(
				column: 'notes_plain',
				description: 'Plain text notes about the opportunity',
				operators: [Filter::Contains, Filter::FullText],
				searchable: 'FullText',
			),
			'is_new_customer' => AiSearchColumn::boolean('is_new_customer', 'Whether this opportunity is with a brand new customer'),
			'date' => AiSearchColumn::date('date', 'Date the opportunity was created/logged'),
			'status_date' => AiSearchColumn::date('status_date', 'Date the current status was last set'),
			'closed_on' => AiSearchColumn::date('closed_on', 'Date the opportunity was closed (won or lost)'),
			'budget' => AiSearchColumn::number('budget', 'Customer budget'),
			'amount' => AiSearchColumn::number('amount', 'Base quoted amount before discount'),
			'discount_amount' => AiSearchColumn::number('discount_amount', 'Discount amount applied'),
			'discount_percent' => AiSearchColumn::number('discount_percent', 'Discount percentage applied'),
			'total_amount' => AiSearchColumn::number('total_amount', 'Total quoted amount after discount'),
			'probability_percent' => AiSearchColumn::number('probability_percent', 'Win probability percentage'),
			'days_in_funnel' => AiSearchColumn::number('days_in_funnel', 'Number of days the opportunity has spent in the pipeline so far'),
			'source_id' => AiSearchColumn::lookup(
				column: 'source_id',
				description: 'Where this opportunity came from',
				modelKey: 'lead_source',
			),
			'status_id' => AiSearchColumn::lookup(
				column: 'status_id',
				description: 'Current pipeline stage/status',
				modelKey: 'opportunity_status',
			),
			'type_id' => AiSearchColumn::lookup(
				column: 'type_id',
				description: 'Type of opportunity',
				modelKey: 'opportunity_type',
			),
			'customer_id' => AiSearchColumn::reference(
				column: 'customer_id',
				description: 'The customer account this opportunity is for. Obtain it with the account search tool available to you first.',
				modelKey: 'account',
			),
			'decision_maker_id' => AiSearchColumn::reference(
				column: 'decision_maker_id',
				description: 'The decision maker contact for this opportunity. Obtain it with the contact search tool available to you first.',
				modelKey: 'contact',
			),
			'lead_id' => AiSearchColumn::reference(
				column: 'lead_id',
				description: 'The lead this opportunity was converted from, if any. Obtain it with the lead search tool available to you first.',
				modelKey: 'lead',
			),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'                 => $record->id,
			'_customer_id'        => $record->customer_id,
			'_decision_maker_id'  => $record->decision_maker_id,
			'_lead_id'            => $record->lead_id,
			'name'                => $record->name,
			'customer'            => $record->customer?->name,
			'decision_maker'      => $record->decision_maker?->name,
			'lead'                => $record->lead?->name,
			'status'              => $record->status?->name,
			'type'                => $record->type?->name,
			'source'              => $record->source?->name,
			'date'                => $record->date ? Carbon::parse($record->date)->format('d M Y') : null,
			'closed_on'           => $record->closed_on ? Carbon::parse($record->closed_on)->format('d M Y') : null,
			'quotation_number'    => $record->quotation_number,
			'probability_percent' => $record->probability_percent,
			'total_amount'        => $record->total_amount,
		];
	}

	protected function relations(): array
	{
		return [
			'products'            => 'search_opportunity_product',
			'quotation_histories' => 'search_opportunity_quotation_history',
			'activities'          => 'search_activity',
			'teams'               => 'search_opportunity_team',
			'contacts'            => 'search_opportunity_contact',
			'competitors'         => 'search_opportunity_competitor',
			'term_conditions'     => 'search_opportunity_term_condition',
			'status_histories'    => 'search_opportunity_status_history',
		];
	}
}
