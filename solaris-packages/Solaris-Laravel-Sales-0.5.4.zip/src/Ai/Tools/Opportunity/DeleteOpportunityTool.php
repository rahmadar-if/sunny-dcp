<?php

namespace Solaris\Sales\Ai\Tools\Opportunity;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseDeleteAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Const\OpportunityStatusConst;
use Solaris\Sales\Models\Opportunity;

class DeleteOpportunityTool extends BaseDeleteAiTool
{
	public static function slug(): string
	{
		return 'delete_opportunity';
	}

	protected function resourceLabel(): string
	{
		return 'opportunity';
	}

	protected function guardDelete(mixed $record): ?string
	{
		if ($record->status_id === OpportunityStatusConst::ClosedWon) {
			return 'This opportunity is Closed Won and cannot be deleted here — guide the user to the web app if it truly needs to be removed.';
		}

		return null;
	}

	protected function findRecordById(string $id): ?Opportunity
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('opportunity'))(new (Helper::model('opportunity')));

		return $repo->find($id);
	}

	protected function delete(Model $record): array
	{
		$repo = new (Helper::repository('opportunity'))(new (Helper::model('opportunity')));
		$repo->delete($record->id);

		return AiResponse::success(
			['deleted' => $record->name],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
