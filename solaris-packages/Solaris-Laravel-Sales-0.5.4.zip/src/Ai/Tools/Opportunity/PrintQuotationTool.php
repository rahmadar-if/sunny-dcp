<?php

namespace Solaris\Sales\Ai\Tools\Opportunity;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Support\Facades\Storage;
use Laravel\Ai\Tools\Request;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseConfirmAiTool;
use Solaris\Core\Ai\Tools\HasWaConversation;
use Solaris\Core\Ai\Tools\NeedsWaConversation;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\Attachment;
use Solaris\Core\Services\WhatsApp\WhatsAppService;
use Stringable;

class PrintQuotationTool extends BaseConfirmAiTool implements NeedsWaConversation
{
	use HasWaConversation;

	public static function slug(): string
	{
		return 'print_quotation';
	}

	public function description(): Stringable|string
	{
		return 'Send the quotation PDF for an opportunity to the user via WhatsApp. Two modes: '
			. '"new" generates a brand-new quotation (creates a new quotation history record) — always the freshest '
			. 'numbers; "history" retrieves an existing, already-generated quotation without creating anything new.'
			. "\n\n"
			. 'MODE "new": Requires the opportunity to already have a customer, a phone or email, at least one '
			. 'product, and a customer address set — if any is missing this tool will say so; guide the user to fix '
			. 'it via update_opportunity (customer/phone/email) or create_opportunity_product (products) first — '
			. 'address is managed via the web app. Call this tool with type="new" NOW as soon as the '
			. 'user asks for a new quotation — do NOT wait for the user\'s approval before calling it the first '
			. 'time, and do NOT compose a confirmation message yourself without calling it. This first call (no '
			. 'confirmation_token) only validates the opportunity; it does NOT generate or send anything yet. It '
			. 'returns a summary plus a confirmation_token — present that summary to the user and wait for explicit '
			. 'approval. NEVER invent your own confirmation_token — only use the exact value this tool returned. '
			. 'Only after the user explicitly approves, call this exact same tool again with the same '
			. 'opportunity_id, type="new", plus confirmation_token to actually generate and send it — never tell '
			. 'the user it was sent before that second call returns success.'
			. "\n\n"
			. 'MODE "history": No confirmation needed — this only reads and sends a file that already exists. Omit '
			. 'history_id to send the most recent quotation for the opportunity. If the user wants a specific past '
			. 'quotation (by date or number), call the opportunity quotation history search tool first to list them, then '
			. 'pass the chosen id as history_id.'
			. "\n\n"
			. 'Always resolve the opportunity with the opportunity search tool available to you first if its id is not already known.';
	}

	public function schema(JsonSchema $schema): array
	{
		return array_merge([
			'opportunity_id' => $schema->string()
				->description('The opportunity id to print the quotation for. Required.')
				->required(),
			'type' => $schema->string()
				->description('Which quotation to send: "new" (generate a fresh one) or "history" (send an existing one). Required.')
				->required(),
			'history_id' => $schema->string()->description(
				'Only used when type="history". The specific quotation history id to send (from '
				. 'the opportunity quotation history search tool). Omit to send the most recent one for this opportunity.'
			),
		], $this->confirmationSchema($schema));
	}

	// "history" mode is read-only (no confirmation protocol) by design — intercepted here, before the
	// confirmation-token dance in HasConfirmation::execute() even starts. "new" mode (and any malformed
	// request missing/with a different type) falls through to the normal confirm/execute flow below,
	// where validateConfirmation() reports the real "type must be new or history" error.
	protected function execute(Request $request): Stringable|string
	{
		if (strtolower(trim((string) ($request['type'] ?? ''))) === 'history') {
			return json_encode($this->sendHistory($request), JSON_UNESCAPED_UNICODE);
		}

		return parent::execute($request);
	}

	public function validateConfirmation(Request $request): array
	{
		$opportunityId = trim((string) ($request['opportunity_id'] ?? ''));

		if ($opportunityId === '') {
			return AiResponse::error(AiErrorCode::UserError, 'opportunity_id is required.');
		}

		$opportunity = Helper::model('opportunity')::with(['customer.addresses', 'products'])->find($opportunityId);

		if ($opportunity === null) {
			return AiResponse::error(AiErrorCode::NotFound, 'Opportunity not found.');
		}

		$type = strtolower(trim((string) ($request['type'] ?? '')));

		if ($type !== 'new') {
			return AiResponse::error(AiErrorCode::UserError, 'type must be "new" or "history".');
		}

		if (!$opportunity->customer_id) {
			return AiResponse::error(AiErrorCode::BusinessRule, 'Customer must be set on this opportunity before printing a quotation.');
		}

		if (!$opportunity->phone && !$opportunity->email) {
			return AiResponse::error(AiErrorCode::BusinessRule, 'Phone or email must be set on this opportunity before printing a quotation.');
		}

		if ($opportunity->products->isEmpty()) {
			return AiResponse::error(AiErrorCode::BusinessRule, 'At least one product is required before printing a quotation.');
		}

		if (($opportunity->customer?->addresses ?? collect())->isEmpty()) {
			return AiResponse::error(AiErrorCode::BusinessRule, 'Customer address must be set before printing a quotation.');
		}

		return [
			'payload' => ['opportunity_id' => $opportunity->id],
			'summary' => ['opportunity' => $opportunity->name, 'total_amount' => $opportunity->total_amount],
		];
	}

	public function executeConfirmed(Request $request, array $payload): array
	{
		$history = (new (Helper::repository('opportunity'))(new (Helper::model('opportunity'))))
			->printQuotation($payload['opportunity_id'], false);

		$this->sendAttachment($history->attachment, $history->number_quotation);

		return AiResponse::success(
			['number_quotation' => $history->number_quotation],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language that a new quotation was generated and sent.',
		);
	}

	private function sendHistory(Request $request): array
	{
		$opportunityId = trim((string) ($request['opportunity_id'] ?? ''));

		if ($opportunityId === '') {
			return AiResponse::error(AiErrorCode::UserError, 'opportunity_id is required.');
		}

		$opportunity = Helper::model('opportunity')::find($opportunityId);

		if ($opportunity === null) {
			return AiResponse::error(AiErrorCode::NotFound, 'Opportunity not found.');
		}

		$historyId = trim((string) ($request['history_id'] ?? ''));

		$query = Helper::model('opportunity_quotation_history')::where('opportunity_id', $opportunity->id)
			->with('attachment');

		$history = $historyId !== ''
			? $query->where('id', $historyId)->first()
			: $query->latest('date')->first();

		if ($history === null) {
			return AiResponse::error(
				AiErrorCode::NotFound,
				'No quotation history found. Use the opportunity quotation history search tool to list available quotations, or use type="new" to generate one.',
			);
		}

		if ($history->attachment === null) {
			return AiResponse::error(AiErrorCode::NotFound, 'This quotation history has no file attached.');
		}

		$this->sendAttachment($history->attachment, $history->number_quotation);

		return AiResponse::success(
			['number_quotation' => $history->number_quotation],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language that the quotation file has been sent.',
		);
	}

	private function sendAttachment(Attachment $attachment, string $caption): void
	{
		WhatsAppService::device($this->conversation->device_id)->sendMedia(
			$this->conversation,
			Storage::disk($attachment->disk)->path($attachment->path),
			$attachment->file_name,
			'application/pdf',
			$caption,
		);
	}
}
