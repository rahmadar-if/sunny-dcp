<?php

namespace Solaris\Sales\Ai\Tools\Opportunity;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

// Reference-shaped variant of search_opportunity, for the agents that point AT a deal rather than work
// on one: the order specialist resolving the source an order is created from, the activity specialist
// linking a meeting to it. They need to find the right deal and read a few identifying facts — never to
// filter on its 28 columns or walk its eight relation groups. That surface belongs to the sales
// specialist, which keeps the full tool.
//
// Extends the winning class rather than a base one so it stays in step with whatever Sales ships; the
// allowlist below decides the result either way.
class SearchOpportunityBasicTool extends SearchOpportunityTool
{
	public static function slug(): string
	{
		return 'search_opportunity_basic';
	}

	protected function resourceLabel(): string
	{
		return 'sales opportunities/deals — enough to identify one and read its customer, stage, and value';
	}

	protected function fields(): array
	{
		return array_intersect_key(parent::fields(), array_flip([
			'name',
			'customer_id',
			'status_id',
			'date',
			'quotation_number',
			'total_amount',
		]));
	}

	protected function auditFields(): array
	{
		return [];
	}

	protected function relations(): array
	{
		return [];
	}

	// Limited to columns this tool actually selects — scopePrepared() only fetches the fields above plus
	// the model's own prepareColumns, so the parent's decision_maker/lead/type/source reads would come
	// back null or fire a lazy load per row.
	protected function formatRecord(Model $record): array
	{
		return [
			'_id'              => $record->id,
			'_customer_id'     => $record->customer_id,
			'name'             => $record->name,
			'customer'         => $record->customer?->name,
			'status'           => $record->status?->name,
			'date'             => $record->date ? Carbon::parse($record->date)->format('d M Y') : null,
			'quotation_number' => $record->quotation_number,
			'total_amount'     => $record->total_amount,
		];
	}
}
