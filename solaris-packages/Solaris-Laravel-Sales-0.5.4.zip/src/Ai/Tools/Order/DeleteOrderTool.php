<?php

namespace Solaris\Sales\Ai\Tools\Order;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseDeleteAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Models\Order;

class DeleteOrderTool extends BaseDeleteAiTool
{
	public static function slug(): string
	{
		return 'delete_order';
	}

	protected function resourceLabel(): string
	{
		return 'order';
	}

	protected function findRecordById(string $id): ?Order
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('order'))(new (Helper::model('order')));

		return $repo->find($id);
	}

	protected function delete(Model $record): array
	{
		$repo = new (Helper::repository('order'))(new (Helper::model('order')));
		$repo->delete($record->id);

		return AiResponse::success(
			['deleted' => $record->number],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
