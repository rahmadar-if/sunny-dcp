<?php

namespace Solaris\Sales\Ai\Tools\Order;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Services\Filter;

class SearchOrderTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_order';
	}

	protected function resourceLabel(): string
	{
		return 'orders — confirmed sales orders created from a won/in-progress opportunity';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('order'))();
	}

	protected function fields(): array
	{
		return [
			'number' => AiSearchColumn::string(
				column: 'number',
				description: 'Order number',
				searchable: true,
			),
			'notes_plain' => AiSearchColumn::string(
				column: 'notes_plain',
				description: 'Plain text notes about the order',
				operators: [Filter::Contains, Filter::FullText],
				searchable: 'FullText',
			),
			'date' => AiSearchColumn::date('date', 'Date the order was created'),
			'amount' => AiSearchColumn::number('amount', 'Order amount'),
			'status_id' => AiSearchColumn::lookup(
				column: 'status_id',
				description: 'Current status of the order',
				modelKey: 'order_status',
			),
			'account_id' => AiSearchColumn::reference(
				column: 'account_id',
				description: 'The account this order is for. Obtain it with the account search tool available to you first.',
				modelKey: 'account',
			),
			'contact_id' => AiSearchColumn::reference(
				column: 'contact_id',
				description: 'The contact this order is for. Obtain it with the contact search tool available to you first.',
				modelKey: 'contact',
			),
			'opportunity_id' => AiSearchColumn::reference(
				column: 'opportunity_id',
				description: 'The opportunity this order was created from. Obtain it with the opportunity search tool available to you first.',
				modelKey: 'opportunity',
			),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'             => $record->id,
			'_account_id'     => $record->account_id,
			'_contact_id'     => $record->contact_id,
			'_opportunity_id' => $record->opportunity_id,
			'number'          => $record->number,
			'account'         => $record->account?->name,
			'contact'         => $record->contact?->name,
			'opportunity'     => $record->opportunity?->name,
			'status'          => $record->status?->name,
			'date'            => $record->date ? Carbon::parse($record->date)->format('d M Y') : null,
			'amount'          => $record->amount,
		];
	}

	protected function relations(): array
	{
		return [
			'detail'          => 'search_order_detail',
			'status_history'  => 'search_order_status_history',
			'activities'      => 'search_activity',
		];
	}
}
