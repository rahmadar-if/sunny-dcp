<?php

namespace Solaris\Sales\Ai\Tools\Order;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Arr;
use Illuminate\Support\Str;
use Laravel\Ai\Tools\Request;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiErrorCode;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseCreateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Ai\Tools\Activity\CreateActivityTool;
use Solaris\Sales\Ai\Tools\OrderDetail\CreateOrderDetailTool;
use Solaris\Sales\Http\Requests\ActivityRequest;
use Solaris\Sales\Http\Requests\OrderDetailRequest;
use Solaris\Sales\Http\Requests\OrderRequest;

class CreateOrderTool extends BaseCreateAiTool
{
	public static function slug(): string
	{
		return 'create_order';
	}

	protected function resourceLabel(): string
	{
		return 'order';
	}

	public static function fields(JsonSchema $schema): array
	{
		$detailFields   = Arr::except(CreateOrderDetailTool::fields($schema), ['order_id']);
		$activityFields = CreateActivityTool::fields($schema);

		return [
			'opportunity_id' => $schema->string()
				->description(
					'The won/in-progress opportunity this order is created from. Obtain with the opportunity search tool available to you '
						. 'first. The order number, date, customer, contact, amount and its initial line items are all '
						. 'copied automatically from this opportunity.'
				)
				->required(),
			'notes' => $schema->string()->description('Free-text notes about the order.'),
			'detail_order_details' => $schema->array()->items($schema->object($detailFields))->description(
				'EXTRA product line items to add on top of the ones copied from the opportunity, each linked '
					. 'automatically. Resolve each product with the product search tool available to you (active=true) first. Only pass this if '
					. 'the user wants line items beyond what the opportunity already carries. Supports multiple. Optional.'
			),
			'detail_activities' => $schema->array()->items($schema->object($activityFields))->description(
				'Activities/tasks to schedule under this order, each linked automatically. Supports multiple. Optional.'
			),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::reference(column: 'opportunity_id', label: 'opportunity', modelKey: 'opportunity'),
		];
	}

	protected function rules(): array
	{
		return OrderRequest::createRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/add-order" with no other text, ask which opportunity to create the order from. '
			. 'If followed by details, extract the opportunity and proceed to confirmation — skip clarifying '
			. 'questions unless something is ambiguous.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to create an order from an opportunity/deal, locate the opportunity '
			. 'with the opportunity search tool available to you first, then confirm before calling this tool. Everything (number, date, '
			. 'customer, contact, amount, line items) is derived from the opportunity — never ask the user to '
			. 're-enter those.'
			. "\n\n"
			. 'DETAILS: Only pass detail_order_details if the user wants EXTRA line items beyond those copied from '
			. 'the opportunity. Pass detail_activities to schedule activities under the order in the same request, '
			. 'instead of calling their own tools. Line totals and the order amount are computed automatically — '
			. 'never set them.';
	}

	public function validateConfirmation(Request $request): array
	{
		$result = parent::validateConfirmation($request);

		if (isset($result['error'])) {
			return $result;
		}

		// Self-generated ahead of insert — BaseModel uses HasUuids, which respects an id already set on the
		// data array. Knowing it up front lets detail_* rows (which require order_id) validate for real.
		$orderId = (string) Str::uuid7();

		[$details, $errors] = $this->validateDetailList((array) ($request['detail_order_details'] ?? []), OrderDetailRequest::createRules(), 'order_id', $orderId);
		if (!empty($errors)) {
			return AiResponse::error(AiErrorCode::UserError,'One or more order line items failed validation.', ['messages' => $errors]);
		}

		[$activities, $errors] = $this->validateDetailList((array) ($request['detail_activities'] ?? []), ActivityRequest::createRules(), 'order_id', $orderId);
		if (!empty($errors)) {
			return AiResponse::error(AiErrorCode::UserError,'One or more activities failed validation.', ['messages' => $errors]);
		}

		$result['payload']['raw']['id']                   = $orderId;
		$result['payload']['raw']['detail_order_details'] = $details;
		$result['payload']['raw']['detail_activities']    = $activities;

		if (!empty($details)) {
			$result['summary']['detail_order_details'] = count($details) . ' extra line item(s)';
		}

		if (!empty($activities)) {
			$result['summary']['detail_activities'] = array_map(fn ($a) => $a['subject'], $activities);
		}

		return $result;
	}

	protected function afterCreate(Model $record, array $raw): void
	{
		$groups = [
			'order_detail' => $raw['detail_order_details'] ?? [],
			'activity'     => $raw['detail_activities'] ?? [],
		];

		foreach ($groups as $modelKey => $rows) {
			if (empty($rows)) {
				continue;
			}

			$repo = new (Helper::repository($modelKey))(new (Helper::model($modelKey)), transaction: false);

			foreach ($rows as $data) {
				$repo->create($data);
			}
		}
	}

	protected function create(array $validated, array $raw): array
	{
		$validated['id'] = $raw['id'] ?? (string) Str::uuid7();

		$repo  = new (Helper::repository('order'))(new (Helper::model('order')));
		$order = $repo->create($validated,
			before: fn ($data)   => $this->beforeCreate($data, $raw),
			after:  fn ($record) => $this->afterCreate($record, $raw),
		);

		return AiResponse::success(
			['id' => $order->id, 'number' => $order->number],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
