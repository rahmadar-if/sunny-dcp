<?php

namespace Solaris\Sales\Ai\Tools\OrderDetail;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiColumn;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseCreateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Http\Requests\OrderDetailRequest;

class CreateOrderDetailTool extends BaseCreateAiTool
{
	public static function slug(): string
	{
		return 'create_order_detail';
	}

	protected function resourceLabel(): string
	{
		return 'order line item';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'order_id' => $schema->string()
				->description('The order id to add this line item to. Obtain it with the order search tool available to you first.')
				->required(),
			'product_id' => $schema->string()
				->description(
					'The product id to add. Obtain it with the product search tool available to you first, filtered to active=true — '
						. 'inactive products cannot be added.'
				)
				->required(),
			'qty' => $schema->string()
				->description('Quantity as a plain integer.')
				->required(),
			'price' => $schema->string()
				->description(
					'Unit price as a plain number. Use the product\'s listed price from the product search tool '
						. 'unless the user gives a different price.'
				)
				->required(),
			'discount' => $schema->string()->description('Discount amount for this line item as a plain number.'),
		];
	}

	protected function lookupChecks(): array
	{
		return [
			AiColumn::reference(column: 'order_id', label: 'order', modelKey: 'order'),
		];
	}

	protected function rules(): array
	{
		return OrderDetailRequest::createRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/add-order-detail" with no other text, ask which order and which product to add. '
			. 'If followed by details, extract the fields directly and proceed to confirmation — skip clarifying '
			. 'questions unless a field is ambiguous.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to add a product/line item to an order, first locate the order via '
			. 'the order search tool and the product with the product search tool available to you (active=true) if their ids are not already known, '
			. 'then confirm the line item (product, quantity, price, discount) before calling this tool.'
			. "\n\n"
			. 'The line total and the order\'s overall amount are recalculated automatically — never ask the user '
			. 'for them or set them directly.';
	}

	protected function create(array $validated, array $raw): array
	{
		$repo   = new (Helper::repository('order_detail'))(new (Helper::model('order_detail')));
		$detail = $repo->create($validated,
			before: fn ($data)   => $this->beforeCreate($data, $raw),
			after:  fn ($record) => $this->afterCreate($record, $raw),
		);

		return AiResponse::success(
			[
				'id'       => $detail->id,
				'product'  => $detail->product?->name,
				'qty'      => $detail->qty,
				'price'    => $detail->price,
				'discount' => $detail->discount,
				'total'    => $detail->total,
			],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
