<?php

namespace Solaris\Sales\Ai\Tools\OrderDetail;

use Illuminate\Contracts\JsonSchema\JsonSchema;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseUpdateAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Http\Requests\OrderDetailRequest;
use Solaris\Sales\Models\OrderDetail;

class UpdateOrderDetailTool extends BaseUpdateAiTool
{
	public static function slug(): string
	{
		return 'update_order_detail';
	}

	protected function resourceLabel(): string
	{
		return 'order line item';
	}

	public static function fields(JsonSchema $schema): array
	{
		return [
			'id' => $schema->string()
				->description('The order line item id. Required. Obtain with the order detail search tool available to you.')
				->required(),
			'qty' => $schema->string()->description('New quantity as a plain integer.'),
			'price' => $schema->string()->description('New unit price as a plain number.'),
			'discount' => $schema->string()->description('New discount amount for this line item as a plain number.'),
		];
	}

	protected function rules(): array
	{
		return OrderDetailRequest::updateRules();
	}

	protected function descriptionExtra(): ?string
	{
		return 'COMMANDS: '
			. 'If the user sends "/update-order-detail" with no other text, ask which line item and what to change. '
			. 'If followed by a description of the changes, extract the fields directly and proceed to confirmation — '
			. 'skip clarifying questions unless a field is ambiguous.'
			. "\n\n"
			. 'NATURAL LANGUAGE: If the user asks to change the quantity, price, or discount of a product already on '
			. 'an order, first locate the line item with the order detail search tool available to you if its id is not already known, then '
			. 'confirm the changes before calling this tool. To change which product a line refers to, delete this '
			. 'line item and add a new one instead — the product itself cannot be swapped here.'
			. "\n\n"
			. 'The line total and the order\'s overall amount are recalculated automatically — never ask the user '
			. 'for them or set them directly.';
	}

	protected function findRecordById(string $id): ?OrderDetail
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('order_detail'))(new (Helper::model('order_detail')));

		return $repo->find($id);
	}

	protected function currentData(mixed $record): array
	{
		return [
			'qty'      => $record->qty,
			'price'    => $record->price,
			'discount' => $record->discount,
		];
	}

	protected function update(mixed $record, array $validated, array $changes): array
	{
		$repo   = new (Helper::repository('order_detail'))(new (Helper::model('order_detail')));
		$detail = $repo->update($record->id, $validated,
			before: fn ($record, $data) => $this->beforeUpdate($record, $data, $changes),
			after:  fn ($record)        => $this->afterUpdate($record, $changes),
		);

		return AiResponse::success(
			[
				'id'      => $detail->id,
				'product' => $detail->product?->name,
				'total'   => $detail->total,
				'updated' => array_keys($changes),
			],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
