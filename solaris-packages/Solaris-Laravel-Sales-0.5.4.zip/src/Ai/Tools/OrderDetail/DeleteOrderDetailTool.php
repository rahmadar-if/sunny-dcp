<?php

namespace Solaris\Sales\Ai\Tools\OrderDetail;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiResponse;
use Solaris\Core\Ai\Tools\BaseDeleteAiTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Models\OrderDetail;

class DeleteOrderDetailTool extends BaseDeleteAiTool
{
	public static function slug(): string
	{
		return 'delete_order_detail';
	}

	protected function resourceLabel(): string
	{
		return 'order line item';
	}

	protected function findRecordById(string $id): ?OrderDetail
	{
		if ($id === '') {
			return null;
		}

		$repo = new (Helper::repository('order_detail'))(new (Helper::model('order_detail')));

		return $repo->find($id);
	}

	protected function delete(Model $record): array
	{
		$repo    = new (Helper::repository('order_detail'))(new (Helper::model('order_detail')));
		$product = $record->product?->name;
		$repo->delete($record->id);

		return AiResponse::success(
			['deleted' => $product ?? $record->id],
			instruction: 'Reply immediately with a brief confirmation in the user\'s language.',
		);
	}
}
