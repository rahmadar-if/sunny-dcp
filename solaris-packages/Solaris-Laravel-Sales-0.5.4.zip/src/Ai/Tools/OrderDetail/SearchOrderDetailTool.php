<?php

namespace Solaris\Sales\Ai\Tools\OrderDetail;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Ai\Tools\AiSearchColumn;
use Solaris\Core\Ai\Tools\BaseSearchTool;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Services\Filter;

class SearchOrderDetailTool extends BaseSearchTool
{
	public static function slug(): string
	{
		return 'search_order_detail';
	}

	protected function resourceLabel(): string
	{
		return 'order line items — the products/services on a confirmed sales order, each with quantity, '
			. 'unit price, discount, and line total';
	}

	protected function model(): BaseModel
	{
		return new (Helper::model('order_detail'))();
	}

	protected function fields(): array
	{
		return [
			'order_id' => AiSearchColumn::reference(
				column: 'order_id',
				description: 'The order id this line item belongs to. Obtain it with the order search tool available to you first.',
				modelKey: 'order',
				operators: [Filter::Equal],
			),
			'product_id' => AiSearchColumn::reference(
				column: 'product_id',
				description: 'The product this line item refers to. Obtain it with the product search tool available to you first.',
				modelKey: 'product',
				operators: [Filter::Equal, Filter::In],
			),
			'qty' => AiSearchColumn::string(
				column: 'qty',
				description: 'Quantity',
				operators: [Filter::Equal, Filter::Greater, Filter::Less],
			),
			'price' => AiSearchColumn::string(
				column: 'price',
				description: 'Unit price',
				operators: [Filter::Equal, Filter::Greater, Filter::Less, Filter::Between],
			),
			'discount' => AiSearchColumn::string(
				column: 'discount',
				description: 'Discount amount for this line item',
				operators: [Filter::Equal, Filter::Greater, Filter::Less],
			),
			'total' => AiSearchColumn::string(
				column: 'total',
				description: 'Line total after discount',
				operators: [Filter::Equal, Filter::Greater, Filter::Less, Filter::Between],
			),
		];
	}

	protected function formatRecord(Model $record): array
	{
		return [
			'_id'      => $record->id,
			'_order_id' => $record->order_id,
			'product'  => $record->product?->name,
			'qty'      => $record->qty,
			'price'    => $record->price,
			'discount' => $record->discount,
			'total'    => $record->total,
		];
	}
}
