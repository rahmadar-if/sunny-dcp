<?php

namespace Solaris\Sales\Commands;

use Illuminate\Support\Facades\Facade;

/**
 * @see \VendorName\Skeleton\Skeleton
 */
class SolarisSales extends Facade
{
    protected static function getFacadeAccessor(): string
    {
        return \Solaris\Sales\SolarisSales::class;
    }
}
