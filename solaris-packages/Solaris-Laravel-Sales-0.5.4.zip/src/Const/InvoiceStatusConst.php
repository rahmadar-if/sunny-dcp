<?php

namespace Solaris\Sales\Const;

class InvoiceStatusConst
{
    public const Draft     = "9f146cd7-033d-48d1-acdc-bc71b5f1a5eb";
    public const Issued    = "1338739f-0f90-40eb-86a6-5a2d146e2328"; // change to issued
    public const Completed = "81c1308c-8492-4cba-86cc-f99061b2fdb3";
    public const Cancel    = "7658bef0-3f7d-44f6-a0d3-52649d54c609";
}