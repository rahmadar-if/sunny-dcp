<?php

namespace Solaris\Sales\Const;

class OrderStatusConst
{
    public const Draft        = "95e8938c-caee-4828-b283-1043a96983a5";
    public const Confirmation = "f293dcad-5517-4405-8ca3-49bd575f83b8";
    public const Completed    = "2168e416-a678-43db-bb65-e0f02c2b3ead";
    public const Cancel       = "0e62a1fa-e9dd-4c26-b0ba-5765911bc558";
}