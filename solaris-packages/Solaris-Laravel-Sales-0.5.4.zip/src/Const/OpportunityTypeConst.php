<?php

namespace Solaris\Sales\Const;

class OpportunityTypeConst
{
    public const NewBusiness = "019e5e24-17a8-7303-8d82-8ba5fd50459a";
    public const RepeatOrder = "019e5e24-17a8-76cf-95ae-8087ae073740";
    public const UpsellCross = "019e5e24-17a8-7c52-8db6-c5e7a1899a80";
    public const Tender      = "019e5e24-17a8-7e41-9ecb-53b1e22e88b0";
}