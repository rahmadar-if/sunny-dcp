<?php

namespace Solaris\Sales\Const;

class OpportunityStatusConst
{
    public const Qualification = "994d1a68-3027-4df3-bcf1-9e27341127a5";
    public const Proposal      = "b832eb7b-cc2c-4737-8551-f5f23158fede";
    public const Negotiation   = "80f4e99f-7adc-4213-b487-f28d0848f5dd";
    public const ClosedWon     = "847cc858-86f1-4874-9fdd-baff94561531";
    public const ClosedLost    = "4c9acd2e-1be9-40c1-9ac8-b618a62148f9";
}
