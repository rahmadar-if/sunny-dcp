<?php

namespace Solaris\Sales\Services;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Arr;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Solaris\BaseCRM\Const\LeadSourceConst;
use Solaris\MasterData\Const\ActivityCategoryConst;
use Solaris\Sales\Const\InvoiceStatusConst;
use Solaris\Sales\Const\OpportunityStatusConst;
use Solaris\Sales\Const\OrderStatusConst;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\Number;
use Solaris\Core\Services\Dashboard\DashboardService;
use Solaris\Core\Services\MetricDashboard\MetricChange;
use Solaris\Core\Services\MetricDashboard\MetricDashboard;
use Solaris\Core\Services\MetricDashboard\MetricResponse;

class SalesDashboard
{
    public static function all(array $period, bool $mobile = false): array
    {
        $totalRevenue       = static::totalRevenue($period, $mobile);
        $outstandingInvoice = static::outstandingInvoice($period, $mobile);
        $totalSales         = static::totalSales($period, $mobile);
        $pipelineForecast   = static::pipelineForecast($period, $mobile);
        $leadConversion     = static::leadConversion($period, $mobile);
        $winRate            = static::winRate($period, $mobile);
        $opportunityAmount  = static::opportunityAmount($period, $mobile);
        $opportunityClosedWonAmount = static::opportunityClosedWonAmount($period, $mobile);
        $totalLead          = static::totalLead($period, $mobile);
        $qualifiedLead      = static::qualifiedLead($period, $mobile);
        $totalOpportunity   = static::totalOpportunity($period, $mobile);
        $avgSalesCycle      = static::avgSalesCycle($period, $mobile);
        $avgPaymentTime     = static::avgPaymentTime($period, $mobile);
        $totalOrder         = static::totalOrder($period, $mobile);
        $totalInvoice       = static::totalInvoice($period, $mobile);

        $opportunityPipeline = static::opportunityPipeline($period);
        $activity            = static::activity();
        $salesAnalytic       = static::salesAnalytic($period, $mobile);
        $topSales            = static::topSales($period);
        $topCustomer         = static::topCustomer($period);
        $prospectBySource    = static::prospectBySource($period, $mobile);
        $opportunityOverview = static::opportunityOverview($period);
        $topOpportunity      = static::topOpportunity($period);
        $revenueAnalytic     = static::revenueAnalytic($period, $mobile);
        $recentOrder         = static::recentOrder();
        $topOrder            = static::topOrder($period);
        $topProductOrdered   = static::topProductOrdered($period);

        return [
            'summary' => [
                'total_revenue'        => $totalRevenue,
                'outstanding_invoice'  => $outstandingInvoice,
                'total_sales'          => $totalSales,
                'pipeline_forecast'    => $pipelineForecast,
                'lead_conversion'        => $leadConversion,
                'win_rate'               => $winRate,
                'opportunity_closed_won' => $opportunityClosedWonAmount,
                'sales_analytic'         => $salesAnalytic,
                'opportunity_pipeline' => $opportunityPipeline,
                'activity'             => [
                    'upcoming' => $activity['upcoming'], 
                    'todo'     => $activity['todo'],
                    'recent'   => $activity['recent']
                ],
                'top_sales'    => $topSales, 
                'top_customer' => $topCustomer
            ],
            'lead_opportunity' => [
                'total_lead'           => $totalLead,
                'qualified_lead'       => $qualifiedLead,
                'lead_conversion'      => $leadConversion,
                'total_opportunity'    => $totalOpportunity,
                'opportunity_amount'   => $opportunityAmount,
                'pipeline_forecast'    => $pipelineForecast,
                'win_rate'             => $winRate,
                'avg_sales_cycle'      => $avgSalesCycle,
                'opportunity_pipeline' => $opportunityPipeline,
                'prospect_by_source'   => $prospectBySource,
                'opportunity_overview' => $opportunityOverview,
                'top_opportunity'      => $topOpportunity
            ],
            'order_invoice' => [
                "total_revenue"       => $totalRevenue,
                "outstanding_invoice" => $outstandingInvoice,
                "avg_payment_time"    => $avgPaymentTime,
                "total_sales"         => $totalSales,
                "total_order"         => $totalOrder, 
                "total_invoice"       => $totalInvoice,
                "revenue_analytic"    => $revenueAnalytic,
                "recent_order"        => $recentOrder,
                "top_order"           => $topOrder,
                "top_product_ordered" => $topProductOrdered
            ]
        ];
    }

    // Metric

    public static function totalRevenue(array $period, bool $mobile = false): MetricResponse
    {
        $query   = Helper::model("invoice")::where("status_id", InvoiceStatusConst::Completed);
        $builder = (new MetricDashboard($query, "SUM", "amount"))
            ->setPeriod($period)
            ->setDateColumn("completed_at")
            ->setPrefix("Rp ");

        if ($mobile) {
            $builder->setReadable(true);
        } else {
            $builder->withChange()->withChart()->setRawValue();
        }

        return $builder->generate();
    }

    public static function outstandingInvoice(array $period, bool $mobile = false): MetricResponse
    {
        $query   = Helper::model("invoice")::where("status_id", InvoiceStatusConst::Issued);
        $builder = (new MetricDashboard($query, "SUM", "amount"))
            ->setPeriod($period)
            ->setDateColumn("issued_date")
            ->setPrefix("Rp ");

        if ($mobile) {
            $builder->setReadable(true);
        } else {
            $builder->withChange()->withChart()->setRawValue();
        }

        return $builder->generate();
    }

    public static function totalSales(array $period, bool $mobile = false): MetricResponse
    {
        $query   = Helper::model("order")::whereIn("status_id", [OrderStatusConst::Confirmation, OrderStatusConst::Completed]);
        $builder = (new MetricDashboard($query, "SUM", "amount"))
            ->setPeriod($period)
            ->setDateColumn("date")
            ->setPrefix("Rp ");

        if ($mobile) {
            $builder->setReadable(true);
        } else {
            $builder->withChange()->withChart()->setRawValue();
        }

        return $builder->generate();
    }

    public static function pipelineForecast(array $period, bool $mobile = false): MetricResponse
    {
        $oppModel = Helper::model("opportunity");

        $query = fn(): Builder => $oppModel::whereNotIn("opportunities.status_id", [OpportunityStatusConst::ClosedWon, OpportunityStatusConst::ClosedLost])
            ->select(DB::raw("SUM(opportunities.total_amount * opportunity_statuses.probability / 100) as forecast"))
            ->leftJoin("opportunity_statuses", "opportunity_statuses.id", "=", "opportunities.status_id");

        $currentValue = $query()
            ->whereBetween('opportunities.date', $period)
            ->value('forecast') ?? 0;

        if ($mobile) {
            return new MetricResponse(value: "Rp ".Number::readableNumber($currentValue, 1), change: null, chart: null);
        }

        $previousValue = $query()
            ->whereBetween('opportunities.date', DashboardService::getPreviousPeriod($period[0], $period[1]))
            ->value('forecast') ?? 0;

        $change     = $previousValue > 0 ? (($currentValue - $previousValue) / $previousValue) * 100 : 0;
        $changeType = $change > 0 ? "up" : ($change < 0 ? "down" : null);

        $chart = MetricDashboard::buildChart(
            $query(),
            $period,
            "opportunities.date",
            fn(string $bucketExpr) => "{$bucketExpr} AS bucket, SUM(opportunities.total_amount * opportunity_statuses.probability) AS value"
        );

        return new MetricResponse(
            value:  $currentValue,
            change: new MetricChange(
                value: Number::readableNumber(abs($change), 1)."%",
                type:  $changeType,
                title: DashboardService::getChangeTitle($period[0], $period[1])
            ),
            chart: $chart
        );
    }

    public static function leadConversion(array $period, bool $mobile = false): MetricResponse
    {
        $leadModel = Helper::model("lead");

        $totalLead    = $leadModel::whereBetween("date", $period)->count();
        $totalLeadOpp = $leadModel::whereBetween("date", $period)->whereHas("opportunity")->count();
        $currentValue = $totalLead > 0 ? round(($totalLeadOpp / $totalLead) * 100, 2) : 0;

        if ($mobile) {
            return new MetricResponse(value: Number::readableNumber($currentValue, 1)."%", change: null, chart: null);
        }

        $prevPeriod       = DashboardService::getPreviousPeriod($period[0], $period[1]);
        $prevTotalLead    = $leadModel::whereBetween("date", $prevPeriod)->count();
        $prevTotalLeadOpp = $leadModel::whereBetween("date", $prevPeriod)->whereHas("opportunity")->count();
        $previousValue    = $prevTotalLead > 0 ? round(($prevTotalLeadOpp / $prevTotalLead) * 100, 2) : 0;

        $change     = $previousValue > 0 ? (($currentValue - $previousValue) / $previousValue) * 100 : 0;
        $changeType = $change > 0 ? "up" : ($change < 0 ? "down" : null);

        $queryChart = $leadModel::query()->leftJoin("opportunities", "opportunities.lead_id", "=", "leads.id");

        $chart = MetricDashboard::buildChart(
            $queryChart,
            $period,
            "leads.date",
            fn(string $bucketExpr) => "{$bucketExpr} AS bucket, COUNT(DISTINCT leads.id) as total_lead, COUNT(DISTINCT opportunities.id) as total_opportunity",
            fn($row) => $row->total_lead > 0 ? round(($row->total_opportunity / $row->total_lead) * 100, 2) : 0
        );

        return new MetricResponse(
            value:  Number::readableNumber($currentValue, 1)."%",
            change: new MetricChange(
                value: Number::readableNumber(abs($change), 1)."%",
                type:  $changeType,
                title: DashboardService::getChangeTitle($period[0], $period[1])
            ),
            chart: $chart
        );
    }

    public static function winRate(array $period, bool $mobile = false): MetricResponse
    {
        $oppModel = Helper::model("opportunity");

        $totalOpp    = $oppModel::whereBetween("date", $period)->count();
        $totalOppWin = $oppModel::whereBetween("date", $period)
            ->where("status_id", OpportunityStatusConst::ClosedWon)
            ->count();

        $currentValue = $totalOpp > 0 ? round(($totalOppWin / $totalOpp) * 100, 2) : 0;

        if ($mobile) {
            return new MetricResponse(value: Number::readableNumber($currentValue, 1)."%", change: null, chart: null);
        }

        $prevPeriod      = DashboardService::getPreviousPeriod($period[0], $period[1]);
        $prevTotalOpp    = $oppModel::whereBetween("date", $prevPeriod)->count();
        $prevTotalOppWin = $oppModel::whereBetween("date", $prevPeriod)
            ->where("status_id", OpportunityStatusConst::ClosedWon)
            ->count();

        $previousValue = $prevTotalOpp > 0 ? round(($prevTotalOppWin / $prevTotalOpp) * 100, 2) : 0;

        $change     = $previousValue > 0 ? (($currentValue - $previousValue) / $previousValue) * 100 : 0;
        $changeType = $change > 0 ? "up" : ($change < 0 ? "down" : null);

        $chart = MetricDashboard::buildChart(
            $oppModel::query(),
            $period,
            "date",
            fn(string $bucketExpr) => "{$bucketExpr} AS bucket,
                COUNT(*) AS total_opportunity,
                SUM(
                    CASE
                        WHEN status_id = '" . OpportunityStatusConst::ClosedWon . "'
                        THEN 1 ELSE 0
                    END
                ) AS total_won
            ",
            fn($row) => $row->total_opportunity > 0 ? round(($row->total_won / $row->total_opportunity) * 100, 2) : 0
        );

        return new MetricResponse(
            value:  Number::readableNumber($currentValue, 1)."%",
            change: new MetricChange(
                value: Number::readableNumber(abs($change), 1)."%",
                type:  $changeType,
                title: DashboardService::getChangeTitle($period[0], $period[1])
            ),
            chart: $chart
        );
    }

    public static function opportunityAmount(array $period, bool $mobile = false): MetricResponse
    {
        $query   = Helper::model("opportunity")::whereNot("status_id", OpportunityStatusConst::ClosedLost);
        $builder = (new MetricDashboard($query, "SUM", "total_amount"))
            ->setPeriod($period)
            ->setDateColumn("date")
            ->setPrefix("Rp ");

        if ($mobile) {
            $builder->setReadable(true);
        } else {
            $builder->withChange()->withChart()->setRawValue();
        }

        return $builder->generate();
    }

    public static function opportunityClosedWonAmount(array $period, bool $mobile = false): MetricResponse
    {
        $query   = Helper::model("opportunity")::where("status_id", OpportunityStatusConst::ClosedWon);
        $builder = (new MetricDashboard($query, "SUM", "total_amount"))
            ->setPeriod($period)
            ->setDateColumn("closed_on")
            ->setPrefix("Rp ");

        if ($mobile) {
            $builder->setReadable(true);
        } else {
            $builder->withChange()->withChart()->setRawValue();
        }

        return $builder->generate();
    }

    public static function totalLead(array $period, bool $mobile = false): MetricResponse
    {
        $builder = (new MetricDashboard(new (Helper::model("lead")), "COUNT"))
            ->setPeriod($period)
            ->setDateColumn("date")
            ->setDecimal(0)
            ->setReadable(true);

        if (!$mobile) {
            $builder->withChange()->withChart();
        }

        return $builder->generate();
    }

    public static function qualifiedLead(array $period, bool $mobile = false): MetricResponse
    {
        $query   = Helper::model("lead")::whereHas('opportunity');
        $builder = (new MetricDashboard($query, "COUNT"))
            ->setPeriod($period)
            ->setDateColumn("date")
            ->setDecimal(0)
            ->setReadable(true);

        if (!$mobile) {
            $builder->withChange()->withChart();
        }

        return $builder->generate();
    }

    public static function totalOpportunity(array $period, bool $mobile = false): MetricResponse
    {
        $builder = (new MetricDashboard(new (Helper::model("opportunity")), "COUNT"))
            ->setPeriod($period)
            ->setDateColumn("date")
            ->setDecimal(0)
            ->setReadable(true);

        if (!$mobile) {
            $builder->withChange()->withChart();
        }

        return $builder->generate();
    }
    
    public static function avgSalesCycle(array $period, bool $mobile = false): MetricResponse
    {
        $oppModel = Helper::model("opportunity");

        $driver = DB::getDriverName();
        $dateDiffExpr = match ($driver) {
            'mysql', 'mariadb' => 'DATEDIFF(closed_on, date)',
            'pgsql'  => '(closed_on::date - date::date)',
            'sqlsrv' => 'DATEDIFF(day, date, closed_on) * 1.0',
            'sqlite' => '(julianday(closed_on) - julianday(date))',
            default  => throw new \RuntimeException("Unsupported DB driver: {$driver}"),
        };
        $query = fn(): Builder => $oppModel::where("status_id", OpportunityStatusConst::ClosedWon)
            ->selectRaw("AVG({$dateDiffExpr}) AS avg_sales_cycle");

        $currentValue = $query()
            ->whereBetween('closed_on', $period)
            ->value('avg_sales_cycle') ?? 0;

        $convertDays = function(int|float $days): string {
            if ($days >= 30) {
                return (int) floor($days / 30)." Month";
            }

            if ($days >= 7) {
                return (int) floor($days / 7)." week";
            }

            return (int) floor($days)." Day";
        };

        if ($mobile) {
            return new MetricResponse(value: $convertDays($currentValue), change: null, chart: null);
        }

        $previousValue = $query()
            ->whereBetween('closed_on', DashboardService::getPreviousPeriod($period[0], $period[1]))
            ->value('avg_sales_cycle') ?? 0;

        $change     = $previousValue > 0 ? (($currentValue - $previousValue) / $previousValue) * 100 : 0;
        $changeType = $change > 0 ? "down" : ($change < 0 ? "up" : null);

        $chart = MetricDashboard::buildChart(
            $query(),
            $period,
            "closed_on",
            fn(string $bucketExpr) => "{$bucketExpr} AS bucket, AVG({$dateDiffExpr}) AS value"
        );

        return new MetricResponse(
            value:  $convertDays($currentValue),
            change: new MetricChange(
                value: Number::readableNumber(abs($change), 1)."%",
                type:  $changeType,
                title: DashboardService::getChangeTitle($period[0], $period[1])
            ),
            chart: $chart
        );
    }

    public static function avgPaymentTime(array $period, bool $mobile = false): MetricResponse
    {
        $invoiceModel = Helper::model("invoice");

        $driver = DB::getDriverName();
        $dateDiffExpr = match ($driver) {
            'mysql', 'mariadb' => 'DATEDIFF(completed_at, issued_date)',
            'pgsql'  => '(completed_at::date - issued_date::date)',
            'sqlsrv' => 'DATEDIFF(day, issued_date, completed_at) * 1.0',
            'sqlite' => '(julianday(completed_at) - julianday(issued_date))',
            default  => throw new \RuntimeException("Unsupported DB driver: {$driver}"),
        };
        $query = fn(): Builder => $invoiceModel::where("status_id", InvoiceStatusConst::Completed)
            ->whereNotNull("completed_at")
            ->selectRaw("AVG({$dateDiffExpr}) AS avg_payment_time");

        $currentValue = $query()
            ->whereBetween('completed_at', $period)
            ->value('avg_payment_time') ?? 0;

        $convertDays = function(int|float $days): string {
            if ($days >= 30) {
                return (int) floor($days / 30)." Month";
            }

            if ($days >= 7) {
                return (int) floor($days / 7)." week";
            }

            return (int) floor($days)." Day";
        };

        if ($mobile) {
            return new MetricResponse(value: $convertDays($currentValue), change: null, chart: null);
        }

        $previousValue = $query()
            ->whereBetween('completed_at', DashboardService::getPreviousPeriod($period[0], $period[1]))
            ->value('avg_payment_time') ?? 0;

        $change     = $previousValue > 0 ? (($currentValue - $previousValue) / $previousValue) * 100 : 0;
        $changeType = $change > 0 ? "down" : ($change < 0 ? "up" : null);

        $chart = MetricDashboard::buildChart(
            $query(),
            $period,
            "completed_at",
            fn(string $bucketExpr) => "{$bucketExpr} AS bucket, AVG({$dateDiffExpr}) AS value"
        );

        return new MetricResponse(
            value:  $convertDays($currentValue),
            change: new MetricChange(
                value: Number::readableNumber(abs($change), 1)."%",
                type:  $changeType,
                title: DashboardService::getChangeTitle($period[0], $period[1])
            ),
            chart: $chart
        );
    }

    public static function totalOrder(array $period, bool $mobile = false): MetricResponse
    {
        $builder = (new MetricDashboard(new (Helper::model("order")), "COUNT"))
            ->setPeriod($period)
            ->setDateColumn("date")
            ->setDecimal(0)
            ->setReadable(true);

        if (!$mobile) {
            $builder->withChange()->withChart();
        }

        return $builder->generate();
    }

    public static function totalInvoice(array $period, bool $mobile = false): MetricResponse
    {
        $builder = (new MetricDashboard(new (Helper::model("invoice")), "COUNT"))
            ->setPeriod($period)
            ->setDateColumn("created_at")
            ->setDecimal(0)
            ->setReadable(true);

        if (!$mobile) {
            $builder->withChange()->withChart();
        }

        return $builder->generate();
    }

    // End Metric

    public static function opportunityPipeline(array $period): array
    {
        $status = Helper::model("opportunity_status")::toLookup(false)
            ->where("id", "!=", OpportunityStatusConst::ClosedLost);

        $data = Helper::model("opportunity_status_history")::select(
                "opportunity_statuses.id as status_id",
                DB::raw("COUNT(DISTINCT opportunity_status_histories.opportunity_id) as total")
            )
            ->leftJoin("opportunity_statuses", "opportunity_statuses.id", "=", "opportunity_status_histories.status_id")
            ->leftJoin("opportunities", "opportunities.id", "=", "opportunity_status_histories.opportunity_id")
            ->whereBetween("opportunities.date", $period)
            ->where("opportunity_statuses.id", "!=", OpportunityStatusConst::ClosedLost)
            ->groupBy("opportunity_statuses.id")
            ->orderBy("opportunity_statuses.position", "ASC")
            ->get();

        $series = [];
        foreach ($status as $item) {
            $series[] = [
                'name'  => $item->name,
                'value' => $data->where("status_id", $item->id)->value('total') ?? 0,
                'color' => $item->color
            ];
        }

        return $series;
    }

    public static function salesAnalytic(array $period, bool $mobile = false): array
    {
        $months = DashboardService::getPeriodInMonth($period);

        $driver  = DB::getDriverName();
        $rawExpr = function(string $dateColumn) use($driver) {
            return (object)[
                "month"      => $driver === 'pgsql' ? DB::raw("EXTRACT(MONTH FROM {$dateColumn}) as month") : DB::raw("MONTH({$dateColumn}) as month"),
                "year"       => $driver === 'pgsql' ? DB::raw("EXTRACT(YEAR FROM {$dateColumn}) as year") : DB::raw("YEAR({$dateColumn}) as year"),
                "groupMonth" => $driver === 'pgsql' ? DB::raw("EXTRACT(MONTH FROM {$dateColumn})") : DB::raw("MONTH({$dateColumn})"),
                "groupYear"  => $driver === 'pgsql' ? DB::raw("EXTRACT(YEAR FROM {$dateColumn})") : DB::raw("YEAR({$dateColumn})")
            ];
        };

        $oppRawExpr  = $rawExpr("date");
        $opportunity = Helper::model("opportunity")::select(
            $oppRawExpr->month,
            $oppRawExpr->year,
            DB::raw("SUM(total_amount) as amount")
        )
        ->whereBetween("date", $period)
        ->whereNot("status_id", OpportunityStatusConst::ClosedLost)
        ->groupBy($oppRawExpr->groupMonth, $oppRawExpr->groupYear)
        ->orderBy($oppRawExpr->groupYear, "ASC")
        ->orderBy($oppRawExpr->groupMonth, "ASC")
        ->get()
        ->map(function($item) {
            $item->month_year = Carbon::createFromDate($item->year, $item->month, 1)->translatedFormat('M-y');
            return $item;
        });

        $sales = Helper::model("order")::select(
            $oppRawExpr->month,
            $oppRawExpr->year,
            DB::raw("SUM(amount) as amount")
        )
        ->whereBetween("date", $period)
        ->whereIn("status_id", [OrderStatusConst::Confirmation, OrderStatusConst::Completed])
        ->groupBy($oppRawExpr->groupMonth, $oppRawExpr->groupYear)
        ->orderBy($oppRawExpr->groupYear, "ASC")
        ->orderBy($oppRawExpr->groupMonth, "ASC")
        ->get()
        ->map(function($item) {
            $item->month_year = Carbon::createFromDate($item->year, $item->month, 1)->translatedFormat('M-y');
            return $item;
        });

        $invoiceRawExpr = $rawExpr("completed_at");
        $revenue        = Helper::model("invoice")::select(
            $invoiceRawExpr->month,
            $invoiceRawExpr->year,
            DB::raw("SUM(amount) as amount")
        )
        ->whereBetween("completed_at", $period)
        ->where("status_id", InvoiceStatusConst::Completed)
        ->groupBy($invoiceRawExpr->groupMonth, $invoiceRawExpr->groupYear)
        ->orderBy($invoiceRawExpr->groupYear, "ASC")
        ->orderBy($invoiceRawExpr->groupMonth, "ASC")
        ->get()
        ->map(function($item) {
            $item->month_year = Carbon::createFromDate($item->year, $item->month, 1)->translatedFormat('M-y');
            return $item;
        });

        $opportunitySeries = [];
        $salesSeries       = [];
        $revenueSeries     = [];

        foreach ($months as $value) {
            $opportunitySeries[] = floatval($opportunity->where("month_year", $value)->first()->amount ?? 0);
            $salesSeries[]       = floatval($sales->where("month_year", $value)->first()->amount ?? 0);
            $revenueSeries[]     = floatval($revenue->where("month_year", $value)->first()->amount ?? 0);
        }

        if ($mobile) {
            return [
                "series" => [
                    ["name" => "Opportunity", "color" => "primary", "data" => $opportunitySeries],
                    ["name" => "Sales",       "color" => "info",    "data" => $salesSeries],
                    ["name" => "Revenue",     "color" => "success", "data" => $revenueSeries]
                ],
                "categories" => $months
            ];
        }

        return [
            "series" => [
                ["name" => "Opportunity", "data" => $opportunitySeries],
                ["name" => "Sales",       "data" => $salesSeries],
                ["name" => "Revenue",     "data" => $revenueSeries]
            ],
            "colors" => [
                "var(--primary-color)",
                "var(--info-color)",
                "var(--success-color)"
            ],
            "categories" => $months
        ];
    }

    public static function activity(): array
    {
        $user          = Auth::user();
        $activityModel = Helper::model('activity');

        $icon = fn(string $category): string => match ($category) {
            "Call"    => "ri-phone-line",
            "Visit"   => "ri-user-location-fill",
            "Meeting" => "ri-slideshow-line",
            "Email"   => "ri-mail-line",
            "To Do"   => "ri-task-line"
        };

        $color = fn(string $prioriy): string => match ($prioriy) {
            "High"   => "danger",
            "Medium" => "info",
            "Low"    => "success",
        };

        $prepareColumns = ["subject", "start_date", "end_date", "category", "status", "priority", "account.name", "contact.name"];

        $upcoming = $activityModel::prepared($prepareColumns)
            ->whereNot('category_id', ActivityCategoryConst::ToDo)
            ->where('start_date', '>', now())
            ->where('created_by_id', $user->id)
            ->orderBy('start_date', 'desc')
            ->take(5)
            ->get()
            ->map(function($item) use($icon, $color) {
                $item->icon   = $icon($item->category->name);
                $item->color  = $color($item->priority->name);
                $item->recent = $item->start_date->diffForHumans();

                return $item;
            });

        $todo = $activityModel::toDo()
            ->prepared($prepareColumns)
            ->where('created_by_id', $user->id)
            ->orderBy('start_date', 'desc')
            ->take(5)
            ->get()
            ->map(function($item) use($icon, $color) {
                $item->icon   = $icon($item->category->name);
                $item->color  = $color($item->priority->name);
                $item->recent = $item->start_date->diffForHumans();

                return $item;
            });

        $recent = $activityModel::prepared($prepareColumns)
            ->whereNot('category_id', ActivityCategoryConst::ToDo)
            ->where('start_date', '<', now())
            ->where('created_by_id', $user->id)
            ->orderBy('start_date', 'desc')
            ->take(5)
            ->get()
            ->map(function($item) use($icon, $color) {
                $item->icon   = $icon($item->category->name);
                $item->color  = $color($item->priority->name);
                $item->recent = $item->start_date->diffForHumans();

                return $item;
            });

        return [
            'upcoming' => $upcoming,
            'todo'     => $todo,
            'recent'   => $recent,
        ];
    }

    public static function topSales(array $period): Collection
    {
        return Helper::model("opportunity")::query()
            ->select(
                "users.id as user_id",
                "users.name as user_name",
                "users.email as user_email",
                "users.profile_picture_id as avatar",
                DB::raw("SUM(opportunities.total_amount) as total_opportunity_amount"),
                DB::raw("COUNT(*) as total_opportunity")
            )
            ->leftJoin("users", "users.id", "=", "opportunities.created_by_id")
            ->where("opportunities.status_id", OpportunityStatusConst::ClosedWon)
            ->whereBetween("opportunities.closed_on", $period)
            ->groupBy("users.id", "users.name", "users.email", "users.profile_picture_id")
            ->orderBy("total_opportunity_amount", "desc")
            ->take(5)
            ->get()
            ->map(function($item) {
                $item->total_opportunity_amount = (float) $item->total_opportunity_amount;

                return $item;
            });
    }

    public static function topCustomer(array $period): Collection
    {
        return Helper::model("invoice")::query()
            ->select(
                "accounts.id as account_id",
                "accounts.name as account_name",
                "contacts.name as primary_contact",
                "accounts.profile_picture_id as avatar",
                DB::raw("SUM(invoices.amount) as total_invoice_amount"),
                DB::raw("COUNT(*) as total_invoice")
            )
            ->leftJoin("accounts", "accounts.id", "=", "invoices.account_id")
            ->leftJoin("contacts", "contacts.id", "=", "accounts.primary_contact_id")
            ->where("invoices.status_id", InvoiceStatusConst::Completed)
            ->whereBetween("invoices.completed_at", $period)
            ->groupBy("accounts.id", "accounts.name", "contacts.name", "accounts.profile_picture_id")
            ->orderBy("total_invoice_amount", "desc")
            ->take(5)
            ->get()
            ->map(function($item) {
                $item->total_invoice_amount = (float) $item->total_invoice_amount;

                return $item;
            });
    }

    public static function prospectBySource(array $period, bool $mobile = false): array
    {
        $sources = Helper::model("lead_source")::toLookup(false);

        $leadQuery = fn(array $dates): Builder => Helper::model("lead")::select(
                "source_id",
                DB::raw("COUNT(*) as total")
            )
            ->whereDoesntHave("opportunity")
            ->whereBetween("date", $dates)
            ->groupBy("source_id");

        $oppQuery = fn(array $dates): Builder => Helper::model("opportunity")::select(
                "source_id",
                DB::raw("COUNT(*) as total")
            )
            ->whereBetween("date", $dates)
            ->groupBy("source_id");

        $prevPeriod = DashboardService::getPreviousPeriod($period[0], $period[1]);

        $lead     = $leadQuery($period)->get();
        $prevLead = $leadQuery($prevPeriod)->get();

        $opportunity     = $oppQuery($period)->get();
        $prevOpportunity = $oppQuery($prevPeriod)->get();

        $color = fn(string $sourceId): string => match ($sourceId) {
            LeadSourceConst::Email       => "primary",
            LeadSourceConst::Call        => "secondary",
            LeadSourceConst::SocialMedia => "info",
            LeadSourceConst::Referral    => "success",
            default => "primary"
        };

        $rawResult = [];
        foreach ($sources as $source) {
            $_lead     = $lead->where('source_id', $source->id)->first();
            $_prevLead = $prevLead->where("source_id", $source->id)->first();
            $opp       = $opportunity->where('source_id', $source->id)->first();
            $prevOpp   = $prevOpportunity->where('source_id', $source->id)->first();

            $total     = ((int)$_lead?->total ?? 0) + ((int)$opp?->total ?? 0);
            $prevTotal = ((int)$_prevLead?->total ?? 0) + ((int)$prevOpp?->total ?? 0);

            $change     = $prevTotal > 0 ? (($total - $prevTotal) / $prevTotal) * 100 : 0;
            $changeType = $change > 0 ? "down" : ($change < 0 ? "up" : null);

            $rawResult[] = [
                'id'          => $source->id,
                'name'        => $source->name,
                'color'       => $color($source->id),
                'total'       => $total,
                'change'      => Number::readableNumber(abs($change), 1)."%",
                'change_type' => $changeType,
            ];
        }

        if ($mobile) {
            return [
                "detail" => array_map(fn($item) => (object)[
                    "name"        => $item['name'],
                    "color"       => $item['color'],
                    "total"       => $item['total'],
                    "change"      => $item['change'],
                    "change_type" => $item['change_type'],
                ], $rawResult)
            ];
        }

        $icon = fn(string $sourceId): string => match ($sourceId) {
            LeadSourceConst::Email       => "ri-mail-line",
            LeadSourceConst::Call        => "ri-phone-line",
            LeadSourceConst::SocialMedia => "ri-hashtag",
            LeadSourceConst::Referral    => "ri-user-follow-line",
            default => "ri-database-2-line"
        };

        $result = [];
        foreach ($rawResult as $item) {
            $ct = $item['change_type'];
            $result[] = (object)[
                "name"        => $item['name'],
                "icon"        => $icon($item['id']),
                "color"       => $item['color'],
                "total"       => $item['total'],
                "change"      => $item['change'],
                "changeIcon"  => $ct ? ($ct == "up" ? "ti ti-arrow-narrow-up" : "ti ti-arrow-narrow-down") : null,
                "changeColor" => $ct ? ($ct == "up" ? "success" : "danger") : "primary",
            ];
        }

        return [
            "detail" => $result,
            "chart"  => [
                "series" => Arr::map($result, fn($item) => $item->total),
                "label"  => Arr::map($result, fn($item) => $item->name),
                "colors" => Arr::map($result, fn($item) => "var(--{$item->color}-color)")
            ]
        ];
    }

    public static function opportunityOverview(array $period): array
    {
        $oppModel = Helper::model("opportunity");
        $query    = fn(array $dates): Builder => $oppModel::select(
                "status_id",
                DB::raw("COUNT(*) as total"),
                DB::raw("SUM(total_amount) as total_amount")
            )
            ->whereBetween("date", $dates)
            ->groupBy("status_id");

        $statuses      = Helper::model("opportunity_status")::toLookup(false);
        $currentValue  = $query($period)->get();
        $previousValue = $query(DashboardService::getPreviousPeriod($period[0], $period[1]))->get();
        
        $icon = fn(string $statusId): string => match ($statusId) {
            OpportunityStatusConst::Qualification => "ri-questionnaire-line",
            OpportunityStatusConst::Proposal      => "ri-file-paper-line",
            OpportunityStatusConst::Negotiation   => "ri-discuss-line",
            OpportunityStatusConst::ClosedWon     => "ri-checkbox-circle-line",
            OpportunityStatusConst::ClosedLost    => "ri-close-circle-line",
        };

        $changeIcon = fn(?string $changeType, string $statusId): ?string => match (true) {
            $statusId == OpportunityStatusConst::ClosedLost && $changeType == "up"   => "ri-arrow-down-line",
            $statusId == OpportunityStatusConst::ClosedLost && $changeType == "down" => "ri-arrow-up-line",
            $changeType == "up"   => "ri-arrow-up-line",
            $changeType == "down" => "ri-arrow-down-line",
            default => null
        };

        $changeColor = fn(?string $changeType, string $statusId): string => match (true) {
            $statusId == OpportunityStatusConst::ClosedLost && $changeType == "up"   => "danger",
            $statusId == OpportunityStatusConst::ClosedLost && $changeType == "down" => "success",
            $changeType == "up"   => "success",
            $changeType == "down" => "danger",
            default => "primary"
        };

        $total       = $currentValue->sum("total");
        $totalAmount = $currentValue
            ->where("status_id", "!=", OpportunityStatusConst::ClosedLost)
            ->sum("total_amount");

        $result = [];
        foreach($statuses as $status) {
            $currOverview = $currentValue->where("status_id", $status->id)->first();
            $prevOverview = $previousValue->where("status_id", $status->id)->first();

            $currAmount = (float)$currOverview?->total_amount ?? 0;
            $prevAmount = (float)$prevOverview?->total_amount ?? 0;

            $change     = $prevAmount > 0 ? (($currAmount - $prevAmount) / $prevAmount) * 100 : 0;
            $changeType = $change > 0 ? "down" : ($change < 0 ? "up" : null);

            $result[] = (object)[
                "id"           => $status->id,
                "name"         => $status->name,
                "total"        => $currOverview?->total ?? 0,
                "total_amount" => $status->id == OpportunityStatusConst::ClosedLost ? $currAmount * -1 : $currAmount,
                "icon"         => $icon($status->id),
                "color"        => $status->color,
                "percent"      => $currOverview?->total > 0 ? $currOverview?->total / $total * 100 : 0,
                "change"       => Number::readableNumber(abs($change), 1)."%",
                "changeIcon"   => $changeIcon($changeType, $status->id),
                "changeColor"  => $changeColor($changeType, $status->id),
            ];
        }

        return [
            "total"        => $total,
            "total_amount" => $totalAmount,
            "detail"       => $result
        ];
    }

    public static function topOpportunity(array $period): Collection
    {
        return Helper::model("opportunity")::prepared([
                "name", 
                "date",
                "source.name",
                "customer[name, profile_picture.id]",
                "decision_maker[name, profile_picture.id]", 
                "total_amount",
                "status[name, color, probability]"
            ])
            ->whereNotIn('status_id', [OpportunityStatusConst::Qualification, OpportunityStatusConst::ClosedWon, OpportunityStatusConst::ClosedLost])
            ->whereBetween("date", $period)
            ->sort([['status.probability', 'desc'], ['total_amount', 'desc'], ['date', 'desc']])
            ->skip(0)
            ->take(5)
            ->get()
            ->map(function($item) {
                $item->total_amount = (float) $item->total_amount;

                return $item;
            });
    }

    public static function revenueAnalytic(array $period, bool $mobile = false): array
    {
        $months = DashboardService::getPeriodInMonth($period);

        $driver  = DB::getDriverName();
        $rawExpr = function(string $dateColumn) use($driver) {
            return (object)[
                "month"      => $driver === 'pgsql' ? DB::raw("EXTRACT(MONTH FROM {$dateColumn}) as month") : DB::raw("MONTH({$dateColumn}) as month"),
                "year"       => $driver === 'pgsql' ? DB::raw("EXTRACT(YEAR FROM {$dateColumn}) as year") : DB::raw("YEAR({$dateColumn}) as year"),
                "groupMonth" => $driver === 'pgsql' ? DB::raw("EXTRACT(MONTH FROM {$dateColumn})") : DB::raw("MONTH({$dateColumn})"),
                "groupYear"  => $driver === 'pgsql' ? DB::raw("EXTRACT(YEAR FROM {$dateColumn})") : DB::raw("YEAR({$dateColumn})")
            ];
        };

        $salesRawExpr = $rawExpr("date");
        $sales        = Helper::model("order")::select(
            $salesRawExpr->month,
            $salesRawExpr->year,
            DB::raw("SUM(amount) as amount")
        )
        ->whereBetween("date", $period)
        ->where("status_id", OrderStatusConst::Completed)
        ->groupBy($salesRawExpr->groupMonth, $salesRawExpr->groupYear)
        ->orderBy($salesRawExpr->groupYear, "ASC")
        ->orderBy($salesRawExpr->groupMonth, "ASC")
        ->get()
        ->map(function($item) {
            $item->month_year = Carbon::createFromDate($item->year, $item->month, 1)->translatedFormat('M-y');
            return $item;
        });

        $revenueRawExpr = $rawExpr("completed_at");
        $revenue        = Helper::model("invoice")::select(
            $revenueRawExpr->month,
            $revenueRawExpr->year,
            DB::raw("SUM(amount) as amount")
        )
        ->whereBetween("completed_at", $period)
        ->where("status_id", InvoiceStatusConst::Completed)
        ->groupBy($revenueRawExpr->groupMonth, $revenueRawExpr->groupYear)
        ->orderBy($revenueRawExpr->groupYear, "ASC")
        ->orderBy($revenueRawExpr->groupMonth, "ASC")
        ->get()
        ->map(function($item) {
            $item->month_year = Carbon::createFromDate($item->year, $item->month, 1)->translatedFormat('M-y');
            return $item;
        });

        $outExpr = $rawExpr("issued_date");
        $outstanding = Helper::model("invoice")::select(
            $outExpr->month,
            $outExpr->year,
            DB::raw("SUM(amount) as amount")
        )
        ->whereBetween("issued_date", $period)
        ->where("status_id", InvoiceStatusConst::Issued)
        ->groupBy($outExpr->groupMonth, $outExpr->groupYear)
        ->orderBy($outExpr->groupYear, "ASC")
        ->orderBy($outExpr->groupMonth, "ASC")
        ->get()
        ->map(function($item) {
            $item->month_year = Carbon::createFromDate($item->year, $item->month, 1)->translatedFormat('M-y');
            return $item;
        });

        $orderSeries       = [];
        $revenueSeries     = [];
        $outstandingSeries = [];

        foreach ($months as $value) {
            $orderSeries[]       = floatval($sales->where("month_year", $value)->first()->amount ?? 0);
            $revenueSeries[]     = floatval($revenue->where("month_year", $value)->first()->amount ?? 0);
            $outstandingSeries[] = floatval($outstanding->where("month_year", $value)->first()->amount ?? 0);
        }

        if ($mobile) {
            return [
                "series" => [
                    ["name" => "Sales",       "color" => "primary", "data" => $orderSeries],
                    ["name" => "Revenue",     "color" => "success", "data" => $revenueSeries],
                    ["name" => "Outstanding", "color" => "danger",  "data" => $outstandingSeries]
                ],
                "categories" => $months
            ];
        }

        return [
            "series" => [
                ["name" => "Sales",       "data" => $orderSeries],
                ["name" => "Revenue",     "data" => $revenueSeries],
                ["name" => "Outstanding", "data" => $outstandingSeries]
            ],
            "colors" => [
                "var(--primary-color)",
                "var(--success-color)",
                "var(--danger-color)"
            ],
            "categories" => $months
        ];
    }

    public static function recentOrder(): Collection
    {
        return Helper::model('order')::prepared("number", "date", "status.name", "account[name, profile_picture.id], amount")
            ->where('date', '<', now())
            ->orderBy('date', 'desc')
            ->take(5)
            ->get()
            ->map(function($item) {
                $item->recent = $item->date->diffForHumans();
                $item->amount = (float) $item->amount;

                return $item;
            });
    }

    public static function topOrder(array $period): Collection
    {
        return Helper::model("order")::prepared("number", "status.name", "account[name, profile_picture.id], amount")
            ->whereNotIn("status_id", [OrderStatusConst::Completed, OrderStatusConst::Cancel])
            ->whereBetween("date", $period)
            ->orderBy("amount", "desc")
            ->take(5)
            ->get()
            ->map(function($item) {
                $item->amount = (float) $item->amount;

                return $item;
            });
    }

    public static function topProductOrdered(array $period): Collection
    {
        return Helper::model("order_detail")::addSelect([
                "order_details.product_id",
                "products.name as product_name",
                "products.product_picture_id as avatar",
                DB::raw("SUM(order_details.qty) as total_qty"),
                DB::raw("SUM(order_details.total) as total_amount"),
                DB::raw("COUNT(DISTINCT order_details.order_id) as order_count"),
            ])
            ->leftJoin("products", "products.id", "=", "order_details.product_id")
            ->where("products.active", true)
            ->whereHas("order", fn ($q) => $q->whereBetween("date", $period)
                ->whereNot("status_id", OrderStatusConst::Cancel)
            )
            ->groupBy("order_details.product_id", "products.name", "products.product_picture_id")
            ->orderByDesc("total_amount")
            ->take(5)
            ->get()
            ->map(function($item) {
                $item->total_amount = (float) $item->total_amount;

                return $item;
            });
    }
}