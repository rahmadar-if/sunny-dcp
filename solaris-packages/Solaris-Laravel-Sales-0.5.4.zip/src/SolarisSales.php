<?php

namespace Solaris\Sales;

class SolarisSales {}
