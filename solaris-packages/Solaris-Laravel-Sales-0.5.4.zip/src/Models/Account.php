<?php

namespace Solaris\Sales\Models;

use Illuminate\Database\Eloquent\Relations\HasMany;
use Solaris\BaseCRM\Models\Account as BaseAccount;
use Solaris\Core\Helpers\Helper;

class Account extends BaseAccount
{
    public function opportunities(): HasMany
    {
        return $this->hasMany(Helper::model('opportunity'), 'customer_id', 'id');
    }

    public function orders(): HasMany
    {
        return $this->hasMany(Helper::model('order'), 'account_id', 'id');
    }

    public function invoices(): HasMany
    {
        return $this->hasMany(Helper::model('invoice'), 'account_id', 'id');
    }

    public function contracts(): HasMany
    {
        return $this->hasMany(Helper::model('contract'), 'account_id', 'id');
    }
}
