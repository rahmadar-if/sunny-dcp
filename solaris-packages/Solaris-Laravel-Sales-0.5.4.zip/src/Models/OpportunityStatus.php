<?php

namespace Solaris\Sales\Models;

use Solaris\Core\Models\LookupStage;

class OpportunityStatus extends LookupStage
{
    protected $table                = 'opportunity_statuses';
    protected array $prepareColumns = ['id', 'name', 'color', 'position', 'group_id', 'probability'];
}
