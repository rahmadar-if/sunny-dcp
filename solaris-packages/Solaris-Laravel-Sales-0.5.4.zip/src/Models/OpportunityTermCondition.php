<?php

namespace Solaris\Sales\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FolderAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\ImportAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

#[FormAccess()]
#[DataTableAccess()]
#[FolderAccess()]
#[ExportAccess()]
#[ImportAccess()]
class OpportunityTermCondition extends BaseModel
{
    protected $table = "opportunity_term_conditions";

    public function opportunity(): BelongsTo
    {
        return $this->belongsTo(Helper::model('opportunity'), "opportunity_id", "id");
    }

    public function importRules(): array
    {
        return [
            'opportunity_id' => ['required', 'uuid'],
            'subject'        => ['required', 'string'],
        ];
    }
}
