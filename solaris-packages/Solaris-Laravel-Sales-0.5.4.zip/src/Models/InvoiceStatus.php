<?php

namespace Solaris\Sales\Models;

use Solaris\Core\Models\LookupStage;

class InvoiceStatus extends LookupStage
{
    protected $table = 'invoice_statuses';
}
