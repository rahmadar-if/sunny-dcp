<?php

namespace Solaris\Sales\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FolderAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\ImportAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

#[FormAccess()]
#[DataTableAccess()]
#[FolderAccess()]
#[ExportAccess()]
#[ImportAccess()]
class OpportunityProduct extends BaseModel
{
    protected $table                = "opportunity_products";
    protected array $prepareColumns = ["opportunity_id", "product_id", "qty", "price", "disc", "total"];

    protected function casts(): array
    {
        return array_merge(parent::casts(), [
            "qty"   => "integer",
            'price' => 'float',
            'disc'  => 'float',
            'total' => 'float',
        ]);
    }

    public function opportunity(): BelongsTo
    {
        return $this->belongsTo(Helper::model('opportunity'), "opportunity_id", "id");
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Helper::model('product'), "product_id", "id");
    }

    public function importRules(): array
    {
        return [
            'opportunity_id' => ['required', 'uuid'],
            'product_id'     => ['required', 'uuid'],
            'price'          => ['required', 'decimal:0,2'],
            'qty'            => ['required', 'integer'],
            'disc'           => ['nullable', 'decimal:0,2'],
            'total'          => ['required', 'decimal:0,2'],
        ];
    }
}
