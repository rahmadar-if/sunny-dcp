<?php

namespace Solaris\Sales\Models;

use Illuminate\Database\Eloquent\Builder;
use Solaris\BaseCRM\Models\Product as BaseProduct;
use Solaris\Core\Attributes\LookupAccess;

#[LookupAccess(scopes: [
    "active", 
    "availableInOpportunityProduct",
    "availableInOrderDetail",
    "availableInInvoiceDetail"
], extend: true)]
class Product extends BaseProduct
{
    public function scopeAvailableInOpportunityProduct(Builder $query, string $opportunityId)
    {
        return $query->active()->whereNotIn("id", function($query) use($opportunityId) {
            $query->select("product_id")
                ->from("opportunity_products")
                ->where("opportunity_id", $opportunityId);
        });
    }

    public function scopeAvailableInOrderDetail(Builder $query, string $orderId)
    {
        return $query->active()->whereNotIn("id", function($query) use($orderId) {
            $query->select("product_id")
                ->from("order_details")
                ->where("order_id", $orderId);
        });
    }

    public function scopeAvailableInInvoiceDetail(Builder $query, string $invoiceId)
    {
        return $query->active()->whereNotIn("id", function($query) use($invoiceId) {
            $query->select("product_id")
                ->from("invoice_details")
                ->where("invoice_id", $invoiceId);
        });
    }
}