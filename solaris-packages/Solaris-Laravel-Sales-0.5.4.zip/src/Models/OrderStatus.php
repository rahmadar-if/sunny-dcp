<?php

namespace Solaris\Sales\Models;

use Solaris\Core\Models\LookupStage;

class OrderStatus extends LookupStage
{
    protected $table = 'order_statuses';
}
