<?php

namespace Solaris\Sales\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\StageHistoryModel;

class OrderStatusHistory extends StageHistoryModel
{
    protected $table = 'order_status_histories';

    public function status(): BelongsTo
    {
        return $this->belongsTo(Helper::model('order_status'), 'status_id', 'id');
    }

    public function order(): BelongsTo
    {
        return $this->belongsTo(Helper::model('order'), 'order_id', 'id');
    }

    protected static function parentModel(): string
    {
        return Helper::model('order');
    }

    protected static function parentColumn(): string
    {
        return 'order_id';
    }

    protected static function stageModel(): string
    {
        return Helper::model('order_status');
    }

    protected static function stageColumn(): string
    {
        return 'status_id';
    }
}
