<?php

namespace Solaris\Sales\Models;

use Illuminate\Database\Eloquent\Relations\HasOne;
use Solaris\BaseCRM\Models\Lead as BaseLead;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Attributes\MetricAccess;

#[MetricAccess()]
class Lead extends BaseLead
{
    public function opportunity(): HasOne
    {
        return $this->hasOne(Helper::model('opportunity'), 'lead_id', 'id');
    }
}