<?php

namespace Solaris\Sales\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FolderAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\ImportAccess;
use Solaris\Core\Attributes\LookupAccess;
use Solaris\Core\Attributes\MetricAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Interfaces\Model\SolarisKanban;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Traits\Model\HasKanban;
use Solaris\Core\Traits\Model\HasStageHistory;
use Solaris\Sales\Const\OpportunityStatusConst;

#[FormAccess()]
#[LookupAccess()]
#[DataTableAccess(scopes: ["open"])]
#[MetricAccess(scopes: ["closedWon"])]
#[FolderAccess()]
#[ExportAccess()]
#[ImportAccess()]
class Opportunity extends BaseModel implements SolarisKanban
{
    use HasKanban, HasStageHistory;

    protected $table                = 'opportunities';
    protected ?string $displayValue = 'name';
    protected array   $searchColumns = ['notes_plain' => 'FullText'];

    protected static function booted()
    {
        parent::booted();

        $syncNotes = function ($opportunity) {
            if ($opportunity->isDirty('notes') || ($opportunity->notes && !$opportunity->notes_plain)) {
                $opportunity->notes_plain = $opportunity->notes ? Helper::stripHtml($opportunity->notes) : null;
            }
        };

        static::creating($syncNotes);
        static::updating($syncNotes);
    }

    public function getBoardColumn(): ?string
    {
        return 'status_id';
    }

    public function getBoardPositionColumn(): ?string
    {
        return 'position';
    }

    protected static function stageHistoryModel(): string
    {
        return Helper::model('opportunity_status_history');
    }

    protected static function stageColumn(): string
    {
        return 'status_id';
    }
    
    protected function casts(): array
    {
        return array_merge(parent::casts(), [
            'date'                => 'date:d M Y',
            'status_date'         => 'date:d M Y',
            'closed_on'           => 'date:d M Y',
            'budget'              => 'float',
            'amount'              => 'float',
            'probability_percent' => 'float',
            'discount_amount'     => 'float',
            'discount_percent'    => 'float',
            'total_amount'        => 'float',
            'is_new_customer'     => 'boolean'
        ]);
    }

    public function status(): BelongsTo
    {
        return $this->belongsTo(Helper::model('opportunity_status'), 'status_id', 'id');
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Helper::model('account'), 'customer_id', 'id');
    }

    public function decision_maker(): BelongsTo
    {
        return $this->belongsTo(Helper::model('contact'), 'decision_maker_id', 'id');
    }

    public function lead(): BelongsTo
    {
        return $this->belongsTo(Helper::model('lead'), 'lead_id', 'id');
    }

    public function type(): BelongsTo
    {
        return $this->belongsTo(Helper::model('opportunity_type'), 'type_id', 'id');
    }

    public function source(): BelongsTo
    {
        return $this->belongsTo(Helper::model('lead_source'), 'source_id', 'id');
    }

    public function products(): HasMany
    {
        return $this->hasMany(Helper::model('opportunity_product'), 'opportunity_id', 'id');
    }

    public function status_histories(): HasMany
    {
        return $this->hasMany(Helper::model('opportunity_status_history'), 'opportunity_id', 'id');
    }

    public function quotation_histories(): HasMany
    {
        return $this->hasMany(Helper::model('opportunity_quotation_history'), 'opportunity_id', 'id');
    }

    public function activities(): HasMany
    {
        return $this->hasMany(Helper::model('activity'), 'opportunity_id', 'id');
    }

    public function teams(): HasMany
    {
        return $this->hasMany(Helper::model('opportunity_team'), 'opportunity_id', 'id');
    }

    public function contacts(): HasMany
    {
        return $this->hasMany(Helper::model('opportunity_contact'), 'opportunity_id', 'id');
    }

    public function competitors(): HasMany
    {
        return $this->hasMany(Helper::model('opportunity_competitor'), 'opportunity_id', 'id');
    }

    public function term_conditions(): HasMany
    {
        return $this->hasMany(Helper::model('opportunity_term_condition'), 'opportunity_id', 'id');
    }

    public function orders(): HasMany
    {
        return $this->hasMany(Helper::model('order'), 'opportunity_id', 'id');
    }

    public function scopeOpen(Builder $query)
    {
        return $query->whereHas("status", fn($query) => $query->where("is_final_stage", false));
    }

    public function scopeClosedWon(Builder $query)
    {
        return $query->where("status_id", OpportunityStatusConst::ClosedWon);
    }

    public function importRules(): array
    {
        return [
            'name'                => ['required', 'string', 'max:255'],
            'date'                => ['required', 'date'],
            'customer_id'         => ['required', 'uuid'],
            'decision_maker_id'   => ['nullable', 'uuid'],
            'customer_need'       => ['required', 'string'],
            'budget'              => ['nullable', 'decimal:0,2'],
            'source_id'           => ['required', 'uuid'],
            'status_id'           => ['nullable', 'uuid'],
            'probability_percent' => ['nullable', 'integer', 'min:0', 'max:100'],
            'quotation_number'    => ['nullable', 'string', 'max:255'],
            'latest_status'       => ['nullable', 'string', 'max:255'],
            'status_date'         => ['nullable', 'date'],
            'description'         => ['nullable', 'string'],
            'is_new_customer'     => ['nullable', 'boolean'],
            'closed_on'           => ['nullable', 'date'],
            'our_strengths'       => ['nullable', 'string'],
            'our_weaknesses'      => ['nullable', 'string'],
            'sales_tactics'       => ['nullable', 'string'],
            'notes'               => ['nullable', 'string'],
        ];
    }
}
