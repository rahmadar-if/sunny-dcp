<?php

namespace Solaris\Sales\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Solaris\BaseCRM\Models\Contact as BaseContact;
use Solaris\Core\Attributes\LookupAccess;
use Solaris\Core\Helpers\Helper;

#[LookupAccess(scopes: ["availableInOpportunityContact"], extend: true)]
class Contact extends BaseContact
{
    // Opportunities where this contact is the direct decision maker (opportunities.decision_maker_id).
    public function opportunities(): HasMany
    {
        return $this->hasMany(Helper::model('opportunity'), 'decision_maker_id', 'id');
    }

    // Every opportunity this contact is involved in, any role, via the opportunity_contacts pivot —
    // broader than opportunities() above, which only covers the decision-maker case.
    public function opportunity_contacts(): HasMany
    {
        return $this->hasMany(Helper::model('opportunity_contact'), 'contact_id', 'id');
    }

    public function orders(): HasMany
    {
        return $this->hasMany(Helper::model('order'), 'contact_id', 'id');
    }

    public function invoices(): HasMany
    {
        return $this->hasMany(Helper::model('invoice'), 'contact_id', 'id');
    }

    public function contracts(): HasMany
    {
        return $this->hasMany(Helper::model('contract'), 'contact_id', 'id');
    }

    public function scopeAvailableInOpportunityContact(Builder $query, string $opportunityId)
    {
        return $query
            ->whereNotIn("id", function($query) use($opportunityId) {
                $query->select("contact_id")
                    ->from("opportunity_contacts")
                    ->where("opportunity_id", $opportunityId);
            })
            ->whereIn("account_id", function($query) use($opportunityId) {
                $query->select("customer_id")
                    ->from("opportunities")
                    ->where("id", $opportunityId);
            });
    }
}