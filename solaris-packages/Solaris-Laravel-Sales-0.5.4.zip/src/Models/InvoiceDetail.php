<?php

namespace Solaris\Sales\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FolderAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\ImportAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

#[FormAccess()]
#[DataTableAccess()]
#[FolderAccess()]
#[ExportAccess()]
#[ImportAccess()]
class InvoiceDetail extends BaseModel
{
    protected $table                = "invoice_details";
    protected array $prepareColumns = ["invoice_id", "product_id", "qty", "price", "discount", "total"];

    protected function casts(): array
    {
        return array_merge(parent::casts(), [
            "qty"      => "integer",
            'price'    => 'float',
            'discount' => 'float',
            'total'    => 'float',
        ]);
    }

    public function invoice(): BelongsTo
    {
        return $this->belongsTo(Helper::model('invoice'), "invoice_id", "id");
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Helper::model('product'), "product_id", "id");
    }

    public function importRules(): array
    {
        return [
            'invoice_id' => ['required', 'uuid'],
            'product_id' => ['required', 'uuid'],
            'price'      => ['required', 'decimal:0,2'],
            'qty'        => ['required', 'integer'],
            'discount'   => ['nullable', 'decimal:0,2'],
            'total'      => ['required', 'decimal:0,2'],
        ];
    }
}
