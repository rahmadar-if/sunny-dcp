<?php

namespace Solaris\Sales\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FolderAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\ImportAccess;
use Solaris\Core\Attributes\LookupAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

#[LookupAccess()]
#[FormAccess()]
#[DataTableAccess()]
#[FolderAccess()]
#[ExportAccess()]
#[ImportAccess()]
class Contract extends BaseModel
{
    protected $table                = 'contracts';
    protected ?string $displayValue = 'number';
    protected array $prepareColumns = ['number', 'subject', 'account_id', 'contact_id', 'start_date', 'end_date', 'amount', 'notes'];
    protected array $searchColumns  = ['notes_plain' => 'FullText'];

    protected static function booted()
    {
        parent::booted();

        $syncNotes = function ($contract) {
            if ($contract->isDirty('notes') || ($contract->notes && !$contract->notes_plain)) {
                $contract->notes_plain = $contract->notes ? Helper::stripHtml($contract->notes) : null;
            }
        };

        static::creating($syncNotes);
        static::updating($syncNotes);
    }

    protected function casts(): array
    {
        return array_merge(parent::casts(),
        [
            'amount'     => 'float',
            'start_date' => 'date:d M Y',
            'end_date'   => 'date:d M Y'
        ]);
    }

    public function account(): BelongsTo
    {
        return $this->belongsTo(Helper::model('account'), 'account_id', 'id');
    }

    public function contact(): BelongsTo
    {
        return $this->belongsTo(Helper::model('contact'), 'contact_id', 'id');
    }

    public function importRules(): array
    {
        return [
            'number'     => ['required', 'string'],
            'subject'    => ['required', 'string'],
            'account_id' => ['required', 'uuid'],
            'contact_id' => ['nullable', 'uuid'],
            'start_date' => ['required', 'date'],
            'end_date'   => ['nullable', 'date'],
            'amount'     => ['nullable', 'decimal:0,2'],
            'notes'      => ['nullable', 'string'],
        ];
    }
}
