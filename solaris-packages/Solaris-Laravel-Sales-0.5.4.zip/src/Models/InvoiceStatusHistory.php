<?php

namespace Solaris\Sales\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\StageHistoryModel;

class InvoiceStatusHistory extends StageHistoryModel
{
    protected $table = 'invoice_status_histories';

    public function status(): BelongsTo
    {
        return $this->belongsTo(Helper::model('invoice_status'), 'status_id', 'id');
    }

    public function invoice(): BelongsTo
    {
        return $this->belongsTo(Helper::model('invoice'), 'invoice_id', 'id');
    }

    protected static function parentModel(): string
    {
        return Helper::model('invoice');
    }

    protected static function parentColumn(): string
    {
        return 'invoice_id';
    }

    protected static function stageModel(): string
    {
        return Helper::model('invoice_status');
    }

    protected static function stageColumn(): string
    {
        return 'status_id';
    }
}
