<?php

namespace Solaris\Sales\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FolderAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\ImportAccess;
use Solaris\Core\Attributes\LookupAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Traits\Model\HasStageHistory;

#[FormAccess()]
#[LookupAccess()]
#[DataTableAccess()]
#[FolderAccess()]
#[ExportAccess()]
#[ImportAccess()]
class Invoice extends BaseModel
{
    use HasStageHistory;

    protected $table                = 'invoices';
    protected ?string $displayValue = 'number';
    protected array   $searchColumns = ['notes_plain' => 'FullText'];

    protected static function booted()
    {
        parent::booted();

        $syncNotes = function ($invoice) {
            if ($invoice->isDirty('notes') || ($invoice->notes && !$invoice->notes_plain)) {
                $invoice->notes_plain = $invoice->notes ? Helper::stripHtml($invoice->notes) : null;
            }
        };

        static::creating($syncNotes);
        static::updating($syncNotes);
    }

    protected static function stageHistoryModel(): string
    {
        return Helper::model('invoice_status_history');
    }

    protected static function stageColumn(): string
    {
        return 'status_id';
    }

    protected function casts(): array
    {
        return array_merge(parent::casts(),
        [
            'amount'       => 'float',
            'issued_date'  => 'date:d M Y',
            'due_date'     => 'date:d M Y',
            'completed_at' => 'date:d M Y'
        ]);
    }

    public function status(): BelongsTo
    {
        return $this->belongsTo(Helper::model('invoice_status'), 'status_id', 'id');
    }

    public function account(): BelongsTo
    {
        return $this->belongsTo(Helper::model('account'), 'account_id', 'id');
    }

    public function contact(): BelongsTo
    {
        return $this->belongsTo(Helper::model('contact'), 'contact_id', 'id');
    }

    public function order(): BelongsTo
    {
        return $this->belongsTo(Helper::model('order'), 'order_id', 'id');
    }

    public function detail(): HasMany
    {
        return $this->hasMany(Helper::model('invoice_detail'), 'invoice_id', 'id');
    }

    public function status_history(): HasMany
    {
        return $this->hasMany(Helper::model('invoice_status_history'), 'invoice_id', 'id');
    }

    public function activities(): HasMany
    {
        return $this->hasMany(Helper::model('activity'), 'invoice_id', 'id');
    }

    public function importRules(): array
    {
        return [
            'subject'    => ['required', 'string'],
            'account_id' => ['required', 'uuid'],
            'order_id'   => ['required', 'uuid'],
            'contact_id' => ['nullable', 'uuid'],
            'due_date'   => ['nullable', 'date'],
            'amount'     => ['nullable', 'decimal:0,2'],
            'status_id'  => ['nullable', 'uuid'],
        ];
    }
}
