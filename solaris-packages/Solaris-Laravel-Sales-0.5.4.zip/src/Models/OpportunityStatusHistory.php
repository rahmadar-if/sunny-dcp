<?php

namespace Solaris\Sales\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\StageHistoryModel;

class OpportunityStatusHistory extends StageHistoryModel
{
    protected $table = 'opportunity_status_histories';

    public function status(): BelongsTo
    {
        return $this->belongsTo(Helper::model('opportunity_status'), 'status_id', 'id');
    }

    public function opportunity(): BelongsTo
    {
        return $this->belongsTo(Helper::model('opportunity'), 'opportunity_id', 'id');
    }

    protected static function parentModel(): string
    {
        return Helper::model('opportunity');
    }

    protected static function parentColumn(): string
    {
        return 'opportunity_id';
    }

    protected static function stageModel(): string
    {
        return Helper::model('opportunity_status');
    }

    protected static function stageColumn(): string
    {
        return 'status_id';
    }
}
