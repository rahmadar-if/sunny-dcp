<?php

namespace Solaris\Sales\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FolderAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\ImportAccess;
use Solaris\Core\Attributes\LookupAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;
use Solaris\Core\Traits\Model\HasStageHistory;
use Solaris\Sales\Const\OrderStatusConst;

#[FormAccess()]
#[LookupAccess(scopes: ["invoiceable"])]
#[DataTableAccess()]
#[FolderAccess()]
#[ExportAccess()]
#[ImportAccess()]
class Order extends BaseModel
{
    use HasStageHistory;

    protected $table                = 'orders';
    protected ?string $displayValue = 'number';
    protected array   $searchColumns = ['notes_plain' => 'FullText'];

    protected static function booted()
    {
        parent::booted();

        $syncNotes = function ($order) {
            if ($order->isDirty('notes') || ($order->notes && !$order->notes_plain)) {
                $order->notes_plain = $order->notes ? Helper::stripHtml($order->notes) : null;
            }
        };

        static::creating($syncNotes);
        static::updating($syncNotes);
    }

    protected static function stageHistoryModel(): string
    {
        return Helper::model('order_status_history');
    }

    protected static function stageColumn(): string
    {
        return 'status_id';
    }

    protected function casts(): array
    {
        return array_merge(parent::casts(),
        [
            'date'   => 'date:d M Y',
            'amount' => 'float'
        ]);
    }

    public function status(): BelongsTo
    {
        return $this->belongsTo(Helper::model('order_status'), 'status_id', 'id');
    }

    public function account(): BelongsTo
    {
        return $this->belongsTo(Helper::model('account'), 'account_id', 'id');
    }

    public function contact(): BelongsTo
    {
        return $this->belongsTo(Helper::model('contact'), 'contact_id', 'id');
    }

    public function opportunity(): BelongsTo
    {
        return $this->belongsTo(Helper::model('opportunity'), 'opportunity_id', 'id');
    }

    public function detail(): HasMany
    {
        return $this->hasMany(Helper::model('order_detail'), 'order_id', 'id');
    }

    public function status_history(): HasMany
    {
        return $this->hasMany(Helper::model('order_status_history'), 'order_id', 'id');
    }

    public function activities(): HasMany
    {
        return $this->hasMany(Helper::model('activity'), 'order_id', 'id');
    }

    public function scopeInvoiceable(Builder $query): Builder
    {
        return $query->whereIn('status_id', [OrderStatusConst::Confirmation, OrderStatusConst::Completed]);
    }

    public function importRules(): array
    {
        return [
            'opportunity_id' => ['required', 'uuid'],
            'date'           => ['nullable', 'date'],
            'account_id'     => ['nullable', 'uuid'],
            'contact_id'     => ['nullable', 'uuid'],
            'status_id'      => ['nullable', 'uuid'],
        ];
    }
}
