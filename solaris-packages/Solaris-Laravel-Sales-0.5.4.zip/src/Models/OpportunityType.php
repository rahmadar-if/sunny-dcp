<?php

namespace Solaris\Sales\Models;

use Solaris\Core\Models\LookupModel;

class OpportunityType extends LookupModel
{
    protected $table = 'opportunity_types';
}
