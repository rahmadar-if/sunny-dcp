<?php

namespace Solaris\Sales\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FolderAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\ImportAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\Attachment;
use Solaris\Core\Models\BaseModel;

#[FormAccess()]
#[DataTableAccess()]
#[FolderAccess()]
#[ExportAccess()]
#[ImportAccess()]
class OpportunityQuotationHistory extends BaseModel
{
    protected $table                = "opportunity_quotation_histories";
    protected ?string $displayValue = 'number_quotation';

    protected function casts(): array
    {
        return array_merge(parent::casts(), [
            "date"         => "date:d M Y",
            "total_amount" => "float"
        ]);
    }

    public function opportunity(): BelongsTo
    {
        return $this->belongsTo(Helper::model('opportunity'), "opportunity_id", "id");
    }

    public function attachment(): BelongsTo
    {
        return $this->belongsTo(Attachment::class, "attachment_id", "id");
    }

    public function importRules(): array
    {
        return [
            'opportunity_id'   => ['required', 'uuid'],
            'number_quotation' => ['required', 'string'],
            'total_amount'     => ['required', 'decimal:0,2'],
            'date'             => ['required', 'date'],
        ];
    }
}
