<?php

namespace Solaris\Sales\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\BaseCRM\Models\Activity as BaseActivity;
use Solaris\Core\Helpers\Helper;

class Activity extends BaseActivity
{
    public function opportunity() : BelongsTo
    {
        return $this->belongsTo(Helper::model('opportunity'), 'opportunity_id', 'id');
    }

    public function order() : BelongsTo
    {
        return $this->belongsTo(Helper::model('order'), 'order_id', 'id');
    }

    public function invoice() : BelongsTo
    {
        return $this->belongsTo(Helper::model('invoice'), 'invoice_id', 'id');
    }

    public function importRules(): array
    {
        return array_merge(parent::importRules(), [
            'opportunity_id' => ['nullable', 'uuid'],
            'order_id'       => ['nullable', 'uuid'],
            'invoice_id'     => ['nullable', 'uuid'],
        ]);
    }
}