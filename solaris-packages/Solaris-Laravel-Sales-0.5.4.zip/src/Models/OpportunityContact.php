<?php

namespace Solaris\Sales\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FolderAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\ImportAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

#[FormAccess()]
#[DataTableAccess()]
#[FolderAccess()]
#[ExportAccess()]
#[ImportAccess()]
class OpportunityContact extends BaseModel
{
    protected $table                = "opportunity_contacts";
    protected array $prepareColumns = ["opportunity_id", "contact_id", "role", "is_decision_maker"];

    public function casts(): array 
    {
        return array_merge(parent::casts(), [
            "is_decision_maker" => "boolean"
        ]);
    }

    public function contact() 
    {
        return $this->belongsTo(Helper::model('contact'), "contact_id", "id");
    }

    public function opportunity(): BelongsTo
    {
        return $this->belongsTo(Helper::model('opportunity'), "opportunity_id", "id");
    }

    public function importRules(): array
    {
        return [
            'opportunity_id'    => ['required', 'uuid'],
            'contact_id'        => ['required', 'uuid'],
            'role'              => ['nullable', 'string', 'max:255'],
            'is_decision_maker' => ['nullable', 'boolean'],
        ];
    }
}
