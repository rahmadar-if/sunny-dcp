<?php

namespace Solaris\Sales\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Solaris\Core\Attributes\DataTableAccess;
use Solaris\Core\Attributes\ExportAccess;
use Solaris\Core\Attributes\FolderAccess;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Attributes\ImportAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Models\BaseModel;

#[FormAccess()]
#[DataTableAccess()]
#[FolderAccess()]
#[ExportAccess()]
#[ImportAccess()]
class OpportunityCompetitor extends BaseModel
{
    protected $table = "opportunity_competitors";

    public function casts(): array
    {
        return array_merge(parent::casts(), [
            'total_amount' => 'float',
        ]);
    }

    public function opportunity(): BelongsTo
    {
        return $this->belongsTo(Helper::model('opportunity'), "opportunity_id", "id");
    }

    public function importRules(): array
    {
        return [
            'opportunity_id' => ['required', 'uuid'],
            'name'           => ['required', 'string'],
            'total_amount'   => ['nullable', 'decimal:0,2'],
            'strength'       => ['nullable', 'string'],
            'weakness'       => ['nullable', 'string'],
            'rating'         => ['nullable', 'integer'],
        ];
    }
}
