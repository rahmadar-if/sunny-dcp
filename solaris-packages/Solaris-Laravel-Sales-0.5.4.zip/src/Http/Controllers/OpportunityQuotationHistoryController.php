<?php

namespace Solaris\Sales\Http\Controllers;

use Illuminate\Http\JsonResponse;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\Sales\Http\Requests\OpportunityQuotationHistoryRequest;

#[FormAccess()]
class OpportunityQuotationHistoryController
{
    /** @var BaseRepository */
    protected $repo;

    public function __construct()
    {
        $this->repo = new (Helper::repository('opportunity_quotation_history'))(new (Helper::model('opportunity_quotation_history')));
    }

    public function store(): JsonResponse
    {
        /** @var OpportunityQuotationHistoryRequest $request */
        $request = app(Helper::formRequest("opportunity_quotation_history"));
        $data    = $this->repo->create($request->cleanData());

        return SolarResponse::success($data);
    }

    public function show(string $id): JsonResponse
    {
        return response()->json($this->repo->findComplete($id, $this->extendColumns()));
    }

    public function update(string $id): JsonResponse
    {
        /** @var OpportunityQuotationHistoryRequest $request */
        $request = app(Helper::formRequest("opportunity_quotation_history"));
        $data    = $this->repo->update($id, $request->cleanData());

        return SolarResponse::success($data);
    }

    public function destroy(string $id): JsonResponse
    {
        return SolarResponse::deleted($this->repo->delete($id));
    }

    public function extendColumns(): array
    {
        return [];
    }
}
