<?php

namespace Solaris\Sales\Http\Controllers;

use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Sales\Http\Requests\InvoiceRequest;
use Solaris\Sales\Repositories\InvoiceRepository;

#[FormAccess()]
class InvoiceController
{
    /** @var InvoiceRepository */
    protected $repo;

    public function __construct()
    {
        $this->repo = new (Helper::repository('invoice'))(new (Helper::model('invoice')));
    }

    public function index(): View
    {
        $breadcrumbs = [
            ['label' => 'Sales'],
            ['label' => 'Invoice']
        ];

        return view(Helper::view("invoice.list"), [
            'breadcrumbs' => $breadcrumbs
        ]);
    }

    public function store(): JsonResponse
    {
        /** @var InvoiceRequest $request */
        $request = app(Helper::formRequest("invoice"));
        $data    = $this->repo->create($request->cleanData());

        return SolarResponse::success($data);
    }

    public function show(Request $request, string $id): RedirectResponse|JsonResponse
    {
        if(!$request->expectsJson()) {
            return redirect(route('sales.invoice.edit', ['id' => $id]));
        }

        return response()->json($this->repo->findComplete($id, $this->extendColumns()));
    }

    public function edit(string $id): View
    {
        $data = $this->repo->findComplete($id, $this->extendColumns());
        $breadcrumbs = [
            ['label' => 'Sales'],
            ['label' => 'Invoice'],
            ['label' => $data->number]
        ];

        return view(Helper::view("invoice.page"), [
            'data'        => $data,
            'breadcrumbs' => $breadcrumbs
        ]);
    }

    public function update(string $id): JsonResponse
    {
        /** @var InvoiceRequest $request */
        $request = app(Helper::formRequest("invoice"));
        $data    = $this->repo->update($id, $request->cleanData());

        return SolarResponse::success($data);
    }

    public function destroy(string $id): JsonResponse
    {
        return SolarResponse::deleted($this->repo->delete($id));
    }

    public function extendColumns(): array
    {
        return [];
    }
}
