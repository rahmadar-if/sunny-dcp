<?php

namespace Solaris\Sales\Http\Controllers;

use Illuminate\Http\JsonResponse;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Sales\Http\Requests\OpportunityProductRequest;
use Solaris\Sales\Repositories\OpportunityProductRepository;

#[FormAccess()]
class OpportunityProductController
{
    /** @var OpportunityProductRepository */
    protected $repo;

    public function __construct()
    {
        $this->repo = new (Helper::repository('opportunity_product'))(new (Helper::model('opportunity_product')));
    }

    public function store(): JsonResponse
    {
        /** @var OpportunityProductRequest $request */
        $request = app(Helper::formRequest("opportunity_product"));
        $data    = $this->repo->create($request->cleanData());

        return SolarResponse::success($data);
    }

    public function show(string $id): JsonResponse
    {
        return response()->json($this->repo->findComplete($id, $this->extendColumns()));
    }

    public function update(string $id): JsonResponse
    {
        /** @var OpportunityProductRequest $request */
        $request = app(Helper::formRequest("opportunity_product"));
        $data    = $this->repo->update($id, $request->cleanData());

        return SolarResponse::success($data);
    }

    public function destroy(string $id): JsonResponse
    {
        return SolarResponse::deleted($this->repo->delete($id));
    }

    public function extendColumns(): array
    {
        return [
            "product[price,availability,category,brand,product_picture_id,unit_of_measure]"
        ];
    }
}
