<?php

namespace Solaris\Sales\Http\Controllers;

use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Illuminate\Support\Facades\DB;
use Solaris\Core\Models\LookupModel;
use Solaris\Sales\Const\OpportunityStatusConst;
use Solaris\Sales\Http\Requests\OpportunityRequest;
use Solaris\Sales\Repositories\OpportunityRepository;

#[FormAccess()]
class OpportunityController
{
    /** @var OpportunityRepository */
    protected $repo;

    public function __construct()
    {
        $this->repo = new (Helper::repository('opportunity'))(new (Helper::model('opportunity')));
    }

    public function index(): View
    {
        $breadcrumbs = [
            ['label' => 'Sales'],
            ['label' => 'Opportunity']
        ];

        return view(Helper::view("opportunity.list"), [
            'breadcrumbs' => $breadcrumbs
        ]);
    }

    public function store(): JsonResponse
    {
        /** @var OpportunityRequest $request */
        $request = app(Helper::formRequest("opportunity"));
        $data    = $this->repo->create($request->cleanData());

        $data["customer"]       = $this->fillLookup("account", $data["customer_id"]);
        $data["decision_maker"] = $this->fillLookup("contact", $data["decision_maker_id"]);
        $data["source"]         = $this->fillLookup("lead_source", $data["source_id"]);
        $data["status"]         = $this->fillLookup("opportunity_status", $data["status_id"]);
        $data["created_by"]     = $this->fillLookup("user", $data["created_by_id"]);

        return SolarResponse::success($data);
    }

    public function show(Request $request, string $id): RedirectResponse|JsonResponse
    {
        if(!$request->expectsJson()) {
            return redirect(route('sales.opportunity.edit', ['id' => $id]));
        }

        return response()->json($this->repo->findComplete($id, $this->extendColumns()));
    }

    public function edit(string $id): View
    {
        $data = $this->repo->findComplete($id, $this->extendColumns());
        $breadcrumbs = [
            ['label' => 'Sales'],
            ['label' => 'Opportunity'],
            ['label' => $data->name]
        ];

        return view(Helper::view("opportunity.page"), [
            'data'        => $data,
            'breadcrumbs' => $breadcrumbs
        ]);
    }

    public function update(string $id): JsonResponse
    {
        /** @var OpportunityRequest $request */
        $request = app(Helper::formRequest("opportunity"));
        $data    = $this->repo->update($id, $request->cleanData());

        return SolarResponse::success($data);
    }

    public function updateStatus(Request $request): JsonResponse
    {
        Helper::model('opportunity')::where('id', $request->input('id'))->update([
            'status_date'   => $request->input('status_date'),
            'latest_status' => $request->input('latest_status'),
        ]);

        return SolarResponse::success();
    }

    public function listSummary(Request $request): JsonResponse
    {
        $search     = $request->input('search');
        $preFilters = $request->input('pre_filters', []);
        $filters    = $request->input('filters', []);

        $closedWon  = OpportunityStatusConst::ClosedWon;
        $closedLost = OpportunityStatusConst::ClosedLost;

        $summary = Helper::model('opportunity')::query()
            ->selectRaw("COUNT(*) AS total_opportunity")
            ->selectRaw("COALESCE(SUM(CASE WHEN status_id <> ? THEN total_amount ELSE 0 END), 0) AS total_amount", [$closedLost])
            ->selectRaw("COUNT(CASE WHEN status_id = ? THEN 1 END) AS total_closed_won", [$closedWon])
            ->selectRaw("COALESCE(SUM(CASE WHEN status_id = ? THEN total_amount ELSE 0 END), 0) AS total_closed_won_amount", [$closedWon])
            ->selectRaw("COUNT(CASE WHEN status_id NOT IN (?, ?) THEN 1 END) AS total_progress", [$closedWon, $closedLost])
            ->when(!empty($search), fn ($query) => $query->search($search))
            ->when(!empty($preFilters), fn ($query) => $query->filter($preFilters))
            ->when(!empty($filters), fn ($query) => $query->filter($filters))
            ->first();

        return response()->json([
            'total_opportunity'       => (int)$summary->total_opportunity,
            'total_amount'            => (float)$summary->total_amount,
            'total_closed_won'        => (int)$summary->total_closed_won,
            'total_closed_won_amount' => (float)$summary->total_closed_won_amount,
            'total_progress'          => (int)$summary->total_progress,
        ]);
    }

    public function kanbanSummary(Request $request): JsonResponse
    {
        $columns    = $request->input('columns', []);
        $search     = $request->input('search');
        $preFilters = $request->input('pre_filters', []);
        $filters    = $request->input('filters', []);

        $summary = Helper::model('opportunity')::query()
            ->select('status_id', DB::raw('SUM(total_amount) AS total_amount'))
            ->when(!empty($search), fn ($query) => $query->search($search, is_string($columns) ? [$columns] : $columns))
            ->when(!empty($preFilters), fn ($query) => $query->filter($preFilters))
            ->when(!empty($filters), fn ($query) => $query->filter($filters))
            ->groupBy('status_id')
            ->get()
            ->mapWithKeys(fn ($row) => [$row->status_id => ['total_amount' => (float)$row->total_amount]])
            ->all();

        return response()->json($summary);
    }

    public function destroy(string $id): JsonResponse
    {
        return SolarResponse::deleted($this->repo->delete($id));
    }

    public function printQuotation(string $id): Response
    {
        return $this->repo->printQuotation($id);
    }

    public function createOrder(string $id): JsonResponse
    {
        $opportunity = $this->repo->find($id);

        if ($opportunity->status_id !== OpportunityStatusConst::ClosedWon) {
            return SolarResponse::error('Opportunity must be Closed Won before creating an order.', 422);
        }

        $orderRepo = new (Helper::repository('order'))(new (Helper::model('order')));

        return SolarResponse::success($orderRepo->create(['opportunity_id' => $id]));
    }

    protected function fillLookup(string $lookup, ?string $lookupId): mixed
    {
        if(is_null($lookupId)) {
            return null;
        }

        $model = Helper::model($lookup);
        if(is_a($model, LookupModel::class, true)) {
            return $model::toLookup(false)->where("id", $lookupId)->first();
        }

        return $model::prepared()
            ->where("id", $lookupId)
            ->first();
    }

    public function extendColumns(): array
    {
        return [];
    }
}
