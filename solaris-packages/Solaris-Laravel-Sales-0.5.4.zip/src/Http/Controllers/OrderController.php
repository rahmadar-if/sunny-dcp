<?php

namespace Solaris\Sales\Http\Controllers;

use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Sales\Http\Requests\OrderRequest;
use Solaris\Sales\Repositories\OrderRepository;

#[FormAccess()]
class OrderController
{
    /** @var OrderRepository */
    protected $repo;

    public function __construct()
    {
        $this->repo = new (Helper::repository('order'))(new (Helper::model('order')));
    }

    public function index(): View
    {
        $breadcrumbs = [
            ['label' => 'Sales'],
            ['label' => 'Order']
        ];

        return view(Helper::view("order.list"), [
            'breadcrumbs' => $breadcrumbs
        ]);
    }

    public function store(): JsonResponse
    {
        /** @var OrderRequest $request */
        $request = app(Helper::formRequest("order"));
        $data    = $this->repo->create($request->cleanData());

        return SolarResponse::success($data);
    }

    public function show(Request $request, string $id): RedirectResponse|JsonResponse
    {
        if(!$request->expectsJson()) {
            return redirect(route('sales.order.edit', ['id' => $id]));
        }

        return response()->json($this->repo->findComplete($id, $this->extendColumns()));
    }

    public function edit(string $id): View
    {
        $data = $this->repo->findComplete($id, $this->extendColumns());
        $breadcrumbs = [
            ['label' => 'Sales'],
            ['label' => 'Order'],
            ['label' => $data->number]
        ];

        return view(Helper::view("order.page"), [
            'data'        => $data,
            'breadcrumbs' => $breadcrumbs
        ]);
    }

    public function update(string $id): JsonResponse
    {
        /** @var OrderRequest $request */
        $request = app(Helper::formRequest("order"));
        $data    = $this->repo->update($id, $request->cleanData());

        return SolarResponse::success($data);
    }

    public function destroy(string $id): JsonResponse
    {
        return SolarResponse::deleted($this->repo->delete($id));
    }

    public function extendColumns(): array
    {
        return [];
    }
}
