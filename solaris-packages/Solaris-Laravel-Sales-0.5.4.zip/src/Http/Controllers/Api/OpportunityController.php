<?php

namespace Solaris\Sales\Http\Controllers\Api;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Solaris\Core\Docs\Api\ApiEntity;
use Solaris\Core\Docs\Api\ApiField;
use Solaris\Core\Docs\Api\ApiOperation;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarApiResponse;
use Solaris\Core\Http\Controllers\Api\BaseApiController;
use Solaris\Sales\Http\Requests\OpportunityRequest;

/**
 * Sales-only entity — no MasterData or BaseCRM layer to extend, so everything is declared here.
 */
class OpportunityController extends BaseApiController
{
    public function key(): string
    {
        return 'opportunity';
    }

    // position (kanban card order, purely a UI concern) and notes_plain (internal search column)
    // are left out.
    public function columns(): array
    {
        return [
            'id',
            'name',
            'date',
            'type',
            'source',
            'status',
            'lead',
            'customer',
            'decision_maker',
            'phone',
            'email',
            'customer_need',
            'budget',
            'amount',
            'discount_amount',
            'discount_percent',
            'total_amount',
            'probability_percent',
            'quotation_number',
            'latest_status',
            'status_date',
            'closed_on',
            'is_new_customer',
            'description',
            'our_strengths',
            'our_weaknesses',
            'sales_tactics',
            'days_in_funnel',
            'notes',
            'created_at',
            'updated_at',
            'created_by',
            'updated_by',
        ];
    }

    public function relations(): array
    {
        return ['type', 'source', 'status', 'lead', 'customer', 'decision_maker'];
    }

    /**
     * Status has its own endpoint, so it must not ride along in an ordinary field update — a stage
     * change buried in a bulk edit is the kind of thing nobody notices until it matters.
     *
     * The web moves this through the kanban board instead, which is unaffected.
     */
    public function guarded(): array
    {
        return ['status_id', 'status'];
    }

    public function searchColumns(): array
    {
        return ['name', 'quotation_number', 'phone', 'email'];
    }

    public function actionRules(): array
    {
        return ['updateStatus' => OpportunityRequest::stageRules()];
    }

    public function entityDocs(): ApiEntity
    {
        return ApiEntity::make('Opportunity')
            ->description('A deal in progress, from qualification through to won or lost.');
    }

    public function fieldDocs(): array
    {
        return [
            'id'                  => ApiField::uuid('Unique identifier.')->readOnly(),
            'name'                => ApiField::string('What the deal is called.')->example('Pengadaan panel surya - PT Sinar Jaya'),
            'date'                => ApiField::date('Date the opportunity was opened.')->example('2026-08-17'),
            'type'                => ApiField::lookup('New business, renewal, and so on.'),
            'source'              => ApiField::lookup('Where the deal originated.'),
            'status'              => ApiField::stage('Current stage. Changed through its own endpoint, not through update.')->readOnly(),
            'lead'                => ApiField::lookup('Lead this opportunity was promoted from, if any.'),
            'customer'            => ApiField::lookup('Account the deal is with.'),
            'decision_maker'      => ApiField::lookup('Contact who decides. Setting this also adds them to the opportunity contacts.'),
            'phone'               => ApiField::string('Contact number. Required unless an email is given.')->example('+628123456789'),
            'email'               => ApiField::email('Contact email. Required unless a phone is given.')->example('budi@sinarjaya.co.id'),
            'customer_need'       => ApiField::text('What the buyer is asking for. At least 10 characters.'),
            'budget'              => ApiField::decimal('Budget the buyer indicated.')->example(500000000),

            // Everything below to days_in_funnel is derived — none of it appears in the rule set.
            'amount'              => ApiField::decimal('Sum of the opportunity products before discount.')->example(520000000)->readOnly(),
            'discount_amount'     => ApiField::decimal('Total discount across the products.')->example(20000000)->readOnly(),
            'discount_percent'    => ApiField::decimal('Discount as a percentage of the amount.')->example(3.85)->readOnly(),
            'total_amount'        => ApiField::decimal('Amount after discount. This is the deal value.')->example(500000000)->readOnly(),
            'probability_percent' => ApiField::decimal('Chance of winning, taken from the current stage.')->example(60)->readOnly(),

            'quotation_number'    => ApiField::string('Reference of the quotation sent.')->example('QT-2026-0817-001'),
            'latest_status'       => ApiField::string('Short free text note on where things stand.'),
            'status_date'         => ApiField::date('Date that note was written.')->example('2026-08-17'),
            // Writable, but the repository overwrites it the moment the stage becomes Closed Won.
            'closed_on'           => ApiField::date('Date the deal closed. Set automatically when the stage moves to closed won.')->example('2026-09-30'),
            'is_new_customer'     => ApiField::boolean('True when the account or contact was created out of the originating lead.'),
            'description'         => ApiField::text('Longer description of the deal.'),
            'our_strengths'       => ApiField::text('Where we are strong in this deal.'),
            'our_weaknesses'      => ApiField::text('Where we are exposed.'),
            'sales_tactics'       => ApiField::text('How the deal is being approached.'),
            'days_in_funnel'      => ApiField::integer('How long the deal has been open, in days.')->example(23)->readOnly(),
            'notes'               => ApiField::text('Rich text notes. HTML is accepted.'),
            'created_at'          => ApiField::dateTime('When the record was created.')->readOnly(),
            'updated_at'          => ApiField::dateTime('When the record was last changed.')->readOnly(),
            'created_by'          => ApiField::user('Who created the record.')->readOnly(),
            'updated_by'          => ApiField::user('Who last changed the record.')->readOnly(),
        ];
    }

    public function endpointDocs(): array
    {
        return [
            'index'  => ApiOperation::make('List opportunities'),
            'search' => ApiOperation::make('Search opportunities')
                ->description('Same as the list endpoint, but accepts the full Filter DSL in the body instead of a query string.'),
            'show'   => ApiOperation::make('Get one opportunity'),
            'store'  => ApiOperation::make('Create an opportunity')
                ->description("Either a phone or an email must be given. A new opportunity starts at the qualification stage.\n\nThe deal value is not set here — it follows from the products attached to the opportunity.\n\nSend an `Idempotency-Key` header so a retried request cannot create a duplicate."),
            'update' => ApiOperation::make('Update an opportunity')
                ->description("Partial update — only the fields you send are changed. Fields you omit are left untouched.\n\nThe stage is handled by its own endpoint and is rejected here."),
            'replace' => ApiOperation::make('Update an opportunity (full)')
                ->description("Same effect as the partial update, but every required field must be present.\n\nFields you omit are still left untouched; this endpoint does not blank them."),
            'destroy' => ApiOperation::make('Delete an opportunity'),

            'updateStatus' => ApiOperation::make('Change opportunity stage')
                ->description("Every change here is recorded in the opportunity's stage history, and `probability_percent` is refreshed from the new stage.\n\nMoving to closed won also stamps `closed_on` with today's date."),
        ];
    }

    public function updateStatus(Request $request, string $id): JsonResponse
    {
        $formRequest = app(Helper::formRequest($this->key()));

        $this->repo->update($id, $formRequest->cleanData());

        return SolarApiResponse::item(new ($this->resource())(
            $this->repo->findComplete($id, $this->columns())
        ));
    }
}
