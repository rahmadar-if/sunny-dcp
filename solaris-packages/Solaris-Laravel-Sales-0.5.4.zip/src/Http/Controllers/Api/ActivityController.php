<?php

namespace Solaris\Sales\Http\Controllers\Api;

use Solaris\BaseCRM\Http\Controllers\Api\ActivityController as BaseActivityController;
use Solaris\Core\Docs\Api\ApiField;

class ActivityController extends BaseActivityController
{
    // Plain columns, not a computed block: ActivityRepository is not overridden here, so there is
    // nothing to put behind ?include= the way Account and Contact do.
    public function columns(): array
    {
        return array_merge(parent::columns(), [
            'opportunity',
            'order',
            'invoice',
        ]);
    }

    public function relations(): array
    {
        return array_merge(parent::relations(), ['opportunity', 'order', 'invoice']);
    }

    public function fieldDocs(): array
    {
        return array_merge(parent::fieldDocs(), [
            'opportunity' => ApiField::lookup('Opportunity the activity relates to.'),
            'order'       => ApiField::lookup('Order the activity relates to.'),
            'invoice'     => ApiField::lookup('Invoice the activity relates to.'),
        ]);
    }
}
