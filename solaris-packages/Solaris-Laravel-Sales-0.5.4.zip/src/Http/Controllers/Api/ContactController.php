<?php

namespace Solaris\Sales\Http\Controllers\Api;

use Solaris\BaseCRM\Http\Controllers\Api\ContactController as BaseContactController;
use Solaris\Core\Docs\Api\ApiField;

class ContactController extends BaseContactController
{
    /**
     * Note this block is not the same as the one on Account: ContactRepository::findComplete()
     * computes three sums and two subqueries, but no counts — so total_opportunity and its
     * siblings do not exist here. Sits behind ?include=stats for the same reason.
     */
    public function fieldDocs(): array
    {
        return array_merge(parent::fieldDocs(), [
            'stats' => ApiField::object('Sales figures aggregated across orders and invoices.', [
                'sales_total_revenue'       => ApiField::decimal('Sum of completed invoices.')->example(120000000),
                'sales_total_sales'         => ApiField::decimal('Sum of confirmed and completed orders.')->example(145000000),
                'sales_outstanding_invoice' => ApiField::decimal('Sum of issued invoices not yet paid.')->example(25000000),
                'latest_lead'               => ApiField::object('Most recent lead still in play.'),
                'latest_opportunity'        => ApiField::object('Most recent opportunity still open.'),
            ]),
        ]);
    }
}
