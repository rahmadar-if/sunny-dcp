<?php

namespace Solaris\Sales\Http\Controllers\Api;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Solaris\Core\Docs\Api\ApiEntity;
use Solaris\Core\Docs\Api\ApiField;
use Solaris\Core\Docs\Api\ApiOperation;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarApiResponse;
use Solaris\Core\Http\Controllers\Api\BaseApiController;
use Solaris\Sales\Http\Requests\OrderRequest;

class OrderController extends BaseApiController
{
    public function key(): string
    {
        return 'order';
    }

    public function columns(): array
    {
        return [
            'id',
            'number',
            'date',
            'opportunity',
            'account',
            'contact',
            'status',
            'amount',
            'notes',
            'created_at',
            'updated_at',
            'created_by',
            'updated_by',
        ];
    }

    public function relations(): array
    {
        return ['opportunity', 'account', 'contact', 'status'];
    }

    /**
     * Status has its own endpoint, so it must not ride along in an ordinary field update — a stage
     * change buried in a bulk edit is the kind of thing nobody notices until it matters.
     */
    public function guarded(): array
    {
        return ['status_id', 'status'];
    }

    public function searchColumns(): array
    {
        return ['number'];
    }

    public function actionRules(): array
    {
        return ['updateStatus' => OrderRequest::stageRules()];
    }

    public function entityDocs(): ApiEntity
    {
        return ApiEntity::make('Order')
            ->description('A confirmed sale, raised from a won opportunity.');
    }

    public function fieldDocs(): array
    {
        return [
            'id'          => ApiField::uuid('Unique identifier.')->readOnly(),
            'number'      => ApiField::string('Order number, generated on creation.')->example('SO-2026-08-0001')->readOnly(),
            'date'        => ApiField::date('Order date. Set to today on creation; editable afterwards.')->example('2026-08-17'),
            'opportunity' => ApiField::lookup('Opportunity this order was raised from.'),
            'account'     => ApiField::lookup('Customer. Taken from the opportunity on creation; editable afterwards.'),
            'contact'     => ApiField::lookup('Person to deal with. Taken from the opportunity on creation; editable afterwards.'),
            'status'      => ApiField::stage('Current stage. Changed through its own endpoint, not through update.')->readOnly(),
            // Follows the order lines, which are copied from the opportunity products.
            'amount'      => ApiField::decimal('Order value, taken from the order lines.')->example(500000000)->readOnly(),
            'notes'       => ApiField::text('Rich text notes. HTML is accepted.'),
            'created_at'  => ApiField::dateTime('When the record was created.')->readOnly(),
            'updated_at'  => ApiField::dateTime('When the record was last changed.')->readOnly(),
            'created_by'  => ApiField::user('Who created the record.')->readOnly(),
            'updated_by'  => ApiField::user('Who last changed the record.')->readOnly(),
        ];
    }

    public function endpointDocs(): array
    {
        return [
            'index'  => ApiOperation::make('List orders'),
            'search' => ApiOperation::make('Search orders')
                ->description('Same as the list endpoint, but accepts the full Filter DSL in the body instead of a query string.'),
            'show'   => ApiOperation::make('Get one order'),
            'store'  => ApiOperation::make('Create an order from an opportunity')
                ->description("An order is raised from an opportunity, so the only thing to send is which one.\n\nEverything else follows from it: the number is generated, the date is today, the stage starts at draft, the customer and contact are taken from the opportunity, and its products are copied across as order lines. Those fields are editable afterwards, but sending them here has no effect.\n\nSend an `Idempotency-Key` header so a retried request cannot create a duplicate."),
            'update' => ApiOperation::make('Update an order')
                ->description("Partial update — only the fields you send are changed. Fields you omit are left untouched.\n\nThe stage is handled by its own endpoint and is rejected here."),
            'replace' => ApiOperation::make('Update an order (full)')
                ->description("Same effect as the partial update, but every required field must be present.\n\nFields you omit are still left untouched; this endpoint does not blank them."),
            'destroy' => ApiOperation::make('Delete an order'),

            'updateStatus' => ApiOperation::make('Change order stage')
                ->description("Every change here is recorded in the order's stage history."),
        ];
    }

    public function updateStatus(Request $request, string $id): JsonResponse
    {
        $formRequest = app(Helper::formRequest($this->key()));

        $this->repo->update($id, $formRequest->cleanData());

        return SolarApiResponse::item(new ($this->resource())(
            $this->repo->findComplete($id, $this->columns())
        ));
    }
}
