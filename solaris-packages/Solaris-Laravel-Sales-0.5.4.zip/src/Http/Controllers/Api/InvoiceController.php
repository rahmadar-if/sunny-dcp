<?php

namespace Solaris\Sales\Http\Controllers\Api;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Solaris\Core\Docs\Api\ApiEntity;
use Solaris\Core\Docs\Api\ApiField;
use Solaris\Core\Docs\Api\ApiOperation;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarApiResponse;
use Solaris\Core\Http\Controllers\Api\BaseApiController;
use Solaris\Sales\Http\Requests\InvoiceRequest;

class InvoiceController extends BaseApiController
{
    public function key(): string
    {
        return 'invoice';
    }

    /**
     * payment_amount is deliberately absent. The column exists — it was even dropped and re-added
     * in migration 000006 — but nothing reads or writes it: not the rule sets, not the repository,
     * not mobile. Publishing it would promise a payment figure that nothing ever fills in.
     */
    public function columns(): array
    {
        return [
            'id',
            'number',
            'subject',
            'order',
            'account',
            'contact',
            'issued_date',
            'due_date',
            'completed_at',
            'status',
            'amount',
            'notes',
            'created_at',
            'updated_at',
            'created_by',
            'updated_by',
        ];
    }

    public function relations(): array
    {
        return ['order', 'account', 'contact', 'status'];
    }

    /**
     * Status has its own endpoint, so it must not ride along in an ordinary field update — a stage
     * change buried in a bulk edit is the kind of thing nobody notices until it matters.
     */
    public function guarded(): array
    {
        return ['status_id', 'status'];
    }

    public function searchColumns(): array
    {
        return ['number', 'subject'];
    }

    public function actionRules(): array
    {
        return ['updateStatus' => InvoiceRequest::stageRules()];
    }

    public function entityDocs(): ApiEntity
    {
        return ApiEntity::make('Invoice')
            ->description('A bill raised against an order.');
    }

    public function fieldDocs(): array
    {
        return [
            'id'           => ApiField::uuid('Unique identifier.')->readOnly(),
            'number'       => ApiField::string('Invoice number, generated on creation.')->example('INV-2026-08-0001')->readOnly(),
            // Present in createRules() but not in updateRules(), so it cannot be corrected later.
            'subject'      => ApiField::string('What the invoice is for. Can only be set when the invoice is created.')->example('Pengadaan panel surya tahap 1'),
            'order'        => ApiField::lookup('Order being billed.'),
            'account'      => ApiField::lookup('Customer. Taken from the order on creation; editable afterwards.'),
            'contact'      => ApiField::lookup('Person to bill. Taken from the order on creation; editable afterwards.'),
            'issued_date'  => ApiField::date('Date the invoice was issued. Stamped when the stage moves to issued.')->example('2026-08-17')->readOnly(),
            'due_date'     => ApiField::date('Date payment is due.')->example('2026-09-16'),
            'completed_at' => ApiField::date('Date the invoice was settled. Stamped when the stage moves to completed.')->example('2026-09-10')->readOnly(),
            'status'       => ApiField::stage('Current stage. Changed through its own endpoint, not through update.')->readOnly(),
            'amount'       => ApiField::decimal('Amount billed. Taken from the order on creation; correctable afterwards.')->example(500000000),
            'notes'        => ApiField::text('Rich text notes. HTML is accepted.'),
            'created_at'   => ApiField::dateTime('When the record was created.')->readOnly(),
            'updated_at'   => ApiField::dateTime('When the record was last changed.')->readOnly(),
            'created_by'   => ApiField::user('Who created the record.')->readOnly(),
            'updated_by'   => ApiField::user('Who last changed the record.')->readOnly(),
        ];
    }

    public function endpointDocs(): array
    {
        return [
            'index'  => ApiOperation::make('List invoices'),
            'search' => ApiOperation::make('Search invoices')
                ->description('Same as the list endpoint, but accepts the full Filter DSL in the body instead of a query string.'),
            'show'   => ApiOperation::make('Get one invoice'),
            'store'  => ApiOperation::make('Create an invoice from an order')
                ->description("An invoice is raised against an order, so all that is needed is which one and what it is for.\n\nEverything else follows: the number is generated, the stage starts at draft, the customer, contact and amount are taken from the order, and its lines are copied across. Those fields are editable afterwards, but sending them here has no effect.\n\nSend an `Idempotency-Key` header so a retried request cannot create a duplicate."),
            'update' => ApiOperation::make('Update an invoice')
                ->description("Partial update — only the fields you send are changed. Fields you omit are left untouched.\n\nThe stage has its own endpoint and is rejected here. The subject can only be set at creation and is not accepted."),
            'replace' => ApiOperation::make('Update an invoice (full)')
                ->description("Same effect as the partial update, but every required field must be present.\n\nFields you omit are still left untouched; this endpoint does not blank them."),
            'destroy' => ApiOperation::make('Delete an invoice'),

            'updateStatus' => ApiOperation::make('Change invoice stage')
                ->description("Every change here is recorded in the invoice's stage history.\n\nMoving to issued stamps `issued_date`, and moving to completed stamps `completed_at`, both with today's date."),
        ];
    }

    public function updateStatus(Request $request, string $id): JsonResponse
    {
        $formRequest = app(Helper::formRequest($this->key()));

        $this->repo->update($id, $formRequest->cleanData());

        return SolarApiResponse::item(new ($this->resource())(
            $this->repo->findComplete($id, $this->columns())
        ));
    }
}
