<?php

namespace Solaris\Sales\Http\Controllers\Api;

use Illuminate\Http\JsonResponse;
use Solaris\BaseCRM\Http\Controllers\Api\LeadController as BaseLeadController;
use Solaris\Core\Docs\Api\ApiField;
use Solaris\Core\Docs\Api\ApiOperation;
use Solaris\Core\Helpers\SolarApiResponse;

class LeadController extends BaseLeadController
{
    // opportunity is a hasOne, so it is readable but never something a partner sends — it stays
    // out of relations(), which is the list the lookup resolver works from.
    public function columns(): array
    {
        return array_merge(parent::columns(), ['opportunity']);
    }

    public function fieldDocs(): array
    {
        return array_merge(parent::fieldDocs(), [
            'opportunity' => ApiField::lookup('Opportunity this lead turned into, once it has been promoted.')->readOnly(),
        ]);
    }

    public function endpointDocs(): array
    {
        return array_merge(parent::endpointDocs(), [
            'prospect' => ApiOperation::make('Promote the lead to an opportunity')
                ->description("Moves the lead to qualified and opens an opportunity carrying its account, contact, need and source.\n\nRefused with **409** when the lead already has an opportunity, or when it has neither an account nor a contact — link or create one of those first."),
        ]);
    }

    /**
     * hotLead() raises a plain exception for the two states it refuses. Both are ordinary answers
     * to a legitimate request, so they are reported as a conflict rather than a server fault.
     */
    public function prospect(string $id): JsonResponse
    {
        try {
            $opportunity = $this->repo->hotLead($id);
        } catch (\Exception $e) {
            return SolarApiResponse::error(SolarApiResponse::CONFLICT, $e->getMessage(), 409);
        }

        return SolarApiResponse::created(['id' => $opportunity->id, 'name' => $opportunity->name]);
    }
}
