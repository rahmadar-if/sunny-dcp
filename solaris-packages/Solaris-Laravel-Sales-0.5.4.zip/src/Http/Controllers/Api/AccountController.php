<?php

namespace Solaris\Sales\Http\Controllers\Api;

use Solaris\BaseCRM\Http\Controllers\Api\AccountController as BaseAccountController;
use Solaris\Core\Docs\Api\ApiField;

class AccountController extends BaseAccountController
{
    // Sales adds no contract fields of its own — its extra figures are computed, and sit behind
    // ?include=stats so a list request never pays for them. The block itself is declared in
    // AccountResource; only its description lives here.
    public function fieldDocs(): array
    {
        return array_merge(parent::fieldDocs(), [
            'stats' => ApiField::object('Sales figures aggregated across opportunities, orders and invoices.', [
                'total_opportunity'         => ApiField::integer('Number of opportunities.')->example(12),
                'total_order'               => ApiField::integer('Number of orders.')->example(8),
                'total_invoice'             => ApiField::integer('Number of invoices.')->example(19),
                'sales_total_revenue'       => ApiField::decimal('Sum of completed invoices.')->example(450000000),
                'sales_total_sales'         => ApiField::decimal('Sum of confirmed and completed orders.')->example(520000000),
                'sales_outstanding_invoice' => ApiField::decimal('Sum of issued invoices not yet paid.')->example(70000000),
                'latest_lead'               => ApiField::object('Most recent lead still in play.'),
                'latest_opportunity'        => ApiField::object('Most recent opportunity still open.'),
            ]),
        ]);
    }
}
