<?php

namespace Solaris\Sales\Http\Controllers;

use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\Sales\Http\Requests\ContractRequest;

#[FormAccess()]
class ContractController
{
    /** @var BaseRepository */
    protected $repo;

    public function __construct()
    {
        $this->repo = new (Helper::repository('contract'))(new (Helper::model('contract')));
    }

    public function index(): View
    {
        $breadcrumbs = [
            ['label' => 'Sales'],
            ['label' => 'Contract']
        ];

        return view(Helper::view("contract.list"), [
            'breadcrumbs' => $breadcrumbs
        ]);
    }

    public function store(): JsonResponse
    {
        /** @var ContractRequest $request */
        $request = app(Helper::formRequest("contract"));
        $data    = $this->repo->create($request->cleanData());

        return SolarResponse::success($data);
    }

    public function show(Request $request, string $id): RedirectResponse|JsonResponse
    {
        if(!$request->expectsJson()) {
            return redirect(route('sales.contract.edit', ['id' => $id]));
        }

        return response()->json($this->repo->findComplete($id, $this->extendColumns()));
    }

    public function edit(string $id): View
    {
        $data = $this->repo->findComplete($id, $this->extendColumns());
        $breadcrumbs = [
            ['label' => 'Sales'],
            ['label' => 'Contract'],
            ['label' => $data->number]
        ];

        return view(Helper::view("contract.page"), [
            'data'        => $data,
            'breadcrumbs' => $breadcrumbs
        ]);
    }

    public function update(string $id): JsonResponse
    {
        /** @var ContractRequest $request */
        $request = app(Helper::formRequest("contract"));
        $data    = $this->repo->update($id, $request->cleanData());

        return SolarResponse::success($data);
    }

    public function destroy(string $id): JsonResponse
    {
        return SolarResponse::deleted($this->repo->delete($id));
    }

    public function extendColumns(): array
    {
        return [];
    }
}
