<?php

namespace Solaris\Sales\Http\Controllers;

use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Solaris\Sales\Services\SalesDashboard;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Services\Dashboard\DashboardService;

class SalesDashboardController
{
    public function index(): View
    {
        $breadcrumbs = [
            ['label' => 'Dashboard'],
            ['label' => 'Sales']
        ];

        $period = DashboardService::getDefaultPeriod();

        return view(Helper::view("sales_dashboard"), [
            'breadcrumbs' => $breadcrumbs,
            'data'        => SalesDashboard::all($period)
        ]);
    }

    public function all(Request $request): JsonResponse
    {
        $period = $request->input('period');
        return response()->json(SalesDashboard::all($period));
    }

    public function opportunityPipeline(Request $request): JsonResponse
    {
        $period = $request->input('period');
        return response()->json(SalesDashboard::opportunityPipeline($period));
    }

    public function salesAnalytic(Request $request): JsonResponse
    {
        $period = $request->input('period');
        return response()->json(SalesDashboard::salesAnalytic($period));
    }

    public function activity(): JsonResponse
    {
        return response()->json(SalesDashboard::activity());
    }

    public function topSales(Request $request): JsonResponse
    {
        $period = $request->input('period');
        return response()->json(SalesDashboard::topSales($period));
    }

    public function topCustomer(Request $request): JsonResponse
    {
        $period = $request->input('period');
        return response()->json(SalesDashboard::topCustomer($period));
    }

    public function prospectBySource(Request $request): JsonResponse
    {
        $period = $request->input('period');
        return response()->json(SalesDashboard::prospectBySource($period));
    }

    public function opportunityOverview(Request $request): JsonResponse
    {
        $period = $request->input('period');
        return response()->json(SalesDashboard::opportunityOverview($period));
    }

    public function topOpportunity(Request $request): JsonResponse
    {
        $period = $request->input('period');
        return response()->json(SalesDashboard::topOpportunity($period));
    }

    public function revenueAnalytic(Request $request): JsonResponse
    {
        $period = $request->input('period');
        return response()->json(SalesDashboard::revenueAnalytic($period));
    }

    public function recentOrder(): JsonResponse
    {
        return response()->json(SalesDashboard::recentOrder());
    }

    public function topOrder(Request $request): JsonResponse
    {
        $period = $request->input('period');
        return response()->json(SalesDashboard::topOrder($period));
    }

    public function topProductOrdered(Request $request): JsonResponse
    {
        $period = $request->input('period');
        return response()->json(SalesDashboard::topProductOrdered($period));
    }
}