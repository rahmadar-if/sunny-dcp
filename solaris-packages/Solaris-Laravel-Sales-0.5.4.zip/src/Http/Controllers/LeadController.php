<?php

namespace Solaris\Sales\Http\Controllers;

use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Solaris\BaseCRM\Const\LeadStatusConst;
use Solaris\BaseCRM\Http\Controllers\LeadController as BaseLeadController;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Sales\Repositories\LeadRepository;

class LeadController extends BaseLeadController
{
    /** @var LeadRepository */
    protected $repo;

    public function index(): View
    {
        $breadcrumbs = [
            ['label' => 'Sales'],
            ['label' => 'Lead']
        ];

        return view(Helper::view("lead.list"), [
            'breadcrumbs' => $breadcrumbs
        ]);
    }

    public function show(Request $request, string $id): RedirectResponse|JsonResponse
    {
        if(!$request->expectsJson()) {
            return redirect(route('sales.lead.edit', ['id' => $id]));
        }

        return parent::show($request, $id);
    }

    public function edit(string $id): View
    {
        $data = $this->repo->findComplete($id, $this->extendColumns());
        $breadcrumbs = [
            ['label' => 'Sales'],
            ['label' => 'Lead'],
            ['label' => $data->name]
        ];

        return view(Helper::view("lead.page"), [
            'data'        => $data,
            'breadcrumbs' => $breadcrumbs
        ]);
    }

    public function update(string $id): JsonResponse
    {
        $request = app(Helper::formRequest("lead"));

        $cleanData = $request->cleanData();
        $cleanData["send_to_opportunity"] = $request->input("send_to_opportunity") ? true : false;

        $data = $this->repo->update($id, $cleanData);

        return SolarResponse::success($data);
    }

    public function listSummary(Request $request): JsonResponse
    {
        $search     = $request->input('search');
        $preFilters = $request->input('pre_filters', []);
        $filters    = $request->input('filters', []);

        $leadModel = new (Helper::model('lead'));
        $leadTable = $leadModel->getTable();
        $oppTable  = (new (Helper::model('opportunity')))->getTable();

        $hasOpportunity = "EXISTS (SELECT 1 FROM {$oppTable} WHERE {$oppTable}.lead_id = {$leadTable}.id)";

        $summary = $leadModel::query()
            ->selectRaw("COUNT(*) AS total_lead")
            ->selectRaw("COUNT(CASE WHEN {$leadTable}.status_id = ? THEN 1 END) AS total_cold", [LeadStatusConst::New])
            ->selectRaw(
                "COUNT(CASE WHEN {$leadTable}.status_id = ? OR ({$leadTable}.status_id = ? AND NOT {$hasOpportunity}) THEN 1 END) AS total_warm",
                [LeadStatusConst::Nurturing, LeadStatusConst::Qualified]
            )
            ->selectRaw(
                "COUNT(CASE WHEN {$leadTable}.status_id = ? AND {$hasOpportunity} THEN 1 END) AS total_hot",
                [LeadStatusConst::Qualified]
            )
            ->selectRaw(
                "COALESCE(SUM(CASE WHEN {$leadTable}.status_id <> ? THEN {$leadTable}.budget ELSE 0 END), 0) AS total_budget",
                [LeadStatusConst::Disqualified]
            )
            ->when(!empty($search), fn ($query) => $query->search($search))
            ->when(!empty($preFilters), fn ($query) => $query->filter($preFilters))
            ->when(!empty($filters), fn ($query) => $query->filter($filters))
            ->first();

        return response()->json([
            'total_lead'   => (int)$summary->total_lead,
            'total_cold'   => (int)$summary->total_cold,
            'total_warm'   => (int)$summary->total_warm,
            'total_hot'    => (int)$summary->total_hot,
            'total_budget' => (float)$summary->total_budget,
        ]);
    }

    public function prospect(string $id): JsonResponse
    {
        $data = $this->repo->hotLead($id);

        return SolarResponse::success($data);
    }
}
