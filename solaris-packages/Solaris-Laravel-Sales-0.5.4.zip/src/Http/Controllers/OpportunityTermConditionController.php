<?php

namespace Solaris\Sales\Http\Controllers;

use Illuminate\Http\JsonResponse;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\Sales\Http\Requests\OpportunityTermConditionRequest;

#[FormAccess()]
class OpportunityTermConditionController
{
    /** @var BaseRepository */
    protected $repo;

    public function __construct()
    {
        $this->repo = new (Helper::repository('opportunity_term_condition'))(new (Helper::model('opportunity_term_condition')));
    }

    public function store(): JsonResponse
    {
        /** @var OpportunityTermConditionRequest $request */
        $request = app(Helper::formRequest("opportunity_term_condition"));
        $data    = $this->repo->create($request->cleanData());

        return SolarResponse::success($data);
    }

    public function show(string $id): JsonResponse
    {
        return response()->json($this->repo->findComplete($id, $this->extendColumns()));
    }

    public function update(string $id): JsonResponse
    {
        /** @var OpportunityTermConditionRequest $request */
        $request = app(Helper::formRequest("opportunity_term_condition"));
        $data    = $this->repo->update($id, $request->cleanData());

        return SolarResponse::success($data);
    }

    public function destroy(string $id): JsonResponse
    {
        return SolarResponse::deleted($this->repo->delete($id));
    }

    public function extendColumns(): array
    {
        return [];
    }
}
