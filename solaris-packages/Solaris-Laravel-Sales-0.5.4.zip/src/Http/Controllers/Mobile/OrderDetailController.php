<?php

namespace Solaris\Sales\Http\Controllers\Mobile;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Sales\Http\Requests\OrderDetailRequest;
use Solaris\Sales\Repositories\OrderDetailRepository;

class OrderDetailController
{
	/** @var OrderDetailRepository */
	protected $repo;

	public function __construct()
	{
		$this->repo = new (Helper::repository('order_detail'))(new (Helper::model('order_detail')));
	}

	public function index(Request $request): JsonResponse
	{
		$data = $this->repo->list(
			columns : $this->listColumn(),
			search  : $request->input('search'),
			filter  : $request->input('filter'),
			sort    : $request->input('sort'),
			page    : $request->input('page'),
			length  : $request->input('length'),
		);
		return SolarResponse::list(Helper::mobileResouces('order_detail'), $data);
	}

	public function show(string $id): JsonResponse
	{
		$data = $this->repo->findComplete($id, $this->detailColumns());
		return new (Helper::mobileResouces('order_detail'))($data);
	}

	public function store(): JsonResponse
	{
		/** @var OrderDetailRequest */
		$request = app(Helper::formRequest('order_detail'));
		$data    = $this->repo->create($request->cleanData());

		return SolarResponse::success($data);
	}

	public function update(string $id): JsonResponse
	{
		/** @var OrderDetailRequest */
		$request = app(Helper::formRequest('order_detail'));
		$data    = $this->repo->update($id, $request->cleanData());

		return SolarResponse::success($data);
	}

	public function destroy(string $id): JsonResponse
	{
		return SolarResponse::deleted($this->repo->delete($id));
	}

	public function listColumn(): array
	{
		return [
			'id',
			'product',
			'price',
			'qty',
			'discount',
			'total',
		];
	}

	public function detailColumns(): array
	{
		return [
			'id',
			'product',
			'price',
			'qty',
			'discount',
			'amount',
			'total',
		];
	}
}
