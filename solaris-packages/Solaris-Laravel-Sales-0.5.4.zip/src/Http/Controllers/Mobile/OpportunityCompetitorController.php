<?php

namespace Solaris\Sales\Http\Controllers\Mobile;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\Sales\Http\Requests\OpportunityCompetitorRequest;

class OpportunityCompetitorController
{
	/** @var BaseRepository */
	protected $repo;

	public function __construct()
	{
		$this->repo = new (Helper::repository('opportunity_competitor'))(new (Helper::model('opportunity_competitor')));
	}

	public function index(Request $request): JsonResponse
	{
		$data = $this->repo->list(
			columns : $this->listColumn(),
			search  : $request->input('search'),
			filter  : $request->input('filter'),
			sort    : $request->input('sort'),
			page    : $request->input('page'),
			length  : $request->input('length'),
		);
		return SolarResponse::list(Helper::mobileResouces('opportunity_competitor'), $data);
	}

	public function show(string $id): JsonResponse
	{
		$data = $this->repo->findComplete($id, $this->detailColumns());
		return new (Helper::mobileResouces('opportunity_competitor'))($data);
	}

	public function store(): JsonResponse
	{
		/** @var OpportunityCompetitorRequest */
		$request = app(Helper::formRequest('opportunity_competitor'));
		$data    = $this->repo->create($request->cleanData());

		return SolarResponse::success($data);
	}

	public function update(string $id): JsonResponse
	{
		/** @var OpportunityCompetitorRequest */
		$request = app(Helper::formRequest('opportunity_competitor'));
		$data    = $this->repo->update($id, $request->cleanData());

		return SolarResponse::success($data);
	}

	public function destroy(string $id): JsonResponse
	{
		return SolarResponse::deleted($this->repo->delete($id));
	}

	public function listColumn(): array
	{
		return [
			'id',
			'name',
			'total_amount',
			'rating',
			'strength',
			'weakness',
		];
	}

	public function detailColumns(): array
	{
		return [
			'id',
			'name',
			'total_amount',
			'rating',
			'strength',
			'weakness',
		];
	}
}
