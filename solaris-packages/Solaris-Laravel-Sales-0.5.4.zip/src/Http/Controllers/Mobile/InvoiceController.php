<?php

namespace Solaris\Sales\Http\Controllers\Mobile;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Sales\Http\Requests\InvoiceRequest;
use Solaris\Sales\Repositories\InvoiceRepository;

class InvoiceController
{
	/** @var InvoiceRepository */
	protected $repo;

	public function __construct()
	{
		$this->repo = new (Helper::repository('invoice'))(new (Helper::model('invoice')));
	}

	public function index(Request $request): JsonResponse
	{
		$data = $this->repo->list(
			columns : $this->listColumn(),
			search  : $request->input('search'),
			filter  : $request->input('filter'),
			sort    : $request->input('sort'),
			page    : $request->input('page'),
			length  : $request->input('length'),
		);
		return SolarResponse::list(Helper::mobileResouces('invoice'), $data);
	}

	public function show(string $id): JsonResponse
	{
		$data = $this->repo->findComplete($id, $this->detailColumns());
		return new (Helper::mobileResouces('invoice'))($data);
	}

	public function store(): JsonResponse
	{
		/** @var InvoiceRequest */
		$request = app(Helper::formRequest('invoice'));
		$data    = $this->repo->create($request->cleanData());

		return SolarResponse::success($data);
	}

	public function update(string $id): JsonResponse
	{
		/** @var InvoiceRequest */
		$request = app(Helper::formRequest('invoice'));
		$data    = $this->repo->update($id, $request->cleanData());

		return SolarResponse::success($data);
	}

	public function destroy(string $id): JsonResponse
	{
		return SolarResponse::deleted($this->repo->delete($id));
	}

	public function listColumn(): array
	{
		return [
			'id',
			'number',
			'subject',
			'account',
			'contact',
			'due_date',
			'status',
			'amount',
		];
	}

	public function detailColumns(): array
	{
		return [
			'id',
			'number',
			'subject',
			'order',
			'account',
			'contact',
			'issued_date',
			'due_date',
			'completed_at',
			'status',
			'amount',
			'notes',
			'created_at',
			'updated_at',
			'created_by',
			'updated_by',
		];
	}
}
