<?php

namespace Solaris\Sales\Http\Controllers\Mobile;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Sales\Http\Requests\OpportunityRequest;
use Solaris\Sales\Http\Resources\Mobile\OpportunityResource;
use Solaris\Sales\Repositories\OpportunityRepository;

class OpportunityController
{
	/** @var OpportunityRepository */
	protected $repo;

	public function __construct()
	{
		$this->repo = new (Helper::repository('opportunity'))(new (Helper::model('opportunity')));
	}

	public function index(Request $request): JsonResponse
	{
		$data = $this->repo->list(
			columns : $this->listColumn(),
			search  : $request->input('search'),
			filter  : $request->input('filter'),
			sort    : $request->input('sort'),
			page    : $request->input('page'),
			length  : $request->input('length'),
		);
		return SolarResponse::list(Helper::mobileResouces('opportunity'), $data);
	}

	public function show(string $id): OpportunityResource
	{
		$data = $this->repo->findComplete($id, $this->detailColumns());
		return new (Helper::mobileResouces('opportunity'))($data);
	}

	public function store(): JsonResponse
	{
		/** @var OpportunityRequest */
		$request = app(Helper::formRequest('opportunity'));
		$data    = $this->repo->create($request->cleanData());

		return SolarResponse::success($data);
	}

	public function update(string $id): JsonResponse
	{
		/** @var OpportunityRequest */
		$request = app(Helper::formRequest('opportunity'));
		$data    = $this->repo->update($id, $request->cleanData());

		return SolarResponse::success($data);
	}

	public function destroy(string $id): JsonResponse
	{
		return SolarResponse::deleted($this->repo->delete($id));
	}

	public function listColumn(): array
	{
		return [
			'id',
			'date',
			'name',
			'customer',
			'decision_maker',
			'total_amount',
			'customer_need',
			'status',
			'phone',
			'email',
		];
	}

	public function detailColumns(): array
	{
		return [
			'id',
			'name',
			'date',
			'source',
			'is_new_customer',
			'closed_on',
			'customer',
			'decision_maker',
			'quotation_number',
			'customer_need',
			'budget',
			'latest_status',
			'status_date',
			'description',
			'our_weaknesses',
			'our_strengths',
			'sales_tactics',
			'status',
			'lead',
			'notes',
			'days_in_funnel',
			'created_at',
			'updated_at',
			'created_by',
			'updated_by',
		];
	}
}
