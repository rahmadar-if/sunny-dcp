<?php

namespace Solaris\Sales\Http\Controllers\Mobile;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Sales\Http\Requests\OpportunityProductRequest;
use Solaris\Sales\Repositories\OpportunityProductRepository;

class OpportunityProductController
{
	/** @var OpportunityProductRepository */
	protected $repo;

	public function __construct()
	{
		$this->repo = new (Helper::repository('opportunity_product'))(new (Helper::model('opportunity_product')));
	}

	public function index(Request $request): JsonResponse
	{
		$data = $this->repo->list(
			columns : $this->listColumn(),
			search  : $request->input('search'),
			filter  : $request->input('filter'),
			sort    : $request->input('sort'),
			page    : $request->input('page'),
			length  : $request->input('length'),
		);
		return SolarResponse::list(Helper::mobileResouces('opportunity_product'), $data);
	}

	public function show(string $id): JsonResponse
	{
		$data = $this->repo->findComplete($id, $this->detailColumns());
		return new (Helper::mobileResouces('opportunity_product'))($data);
	}

	public function store(): JsonResponse
	{
		/** @var OpportunityProductRequest */
		$request = app(Helper::formRequest('opportunity_product'));
		$data    = $this->repo->create($request->cleanData());

		return SolarResponse::success($data);
	}

	public function update(string $id): JsonResponse
	{
		/** @var OpportunityProductRequest */
		$request = app(Helper::formRequest('opportunity_product'));
		$data    = $this->repo->update($id, $request->cleanData());

		return SolarResponse::success($data);
	}

	public function destroy(string $id): JsonResponse
	{
		return SolarResponse::deleted($this->repo->delete($id));
	}

	public function listColumn(): array
	{
		return [
			'id',
			'product',
			'price',
			'qty',
			'disc',
			'total',
		];
	}

	public function detailColumns(): array
	{
		return [
			'id',
			'product',
			'price',
			'qty',
			'disc',
			'amount',
			'total',
		];
	}
}
