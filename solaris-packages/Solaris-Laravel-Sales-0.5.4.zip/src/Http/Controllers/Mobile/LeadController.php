<?php

namespace Solaris\Sales\Http\Controllers\Mobile;

use Illuminate\Http\JsonResponse;
use Solaris\BaseCRM\Http\Controllers\Mobile\LeadController as BaseLeadController;
use Solaris\BaseCRM\Http\Requests\LeadRequest;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Sales\Repositories\LeadRepository;

class LeadController extends BaseLeadController
{
	/** @var LeadRepository */
	protected $repo;

	public function update(string $id): JsonResponse
    {
		/** @var LeadRequest */
        $request = app(Helper::formRequest("lead"));

        $cleanData = $request->cleanData();
        $cleanData["send_to_opportunity"] = $request->input("send_to_opportunity") ? true : false;

        $data = $this->repo->update($id, $cleanData);

        return SolarResponse::success($data);
    }

	public function prospect(string $id): JsonResponse
    {
        $data = $this->repo->hotLead($id);

        return SolarResponse::success($data);
    }

	public function listColumn(): array
	{
		return array_merge(parent::listColumn(), ['opportunity']);
	}

	public function detailColumns(): array
	{
		return array_merge(parent::detailColumns(), ['opportunity']);
	}
}
