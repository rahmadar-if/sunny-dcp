<?php

namespace Solaris\Sales\Http\Controllers\Mobile;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\MasterData\Http\Controllers\Mobile\HomeController as BaseHomeController;
use Solaris\Sales\Http\Resources\Mobile\HotLeadResource;
use Solaris\Sales\Http\Resources\Mobile\TopOpportunityResource;
use Solaris\Sales\Repositories\LeadRepository;
use Solaris\Sales\Repositories\OpportunityRepository;

class HomeController extends BaseHomeController
{
    protected function buildIndexData(): array
    {
        return array_merge(parent::buildIndexData(), [
            'hot_leads'       => $this->getHotLeads(),
            'top_opportunity' => $this->getTopOpportunity(),
        ]);
    }

    protected function getHotLeads(): AnonymousResourceCollection
    {
        /** @var LeadRepository */
        $repo = new (Helper::repository('lead'))(new (Helper::model('lead')));
        return HotLeadResource::collection($repo->hotLeads());
    }

    protected function getTopOpportunity(): AnonymousResourceCollection
    {
        /** @var OpportunityRepository */
        $repo = new (Helper::repository('opportunity'))(new (Helper::model('opportunity')));
        return TopOpportunityResource::collection($repo->topOpportunity());
    }

    public function hotLeads(): JsonResponse
    {
        /** @var LeadRepository */
        $repo = new (Helper::repository('lead'))(new (Helper::model('lead')));
        return SolarResponse::list(HotLeadResource::class, $repo->hotLeads());
    }

    public function topOpportunity(): JsonResponse
    {
        /** @var OpportunityRepository */
        $repo = new (Helper::repository('opportunity'))(new (Helper::model('opportunity')));
        return SolarResponse::list(TopOpportunityResource::class, $repo->topOpportunity());
    }
}