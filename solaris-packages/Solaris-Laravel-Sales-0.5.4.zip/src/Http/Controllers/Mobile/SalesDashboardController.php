<?php

namespace Solaris\Sales\Http\Controllers\Mobile;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Http\Resources\Mobile\RecentOrderResource;
use Solaris\Sales\Http\Resources\Mobile\TopCustomerResource;
use Solaris\Sales\Http\Resources\Mobile\TopOpportunityResource;
use Solaris\Sales\Http\Resources\Mobile\TopOrderResource;
use Solaris\Sales\Http\Resources\Mobile\TopProductOrderedResource;
use Solaris\Sales\Http\Resources\Mobile\TopSalesResource;
use Solaris\Sales\Services\SalesDashboard;

class SalesDashboardController
{
    public function all(Request $request): JsonResponse
    {
        $period           = $request->input('period');
        $data             = SalesDashboard::all($period, true);
        $activityResource = Helper::mobileResouces('activity');

        $data['summary']['activity'] = [
            'upcoming' => $activityResource::collection($data['summary']['activity']['upcoming']),
            'todo'     => $activityResource::collection($data['summary']['activity']['todo']),
            'recent'   => $activityResource::collection($data['summary']['activity']['recent']),
        ];

        $data['summary']['top_sales']                 = TopSalesResource::collection($data['summary']['top_sales']);
        $data['summary']['top_customer']              = TopCustomerResource::collection($data['summary']['top_customer']);
        $data['lead_opportunity']['top_opportunity']  = TopOpportunityResource::collection($data['lead_opportunity']['top_opportunity']);
        $data['order_invoice']['recent_order']        = RecentOrderResource::collection($data['order_invoice']['recent_order']);
        $data['order_invoice']['top_order']           = TopOrderResource::collection($data['order_invoice']['top_order']);
        $data['order_invoice']['top_product_ordered'] = TopProductOrderedResource::collection($data['order_invoice']['top_product_ordered']);

        return response()->json($data);
    }

    public function opportunityPipeline(Request $request): JsonResponse
    {
        $period = $request->input('period');
        return response()->json(SalesDashboard::opportunityPipeline($period));
    }

    public function salesAnalytic(Request $request): JsonResponse
    {
        $period = $request->input('period');
        return response()->json(SalesDashboard::salesAnalytic($period, true));
    }

    public function activity(): JsonResponse
    {
        $data             = SalesDashboard::activity();
        $activityResource = Helper::mobileResouces('activity');

        return response()->json([
            'upcoming' => $activityResource::collection($data['upcoming']),
            'todo'     => $activityResource::collection($data['todo']),
            'recent'   => $activityResource::collection($data['recent']),
        ]);
    }

    public function topSales(Request $request): JsonResponse
    {
        $period = $request->input('period');
        return response()->json(TopSalesResource::collection(SalesDashboard::topSales($period)));
    }

    public function topCustomer(Request $request): JsonResponse
    {
        $period = $request->input('period');
        return response()->json(TopCustomerResource::collection(SalesDashboard::topCustomer($period)));
    }

    public function prospectBySource(Request $request): JsonResponse
    {
        $period = $request->input('period');
        return response()->json(SalesDashboard::prospectBySource($period, true));
    }

    public function opportunityOverview(Request $request): JsonResponse
    {
        $period = $request->input('period');
        return response()->json(SalesDashboard::opportunityOverview($period));
    }

    public function topOpportunity(Request $request): JsonResponse
    {
        $period = $request->input('period');
        return response()->json(TopOpportunityResource::collection(SalesDashboard::topOpportunity($period)));
    }

    public function revenueAnalytic(Request $request): JsonResponse
    {
        $period = $request->input('period');
        return response()->json(SalesDashboard::revenueAnalytic($period, true));
    }

    public function recentOrder(): JsonResponse
    {
        return response()->json(RecentOrderResource::collection(SalesDashboard::recentOrder()));
    }

    public function topOrder(Request $request): JsonResponse
    {
        $period = $request->input('period');
        return response()->json(TopOrderResource::collection(SalesDashboard::topOrder($period)));
    }

    public function topProductOrdered(Request $request): JsonResponse
    {
        $period = $request->input('period');
        return response()->json(TopProductOrderedResource::collection(SalesDashboard::topProductOrdered($period)));
    }
}
