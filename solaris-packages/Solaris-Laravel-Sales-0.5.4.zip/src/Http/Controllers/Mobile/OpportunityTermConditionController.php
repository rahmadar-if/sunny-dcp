<?php

namespace Solaris\Sales\Http\Controllers\Mobile;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\Sales\Http\Requests\OpportunityTermConditionRequest;

class OpportunityTermConditionController
{
	/** @var BaseRepository */
	protected $repo;

	public function __construct()
	{
		$this->repo = new (Helper::repository('opportunity_term_condition'))(new (Helper::model('opportunity_term_condition')));
	}

	public function index(Request $request): JsonResponse
	{
		$data = $this->repo->list(
			columns : $this->listColumn(),
			search  : $request->input('search'),
			filter  : $request->input('filter'),
			sort    : $request->input('sort'),
			page    : $request->input('page'),
			length  : $request->input('length'),
		);
		return SolarResponse::list(Helper::mobileResouces('opportunity_term_condition'), $data);
	}

	public function show(string $id): JsonResponse
	{
		$data = $this->repo->findComplete($id, $this->detailColumns());
		return new (Helper::mobileResouces('opportunity_term_condition'))($data);
	}

	public function store(): JsonResponse
	{
		/** @var OpportunityTermConditionRequest */
		$request = app(Helper::formRequest('opportunity_term_condition'));
		$data    = $this->repo->create($request->cleanData());

		return SolarResponse::success($data);
	}

	public function update(string $id): JsonResponse
	{
		/** @var OpportunityTermConditionRequest */
		$request = app(Helper::formRequest('opportunity_term_condition'));
		$data    = $this->repo->update($id, $request->cleanData());

		return SolarResponse::success($data);
	}

	public function destroy(string $id): JsonResponse
	{
		return SolarResponse::deleted($this->repo->delete($id));
	}

	public function listColumn(): array
	{
		return [
			'id',
			'subject',
		];
	}

	public function detailColumns(): array
	{
		return [
			'id',
			'subject',
		];
	}
}
