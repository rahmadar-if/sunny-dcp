<?php

namespace Solaris\Sales\Http\Controllers;

use Solaris\BaseCRM\Http\Controllers\ActivityController as BaseActivityController;

class ActivityController extends BaseActivityController
{
    public function extendColumns(): array
    {
        return array_merge(parent::extendColumns(), [
            "opportunity_id",
            "order_id",
            "invoice_id"
        ]);
    }
}