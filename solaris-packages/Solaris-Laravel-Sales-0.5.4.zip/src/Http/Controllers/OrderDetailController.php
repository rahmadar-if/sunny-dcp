<?php

namespace Solaris\Sales\Http\Controllers;

use Illuminate\Http\JsonResponse;
use Solaris\Core\Attributes\FormAccess;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Helpers\SolarResponse;
use Solaris\Sales\Http\Requests\OrderDetailRequest;
use Solaris\Sales\Repositories\OrderDetailRepository;

#[FormAccess()]
class OrderDetailController
{
    /** @var OrderDetailRepository */
    protected $repo;

    public function __construct()
    {
        $this->repo = new (Helper::repository('order_detail'))(new (Helper::model('order_detail')));
    }

    public function store(): JsonResponse
    {
        /** @var OrderDetailRequest $request */
        $request = app(Helper::formRequest("order_detail"));
        $data    = $this->repo->create($request->cleanData());

        return SolarResponse::success($data);
    }

    public function show(string $id): JsonResponse
    {
        return response()->json($this->repo->findComplete($id, $this->extendColumns()));
    }

    public function update(string $id): JsonResponse
    {
        /** @var OrderDetailRequest $request */
        $request = app(Helper::formRequest("order_detail"));
        $data    = $this->repo->update($id, $request->cleanData());

        return SolarResponse::success($data);
    }

    public function destroy(string $id): JsonResponse
    {
        return SolarResponse::deleted($this->repo->delete($id));
    }

    public function extendColumns(): array
    {
        return [];
    }
}
