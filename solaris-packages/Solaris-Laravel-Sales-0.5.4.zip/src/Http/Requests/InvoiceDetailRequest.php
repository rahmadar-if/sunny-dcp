<?php

namespace Solaris\Sales\Http\Requests;

use Illuminate\Validation\Rule;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Http\Requests\BaseFormRequest;

class InvoiceDetailRequest extends BaseFormRequest
{
    public function rules(): array
    {
        return $this->method() === 'POST' ? static::createRules() : static::updateRules();
    }

    // total is intentionally omitted — it is computed server-side by the repository, never client-supplied.
    public static function createRules(): array
    {
        return array_merge(static::updateRules(), [
            'product_id' => ['required', 'uuid', Rule::exists(Helper::model('product'), 'id')->where('active', true)],
            'invoice_id' => 'required|uuid',
        ]);
    }

    // product_id is not updatable — a line item's product cannot be swapped; delete and re-add instead.
    public static function updateRules(): array
    {
        return [
            'qty'      => 'required|integer',
            'price'    => 'required|decimal:0,2',
            'discount' => 'nullable|decimal:0,2',
        ];
    }
}
