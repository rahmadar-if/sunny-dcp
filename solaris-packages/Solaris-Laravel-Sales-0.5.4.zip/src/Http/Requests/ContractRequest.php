<?php

namespace Solaris\Sales\Http\Requests;

use Solaris\Core\Http\Requests\BaseFormRequest;

class ContractRequest extends BaseFormRequest
{
    public function rules(): array
    {
        return $this->method() === 'POST' ? static::createRules() : static::updateRules();
    }

    public static function createRules(): array
    {
        return [
            'number'     => 'required|string',
            'subject'    => 'required|string',
            'account_id' => 'required|uuid',
            'contact_id' => 'nullable|uuid',
            'start_date' => 'required|date_format:Y-m-d',
            'end_date'   => 'nullable|date_format:Y-m-d',
        ];
    }

    public static function updateRules(): array
    {
        return [
            'number'     => 'required|string',
            'subject'    => 'required|string',
            'account_id' => 'required|uuid',
            'contact_id' => 'nullable|uuid',
            'start_date' => 'required|date_format:Y-m-d',
            'end_date'   => 'required|date_format:Y-m-d',
            'amount'     => 'required|decimal:0,2',
            'notes'      => 'required|string',
        ];
    }
}
