<?php

namespace Solaris\Sales\Http\Requests;

use Solaris\Core\Http\Requests\BaseFormRequest;

class OrderRequest extends BaseFormRequest
{
    public function rules(): array
    {
        if ($this->routeIs('api.v1.order.update-status')) {
            return static::stageRules();
        }

        $isApi = $this->is('api/v1/*');

        return match ($this->method()) {
            'POST'  => $isApi ? static::apiCreateRules() : static::createRules(),
            'PUT'   => $isApi ? static::apiUpdateRules() : static::updateRules(),
            'PATCH' => static::patchRules(),
        };
    }

    /**
     * The stage on its own. Kept here so the controller documenting the endpoint and the request
     * validating it read from the same declaration.
     */
    public static function stageRules(): array
    {
        return ['status_id' => 'required|uuid'];
    }

    /**
     * The usual widening does not apply here.
     *
     * Elsewhere createRules() is short because the web create modal is short, so the API opens the
     * remaining fields. An order is different: it is derived from an opportunity, and creating()
     * overwrites date, account, contact, amount and status regardless of what arrives. Advertising
     * them would promise something the repository then ignores.
     */
    public static function apiCreateRules(): array
    {
        return static::createRules();
    }

    // Only opportunity_id is client-supplied on create — date, account, contact, amount, status and the
    // initial order_details are all derived from the opportunity by OrderRepository.
    public static function createRules(): array
    {
        return [
            'opportunity_id' => 'required|uuid',
            'notes'          => 'nullable|string',
        ];
    }

    public static function updateRules(): array
    {
        return [
            'date'       => 'required|date_format:Y-m-d',
            'account_id' => 'required|uuid',
            'contact_id' => 'nullable|uuid',
            'status_id'  => 'required|uuid',
            'notes'      => 'nullable|string',
        ];
    }
}
