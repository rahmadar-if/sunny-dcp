<?php

namespace Solaris\Sales\Http\Requests;

use Solaris\Core\Http\Requests\BaseFormRequest;

class OpportunityContactRequest extends BaseFormRequest
{
    public function rules(): array
    {
        return $this->method() === 'POST' ? static::createRules() : static::updateRules();
    }

    public static function createRules(): array
    {
        return array_merge(static::updateRules(), [
            'opportunity_id' => 'required|uuid',
        ]);
    }

    // role is nullable — when omitted it falls back to the linked contact's job title
    // (see OpportunityContactRepository::creating()).
    public static function updateRules(): array
    {
        return [
            'contact_id'        => 'required|uuid',
            'role'              => 'nullable|string|max:255',
            'is_decision_maker' => 'nullable|boolean',
        ];
    }
}
