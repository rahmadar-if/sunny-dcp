<?php

namespace Solaris\Sales\Http\Requests;

use Solaris\Core\Http\Requests\BaseFormRequest;

class OpportunityRequest extends BaseFormRequest
{
    public function rules(): array
    {
        if ($this->routeIs('api.v1.opportunity.update-status')) {
            return static::stageRules();
        }

        $isApi = $this->is('api/v1/*');

        $rules = match ($this->method()) {
            // The API has no two-step create, so it opens every writable field at once.
            'POST'  => $isApi ? static::apiCreateRules() : static::createRules(),
            'PUT'   => $isApi ? static::apiUpdateRules() : static::updateRules(),
            'PATCH' => static::patchRules(),
        };

        return $rules;
    }

    /**
     * The stage on its own. Kept here so the controller documenting the endpoint and the request
     * validating it read from the same declaration.
     */
    public static function stageRules(): array
    {
        return ['status_id' => 'required|uuid'];
    }

    public static function createRules(): array
    {
        return [
            'name'              => 'required|string|max:255',
            'date'              => 'required|date_format:Y-m-d',
            'customer_id'       => 'required|uuid',
            'decision_maker_id' => 'nullable|uuid',
            'customer_need'     => 'required|string|min:10',
            'budget'            => 'nullable|decimal:0,2',
            'source_id'         => 'required|uuid',
            'status_id'         => 'nullable|uuid',
            'type_id'           => 'nullable|uuid',
            'phone'             => 'required_without:email|nullable|string|max:50',
            'email'             => 'required_without:phone|nullable|string|email|max:255',
        ];
    }

    public static function updateRules(): array
    {
        return array_merge(static::createRules(), [
            'quotation_number'    => 'nullable|string|max:255',
            'latest_status'       => 'nullable|string|max:255',
            'status_date'         => 'nullable|date_format:Y-m-d',
            'description'         => 'nullable|string',
            'is_new_customer'     => 'nullable|boolean',
            'closed_on'           => 'nullable|date_format:Y-m-d',
            'status_id'           => 'nullable|uuid',
            'our_strengths'       => 'nullable|string',
            'our_weaknesses'      => 'nullable|string',
            'sales_tactics'       => 'nullable|string',
            'notes'               => 'nullable|string'
        ]);
    }
}