<?php

namespace Solaris\Sales\Http\Requests;

use Solaris\Core\Http\Requests\BaseFormRequest;

class OpportunityCompetitorRequest extends BaseFormRequest
{
    public function rules(): array
    {
        return $this->method() === 'POST' ? static::createRules() : static::updateRules();
    }

    public static function createRules(): array
    {
        return array_merge(static::updateRules(), [
            'opportunity_id' => 'required|uuid',
        ]);
    }

    public static function updateRules(): array
    {
        return [
            'name'         => 'required|string',
            'total_amount' => 'nullable|decimal:0,2',
            'strength'     => 'nullable|string',
            'weakness'     => 'nullable|string',
            'rating'       => 'nullable|integer',
        ];
    }
}
