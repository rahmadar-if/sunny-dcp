<?php

namespace Solaris\Sales\Http\Requests;

use Solaris\Core\Http\Requests\BaseFormRequest;

class InvoiceRequest extends BaseFormRequest
{
    public function rules(): array
    {
        if ($this->routeIs('api.v1.invoice.update-status')) {
            return static::stageRules();
        }

        $isApi = $this->is('api/v1/*');

        return match ($this->method()) {
            'POST'  => $isApi ? static::apiCreateRules() : static::createRules(),
            'PUT'   => $isApi ? static::apiUpdateRules() : static::updateRules(),
            'PATCH' => static::patchRules(),
        };
    }

    /**
     * The stage on its own. Kept here so the controller documenting the endpoint and the request
     * validating it read from the same declaration.
     */
    public static function stageRules(): array
    {
        return ['status_id' => 'required|uuid'];
    }

    /**
     * The usual widening does not apply here.
     *
     * Elsewhere createRules() is short because the web create modal is short, so the API opens the
     * remaining fields. An invoice is different: it is derived from an order, and creating()
     * overwrites account, contact, amount and status regardless of what arrives. Advertising them
     * would promise something the repository then ignores.
     */
    public static function apiCreateRules(): array
    {
        return static::createRules();
    }

    // account_id, contact_id, amount and the initial invoice_details are derived from the order by
    // InvoiceRepository — only subject and order_id are client-supplied on create.
    public static function createRules(): array
    {
        return [
            'subject'  => 'required|string',
            'order_id' => 'required|uuid',
            'notes'    => 'nullable|string',
        ];
    }

    public static function updateRules(): array
    {
        return [
            'due_date'   => 'required|date_format:Y-m-d',
            'amount'     => 'required|decimal:0,2',
            'account_id' => 'required|uuid',
            'contact_id' => 'nullable|uuid',
            'status_id'  => 'required|uuid',
            'notes'      => 'nullable|string',
        ];
    }
}
