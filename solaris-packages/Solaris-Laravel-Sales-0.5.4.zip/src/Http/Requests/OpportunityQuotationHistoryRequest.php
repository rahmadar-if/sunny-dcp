<?php

namespace Solaris\Sales\Http\Requests;

use Solaris\Core\Http\Requests\BaseFormRequest;

class OpportunityQuotationHistoryRequest extends BaseFormRequest
{
    public function rules(): array
    {
        $rules = [
            "number_quotation" => "required|string",
            "total_amount"     => 'required|decimal:0,2',
            'date'             => 'required|date_format:Y-m-d',
        ];

        if($this->method() == 'POST') {
            $rules['opportunity_id'] = 'required|uuid';
        }

        return $rules;
    }
}
