<?php

namespace Solaris\Sales\Http\Requests;

use Solaris\Core\Http\Requests\BaseFormRequest;

class OpportunityTermConditionRequest extends BaseFormRequest
{
    public function rules(): array
    {
        return $this->method() === 'POST' ? static::createRules() : static::updateRules();
    }

    public static function createRules(): array
    {
        return array_merge(static::updateRules(), [
            'opportunity_id' => 'required|uuid',
        ]);
    }

    public static function updateRules(): array
    {
        return [
            'subject' => 'required|string',
        ];
    }
}
