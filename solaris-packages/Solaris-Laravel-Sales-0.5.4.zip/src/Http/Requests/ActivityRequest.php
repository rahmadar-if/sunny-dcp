<?php

namespace Solaris\Sales\Http\Requests;

use Solaris\BaseCRM\Http\Requests\ActivityRequest as BaseActivityRequest;

class ActivityRequest extends BaseActivityRequest
{
    public static function createRules(): array
    {
        return array_merge(parent::createRules(), [
            'opportunity_id' => 'nullable|uuid',
            'order_id'       => 'nullable|uuid',
            'invoice_id'     => 'nullable|uuid',
        ]);
    }

    public static function updateRules(): array
    {
        return array_merge(parent::updateRules(), [
            'opportunity_id' => 'nullable|uuid',
            'order_id'       => 'nullable|uuid',
            'invoice_id'     => 'nullable|uuid',
        ]);
    }
}