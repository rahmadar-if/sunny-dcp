<?php

namespace Solaris\Sales\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Helpers\LookupResource;
use Solaris\Core\Http\Resources\BaseResource;

class OpportunityStatusHistoryResource extends BaseResource
{
	protected function list(Request $request): array
	{
		return [
			'id'     => $this->id,
			'status' => LookupResource::from($this->status),
			'start'  => $this->start,
			'end'    => $this->end,
		];
	}

	protected function detail(Request $request): array
	{
		return [
			'id'     => $this->id,
			'status' => LookupResource::from($this->status),
			'start'  => $this->start,
			'end'    => $this->end,
		];
	}
}
