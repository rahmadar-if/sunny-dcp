<?php

namespace Solaris\Sales\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Helpers\LookupResource;
use Solaris\Core\Http\Resources\BaseResource;

class InvoiceDetailResource extends BaseResource
{
	protected function list(Request $request): array
	{
		return [
			'id'       => $this->id,
			'product'  => LookupResource::from($this->product),
			'price'    => $this->price,
			'qty'      => $this->qty,
			'discount' => $this->discount,
			'total'    => $this->total,
		];
	}

	protected function detail(Request $request): array
	{
		return [
			'id'       => $this->id,
			'product'  => LookupResource::from($this->product),
			'price'    => $this->price,
			'qty'      => $this->qty,
			'discount' => $this->discount,
			'amount'   => $this->amount,
			'total'    => $this->total,
		];
	}
}
