<?php

namespace Solaris\Sales\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Helpers\LookupResource;
use Solaris\Core\Http\Resources\BaseResource;

class OpportunityResource extends BaseResource
{
	protected function list(Request $request): array
	{
		return [
			'id'             => $this->id,
			'date'           => $this->date,
			'name'           => $this->name,
			'customer'       => LookupResource::from($this->customer),
			'decision_maker' => LookupResource::from($this->decision_maker),
			'total_amount'   => $this->total_amount,
			'customer_need'  => $this->customer_need,
			'status'         => LookupResource::from($this->status, ['color', 'probability']),
			'phone' 		 => $this->phone,
			'email' 		 => $this->email,
			'source'		 => LookupResource::from($this->source),
		];
	}

	protected function detail(Request $request): array
	{
		return [
			'id'               => $this->id,
			'name'             => $this->name,
			'date'             => $this->date,
			'source'           => LookupResource::from($this->source),
			'is_new_customer'  => $this->is_new_customer,
			'closed_on'        => $this->closed_on,
			'customer'         => LookupResource::from($this->customer),
			'decision_maker'   => LookupResource::from($this->decision_maker),
			'quotation_number' => $this->quotation_number,
			'customer_need'    => $this->customer_need,
			'budget'           => $this->budget,
			'latest_status'    => $this->latest_status,
			'status_date'      => $this->status_date,
			'description'      => $this->description,
			'our_weaknesses'   => $this->our_weaknesses,
			'our_strengths'    => $this->our_strengths,
			'sales_tactics'    => $this->sales_tactics,
			'status'           => LookupResource::from($this->status, ['color', 'probability']),
			'lead'             => LookupResource::from($this->lead),
			'notes'            => $this->notes,
			'amount'		   => $this->amount,
			'total_amount'	   => $this->total_amount,
			'discount_amount'  => $this->discount_amount,
			'discount_percent' => $this->discount_percent,
			'days_in_funnel'   => $this->days_in_funnel,
			'created_at'       => $this->created_at,
			'updated_at'       => $this->updated_at,
			'created_by'       => LookupResource::user($this->created_by),
			'updated_by'       => LookupResource::user($this->updated_by),
		];
	}
}
