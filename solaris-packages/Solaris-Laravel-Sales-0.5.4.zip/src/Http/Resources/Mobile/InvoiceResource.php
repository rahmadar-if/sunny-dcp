<?php

namespace Solaris\Sales\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Helpers\LookupResource;
use Solaris\Core\Http\Resources\BaseResource;

class InvoiceResource extends BaseResource
{
	protected function list(Request $request): array
	{
		return [
			'id'       => $this->id,
			'number'   => $this->number,
			'subject'  => $this->subject,
			'account'  => LookupResource::from($this->account),
			'contact'  => LookupResource::from($this->contact),
			'due_date' => $this->due_date,
			'status'   => LookupResource::lookupStage($this->status),
			'amount'   => $this->amount,
		];
	}

	protected function detail(Request $request): array
	{
		return [
			'id'           => $this->id,
			'number'       => $this->number,
			'subject'      => $this->subject,
			'order'        => LookupResource::from($this->order),
			'account'      => LookupResource::from($this->account),
			'contact'      => LookupResource::from($this->contact),
			'issued_date'  => $this->issued_date,
			'due_date'     => $this->due_date,
			'completed_at' => $this->completed_at,
			'status'       => LookupResource::lookupStage($this->status),
			'amount'       => $this->amount,
			'notes'        => $this->notes,
			'created_at'   => $this->created_at,
			'updated_at'   => $this->updated_at,
			'created_by'   => LookupResource::user($this->created_by),
			'updated_by'   => LookupResource::user($this->updated_by),
		];
	}
}
