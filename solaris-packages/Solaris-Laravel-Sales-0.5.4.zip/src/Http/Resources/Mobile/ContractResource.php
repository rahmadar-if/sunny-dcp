<?php

namespace Solaris\Sales\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Helpers\LookupResource;
use Solaris\Core\Http\Resources\BaseResource;

class ContractResource extends BaseResource
{
	protected function list(Request $request): array
	{
		return [
			'id'         => $this->id,
			'number'     => $this->number,
			'subject'    => $this->subject,
			'account'    => LookupResource::from($this->account),
			'contact'    => LookupResource::from($this->contact),
			'start_date' => $this->start_date,
			'end_date'   => $this->end_date,
			'amount'     => $this->amount,
		];
	}

	protected function detail(Request $request): array
	{
		return [
			'id'         => $this->id,
			'number'     => $this->number,
			'subject'    => $this->subject,
			'account'    => LookupResource::from($this->account),
			'contact'    => LookupResource::from($this->contact),
			'start_date' => $this->start_date,
			'end_date'   => $this->end_date,
			'amount'     => $this->amount,
			'notes'      => $this->notes,
			'created_at' => $this->created_at,
			'updated_at' => $this->updated_at,
			'created_by' => LookupResource::user($this->created_by),
			'updated_by' => LookupResource::user($this->updated_by),
		];
	}
}
