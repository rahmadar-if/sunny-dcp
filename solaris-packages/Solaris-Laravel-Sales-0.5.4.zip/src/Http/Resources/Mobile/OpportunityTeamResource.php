<?php

namespace Solaris\Sales\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Http\Resources\BaseResource;

class OpportunityTeamResource extends BaseResource
{
	protected function list(Request $request): array
	{
		return [
			'id'   => $this->id,
			'name' => $this->name,
			'role' => $this->role,
		];
	}

	protected function detail(Request $request): array
	{
		return [
			'id'   => $this->id,
			'name' => $this->name,
			'role' => $this->role,
		];
	}
}
