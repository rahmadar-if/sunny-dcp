<?php

namespace Solaris\Sales\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Http\Resources\BaseResource;
use Solaris\Core\Helpers\LookupResource;

class HotLeadResource extends BaseResource
{
    protected function list(Request $request): array
    {
        return [
			'id'           => $this->id,
			'date'         => $this->date,
			'name'         => $this->name,
			'account'      => LookupResource::from($this->account),
			'account_name' => $this->account_name,
			'contact_name' => $this->contact_name,
			'budget_range' => LookupResource::from($this->budget_range),
			'customer_need'=> $this->customer_need,
			'status'       => LookupResource::from($this->status, 'color'),
			'phone'        => $this->phone,
			'email'        => $this->email,
			'contact'      => LookupResource::from($this->contact),
			'source'       => LookupResource::from($this->source),
		];
    }

    protected function detail(Request $request): array
    {
        return [];
    }
}
