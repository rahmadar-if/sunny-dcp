<?php

namespace Solaris\Sales\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Http\Resources\BaseResource;

class OpportunityQuotationHistoryResource extends BaseResource
{
	protected function list(Request $request): array
	{
		return [
			'id'               => $this->id,
			'date'             => $this->date,
			'number_quotation' => $this->number_quotation,
			'total_amount'     => $this->total_amount,
		];
	}

	protected function detail(Request $request): array
	{
		return [
			'id'               => $this->id,
			'date'             => $this->date,
			'number_quotation' => $this->number_quotation,
			'total_amount'     => $this->total_amount,
		];
	}
}
