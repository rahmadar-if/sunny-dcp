<?php

namespace Solaris\Sales\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Http\Resources\BaseResource;

class OpportunityCompetitorResource extends BaseResource
{
	protected function list(Request $request): array
	{
		return [
			'id'           => $this->id,
			'name'         => $this->name,
			'total_amount' => $this->total_amount,
			'rating'       => $this->rating,
			'strength'     => $this->strength,
			'weakness'     => $this->weakness,
		];
	}

	protected function detail(Request $request): array
	{
		return [
			'id'           => $this->id,
			'name'         => $this->name,
			'total_amount' => $this->total_amount,
			'rating'       => $this->rating,
			'strength'     => $this->strength,
			'weakness'     => $this->weakness,
		];
	}
}
