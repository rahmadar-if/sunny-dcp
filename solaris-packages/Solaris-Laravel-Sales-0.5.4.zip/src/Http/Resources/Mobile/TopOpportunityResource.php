<?php

namespace Solaris\Sales\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Http\Resources\BaseResource;
use Solaris\Core\Helpers\LookupResource;

class TopOpportunityResource extends BaseResource
{
    protected function list(Request $request): array
    {
        return [
            'id'             => $this->id,
            'date'           => $this->date,
            'name'           => $this->name,
            'customer'       => LookupResource::from($this->customer),
            'decision_maker' => LookupResource::from($this->decision_maker),
            'source'         => LookupResource::from($this->source),
            'status'         => LookupResource::from($this->status, ['color', 'probability']),
            'total_amount'   => $this->total_amount,
        ];
    }

    protected function detail(Request $request): array
    {
        return [];
    }
}
