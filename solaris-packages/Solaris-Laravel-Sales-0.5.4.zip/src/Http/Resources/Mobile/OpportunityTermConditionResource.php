<?php

namespace Solaris\Sales\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Http\Resources\BaseResource;

class OpportunityTermConditionResource extends BaseResource
{
	protected function list(Request $request): array
	{
		return [
			'id'      => $this->id,
			'subject' => $this->subject,
		];
	}

	protected function detail(Request $request): array
	{
		return [
			'id'      => $this->id,
			'subject' => $this->subject,
		];
	}
}
