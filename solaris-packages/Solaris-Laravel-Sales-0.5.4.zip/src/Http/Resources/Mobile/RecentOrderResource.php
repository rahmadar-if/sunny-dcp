<?php

namespace Solaris\Sales\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Helpers\LookupResource;
use Solaris\Core\Http\Resources\BaseResource;

class RecentOrderResource extends BaseResource
{
    protected function list(Request $request): array
    {
        return [
            'id'      => $this->id,
            'number'  => $this->number,
            'date'    => $this->date,
            'recent'  => $this->recent,
            'account' => LookupResource::from($this->account),
            'status'  => LookupResource::from($this->status, 'color'),
            'amount'  => $this->amount_formatted,
            'avatar'  => LookupResource::image($this->account->profile_picture_id)['thumbnail']
        ];
    }

    protected function detail(Request $request): array
    {
        return [];
    }
}
