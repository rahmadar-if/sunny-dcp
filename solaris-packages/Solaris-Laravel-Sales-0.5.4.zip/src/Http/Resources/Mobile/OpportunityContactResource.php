<?php

namespace Solaris\Sales\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Helpers\LookupResource;
use Solaris\Core\Http\Resources\BaseResource;

class OpportunityContactResource extends BaseResource
{
	protected function list(Request $request): array
	{
		return [
			'id'                => $this->id,
			'contact'           => LookupResource::from($this->contact),
			'role'              => $this->role,
			'is_decision_maker' => $this->is_decision_maker,
		];
	}

	protected function detail(Request $request): array
	{
		return [
			'id'                => $this->id,
			'contact'           => LookupResource::from($this->contact),
			'role'              => $this->role,
			'is_decision_maker' => $this->is_decision_maker,
		];
	}
}
