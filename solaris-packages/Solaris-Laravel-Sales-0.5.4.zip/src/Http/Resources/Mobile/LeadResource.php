<?php

namespace Solaris\Sales\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Helpers\LookupResource;
use Solaris\BaseCRM\Http\Resources\Mobile\LeadResource as BaseLeadResource;

class LeadResource extends BaseLeadResource
{
	protected function list(Request $request): array
	{
		return array_merge(parent::list($request), [
			'opportunity' => LookupResource::from($this->opportunity)
		]);
	}

	protected function detail(Request $request): array
	{
		return array_merge(parent::detail($request), [
			'opportunity' => LookupResource::from($this->opportunity)
		]);
	}
}
