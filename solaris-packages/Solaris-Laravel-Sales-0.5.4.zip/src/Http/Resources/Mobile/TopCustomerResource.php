<?php

namespace Solaris\Sales\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Helpers\LookupResource;
use Solaris\Core\Http\Resources\BaseResource;

class TopCustomerResource extends BaseResource
{
    protected function list(Request $request): array
    {
        return [
            'account_id'          => $this->account_id,
            'account_name'        => $this->account_name,
            'primary_contact'     => $this->primary_contact,
            'avatar'              => LookupResource::image($this->avatar)['thumbnail'],
            'total_invoice_amount'=> $this->total_invoice_amount,
            'total_invoice'       => $this->total_invoice,
        ];
    }

    protected function detail(Request $request): array
    {
        return [];
    }
}
