<?php

namespace Solaris\Sales\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Helpers\LookupResource;
use Solaris\Core\Http\Resources\BaseResource;

class TopSalesResource extends BaseResource
{
    protected function list(Request $request): array
    {
        return [
            'user_id'                  => $this->user_id,
            'user_name'                => $this->user_name,
            'user_email'               => $this->user_email,
            'avatar'                   => LookupResource::image($this->avatar)['thumbnail'],
            'total_opportunity_amount' => $this->total_opportunity_amount,
            'total_opportunity'        => $this->total_opportunity,
        ];
    }

    protected function detail(Request $request): array
    {
        return [];
    }
}
