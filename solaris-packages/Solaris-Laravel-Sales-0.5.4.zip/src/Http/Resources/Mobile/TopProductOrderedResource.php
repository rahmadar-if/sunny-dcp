<?php

namespace Solaris\Sales\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Solaris\Core\Helpers\LookupResource;
use Solaris\Core\Http\Resources\BaseResource;

class TopProductOrderedResource extends BaseResource
{
    protected function list(Request $request): array
    {
        return [
            'id'           => $this->product_id,
            'name'         => $this->product_name,
            'avatar'       => LookupResource::image($this->avatar)['thumbnail'],
            'total_qty'    => $this->total_qty,
            'total_amount' => $this->total_amount,
            'order_count'  => $this->order_count,
        ];
    }

    protected function detail(Request $request): array
    {
        return [];
    }
}
