<?php

namespace Solaris\Sales\Http\Resources\Api;

use Illuminate\Http\Request;
use Solaris\BaseCRM\Http\Resources\Api\ContactResource as BaseContactResource;

class ContactResource extends BaseContactResource
{
    /**
     * These figures come from ContactRepository::findComplete(), which runs three sums and two
     * subqueries per record. Behind ?include=stats so a 25-row list does not turn into a hundred
     * queries, and so the base shape stays identical between list and detail.
     */
    public function includes(Request $request): array
    {
        return [
            'stats' => fn () => [
                'sales_total_revenue'       => $this->sales_total_revenue,
                'sales_total_sales'         => $this->sales_total_sales,
                'sales_outstanding_invoice' => $this->sales_outstanding_invoice,
                'latest_lead'               => $this->latest_lead,
                'latest_opportunity'        => $this->latest_opportunity,
            ],
        ];
    }
}
