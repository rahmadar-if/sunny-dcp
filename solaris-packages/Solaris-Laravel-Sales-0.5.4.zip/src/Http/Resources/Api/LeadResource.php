<?php

namespace Solaris\Sales\Http\Resources\Api;

use Illuminate\Http\Request;
use Solaris\BaseCRM\Http\Resources\Api\LeadResource as BaseLeadResource;
use Solaris\Core\Helpers\LookupResource;

class LeadResource extends BaseLeadResource
{
    protected function fields(Request $request): array
    {
        return array_merge(parent::fields($request), [
            'opportunity' => LookupResource::from($this->opportunity),
        ]);
    }
}
