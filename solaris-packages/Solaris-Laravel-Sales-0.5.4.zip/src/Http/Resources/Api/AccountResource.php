<?php

namespace Solaris\Sales\Http\Resources\Api;

use Illuminate\Http\Request;
use Solaris\BaseCRM\Http\Resources\Api\AccountResource as BaseAccountResource;

class AccountResource extends BaseAccountResource
{
    /**
     * These figures come from AccountRepository::findComplete(), which runs three counts, three
     * sums and two subqueries per record. Behind ?include=stats so a 25-row list does not turn
     * into two hundred queries, and so the base shape stays identical between list and detail.
     */
    public function includes(Request $request): array
    {
        return [
            'stats' => fn () => [
                'total_opportunity'          => $this->total_opportunity,
                'total_order'                => $this->total_order,
                'total_invoice'              => $this->total_invoice,
                'sales_total_revenue'        => $this->sales_total_revenue,
                'sales_total_sales'          => $this->sales_total_sales,
                'sales_outstanding_invoice'  => $this->sales_outstanding_invoice,
                'latest_lead'                => $this->latest_lead,
                'latest_opportunity'         => $this->latest_opportunity,
            ],
        ];
    }
}
