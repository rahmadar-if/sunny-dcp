<?php

namespace Solaris\Sales\Http\Resources\Api;

use Illuminate\Http\Request;
use Solaris\Core\Helpers\LookupResource;
use Solaris\Core\Http\Resources\Api\BaseApiResource;

class OrderResource extends BaseApiResource
{
    protected function fields(Request $request): array
    {
        return [
            'id'          => $this->id,
            'number'      => $this->number,
            'date'        => $this->date,
            'opportunity' => LookupResource::from($this->opportunity),
            'account'     => LookupResource::from($this->account),
            'contact'     => LookupResource::from($this->contact),
            'status'      => LookupResource::lookupStage($this->status),
            'amount'      => $this->amount,
            'notes'       => $this->notes,
            'created_at'  => $this->created_at,
            'updated_at'  => $this->updated_at,
            'created_by'  => LookupResource::user($this->created_by),
            'updated_by'  => LookupResource::user($this->updated_by),
        ];
    }
}
