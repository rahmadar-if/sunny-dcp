<?php

namespace Solaris\Sales\Http\Resources\Api;

use Illuminate\Http\Request;
use Solaris\Core\Helpers\LookupResource;
use Solaris\Core\Http\Resources\Api\BaseApiResource;

class OpportunityResource extends BaseApiResource
{
    protected function fields(Request $request): array
    {
        return [
            'id'                  => $this->id,
            'name'                => $this->name,
            'date'                => $this->date,
            'type'                => LookupResource::from($this->type),
            'source'              => LookupResource::from($this->source),
            'status'              => LookupResource::lookupStage($this->status),
            'lead'                => LookupResource::from($this->lead),
            'customer'            => LookupResource::from($this->customer),
            'decision_maker'      => LookupResource::from($this->decision_maker),
            'phone'               => $this->phone,
            'email'               => $this->email,
            'customer_need'       => $this->customer_need,
            'budget'              => $this->budget,
            'amount'              => $this->amount,
            'discount_amount'     => $this->discount_amount,
            'discount_percent'    => $this->discount_percent,
            'total_amount'        => $this->total_amount,
            'probability_percent' => $this->probability_percent,
            'quotation_number'    => $this->quotation_number,
            'latest_status'       => $this->latest_status,
            'status_date'         => $this->status_date,
            'closed_on'           => $this->closed_on,
            'is_new_customer'     => $this->is_new_customer,
            'description'         => $this->description,
            'our_strengths'       => $this->our_strengths,
            'our_weaknesses'      => $this->our_weaknesses,
            'sales_tactics'       => $this->sales_tactics,
            'days_in_funnel'      => $this->days_in_funnel,
            'notes'               => $this->notes,
            'created_at'          => $this->created_at,
            'updated_at'          => $this->updated_at,
            'created_by'          => LookupResource::user($this->created_by),
            'updated_by'          => LookupResource::user($this->updated_by),
        ];
    }
}
