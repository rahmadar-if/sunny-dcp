<?php

namespace Solaris\Sales\Http\Resources\Api;

use Illuminate\Http\Request;
use Solaris\Core\Helpers\LookupResource;
use Solaris\Core\Http\Resources\Api\BaseApiResource;

class InvoiceResource extends BaseApiResource
{
    protected function fields(Request $request): array
    {
        return [
            'id'           => $this->id,
            'number'       => $this->number,
            'subject'      => $this->subject,
            'order'        => LookupResource::from($this->order),
            'account'      => LookupResource::from($this->account),
            'contact'      => LookupResource::from($this->contact),
            'issued_date'  => $this->issued_date,
            'due_date'     => $this->due_date,
            'completed_at' => $this->completed_at,
            'status'       => LookupResource::lookupStage($this->status),
            'amount'       => $this->amount,
            'notes'        => $this->notes,
            'created_at'   => $this->created_at,
            'updated_at'   => $this->updated_at,
            'created_by'   => LookupResource::user($this->created_by),
            'updated_by'   => LookupResource::user($this->updated_by),
        ];
    }
}
