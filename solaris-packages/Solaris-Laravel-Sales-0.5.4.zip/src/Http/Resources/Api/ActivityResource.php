<?php

namespace Solaris\Sales\Http\Resources\Api;

use Illuminate\Http\Request;
use Solaris\BaseCRM\Http\Resources\Api\ActivityResource as BaseActivityResource;
use Solaris\Core\Helpers\LookupResource;

class ActivityResource extends BaseActivityResource
{
    protected function fields(Request $request): array
    {
        return array_merge(parent::fields($request), [
            'opportunity' => LookupResource::from($this->opportunity),
            'order'       => LookupResource::from($this->order),
            'invoice'     => LookupResource::from($this->invoice),
        ]);
    }
}
