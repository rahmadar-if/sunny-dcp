<?php

namespace Solaris\Sales\Repositories;

use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Interfaces\Model\SolarisModel;
use Solaris\Core\Models\Attachment;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\Core\Services\HtmlToPdfService;
use Solaris\MasterData\Const\AddressTypeConst;
use Solaris\Sales\Const\OpportunityStatusConst;
use Solaris\Sales\Models\Opportunity;
use Solaris\Sales\Models\OpportunityQuotationHistory;

class OpportunityRepository extends BaseRepository
{
    public function __construct(Opportunity $model, bool $transaction = true)
    {
        parent::__construct($model, $transaction);
    }

    public function findComplete(string $id, array $columns = []): Opportunity
    {
        $data = $this->model
            ->prepared(array_merge(static::defaultColumns(), $columns))
            ->where('id', $id)
            ->first();

        return $data;
    }

    protected function creating(array $data): array
    {
        if (!isset($data['status_id'])) {
            $data['status_id'] = OpportunityStatusConst::Qualification;
        }
        
        return $data;
    }

    protected function created(Model|SolarisModel $record, array $data, array $rawData): void
    {
        if ($record->decision_maker_id) {
            $contact = Helper::model('contact')::find($record->decision_maker_id);
    
            Helper::model('opportunity_contact')::create([
                'contact_id'        => $record->decision_maker_id,
                'opportunity_id'    => $record->id,
                'role'              => $contact?->job_title ?? '',
                'is_decision_maker' => true,
            ]);
        }
    }

    protected function updating(Model|SolarisModel $record, array $data): array
    {
        if (isset($data['status_id']) && $data['status_id'] !== $record->status_id) {
            $status = $this->getOpportunityStatus($data['status_id']);

            if ($data['status_id'] == OpportunityStatusConst::ClosedWon) {
                $data['closed_on'] = now();
            }

            $data['probability_percent'] = $status->probability;
        }

        return [$record, $data];
    }

    protected function updated(Model|SolarisModel $record, array $data, array $rawData): void
    {
        if (!array_key_exists('decision_maker_id', $data)) {
            return;
        }

        $oldId              = $record->getOriginal('decision_maker_id');
        $newId              = $record->decision_maker_id;
        $opportunityContact = Helper::model('opportunity_contact');

        if ($newId !== $oldId) {
            if (!$newId) {
                $opportunityContact::where('opportunity_id', $record->id)
                    ->where('contact_id', $oldId)
                    ->where('is_decision_maker', true)
                    ->delete();
            } elseif (!$oldId) {
                $contact = Helper::model('contact')::find($newId);
                $opportunityContact::create([
                    'contact_id'        => $newId,
                    'opportunity_id'    => $record->id,
                    'role'              => $contact?->job_title ?? '',
                    'is_decision_maker' => true,
                ]);
            } else {
                $opportunityContact::where('opportunity_id', $record->id)
                    ->where('contact_id', $oldId)
                    ->where('is_decision_maker', true)
                    ->update(['contact_id' => $newId]);
            }
        }
    }

    private function getOpportunityStatus(string $statusId)
    {
        return Helper::model('opportunity_status')::getCache()->get($statusId);
    }

    public static function defaultColumns(): array
    {
        return [
            'id',
            'name',
            'date',
            'is_new_customer',
            'phone',
            'email',
            'budget',
            'customer_need',
            'amount',
            'discount_amount',
            'discount_percent',
            'total_amount',
            'quotation_number',
            'latest_status',
            'status_date',
            'description',
            'our_weaknesses',
            'our_strengths',
            'sales_tactics',
            'notes',
            'customer[name,industry.name,primary_phone,email,profile_picture_id]',
            'decision_maker[name,job_title,profile_picture_id]',
            'lead[name,date,budget_range,is_new_account,is_new_contact]',
            'status_id',
            'created_by_id',
            'source_id',
            'closed_on',
            'type_id',
            'days_in_funnel'
        ];
    }

    public static function bulkUpdateDaysInFunnel(): int
    {
        $expression = match(DB::getDriverName()) {
            'pgsql'  => 'GREATEST(0, CURRENT_DATE - "date"::date)',
            'sqlsrv' => 'CASE WHEN DATEDIFF(day, [date], CAST(GETDATE() AS DATE)) < 0 THEN 0 ELSE DATEDIFF(day, [date], CAST(GETDATE() AS DATE)) END',
            default  => 'GREATEST(0, DATEDIFF(CURDATE(), `date`))',
        };

        return Helper::model('opportunity')::whereNotIn('status_id', [OpportunityStatusConst::ClosedWon, OpportunityStatusConst::ClosedLost])
            ->update(['days_in_funnel' => DB::raw($expression)]);
    }

    public function topOpportunity(int $length = 5): Collection
    {
        return $this->model
            ->prepared([
                'name',
                'date',
                'source.name',
                'customer.name',
                'decision_maker.name',
                'total_amount',
                'status[name,color,probability]',
            ])
            ->whereNotIn('status_id', [OpportunityStatusConst::Qualification, OpportunityStatusConst::ClosedWon, OpportunityStatusConst::ClosedLost])
            ->sort([['status.probability', 'desc'], ['total_amount', 'desc'], ['date', 'desc']])
            ->skip(0)
            ->take($length)
            ->get();
    }

    public function printQuotation(string $id, bool $download = true): Response|OpportunityQuotationHistory
    {
        $opportunity = $this->model
            ->with(['customer.addresses', 'products.product'])
            ->find($id);

        abort_if(!$opportunity, 404, 'Opportunity not found.');
        abort_if(!$opportunity->customer_id, 422, 'Customer must be set before printing a quotation.');
        abort_if(!$opportunity->phone && !$opportunity->email, 422, 'Phone or email must be set before printing a quotation.');
        abort_if($opportunity->products->isEmpty(), 422, 'At least one product is required before printing a quotation.');

        $addresses = $opportunity->customer?->addresses ?? new Collection();
        $address   = $addresses->firstWhere('address_type_id', AddressTypeConst::Business) ?? $addresses->first();
        abort_if(!$address, 422, 'Customer address must be set before printing a quotation.');

        $history = Helper::model('opportunity_quotation_history')::create([
            'opportunity_id' => $opportunity->id,
            'date'           => now(),
            'total_amount'   => $opportunity->total_amount,
        ]);

        $pdf = HtmlToPdfService::view('sales::pdf.quotation.classic', [
            'opportunity' => $opportunity,
            'history'     => $history,
            'address'     => $address,
        ], false);

        $filename     = "{$history->number_quotation}.pdf";
        $response     = $pdf->download($filename);
        $binary       = $response->getContent();
        $attachmentId = (string) Str::orderedUuid();
        $path         = str_replace('-', '', $attachmentId) . '.pdf';

        Storage::disk('public')->put($path, $binary);

        $attachment = Attachment::create([
            'id'             => $attachmentId,
            'disk'           => 'public',
            'file_name'      => $filename,
            'file_size'      => strlen($binary),
            'file_extension' => 'pdf',
            'table_name'     => 'opportunity_quotation_histories',
            'record_id'      => $history->id,
            'path'           => $path,
        ]);

        $history->update(['attachment_id' => $attachment->id]);

        return $download ? $response : $history->load('attachment');
    }
}