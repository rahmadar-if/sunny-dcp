<?php

namespace Solaris\Sales\Repositories;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Interfaces\Model\SolarisModel;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\Sales\Models\OrderDetail;

class OrderDetailRepository extends BaseRepository
{
	public function __construct(OrderDetail $model, bool $transaction = true)
	{
		parent::__construct($model, $transaction);
	}

	protected function creating(array $data): array
	{
		$data['total'] = $this->calculateTotal($data['price'], $data['qty'], $data['discount']);
		return $data;
	}

	protected function created(Model|SolarisModel $record, array $data, array $rawData): void
	{
		$this->updateOrderAmount($record);
	}

	protected function updating(Model|SolarisModel $record, array $data): array
	{
		$data['total'] = $this->calculateTotal(
			$data['price']    ?? $record->price,
			$data['qty']      ?? $record->qty,
			$data['discount'] ?? $record->discount
		);

		return [$record, $data];
	}

	private function calculateTotal(float $price, float $qty, ?float $discount): float
	{
		return ($price * $qty) - ($discount ?? 0);
	}

	protected function updated(Model|SolarisModel $record, array $data, array $rawData): void
	{
		$this->updateOrderAmount($record);
	}

	protected function deleted(Model|SolarisModel $record): void
	{
		$this->updateOrderAmount($record);
	}

	private function updateOrderAmount(Model $orderDetail): void
	{
		$order = Helper::model('order')::find($orderDetail->order_id);
		$order->amount = $order->detail->sum('total');
		$order->save();
	}
}
