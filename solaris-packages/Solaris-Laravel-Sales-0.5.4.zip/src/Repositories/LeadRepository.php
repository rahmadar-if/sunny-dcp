<?php

namespace Solaris\Sales\Repositories;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Solaris\BaseCRM\Const\LeadStatusConst;
use Solaris\BaseCRM\Repositories\LeadRepository as BaseLeadRepository;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Interfaces\Model\SolarisModel;
use Solaris\Sales\Const\OpportunityStatusConst;
use Solaris\Sales\Const\OpportunityTypeConst;
use Solaris\Sales\Models\Opportunity;

class LeadRepository extends BaseLeadRepository
{
    protected function updating(Model|SolarisModel $record, array $data): array
    {
        [$record, $data] = parent::updating($record, $data);

        unset($data["send_to_opportunity"]);

        $isQualifying = isset($data['status_id']) && $data['status_id'] === LeadStatusConst::Qualified;
        $hasAccount   = !is_null($record->account_id) || !empty($data['account_id']);
        $hasContact   = !is_null($record->contact_id) || !empty($data['contact_id']);

        if ($isQualifying && !$hasAccount && !$hasContact) {
            throw new \Exception("Lead must have at least an Account or Contact before this action");
        }

        return [$record, $data];
    }

    protected function updated(Model|SolarisModel $record, array $data, array $rawData): void
    {
        parent::updated($record, $data, $rawData);

        if (
            $record->wasChanged('status_id') &&
            $record->status_id === LeadStatusConst::Qualified &&
            ($rawData['send_to_opportunity'] ?? false) &&
            !$record->opportunity()->exists()
        ) {
            $this->toOpportunity($record);
        }
    }

    // Eligibility guard for the Hot Lead action — reused by the AI HotLeadTool to surface the same error
    // up front (before confirmation) that hotLead() would otherwise throw at execution time. Returns the
    // error message, or null when the lead is eligible.
    public static function hotLeadValidationError(Model $lead): ?string
    {
        $allowedStatuses = [LeadStatusConst::Nurturing, LeadStatusConst::Qualified];

        if (!in_array($lead->status_id, $allowedStatuses)) {
            return "Hot Lead is only allowed from Nurturing or Qualified status.";
        }

        if ($lead->opportunity()->exists()) {
            return "Lead already has an Opportunity.";
        }

        if (is_null($lead->account_id) && is_null($lead->contact_id)) {
            return "Lead must have at least an Account or Contact.";
        }

        return null;
    }

    public function hotLead(string $id): Opportunity
    {
        $opportunity = null;
        try {
            DB::beginTransaction();

            $data = $this->find($id);

            if ($error = static::hotLeadValidationError($data)) {
                throw new \Exception($error);
            }

            $data->status_id = LeadStatusConst::Qualified;
            $data->save();

            $opportunity = $this->toOpportunity($data);

            DB::commit();
        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
        }

        return $opportunity;
    }

    public function toOpportunity(Model $lead): Opportunity
    {
        $now  = Carbon::now();
        $repo = new (Helper::repository('opportunity'))(new (Helper::model('opportunity')));
        return $repo->create([
            'name'              => $lead->name,
            'date'              => $now->format('Y-m-d'),
            'customer_id'       => $lead->account_id,
            'decision_maker_id' => $lead->contact_id,
            'phone'             => $lead->phone,
            'email'             => $lead->email,
            'customer_need'     => $lead->customer_need,
            'lead_id'           => $lead->id,
            'source_id'         => $lead->source_id,
            'type_id'           => OpportunityTypeConst::NewBusiness,
            'status_id'         => OpportunityStatusConst::Qualification,
            'is_new_customer'   => $lead->is_new_contact || $lead->is_new_account
        ]);
    }

    public static function defaultColumns(): array
    {
        return array_merge(parent::defaultColumns(), [
            'opportunity[date,name,status[name,color],total_amount]'  
        ]);
    }

    public function hotLeads(int $length = 5): Collection
    {
        return $this->model
            ->prepared([
                'id',
                'date',
                'name',
                'account.name',
                'contact.name',
                'account_name',
                'contact_name',
                'budget_range.name',
                'budget',
                'customer_need',
                'status[name,color]',
                'phone',
                'email',
                'source.name',
            ])
            ->where(function($q) {
                $q->where(fn($q) => $q->where('status_id', LeadStatusConst::Nurturing)->whereNotNull('budget_range_id'))
                  ->orWhere('status_id', LeadStatusConst::Qualified);
            })
            ->whereDoesntHave('opportunity')
            ->where(fn($q) => $q->whereNotNull('account_id')->orWhereNotNull('contact_id'))
            ->orderBy("date", "desc")
            ->skip(0)
            ->take($length)
            ->get();
    }
}