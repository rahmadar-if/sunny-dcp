<?php

namespace Solaris\Sales\Repositories;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Interfaces\Model\SolarisModel;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\Sales\Const\OrderStatusConst;
use Solaris\Sales\Models\Order;

class OrderRepository extends BaseRepository
{
    public function __construct(Order $model, bool $transaction = true)
    {
        parent::__construct($model, $transaction);
    }
    
    public function findComplete(string $id, array $columns = []): Order
    {
        $data = $this->model
            ->prepared(array_merge(static::defaultColumns(), $columns))
            ->where('id', $id)
            ->first();

        return $data;
    }

    protected function creating(array $data): array
    {
        $data['status_id'] = OrderStatusConst::Draft;

        $opportunity         = Helper::model('opportunity')::find($data["opportunity_id"]);
        $data["date"]        = Carbon::now();
        $data["account_id"]  = $opportunity->customer_id;
        $data["contact_id"]  = $opportunity->decision_maker_id;
        $data["amount"]      = $opportunity->total_amount;

        return $data;
    }

    protected function created(Model|SolarisModel $record, array $data, array $rawData): void
    {
        $products = Helper::model('opportunity_product')::where('opportunity_id', $data["opportunity_id"])->get();

        $orderDetails = [];
        foreach ($products as $product) {
            $orderDetails[] = [
                "id"            => (string) Str::uuid7(),
                "order_id"      => $record->id,
                "product_id"    => $product->product_id,
                "price"         => $product->price,
                "qty"           => $product->qty,
                "discount"      => $product->disc,
                "total"         => $product->total,
                "created_by_id" => $record->created_by_id,
                "updated_by_id" => $record->created_by_id
            ];
        }

        if (!empty($orderDetails)) {
            DB::table("order_details")->insert($orderDetails);
        }
    }

    public static function defaultColumns(): array
    {
        return [
            'id',
            'number',
            'date',
            'amount',
            'account_id',
            'contact_id',
            'opportunity_id',
            'status_id',
            'created_by_id'
        ];
    }
}
