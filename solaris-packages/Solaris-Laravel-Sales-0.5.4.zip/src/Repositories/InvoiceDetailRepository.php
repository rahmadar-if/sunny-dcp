<?php

namespace Solaris\Sales\Repositories;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Interfaces\Model\SolarisModel;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\Sales\Models\InvoiceDetail;

class InvoiceDetailRepository extends BaseRepository
{
	public function __construct(InvoiceDetail $model, bool $transaction = true)
	{
		parent::__construct($model, $transaction);
	}

	protected function creating(array $data): array
	{
		$data['total'] = $this->calculateTotal($data['price'], $data['qty'], $data['discount']);
		return $data;
	}

	protected function created(Model|SolarisModel $record, array $data, array $rawData): void
	{
		$this->updateInvoiceAmount($record);
	}

	protected function updating(Model|SolarisModel $record, array $data): array
	{
		$data['total'] = $this->calculateTotal(
			$data['price']    ?? $record->price,
			$data['qty']      ?? $record->qty,
			$data['discount'] ?? $record->discount
		);
		return [$record, $data];
	}

	private function calculateTotal(float $price, float $qty, ?float $discount): float
	{
		return ($price * $qty) - ($discount ?? 0);
	}

	protected function updated(Model|SolarisModel $record, array $data, array $rawData): void
	{
		$this->updateInvoiceAmount($record);
	}

	protected function deleted(Model|SolarisModel $record): void
	{
		$this->updateInvoiceAmount($record);
	}

	private function updateInvoiceAmount(Model $invoiceDetail): void
	{
		$invoice = Helper::model('invoice')::find($invoiceDetail->invoice_id);
		$invoice->amount = $invoice->detail->sum('total');
		$invoice->save();
	}
}
