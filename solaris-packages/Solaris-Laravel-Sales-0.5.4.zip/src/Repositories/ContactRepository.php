<?php

namespace Solaris\Sales\Repositories;

use Solaris\BaseCRM\Const\LeadStatusConst;
use Solaris\Core\Helpers\Helper;
use Solaris\MasterData\Repositories\ContactRepository as BaseContactRepository;
use Solaris\Sales\Const\InvoiceStatusConst;
use Solaris\Sales\Const\OpportunityStatusConst;
use Solaris\Sales\Const\OrderStatusConst;
use Solaris\Sales\Models\Contact;

class ContactRepository extends BaseContactRepository
{
    public function __construct(Contact $model, bool $transaction = true)
    {
        parent::__construct($model, $transaction);
    }

    public function findComplete(string $id, array $columns = []): Contact
    {
        $data = parent::findComplete($id, $columns);

        $data->sales_total_revenue = (float) Helper::model('invoice')::where('contact_id', $id)
            ->where('status_id', InvoiceStatusConst::Completed)
            ->sum('amount');

        $data->sales_total_sales = (float) Helper::model('order')::where('contact_id', $id)
            ->whereIn('status_id', [OrderStatusConst::Confirmation, OrderStatusConst::Completed])
            ->sum('amount');

        $data->sales_outstanding_invoice = (float) Helper::model('invoice')::where('contact_id', $id)
            ->where('status_id', InvoiceStatusConst::Issued)
            ->sum('amount');

        $opportunityIds = Helper::model('opportunity_contact')::where('contact_id', $id)
            ->pluck('opportunity_id');

        $data->latest_lead = Helper::model('lead')::prepared('name', 'date', 'status.name')
            ->where('contact_id', $id)
            ->whereNot('status_id', LeadStatusConst::Disqualified)
			->where(function($query) {
				$query->whereNot('status_id', LeadStatusConst::Qualified)
					->orWhere(
						fn($query) => $query->where('status_id', LeadStatusConst::Qualified)
							->whereDoesntHave('opportunity')
						);
			})
            ->latest('date')
            ->first();

        $data->latest_opportunity = Helper::model('opportunity')::prepared('name', 'date', 'status.name', 'total_amount')
            ->whereIn('id', $opportunityIds)
            ->whereNotIn('status_id', [OpportunityStatusConst::ClosedWon, OpportunityStatusConst::ClosedLost])
            ->latest('date')
            ->first();

        return $data;
    }
}
