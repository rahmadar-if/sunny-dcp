<?php

namespace Solaris\Sales\Repositories;

use Solaris\BaseCRM\Const\LeadStatusConst;
use Solaris\BaseCRM\Models\Account;
use Solaris\BaseCRM\Repositories\AccountRepository as BaseAccountRepository;
use Solaris\Core\Helpers\Helper;
use Solaris\Sales\Const\InvoiceStatusConst;
use Solaris\Sales\Const\OpportunityStatusConst;
use Solaris\Sales\Const\OrderStatusConst;

class AccountRepository extends BaseAccountRepository
{
	public function __construct(Account $model, bool $transaction = true)
	{
		parent::__construct($model, $transaction);
	}

	public function findComplete(string $id, array $columns = []): Account
	{
		$data = parent::findComplete($id, $columns);

		$data->total_opportunity = Helper::model('opportunity')::where('customer_id', $id)->count();
		$data->total_order       = Helper::model('order')::where('account_id', $id)->count();
		$data->total_invoice     = Helper::model('invoice')::where('account_id', $id)->count();

		$data->sales_total_revenue = (float) Helper::model('invoice')::where('account_id', $id)
			->where('status_id', InvoiceStatusConst::Completed)
			->sum('amount');

		$data->sales_total_sales = (float) Helper::model('order')::where('account_id', $id)
			->whereIn('status_id', [OrderStatusConst::Confirmation, OrderStatusConst::Completed])
			->sum('amount');

		$data->sales_outstanding_invoice = (float) Helper::model('invoice')::where('account_id', $id)
			->where('status_id', InvoiceStatusConst::Issued)
			->sum('amount');

		$data->latest_lead = Helper::model('lead')::prepared('name', 'date', 'status.name', 'budget_range.name')
			->where('account_id', $id)
			->whereNot('status_id', LeadStatusConst::Disqualified)
			->where(function($query) {
				$query->whereNot('status_id', LeadStatusConst::Qualified)
					->orWhere(
						fn($query) => $query->where('status_id', LeadStatusConst::Qualified)
							->whereDoesntHave('opportunity')
						);
			})
			->latest('date')
			->first();

		$data->latest_opportunity = Helper::model('opportunity')::prepared('name', 'date', 'status.name', 'total_amount')
			->where('customer_id', $id)
			->whereNotIn('status_id', [OpportunityStatusConst::ClosedWon, OpportunityStatusConst::ClosedLost])
			->latest('date')
			->first();

		return $data;
	}
}
