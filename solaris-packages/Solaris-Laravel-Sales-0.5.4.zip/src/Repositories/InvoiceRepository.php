<?php

namespace Solaris\Sales\Repositories;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Interfaces\Model\SolarisModel;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\Sales\Const\InvoiceStatusConst;
use Solaris\Sales\Models\Invoice;

class InvoiceRepository extends BaseRepository
{
    public function __construct(Invoice $model, bool $transaction = true)
    {
        parent::__construct($model, $transaction);
    }

    public function findComplete(string $id, array $columns = []): Invoice
    {
        $data = $this->model
            ->prepared(array_merge(static::defaultColumns(), $columns))
            ->where('id', $id)
            ->first();

        return $data;
    }

    protected function creating(array $data): array
    {
        $data['status_id'] = InvoiceStatusConst::Draft;

        $order              = Helper::model('order')::find($data["order_id"]);
        $data["account_id"] = $order->account_id;
        $data["contact_id"] = $order->contact_id;
        $data["amount"]     = $order->amount;

        return $data;
    }

    protected function created(Model|SolarisModel $record, array $data, array $rawData): void
    {
        $products = Helper::model('order_detail')::where('order_id', $data["order_id"])->get();

        $invoiceDetails = [];
        foreach ($products as $product) {
            $invoiceDetails[] = [
                'id'            => (string) Str::uuid7(),
                'invoice_id'    => $record->id,
                'price'         => $product->price,
                'qty'           => $product->qty,
                'discount'      => $product->discount,
                'total'         => $product->total,
                'product_id'    => $product->product_id,
                'created_by_id' => $record->created_by_id,
                'updated_by_id' => $record->created_by_id
            ];
        }

        if (!empty($invoiceDetails)) {
            DB::table("invoice_details")->insert($invoiceDetails);
        }
    }

    protected function updating(Model|SolarisModel $record, array $data): array
    {
        if(isset($data['status_id'])) {
            if($data['status_id'] == InvoiceStatusConst::Issued) {
                $data['issued_date'] = now();
            } else if($data['status_id'] == InvoiceStatusConst::Completed) {
                $data['completed_at'] = now();
            }
        }
        return [$record, $data];
    }

    public static function defaultColumns(): array
    {
        return [
            'id',
            'number',
            'subject',
            'issued_date',
            'due_date',
            'completed_at',
            'amount',
            'order_id',
            'account_id',
            'contact_id',
            'status_id',
            'created_by_id'
        ];
    }
}
