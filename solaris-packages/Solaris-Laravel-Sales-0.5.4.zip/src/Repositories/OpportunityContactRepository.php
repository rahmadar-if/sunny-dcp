<?php

namespace Solaris\Sales\Repositories;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Interfaces\Model\SolarisModel;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\Sales\Models\OpportunityContact;

class OpportunityContactRepository extends BaseRepository
{
    public function __construct(OpportunityContact $model, bool $transaction = true)
    {
        parent::__construct($model, $transaction);
    }

    // role defaults to the linked contact's job title when not explicitly provided.
    protected function creating(array $data): array
    {
        if (empty($data['role']) && !empty($data['contact_id'])) {
            $data['role'] = Helper::model('contact')::find($data['contact_id'])?->job_title;
        }

        return $data;
    }

    protected function created(Model|SolarisModel $record, array $data, array $rawData): void
    {
        if ($record->is_decision_maker) {
            $this->promoteToDecisionMaker($record, $record->contact_id);
        }
    }

    protected function updated(Model|SolarisModel $record, array $data, array $rawData): void
    {
        if (isset($data['is_decision_maker']) && $record->is_decision_maker) {
            $this->promoteToDecisionMaker($record, $record->contact_id);
        }
    }

    protected function promoteToDecisionMaker(Model $record, string $contactId): void
    {
        Helper::model('opportunity_contact')::where('opportunity_id', $record->opportunity_id)
            ->where('id', '!=', $record->id)
            ->where('is_decision_maker', true)
            ->update(['is_decision_maker' => false]);

        $opportunity = Helper::model('opportunity')::find($record->opportunity_id);

        if ($opportunity && $opportunity->decision_maker_id !== $contactId) {
            $opportunity->decision_maker_id = $contactId;
            $opportunity->save();
        }
    }
}
