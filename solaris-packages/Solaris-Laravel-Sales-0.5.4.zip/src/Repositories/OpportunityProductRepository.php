<?php

namespace Solaris\Sales\Repositories;

use Illuminate\Database\Eloquent\Model;
use Solaris\Core\Helpers\Helper;
use Solaris\Core\Interfaces\Model\SolarisModel;
use Solaris\Core\Repositories\BaseRepository;
use Solaris\Sales\Models\OpportunityProduct;

class OpportunityProductRepository extends BaseRepository
{
	public function __construct(OpportunityProduct $model, bool $transaction = true)
	{
		parent::__construct($model, $transaction);
	}

	protected function creating(array $data): array
	{
		$data['total'] = $this->calculateTotal($data['price'], $data['qty'], $data['disc'] ?? null);
		return $data;
	}

	protected function created(Model|SolarisModel $record, array $data, array $rawData): void
	{
		$this->updateOpportunityAmount($record);
	}

	protected function updating(Model|SolarisModel $record, array $data): array
	{
		$data['total'] = $this->calculateTotal(
			$data['price'] ?? $record->price,
			$data['qty']   ?? $record->qty,
			$data['disc']  ?? $record->disc
		);
		return [$record, $data];
	}

	private function calculateTotal(float $price, float $qty, ?float $disc): float
	{
		return ($price * $qty) - ($disc ?? 0);
	}

	protected function updated(Model|SolarisModel $record, array $data, array $rawData): void
	{
		$this->updateOpportunityAmount($record);
	}

	protected function deleted(Model|SolarisModel $record): void
	{
		$this->updateOpportunityAmount($record);
	}

	private function updateOpportunityAmount(Model $opportunityProduct): void
	{
		$opportunity      = Helper::model('opportunity')::find($opportunityProduct->opportunity_id);
		$totalDiscount    = $opportunity->products->sum('disc');
		$totalTotalAmount = $opportunity->products->sum('total');

		$opportunity->amount           = $totalTotalAmount + $totalDiscount;
		$opportunity->discount_amount  = $totalDiscount;
		$opportunity->discount_percent = $opportunity->amount > 0
			? ($totalDiscount / $opportunity->amount) * 100
			: 0;
		$opportunity->total_amount     = $totalTotalAmount;
		$opportunity->save();
	}
}
