<?php

namespace Solaris\Sales;

use Illuminate\Support\Facades\Route;
use Spatie\LaravelPackageTools\Package;
use Spatie\LaravelPackageTools\PackageServiceProvider;

class SolarisSalesServiceProvider extends PackageServiceProvider
{
    public function configurePackage(Package $package): void
    {
        /*
         * This class is a Package Service Provider
         *
         * More info: https://github.com/spatie/laravel-package-tools
         */
        $package
            ->name('sales')
            ->hasConfigFile(['solaris'])
            ->hasViews('sales')
            ->discoversMigrations()
            ->runsMigrations();
    }

    public function packageBooted()
    {
        Route::middleware('web')
            ->group(__DIR__ . '/../routes/web.php');

        Route::middleware('api')
            ->prefix('api')
            ->group([
                __DIR__.'/../routes/api.php',
                __DIR__.'/../routes/mobile.php',
            ]);
    }
}
