<?php

use Illuminate\Support\Facades\Route;
use Solaris\Core\Helpers\Helper;

// Only what Sales adds on top of BaseCRM. The CRUD block stays where it was declared; swapping the
// controller is done through config, not by redeclaring routes.
Route::prefix('v1')
    ->middleware(['api.log', 'auth.api_key', 'throttle:api_key'])
    ->group(function () {
        Route::prefix('leads')->group(function () {
            $controller = Helper::apiController('lead');

            Route::post('/{id}/prospect', [$controller, 'prospect'])
                ->whereUuid('id')
                ->middleware('permission:api.lead.prospect')
                ->name('api.v1.lead.prospect');
        });

        Route::prefix('opportunities')->group(function () {
            $controller = Helper::apiController('opportunity');

            Route::get('/', [$controller, 'index'])
                ->middleware('permission:api.opportunity.view')
                ->name('api.v1.opportunity.index');

            Route::post('/search', [$controller, 'search'])
                ->middleware('permission:api.opportunity.view')
                ->name('api.v1.opportunity.search');

            Route::post('/', [$controller, 'store'])
                ->middleware(['permission:api.opportunity.create', 'api.idempotency'])
                ->name('api.v1.opportunity.store');

            Route::get('/{id}', [$controller, 'show'])
                ->whereUuid('id')
                ->middleware('permission:api.opportunity.view')
                ->name('api.v1.opportunity.show');

            Route::patch('/{id}', [$controller, 'update'])
                ->whereUuid('id')
                ->middleware('permission:api.opportunity.update')
                ->name('api.v1.opportunity.update');

            Route::put('/{id}', [$controller, 'replace'])
                ->whereUuid('id')
                ->middleware('permission:api.opportunity.update')
                ->name('api.v1.opportunity.replace');

            Route::delete('/{id}', [$controller, 'destroy'])
                ->whereUuid('id')
                ->middleware('permission:api.opportunity.delete')
                ->name('api.v1.opportunity.destroy');

            Route::post('/{id}/status', [$controller, 'updateStatus'])
                ->whereUuid('id')
                ->middleware(['permission:api.opportunity.update-status', 'api.idempotency'])
                ->name('api.v1.opportunity.update-status');
        });

        Route::prefix('orders')->group(function () {
            $controller = Helper::apiController('order');

            Route::get('/', [$controller, 'index'])
                ->middleware('permission:api.order.view')
                ->name('api.v1.order.index');

            Route::post('/search', [$controller, 'search'])
                ->middleware('permission:api.order.view')
                ->name('api.v1.order.search');

            Route::post('/', [$controller, 'store'])
                ->middleware(['permission:api.order.create', 'api.idempotency'])
                ->name('api.v1.order.store');

            Route::get('/{id}', [$controller, 'show'])
                ->whereUuid('id')
                ->middleware('permission:api.order.view')
                ->name('api.v1.order.show');

            Route::patch('/{id}', [$controller, 'update'])
                ->whereUuid('id')
                ->middleware('permission:api.order.update')
                ->name('api.v1.order.update');

            Route::put('/{id}', [$controller, 'replace'])
                ->whereUuid('id')
                ->middleware('permission:api.order.update')
                ->name('api.v1.order.replace');

            Route::delete('/{id}', [$controller, 'destroy'])
                ->whereUuid('id')
                ->middleware('permission:api.order.delete')
                ->name('api.v1.order.destroy');

            Route::post('/{id}/status', [$controller, 'updateStatus'])
                ->whereUuid('id')
                ->middleware(['permission:api.order.update-status', 'api.idempotency'])
                ->name('api.v1.order.update-status');
        });

        Route::prefix('invoices')->group(function () {
            $controller = Helper::apiController('invoice');

            Route::get('/', [$controller, 'index'])
                ->middleware('permission:api.invoice.view')
                ->name('api.v1.invoice.index');

            Route::post('/search', [$controller, 'search'])
                ->middleware('permission:api.invoice.view')
                ->name('api.v1.invoice.search');

            Route::post('/', [$controller, 'store'])
                ->middleware(['permission:api.invoice.create', 'api.idempotency'])
                ->name('api.v1.invoice.store');

            Route::get('/{id}', [$controller, 'show'])
                ->whereUuid('id')
                ->middleware('permission:api.invoice.view')
                ->name('api.v1.invoice.show');

            Route::patch('/{id}', [$controller, 'update'])
                ->whereUuid('id')
                ->middleware('permission:api.invoice.update')
                ->name('api.v1.invoice.update');

            Route::put('/{id}', [$controller, 'replace'])
                ->whereUuid('id')
                ->middleware('permission:api.invoice.update')
                ->name('api.v1.invoice.replace');

            Route::delete('/{id}', [$controller, 'destroy'])
                ->whereUuid('id')
                ->middleware('permission:api.invoice.delete')
                ->name('api.v1.invoice.destroy');

            Route::post('/{id}/status', [$controller, 'updateStatus'])
                ->whereUuid('id')
                ->middleware(['permission:api.invoice.update-status', 'api.idempotency'])
                ->name('api.v1.invoice.update-status');
        });
    });
