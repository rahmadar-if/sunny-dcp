<?php

use Illuminate\Support\Facades\Route;
use Solaris\Core\Helpers\Helper;

Route::middleware(['auth', 'menu.access'])->group(function () {

    Route::prefix('sales')->group(function () {
        Route::prefix('lead')->group(function () {
            $leadController = Helper::controller('lead');
    
            Route::get('/', [$leadController, 'index'])
                ->name('sales.lead');
            
            Route::get('/{id}', [$leadController, 'show'])
                ->whereUuid('id')
                ->name('sales.lead.read');
            
            Route::get('/edit/{id}', [$leadController, 'edit'])
                ->whereUuid('id')
                ->name('sales.lead.edit');

            Route::post('/list-summary', [$leadController, 'listSummary'])
                ->name('sales.lead.list-summary');

            Route::post('/prospect/{id}', [$leadController, 'prospect'])
                ->whereUuid('id')
                ->name('sales.lead.prospect');
        });

        Route::prefix('opportunity')->group(function () {
            $opportunityController = Helper::controller('opportunity');

            Route::get('/', [$opportunityController, 'index'])
                ->name('sales.opportunity');

            Route::get('/{id}', [$opportunityController, 'show'])
                ->whereUuid('id')
                ->name('sales.opportunity.read');

            Route::get('/edit/{id}', [$opportunityController, 'edit'])
                ->whereUuid('id')
                ->name('sales.opportunity.edit');

            Route::put('/update-status', [$opportunityController, 'updateStatus'])
                ->name('sales.opportunity.update-status');

            Route::post('/list-summary', [$opportunityController, 'listSummary'])
                ->name('sales.opportunity.list-summary');

            Route::post('/kanban-summary', [$opportunityController, 'kanbanSummary'])
                ->name('sales.opportunity.kanban-summary');

            Route::post('/print-quotation/{id}', [$opportunityController, 'printQuotation'])
                ->whereUuid('id')
                ->name('sales.opportunity.print-quotation');

            Route::post('/create-order/{id}', [$opportunityController, 'createOrder'])
                ->whereUuid('id')
                ->name('sales.opportunity.create-order');
        });

        Route::prefix('order')->group(function () {
            $orderController = Helper::controller('order');
    
            Route::get('/', [$orderController, 'index'])
                ->name('sales.order');
            
            Route::get('/{id}', [$orderController, 'show'])
                ->whereUuid('id')
                ->name('sales.order.read');
            
            Route::get('/edit/{id}', [$orderController, 'edit'])
                ->whereUuid('id')
                ->name('sales.order.edit');
        });

        Route::prefix('invoice')->group(function () {
            $invoiceController = Helper::controller('invoice');
    
            Route::get('/', [$invoiceController, 'index'])
                ->name('sales.invoice');
            
            Route::get('/{id}', [$invoiceController, 'show'])
                ->whereUuid('id')
                ->name('sales.invoice.read');
            
            Route::get('/edit/{id}', [$invoiceController, 'edit'])
                ->whereUuid('id')
                ->name('sales.invoice.edit');
        });

        Route::prefix('contract')->group(function () {
            $contractController = Helper::controller('contract');
    
            Route::get('/', [$contractController, 'index'])
                ->name('sales.contract');
            
            Route::get('/{id}', [$contractController, 'show'])
                ->whereUuid('id')
                ->name('sales.contract.read');
            
            Route::get('/edit/{id}', [$contractController, 'edit'])
                ->whereUuid('id')
                ->name('sales.contract.edit');
        });

        Route::prefix('dashboard')->group(function () {
            $controller = Helper::controller('sales_dashboard');

            Route::get('/', [$controller, 'index'])->name('sales.dashboard');
            Route::post('/all', [$controller, 'all'])->name('sales.dashboard.all');
            Route::post('/opportunity-pipeline', [$controller, 'opportunityPipeline'])->name('sales.dashboard.opportunity-pipeline');
            Route::post('/sales-analytic', [$controller, 'salesAnalytic'])->name('sales.dashboard.sales-analytic');
            Route::post('/activity', [$controller, 'activity'])->name('sales.dashboard.activity');
            Route::post('/top-sales', [$controller, 'topSales'])->name('sales.dashboard.top-sales');
            Route::post('/top-customer', [$controller, 'topCustomer'])->name('sales.dashboard.top-customer');
            Route::post('/prospect-by-source', [$controller, 'prospectBySource'])->name('sales.dashboard.prospect-by-source');
            Route::post('/opportunity-overview', [$controller, 'opportunityOverview'])->name('sales.dashboard.opportunity-overview');
            Route::post('/top-opportunity', [$controller, 'topOpportunity'])->name('sales.dashboard.top-opportunity');
            Route::post('/revenue-analytic', [$controller, 'revenueAnalytic'])->name('sales.dashboard.revenue-analytic');
            Route::post('/recent-order', [$controller, 'recentOrder'])->name('sales.dashboard.recent-order');
            Route::post('/top-order', [$controller, 'topOrder'])->name('sales.dashboard.top-order');
            Route::post('/top-product-ordered', [$controller, 'topProductOrdered'])->name('sales.dashboard.top-product-ordered');
        });
    });

});