<?php

use Illuminate\Support\Facades\Route;
use Solaris\Core\Helpers\Helper;

Route::prefix('mobile')->group(function () {
    Route::middleware('auth.mobile')->group(function () {

        Route::prefix('home')->group(function () {
            Route::get('/hot-leads', [Helper::mobileController('home'), 'hotLeads'])
                ->name('mobile.home.hot-leads');
        });

        Route::prefix('sales')->group(function () {

            Route::prefix('lead')->group(function () {
                Route::post('/prospect/{id}', [Helper::mobileController('lead'), 'prospect'])
                    ->whereUuid('id')
                    ->name('mobile.sales.lead.prospect');
            });

            Route::prefix('opportunity')->group(function () {
                $controller = Helper::mobileController('opportunity');

                Route::post('/', [$controller, 'store'])
                    ->name('mobile.sales.opportunity.store');

                Route::put('/{id}', [$controller, 'update'])
                    ->name('mobile.sales.opportunity.update');

                Route::post('/list', [$controller, 'index'])
                    ->name('mobile.sales.opportunity');

                Route::get('/{id}', [$controller, 'show'])
                    ->whereUuid('id')
                    ->name('mobile.sales.opportunity.read');

                Route::delete('/{id}', [$controller, 'destroy'])
                    ->whereUuid('id')
                    ->name('mobile.sales.opportunity.destroy');

                Route::prefix('product')->group(function () {
                    $controller = Helper::mobileController('opportunity_product');

                    Route::post('/', [$controller, 'store'])
                        ->name('mobile.sales.opportunity-product.store');

                    Route::put('/{id}', [$controller, 'update'])
                        ->name('mobile.sales.opportunity-product.update');

                    Route::post('/list', [$controller, 'index'])
                        ->name('mobile.sales.opportunity-product');

                    Route::get('/{id}', [$controller, 'show'])
                        ->whereUuid('id')
                        ->name('mobile.sales.opportunity-product.read');

                    Route::delete('/{id}', [$controller, 'destroy'])
                        ->whereUuid('id')
                        ->name('mobile.sales.opportunity-product.destroy');
                });

                Route::prefix('team')->group(function () {
                    $controller = Helper::mobileController('opportunity_team');

                    Route::post('/', [$controller, 'store'])
                        ->name('mobile.sales.opportunity-team.store');

                    Route::put('/{id}', [$controller, 'update'])
                        ->name('mobile.sales.opportunity-team.update');

                    Route::post('/list', [$controller, 'index'])
                        ->name('mobile.sales.opportunity-team');

                    Route::get('/{id}', [$controller, 'show'])
                        ->whereUuid('id')
                        ->name('mobile.sales.opportunity-team.read');

                    Route::delete('/{id}', [$controller, 'destroy'])
                        ->whereUuid('id')
                        ->name('mobile.sales.opportunity-team.destroy');
                });

                Route::prefix('contact')->group(function () {
                    $controller = Helper::mobileController('opportunity_contact');

                    Route::post('/', [$controller, 'store'])
                        ->name('mobile.sales.opportunity-contact.store');

                    Route::put('/{id}', [$controller, 'update'])
                        ->name('mobile.sales.opportunity-contact.update');

                    Route::post('/list', [$controller, 'index'])
                        ->name('mobile.sales.opportunity-contact');

                    Route::get('/{id}', [$controller, 'show'])
                        ->whereUuid('id')
                        ->name('mobile.sales.opportunity-contact.read');

                    Route::delete('/{id}', [$controller, 'destroy'])
                        ->whereUuid('id')
                        ->name('mobile.sales.opportunity-contact.destroy');
                });

                Route::prefix('competitor')->group(function () {
                    $controller = Helper::mobileController('opportunity_competitor');

                    Route::post('/', [$controller, 'store'])
                        ->name('mobile.sales.opportunity-competitor.store');

                    Route::put('/{id}', [$controller, 'update'])
                        ->name('mobile.sales.opportunity-competitor.update');

                    Route::post('/list', [$controller, 'index'])
                        ->name('mobile.sales.opportunity-competitor');

                    Route::get('/{id}', [$controller, 'show'])
                        ->whereUuid('id')
                        ->name('mobile.sales.opportunity-competitor.read');

                    Route::delete('/{id}', [$controller, 'destroy'])
                        ->whereUuid('id')
                        ->name('mobile.sales.opportunity-competitor.destroy');
                });

                Route::prefix('term-condition')->group(function () {
                    $controller = Helper::mobileController('opportunity_term_condition');

                    Route::post('/', [$controller, 'store'])
                        ->name('mobile.sales.opportunity-term-condition.store');

                    Route::put('/{id}', [$controller, 'update'])
                        ->name('mobile.sales.opportunity-term-condition.update');

                    Route::post('/list', [$controller, 'index'])
                        ->name('mobile.sales.opportunity-term-condition');

                    Route::get('/{id}', [$controller, 'show'])
                        ->whereUuid('id')
                        ->name('mobile.sales.opportunity-term-condition.read');

                    Route::delete('/{id}', [$controller, 'destroy'])
                        ->whereUuid('id')
                        ->name('mobile.sales.opportunity-term-condition.destroy');
                });

                Route::prefix('quotation-history')->group(function () {
                    $controller = Helper::mobileController('opportunity_quotation_history');

                    Route::post('/', [$controller, 'store'])
                        ->name('mobile.sales.opportunity-quotation-history.store');

                    Route::put('/{id}', [$controller, 'update'])
                        ->name('mobile.sales.opportunity-quotation-history.update');

                    Route::post('/list', [$controller, 'index'])
                        ->name('mobile.sales.opportunity-quotation-history');

                    Route::get('/{id}', [$controller, 'show'])
                        ->whereUuid('id')
                        ->name('mobile.sales.opportunity-quotation-history.read');

                    Route::delete('/{id}', [$controller, 'destroy'])
                        ->whereUuid('id')
                        ->name('mobile.sales.opportunity-quotation-history.destroy');
                });

                Route::prefix('status-history')->group(function () {
                    $controller = Helper::mobileController('opportunity_status_history');

                    Route::post('/list', [$controller, 'index'])
                        ->name('mobile.sales.opportunity-status-history');

                    Route::get('/{id}', [$controller, 'show'])
                        ->whereUuid('id')
                        ->name('mobile.sales.opportunity-status-history.read');
                });
            });

            Route::prefix('order')->group(function () {
                $controller = Helper::mobileController('order');

                Route::post('/', [$controller, 'store'])
                    ->name('mobile.sales.order.store');

                Route::put('/{id}', [$controller, 'update'])
                    ->name('mobile.sales.order.update');

                Route::post('/list', [$controller, 'index'])
                    ->name('mobile.sales.order');

                Route::get('/{id}', [$controller, 'show'])
                    ->whereUuid('id')
                    ->name('mobile.sales.order.read');

                Route::delete('/{id}', [$controller, 'destroy'])
                    ->whereUuid('id')
                    ->name('mobile.sales.order.destroy');

                Route::prefix('detail')->group(function () {
                    $controller = Helper::mobileController('order_detail');

                    Route::post('/', [$controller, 'store'])
                        ->name('mobile.sales.order-detail.store');

                    Route::put('/{id}', [$controller, 'update'])
                        ->name('mobile.sales.order-detail.update');

                    Route::post('/list', [$controller, 'index'])
                        ->name('mobile.sales.order-detail');

                    Route::get('/{id}', [$controller, 'show'])
                        ->whereUuid('id')
                        ->name('mobile.sales.order-detail.read');

                    Route::delete('/{id}', [$controller, 'destroy'])
                        ->whereUuid('id')
                        ->name('mobile.sales.order-detail.destroy');
                });

                Route::prefix('status-history')->group(function () {
                    $controller = Helper::mobileController('order_status_history');

                    Route::post('/list', [$controller, 'index'])
                        ->name('mobile.sales.order-status-history');

                    Route::get('/{id}', [$controller, 'show'])
                        ->whereUuid('id')
                        ->name('mobile.sales.order-status-history.read');
                });
            });

            Route::prefix('invoice')->group(function () {
                $controller = Helper::mobileController('invoice');

                Route::post('/', [$controller, 'store'])
                    ->name('mobile.sales.invoice.store');

                Route::put('/{id}', [$controller, 'update'])
                    ->name('mobile.sales.invoice.update');

                Route::post('/list', [$controller, 'index'])
                    ->name('mobile.sales.invoice');

                Route::get('/{id}', [$controller, 'show'])
                    ->whereUuid('id')
                    ->name('mobile.sales.invoice.read');

                Route::delete('/{id}', [$controller, 'destroy'])
                    ->whereUuid('id')
                    ->name('mobile.sales.invoice.destroy');

                Route::prefix('detail')->group(function () {
                    $controller = Helper::mobileController('invoice_detail');

                    Route::post('/', [$controller, 'store'])
                        ->name('mobile.sales.invoice-detail.store');

                    Route::put('/{id}', [$controller, 'update'])
                        ->name('mobile.sales.invoice-detail.update');

                    Route::post('/list', [$controller, 'index'])
                        ->name('mobile.sales.invoice-detail');

                    Route::get('/{id}', [$controller, 'show'])
                        ->whereUuid('id')
                        ->name('mobile.sales.invoice-detail.read');

                    Route::delete('/{id}', [$controller, 'destroy'])
                        ->whereUuid('id')
                        ->name('mobile.sales.invoice-detail.destroy');
                });

                Route::prefix('status-history')->group(function () {
                    $controller = Helper::mobileController('invoice_status_history');

                    Route::post('/list', [$controller, 'index'])
                        ->name('mobile.sales.invoice-status-history');

                    Route::get('/{id}', [$controller, 'show'])
                        ->whereUuid('id')
                        ->name('mobile.sales.invoice-status-history.read');
                });
            });

            Route::prefix('contract')->group(function () {
                $controller = Helper::mobileController('contract');

                Route::post('/', [$controller, 'store'])
                    ->name('mobile.sales.contract.store');

                Route::put('/{id}', [$controller, 'update'])
                    ->name('mobile.sales.contract.update');

                Route::post('/list', [$controller, 'index'])
                    ->name('mobile.sales.contract');

                Route::get('/{id}', [$controller, 'show'])
                    ->whereUuid('id')
                    ->name('mobile.sales.contract.read');

                Route::delete('/{id}', [$controller, 'destroy'])
                    ->whereUuid('id')
                    ->name('mobile.sales.contract.destroy');
            });

            Route::prefix('dashboard')->group(function () {
                $controller = Helper::mobileController('sales_dashboard');

                Route::post('/all', [$controller, 'all'])->name('mobile.sales.dashboard.all');
                Route::post('/opportunity-pipeline', [$controller, 'opportunityPipeline'])->name('mobile.sales.dashboard.opportunity-pipeline');
                Route::post('/sales-analytic', [$controller, 'salesAnalytic'])->name('mobile.sales.dashboard.sales-analytic');
                Route::post('/activity', [$controller, 'activity'])->name('mobile.sales.dashboard.activity');
                Route::post('/top-sales', [$controller, 'topSales'])->name('mobile.sales.dashboard.top-sales');
                Route::post('/top-customer', [$controller, 'topCustomer'])->name('mobile.sales.dashboard.top-customer');
                Route::post('/prospect-by-source', [$controller, 'prospectBySource'])->name('mobile.sales.dashboard.prospect-by-source');
                Route::post('/opportunity-overview', [$controller, 'opportunityOverview'])->name('mobile.sales.dashboard.opportunity-overview');
                Route::post('/top-opportunity', [$controller, 'topOpportunity'])->name('mobile.sales.dashboard.top-opportunity');
                Route::post('/revenue-analytic', [$controller, 'revenueAnalytic'])->name('mobile.sales.dashboard.revenue-analytic');
                Route::post('/recent-order', [$controller, 'recentOrder'])->name('mobile.sales.dashboard.recent-order');
                Route::post('/top-order', [$controller, 'topOrder'])->name('mobile.sales.dashboard.top-order');
                Route::post('/top-product-ordered', [$controller, 'topProductOrdered'])->name('mobile.sales.dashboard.top-product-ordered');
            });
        });
    });
});
