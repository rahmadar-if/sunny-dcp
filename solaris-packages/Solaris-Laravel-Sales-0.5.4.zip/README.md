# Solaris Sales

A Laravel package for managing the full sales pipeline — built on top of `solaris/solaris-laravel-basecrm`.

Covers the complete sales cycle from Leads and Opportunities through Orders, Invoices, and Contracts, with stage history tracking, quotation management, and granular access control wired in from the start.

---

## Requirements

- PHP 8.2+
- Laravel 11 or 12
- `solaris/solaris-laravel-basecrm` v0.4.2+

---

## Modules

### Lead
Extends BaseCRM Lead with sales-specific handling.

- Full lead info inherited from BaseCRM
- Integrated into the sales pipeline flow

### Opportunity
Manages sales opportunities from qualification to close.

- Basic info: title, description, budget, expected close date
- Relationships: Account, Contact, Lead source
- Stage pipeline with configurable `OpportunityStatus` lookup
- Full **stage history** with timestamps per transition
- **Competitors**: track competing vendors per opportunity
- **Contacts**: multiple stakeholders linked per opportunity
- **Products**: products pitched per opportunity
- **Team**: internal team members assigned
- **Term & Conditions**: negotiated terms tracking
- **Quotation History**: versioned quotation records

### Order
Manages sales orders generated from opportunities.

- Linked to Account and Contact
- **Order Details**: line items with product, quantity, and pricing
- Status workflow via `OrderStatus` lookup
- Full **status history** with timestamps per transition

### Invoice
Manages invoices raised against orders.

- Linked to Account, Contact, and Order
- **Invoice Details**: line items with product, quantity, and pricing
- Status workflow via `InvoiceStatus` lookup
- Full **status history** with timestamps per transition

### Contract
Manages contracts finalized from opportunities or orders.

- Linked to Account and Contact
- Contract reference and term tracking

### Activity
Extends BaseCRM Activity for sales context.

- Full activity tracking inherited from BaseCRM
- Linked to sales entities (Opportunity, Order)

### Dashboard
Sales analytics and metrics overview.

- Multiple analytics endpoints under `/sales/dashboard`
- Metric boards for pipeline health, revenue tracking, and activity summaries

---

## Architecture

All modules follow the same pattern inherited from `solaris-laravel-core`:

- **Models** extend `BaseModel` (UUID primary key, audit fields, soft deletes)
- **Repositories** extend `BaseRepository` (CRUD, batch ops, attachment handling)
- **Controllers** handle list, edit, and batch delete via standard endpoints
- **FormRequests** extend `BaseFormRequest` for consistent validation

Routes are prefixed under `/sales` and protected by `auth` and `menu.access` middleware.

---

## Lookup / Reference Data

The following reference models are bundled and auto-registered for lookup management:

| Model | Description |
|---|---|
| `OpportunityStatus` | Opportunity pipeline stages (supports final stage flag) |
| `OrderStatus` | Order workflow stages |
| `InvoiceStatus` | Invoice workflow stages |

---

## Changelog

Please see [CHANGELOG](CHANGELOG.md) for recent changes.
