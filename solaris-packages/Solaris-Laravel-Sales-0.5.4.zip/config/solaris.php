<?php

// config for Solaris/Sales
return [

    /*
    |--------------------------------------------------------------------------
    | Resources
    |--------------------------------------------------------------------------
    */
    'resource' => [
        'path' => [
            'sales' => 'vendor/solaris/solaris-laravel-sales/resources',
        ],
        'views' => [
            'account' => [
                'page' => 'sales::pages.account.page',
            ],
            'contact' => [
                'page' => 'sales::pages.contact.page',
            ],
            'activity' => [
                'page' => 'sales::pages.activity.page',
            ],
            'lead' => [
                'list' => 'sales::pages.lead.list',
                'page' => 'sales::pages.lead.page',
            ],
            'opportunity' => [
                'list' => 'sales::pages.opportunity.list',
                'page' => 'sales::pages.opportunity.page',
            ],
            'contract' => [
                'list' => 'sales::pages.contract.list',
                'page' => 'sales::pages.contract.page',
            ],
            'order' => [
                'list' => 'sales::pages.order.list',
                'page' => 'sales::pages.order.page',
            ],
            'invoice' => [
                'list' => 'sales::pages.invoice.list',
                'page' => 'sales::pages.invoice.page',
            ],
            'sales_dashboard' => 'sales::pages.sales-dashboard.page',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Models
    |--------------------------------------------------------------------------
    */
    'model' => [
        'namespaces' => [
            'Solaris\\Sales\\Models' => base_path('vendor/solaris/solaris-laravel-sales/src/Models'),
        ],
        'models' => [
            'account'  => 'Solaris\\Sales\\Models\\Account',
            'contact'  => 'Solaris\\Sales\\Models\\Contact',
            'activity' => 'Solaris\\Sales\\Models\\Activity',
            'product'  => 'Solaris\\Sales\\Models\\Product',
            'lead'     => 'Solaris\\Sales\\Models\\Lead',
            'contract' => 'Solaris\\Sales\\Models\\Contract',

            'opportunity'                   => 'Solaris\\Sales\\Models\\Opportunity',
            'opportunity_type'              => 'Solaris\\Sales\\Models\\OpportunityType',
            'opportunity_status'            => 'Solaris\\Sales\\Models\\OpportunityStatus',
            'opportunity_product'           => 'Solaris\\Sales\\Models\\OpportunityProduct',
            'opportunity_quotation_history' => 'Solaris\\Sales\\Models\\OpportunityQuotationHistory',
            'opportunity_team'              => 'Solaris\\Sales\\Models\\OpportunityTeam',
            'opportunity_contact'           => 'Solaris\\Sales\\Models\\OpportunityContact',
            'opportunity_competitor'        => 'Solaris\\Sales\\Models\\OpportunityCompetitor',
            'opportunity_status_history'    => 'Solaris\\Sales\\Models\\OpportunityStatusHistory',
            'opportunity_term_condition'    => 'Solaris\\Sales\\Models\\OpportunityTermCondition',

            'order'                => 'Solaris\\Sales\\Models\\Order',
            'order_detail'         => 'Solaris\\Sales\\Models\\OrderDetail',
            'order_status'         => 'Solaris\\Sales\\Models\\OrderStatus',
            'order_status_history' => 'Solaris\\Sales\\Models\\OrderStatusHistory',

            'invoice'                => 'Solaris\\Sales\\Models\\Invoice',
            'invoice_detail'         => 'Solaris\\Sales\\Models\\InvoiceDetail',
            'invoice_status'         => 'Solaris\\Sales\\Models\\InvoiceStatus',
            'invoice_status_history' => 'Solaris\\Sales\\Models\\InvoiceStatusHistory',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Repositories
    |--------------------------------------------------------------------------
    */
    'repositories' => [
        'account'  => 'Solaris\\Sales\\Repositories\\AccountRepository',
        'contact'  => 'Solaris\\Sales\\Repositories\\ContactRepository',
        'lead'     => 'Solaris\\Sales\\Repositories\\LeadRepository',
        'contract' => 'Solaris\\Core\\Repositories\\BaseRepository',

        'opportunity'                   => 'Solaris\\Sales\\Repositories\\OpportunityRepository',
        'opportunity_product'           => 'Solaris\\Sales\\Repositories\\OpportunityProductRepository',
        'opportunity_team'              => 'Solaris\\Core\\Repositories\\BaseRepository',
        'opportunity_contact'           => 'Solaris\\Sales\\Repositories\\OpportunityContactRepository',
        'opportunity_competitor'        => 'Solaris\\Core\\Repositories\\BaseRepository',
        'opportunity_term_condition'    => 'Solaris\\Core\\Repositories\\BaseRepository',
        'opportunity_quotation_history' => 'Solaris\\Core\\Repositories\\BaseRepository',

        'order'        => 'Solaris\\Sales\\Repositories\\OrderRepository',
        'order_detail' => 'Solaris\\Sales\\Repositories\\OrderDetailRepository',

        'invoice'        => 'Solaris\\Sales\\Repositories\\InvoiceRepository',
        'invoice_detail' => 'Solaris\\Sales\\Repositories\\InvoiceDetailRepository',
    ],

    /*
    |--------------------------------------------------------------------------
    | HTTP Layer
    |--------------------------------------------------------------------------
    */
    'controller' => [
        'namespaces' => [
            'Solaris\\Sales\\Http\\Controllers',
        ],
        'controllers' => [
            'lead' => 'Solaris\\Sales\\Http\\Controllers\\LeadController',

            'opportunity'                   => 'Solaris\\Sales\\Http\\Controllers\\OpportunityController',
            'opportunity_product'           => 'Solaris\\Sales\\Http\\Controllers\\OpportunityProductController',
            'opportunity_team'              => 'Solaris\\Sales\\Http\\Controllers\\OpportunityTeamController',
            'opportunity_contact'           => 'Solaris\\Sales\\Http\\Controllers\\OpportunityContactController',
            'opportunity_competitor'        => 'Solaris\\Sales\\Http\\Controllers\\OpportunityCompetitorController',
            'opportunity_term_condition'    => 'Solaris\\Sales\\Http\\Controllers\\OpportunityTermConditionController',
            'opportunity_quotation_history' => 'Solaris\\Sales\\Http\\Controllers\\OpportunityQuotationHistoryController',

            'contract' => 'Solaris\\Sales\\Http\\Controllers\\ContractController',

            'order'        => 'Solaris\\Sales\\Http\\Controllers\\OrderController',
            'order_detail' => 'Solaris\\Sales\\Http\\Controllers\\OrderDetailController',

            'invoice'        => 'Solaris\\Sales\\Http\\Controllers\\InvoiceController',
            'invoice_detail' => 'Solaris\\Sales\\Http\\Controllers\\InvoiceDetailController',

            'sales_dashboard' => 'Solaris\\Sales\\Http\\Controllers\\SalesDashboardController',

            'activity' => 'Solaris\\Sales\\Http\\Controllers\\ActivityController',
        ],
    ],

    'form_requests' => [
        'opportunity'                   => 'Solaris\\Sales\\Http\\Requests\\OpportunityRequest',
        'opportunity_product'           => 'Solaris\\Sales\\Http\\Requests\\OpportunityProductRequest',
        'opportunity_team'              => 'Solaris\\Sales\\Http\\Requests\\OpportunityTeamRequest',
        'opportunity_contact'           => 'Solaris\\Sales\\Http\\Requests\\OpportunityContactRequest',
        'opportunity_competitor'        => 'Solaris\\Sales\\Http\\Requests\\OpportunityCompetitorRequest',
        'opportunity_term_condition'    => 'Solaris\\Sales\\Http\\Requests\\OpportunityTermConditionRequest',
        'opportunity_quotation_history' => 'Solaris\\Sales\\Http\\Requests\\OpportunityQuotationHistoryRequest',

        'contract' => 'Solaris\\Sales\\Http\\Requests\\ContractRequest',

        'order'        => 'Solaris\\Sales\\Http\\Requests\\OrderRequest',
        'order_detail' => 'Solaris\\Sales\\Http\\Requests\\OrderDetailRequest',

        'invoice'        => 'Solaris\\Sales\\Http\\Requests\\InvoiceRequest',
        'invoice_detail' => 'Solaris\\Sales\\Http\\Requests\\InvoiceDetailRequest',

        'activity' => 'Solaris\\Sales\\Http\\Requests\\ActivityRequest',
    ],

    /*
    |--------------------------------------------------------------------------
    | 3rd Party API
    |--------------------------------------------------------------------------
    */
    'api' => [
        'controllers' => [
            'account'  => 'Solaris\\Sales\\Http\\Controllers\\Api\\AccountController',
            'contact'  => 'Solaris\\Sales\\Http\\Controllers\\Api\\ContactController',
            'activity' => 'Solaris\\Sales\\Http\\Controllers\\Api\\ActivityController',
            'lead'        => 'Solaris\\Sales\\Http\\Controllers\\Api\\LeadController',
            'opportunity' => 'Solaris\\Sales\\Http\\Controllers\\Api\\OpportunityController',
            'order'       => 'Solaris\\Sales\\Http\\Controllers\\Api\\OrderController',
            'invoice'     => 'Solaris\\Sales\\Http\\Controllers\\Api\\InvoiceController',
        ],

        'resources' => [
            'account'  => 'Solaris\\Sales\\Http\\Resources\\Api\\AccountResource',
            'contact'  => 'Solaris\\Sales\\Http\\Resources\\Api\\ContactResource',
            'activity' => 'Solaris\\Sales\\Http\\Resources\\Api\\ActivityResource',
            'lead'        => 'Solaris\\Sales\\Http\\Resources\\Api\\LeadResource',
            'opportunity' => 'Solaris\\Sales\\Http\\Resources\\Api\\OpportunityResource',
            'order'       => 'Solaris\\Sales\\Http\\Resources\\Api\\OrderResource',
            'invoice'     => 'Solaris\\Sales\\Http\\Resources\\Api\\InvoiceResource',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Mobile
    |--------------------------------------------------------------------------
    */
    'mobile' => [
        'controllers' => [
            'lead' => 'Solaris\\Sales\\Http\\Controllers\\Mobile\\LeadController',

            'opportunity'                   => 'Solaris\\Sales\\Http\\Controllers\\Mobile\\OpportunityController',
            'opportunity_product'           => 'Solaris\\Sales\\Http\\Controllers\\Mobile\\OpportunityProductController',
            'opportunity_team'              => 'Solaris\\Sales\\Http\\Controllers\\Mobile\\OpportunityTeamController',
            'opportunity_contact'           => 'Solaris\\Sales\\Http\\Controllers\\Mobile\\OpportunityContactController',
            'opportunity_competitor'        => 'Solaris\\Sales\\Http\\Controllers\\Mobile\\OpportunityCompetitorController',
            'opportunity_term_condition'    => 'Solaris\\Sales\\Http\\Controllers\\Mobile\\OpportunityTermConditionController',
            'opportunity_quotation_history' => 'Solaris\\Sales\\Http\\Controllers\\Mobile\\OpportunityQuotationHistoryController',
            'opportunity_status_history'    => 'Solaris\\Sales\\Http\\Controllers\\Mobile\\OpportunityStatusHistoryController',

            'order'                 => 'Solaris\\Sales\\Http\\Controllers\\Mobile\\OrderController',
            'order_detail'          => 'Solaris\\Sales\\Http\\Controllers\\Mobile\\OrderDetailController',
            'order_status_history'  => 'Solaris\\Sales\\Http\\Controllers\\Mobile\\OrderStatusHistoryController',

            'invoice'                => 'Solaris\\Sales\\Http\\Controllers\\Mobile\\InvoiceController',
            'invoice_detail'         => 'Solaris\\Sales\\Http\\Controllers\\Mobile\\InvoiceDetailController',
            'invoice_status_history' => 'Solaris\\Sales\\Http\\Controllers\\Mobile\\InvoiceStatusHistoryController',

            'contract' => 'Solaris\\Sales\\Http\\Controllers\\Mobile\\ContractController',

            'home'            => 'Solaris\\Sales\\Http\\Controllers\\Mobile\\HomeController',
            'sales_dashboard' => 'Solaris\\Sales\\Http\\Controllers\\Mobile\\SalesDashboardController',
        ],

        'resources' => [
            'lead' => 'Solaris\\Sales\\Http\\Resources\\Mobile\\LeadResource',

            'opportunity'                   => 'Solaris\\Sales\\Http\\Resources\\Mobile\\OpportunityResource',
            'opportunity_product'           => 'Solaris\\Sales\\Http\\Resources\\Mobile\\OpportunityProductResource',
            'opportunity_team'              => 'Solaris\\Sales\\Http\\Resources\\Mobile\\OpportunityTeamResource',
            'opportunity_contact'           => 'Solaris\\Sales\\Http\\Resources\\Mobile\\OpportunityContactResource',
            'opportunity_competitor'        => 'Solaris\\Sales\\Http\\Resources\\Mobile\\OpportunityCompetitorResource',
            'opportunity_term_condition'    => 'Solaris\\Sales\\Http\\Resources\\Mobile\\OpportunityTermConditionResource',
            'opportunity_quotation_history' => 'Solaris\\Sales\\Http\\Resources\\Mobile\\OpportunityQuotationHistoryResource',
            'opportunity_status_history'    => 'Solaris\\Sales\\Http\\Resources\\Mobile\\OpportunityStatusHistoryResource',

            'order'                 => 'Solaris\\Sales\\Http\\Resources\\Mobile\\OrderResource',
            'order_detail'          => 'Solaris\\Sales\\Http\\Resources\\Mobile\\OrderDetailResource',
            'order_status_history'  => 'Solaris\\Sales\\Http\\Resources\\Mobile\\OrderStatusHistoryResource',

            'invoice'                => 'Solaris\\Sales\\Http\\Resources\\Mobile\\InvoiceResource',
            'invoice_detail'         => 'Solaris\\Sales\\Http\\Resources\\Mobile\\InvoiceDetailResource',
            'invoice_status_history' => 'Solaris\\Sales\\Http\\Resources\\Mobile\\InvoiceStatusHistoryResource',

            'contract' => 'Solaris\\Sales\\Http\\Resources\\Mobile\\ContractResource',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Artificial Intelligence
    |--------------------------------------------------------------------------
    |
    | Own slug=>FQCN registry entries, merged into Core's ai.agents/ai.tools — same declarative pattern as
    | Core/MasterData (see MasterData's config/solaris.php doc comment), read by AiRegistryService::sync().
    | No imperative boot-time registration in the service provider.
    |
    | SalesAgent (Lead + Opportunity, incl. product line items and quotations) and OrderAgent (Order,
    | Contract, Invoice — read-only so far) split the sales pipeline into "selling" vs "fulfillment/billing"
    | so neither specialist carries more tools/instructions than one conversation turn needs.
    |
    */
    'ai' => [
        'agents' => [
            'sales' => 'Solaris\\Sales\\Ai\\Agents\\SalesAgent',
            'order' => 'Solaris\\Sales\\Ai\\Agents\\OrderAgent',
        ],

        'tools' => [
            // Overrides BaseCRM's search_activity/search_lead/search_account/search_contact with
            // Sales-linked columns/relations (opportunity/order/invoice on Activity, opportunity on Lead,
            // opportunities on Account/Contact). Picked up automatically by MasterData/BaseCRM's own
            // registration — no re-registration needed here.
            'search_activity' => 'Solaris\\Sales\\Ai\\Tools\\Activity\\SearchActivityTool',
            'search_lead'     => 'Solaris\\Sales\\Ai\\Tools\\Lead\\SearchLeadTool',
            'search_account'  => 'Solaris\\Sales\\Ai\\Tools\\Account\\SearchAccountTool',
            'search_contact'  => 'Solaris\\Sales\\Ai\\Tools\\Contact\\SearchContactTool',

            // Sales-native lead action (qualify + convert to opportunity) — BaseCRM owns the Lead CRUD tools.
            'hot_lead' => 'Solaris\\Sales\\Ai\\Tools\\Lead\\HotLeadTool',

            'create_opportunity' => 'Solaris\\Sales\\Ai\\Tools\\Opportunity\\CreateOpportunityTool',
            'update_opportunity' => 'Solaris\\Sales\\Ai\\Tools\\Opportunity\\UpdateOpportunityTool',
            'delete_opportunity' => 'Solaris\\Sales\\Ai\\Tools\\Opportunity\\DeleteOpportunityTool',
            'search_opportunity' => 'Solaris\\Sales\\Ai\\Tools\\Opportunity\\SearchOpportunityTool',

            // Reference-shaped variant for agents that only point at a deal (order, activity) — never
            // grant it alongside the full tool, the agent would carry both descriptions.
            'search_opportunity_basic' => 'Solaris\\Sales\\Ai\\Tools\\Opportunity\\SearchOpportunityBasicTool',


            'search_opportunity_quotation_history' => 'Solaris\\Sales\\Ai\\Tools\\OpportunityQuotationHistory\\SearchOpportunityQuotationHistoryTool',

            'create_opportunity_product' => 'Solaris\\Sales\\Ai\\Tools\\OpportunityProduct\\CreateOpportunityProductTool',
            'update_opportunity_product' => 'Solaris\\Sales\\Ai\\Tools\\OpportunityProduct\\UpdateOpportunityProductTool',
            'delete_opportunity_product' => 'Solaris\\Sales\\Ai\\Tools\\OpportunityProduct\\DeleteOpportunityProductTool',
            'search_opportunity_product' => 'Solaris\\Sales\\Ai\\Tools\\OpportunityProduct\\SearchOpportunityProductTool',

            'create_opportunity_team' => 'Solaris\\Sales\\Ai\\Tools\\OpportunityTeam\\CreateOpportunityTeamTool',
            'update_opportunity_team' => 'Solaris\\Sales\\Ai\\Tools\\OpportunityTeam\\UpdateOpportunityTeamTool',
            'delete_opportunity_team' => 'Solaris\\Sales\\Ai\\Tools\\OpportunityTeam\\DeleteOpportunityTeamTool',
            'search_opportunity_team' => 'Solaris\\Sales\\Ai\\Tools\\OpportunityTeam\\SearchOpportunityTeamTool',

            'create_opportunity_contact' => 'Solaris\\Sales\\Ai\\Tools\\OpportunityContact\\CreateOpportunityContactTool',
            'update_opportunity_contact' => 'Solaris\\Sales\\Ai\\Tools\\OpportunityContact\\UpdateOpportunityContactTool',
            'delete_opportunity_contact' => 'Solaris\\Sales\\Ai\\Tools\\OpportunityContact\\DeleteOpportunityContactTool',
            'search_opportunity_contact' => 'Solaris\\Sales\\Ai\\Tools\\OpportunityContact\\SearchOpportunityContactTool',

            'create_opportunity_competitor' => 'Solaris\\Sales\\Ai\\Tools\\OpportunityCompetitor\\CreateOpportunityCompetitorTool',
            'update_opportunity_competitor' => 'Solaris\\Sales\\Ai\\Tools\\OpportunityCompetitor\\UpdateOpportunityCompetitorTool',
            'delete_opportunity_competitor' => 'Solaris\\Sales\\Ai\\Tools\\OpportunityCompetitor\\DeleteOpportunityCompetitorTool',
            'search_opportunity_competitor' => 'Solaris\\Sales\\Ai\\Tools\\OpportunityCompetitor\\SearchOpportunityCompetitorTool',

            'create_opportunity_term_condition' => 'Solaris\\Sales\\Ai\\Tools\\OpportunityTermCondition\\CreateOpportunityTermConditionTool',
            'update_opportunity_term_condition' => 'Solaris\\Sales\\Ai\\Tools\\OpportunityTermCondition\\UpdateOpportunityTermConditionTool',
            'delete_opportunity_term_condition' => 'Solaris\\Sales\\Ai\\Tools\\OpportunityTermCondition\\DeleteOpportunityTermConditionTool',
            'search_opportunity_term_condition' => 'Solaris\\Sales\\Ai\\Tools\\OpportunityTermCondition\\SearchOpportunityTermConditionTool',

            'search_opportunity_status_history' => 'Solaris\\Sales\\Ai\\Tools\\OpportunityStatusHistory\\SearchOpportunityStatusHistoryTool',

            'print_quotation' => 'Solaris\\Sales\\Ai\\Tools\\Opportunity\\PrintQuotationTool',

            'create_order' => 'Solaris\\Sales\\Ai\\Tools\\Order\\CreateOrderTool',
            'update_order' => 'Solaris\\Sales\\Ai\\Tools\\Order\\UpdateOrderTool',
            'delete_order' => 'Solaris\\Sales\\Ai\\Tools\\Order\\DeleteOrderTool',
            'search_order' => 'Solaris\\Sales\\Ai\\Tools\\Order\\SearchOrderTool',

            'create_order_detail' => 'Solaris\\Sales\\Ai\\Tools\\OrderDetail\\CreateOrderDetailTool',
            'update_order_detail' => 'Solaris\\Sales\\Ai\\Tools\\OrderDetail\\UpdateOrderDetailTool',
            'delete_order_detail' => 'Solaris\\Sales\\Ai\\Tools\\OrderDetail\\DeleteOrderDetailTool',
            'search_order_detail' => 'Solaris\\Sales\\Ai\\Tools\\OrderDetail\\SearchOrderDetailTool',

            'search_order_status_history' => 'Solaris\\Sales\\Ai\\Tools\\OrderStatusHistory\\SearchOrderStatusHistoryTool',

            'create_invoice' => 'Solaris\\Sales\\Ai\\Tools\\Invoice\\CreateInvoiceTool',
            'update_invoice' => 'Solaris\\Sales\\Ai\\Tools\\Invoice\\UpdateInvoiceTool',
            'delete_invoice' => 'Solaris\\Sales\\Ai\\Tools\\Invoice\\DeleteInvoiceTool',
            'search_invoice' => 'Solaris\\Sales\\Ai\\Tools\\Invoice\\SearchInvoiceTool',

            'create_invoice_detail' => 'Solaris\\Sales\\Ai\\Tools\\InvoiceDetail\\CreateInvoiceDetailTool',
            'update_invoice_detail' => 'Solaris\\Sales\\Ai\\Tools\\InvoiceDetail\\UpdateInvoiceDetailTool',
            'delete_invoice_detail' => 'Solaris\\Sales\\Ai\\Tools\\InvoiceDetail\\DeleteInvoiceDetailTool',
            'search_invoice_detail' => 'Solaris\\Sales\\Ai\\Tools\\InvoiceDetail\\SearchInvoiceDetailTool',

            'search_invoice_status_history' => 'Solaris\\Sales\\Ai\\Tools\\InvoiceStatusHistory\\SearchInvoiceStatusHistoryTool',

            'create_contract' => 'Solaris\\Sales\\Ai\\Tools\\Contract\\CreateContractTool',
            'update_contract' => 'Solaris\\Sales\\Ai\\Tools\\Contract\\UpdateContractTool',
            'delete_contract' => 'Solaris\\Sales\\Ai\\Tools\\Contract\\DeleteContractTool',
            'search_contract' => 'Solaris\\Sales\\Ai\\Tools\\Contract\\SearchContractTool',
        ],

        // Provider/model failover chain for SalesAgent and OrderAgent (see Core's Ai\Concerns\HasProviderFailover) —
        // same shape/key as Core's ai.agent_providers, this package only supplies its own agents' chains.
        'agent_providers' => [
            'sales' => [
                'providers' => [
                    'openrouter' => env('SALES_AGENT_OPENROUTER_MODEL') ?: 'deepseek/deepseek-v4-pro',
                    'gemini'     => env('SALES_AGENT_GEMINI_MODEL') ?: 'gemini-3.5-flash-lite',
                    'anthropic'  => env('SALES_AGENT_ANTHROPIC_MODEL') ?: 'claude-haiku-4-5-20251001',
                    'openai'     => env('SALES_AGENT_OPENAI_MODEL') ?: 'gpt-5.4-nano',
                ],
            ],
            'order' => [
                'providers' => [
                    'openrouter' => env('ORDER_AGENT_OPENROUTER_MODEL') ?: 'deepseek/deepseek-v4-pro',
                    'gemini'     => env('ORDER_AGENT_GEMINI_MODEL') ?: 'gemini-3.5-flash-lite',
                    'anthropic'  => env('ORDER_AGENT_ANTHROPIC_MODEL') ?: 'claude-haiku-4-5-20251001',
                    'openai'     => env('ORDER_AGENT_OPENAI_MODEL') ?: 'gpt-5.4-nano',
                ],
            ],
        ],
    ],
];
